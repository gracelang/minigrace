#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_ast_outer_5(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_7(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_8(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_body_9(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_register_11(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_11(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_13(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_22(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_68(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_70(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_71(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_body_72(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_register_74(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_74(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_76(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_85(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_117(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_134(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_136(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_137(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_thenblock_138(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_elseblock_139(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_register_141(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_register_141(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_line_143(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object reader_ast_outer_152(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_184(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_213(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_230(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_232(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_234(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_params_235(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_body_236(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_selfclosure_238(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_register_240(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object writer_ast_register_240(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[6] = args[0];
  return nothing;
}
Object reader_ast_line_242(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[7];
}
Object reader_ast_outer_251(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_269(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_298(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_315(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_317(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_318(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_params_319(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_rtype_320(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_line_322(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_register_324(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object writer_ast_register_324(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[6] = args[0];
  return nothing;
}
Object reader_ast_outer_333(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_398(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_434(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_436(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_437(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_methods_438(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_unionTypes_440(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_intersectionTypes_442(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_line_444(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object reader_ast_generics_446(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[7];
}
Object writer_ast_generics_446(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[7] = args[0];
  return nothing;
}
Object reader_ast_nominal_448(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[8];
}
Object writer_ast_nominal_448(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[8] = args[0];
  return nothing;
}
Object reader_ast_register_450(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[9];
}
Object writer_ast_register_450(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[9] = args[0];
  return nothing;
}
Object reader_ast_outer_459(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_507(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_550(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_581(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_602(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_604(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_605(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_params_606(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_body_607(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_dtype_608(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_dtype_608(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_varargs_610(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object writer_ast_varargs_610(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[6] = args[0];
  return nothing;
}
Object reader_ast_vararg_612(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[7];
}
Object writer_ast_vararg_612(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[7] = args[0];
  return nothing;
}
Object reader_ast_selfclosure_614(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[8];
}
Object writer_ast_selfclosure_614(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[8] = args[0];
  return nothing;
}
Object reader_ast_register_616(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[9];
}
Object writer_ast_register_616(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[9] = args[0];
  return nothing;
}
Object reader_ast_line_618(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[10];
}
Object reader_ast_outer_627(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_662(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_691(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_708(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_710(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_711(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_with_712(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_line_717(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_register_719(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_register_719(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_outer_728(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_769(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_786(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_788(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_789(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_name_790(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_params_791(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_register_793(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_register_793(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_line_795(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object reader_ast_superclass_796(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[7];
}
Object reader_ast_outer_805(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_861(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_889(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_906(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_908(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_909(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_register_911(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_911(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_913(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_superclass_914(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_otype_916(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object writer_ast_otype_916(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[6] = args[0];
  return nothing;
}
Object reader_ast_outer_925(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_977(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_994(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_996(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_997(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_register_999(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_999(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_1001(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_outer_1010(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1022(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1039(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1041(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1042(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_ast_value_1042(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_ast_in_1043(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_register_1045(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_1045(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_1047(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_1056(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1082(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1084(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1085(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_params_1086(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_register_1088(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_1088(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_1090(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_1104(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1121(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1123(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1124(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_ast_value_1124(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_ast_dtype_1125(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_dtype_1125(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_register_1127(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_1127(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_1129(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_1140(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1142(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1143(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_register_1145(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_1145(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_1147(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_outer_1158(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1160(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1161(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_ast_value_1161(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_ast_register_1163(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_1163(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_1165(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_outer_1176(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1178(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1179(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_register_1181(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_1181(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_1183(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_outer_1194(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1196(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1197(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_left_1198(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_right_1199(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_register_1201(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_register_1201(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_line_1203(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object reader_ast_outer_1212(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1256(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1258(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1259(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_index_1260(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_register_1262(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_1262(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_1264(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_1273(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1311(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1313(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_dest_1314(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_value_1315(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_register_1317(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_register_1317(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_line_1319(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_ast_outer_1328(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1366(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1368(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_name_1369(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_value_1370(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_dtype_1371(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_dtype_1371(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_register_1373(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_register_1373(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_line_1375(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object reader_ast_outer_1384(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1432(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1434(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_name_1435(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_value_1436(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_ast_dtype_1437(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_ast_dtype_1437(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_ast_register_1439(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_ast_register_1439(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_ast_line_1441(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[6];
}
Object reader_ast_outer_1450(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1501(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1503(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1504(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_register_1506(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_1506(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_1508(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_outer_1517(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_outer_1541(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_ast_kind_1543(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_ast_value_1544(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_ast_register_1546(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_ast_register_1546(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_ast_line_1548(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_ast_outer_1557(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_util_init();
Object module_util;
static Object strlit6;
static Object strlit10;
static Object strlit15;
static Object strlit24;
static Object strlit29;
static Object strlit40;
static Object strlit46;
static Object strlit50;
static Object strlit55;
static Object strlit69;
static Object strlit73;
static Object strlit78;
static Object strlit87;
static Object strlit92;
static Object strlit103;
static Object strlit109;
static Object strlit119;
static Object strlit135;
static Object strlit140;
static Object strlit145;
static Object strlit154;
static Object strlit159;
static Object strlit170;
static Object strlit176;
static Object strlit186;
static Object strlit199;
static Object strlit205;
static Object strlit215;
static Object strlit231;
static Object strlit233;
static Object strlit239;
static Object strlit244;
static Object strlit253;
static Object strlit258;
static Object strlit261;
static Object strlit271;
static Object strlit284;
static Object strlit290;
static Object strlit300;
static Object strlit316;
static Object strlit323;
static Object strlit326;
static Object strlit335;
static Object strlit340;
static Object strlit341;
static Object strlit344;
static Object strlit349;
static Object strlit355;
static Object strlit364;
static Object strlit367;
static Object strlit372;
static Object strlit377;
static Object strlit384;
static Object strlit390;
static Object strlit400;
static Object strlit417;
static Object strlit420;
static Object strlit427;
static Object strlit435;
static Object strlit449;
static Object strlit452;
static Object strlit461;
static Object strlit466;
static Object strlit467;
static Object strlit470;
static Object strlit475;
static Object strlit481;
static Object strlit491;
static Object strlit494;
static Object strlit499;
static Object strlit509;
static Object strlit512;
static Object strlit517;
static Object strlit523;
static Object strlit534;
static Object strlit537;
static Object strlit542;
static Object strlit552;
static Object strlit555;
static Object strlit560;
static Object strlit566;
static Object strlit573;
static Object strlit583;
static Object strlit596;
static Object strlit603;
static Object strlit615;
static Object strlit620;
static Object strlit629;
static Object strlit634;
static Object strlit637;
static Object strlit648;
static Object strlit654;
static Object strlit664;
static Object strlit677;
static Object strlit683;
static Object strlit693;
static Object strlit709;
static Object strlit718;
static Object strlit721;
static Object strlit730;
static Object strlit735;
static Object strlit738;
static Object strlit742;
static Object strlit755;
static Object strlit761;
static Object strlit771;
static Object strlit787;
static Object strlit792;
static Object strlit798;
static Object strlit807;
static Object strlit812;
static Object strlit818;
static Object strlit826;
static Object strlit831;
static Object strlit835;
static Object strlit848;
static Object strlit853;
static Object strlit863;
static Object strlit876;
static Object strlit881;
static Object strlit891;
static Object strlit907;
static Object strlit910;
static Object strlit918;
static Object strlit927;
static Object strlit932;
static Object strlit938;
static Object strlit943;
static Object strlit947;
static Object strlit960;
static Object strlit965;
static Object strlit979;
static Object strlit995;
static Object strlit998;
static Object strlit1003;
static Object strlit1012;
static Object strlit1017;
static Object strlit1024;
static Object strlit1040;
static Object strlit1044;
static Object strlit1049;
static Object strlit1058;
static Object strlit1063;
static Object strlit1067;
static Object strlit1083;
static Object strlit1087;
static Object strlit1092;
static Object strlit1097;
static Object strlit1111;
static Object strlit1116;
static Object strlit1122;
static Object strlit1126;
static Object strlit1131;
static Object strlit1135;
static Object strlit1141;
static Object strlit1144;
static Object strlit1149;
static Object strlit1153;
static Object strlit1159;
static Object strlit1162;
static Object strlit1167;
static Object strlit1171;
static Object strlit1177;
static Object strlit1180;
static Object strlit1185;
static Object strlit1189;
static Object strlit1195;
static Object strlit1200;
static Object strlit1205;
static Object strlit1214;
static Object strlit1219;
static Object strlit1223;
static Object strlit1226;
static Object strlit1240;
static Object strlit1257;
static Object strlit1261;
static Object strlit1266;
static Object strlit1275;
static Object strlit1280;
static Object strlit1281;
static Object strlit1295;
static Object strlit1312;
static Object strlit1316;
static Object strlit1321;
static Object strlit1330;
static Object strlit1335;
static Object strlit1336;
static Object strlit1350;
static Object strlit1367;
static Object strlit1372;
static Object strlit1377;
static Object strlit1386;
static Object strlit1391;
static Object strlit1392;
static Object strlit1405;
static Object strlit1416;
static Object strlit1433;
static Object strlit1438;
static Object strlit1443;
static Object strlit1452;
static Object strlit1457;
static Object strlit1458;
static Object strlit1474;
static Object strlit1485;
static Object strlit1502;
static Object strlit1505;
static Object strlit1510;
static Object strlit1519;
static Object strlit1524;
static Object strlit1525;
static Object strlit1542;
static Object strlit1545;
static Object strlit1550;
static Object strlit1559;
static Object strlit1564;
static Object strlit1565;
Object meth_ast_apply23(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 33
  setline(33);
// Begin line 32
  setline(32);
// compilenode returning *var_spc
  if (strlit24 == NULL) {
    strlit24 = alloc_String("  ");
  }
// compilenode returning strlit24
  params[0] = strlit24;
  Object opresult26 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult26
  *var_spc = opresult26;
  if (opresult26 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty14(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 31
  setline(31);
// Begin line 30
  setline(30);
  if (strlit15 == NULL) {
    strlit15 = alloc_String("");
  }
// compilenode returning strlit15
  var_spc = alloc_var();
  *var_spc = strlit15;
  if (strlit15 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 33
  setline(33);
// Begin line 34
  setline(34);
// Begin line 31
  setline(31);
  Object num17 = alloc_Float64(0.0);
// compilenode returning num17
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult19 = callmethod(num17, "..", 1, params);
// compilenode returning opresult19
// Begin line 33
  setline(33);
// Begin line 555
  setline(555);
  Object obj21 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj21, self, 0);
  addmethod2(obj21, "outer", &reader_ast_outer_22);
  adddatum2(obj21, self, 0);
  block_savedest(obj21);
  Object **closure23 = createclosure(2);
  addtoclosure(closure23, var_spc);
  Object *selfpp28 = alloc_var();
  *selfpp28 = self;
  addtoclosure(closure23, selfpp28);
  struct UserObject *uo23 = (struct UserObject*)obj21;
  uo23->data[1] = (Object)closure23;
  addmethod2(obj21, "apply", &meth_ast_apply23);
  set_type(obj21, 0);
// compilenode returning obj21
  setclassname(obj21, "Block<ast:20>");
// compilenode returning obj21
  params[0] = opresult19;
  Object iter16 = callmethod(opresult19, "iter", 1, params);
  while(1) {
    Object cond16 = callmethod(iter16, "havemore", 0, NULL);
    if (!istrue(cond16)) break;
    params[0] = callmethod(iter16, "next", 0, NULL);
    callmethod(obj21, "apply", 1, params);
  }
// compilenode returning opresult19
// Begin line 35
  setline(35);
// Begin line 34
  setline(34);
  if (strlit29 == NULL) {
    strlit29 = alloc_String("For""\x0a""");
  }
// compilenode returning strlit29
  var_s = alloc_var();
  *var_s = strlit29;
  if (strlit29 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 35
  setline(35);
// Begin line 36
  setline(36);
// Begin line 35
  setline(35);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult31 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult31
// compilenode returning *var_depth
  Object num32 = alloc_Float64(1.0);
// compilenode returning num32
  params[0] = num32;
  Object sum34 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum34
// Begin line 36
  setline(36);
// Begin line 555
  setline(555);
// Begin line 35
  setline(35);
// compilenode returning self
  Object call35 = callmethod(self, "value",
    0, params);
// compilenode returning call35
// compilenode returning call35
  params[0] = sum34;
  Object call36 = callmethod(call35, "pretty",
    1, params);
// compilenode returning call36
  params[0] = call36;
  Object opresult38 = callmethod(opresult31, "++", 1, params);
// compilenode returning opresult38
  *var_s = opresult38;
  if (opresult38 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 37
  setline(37);
// Begin line 36
  setline(36);
// compilenode returning *var_s
  if (strlit40 == NULL) {
    strlit40 = alloc_String("""\x0a""");
  }
// compilenode returning strlit40
  params[0] = strlit40;
  Object opresult42 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult42
  *var_s = opresult42;
  if (opresult42 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 38
  setline(38);
// Begin line 37
  setline(37);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult45 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult45
  if (strlit46 == NULL) {
    strlit46 = alloc_String("Do:");
  }
// compilenode returning strlit46
  params[0] = strlit46;
  Object opresult48 = callmethod(opresult45, "++", 1, params);
// compilenode returning opresult48
  *var_s = opresult48;
  if (opresult48 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 38
  setline(38);
// Begin line 39
  setline(39);
// Begin line 38
  setline(38);
// compilenode returning *var_s
  if (strlit50 == NULL) {
    strlit50 = alloc_String("""\x0a""");
  }
// compilenode returning strlit50
  params[0] = strlit50;
  Object opresult52 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult52
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult54 = callmethod(opresult52, "++", 1, params);
// compilenode returning opresult54
  if (strlit55 == NULL) {
    strlit55 = alloc_String("  ");
  }
// compilenode returning strlit55
  params[0] = strlit55;
  Object opresult57 = callmethod(opresult54, "++", 1, params);
// compilenode returning opresult57
// compilenode returning *var_depth
  Object num58 = alloc_Float64(1.0);
// compilenode returning num58
  params[0] = num58;
  Object sum60 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum60
// Begin line 39
  setline(39);
// Begin line 555
  setline(555);
// Begin line 38
  setline(38);
// compilenode returning self
  Object call61 = callmethod(self, "body",
    0, params);
// compilenode returning call61
// compilenode returning call61
  params[0] = sum60;
  Object call62 = callmethod(call61, "pretty",
    1, params);
// compilenode returning call62
  params[0] = call62;
  Object opresult64 = callmethod(opresult57, "++", 1, params);
// compilenode returning opresult64
  *var_s = opresult64;
  if (opresult64 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 39
  setline(39);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astfor3(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_over = alloc_var();
  *var_over = args[0];
  Object *var_body_39_ = alloc_var();
  *var_body_39_ = args[1];
  Object params[1];
  Object obj4 = alloc_obj2(7,7);
// OBJECT OUTER DEC outer
  adddatum2(obj4, self, 0);
  addmethod2(obj4, "outer", &reader_ast_outer_5);
  adddatum2(obj4, self, 0);
// Begin line 24
  setline(24);
  if (strlit6 == NULL) {
    strlit6 = alloc_String("for");
  }
// compilenode returning strlit6
// OBJECT CONST DEC kind
  adddatum2(obj4, strlit6, 1);
  addmethod2(obj4, "kind", &reader_ast_kind_7);
// Begin line 25
  setline(25);
// compilenode returning *var_over
// OBJECT CONST DEC value
  adddatum2(obj4, *var_over, 2);
  addmethod2(obj4, "value", &reader_ast_value_8);
// Begin line 26
  setline(26);
// compilenode returning *var_body_39_
// OBJECT CONST DEC body
  adddatum2(obj4, *var_body_39_, 3);
  addmethod2(obj4, "body", &reader_ast_body_9);
// Begin line 27
  setline(27);
  if (strlit10 == NULL) {
    strlit10 = alloc_String("");
  }
// compilenode returning strlit10
// OBJECT VAR DEC register
  adddatum2(obj4, strlit10, 4);
  addmethod2(obj4, "register", &reader_ast_register_11);
  addmethod2(obj4, "register:=", &writer_ast_register_11);
// Begin line 29
  setline(29);
// Begin line 555
  setline(555);
// Begin line 28
  setline(28);
// compilenode returning module_util
  Object call12 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call12
// compilenode returning call12
// OBJECT CONST DEC line
  adddatum2(obj4, call12, 5);
  addmethod2(obj4, "line", &reader_ast_line_13);
  addmethod2(obj4, "pretty", &meth_ast_pretty14);
  set_type(obj4, 4);
// compilenode returning obj4
  return obj4;
}
Object meth_ast_apply86(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 54
  setline(54);
// Begin line 53
  setline(53);
// compilenode returning *var_spc
  if (strlit87 == NULL) {
    strlit87 = alloc_String("  ");
  }
// compilenode returning strlit87
  params[0] = strlit87;
  Object opresult89 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult89
  *var_spc = opresult89;
  if (opresult89 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply118(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 60
  setline(60);
// Begin line 61
  setline(61);
// Begin line 60
  setline(60);
// compilenode returning *var_s
  if (strlit119 == NULL) {
    strlit119 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit119
  params[0] = strlit119;
  Object opresult121 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult121
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult123 = callmethod(opresult121, "++", 1, params);
// compilenode returning opresult123
// compilenode returning *var_depth
  Object num124 = alloc_Float64(2.0);
// compilenode returning num124
  params[0] = num124;
  Object sum126 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum126
// compilenode returning *var_x
  params[0] = sum126;
  Object call127 = callmethod(*var_x, "pretty",
    1, params);
// compilenode returning call127
  params[0] = call127;
  Object opresult129 = callmethod(opresult123, "++", 1, params);
// compilenode returning opresult129
  *var_s = opresult129;
  if (opresult129 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty77(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 52
  setline(52);
// Begin line 51
  setline(51);
  if (strlit78 == NULL) {
    strlit78 = alloc_String("");
  }
// compilenode returning strlit78
  var_spc = alloc_var();
  *var_spc = strlit78;
  if (strlit78 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 54
  setline(54);
// Begin line 55
  setline(55);
// Begin line 52
  setline(52);
  Object num80 = alloc_Float64(0.0);
// compilenode returning num80
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult82 = callmethod(num80, "..", 1, params);
// compilenode returning opresult82
// Begin line 54
  setline(54);
// Begin line 555
  setline(555);
  Object obj84 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj84, self, 0);
  addmethod2(obj84, "outer", &reader_ast_outer_85);
  adddatum2(obj84, self, 0);
  block_savedest(obj84);
  Object **closure86 = createclosure(2);
  addtoclosure(closure86, var_spc);
  Object *selfpp91 = alloc_var();
  *selfpp91 = self;
  addtoclosure(closure86, selfpp91);
  struct UserObject *uo86 = (struct UserObject*)obj84;
  uo86->data[1] = (Object)closure86;
  addmethod2(obj84, "apply", &meth_ast_apply86);
  set_type(obj84, 0);
// compilenode returning obj84
  setclassname(obj84, "Block<ast:83>");
// compilenode returning obj84
  params[0] = opresult82;
  Object iter79 = callmethod(opresult82, "iter", 1, params);
  while(1) {
    Object cond79 = callmethod(iter79, "havemore", 0, NULL);
    if (!istrue(cond79)) break;
    params[0] = callmethod(iter79, "next", 0, NULL);
    callmethod(obj84, "apply", 1, params);
  }
// compilenode returning opresult82
// Begin line 56
  setline(56);
// Begin line 55
  setline(55);
  if (strlit92 == NULL) {
    strlit92 = alloc_String("While""\x0a""");
  }
// compilenode returning strlit92
  var_s = alloc_var();
  *var_s = strlit92;
  if (strlit92 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 56
  setline(56);
// Begin line 57
  setline(57);
// Begin line 56
  setline(56);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult94 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult94
// compilenode returning *var_depth
  Object num95 = alloc_Float64(1.0);
// compilenode returning num95
  params[0] = num95;
  Object sum97 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum97
// Begin line 57
  setline(57);
// Begin line 555
  setline(555);
// Begin line 56
  setline(56);
// compilenode returning self
  Object call98 = callmethod(self, "value",
    0, params);
// compilenode returning call98
// compilenode returning call98
  params[0] = sum97;
  Object call99 = callmethod(call98, "pretty",
    1, params);
// compilenode returning call99
  params[0] = call99;
  Object opresult101 = callmethod(opresult94, "++", 1, params);
// compilenode returning opresult101
  *var_s = opresult101;
  if (opresult101 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 58
  setline(58);
// Begin line 57
  setline(57);
// compilenode returning *var_s
  if (strlit103 == NULL) {
    strlit103 = alloc_String("""\x0a""");
  }
// compilenode returning strlit103
  params[0] = strlit103;
  Object opresult105 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult105
  *var_s = opresult105;
  if (opresult105 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 59
  setline(59);
// Begin line 58
  setline(58);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult108 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult108
  if (strlit109 == NULL) {
    strlit109 = alloc_String("Do:");
  }
// compilenode returning strlit109
  params[0] = strlit109;
  Object opresult111 = callmethod(opresult108, "++", 1, params);
// compilenode returning opresult111
  *var_s = opresult111;
  if (opresult111 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 60
  setline(60);
// Begin line 62
  setline(62);
// Begin line 555
  setline(555);
// Begin line 59
  setline(59);
// compilenode returning self
  Object call114 = callmethod(self, "body",
    0, params);
// compilenode returning call114
// compilenode returning call114
// Begin line 60
  setline(60);
// Begin line 555
  setline(555);
  Object obj116 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj116, self, 0);
  addmethod2(obj116, "outer", &reader_ast_outer_117);
  adddatum2(obj116, self, 0);
  block_savedest(obj116);
  Object **closure118 = createclosure(4);
  addtoclosure(closure118, var_s);
  addtoclosure(closure118, var_spc);
  addtoclosure(closure118, var_depth);
  Object *selfpp131 = alloc_var();
  *selfpp131 = self;
  addtoclosure(closure118, selfpp131);
  struct UserObject *uo118 = (struct UserObject*)obj116;
  uo118->data[1] = (Object)closure118;
  addmethod2(obj116, "apply", &meth_ast_apply118);
  set_type(obj116, 0);
// compilenode returning obj116
  setclassname(obj116, "Block<ast:115>");
// compilenode returning obj116
  params[0] = call114;
  Object iter113 = callmethod(call114, "iter", 1, params);
  while(1) {
    Object cond113 = callmethod(iter113, "havemore", 0, NULL);
    if (!istrue(cond113)) break;
    params[0] = callmethod(iter113, "next", 0, NULL);
    callmethod(obj116, "apply", 1, params);
  }
// compilenode returning call114
// Begin line 62
  setline(62);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astwhile66(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_cond = alloc_var();
  *var_cond = args[0];
  Object *var_body_39_ = alloc_var();
  *var_body_39_ = args[1];
  Object params[1];
  Object obj67 = alloc_obj2(7,7);
// OBJECT OUTER DEC outer
  adddatum2(obj67, self, 0);
  addmethod2(obj67, "outer", &reader_ast_outer_68);
  adddatum2(obj67, self, 0);
// Begin line 45
  setline(45);
  if (strlit69 == NULL) {
    strlit69 = alloc_String("while");
  }
// compilenode returning strlit69
// OBJECT CONST DEC kind
  adddatum2(obj67, strlit69, 1);
  addmethod2(obj67, "kind", &reader_ast_kind_70);
// Begin line 46
  setline(46);
// compilenode returning *var_cond
// OBJECT CONST DEC value
  adddatum2(obj67, *var_cond, 2);
  addmethod2(obj67, "value", &reader_ast_value_71);
// Begin line 47
  setline(47);
// compilenode returning *var_body_39_
// OBJECT CONST DEC body
  adddatum2(obj67, *var_body_39_, 3);
  addmethod2(obj67, "body", &reader_ast_body_72);
// Begin line 48
  setline(48);
  if (strlit73 == NULL) {
    strlit73 = alloc_String("");
  }
// compilenode returning strlit73
// OBJECT VAR DEC register
  adddatum2(obj67, strlit73, 4);
  addmethod2(obj67, "register", &reader_ast_register_74);
  addmethod2(obj67, "register:=", &writer_ast_register_74);
// Begin line 50
  setline(50);
// Begin line 555
  setline(555);
// Begin line 49
  setline(49);
// compilenode returning module_util
  Object call75 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call75
// compilenode returning call75
// OBJECT CONST DEC line
  adddatum2(obj67, call75, 5);
  addmethod2(obj67, "line", &reader_ast_line_76);
  addmethod2(obj67, "pretty", &meth_ast_pretty77);
  set_type(obj67, 5);
// compilenode returning obj67
  return obj67;
}
Object meth_ast_apply153(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 78
  setline(78);
// Begin line 77
  setline(77);
// compilenode returning *var_spc
  if (strlit154 == NULL) {
    strlit154 = alloc_String("  ");
  }
// compilenode returning strlit154
  params[0] = strlit154;
  Object opresult156 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult156
  *var_spc = opresult156;
  if (opresult156 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply185(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ix = alloc_var();
  *var_ix = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 84
  setline(84);
// Begin line 85
  setline(85);
// Begin line 84
  setline(84);
// compilenode returning *var_s
  if (strlit186 == NULL) {
    strlit186 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit186
  params[0] = strlit186;
  Object opresult188 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult188
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult190 = callmethod(opresult188, "++", 1, params);
// compilenode returning opresult190
// compilenode returning *var_depth
  Object num191 = alloc_Float64(2.0);
// compilenode returning num191
  params[0] = num191;
  Object sum193 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum193
// compilenode returning *var_ix
  params[0] = sum193;
  Object call194 = callmethod(*var_ix, "pretty",
    1, params);
// compilenode returning call194
  params[0] = call194;
  Object opresult196 = callmethod(opresult190, "++", 1, params);
// compilenode returning opresult196
  *var_s = opresult196;
  if (opresult196 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply214(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ix = alloc_var();
  *var_ix = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 89
  setline(89);
// Begin line 90
  setline(90);
// Begin line 89
  setline(89);
// compilenode returning *var_s
  if (strlit215 == NULL) {
    strlit215 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit215
  params[0] = strlit215;
  Object opresult217 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult217
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult219 = callmethod(opresult217, "++", 1, params);
// compilenode returning opresult219
// compilenode returning *var_depth
  Object num220 = alloc_Float64(2.0);
// compilenode returning num220
  params[0] = num220;
  Object sum222 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum222
// compilenode returning *var_ix
  params[0] = sum222;
  Object call223 = callmethod(*var_ix, "pretty",
    1, params);
// compilenode returning call223
  params[0] = call223;
  Object opresult225 = callmethod(opresult219, "++", 1, params);
// compilenode returning opresult225
  *var_s = opresult225;
  if (opresult225 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty144(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 76
  setline(76);
// Begin line 75
  setline(75);
  if (strlit145 == NULL) {
    strlit145 = alloc_String("");
  }
// compilenode returning strlit145
  var_spc = alloc_var();
  *var_spc = strlit145;
  if (strlit145 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 78
  setline(78);
// Begin line 79
  setline(79);
// Begin line 76
  setline(76);
  Object num147 = alloc_Float64(0.0);
// compilenode returning num147
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult149 = callmethod(num147, "..", 1, params);
// compilenode returning opresult149
// Begin line 78
  setline(78);
// Begin line 555
  setline(555);
  Object obj151 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj151, self, 0);
  addmethod2(obj151, "outer", &reader_ast_outer_152);
  adddatum2(obj151, self, 0);
  block_savedest(obj151);
  Object **closure153 = createclosure(2);
  addtoclosure(closure153, var_spc);
  Object *selfpp158 = alloc_var();
  *selfpp158 = self;
  addtoclosure(closure153, selfpp158);
  struct UserObject *uo153 = (struct UserObject*)obj151;
  uo153->data[1] = (Object)closure153;
  addmethod2(obj151, "apply", &meth_ast_apply153);
  set_type(obj151, 0);
// compilenode returning obj151
  setclassname(obj151, "Block<ast:150>");
// compilenode returning obj151
  params[0] = opresult149;
  Object iter146 = callmethod(opresult149, "iter", 1, params);
  while(1) {
    Object cond146 = callmethod(iter146, "havemore", 0, NULL);
    if (!istrue(cond146)) break;
    params[0] = callmethod(iter146, "next", 0, NULL);
    callmethod(obj151, "apply", 1, params);
  }
// compilenode returning opresult149
// Begin line 80
  setline(80);
// Begin line 79
  setline(79);
  if (strlit159 == NULL) {
    strlit159 = alloc_String("If""\x0a""");
  }
// compilenode returning strlit159
  var_s = alloc_var();
  *var_s = strlit159;
  if (strlit159 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 80
  setline(80);
// Begin line 81
  setline(81);
// Begin line 80
  setline(80);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult161 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult161
// compilenode returning *var_depth
  Object num162 = alloc_Float64(1.0);
// compilenode returning num162
  params[0] = num162;
  Object sum164 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum164
// Begin line 81
  setline(81);
// Begin line 555
  setline(555);
// Begin line 80
  setline(80);
// compilenode returning self
  Object call165 = callmethod(self, "value",
    0, params);
// compilenode returning call165
// compilenode returning call165
  params[0] = sum164;
  Object call166 = callmethod(call165, "pretty",
    1, params);
// compilenode returning call166
  params[0] = call166;
  Object opresult168 = callmethod(opresult161, "++", 1, params);
// compilenode returning opresult168
  *var_s = opresult168;
  if (opresult168 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 82
  setline(82);
// Begin line 81
  setline(81);
// compilenode returning *var_s
  if (strlit170 == NULL) {
    strlit170 = alloc_String("""\x0a""");
  }
// compilenode returning strlit170
  params[0] = strlit170;
  Object opresult172 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult172
  *var_s = opresult172;
  if (opresult172 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 83
  setline(83);
// Begin line 82
  setline(82);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult175 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult175
  if (strlit176 == NULL) {
    strlit176 = alloc_String("Then:");
  }
// compilenode returning strlit176
  params[0] = strlit176;
  Object opresult178 = callmethod(opresult175, "++", 1, params);
// compilenode returning opresult178
  *var_s = opresult178;
  if (opresult178 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 84
  setline(84);
// Begin line 86
  setline(86);
// Begin line 555
  setline(555);
// Begin line 83
  setline(83);
// compilenode returning self
  Object call181 = callmethod(self, "thenblock",
    0, params);
// compilenode returning call181
// compilenode returning call181
// Begin line 84
  setline(84);
// Begin line 555
  setline(555);
  Object obj183 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj183, self, 0);
  addmethod2(obj183, "outer", &reader_ast_outer_184);
  adddatum2(obj183, self, 0);
  block_savedest(obj183);
  Object **closure185 = createclosure(4);
  addtoclosure(closure185, var_s);
  addtoclosure(closure185, var_spc);
  addtoclosure(closure185, var_depth);
  Object *selfpp198 = alloc_var();
  *selfpp198 = self;
  addtoclosure(closure185, selfpp198);
  struct UserObject *uo185 = (struct UserObject*)obj183;
  uo185->data[1] = (Object)closure185;
  addmethod2(obj183, "apply", &meth_ast_apply185);
  set_type(obj183, 0);
// compilenode returning obj183
  setclassname(obj183, "Block<ast:182>");
// compilenode returning obj183
  params[0] = call181;
  Object iter180 = callmethod(call181, "iter", 1, params);
  while(1) {
    Object cond180 = callmethod(iter180, "havemore", 0, NULL);
    if (!istrue(cond180)) break;
    params[0] = callmethod(iter180, "next", 0, NULL);
    callmethod(obj183, "apply", 1, params);
  }
// compilenode returning call181
// Begin line 87
  setline(87);
// Begin line 86
  setline(86);
// compilenode returning *var_s
  if (strlit199 == NULL) {
    strlit199 = alloc_String("""\x0a""");
  }
// compilenode returning strlit199
  params[0] = strlit199;
  Object opresult201 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult201
  *var_s = opresult201;
  if (opresult201 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 88
  setline(88);
// Begin line 87
  setline(87);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult204 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult204
  if (strlit205 == NULL) {
    strlit205 = alloc_String("Else:");
  }
// compilenode returning strlit205
  params[0] = strlit205;
  Object opresult207 = callmethod(opresult204, "++", 1, params);
// compilenode returning opresult207
  *var_s = opresult207;
  if (opresult207 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 89
  setline(89);
// Begin line 91
  setline(91);
// Begin line 555
  setline(555);
// Begin line 88
  setline(88);
// compilenode returning self
  Object call210 = callmethod(self, "elseblock",
    0, params);
// compilenode returning call210
// compilenode returning call210
// Begin line 89
  setline(89);
// Begin line 555
  setline(555);
  Object obj212 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj212, self, 0);
  addmethod2(obj212, "outer", &reader_ast_outer_213);
  adddatum2(obj212, self, 0);
  block_savedest(obj212);
  Object **closure214 = createclosure(4);
  addtoclosure(closure214, var_s);
  addtoclosure(closure214, var_spc);
  addtoclosure(closure214, var_depth);
  Object *selfpp227 = alloc_var();
  *selfpp227 = self;
  addtoclosure(closure214, selfpp227);
  struct UserObject *uo214 = (struct UserObject*)obj212;
  uo214->data[1] = (Object)closure214;
  addmethod2(obj212, "apply", &meth_ast_apply214);
  set_type(obj212, 0);
// compilenode returning obj212
  setclassname(obj212, "Block<ast:211>");
// compilenode returning obj212
  params[0] = call210;
  Object iter209 = callmethod(call210, "iter", 1, params);
  while(1) {
    Object cond209 = callmethod(iter209, "havemore", 0, NULL);
    if (!istrue(cond209)) break;
    params[0] = callmethod(iter209, "next", 0, NULL);
    callmethod(obj212, "apply", 1, params);
  }
// compilenode returning call210
// Begin line 91
  setline(91);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astif132(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_cond = alloc_var();
  *var_cond = args[0];
  Object *var_thenblock_39_ = alloc_var();
  *var_thenblock_39_ = args[1];
  Object *var_elseblock_39_ = alloc_var();
  *var_elseblock_39_ = args[2];
  Object params[1];
  Object obj133 = alloc_obj2(8,8);
// OBJECT OUTER DEC outer
  adddatum2(obj133, self, 0);
  addmethod2(obj133, "outer", &reader_ast_outer_134);
  adddatum2(obj133, self, 0);
// Begin line 68
  setline(68);
  if (strlit135 == NULL) {
    strlit135 = alloc_String("if");
  }
// compilenode returning strlit135
// OBJECT CONST DEC kind
  adddatum2(obj133, strlit135, 1);
  addmethod2(obj133, "kind", &reader_ast_kind_136);
// Begin line 69
  setline(69);
// compilenode returning *var_cond
// OBJECT CONST DEC value
  adddatum2(obj133, *var_cond, 2);
  addmethod2(obj133, "value", &reader_ast_value_137);
// Begin line 70
  setline(70);
// compilenode returning *var_thenblock_39_
// OBJECT CONST DEC thenblock
  adddatum2(obj133, *var_thenblock_39_, 3);
  addmethod2(obj133, "thenblock", &reader_ast_thenblock_138);
// Begin line 71
  setline(71);
// compilenode returning *var_elseblock_39_
// OBJECT CONST DEC elseblock
  adddatum2(obj133, *var_elseblock_39_, 4);
  addmethod2(obj133, "elseblock", &reader_ast_elseblock_139);
// Begin line 72
  setline(72);
  if (strlit140 == NULL) {
    strlit140 = alloc_String("");
  }
// compilenode returning strlit140
// OBJECT VAR DEC register
  adddatum2(obj133, strlit140, 5);
  addmethod2(obj133, "register", &reader_ast_register_141);
  addmethod2(obj133, "register:=", &writer_ast_register_141);
// Begin line 74
  setline(74);
// Begin line 555
  setline(555);
// Begin line 73
  setline(73);
// compilenode returning module_util
  Object call142 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call142
// compilenode returning call142
// OBJECT CONST DEC line
  adddatum2(obj133, call142, 6);
  addmethod2(obj133, "line", &reader_ast_line_143);
  addmethod2(obj133, "pretty", &meth_ast_pretty144);
  set_type(obj133, 6);
// compilenode returning obj133
  return obj133;
}
Object meth_ast_apply252(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 108
  setline(108);
// Begin line 107
  setline(107);
// compilenode returning *var_spc
  if (strlit253 == NULL) {
    strlit253 = alloc_String("  ");
  }
// compilenode returning strlit253
  params[0] = strlit253;
  Object opresult255 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult255
  *var_spc = opresult255;
  if (opresult255 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply270(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mx = alloc_var();
  *var_mx = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 112
  setline(112);
// Begin line 113
  setline(113);
// Begin line 112
  setline(112);
// compilenode returning *var_s
  if (strlit271 == NULL) {
    strlit271 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit271
  params[0] = strlit271;
  Object opresult273 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult273
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult275 = callmethod(opresult273, "++", 1, params);
// compilenode returning opresult275
// compilenode returning *var_depth
  Object num276 = alloc_Float64(2.0);
// compilenode returning num276
  params[0] = num276;
  Object sum278 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum278
// compilenode returning *var_mx
  params[0] = sum278;
  Object call279 = callmethod(*var_mx, "pretty",
    1, params);
// compilenode returning call279
  params[0] = call279;
  Object opresult281 = callmethod(opresult275, "++", 1, params);
// compilenode returning opresult281
  *var_s = opresult281;
  if (opresult281 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply299(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mx = alloc_var();
  *var_mx = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 117
  setline(117);
// Begin line 118
  setline(118);
// Begin line 117
  setline(117);
// compilenode returning *var_s
  if (strlit300 == NULL) {
    strlit300 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit300
  params[0] = strlit300;
  Object opresult302 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult302
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult304 = callmethod(opresult302, "++", 1, params);
// compilenode returning opresult304
// compilenode returning *var_depth
  Object num305 = alloc_Float64(2.0);
// compilenode returning num305
  params[0] = num305;
  Object sum307 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum307
// compilenode returning *var_mx
  params[0] = sum307;
  Object call308 = callmethod(*var_mx, "pretty",
    1, params);
// compilenode returning call308
  params[0] = call308;
  Object opresult310 = callmethod(opresult304, "++", 1, params);
// compilenode returning opresult310
  *var_s = opresult310;
  if (opresult310 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty243(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 106
  setline(106);
// Begin line 105
  setline(105);
  if (strlit244 == NULL) {
    strlit244 = alloc_String("");
  }
// compilenode returning strlit244
  var_spc = alloc_var();
  *var_spc = strlit244;
  if (strlit244 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 108
  setline(108);
// Begin line 109
  setline(109);
// Begin line 106
  setline(106);
  Object num246 = alloc_Float64(0.0);
// compilenode returning num246
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult248 = callmethod(num246, "..", 1, params);
// compilenode returning opresult248
// Begin line 108
  setline(108);
// Begin line 555
  setline(555);
  Object obj250 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj250, self, 0);
  addmethod2(obj250, "outer", &reader_ast_outer_251);
  adddatum2(obj250, self, 0);
  block_savedest(obj250);
  Object **closure252 = createclosure(2);
  addtoclosure(closure252, var_spc);
  Object *selfpp257 = alloc_var();
  *selfpp257 = self;
  addtoclosure(closure252, selfpp257);
  struct UserObject *uo252 = (struct UserObject*)obj250;
  uo252->data[1] = (Object)closure252;
  addmethod2(obj250, "apply", &meth_ast_apply252);
  set_type(obj250, 0);
// compilenode returning obj250
  setclassname(obj250, "Block<ast:249>");
// compilenode returning obj250
  params[0] = opresult248;
  Object iter245 = callmethod(opresult248, "iter", 1, params);
  while(1) {
    Object cond245 = callmethod(iter245, "havemore", 0, NULL);
    if (!istrue(cond245)) break;
    params[0] = callmethod(iter245, "next", 0, NULL);
    callmethod(obj250, "apply", 1, params);
  }
// compilenode returning opresult248
// Begin line 110
  setline(110);
// Begin line 109
  setline(109);
  if (strlit258 == NULL) {
    strlit258 = alloc_String("Block""\x0a""");
  }
// compilenode returning strlit258
  var_s = alloc_var();
  *var_s = strlit258;
  if (strlit258 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 111
  setline(111);
// Begin line 110
  setline(110);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult260 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult260
  if (strlit261 == NULL) {
    strlit261 = alloc_String("Parameters:");
  }
// compilenode returning strlit261
  params[0] = strlit261;
  Object opresult263 = callmethod(opresult260, "++", 1, params);
// compilenode returning opresult263
  *var_s = opresult263;
  if (opresult263 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 112
  setline(112);
// Begin line 114
  setline(114);
// Begin line 555
  setline(555);
// Begin line 111
  setline(111);
// compilenode returning self
  Object call266 = callmethod(self, "params",
    0, params);
// compilenode returning call266
// compilenode returning call266
// Begin line 112
  setline(112);
// Begin line 555
  setline(555);
  Object obj268 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj268, self, 0);
  addmethod2(obj268, "outer", &reader_ast_outer_269);
  adddatum2(obj268, self, 0);
  block_savedest(obj268);
  Object **closure270 = createclosure(4);
  addtoclosure(closure270, var_s);
  addtoclosure(closure270, var_spc);
  addtoclosure(closure270, var_depth);
  Object *selfpp283 = alloc_var();
  *selfpp283 = self;
  addtoclosure(closure270, selfpp283);
  struct UserObject *uo270 = (struct UserObject*)obj268;
  uo270->data[1] = (Object)closure270;
  addmethod2(obj268, "apply", &meth_ast_apply270);
  set_type(obj268, 0);
// compilenode returning obj268
  setclassname(obj268, "Block<ast:267>");
// compilenode returning obj268
  params[0] = call266;
  Object iter265 = callmethod(call266, "iter", 1, params);
  while(1) {
    Object cond265 = callmethod(iter265, "havemore", 0, NULL);
    if (!istrue(cond265)) break;
    params[0] = callmethod(iter265, "next", 0, NULL);
    callmethod(obj268, "apply", 1, params);
  }
// compilenode returning call266
// Begin line 115
  setline(115);
// Begin line 114
  setline(114);
// compilenode returning *var_s
  if (strlit284 == NULL) {
    strlit284 = alloc_String("""\x0a""");
  }
// compilenode returning strlit284
  params[0] = strlit284;
  Object opresult286 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult286
  *var_s = opresult286;
  if (opresult286 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 116
  setline(116);
// Begin line 115
  setline(115);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult289 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult289
  if (strlit290 == NULL) {
    strlit290 = alloc_String("Body:");
  }
// compilenode returning strlit290
  params[0] = strlit290;
  Object opresult292 = callmethod(opresult289, "++", 1, params);
// compilenode returning opresult292
  *var_s = opresult292;
  if (opresult292 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 117
  setline(117);
// Begin line 119
  setline(119);
// Begin line 555
  setline(555);
// Begin line 116
  setline(116);
// compilenode returning self
  Object call295 = callmethod(self, "body",
    0, params);
// compilenode returning call295
// compilenode returning call295
// Begin line 117
  setline(117);
// Begin line 555
  setline(555);
  Object obj297 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj297, self, 0);
  addmethod2(obj297, "outer", &reader_ast_outer_298);
  adddatum2(obj297, self, 0);
  block_savedest(obj297);
  Object **closure299 = createclosure(4);
  addtoclosure(closure299, var_s);
  addtoclosure(closure299, var_spc);
  addtoclosure(closure299, var_depth);
  Object *selfpp312 = alloc_var();
  *selfpp312 = self;
  addtoclosure(closure299, selfpp312);
  struct UserObject *uo299 = (struct UserObject*)obj297;
  uo299->data[1] = (Object)closure299;
  addmethod2(obj297, "apply", &meth_ast_apply299);
  set_type(obj297, 0);
// compilenode returning obj297
  setclassname(obj297, "Block<ast:296>");
// compilenode returning obj297
  params[0] = call295;
  Object iter294 = callmethod(call295, "iter", 1, params);
  while(1) {
    Object cond294 = callmethod(iter294, "havemore", 0, NULL);
    if (!istrue(cond294)) break;
    params[0] = callmethod(iter294, "next", 0, NULL);
    callmethod(obj297, "apply", 1, params);
  }
// compilenode returning call295
// Begin line 119
  setline(119);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astblock228(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object *var_params_39_ = alloc_var();
  *var_params_39_ = args[0];
  Object *var_body_39_ = alloc_var();
  *var_body_39_ = args[1];
  Object params[1];
  Object obj229 = alloc_obj2(9,9);
// OBJECT OUTER DEC outer
  adddatum2(obj229, self, 0);
  addmethod2(obj229, "outer", &reader_ast_outer_230);
  adddatum2(obj229, self, 0);
// Begin line 97
  setline(97);
  if (strlit231 == NULL) {
    strlit231 = alloc_String("block");
  }
// compilenode returning strlit231
// OBJECT CONST DEC kind
  adddatum2(obj229, strlit231, 1);
  addmethod2(obj229, "kind", &reader_ast_kind_232);
// Begin line 98
  setline(98);
  if (strlit233 == NULL) {
    strlit233 = alloc_String("block");
  }
// compilenode returning strlit233
// OBJECT CONST DEC value
  adddatum2(obj229, strlit233, 2);
  addmethod2(obj229, "value", &reader_ast_value_234);
// Begin line 99
  setline(99);
// compilenode returning *var_params_39_
// OBJECT CONST DEC params
  adddatum2(obj229, *var_params_39_, 3);
  addmethod2(obj229, "params", &reader_ast_params_235);
// Begin line 100
  setline(100);
// compilenode returning *var_body_39_
// OBJECT CONST DEC body
  adddatum2(obj229, *var_body_39_, 4);
  addmethod2(obj229, "body", &reader_ast_body_236);
// Begin line 101
  setline(101);
  Object bool237 = alloc_Boolean(1);
// compilenode returning bool237
// OBJECT CONST DEC selfclosure
  adddatum2(obj229, bool237, 5);
  addmethod2(obj229, "selfclosure", &reader_ast_selfclosure_238);
// Begin line 102
  setline(102);
  if (strlit239 == NULL) {
    strlit239 = alloc_String("");
  }
// compilenode returning strlit239
// OBJECT VAR DEC register
  adddatum2(obj229, strlit239, 6);
  addmethod2(obj229, "register", &reader_ast_register_240);
  addmethod2(obj229, "register:=", &writer_ast_register_240);
// Begin line 104
  setline(104);
// Begin line 555
  setline(555);
// Begin line 103
  setline(103);
// compilenode returning module_util
  Object call241 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call241
// compilenode returning call241
// OBJECT CONST DEC line
  adddatum2(obj229, call241, 7);
  addmethod2(obj229, "line", &reader_ast_line_242);
  addmethod2(obj229, "pretty", &meth_ast_pretty243);
  set_type(obj229, 7);
// compilenode returning obj229
  return obj229;
}
Object meth_ast_apply334(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 135
  setline(135);
// Begin line 134
  setline(134);
// compilenode returning *var_spc
  if (strlit335 == NULL) {
    strlit335 = alloc_String("  ");
  }
// compilenode returning strlit335
  params[0] = strlit335;
  Object opresult337 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult337
  *var_spc = opresult337;
  if (opresult337 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply399(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mx = alloc_var();
  *var_mx = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 143
  setline(143);
// Begin line 144
  setline(144);
// Begin line 143
  setline(143);
// compilenode returning *var_s
  if (strlit400 == NULL) {
    strlit400 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit400
  params[0] = strlit400;
  Object opresult402 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult402
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult404 = callmethod(opresult402, "++", 1, params);
// compilenode returning opresult404
// compilenode returning *var_depth
  Object num405 = alloc_Float64(2.0);
// compilenode returning num405
  params[0] = num405;
  Object sum407 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum407
// compilenode returning *var_mx
  params[0] = sum407;
  Object call408 = callmethod(*var_mx, "pretty",
    1, params);
// compilenode returning call408
  params[0] = call408;
  Object opresult410 = callmethod(opresult404, "++", 1, params);
// compilenode returning opresult410
  *var_s = opresult410;
  if (opresult410 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 146
  setline(146);
// Begin line 147
  setline(147);
// Begin line 555
  setline(555);
// Begin line 144
  setline(144);
// compilenode returning *var_mx
  Object call413 = callmethod(*var_mx, "dtype",
    0, params);
// compilenode returning call413
// compilenode returning call413
  Object bool414 = alloc_Boolean(0);
// compilenode returning bool414
  params[0] = bool414;
  Object opresult416 = callmethod(call413, "/=", 1, params);
// compilenode returning opresult416
  Object if412;
  if (istrue(opresult416)) {
// Begin line 146
  setline(146);
// Begin line 145
  setline(145);
  if (strlit417 == NULL) {
    strlit417 = alloc_String("");
  }
// compilenode returning strlit417
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult419 = callmethod(strlit417, "++", 1, params);
// compilenode returning opresult419
  if (strlit420 == NULL) {
    strlit420 = alloc_String(" : ");
  }
// compilenode returning strlit420
  params[0] = strlit420;
  Object opresult422 = callmethod(opresult419, "++", 1, params);
// compilenode returning opresult422
// Begin line 146
  setline(146);
// Begin line 555
  setline(555);
// Begin line 146
  setline(146);
// Begin line 555
  setline(555);
// Begin line 145
  setline(145);
// compilenode returning *var_mx
  Object call423 = callmethod(*var_mx, "dtype",
    0, params);
// compilenode returning call423
// compilenode returning call423
  Object call424 = callmethod(call423, "value",
    0, params);
// compilenode returning call424
// compilenode returning call424
  params[0] = call424;
  Object opresult426 = callmethod(opresult422, "++", 1, params);
// compilenode returning opresult426
  if (strlit427 == NULL) {
    strlit427 = alloc_String("");
  }
// compilenode returning strlit427
  params[0] = strlit427;
  Object opresult429 = callmethod(opresult426, "++", 1, params);
// compilenode returning opresult429
  *var_s = opresult429;
  if (opresult429 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if412 = nothing;
  } else {
  }
// compilenode returning if412
  return if412;
}
Object meth_ast_pretty325(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 133
  setline(133);
// Begin line 132
  setline(132);
  if (strlit326 == NULL) {
    strlit326 = alloc_String("");
  }
// compilenode returning strlit326
  var_spc = alloc_var();
  *var_spc = strlit326;
  if (strlit326 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 135
  setline(135);
// Begin line 136
  setline(136);
// Begin line 133
  setline(133);
  Object num328 = alloc_Float64(0.0);
// compilenode returning num328
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult330 = callmethod(num328, "..", 1, params);
// compilenode returning opresult330
// Begin line 135
  setline(135);
// Begin line 555
  setline(555);
  Object obj332 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj332, self, 0);
  addmethod2(obj332, "outer", &reader_ast_outer_333);
  adddatum2(obj332, self, 0);
  block_savedest(obj332);
  Object **closure334 = createclosure(2);
  addtoclosure(closure334, var_spc);
  Object *selfpp339 = alloc_var();
  *selfpp339 = self;
  addtoclosure(closure334, selfpp339);
  struct UserObject *uo334 = (struct UserObject*)obj332;
  uo334->data[1] = (Object)closure334;
  addmethod2(obj332, "apply", &meth_ast_apply334);
  set_type(obj332, 0);
// compilenode returning obj332
  setclassname(obj332, "Block<ast:331>");
// compilenode returning obj332
  params[0] = opresult330;
  Object iter327 = callmethod(opresult330, "iter", 1, params);
  while(1) {
    Object cond327 = callmethod(iter327, "havemore", 0, NULL);
    if (!istrue(cond327)) break;
    params[0] = callmethod(iter327, "next", 0, NULL);
    callmethod(obj332, "apply", 1, params);
  }
// compilenode returning opresult330
// Begin line 137
  setline(137);
// Begin line 136
  setline(136);
  if (strlit340 == NULL) {
    strlit340 = alloc_String("MethodType""\x0a""");
  }
// compilenode returning strlit340
  var_s = alloc_var();
  *var_s = strlit340;
  if (strlit340 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 138
  setline(138);
// Begin line 137
  setline(137);
  if (strlit341 == NULL) {
    strlit341 = alloc_String("");
  }
// compilenode returning strlit341
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult343 = callmethod(strlit341, "++", 1, params);
// compilenode returning opresult343
  if (strlit344 == NULL) {
    strlit344 = alloc_String("");
  }
// compilenode returning strlit344
  params[0] = strlit344;
  Object opresult346 = callmethod(opresult343, "++", 1, params);
// compilenode returning opresult346
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult348 = callmethod(opresult346, "++", 1, params);
// compilenode returning opresult348
  if (strlit349 == NULL) {
    strlit349 = alloc_String("Name: ");
  }
// compilenode returning strlit349
  params[0] = strlit349;
  Object opresult351 = callmethod(opresult348, "++", 1, params);
// compilenode returning opresult351
// Begin line 138
  setline(138);
// compilenode returning self
  Object call352 = callmethod(self, "value",
    0, params);
// compilenode returning call352
  params[0] = call352;
  Object opresult354 = callmethod(opresult351, "++", 1, params);
// compilenode returning opresult354
// Begin line 137
  setline(137);
  if (strlit355 == NULL) {
    strlit355 = alloc_String("""\x0a""");
  }
// compilenode returning strlit355
  params[0] = strlit355;
  Object opresult357 = callmethod(opresult354, "++", 1, params);
// compilenode returning opresult357
  *var_s = opresult357;
  if (opresult357 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 140
  setline(140);
// Begin line 141
  setline(141);
// compilenode returning self
  Object call360 = callmethod(self, "rtype",
    0, params);
// compilenode returning call360
// Begin line 138
  setline(138);
  Object bool361 = alloc_Boolean(0);
// compilenode returning bool361
  params[0] = bool361;
  Object opresult363 = callmethod(call360, "/=", 1, params);
// compilenode returning opresult363
  Object if359;
  if (istrue(opresult363)) {
// Begin line 140
  setline(140);
// Begin line 139
  setline(139);
  if (strlit364 == NULL) {
    strlit364 = alloc_String("");
  }
// compilenode returning strlit364
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult366 = callmethod(strlit364, "++", 1, params);
// compilenode returning opresult366
  if (strlit367 == NULL) {
    strlit367 = alloc_String("");
  }
// compilenode returning strlit367
  params[0] = strlit367;
  Object opresult369 = callmethod(opresult366, "++", 1, params);
// compilenode returning opresult369
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult371 = callmethod(opresult369, "++", 1, params);
// compilenode returning opresult371
  if (strlit372 == NULL) {
    strlit372 = alloc_String("Returns:""\x0a""  ");
  }
// compilenode returning strlit372
  params[0] = strlit372;
  Object opresult374 = callmethod(opresult371, "++", 1, params);
// compilenode returning opresult374
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult376 = callmethod(opresult374, "++", 1, params);
// compilenode returning opresult376
  if (strlit377 == NULL) {
    strlit377 = alloc_String("");
  }
// compilenode returning strlit377
  params[0] = strlit377;
  Object opresult379 = callmethod(opresult376, "++", 1, params);
// compilenode returning opresult379
// Begin line 140
  setline(140);
// Begin line 555
  setline(555);
// Begin line 140
  setline(140);
// compilenode returning self
  Object call380 = callmethod(self, "rtype",
    0, params);
// compilenode returning call380
  Object call381 = callmethod(call380, "value",
    0, params);
// compilenode returning call381
// compilenode returning call381
  params[0] = call381;
  Object opresult383 = callmethod(opresult379, "++", 1, params);
// compilenode returning opresult383
// Begin line 139
  setline(139);
  if (strlit384 == NULL) {
    strlit384 = alloc_String("""\x0a""");
  }
// compilenode returning strlit384
  params[0] = strlit384;
  Object opresult386 = callmethod(opresult383, "++", 1, params);
// compilenode returning opresult386
  *var_s = opresult386;
  if (opresult386 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if359 = nothing;
  } else {
  }
// compilenode returning if359
// Begin line 142
  setline(142);
// Begin line 141
  setline(141);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult389 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult389
  if (strlit390 == NULL) {
    strlit390 = alloc_String("Parameters:");
  }
// compilenode returning strlit390
  params[0] = strlit390;
  Object opresult392 = callmethod(opresult389, "++", 1, params);
// compilenode returning opresult392
  *var_s = opresult392;
  if (opresult392 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 146
  setline(146);
// Begin line 148
  setline(148);
// compilenode returning self
  Object call395 = callmethod(self, "params",
    0, params);
// compilenode returning call395
// Begin line 146
  setline(146);
// Begin line 555
  setline(555);
  Object obj397 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj397, self, 0);
  addmethod2(obj397, "outer", &reader_ast_outer_398);
  adddatum2(obj397, self, 0);
  block_savedest(obj397);
  Object **closure399 = createclosure(4);
  addtoclosure(closure399, var_s);
  addtoclosure(closure399, var_spc);
  addtoclosure(closure399, var_depth);
  Object *selfpp431 = alloc_var();
  *selfpp431 = self;
  addtoclosure(closure399, selfpp431);
  struct UserObject *uo399 = (struct UserObject*)obj397;
  uo399->data[1] = (Object)closure399;
  addmethod2(obj397, "apply", &meth_ast_apply399);
  set_type(obj397, 0);
// compilenode returning obj397
  setclassname(obj397, "Block<ast:396>");
// compilenode returning obj397
  params[0] = call395;
  Object iter394 = callmethod(call395, "iter", 1, params);
  while(1) {
    Object cond394 = callmethod(iter394, "havemore", 0, NULL);
    if (!istrue(cond394)) break;
    params[0] = callmethod(iter394, "next", 0, NULL);
    callmethod(obj397, "apply", 1, params);
  }
// compilenode returning call395
// Begin line 148
  setline(148);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astmethodtype313(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_name_39_ = alloc_var();
  *var_name_39_ = args[0];
  Object *var_params_39_ = alloc_var();
  *var_params_39_ = args[1];
  Object *var_rtype_39_ = alloc_var();
  *var_rtype_39_ = args[2];
  Object params[1];
  Object obj314 = alloc_obj2(8,8);
// OBJECT OUTER DEC outer
  adddatum2(obj314, self, 0);
  addmethod2(obj314, "outer", &reader_ast_outer_315);
  adddatum2(obj314, self, 0);
// Begin line 125
  setline(125);
  if (strlit316 == NULL) {
    strlit316 = alloc_String("methodtype");
  }
// compilenode returning strlit316
// OBJECT CONST DEC kind
  adddatum2(obj314, strlit316, 1);
  addmethod2(obj314, "kind", &reader_ast_kind_317);
// Begin line 126
  setline(126);
// compilenode returning *var_name_39_
// OBJECT CONST DEC value
  adddatum2(obj314, *var_name_39_, 2);
  addmethod2(obj314, "value", &reader_ast_value_318);
// Begin line 127
  setline(127);
// compilenode returning *var_params_39_
// OBJECT CONST DEC params
  adddatum2(obj314, *var_params_39_, 3);
  addmethod2(obj314, "params", &reader_ast_params_319);
// Begin line 128
  setline(128);
// compilenode returning *var_rtype_39_
// OBJECT CONST DEC rtype
  adddatum2(obj314, *var_rtype_39_, 4);
  addmethod2(obj314, "rtype", &reader_ast_rtype_320);
// Begin line 130
  setline(130);
// Begin line 555
  setline(555);
// Begin line 129
  setline(129);
// compilenode returning module_util
  Object call321 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call321
// compilenode returning call321
// OBJECT CONST DEC line
  adddatum2(obj314, call321, 5);
  addmethod2(obj314, "line", &reader_ast_line_322);
// Begin line 130
  setline(130);
  if (strlit323 == NULL) {
    strlit323 = alloc_String("");
  }
// compilenode returning strlit323
// OBJECT VAR DEC register
  adddatum2(obj314, strlit323, 6);
  addmethod2(obj314, "register", &reader_ast_register_324);
  addmethod2(obj314, "register:=", &writer_ast_register_324);
  addmethod2(obj314, "pretty", &meth_ast_pretty325);
  set_type(obj314, 8);
// compilenode returning obj314
  return obj314;
}
Object meth_ast_apply460(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 167
  setline(167);
// Begin line 166
  setline(166);
// compilenode returning *var_spc
  if (strlit461 == NULL) {
    strlit461 = alloc_String("  ");
  }
// compilenode returning strlit461
  params[0] = strlit461;
  Object opresult463 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult463
  *var_spc = opresult463;
  if (opresult463 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply508(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object self = *closure[2];
// Begin line 174
  setline(174);
// Begin line 173
  setline(173);
  if (strlit509 == NULL) {
    strlit509 = alloc_String("");
  }
// compilenode returning strlit509
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult511 = callmethod(strlit509, "++", 1, params);
// compilenode returning opresult511
  if (strlit512 == NULL) {
    strlit512 = alloc_String("");
  }
// compilenode returning strlit512
  params[0] = strlit512;
  Object opresult514 = callmethod(opresult511, "++", 1, params);
// compilenode returning opresult514
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult516 = callmethod(opresult514, "++", 1, params);
// compilenode returning opresult516
  if (strlit517 == NULL) {
    strlit517 = alloc_String("  ");
  }
// compilenode returning strlit517
  params[0] = strlit517;
  Object opresult519 = callmethod(opresult516, "++", 1, params);
// compilenode returning opresult519
// Begin line 174
  setline(174);
// Begin line 555
  setline(555);
// Begin line 173
  setline(173);
// compilenode returning *var_ut
  Object call520 = callmethod(*var_ut, "value",
    0, params);
// compilenode returning call520
// compilenode returning call520
  params[0] = call520;
  Object opresult522 = callmethod(opresult519, "++", 1, params);
// compilenode returning opresult522
  if (strlit523 == NULL) {
    strlit523 = alloc_String("""\x0a""");
  }
// compilenode returning strlit523
  params[0] = strlit523;
  Object opresult525 = callmethod(opresult522, "++", 1, params);
// compilenode returning opresult525
  *var_s = opresult525;
  if (opresult525 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply551(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_it = alloc_var();
  *var_it = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object self = *closure[2];
// Begin line 180
  setline(180);
// Begin line 179
  setline(179);
  if (strlit552 == NULL) {
    strlit552 = alloc_String("");
  }
// compilenode returning strlit552
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult554 = callmethod(strlit552, "++", 1, params);
// compilenode returning opresult554
  if (strlit555 == NULL) {
    strlit555 = alloc_String("");
  }
// compilenode returning strlit555
  params[0] = strlit555;
  Object opresult557 = callmethod(opresult554, "++", 1, params);
// compilenode returning opresult557
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult559 = callmethod(opresult557, "++", 1, params);
// compilenode returning opresult559
  if (strlit560 == NULL) {
    strlit560 = alloc_String("  ");
  }
// compilenode returning strlit560
  params[0] = strlit560;
  Object opresult562 = callmethod(opresult559, "++", 1, params);
// compilenode returning opresult562
// Begin line 180
  setline(180);
// Begin line 555
  setline(555);
// Begin line 179
  setline(179);
// compilenode returning *var_it
  Object call563 = callmethod(*var_it, "value",
    0, params);
// compilenode returning call563
// compilenode returning call563
  params[0] = call563;
  Object opresult565 = callmethod(opresult562, "++", 1, params);
// compilenode returning opresult565
  if (strlit566 == NULL) {
    strlit566 = alloc_String("""\x0a""");
  }
// compilenode returning strlit566
  params[0] = strlit566;
  Object opresult568 = callmethod(opresult565, "++", 1, params);
// compilenode returning opresult568
  *var_s = opresult568;
  if (opresult568 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply582(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mx = alloc_var();
  *var_mx = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 184
  setline(184);
// Begin line 185
  setline(185);
// Begin line 184
  setline(184);
// compilenode returning *var_s
  if (strlit583 == NULL) {
    strlit583 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit583
  params[0] = strlit583;
  Object opresult585 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult585
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult587 = callmethod(opresult585, "++", 1, params);
// compilenode returning opresult587
// compilenode returning *var_depth
  Object num588 = alloc_Float64(2.0);
// compilenode returning num588
  params[0] = num588;
  Object sum590 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum590
// compilenode returning *var_mx
  params[0] = sum590;
  Object call591 = callmethod(*var_mx, "pretty",
    1, params);
// compilenode returning call591
  params[0] = call591;
  Object opresult593 = callmethod(opresult587, "++", 1, params);
// compilenode returning opresult593
  *var_s = opresult593;
  if (opresult593 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty451(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 165
  setline(165);
// Begin line 164
  setline(164);
  if (strlit452 == NULL) {
    strlit452 = alloc_String("");
  }
// compilenode returning strlit452
  var_spc = alloc_var();
  *var_spc = strlit452;
  if (strlit452 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 167
  setline(167);
// Begin line 168
  setline(168);
// Begin line 165
  setline(165);
  Object num454 = alloc_Float64(0.0);
// compilenode returning num454
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult456 = callmethod(num454, "..", 1, params);
// compilenode returning opresult456
// Begin line 167
  setline(167);
// Begin line 555
  setline(555);
  Object obj458 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj458, self, 0);
  addmethod2(obj458, "outer", &reader_ast_outer_459);
  adddatum2(obj458, self, 0);
  block_savedest(obj458);
  Object **closure460 = createclosure(2);
  addtoclosure(closure460, var_spc);
  Object *selfpp465 = alloc_var();
  *selfpp465 = self;
  addtoclosure(closure460, selfpp465);
  struct UserObject *uo460 = (struct UserObject*)obj458;
  uo460->data[1] = (Object)closure460;
  addmethod2(obj458, "apply", &meth_ast_apply460);
  set_type(obj458, 0);
// compilenode returning obj458
  setclassname(obj458, "Block<ast:457>");
// compilenode returning obj458
  params[0] = opresult456;
  Object iter453 = callmethod(opresult456, "iter", 1, params);
  while(1) {
    Object cond453 = callmethod(iter453, "havemore", 0, NULL);
    if (!istrue(cond453)) break;
    params[0] = callmethod(iter453, "next", 0, NULL);
    callmethod(obj458, "apply", 1, params);
  }
// compilenode returning opresult456
// Begin line 169
  setline(169);
// Begin line 168
  setline(168);
  if (strlit466 == NULL) {
    strlit466 = alloc_String("Type""\x0a""");
  }
// compilenode returning strlit466
  var_s = alloc_var();
  *var_s = strlit466;
  if (strlit466 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 170
  setline(170);
// Begin line 169
  setline(169);
  if (strlit467 == NULL) {
    strlit467 = alloc_String("");
  }
// compilenode returning strlit467
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult469 = callmethod(strlit467, "++", 1, params);
// compilenode returning opresult469
  if (strlit470 == NULL) {
    strlit470 = alloc_String("");
  }
// compilenode returning strlit470
  params[0] = strlit470;
  Object opresult472 = callmethod(opresult469, "++", 1, params);
// compilenode returning opresult472
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult474 = callmethod(opresult472, "++", 1, params);
// compilenode returning opresult474
  if (strlit475 == NULL) {
    strlit475 = alloc_String("Name: ");
  }
// compilenode returning strlit475
  params[0] = strlit475;
  Object opresult477 = callmethod(opresult474, "++", 1, params);
// compilenode returning opresult477
// Begin line 170
  setline(170);
// compilenode returning self
  Object call478 = callmethod(self, "value",
    0, params);
// compilenode returning call478
  params[0] = call478;
  Object opresult480 = callmethod(opresult477, "++", 1, params);
// compilenode returning opresult480
// Begin line 169
  setline(169);
  if (strlit481 == NULL) {
    strlit481 = alloc_String("""\x0a""");
  }
// compilenode returning strlit481
  params[0] = strlit481;
  Object opresult483 = callmethod(opresult480, "++", 1, params);
// compilenode returning opresult483
  *var_s = opresult483;
  if (opresult483 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 174
  setline(174);
// Begin line 176
  setline(176);
// Begin line 555
  setline(555);
// Begin line 176
  setline(176);
// compilenode returning self
  Object call486 = callmethod(self, "unionTypes",
    0, params);
// compilenode returning call486
  Object call487 = callmethod(call486, "size",
    0, params);
// compilenode returning call487
// compilenode returning call487
// Begin line 170
  setline(170);
  Object num488 = alloc_Float64(0.0);
// compilenode returning num488
  params[0] = num488;
  Object opresult490 = callmethod(call487, ">", 1, params);
// compilenode returning opresult490
  Object if485;
  if (istrue(opresult490)) {
// Begin line 172
  setline(172);
// Begin line 171
  setline(171);
  if (strlit491 == NULL) {
    strlit491 = alloc_String("");
  }
// compilenode returning strlit491
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult493 = callmethod(strlit491, "++", 1, params);
// compilenode returning opresult493
  if (strlit494 == NULL) {
    strlit494 = alloc_String("");
  }
// compilenode returning strlit494
  params[0] = strlit494;
  Object opresult496 = callmethod(opresult493, "++", 1, params);
// compilenode returning opresult496
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult498 = callmethod(opresult496, "++", 1, params);
// compilenode returning opresult498
  if (strlit499 == NULL) {
    strlit499 = alloc_String("Union of:""\x0a""");
  }
// compilenode returning strlit499
  params[0] = strlit499;
  Object opresult501 = callmethod(opresult498, "++", 1, params);
// compilenode returning opresult501
  *var_s = opresult501;
  if (opresult501 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 174
  setline(174);
// Begin line 175
  setline(175);
// compilenode returning self
  Object call504 = callmethod(self, "unionTypes",
    0, params);
// compilenode returning call504
// Begin line 174
  setline(174);
// Begin line 555
  setline(555);
  Object obj506 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj506, self, 0);
  addmethod2(obj506, "outer", &reader_ast_outer_507);
  adddatum2(obj506, self, 0);
  block_savedest(obj506);
  Object **closure508 = createclosure(3);
  addtoclosure(closure508, var_s);
  addtoclosure(closure508, var_spc);
  Object *selfpp527 = alloc_var();
  *selfpp527 = self;
  addtoclosure(closure508, selfpp527);
  struct UserObject *uo508 = (struct UserObject*)obj506;
  uo508->data[1] = (Object)closure508;
  addmethod2(obj506, "apply", &meth_ast_apply508);
  set_type(obj506, 0);
// compilenode returning obj506
  setclassname(obj506, "Block<ast:505>");
// compilenode returning obj506
  params[0] = call504;
  Object iter503 = callmethod(call504, "iter", 1, params);
  while(1) {
    Object cond503 = callmethod(iter503, "havemore", 0, NULL);
    if (!istrue(cond503)) break;
    params[0] = callmethod(iter503, "next", 0, NULL);
    callmethod(obj506, "apply", 1, params);
  }
// compilenode returning call504
    if485 = call504;
  } else {
  }
// compilenode returning if485
// Begin line 180
  setline(180);
// Begin line 182
  setline(182);
// Begin line 555
  setline(555);
// Begin line 182
  setline(182);
// compilenode returning self
  Object call529 = callmethod(self, "intersectionTypes",
    0, params);
// compilenode returning call529
  Object call530 = callmethod(call529, "size",
    0, params);
// compilenode returning call530
// compilenode returning call530
// Begin line 176
  setline(176);
  Object num531 = alloc_Float64(0.0);
// compilenode returning num531
  params[0] = num531;
  Object opresult533 = callmethod(call530, ">", 1, params);
// compilenode returning opresult533
  Object if528;
  if (istrue(opresult533)) {
// Begin line 178
  setline(178);
// Begin line 177
  setline(177);
  if (strlit534 == NULL) {
    strlit534 = alloc_String("");
  }
// compilenode returning strlit534
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult536 = callmethod(strlit534, "++", 1, params);
// compilenode returning opresult536
  if (strlit537 == NULL) {
    strlit537 = alloc_String("");
  }
// compilenode returning strlit537
  params[0] = strlit537;
  Object opresult539 = callmethod(opresult536, "++", 1, params);
// compilenode returning opresult539
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult541 = callmethod(opresult539, "++", 1, params);
// compilenode returning opresult541
  if (strlit542 == NULL) {
    strlit542 = alloc_String("Intersection of:""\x0a""");
  }
// compilenode returning strlit542
  params[0] = strlit542;
  Object opresult544 = callmethod(opresult541, "++", 1, params);
// compilenode returning opresult544
  *var_s = opresult544;
  if (opresult544 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 180
  setline(180);
// Begin line 181
  setline(181);
// compilenode returning self
  Object call547 = callmethod(self, "intersectionTypes",
    0, params);
// compilenode returning call547
// Begin line 180
  setline(180);
// Begin line 555
  setline(555);
  Object obj549 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj549, self, 0);
  addmethod2(obj549, "outer", &reader_ast_outer_550);
  adddatum2(obj549, self, 0);
  block_savedest(obj549);
  Object **closure551 = createclosure(3);
  addtoclosure(closure551, var_s);
  addtoclosure(closure551, var_spc);
  Object *selfpp570 = alloc_var();
  *selfpp570 = self;
  addtoclosure(closure551, selfpp570);
  struct UserObject *uo551 = (struct UserObject*)obj549;
  uo551->data[1] = (Object)closure551;
  addmethod2(obj549, "apply", &meth_ast_apply551);
  set_type(obj549, 0);
// compilenode returning obj549
  setclassname(obj549, "Block<ast:548>");
// compilenode returning obj549
  params[0] = call547;
  Object iter546 = callmethod(call547, "iter", 1, params);
  while(1) {
    Object cond546 = callmethod(iter546, "havemore", 0, NULL);
    if (!istrue(cond546)) break;
    params[0] = callmethod(iter546, "next", 0, NULL);
    callmethod(obj549, "apply", 1, params);
  }
// compilenode returning call547
    if528 = call547;
  } else {
  }
// compilenode returning if528
// Begin line 183
  setline(183);
// Begin line 182
  setline(182);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult572 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult572
  if (strlit573 == NULL) {
    strlit573 = alloc_String("Methods:");
  }
// compilenode returning strlit573
  params[0] = strlit573;
  Object opresult575 = callmethod(opresult572, "++", 1, params);
// compilenode returning opresult575
  *var_s = opresult575;
  if (opresult575 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 184
  setline(184);
// Begin line 186
  setline(186);
// compilenode returning self
  Object call578 = callmethod(self, "methods",
    0, params);
// compilenode returning call578
// Begin line 184
  setline(184);
// Begin line 555
  setline(555);
  Object obj580 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj580, self, 0);
  addmethod2(obj580, "outer", &reader_ast_outer_581);
  adddatum2(obj580, self, 0);
  block_savedest(obj580);
  Object **closure582 = createclosure(4);
  addtoclosure(closure582, var_s);
  addtoclosure(closure582, var_spc);
  addtoclosure(closure582, var_depth);
  Object *selfpp595 = alloc_var();
  *selfpp595 = self;
  addtoclosure(closure582, selfpp595);
  struct UserObject *uo582 = (struct UserObject*)obj580;
  uo582->data[1] = (Object)closure582;
  addmethod2(obj580, "apply", &meth_ast_apply582);
  set_type(obj580, 0);
// compilenode returning obj580
  setclassname(obj580, "Block<ast:579>");
// compilenode returning obj580
  params[0] = call578;
  Object iter577 = callmethod(call578, "iter", 1, params);
  while(1) {
    Object cond577 = callmethod(iter577, "havemore", 0, NULL);
    if (!istrue(cond577)) break;
    params[0] = callmethod(iter577, "next", 0, NULL);
    callmethod(obj580, "apply", 1, params);
  }
// compilenode returning call578
// Begin line 187
  setline(187);
// Begin line 186
  setline(186);
// compilenode returning *var_s
  if (strlit596 == NULL) {
    strlit596 = alloc_String("""\x0a""");
  }
// compilenode returning strlit596
  params[0] = strlit596;
  Object opresult598 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult598
  *var_s = opresult598;
  if (opresult598 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 187
  setline(187);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_asttype432(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_name_39_ = alloc_var();
  *var_name_39_ = args[0];
  Object *var_methods_39_ = alloc_var();
  *var_methods_39_ = args[1];
  Object params[1];
  Object obj433 = alloc_obj2(13,11);
// OBJECT OUTER DEC outer
  adddatum2(obj433, self, 0);
  addmethod2(obj433, "outer", &reader_ast_outer_434);
  adddatum2(obj433, self, 0);
// Begin line 154
  setline(154);
  if (strlit435 == NULL) {
    strlit435 = alloc_String("type");
  }
// compilenode returning strlit435
// OBJECT CONST DEC kind
  adddatum2(obj433, strlit435, 1);
  addmethod2(obj433, "kind", &reader_ast_kind_436);
// Begin line 155
  setline(155);
// compilenode returning *var_name_39_
// OBJECT CONST DEC value
  adddatum2(obj433, *var_name_39_, 2);
  addmethod2(obj433, "value", &reader_ast_value_437);
// Begin line 156
  setline(156);
// compilenode returning *var_methods_39_
// OBJECT CONST DEC methods
  adddatum2(obj433, *var_methods_39_, 3);
  addmethod2(obj433, "methods", &reader_ast_methods_438);
// Begin line 158
  setline(158);
  Object array439 = alloc_List();
// compilenode returning array439
// OBJECT CONST DEC unionTypes
  adddatum2(obj433, array439, 4);
  addmethod2(obj433, "unionTypes", &reader_ast_unionTypes_440);
// Begin line 159
  setline(159);
  Object array441 = alloc_List();
// compilenode returning array441
// OBJECT CONST DEC intersectionTypes
  adddatum2(obj433, array441, 5);
  addmethod2(obj433, "intersectionTypes", &reader_ast_intersectionTypes_442);
// Begin line 160
  setline(160);
// Begin line 555
  setline(555);
// Begin line 159
  setline(159);
// compilenode returning module_util
  Object call443 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call443
// compilenode returning call443
// OBJECT CONST DEC line
  adddatum2(obj433, call443, 6);
  addmethod2(obj433, "line", &reader_ast_line_444);
// Begin line 161
  setline(161);
  Object array445 = alloc_List();
// compilenode returning array445
// OBJECT VAR DEC generics
  adddatum2(obj433, array445, 7);
  addmethod2(obj433, "generics", &reader_ast_generics_446);
  addmethod2(obj433, "generics:=", &writer_ast_generics_446);
  Object bool447 = alloc_Boolean(0);
// compilenode returning bool447
// OBJECT VAR DEC nominal
  adddatum2(obj433, bool447, 8);
  addmethod2(obj433, "nominal", &reader_ast_nominal_448);
  addmethod2(obj433, "nominal:=", &writer_ast_nominal_448);
// Begin line 162
  setline(162);
  if (strlit449 == NULL) {
    strlit449 = alloc_String("");
  }
// compilenode returning strlit449
// OBJECT VAR DEC register
  adddatum2(obj433, strlit449, 9);
  addmethod2(obj433, "register", &reader_ast_register_450);
  addmethod2(obj433, "register:=", &writer_ast_register_450);
  addmethod2(obj433, "pretty", &meth_ast_pretty451);
  set_type(obj433, 9);
// compilenode returning obj433
  return obj433;
}
Object meth_ast_apply628(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 207
  setline(207);
// Begin line 206
  setline(206);
// compilenode returning *var_spc
  if (strlit629 == NULL) {
    strlit629 = alloc_String("  ");
  }
// compilenode returning strlit629
  params[0] = strlit629;
  Object opresult631 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult631
  *var_spc = opresult631;
  if (opresult631 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply663(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mx = alloc_var();
  *var_mx = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 213
  setline(213);
// Begin line 214
  setline(214);
// Begin line 213
  setline(213);
// compilenode returning *var_s
  if (strlit664 == NULL) {
    strlit664 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit664
  params[0] = strlit664;
  Object opresult666 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult666
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult668 = callmethod(opresult666, "++", 1, params);
// compilenode returning opresult668
// compilenode returning *var_depth
  Object num669 = alloc_Float64(2.0);
// compilenode returning num669
  params[0] = num669;
  Object sum671 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum671
// compilenode returning *var_mx
  params[0] = sum671;
  Object call672 = callmethod(*var_mx, "pretty",
    1, params);
// compilenode returning call672
  params[0] = call672;
  Object opresult674 = callmethod(opresult668, "++", 1, params);
// compilenode returning opresult674
  *var_s = opresult674;
  if (opresult674 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply692(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mx = alloc_var();
  *var_mx = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 218
  setline(218);
// Begin line 219
  setline(219);
// Begin line 218
  setline(218);
// compilenode returning *var_s
  if (strlit693 == NULL) {
    strlit693 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit693
  params[0] = strlit693;
  Object opresult695 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult695
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult697 = callmethod(opresult695, "++", 1, params);
// compilenode returning opresult697
// compilenode returning *var_depth
  Object num698 = alloc_Float64(2.0);
// compilenode returning num698
  params[0] = num698;
  Object sum700 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum700
// compilenode returning *var_mx
  params[0] = sum700;
  Object call701 = callmethod(*var_mx, "pretty",
    1, params);
// compilenode returning call701
  params[0] = call701;
  Object opresult703 = callmethod(opresult697, "++", 1, params);
// compilenode returning opresult703
  *var_s = opresult703;
  if (opresult703 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty619(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 205
  setline(205);
// Begin line 204
  setline(204);
  if (strlit620 == NULL) {
    strlit620 = alloc_String("");
  }
// compilenode returning strlit620
  var_spc = alloc_var();
  *var_spc = strlit620;
  if (strlit620 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 207
  setline(207);
// Begin line 208
  setline(208);
// Begin line 205
  setline(205);
  Object num622 = alloc_Float64(0.0);
// compilenode returning num622
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult624 = callmethod(num622, "..", 1, params);
// compilenode returning opresult624
// Begin line 207
  setline(207);
// Begin line 555
  setline(555);
  Object obj626 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj626, self, 0);
  addmethod2(obj626, "outer", &reader_ast_outer_627);
  adddatum2(obj626, self, 0);
  block_savedest(obj626);
  Object **closure628 = createclosure(2);
  addtoclosure(closure628, var_spc);
  Object *selfpp633 = alloc_var();
  *selfpp633 = self;
  addtoclosure(closure628, selfpp633);
  struct UserObject *uo628 = (struct UserObject*)obj626;
  uo628->data[1] = (Object)closure628;
  addmethod2(obj626, "apply", &meth_ast_apply628);
  set_type(obj626, 0);
// compilenode returning obj626
  setclassname(obj626, "Block<ast:625>");
// compilenode returning obj626
  params[0] = opresult624;
  Object iter621 = callmethod(opresult624, "iter", 1, params);
  while(1) {
    Object cond621 = callmethod(iter621, "havemore", 0, NULL);
    if (!istrue(cond621)) break;
    params[0] = callmethod(iter621, "next", 0, NULL);
    callmethod(obj626, "apply", 1, params);
  }
// compilenode returning opresult624
// Begin line 209
  setline(209);
// Begin line 208
  setline(208);
  if (strlit634 == NULL) {
    strlit634 = alloc_String("Method""\x0a""");
  }
// compilenode returning strlit634
  var_s = alloc_var();
  *var_s = strlit634;
  if (strlit634 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 209
  setline(209);
// Begin line 210
  setline(210);
// Begin line 209
  setline(209);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult636 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult636
  if (strlit637 == NULL) {
    strlit637 = alloc_String("Name: ");
  }
// compilenode returning strlit637
  params[0] = strlit637;
  Object opresult639 = callmethod(opresult636, "++", 1, params);
// compilenode returning opresult639
// compilenode returning *var_depth
  Object num640 = alloc_Float64(1.0);
// compilenode returning num640
  params[0] = num640;
  Object sum642 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum642
// Begin line 210
  setline(210);
// Begin line 555
  setline(555);
// Begin line 209
  setline(209);
// compilenode returning self
  Object call643 = callmethod(self, "value",
    0, params);
// compilenode returning call643
// compilenode returning call643
  params[0] = sum642;
  Object call644 = callmethod(call643, "pretty",
    1, params);
// compilenode returning call644
  params[0] = call644;
  Object opresult646 = callmethod(opresult639, "++", 1, params);
// compilenode returning opresult646
  *var_s = opresult646;
  if (opresult646 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 211
  setline(211);
// Begin line 210
  setline(210);
// compilenode returning *var_s
  if (strlit648 == NULL) {
    strlit648 = alloc_String("""\x0a""");
  }
// compilenode returning strlit648
  params[0] = strlit648;
  Object opresult650 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult650
  *var_s = opresult650;
  if (opresult650 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 212
  setline(212);
// Begin line 211
  setline(211);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult653 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult653
  if (strlit654 == NULL) {
    strlit654 = alloc_String("Parameters:");
  }
// compilenode returning strlit654
  params[0] = strlit654;
  Object opresult656 = callmethod(opresult653, "++", 1, params);
// compilenode returning opresult656
  *var_s = opresult656;
  if (opresult656 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 213
  setline(213);
// Begin line 215
  setline(215);
// Begin line 555
  setline(555);
// Begin line 212
  setline(212);
// compilenode returning self
  Object call659 = callmethod(self, "params",
    0, params);
// compilenode returning call659
// compilenode returning call659
// Begin line 213
  setline(213);
// Begin line 555
  setline(555);
  Object obj661 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj661, self, 0);
  addmethod2(obj661, "outer", &reader_ast_outer_662);
  adddatum2(obj661, self, 0);
  block_savedest(obj661);
  Object **closure663 = createclosure(4);
  addtoclosure(closure663, var_s);
  addtoclosure(closure663, var_spc);
  addtoclosure(closure663, var_depth);
  Object *selfpp676 = alloc_var();
  *selfpp676 = self;
  addtoclosure(closure663, selfpp676);
  struct UserObject *uo663 = (struct UserObject*)obj661;
  uo663->data[1] = (Object)closure663;
  addmethod2(obj661, "apply", &meth_ast_apply663);
  set_type(obj661, 0);
// compilenode returning obj661
  setclassname(obj661, "Block<ast:660>");
// compilenode returning obj661
  params[0] = call659;
  Object iter658 = callmethod(call659, "iter", 1, params);
  while(1) {
    Object cond658 = callmethod(iter658, "havemore", 0, NULL);
    if (!istrue(cond658)) break;
    params[0] = callmethod(iter658, "next", 0, NULL);
    callmethod(obj661, "apply", 1, params);
  }
// compilenode returning call659
// Begin line 216
  setline(216);
// Begin line 215
  setline(215);
// compilenode returning *var_s
  if (strlit677 == NULL) {
    strlit677 = alloc_String("""\x0a""");
  }
// compilenode returning strlit677
  params[0] = strlit677;
  Object opresult679 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult679
  *var_s = opresult679;
  if (opresult679 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 217
  setline(217);
// Begin line 216
  setline(216);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult682 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult682
  if (strlit683 == NULL) {
    strlit683 = alloc_String("Body:");
  }
// compilenode returning strlit683
  params[0] = strlit683;
  Object opresult685 = callmethod(opresult682, "++", 1, params);
// compilenode returning opresult685
  *var_s = opresult685;
  if (opresult685 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 218
  setline(218);
// Begin line 220
  setline(220);
// Begin line 555
  setline(555);
// Begin line 217
  setline(217);
// compilenode returning self
  Object call688 = callmethod(self, "body",
    0, params);
// compilenode returning call688
// compilenode returning call688
// Begin line 218
  setline(218);
// Begin line 555
  setline(555);
  Object obj690 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj690, self, 0);
  addmethod2(obj690, "outer", &reader_ast_outer_691);
  adddatum2(obj690, self, 0);
  block_savedest(obj690);
  Object **closure692 = createclosure(4);
  addtoclosure(closure692, var_s);
  addtoclosure(closure692, var_spc);
  addtoclosure(closure692, var_depth);
  Object *selfpp705 = alloc_var();
  *selfpp705 = self;
  addtoclosure(closure692, selfpp705);
  struct UserObject *uo692 = (struct UserObject*)obj690;
  uo692->data[1] = (Object)closure692;
  addmethod2(obj690, "apply", &meth_ast_apply692);
  set_type(obj690, 0);
// compilenode returning obj690
  setclassname(obj690, "Block<ast:689>");
// compilenode returning obj690
  params[0] = call688;
  Object iter687 = callmethod(call688, "iter", 1, params);
  while(1) {
    Object cond687 = callmethod(iter687, "havemore", 0, NULL);
    if (!istrue(cond687)) break;
    params[0] = callmethod(iter687, "next", 0, NULL);
    callmethod(obj690, "apply", 1, params);
  }
// compilenode returning call688
// Begin line 220
  setline(220);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astmethod600(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_name_39_ = alloc_var();
  *var_name_39_ = args[0];
  Object *var_params_39_ = alloc_var();
  *var_params_39_ = args[1];
  Object *var_body_39_ = alloc_var();
  *var_body_39_ = args[2];
  Object *var_dtype_39_ = alloc_var();
  *var_dtype_39_ = args[3];
  Object params[1];
  Object obj601 = alloc_obj2(16,12);
// OBJECT OUTER DEC outer
  adddatum2(obj601, self, 0);
  addmethod2(obj601, "outer", &reader_ast_outer_602);
  adddatum2(obj601, self, 0);
// Begin line 193
  setline(193);
  if (strlit603 == NULL) {
    strlit603 = alloc_String("method");
  }
// compilenode returning strlit603
// OBJECT CONST DEC kind
  adddatum2(obj601, strlit603, 1);
  addmethod2(obj601, "kind", &reader_ast_kind_604);
// Begin line 194
  setline(194);
// compilenode returning *var_name_39_
// OBJECT CONST DEC value
  adddatum2(obj601, *var_name_39_, 2);
  addmethod2(obj601, "value", &reader_ast_value_605);
// Begin line 195
  setline(195);
// compilenode returning *var_params_39_
// OBJECT CONST DEC params
  adddatum2(obj601, *var_params_39_, 3);
  addmethod2(obj601, "params", &reader_ast_params_606);
// Begin line 196
  setline(196);
// compilenode returning *var_body_39_
// OBJECT CONST DEC body
  adddatum2(obj601, *var_body_39_, 4);
  addmethod2(obj601, "body", &reader_ast_body_607);
// Begin line 197
  setline(197);
// compilenode returning *var_dtype_39_
// OBJECT VAR DEC dtype
  adddatum2(obj601, *var_dtype_39_, 5);
  addmethod2(obj601, "dtype", &reader_ast_dtype_608);
  addmethod2(obj601, "dtype:=", &writer_ast_dtype_608);
// Begin line 198
  setline(198);
  Object bool609 = alloc_Boolean(0);
// compilenode returning bool609
// OBJECT VAR DEC varargs
  adddatum2(obj601, bool609, 6);
  addmethod2(obj601, "varargs", &reader_ast_varargs_610);
  addmethod2(obj601, "varargs:=", &writer_ast_varargs_610);
// Begin line 199
  setline(199);
  Object bool611 = alloc_Boolean(0);
// compilenode returning bool611
// OBJECT VAR DEC vararg
  adddatum2(obj601, bool611, 7);
  addmethod2(obj601, "vararg", &reader_ast_vararg_612);
  addmethod2(obj601, "vararg:=", &writer_ast_vararg_612);
// Begin line 200
  setline(200);
  Object bool613 = alloc_Boolean(0);
// compilenode returning bool613
// OBJECT VAR DEC selfclosure
  adddatum2(obj601, bool613, 8);
  addmethod2(obj601, "selfclosure", &reader_ast_selfclosure_614);
  addmethod2(obj601, "selfclosure:=", &writer_ast_selfclosure_614);
// Begin line 201
  setline(201);
  if (strlit615 == NULL) {
    strlit615 = alloc_String("");
  }
// compilenode returning strlit615
// OBJECT VAR DEC register
  adddatum2(obj601, strlit615, 9);
  addmethod2(obj601, "register", &reader_ast_register_616);
  addmethod2(obj601, "register:=", &writer_ast_register_616);
// Begin line 203
  setline(203);
// Begin line 555
  setline(555);
// Begin line 202
  setline(202);
// compilenode returning module_util
  Object call617 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call617
// compilenode returning call617
// OBJECT CONST DEC line
  adddatum2(obj601, call617, 10);
  addmethod2(obj601, "line", &reader_ast_line_618);
  addmethod2(obj601, "pretty", &meth_ast_pretty619);
  set_type(obj601, 10);
// compilenode returning obj601
  return obj601;
}
Object meth_ast_apply729(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 235
  setline(235);
// Begin line 234
  setline(234);
// compilenode returning *var_spc
  if (strlit730 == NULL) {
    strlit730 = alloc_String("  ");
  }
// compilenode returning strlit730
  params[0] = strlit730;
  Object opresult732 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult732
  *var_spc = opresult732;
  if (opresult732 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply770(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 242
  setline(242);
// Begin line 243
  setline(243);
// Begin line 242
  setline(242);
// compilenode returning *var_s
  if (strlit771 == NULL) {
    strlit771 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit771
  params[0] = strlit771;
  Object opresult773 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult773
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult775 = callmethod(opresult773, "++", 1, params);
// compilenode returning opresult775
// compilenode returning *var_depth
  Object num776 = alloc_Float64(2.0);
// compilenode returning num776
  params[0] = num776;
  Object sum778 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum778
// compilenode returning *var_x
  params[0] = sum778;
  Object call779 = callmethod(*var_x, "pretty",
    1, params);
// compilenode returning call779
  params[0] = call779;
  Object opresult781 = callmethod(opresult775, "++", 1, params);
// compilenode returning opresult781
  *var_s = opresult781;
  if (opresult781 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty720(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 233
  setline(233);
// Begin line 232
  setline(232);
  if (strlit721 == NULL) {
    strlit721 = alloc_String("");
  }
// compilenode returning strlit721
  var_spc = alloc_var();
  *var_spc = strlit721;
  if (strlit721 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 235
  setline(235);
// Begin line 236
  setline(236);
// Begin line 233
  setline(233);
  Object num723 = alloc_Float64(0.0);
// compilenode returning num723
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult725 = callmethod(num723, "..", 1, params);
// compilenode returning opresult725
// Begin line 235
  setline(235);
// Begin line 555
  setline(555);
  Object obj727 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj727, self, 0);
  addmethod2(obj727, "outer", &reader_ast_outer_728);
  adddatum2(obj727, self, 0);
  block_savedest(obj727);
  Object **closure729 = createclosure(2);
  addtoclosure(closure729, var_spc);
  Object *selfpp734 = alloc_var();
  *selfpp734 = self;
  addtoclosure(closure729, selfpp734);
  struct UserObject *uo729 = (struct UserObject*)obj727;
  uo729->data[1] = (Object)closure729;
  addmethod2(obj727, "apply", &meth_ast_apply729);
  set_type(obj727, 0);
// compilenode returning obj727
  setclassname(obj727, "Block<ast:726>");
// compilenode returning obj727
  params[0] = opresult725;
  Object iter722 = callmethod(opresult725, "iter", 1, params);
  while(1) {
    Object cond722 = callmethod(iter722, "havemore", 0, NULL);
    if (!istrue(cond722)) break;
    params[0] = callmethod(iter722, "next", 0, NULL);
    callmethod(obj727, "apply", 1, params);
  }
// compilenode returning opresult725
// Begin line 237
  setline(237);
// Begin line 236
  setline(236);
  if (strlit735 == NULL) {
    strlit735 = alloc_String("Call""\x0a""");
  }
// compilenode returning strlit735
  var_s = alloc_var();
  *var_s = strlit735;
  if (strlit735 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 238
  setline(238);
// Begin line 237
  setline(237);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult737 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult737
  if (strlit738 == NULL) {
    strlit738 = alloc_String("Method:""\x0a""");
  }
// compilenode returning strlit738
  params[0] = strlit738;
  Object opresult740 = callmethod(opresult737, "++", 1, params);
// compilenode returning opresult740
  *var_s = opresult740;
  if (opresult740 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 238
  setline(238);
// Begin line 239
  setline(239);
// Begin line 238
  setline(238);
// compilenode returning *var_s
  if (strlit742 == NULL) {
    strlit742 = alloc_String("  ");
  }
// compilenode returning strlit742
  params[0] = strlit742;
  Object opresult744 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult744
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult746 = callmethod(opresult744, "++", 1, params);
// compilenode returning opresult746
// compilenode returning *var_depth
  Object num747 = alloc_Float64(2.0);
// compilenode returning num747
  params[0] = num747;
  Object sum749 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum749
// Begin line 239
  setline(239);
// Begin line 555
  setline(555);
// Begin line 238
  setline(238);
// compilenode returning self
  Object call750 = callmethod(self, "value",
    0, params);
// compilenode returning call750
// compilenode returning call750
  params[0] = sum749;
  Object call751 = callmethod(call750, "pretty",
    1, params);
// compilenode returning call751
  params[0] = call751;
  Object opresult753 = callmethod(opresult746, "++", 1, params);
// compilenode returning opresult753
  *var_s = opresult753;
  if (opresult753 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 240
  setline(240);
// Begin line 239
  setline(239);
// compilenode returning *var_s
  if (strlit755 == NULL) {
    strlit755 = alloc_String("""\x0a""");
  }
// compilenode returning strlit755
  params[0] = strlit755;
  Object opresult757 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult757
  *var_s = opresult757;
  if (opresult757 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 241
  setline(241);
// Begin line 240
  setline(240);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult760 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult760
  if (strlit761 == NULL) {
    strlit761 = alloc_String("Parameters:");
  }
// compilenode returning strlit761
  params[0] = strlit761;
  Object opresult763 = callmethod(opresult760, "++", 1, params);
// compilenode returning opresult763
  *var_s = opresult763;
  if (opresult763 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 242
  setline(242);
// Begin line 244
  setline(244);
// Begin line 555
  setline(555);
// Begin line 241
  setline(241);
// compilenode returning self
  Object call766 = callmethod(self, "with",
    0, params);
// compilenode returning call766
// compilenode returning call766
// Begin line 242
  setline(242);
// Begin line 555
  setline(555);
  Object obj768 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj768, self, 0);
  addmethod2(obj768, "outer", &reader_ast_outer_769);
  adddatum2(obj768, self, 0);
  block_savedest(obj768);
  Object **closure770 = createclosure(4);
  addtoclosure(closure770, var_s);
  addtoclosure(closure770, var_spc);
  addtoclosure(closure770, var_depth);
  Object *selfpp783 = alloc_var();
  *selfpp783 = self;
  addtoclosure(closure770, selfpp783);
  struct UserObject *uo770 = (struct UserObject*)obj768;
  uo770->data[1] = (Object)closure770;
  addmethod2(obj768, "apply", &meth_ast_apply770);
  set_type(obj768, 0);
// compilenode returning obj768
  setclassname(obj768, "Block<ast:767>");
// compilenode returning obj768
  params[0] = call766;
  Object iter765 = callmethod(call766, "iter", 1, params);
  while(1) {
    Object cond765 = callmethod(iter765, "havemore", 0, NULL);
    if (!istrue(cond765)) break;
    params[0] = callmethod(iter765, "next", 0, NULL);
    callmethod(obj768, "apply", 1, params);
  }
// compilenode returning call766
// Begin line 244
  setline(244);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astcall706(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_what = alloc_var();
  *var_what = args[0];
  Object *var_with_39_ = alloc_var();
  *var_with_39_ = args[1];
  Object params[1];
  Object obj707 = alloc_obj2(7,7);
// OBJECT OUTER DEC outer
  adddatum2(obj707, self, 0);
  addmethod2(obj707, "outer", &reader_ast_outer_708);
  adddatum2(obj707, self, 0);
// Begin line 226
  setline(226);
  if (strlit709 == NULL) {
    strlit709 = alloc_String("call");
  }
// compilenode returning strlit709
// OBJECT CONST DEC kind
  adddatum2(obj707, strlit709, 1);
  addmethod2(obj707, "kind", &reader_ast_kind_710);
// Begin line 227
  setline(227);
// compilenode returning *var_what
// OBJECT CONST DEC value
  adddatum2(obj707, *var_what, 2);
  addmethod2(obj707, "value", &reader_ast_value_711);
// Begin line 228
  setline(228);
// compilenode returning *var_with_39_
// OBJECT CONST DEC with
  adddatum2(obj707, *var_with_39_, 3);
  addmethod2(obj707, "with", &reader_ast_with_712);
// Begin line 230
  setline(230);
// Begin line 229
  setline(229);
  Object num713 = alloc_Float64(0.0);
// compilenode returning num713
// Begin line 230
  setline(230);
// Begin line 555
  setline(555);
// Begin line 229
  setline(229);
// compilenode returning module_util
  Object call714 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call714
// compilenode returning call714
  params[0] = call714;
  Object sum716 = callmethod(num713, "+", 1, params);
// compilenode returning sum716
// OBJECT CONST DEC line
  adddatum2(obj707, sum716, 4);
  addmethod2(obj707, "line", &reader_ast_line_717);
// Begin line 230
  setline(230);
  if (strlit718 == NULL) {
    strlit718 = alloc_String("");
  }
// compilenode returning strlit718
// OBJECT VAR DEC register
  adddatum2(obj707, strlit718, 5);
  addmethod2(obj707, "register", &reader_ast_register_719);
  addmethod2(obj707, "register:=", &writer_ast_register_719);
  addmethod2(obj707, "pretty", &meth_ast_pretty720);
  set_type(obj707, 11);
// compilenode returning obj707
  return obj707;
}
Object meth_ast_apply806(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 261
  setline(261);
// Begin line 260
  setline(260);
// compilenode returning *var_spc
  if (strlit807 == NULL) {
    strlit807 = alloc_String("  ");
  }
// compilenode returning strlit807
  params[0] = strlit807;
  Object opresult809 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult809
  *var_spc = opresult809;
  if (opresult809 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply862(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 269
  setline(269);
// Begin line 270
  setline(270);
// Begin line 269
  setline(269);
// compilenode returning *var_s
  if (strlit863 == NULL) {
    strlit863 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit863
  params[0] = strlit863;
  Object opresult865 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult865
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult867 = callmethod(opresult865, "++", 1, params);
// compilenode returning opresult867
// compilenode returning *var_depth
  Object num868 = alloc_Float64(2.0);
// compilenode returning num868
  params[0] = num868;
  Object sum870 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum870
// compilenode returning *var_x
  params[0] = sum870;
  Object call871 = callmethod(*var_x, "pretty",
    1, params);
// compilenode returning call871
  params[0] = call871;
  Object opresult873 = callmethod(opresult867, "++", 1, params);
// compilenode returning opresult873
  *var_s = opresult873;
  if (opresult873 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply890(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 273
  setline(273);
// Begin line 274
  setline(274);
// Begin line 273
  setline(273);
// compilenode returning *var_s
  if (strlit891 == NULL) {
    strlit891 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit891
  params[0] = strlit891;
  Object opresult893 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult893
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult895 = callmethod(opresult893, "++", 1, params);
// compilenode returning opresult895
// compilenode returning *var_depth
  Object num896 = alloc_Float64(2.0);
// compilenode returning num896
  params[0] = num896;
  Object sum898 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum898
// compilenode returning *var_x
  params[0] = sum898;
  Object call899 = callmethod(*var_x, "pretty",
    1, params);
// compilenode returning call899
  params[0] = call899;
  Object opresult901 = callmethod(opresult895, "++", 1, params);
// compilenode returning opresult901
  *var_s = opresult901;
  if (opresult901 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty797(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 259
  setline(259);
// Begin line 258
  setline(258);
  if (strlit798 == NULL) {
    strlit798 = alloc_String("");
  }
// compilenode returning strlit798
  var_spc = alloc_var();
  *var_spc = strlit798;
  if (strlit798 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 261
  setline(261);
// Begin line 262
  setline(262);
// Begin line 259
  setline(259);
  Object num800 = alloc_Float64(0.0);
// compilenode returning num800
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult802 = callmethod(num800, "..", 1, params);
// compilenode returning opresult802
// Begin line 261
  setline(261);
// Begin line 555
  setline(555);
  Object obj804 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj804, self, 0);
  addmethod2(obj804, "outer", &reader_ast_outer_805);
  adddatum2(obj804, self, 0);
  block_savedest(obj804);
  Object **closure806 = createclosure(2);
  addtoclosure(closure806, var_spc);
  Object *selfpp811 = alloc_var();
  *selfpp811 = self;
  addtoclosure(closure806, selfpp811);
  struct UserObject *uo806 = (struct UserObject*)obj804;
  uo806->data[1] = (Object)closure806;
  addmethod2(obj804, "apply", &meth_ast_apply806);
  set_type(obj804, 0);
// compilenode returning obj804
  setclassname(obj804, "Block<ast:803>");
// compilenode returning obj804
  params[0] = opresult802;
  Object iter799 = callmethod(opresult802, "iter", 1, params);
  while(1) {
    Object cond799 = callmethod(iter799, "havemore", 0, NULL);
    if (!istrue(cond799)) break;
    params[0] = callmethod(iter799, "next", 0, NULL);
    callmethod(obj804, "apply", 1, params);
  }
// compilenode returning opresult802
// Begin line 262
  setline(262);
  if (strlit812 == NULL) {
    strlit812 = alloc_String("Class(");
  }
// compilenode returning strlit812
  Object num813 = alloc_Float64(0.0);
// compilenode returning num813
// Begin line 263
  setline(263);
// Begin line 555
  setline(555);
// Begin line 262
  setline(262);
// compilenode returning self
  Object call814 = callmethod(self, "name",
    0, params);
// compilenode returning call814
// compilenode returning call814
  params[0] = num813;
  Object call815 = callmethod(call814, "pretty",
    1, params);
// compilenode returning call815
  params[0] = call815;
  Object opresult817 = callmethod(strlit812, "++", 1, params);
// compilenode returning opresult817
  if (strlit818 == NULL) {
    strlit818 = alloc_String(")");
  }
// compilenode returning strlit818
  params[0] = strlit818;
  Object opresult820 = callmethod(opresult817, "++", 1, params);
// compilenode returning opresult820
  var_s = alloc_var();
  *var_s = opresult820;
  if (opresult820 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 265
  setline(265);
// Begin line 267
  setline(267);
// Begin line 555
  setline(555);
// Begin line 263
  setline(263);
// compilenode returning self
  Object call822 = callmethod(self, "superclass",
    0, params);
// compilenode returning call822
// compilenode returning call822
  Object bool823 = alloc_Boolean(0);
// compilenode returning bool823
  params[0] = bool823;
  Object opresult825 = callmethod(call822, "/=", 1, params);
// compilenode returning opresult825
  Object if821;
  if (istrue(opresult825)) {
// Begin line 265
  setline(265);
// Begin line 264
  setline(264);
// compilenode returning *var_s
  if (strlit826 == NULL) {
    strlit826 = alloc_String("""\x0a""");
  }
// compilenode returning strlit826
  params[0] = strlit826;
  Object opresult828 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult828
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult830 = callmethod(opresult828, "++", 1, params);
// compilenode returning opresult830
  if (strlit831 == NULL) {
    strlit831 = alloc_String("Superclass:");
  }
// compilenode returning strlit831
  params[0] = strlit831;
  Object opresult833 = callmethod(opresult830, "++", 1, params);
// compilenode returning opresult833
  *var_s = opresult833;
  if (opresult833 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 265
  setline(265);
// Begin line 266
  setline(266);
// Begin line 265
  setline(265);
// compilenode returning *var_s
  if (strlit835 == NULL) {
    strlit835 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit835
  params[0] = strlit835;
  Object opresult837 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult837
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult839 = callmethod(opresult837, "++", 1, params);
// compilenode returning opresult839
// compilenode returning *var_depth
  Object num840 = alloc_Float64(2.0);
// compilenode returning num840
  params[0] = num840;
  Object sum842 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum842
// Begin line 266
  setline(266);
// Begin line 555
  setline(555);
// Begin line 265
  setline(265);
// compilenode returning self
  Object call843 = callmethod(self, "superclass",
    0, params);
// compilenode returning call843
// compilenode returning call843
  params[0] = sum842;
  Object call844 = callmethod(call843, "pretty",
    1, params);
// compilenode returning call844
  params[0] = call844;
  Object opresult846 = callmethod(opresult839, "++", 1, params);
// compilenode returning opresult846
  *var_s = opresult846;
  if (opresult846 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if821 = nothing;
  } else {
  }
// compilenode returning if821
// Begin line 268
  setline(268);
// Begin line 267
  setline(267);
// compilenode returning *var_s
  if (strlit848 == NULL) {
    strlit848 = alloc_String("""\x0a""");
  }
// compilenode returning strlit848
  params[0] = strlit848;
  Object opresult850 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult850
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult852 = callmethod(opresult850, "++", 1, params);
// compilenode returning opresult852
  if (strlit853 == NULL) {
    strlit853 = alloc_String("Parameters:");
  }
// compilenode returning strlit853
  params[0] = strlit853;
  Object opresult855 = callmethod(opresult852, "++", 1, params);
// compilenode returning opresult855
  *var_s = opresult855;
  if (opresult855 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 269
  setline(269);
// Begin line 271
  setline(271);
// Begin line 555
  setline(555);
// Begin line 268
  setline(268);
// compilenode returning self
  Object call858 = callmethod(self, "params",
    0, params);
// compilenode returning call858
// compilenode returning call858
// Begin line 269
  setline(269);
// Begin line 555
  setline(555);
  Object obj860 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj860, self, 0);
  addmethod2(obj860, "outer", &reader_ast_outer_861);
  adddatum2(obj860, self, 0);
  block_savedest(obj860);
  Object **closure862 = createclosure(4);
  addtoclosure(closure862, var_s);
  addtoclosure(closure862, var_spc);
  addtoclosure(closure862, var_depth);
  Object *selfpp875 = alloc_var();
  *selfpp875 = self;
  addtoclosure(closure862, selfpp875);
  struct UserObject *uo862 = (struct UserObject*)obj860;
  uo862->data[1] = (Object)closure862;
  addmethod2(obj860, "apply", &meth_ast_apply862);
  set_type(obj860, 0);
// compilenode returning obj860
  setclassname(obj860, "Block<ast:859>");
// compilenode returning obj860
  params[0] = call858;
  Object iter857 = callmethod(call858, "iter", 1, params);
  while(1) {
    Object cond857 = callmethod(iter857, "havemore", 0, NULL);
    if (!istrue(cond857)) break;
    params[0] = callmethod(iter857, "next", 0, NULL);
    callmethod(obj860, "apply", 1, params);
  }
// compilenode returning call858
// Begin line 272
  setline(272);
// Begin line 271
  setline(271);
// compilenode returning *var_s
  if (strlit876 == NULL) {
    strlit876 = alloc_String("""\x0a""");
  }
// compilenode returning strlit876
  params[0] = strlit876;
  Object opresult878 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult878
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult880 = callmethod(opresult878, "++", 1, params);
// compilenode returning opresult880
  if (strlit881 == NULL) {
    strlit881 = alloc_String("Body:");
  }
// compilenode returning strlit881
  params[0] = strlit881;
  Object opresult883 = callmethod(opresult880, "++", 1, params);
// compilenode returning opresult883
  *var_s = opresult883;
  if (opresult883 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 273
  setline(273);
// Begin line 275
  setline(275);
// Begin line 555
  setline(555);
// Begin line 272
  setline(272);
// compilenode returning self
  Object call886 = callmethod(self, "value",
    0, params);
// compilenode returning call886
// compilenode returning call886
// Begin line 273
  setline(273);
// Begin line 555
  setline(555);
  Object obj888 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj888, self, 0);
  addmethod2(obj888, "outer", &reader_ast_outer_889);
  adddatum2(obj888, self, 0);
  block_savedest(obj888);
  Object **closure890 = createclosure(4);
  addtoclosure(closure890, var_s);
  addtoclosure(closure890, var_spc);
  addtoclosure(closure890, var_depth);
  Object *selfpp903 = alloc_var();
  *selfpp903 = self;
  addtoclosure(closure890, selfpp903);
  struct UserObject *uo890 = (struct UserObject*)obj888;
  uo890->data[1] = (Object)closure890;
  addmethod2(obj888, "apply", &meth_ast_apply890);
  set_type(obj888, 0);
// compilenode returning obj888
  setclassname(obj888, "Block<ast:887>");
// compilenode returning obj888
  params[0] = call886;
  Object iter885 = callmethod(call886, "iter", 1, params);
  while(1) {
    Object cond885 = callmethod(iter885, "havemore", 0, NULL);
    if (!istrue(cond885)) break;
    params[0] = callmethod(iter885, "next", 0, NULL);
    callmethod(obj888, "apply", 1, params);
  }
// compilenode returning call886
// Begin line 275
  setline(275);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astclass784(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_name_39_ = alloc_var();
  *var_name_39_ = args[0];
  Object *var_params_39_ = alloc_var();
  *var_params_39_ = args[1];
  Object *var_body_39_ = alloc_var();
  *var_body_39_ = args[2];
  Object *var_superclass_39_ = alloc_var();
  *var_superclass_39_ = args[3];
  Object params[1];
  Object obj785 = alloc_obj2(9,9);
// OBJECT OUTER DEC outer
  adddatum2(obj785, self, 0);
  addmethod2(obj785, "outer", &reader_ast_outer_786);
  adddatum2(obj785, self, 0);
// Begin line 250
  setline(250);
  if (strlit787 == NULL) {
    strlit787 = alloc_String("class");
  }
// compilenode returning strlit787
// OBJECT CONST DEC kind
  adddatum2(obj785, strlit787, 1);
  addmethod2(obj785, "kind", &reader_ast_kind_788);
// Begin line 251
  setline(251);
// compilenode returning *var_body_39_
// OBJECT CONST DEC value
  adddatum2(obj785, *var_body_39_, 2);
  addmethod2(obj785, "value", &reader_ast_value_789);
// Begin line 252
  setline(252);
// compilenode returning *var_name_39_
// OBJECT CONST DEC name
  adddatum2(obj785, *var_name_39_, 3);
  addmethod2(obj785, "name", &reader_ast_name_790);
// Begin line 253
  setline(253);
// compilenode returning *var_params_39_
// OBJECT CONST DEC params
  adddatum2(obj785, *var_params_39_, 4);
  addmethod2(obj785, "params", &reader_ast_params_791);
// Begin line 254
  setline(254);
  if (strlit792 == NULL) {
    strlit792 = alloc_String("");
  }
// compilenode returning strlit792
// OBJECT VAR DEC register
  adddatum2(obj785, strlit792, 5);
  addmethod2(obj785, "register", &reader_ast_register_793);
  addmethod2(obj785, "register:=", &writer_ast_register_793);
// Begin line 256
  setline(256);
// Begin line 555
  setline(555);
// Begin line 255
  setline(255);
// compilenode returning module_util
  Object call794 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call794
// compilenode returning call794
// OBJECT CONST DEC line
  adddatum2(obj785, call794, 6);
  addmethod2(obj785, "line", &reader_ast_line_795);
// Begin line 256
  setline(256);
// compilenode returning *var_superclass_39_
// OBJECT CONST DEC superclass
  adddatum2(obj785, *var_superclass_39_, 7);
  addmethod2(obj785, "superclass", &reader_ast_superclass_796);
  addmethod2(obj785, "pretty", &meth_ast_pretty797);
  set_type(obj785, 12);
// compilenode returning obj785
  return obj785;
}
Object meth_ast_apply926(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 291
  setline(291);
// Begin line 290
  setline(290);
// compilenode returning *var_spc
  if (strlit927 == NULL) {
    strlit927 = alloc_String("  ");
  }
// compilenode returning strlit927
  params[0] = strlit927;
  Object opresult929 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult929
  *var_spc = opresult929;
  if (opresult929 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply978(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 300
  setline(300);
// Begin line 301
  setline(301);
// Begin line 300
  setline(300);
// compilenode returning *var_s
  if (strlit979 == NULL) {
    strlit979 = alloc_String("""\x0a""");
  }
// compilenode returning strlit979
  params[0] = strlit979;
  Object opresult981 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult981
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult983 = callmethod(opresult981, "++", 1, params);
// compilenode returning opresult983
// compilenode returning *var_depth
  Object num984 = alloc_Float64(1.0);
// compilenode returning num984
  params[0] = num984;
  Object sum986 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum986
// compilenode returning *var_x
  params[0] = sum986;
  Object call987 = callmethod(*var_x, "pretty",
    1, params);
// compilenode returning call987
  params[0] = call987;
  Object opresult989 = callmethod(opresult983, "++", 1, params);
// compilenode returning opresult989
  *var_s = opresult989;
  if (opresult989 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty917(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 289
  setline(289);
// Begin line 288
  setline(288);
  if (strlit918 == NULL) {
    strlit918 = alloc_String("");
  }
// compilenode returning strlit918
  var_spc = alloc_var();
  *var_spc = strlit918;
  if (strlit918 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 291
  setline(291);
// Begin line 292
  setline(292);
// Begin line 289
  setline(289);
  Object num920 = alloc_Float64(0.0);
// compilenode returning num920
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult922 = callmethod(num920, "..", 1, params);
// compilenode returning opresult922
// Begin line 291
  setline(291);
// Begin line 555
  setline(555);
  Object obj924 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj924, self, 0);
  addmethod2(obj924, "outer", &reader_ast_outer_925);
  adddatum2(obj924, self, 0);
  block_savedest(obj924);
  Object **closure926 = createclosure(2);
  addtoclosure(closure926, var_spc);
  Object *selfpp931 = alloc_var();
  *selfpp931 = self;
  addtoclosure(closure926, selfpp931);
  struct UserObject *uo926 = (struct UserObject*)obj924;
  uo926->data[1] = (Object)closure926;
  addmethod2(obj924, "apply", &meth_ast_apply926);
  set_type(obj924, 0);
// compilenode returning obj924
  setclassname(obj924, "Block<ast:923>");
// compilenode returning obj924
  params[0] = opresult922;
  Object iter919 = callmethod(opresult922, "iter", 1, params);
  while(1) {
    Object cond919 = callmethod(iter919, "havemore", 0, NULL);
    if (!istrue(cond919)) break;
    params[0] = callmethod(iter919, "next", 0, NULL);
    callmethod(obj924, "apply", 1, params);
  }
// compilenode returning opresult922
// Begin line 293
  setline(293);
// Begin line 292
  setline(292);
  if (strlit932 == NULL) {
    strlit932 = alloc_String("Object");
  }
// compilenode returning strlit932
  var_s = alloc_var();
  *var_s = strlit932;
  if (strlit932 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 298
  setline(298);
// Begin line 299
  setline(299);
// Begin line 555
  setline(555);
// Begin line 293
  setline(293);
// compilenode returning self
  Object call934 = callmethod(self, "superclass",
    0, params);
// compilenode returning call934
// compilenode returning call934
  Object bool935 = alloc_Boolean(0);
// compilenode returning bool935
  params[0] = bool935;
  Object opresult937 = callmethod(call934, "/=", 1, params);
// compilenode returning opresult937
  Object if933;
  if (istrue(opresult937)) {
// Begin line 295
  setline(295);
// Begin line 294
  setline(294);
// compilenode returning *var_s
  if (strlit938 == NULL) {
    strlit938 = alloc_String("""\x0a""");
  }
// compilenode returning strlit938
  params[0] = strlit938;
  Object opresult940 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult940
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult942 = callmethod(opresult940, "++", 1, params);
// compilenode returning opresult942
  if (strlit943 == NULL) {
    strlit943 = alloc_String("Superclass:");
  }
// compilenode returning strlit943
  params[0] = strlit943;
  Object opresult945 = callmethod(opresult942, "++", 1, params);
// compilenode returning opresult945
  *var_s = opresult945;
  if (opresult945 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 295
  setline(295);
// Begin line 296
  setline(296);
// Begin line 295
  setline(295);
// compilenode returning *var_s
  if (strlit947 == NULL) {
    strlit947 = alloc_String("""\x0a""  ");
  }
// compilenode returning strlit947
  params[0] = strlit947;
  Object opresult949 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult949
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult951 = callmethod(opresult949, "++", 1, params);
// compilenode returning opresult951
// compilenode returning *var_depth
  Object num952 = alloc_Float64(1.0);
// compilenode returning num952
  params[0] = num952;
  Object sum954 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum954
// Begin line 296
  setline(296);
// Begin line 555
  setline(555);
// Begin line 295
  setline(295);
// compilenode returning self
  Object call955 = callmethod(self, "superclass",
    0, params);
// compilenode returning call955
// compilenode returning call955
  params[0] = sum954;
  Object call956 = callmethod(call955, "pretty",
    1, params);
// compilenode returning call956
  params[0] = call956;
  Object opresult958 = callmethod(opresult951, "++", 1, params);
// compilenode returning opresult958
  *var_s = opresult958;
  if (opresult958 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 297
  setline(297);
// Begin line 296
  setline(296);
// compilenode returning *var_s
  if (strlit960 == NULL) {
    strlit960 = alloc_String("""\x0a""");
  }
// compilenode returning strlit960
  params[0] = strlit960;
  Object opresult962 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult962
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult964 = callmethod(opresult962, "++", 1, params);
// compilenode returning opresult964
  if (strlit965 == NULL) {
    strlit965 = alloc_String("Body:");
  }
// compilenode returning strlit965
  params[0] = strlit965;
  Object opresult967 = callmethod(opresult964, "++", 1, params);
// compilenode returning opresult967
  *var_s = opresult967;
  if (opresult967 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 298
  setline(298);
// Begin line 297
  setline(297);
// compilenode returning *var_depth
  Object num969 = alloc_Float64(1.0);
// compilenode returning num969
  params[0] = num969;
  Object sum971 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum971
  *var_depth = sum971;
  if (sum971 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if933 = nothing;
  } else {
  }
// compilenode returning if933
// Begin line 300
  setline(300);
// Begin line 302
  setline(302);
// Begin line 555
  setline(555);
// Begin line 299
  setline(299);
// compilenode returning self
  Object call974 = callmethod(self, "value",
    0, params);
// compilenode returning call974
// compilenode returning call974
// Begin line 300
  setline(300);
// Begin line 555
  setline(555);
  Object obj976 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj976, self, 0);
  addmethod2(obj976, "outer", &reader_ast_outer_977);
  adddatum2(obj976, self, 0);
  block_savedest(obj976);
  Object **closure978 = createclosure(4);
  addtoclosure(closure978, var_s);
  addtoclosure(closure978, var_spc);
  addtoclosure(closure978, var_depth);
  Object *selfpp991 = alloc_var();
  *selfpp991 = self;
  addtoclosure(closure978, selfpp991);
  struct UserObject *uo978 = (struct UserObject*)obj976;
  uo978->data[1] = (Object)closure978;
  addmethod2(obj976, "apply", &meth_ast_apply978);
  set_type(obj976, 0);
// compilenode returning obj976
  setclassname(obj976, "Block<ast:975>");
// compilenode returning obj976
  params[0] = call974;
  Object iter973 = callmethod(call974, "iter", 1, params);
  while(1) {
    Object cond973 = callmethod(iter973, "havemore", 0, NULL);
    if (!istrue(cond973)) break;
    params[0] = callmethod(iter973, "next", 0, NULL);
    callmethod(obj976, "apply", 1, params);
  }
// compilenode returning call974
// Begin line 302
  setline(302);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astobject904(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_body = alloc_var();
  *var_body = args[0];
  Object *var_superclass_39_ = alloc_var();
  *var_superclass_39_ = args[1];
  Object params[1];
  Object obj905 = alloc_obj2(9,8);
// OBJECT OUTER DEC outer
  adddatum2(obj905, self, 0);
  addmethod2(obj905, "outer", &reader_ast_outer_906);
  adddatum2(obj905, self, 0);
// Begin line 281
  setline(281);
  if (strlit907 == NULL) {
    strlit907 = alloc_String("object");
  }
// compilenode returning strlit907
// OBJECT CONST DEC kind
  adddatum2(obj905, strlit907, 1);
  addmethod2(obj905, "kind", &reader_ast_kind_908);
// Begin line 282
  setline(282);
// compilenode returning *var_body
// OBJECT CONST DEC value
  adddatum2(obj905, *var_body, 2);
  addmethod2(obj905, "value", &reader_ast_value_909);
// Begin line 283
  setline(283);
  if (strlit910 == NULL) {
    strlit910 = alloc_String("");
  }
// compilenode returning strlit910
// OBJECT VAR DEC register
  adddatum2(obj905, strlit910, 3);
  addmethod2(obj905, "register", &reader_ast_register_911);
  addmethod2(obj905, "register:=", &writer_ast_register_911);
// Begin line 285
  setline(285);
// Begin line 555
  setline(555);
// Begin line 284
  setline(284);
// compilenode returning module_util
  Object call912 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call912
// compilenode returning call912
// OBJECT CONST DEC line
  adddatum2(obj905, call912, 4);
  addmethod2(obj905, "line", &reader_ast_line_913);
// Begin line 285
  setline(285);
// compilenode returning *var_superclass_39_
// OBJECT CONST DEC superclass
  adddatum2(obj905, *var_superclass_39_, 5);
  addmethod2(obj905, "superclass", &reader_ast_superclass_914);
// Begin line 286
  setline(286);
  Object bool915 = alloc_Boolean(0);
// compilenode returning bool915
// OBJECT VAR DEC otype
  adddatum2(obj905, bool915, 6);
  addmethod2(obj905, "otype", &reader_ast_otype_916);
  addmethod2(obj905, "otype:=", &writer_ast_otype_916);
  addmethod2(obj905, "pretty", &meth_ast_pretty917);
  set_type(obj905, 13);
// compilenode returning obj905
  return obj905;
}
Object meth_ast_apply1011(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ai = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 316
  setline(316);
// Begin line 315
  setline(315);
// compilenode returning *var_spc
  if (strlit1012 == NULL) {
    strlit1012 = alloc_String("  ");
  }
// compilenode returning strlit1012
  params[0] = strlit1012;
  Object opresult1014 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1014
  *var_spc = opresult1014;
  if (opresult1014 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_apply1023(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ax = alloc_var();
  *var_ax = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object *var_spc = closure[1];
  Object *var_depth = closure[2];
  Object self = *closure[3];
// Begin line 319
  setline(319);
// Begin line 320
  setline(320);
// Begin line 319
  setline(319);
// compilenode returning *var_s
  if (strlit1024 == NULL) {
    strlit1024 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1024
  params[0] = strlit1024;
  Object opresult1026 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1026
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1028 = callmethod(opresult1026, "++", 1, params);
// compilenode returning opresult1028
// compilenode returning *var_depth
  Object num1029 = alloc_Float64(1.0);
// compilenode returning num1029
  params[0] = num1029;
  Object sum1031 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1031
// compilenode returning *var_ax
  params[0] = sum1031;
  Object call1032 = callmethod(*var_ax, "pretty",
    1, params);
// compilenode returning call1032
  params[0] = call1032;
  Object opresult1034 = callmethod(opresult1028, "++", 1, params);
// compilenode returning opresult1034
  *var_s = opresult1034;
  if (opresult1034 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1002(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 314
  setline(314);
// Begin line 313
  setline(313);
  if (strlit1003 == NULL) {
    strlit1003 = alloc_String("");
  }
// compilenode returning strlit1003
  var_spc = alloc_var();
  *var_spc = strlit1003;
  if (strlit1003 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 316
  setline(316);
// Begin line 317
  setline(317);
// Begin line 314
  setline(314);
  Object num1005 = alloc_Float64(0.0);
// compilenode returning num1005
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1007 = callmethod(num1005, "..", 1, params);
// compilenode returning opresult1007
// Begin line 316
  setline(316);
// Begin line 555
  setline(555);
  Object obj1009 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1009, self, 0);
  addmethod2(obj1009, "outer", &reader_ast_outer_1010);
  adddatum2(obj1009, self, 0);
  block_savedest(obj1009);
  Object **closure1011 = createclosure(2);
  addtoclosure(closure1011, var_spc);
  Object *selfpp1016 = alloc_var();
  *selfpp1016 = self;
  addtoclosure(closure1011, selfpp1016);
  struct UserObject *uo1011 = (struct UserObject*)obj1009;
  uo1011->data[1] = (Object)closure1011;
  addmethod2(obj1009, "apply", &meth_ast_apply1011);
  set_type(obj1009, 0);
// compilenode returning obj1009
  setclassname(obj1009, "Block<ast:1008>");
// compilenode returning obj1009
  params[0] = opresult1007;
  Object iter1004 = callmethod(opresult1007, "iter", 1, params);
  while(1) {
    Object cond1004 = callmethod(iter1004, "havemore", 0, NULL);
    if (!istrue(cond1004)) break;
    params[0] = callmethod(iter1004, "next", 0, NULL);
    callmethod(obj1009, "apply", 1, params);
  }
// compilenode returning opresult1007
// Begin line 318
  setline(318);
// Begin line 317
  setline(317);
  if (strlit1017 == NULL) {
    strlit1017 = alloc_String("Array");
  }
// compilenode returning strlit1017
  var_s = alloc_var();
  *var_s = strlit1017;
  if (strlit1017 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 319
  setline(319);
// Begin line 321
  setline(321);
// Begin line 555
  setline(555);
// Begin line 318
  setline(318);
// compilenode returning self
  Object call1019 = callmethod(self, "value",
    0, params);
// compilenode returning call1019
// compilenode returning call1019
// Begin line 319
  setline(319);
// Begin line 555
  setline(555);
  Object obj1021 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1021, self, 0);
  addmethod2(obj1021, "outer", &reader_ast_outer_1022);
  adddatum2(obj1021, self, 0);
  block_savedest(obj1021);
  Object **closure1023 = createclosure(4);
  addtoclosure(closure1023, var_s);
  addtoclosure(closure1023, var_spc);
  addtoclosure(closure1023, var_depth);
  Object *selfpp1036 = alloc_var();
  *selfpp1036 = self;
  addtoclosure(closure1023, selfpp1036);
  struct UserObject *uo1023 = (struct UserObject*)obj1021;
  uo1023->data[1] = (Object)closure1023;
  addmethod2(obj1021, "apply", &meth_ast_apply1023);
  set_type(obj1021, 0);
// compilenode returning obj1021
  setclassname(obj1021, "Block<ast:1020>");
// compilenode returning obj1021
  params[0] = call1019;
  Object iter1018 = callmethod(call1019, "iter", 1, params);
  while(1) {
    Object cond1018 = callmethod(iter1018, "havemore", 0, NULL);
    if (!istrue(cond1018)) break;
    params[0] = callmethod(iter1018, "next", 0, NULL);
    callmethod(obj1021, "apply", 1, params);
  }
// compilenode returning call1019
// Begin line 321
  setline(321);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astarray992(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object *var_values = alloc_var();
  *var_values = args[0];
  Object params[1];
  Object obj993 = alloc_obj2(6,6);
// OBJECT OUTER DEC outer
  adddatum2(obj993, self, 0);
  addmethod2(obj993, "outer", &reader_ast_outer_994);
  adddatum2(obj993, self, 0);
// Begin line 308
  setline(308);
  if (strlit995 == NULL) {
    strlit995 = alloc_String("array");
  }
// compilenode returning strlit995
// OBJECT CONST DEC kind
  adddatum2(obj993, strlit995, 1);
  addmethod2(obj993, "kind", &reader_ast_kind_996);
// Begin line 309
  setline(309);
// compilenode returning *var_values
// OBJECT CONST DEC value
  adddatum2(obj993, *var_values, 2);
  addmethod2(obj993, "value", &reader_ast_value_997);
// Begin line 310
  setline(310);
  if (strlit998 == NULL) {
    strlit998 = alloc_String("");
  }
// compilenode returning strlit998
// OBJECT VAR DEC register
  adddatum2(obj993, strlit998, 3);
  addmethod2(obj993, "register", &reader_ast_register_999);
  addmethod2(obj993, "register:=", &writer_ast_register_999);
// Begin line 312
  setline(312);
// Begin line 555
  setline(555);
// Begin line 311
  setline(311);
// compilenode returning module_util
  Object call1000 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1000
// compilenode returning call1000
// OBJECT CONST DEC line
  adddatum2(obj993, call1000, 4);
  addmethod2(obj993, "line", &reader_ast_line_1001);
  addmethod2(obj993, "pretty", &meth_ast_pretty1002);
  set_type(obj993, 14);
// compilenode returning obj993
  return obj993;
}
Object meth_ast_apply1057(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 336
  setline(336);
// Begin line 335
  setline(335);
// compilenode returning *var_spc
  if (strlit1058 == NULL) {
    strlit1058 = alloc_String("  ");
  }
// compilenode returning strlit1058
  params[0] = strlit1058;
  Object opresult1060 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1060
  *var_spc = opresult1060;
  if (opresult1060 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1048(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 334
  setline(334);
// Begin line 333
  setline(333);
  if (strlit1049 == NULL) {
    strlit1049 = alloc_String("");
  }
// compilenode returning strlit1049
  var_spc = alloc_var();
  *var_spc = strlit1049;
  if (strlit1049 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 336
  setline(336);
// Begin line 337
  setline(337);
// Begin line 334
  setline(334);
  Object num1051 = alloc_Float64(0.0);
// compilenode returning num1051
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1053 = callmethod(num1051, "..", 1, params);
// compilenode returning opresult1053
// Begin line 336
  setline(336);
// Begin line 555
  setline(555);
  Object obj1055 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1055, self, 0);
  addmethod2(obj1055, "outer", &reader_ast_outer_1056);
  adddatum2(obj1055, self, 0);
  block_savedest(obj1055);
  Object **closure1057 = createclosure(2);
  addtoclosure(closure1057, var_spc);
  Object *selfpp1062 = alloc_var();
  *selfpp1062 = self;
  addtoclosure(closure1057, selfpp1062);
  struct UserObject *uo1057 = (struct UserObject*)obj1055;
  uo1057->data[1] = (Object)closure1057;
  addmethod2(obj1055, "apply", &meth_ast_apply1057);
  set_type(obj1055, 0);
// compilenode returning obj1055
  setclassname(obj1055, "Block<ast:1054>");
// compilenode returning obj1055
  params[0] = opresult1053;
  Object iter1050 = callmethod(opresult1053, "iter", 1, params);
  while(1) {
    Object cond1050 = callmethod(iter1050, "havemore", 0, NULL);
    if (!istrue(cond1050)) break;
    params[0] = callmethod(iter1050, "next", 0, NULL);
    callmethod(obj1055, "apply", 1, params);
  }
// compilenode returning opresult1053
// Begin line 338
  setline(338);
// Begin line 337
  setline(337);
  if (strlit1063 == NULL) {
    strlit1063 = alloc_String("Member(");
  }
// compilenode returning strlit1063
// Begin line 338
  setline(338);
// Begin line 555
  setline(555);
// Begin line 337
  setline(337);
// compilenode returning self
  Object call1064 = callmethod(self, "value",
    0, params);
// compilenode returning call1064
// compilenode returning call1064
  params[0] = call1064;
  Object opresult1066 = callmethod(strlit1063, "++", 1, params);
// compilenode returning opresult1066
  if (strlit1067 == NULL) {
    strlit1067 = alloc_String(")""\x0a""");
  }
// compilenode returning strlit1067
  params[0] = strlit1067;
  Object opresult1069 = callmethod(opresult1066, "++", 1, params);
// compilenode returning opresult1069
  var_s = alloc_var();
  *var_s = opresult1069;
  if (opresult1069 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 338
  setline(338);
// Begin line 339
  setline(339);
// Begin line 338
  setline(338);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1071 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1071
// compilenode returning *var_depth
  Object num1072 = alloc_Float64(1.0);
// compilenode returning num1072
  params[0] = num1072;
  Object sum1074 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1074
// Begin line 339
  setline(339);
// Begin line 555
  setline(555);
// Begin line 338
  setline(338);
// compilenode returning self
  Object call1075 = callmethod(self, "in",
    0, params);
// compilenode returning call1075
// compilenode returning call1075
  params[0] = sum1074;
  Object call1076 = callmethod(call1075, "pretty",
    1, params);
// compilenode returning call1076
  params[0] = call1076;
  Object opresult1078 = callmethod(opresult1071, "++", 1, params);
// compilenode returning opresult1078
  *var_s = opresult1078;
  if (opresult1078 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 339
  setline(339);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astmember1037(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object *var_what = alloc_var();
  *var_what = args[0];
  Object *var_in_39_ = alloc_var();
  *var_in_39_ = args[1];
  Object params[1];
  Object obj1038 = alloc_obj2(8,7);
// OBJECT OUTER DEC outer
  adddatum2(obj1038, self, 0);
  addmethod2(obj1038, "outer", &reader_ast_outer_1039);
  adddatum2(obj1038, self, 0);
// Begin line 327
  setline(327);
  if (strlit1040 == NULL) {
    strlit1040 = alloc_String("member");
  }
// compilenode returning strlit1040
// OBJECT CONST DEC kind
  adddatum2(obj1038, strlit1040, 1);
  addmethod2(obj1038, "kind", &reader_ast_kind_1041);
// Begin line 328
  setline(328);
// compilenode returning *var_what
// OBJECT VAR DEC value
  adddatum2(obj1038, *var_what, 2);
  addmethod2(obj1038, "value", &reader_ast_value_1042);
  addmethod2(obj1038, "value:=", &writer_ast_value_1042);
// Begin line 329
  setline(329);
// compilenode returning *var_in_39_
// OBJECT CONST DEC in
  adddatum2(obj1038, *var_in_39_, 3);
  addmethod2(obj1038, "in", &reader_ast_in_1043);
// Begin line 330
  setline(330);
  if (strlit1044 == NULL) {
    strlit1044 = alloc_String("");
  }
// compilenode returning strlit1044
// OBJECT VAR DEC register
  adddatum2(obj1038, strlit1044, 4);
  addmethod2(obj1038, "register", &reader_ast_register_1045);
  addmethod2(obj1038, "register:=", &writer_ast_register_1045);
// Begin line 332
  setline(332);
// Begin line 555
  setline(555);
// Begin line 331
  setline(331);
// compilenode returning module_util
  Object call1046 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1046
// compilenode returning call1046
// OBJECT CONST DEC line
  adddatum2(obj1038, call1046, 5);
  addmethod2(obj1038, "line", &reader_ast_line_1047);
  addmethod2(obj1038, "pretty", &meth_ast_pretty1048);
  set_type(obj1038, 15);
// compilenode returning obj1038
  return obj1038;
}
Object meth_ast_apply1105(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_s = closure[0];
  Object self = *closure[1];
// Begin line 353
  setline(353);
// compilenode returning *var_s
  Object num1106 = alloc_Float64(0.0);
// compilenode returning num1106
// compilenode returning *var_p
  params[0] = num1106;
  Object call1107 = callmethod(*var_p, "pretty",
    1, params);
// compilenode returning call1107
  params[0] = call1107;
  Object opresult1109 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1109
  *var_s = opresult1109;
  if (opresult1109 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 355
  setline(355);
// Begin line 354
  setline(354);
// compilenode returning *var_s
  if (strlit1111 == NULL) {
    strlit1111 = alloc_String(",");
  }
// compilenode returning strlit1111
  params[0] = strlit1111;
  Object opresult1113 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1113
  *var_s = opresult1113;
  if (opresult1113 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1091(Object self, int nparams, Object *args, int32_t flags) {
  Object *var_depth = args + 0;
  Object params[1];
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 352
  setline(352);
// Begin line 351
  setline(351);
  if (strlit1092 == NULL) {
    strlit1092 = alloc_String("Generic(");
  }
// compilenode returning strlit1092
// Begin line 352
  setline(352);
// Begin line 555
  setline(555);
// Begin line 352
  setline(352);
// Begin line 555
  setline(555);
// Begin line 351
  setline(351);
// compilenode returning self
  Object call1093 = callmethod(self, "value",
    0, params);
// compilenode returning call1093
// compilenode returning call1093
  Object call1094 = callmethod(call1093, "value",
    0, params);
// compilenode returning call1094
// compilenode returning call1094
  params[0] = call1094;
  Object opresult1096 = callmethod(strlit1092, "++", 1, params);
// compilenode returning opresult1096
  if (strlit1097 == NULL) {
    strlit1097 = alloc_String("<");
  }
// compilenode returning strlit1097
  params[0] = strlit1097;
  Object opresult1099 = callmethod(opresult1096, "++", 1, params);
// compilenode returning opresult1099
  var_s = alloc_var();
  *var_s = opresult1099;
  if (opresult1099 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 355
  setline(355);
// Begin line 356
  setline(356);
// compilenode returning self
  Object call1101 = callmethod(self, "params",
    0, params);
// compilenode returning call1101
// Begin line 355
  setline(355);
// Begin line 555
  setline(555);
  Object obj1103 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1103, self, 0);
  addmethod2(obj1103, "outer", &reader_ast_outer_1104);
  adddatum2(obj1103, self, 0);
  block_savedest(obj1103);
  Object **closure1105 = createclosure(2);
  addtoclosure(closure1105, var_s);
  Object *selfpp1115 = alloc_var();
  *selfpp1115 = self;
  addtoclosure(closure1105, selfpp1115);
  struct UserObject *uo1105 = (struct UserObject*)obj1103;
  uo1105->data[1] = (Object)closure1105;
  addmethod2(obj1103, "apply", &meth_ast_apply1105);
  set_type(obj1103, 0);
// compilenode returning obj1103
  setclassname(obj1103, "Block<ast:1102>");
// compilenode returning obj1103
  params[0] = call1101;
  Object iter1100 = callmethod(call1101, "iter", 1, params);
  while(1) {
    Object cond1100 = callmethod(iter1100, "havemore", 0, NULL);
    if (!istrue(cond1100)) break;
    params[0] = callmethod(iter1100, "next", 0, NULL);
    callmethod(obj1103, "apply", 1, params);
  }
// compilenode returning call1101
// Begin line 357
  setline(357);
// Begin line 356
  setline(356);
// compilenode returning *var_s
  if (strlit1116 == NULL) {
    strlit1116 = alloc_String(">)");
  }
// compilenode returning strlit1116
  params[0] = strlit1116;
  Object opresult1118 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1118
  return opresult1118;
}
Object meth_ast_astgeneric1080(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object *var_base = alloc_var();
  *var_base = args[0];
  Object *var_params_39_ = alloc_var();
  *var_params_39_ = args[1];
  Object params[1];
  Object obj1081 = alloc_obj2(7,7);
// OBJECT OUTER DEC outer
  adddatum2(obj1081, self, 0);
  addmethod2(obj1081, "outer", &reader_ast_outer_1082);
  adddatum2(obj1081, self, 0);
// Begin line 345
  setline(345);
  if (strlit1083 == NULL) {
    strlit1083 = alloc_String("generic");
  }
// compilenode returning strlit1083
// OBJECT CONST DEC kind
  adddatum2(obj1081, strlit1083, 1);
  addmethod2(obj1081, "kind", &reader_ast_kind_1084);
// Begin line 346
  setline(346);
// compilenode returning *var_base
// OBJECT CONST DEC value
  adddatum2(obj1081, *var_base, 2);
  addmethod2(obj1081, "value", &reader_ast_value_1085);
// Begin line 347
  setline(347);
// compilenode returning *var_params_39_
// OBJECT CONST DEC params
  adddatum2(obj1081, *var_params_39_, 3);
  addmethod2(obj1081, "params", &reader_ast_params_1086);
// Begin line 348
  setline(348);
  if (strlit1087 == NULL) {
    strlit1087 = alloc_String("");
  }
// compilenode returning strlit1087
// OBJECT VAR DEC register
  adddatum2(obj1081, strlit1087, 4);
  addmethod2(obj1081, "register", &reader_ast_register_1088);
  addmethod2(obj1081, "register:=", &writer_ast_register_1088);
// Begin line 350
  setline(350);
// Begin line 555
  setline(555);
// Begin line 349
  setline(349);
// compilenode returning module_util
  Object call1089 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1089
// compilenode returning call1089
// OBJECT CONST DEC line
  adddatum2(obj1081, call1089, 5);
  addmethod2(obj1081, "line", &reader_ast_line_1090);
  addmethod2(obj1081, "pretty", &meth_ast_pretty1091);
  set_type(obj1081, 16);
// compilenode returning obj1081
  return obj1081;
}
Object meth_ast_pretty1130(Object self, int nparams, Object *args, int32_t flags) {
  Object *var_depth = args + 0;
  Object params[1];
// Begin line 369
  setline(369);
// Begin line 368
  setline(368);
  if (strlit1131 == NULL) {
    strlit1131 = alloc_String("Identifier(");
  }
// compilenode returning strlit1131
// Begin line 369
  setline(369);
// Begin line 555
  setline(555);
// Begin line 368
  setline(368);
// compilenode returning self
  Object call1132 = callmethod(self, "value",
    0, params);
// compilenode returning call1132
// compilenode returning call1132
  params[0] = call1132;
  Object opresult1134 = callmethod(strlit1131, "++", 1, params);
// compilenode returning opresult1134
  if (strlit1135 == NULL) {
    strlit1135 = alloc_String(")");
  }
// compilenode returning strlit1135
  params[0] = strlit1135;
  Object opresult1137 = callmethod(opresult1134, "++", 1, params);
// compilenode returning opresult1137
  return opresult1137;
}
Object meth_ast_astidentifier1119(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object *var_n = alloc_var();
  *var_n = args[0];
  Object *var_dtype_39_ = alloc_var();
  *var_dtype_39_ = args[1];
  Object params[1];
  Object obj1120 = alloc_obj2(9,7);
// OBJECT OUTER DEC outer
  adddatum2(obj1120, self, 0);
  addmethod2(obj1120, "outer", &reader_ast_outer_1121);
  adddatum2(obj1120, self, 0);
// Begin line 362
  setline(362);
  if (strlit1122 == NULL) {
    strlit1122 = alloc_String("identifier");
  }
// compilenode returning strlit1122
// OBJECT CONST DEC kind
  adddatum2(obj1120, strlit1122, 1);
  addmethod2(obj1120, "kind", &reader_ast_kind_1123);
// Begin line 363
  setline(363);
// compilenode returning *var_n
// OBJECT VAR DEC value
  adddatum2(obj1120, *var_n, 2);
  addmethod2(obj1120, "value", &reader_ast_value_1124);
  addmethod2(obj1120, "value:=", &writer_ast_value_1124);
// Begin line 364
  setline(364);
// compilenode returning *var_dtype_39_
// OBJECT VAR DEC dtype
  adddatum2(obj1120, *var_dtype_39_, 3);
  addmethod2(obj1120, "dtype", &reader_ast_dtype_1125);
  addmethod2(obj1120, "dtype:=", &writer_ast_dtype_1125);
// Begin line 365
  setline(365);
  if (strlit1126 == NULL) {
    strlit1126 = alloc_String("");
  }
// compilenode returning strlit1126
// OBJECT VAR DEC register
  adddatum2(obj1120, strlit1126, 4);
  addmethod2(obj1120, "register", &reader_ast_register_1127);
  addmethod2(obj1120, "register:=", &writer_ast_register_1127);
// Begin line 367
  setline(367);
// Begin line 555
  setline(555);
// Begin line 366
  setline(366);
// compilenode returning module_util
  Object call1128 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1128
// compilenode returning call1128
// OBJECT CONST DEC line
  adddatum2(obj1120, call1128, 5);
  addmethod2(obj1120, "line", &reader_ast_line_1129);
  addmethod2(obj1120, "pretty", &meth_ast_pretty1130);
  set_type(obj1120, 17);
// compilenode returning obj1120
  return obj1120;
}
Object meth_ast_pretty1148(Object self, int nparams, Object *args, int32_t flags) {
  Object *var_depth = args + 0;
  Object params[1];
// Begin line 380
  setline(380);
// Begin line 379
  setline(379);
  if (strlit1149 == NULL) {
    strlit1149 = alloc_String("Octets(");
  }
// compilenode returning strlit1149
// Begin line 380
  setline(380);
// Begin line 555
  setline(555);
// Begin line 379
  setline(379);
// compilenode returning self
  Object call1150 = callmethod(self, "value",
    0, params);
// compilenode returning call1150
// compilenode returning call1150
  params[0] = call1150;
  Object opresult1152 = callmethod(strlit1149, "++", 1, params);
// compilenode returning opresult1152
  if (strlit1153 == NULL) {
    strlit1153 = alloc_String(")");
  }
// compilenode returning strlit1153
  params[0] = strlit1153;
  Object opresult1155 = callmethod(opresult1152, "++", 1, params);
// compilenode returning opresult1155
  return opresult1155;
}
Object meth_ast_astoctets1138(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object *var_n = alloc_var();
  *var_n = args[0];
  Object params[1];
  Object obj1139 = alloc_obj2(6,6);
// OBJECT OUTER DEC outer
  adddatum2(obj1139, self, 0);
  addmethod2(obj1139, "outer", &reader_ast_outer_1140);
  adddatum2(obj1139, self, 0);
// Begin line 374
  setline(374);
  if (strlit1141 == NULL) {
    strlit1141 = alloc_String("octets");
  }
// compilenode returning strlit1141
// OBJECT CONST DEC kind
  adddatum2(obj1139, strlit1141, 1);
  addmethod2(obj1139, "kind", &reader_ast_kind_1142);
// Begin line 375
  setline(375);
// compilenode returning *var_n
// OBJECT CONST DEC value
  adddatum2(obj1139, *var_n, 2);
  addmethod2(obj1139, "value", &reader_ast_value_1143);
// Begin line 376
  setline(376);
  if (strlit1144 == NULL) {
    strlit1144 = alloc_String("");
  }
// compilenode returning strlit1144
// OBJECT VAR DEC register
  adddatum2(obj1139, strlit1144, 3);
  addmethod2(obj1139, "register", &reader_ast_register_1145);
  addmethod2(obj1139, "register:=", &writer_ast_register_1145);
// Begin line 378
  setline(378);
// Begin line 555
  setline(555);
// Begin line 377
  setline(377);
// compilenode returning module_util
  Object call1146 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1146
// compilenode returning call1146
// OBJECT CONST DEC line
  adddatum2(obj1139, call1146, 4);
  addmethod2(obj1139, "line", &reader_ast_line_1147);
  addmethod2(obj1139, "pretty", &meth_ast_pretty1148);
  set_type(obj1139, 18);
// compilenode returning obj1139
  return obj1139;
}
Object meth_ast_pretty1166(Object self, int nparams, Object *args, int32_t flags) {
  Object *var_depth = args + 0;
  Object params[1];
// Begin line 391
  setline(391);
// Begin line 390
  setline(390);
  if (strlit1167 == NULL) {
    strlit1167 = alloc_String("String(");
  }
// compilenode returning strlit1167
// Begin line 391
  setline(391);
// Begin line 555
  setline(555);
// Begin line 390
  setline(390);
// compilenode returning self
  Object call1168 = callmethod(self, "value",
    0, params);
// compilenode returning call1168
// compilenode returning call1168
  params[0] = call1168;
  Object opresult1170 = callmethod(strlit1167, "++", 1, params);
// compilenode returning opresult1170
  if (strlit1171 == NULL) {
    strlit1171 = alloc_String(")");
  }
// compilenode returning strlit1171
  params[0] = strlit1171;
  Object opresult1173 = callmethod(opresult1170, "++", 1, params);
// compilenode returning opresult1173
  return opresult1173;
}
Object meth_ast_aststring1156(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_n = alloc_var();
  *var_n = args[0];
  Object params[1];
  Object obj1157 = alloc_obj2(7,6);
// OBJECT OUTER DEC outer
  adddatum2(obj1157, self, 0);
  addmethod2(obj1157, "outer", &reader_ast_outer_1158);
  adddatum2(obj1157, self, 0);
// Begin line 385
  setline(385);
  if (strlit1159 == NULL) {
    strlit1159 = alloc_String("string");
  }
// compilenode returning strlit1159
// OBJECT CONST DEC kind
  adddatum2(obj1157, strlit1159, 1);
  addmethod2(obj1157, "kind", &reader_ast_kind_1160);
// Begin line 386
  setline(386);
// compilenode returning *var_n
// OBJECT VAR DEC value
  adddatum2(obj1157, *var_n, 2);
  addmethod2(obj1157, "value", &reader_ast_value_1161);
  addmethod2(obj1157, "value:=", &writer_ast_value_1161);
// Begin line 387
  setline(387);
  if (strlit1162 == NULL) {
    strlit1162 = alloc_String("");
  }
// compilenode returning strlit1162
// OBJECT VAR DEC register
  adddatum2(obj1157, strlit1162, 3);
  addmethod2(obj1157, "register", &reader_ast_register_1163);
  addmethod2(obj1157, "register:=", &writer_ast_register_1163);
// Begin line 389
  setline(389);
// Begin line 555
  setline(555);
// Begin line 388
  setline(388);
// compilenode returning module_util
  Object call1164 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1164
// compilenode returning call1164
// OBJECT CONST DEC line
  adddatum2(obj1157, call1164, 4);
  addmethod2(obj1157, "line", &reader_ast_line_1165);
  addmethod2(obj1157, "pretty", &meth_ast_pretty1166);
  set_type(obj1157, 19);
// compilenode returning obj1157
  return obj1157;
}
Object meth_ast_pretty1184(Object self, int nparams, Object *args, int32_t flags) {
  Object *var_depth = args + 0;
  Object params[1];
// Begin line 402
  setline(402);
// Begin line 401
  setline(401);
  if (strlit1185 == NULL) {
    strlit1185 = alloc_String("Num(");
  }
// compilenode returning strlit1185
// Begin line 402
  setline(402);
// Begin line 555
  setline(555);
// Begin line 401
  setline(401);
// compilenode returning self
  Object call1186 = callmethod(self, "value",
    0, params);
// compilenode returning call1186
// compilenode returning call1186
  params[0] = call1186;
  Object opresult1188 = callmethod(strlit1185, "++", 1, params);
// compilenode returning opresult1188
  if (strlit1189 == NULL) {
    strlit1189 = alloc_String(")");
  }
// compilenode returning strlit1189
  params[0] = strlit1189;
  Object opresult1191 = callmethod(opresult1188, "++", 1, params);
// compilenode returning opresult1191
  return opresult1191;
}
Object meth_ast_astnum1174(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object *var_n = alloc_var();
  *var_n = args[0];
  Object params[1];
  Object obj1175 = alloc_obj2(6,6);
// OBJECT OUTER DEC outer
  adddatum2(obj1175, self, 0);
  addmethod2(obj1175, "outer", &reader_ast_outer_1176);
  adddatum2(obj1175, self, 0);
// Begin line 396
  setline(396);
  if (strlit1177 == NULL) {
    strlit1177 = alloc_String("num");
  }
// compilenode returning strlit1177
// OBJECT CONST DEC kind
  adddatum2(obj1175, strlit1177, 1);
  addmethod2(obj1175, "kind", &reader_ast_kind_1178);
// Begin line 397
  setline(397);
// compilenode returning *var_n
// OBJECT CONST DEC value
  adddatum2(obj1175, *var_n, 2);
  addmethod2(obj1175, "value", &reader_ast_value_1179);
// Begin line 398
  setline(398);
  if (strlit1180 == NULL) {
    strlit1180 = alloc_String("");
  }
// compilenode returning strlit1180
// OBJECT VAR DEC register
  adddatum2(obj1175, strlit1180, 3);
  addmethod2(obj1175, "register", &reader_ast_register_1181);
  addmethod2(obj1175, "register:=", &writer_ast_register_1181);
// Begin line 400
  setline(400);
// Begin line 555
  setline(555);
// Begin line 399
  setline(399);
// compilenode returning module_util
  Object call1182 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1182
// compilenode returning call1182
// OBJECT CONST DEC line
  adddatum2(obj1175, call1182, 4);
  addmethod2(obj1175, "line", &reader_ast_line_1183);
  addmethod2(obj1175, "pretty", &meth_ast_pretty1184);
  set_type(obj1175, 20);
// compilenode returning obj1175
  return obj1175;
}
Object meth_ast_apply1213(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 417
  setline(417);
// Begin line 416
  setline(416);
// compilenode returning *var_spc
  if (strlit1214 == NULL) {
    strlit1214 = alloc_String("  ");
  }
// compilenode returning strlit1214
  params[0] = strlit1214;
  Object opresult1216 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1216
  *var_spc = opresult1216;
  if (opresult1216 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1204(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 415
  setline(415);
// Begin line 414
  setline(414);
  if (strlit1205 == NULL) {
    strlit1205 = alloc_String("");
  }
// compilenode returning strlit1205
  var_spc = alloc_var();
  *var_spc = strlit1205;
  if (strlit1205 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 417
  setline(417);
// Begin line 418
  setline(418);
// Begin line 415
  setline(415);
  Object num1207 = alloc_Float64(0.0);
// compilenode returning num1207
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1209 = callmethod(num1207, "..", 1, params);
// compilenode returning opresult1209
// Begin line 417
  setline(417);
// Begin line 555
  setline(555);
  Object obj1211 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1211, self, 0);
  addmethod2(obj1211, "outer", &reader_ast_outer_1212);
  adddatum2(obj1211, self, 0);
  block_savedest(obj1211);
  Object **closure1213 = createclosure(2);
  addtoclosure(closure1213, var_spc);
  Object *selfpp1218 = alloc_var();
  *selfpp1218 = self;
  addtoclosure(closure1213, selfpp1218);
  struct UserObject *uo1213 = (struct UserObject*)obj1211;
  uo1213->data[1] = (Object)closure1213;
  addmethod2(obj1211, "apply", &meth_ast_apply1213);
  set_type(obj1211, 0);
// compilenode returning obj1211
  setclassname(obj1211, "Block<ast:1210>");
// compilenode returning obj1211
  params[0] = opresult1209;
  Object iter1206 = callmethod(opresult1209, "iter", 1, params);
  while(1) {
    Object cond1206 = callmethod(iter1206, "havemore", 0, NULL);
    if (!istrue(cond1206)) break;
    params[0] = callmethod(iter1206, "next", 0, NULL);
    callmethod(obj1211, "apply", 1, params);
  }
// compilenode returning opresult1209
// Begin line 419
  setline(419);
// Begin line 418
  setline(418);
  if (strlit1219 == NULL) {
    strlit1219 = alloc_String("Op(");
  }
// compilenode returning strlit1219
// Begin line 419
  setline(419);
// Begin line 555
  setline(555);
// Begin line 418
  setline(418);
// compilenode returning self
  Object call1220 = callmethod(self, "value",
    0, params);
// compilenode returning call1220
// compilenode returning call1220
  params[0] = call1220;
  Object opresult1222 = callmethod(strlit1219, "++", 1, params);
// compilenode returning opresult1222
  if (strlit1223 == NULL) {
    strlit1223 = alloc_String(")");
  }
// compilenode returning strlit1223
  params[0] = strlit1223;
  Object opresult1225 = callmethod(opresult1222, "++", 1, params);
// compilenode returning opresult1225
  var_s = alloc_var();
  *var_s = opresult1225;
  if (opresult1225 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 420
  setline(420);
// Begin line 419
  setline(419);
// compilenode returning *var_s
  if (strlit1226 == NULL) {
    strlit1226 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1226
  params[0] = strlit1226;
  Object opresult1228 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1228
  *var_s = opresult1228;
  if (opresult1228 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 420
  setline(420);
// Begin line 421
  setline(421);
// Begin line 420
  setline(420);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1231 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1231
// compilenode returning *var_depth
  Object num1232 = alloc_Float64(1.0);
// compilenode returning num1232
  params[0] = num1232;
  Object sum1234 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1234
// Begin line 421
  setline(421);
// Begin line 555
  setline(555);
// Begin line 420
  setline(420);
// compilenode returning self
  Object call1235 = callmethod(self, "left",
    0, params);
// compilenode returning call1235
// compilenode returning call1235
  params[0] = sum1234;
  Object call1236 = callmethod(call1235, "pretty",
    1, params);
// compilenode returning call1236
  params[0] = call1236;
  Object opresult1238 = callmethod(opresult1231, "++", 1, params);
// compilenode returning opresult1238
  *var_s = opresult1238;
  if (opresult1238 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 422
  setline(422);
// Begin line 421
  setline(421);
// compilenode returning *var_s
  if (strlit1240 == NULL) {
    strlit1240 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1240
  params[0] = strlit1240;
  Object opresult1242 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1242
  *var_s = opresult1242;
  if (opresult1242 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 422
  setline(422);
// Begin line 423
  setline(423);
// Begin line 422
  setline(422);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1245 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1245
// compilenode returning *var_depth
  Object num1246 = alloc_Float64(1.0);
// compilenode returning num1246
  params[0] = num1246;
  Object sum1248 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1248
// Begin line 423
  setline(423);
// Begin line 555
  setline(555);
// Begin line 422
  setline(422);
// compilenode returning self
  Object call1249 = callmethod(self, "right",
    0, params);
// compilenode returning call1249
// compilenode returning call1249
  params[0] = sum1248;
  Object call1250 = callmethod(call1249, "pretty",
    1, params);
// compilenode returning call1250
  params[0] = call1250;
  Object opresult1252 = callmethod(opresult1245, "++", 1, params);
// compilenode returning opresult1252
  *var_s = opresult1252;
  if (opresult1252 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 423
  setline(423);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astop1192(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[18];
  Object *var_op = alloc_var();
  *var_op = args[0];
  Object *var_l = alloc_var();
  *var_l = args[1];
  Object *var_r = alloc_var();
  *var_r = args[2];
  Object params[1];
  Object obj1193 = alloc_obj2(8,8);
// OBJECT OUTER DEC outer
  adddatum2(obj1193, self, 0);
  addmethod2(obj1193, "outer", &reader_ast_outer_1194);
  adddatum2(obj1193, self, 0);
// Begin line 407
  setline(407);
  if (strlit1195 == NULL) {
    strlit1195 = alloc_String("op");
  }
// compilenode returning strlit1195
// OBJECT CONST DEC kind
  adddatum2(obj1193, strlit1195, 1);
  addmethod2(obj1193, "kind", &reader_ast_kind_1196);
// Begin line 408
  setline(408);
// compilenode returning *var_op
// OBJECT CONST DEC value
  adddatum2(obj1193, *var_op, 2);
  addmethod2(obj1193, "value", &reader_ast_value_1197);
// Begin line 409
  setline(409);
// compilenode returning *var_l
// OBJECT CONST DEC left
  adddatum2(obj1193, *var_l, 3);
  addmethod2(obj1193, "left", &reader_ast_left_1198);
// Begin line 410
  setline(410);
// compilenode returning *var_r
// OBJECT CONST DEC right
  adddatum2(obj1193, *var_r, 4);
  addmethod2(obj1193, "right", &reader_ast_right_1199);
// Begin line 411
  setline(411);
  if (strlit1200 == NULL) {
    strlit1200 = alloc_String("");
  }
// compilenode returning strlit1200
// OBJECT VAR DEC register
  adddatum2(obj1193, strlit1200, 5);
  addmethod2(obj1193, "register", &reader_ast_register_1201);
  addmethod2(obj1193, "register:=", &writer_ast_register_1201);
// Begin line 413
  setline(413);
// Begin line 555
  setline(555);
// Begin line 412
  setline(412);
// compilenode returning module_util
  Object call1202 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1202
// compilenode returning call1202
// OBJECT CONST DEC line
  adddatum2(obj1193, call1202, 6);
  addmethod2(obj1193, "line", &reader_ast_line_1203);
  addmethod2(obj1193, "pretty", &meth_ast_pretty1204);
  set_type(obj1193, 21);
// compilenode returning obj1193
  return obj1193;
}
Object meth_ast_apply1274(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 438
  setline(438);
// Begin line 437
  setline(437);
// compilenode returning *var_spc
  if (strlit1275 == NULL) {
    strlit1275 = alloc_String("  ");
  }
// compilenode returning strlit1275
  params[0] = strlit1275;
  Object opresult1277 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1277
  *var_spc = opresult1277;
  if (opresult1277 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1265(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 436
  setline(436);
// Begin line 435
  setline(435);
  if (strlit1266 == NULL) {
    strlit1266 = alloc_String("");
  }
// compilenode returning strlit1266
  var_spc = alloc_var();
  *var_spc = strlit1266;
  if (strlit1266 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 438
  setline(438);
// Begin line 439
  setline(439);
// Begin line 436
  setline(436);
  Object num1268 = alloc_Float64(0.0);
// compilenode returning num1268
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1270 = callmethod(num1268, "..", 1, params);
// compilenode returning opresult1270
// Begin line 438
  setline(438);
// Begin line 555
  setline(555);
  Object obj1272 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1272, self, 0);
  addmethod2(obj1272, "outer", &reader_ast_outer_1273);
  adddatum2(obj1272, self, 0);
  block_savedest(obj1272);
  Object **closure1274 = createclosure(2);
  addtoclosure(closure1274, var_spc);
  Object *selfpp1279 = alloc_var();
  *selfpp1279 = self;
  addtoclosure(closure1274, selfpp1279);
  struct UserObject *uo1274 = (struct UserObject*)obj1272;
  uo1274->data[1] = (Object)closure1274;
  addmethod2(obj1272, "apply", &meth_ast_apply1274);
  set_type(obj1272, 0);
// compilenode returning obj1272
  setclassname(obj1272, "Block<ast:1271>");
// compilenode returning obj1272
  params[0] = opresult1270;
  Object iter1267 = callmethod(opresult1270, "iter", 1, params);
  while(1) {
    Object cond1267 = callmethod(iter1267, "havemore", 0, NULL);
    if (!istrue(cond1267)) break;
    params[0] = callmethod(iter1267, "next", 0, NULL);
    callmethod(obj1272, "apply", 1, params);
  }
// compilenode returning opresult1270
// Begin line 440
  setline(440);
// Begin line 439
  setline(439);
  if (strlit1280 == NULL) {
    strlit1280 = alloc_String("Index");
  }
// compilenode returning strlit1280
  var_s = alloc_var();
  *var_s = strlit1280;
  if (strlit1280 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 441
  setline(441);
// Begin line 440
  setline(440);
// compilenode returning *var_s
  if (strlit1281 == NULL) {
    strlit1281 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1281
  params[0] = strlit1281;
  Object opresult1283 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1283
  *var_s = opresult1283;
  if (opresult1283 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 441
  setline(441);
// Begin line 442
  setline(442);
// Begin line 441
  setline(441);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1286 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1286
// compilenode returning *var_depth
  Object num1287 = alloc_Float64(1.0);
// compilenode returning num1287
  params[0] = num1287;
  Object sum1289 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1289
// Begin line 442
  setline(442);
// Begin line 555
  setline(555);
// Begin line 441
  setline(441);
// compilenode returning self
  Object call1290 = callmethod(self, "value",
    0, params);
// compilenode returning call1290
// compilenode returning call1290
  params[0] = sum1289;
  Object call1291 = callmethod(call1290, "pretty",
    1, params);
// compilenode returning call1291
  params[0] = call1291;
  Object opresult1293 = callmethod(opresult1286, "++", 1, params);
// compilenode returning opresult1293
  *var_s = opresult1293;
  if (opresult1293 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 443
  setline(443);
// Begin line 442
  setline(442);
// compilenode returning *var_s
  if (strlit1295 == NULL) {
    strlit1295 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1295
  params[0] = strlit1295;
  Object opresult1297 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1297
  *var_s = opresult1297;
  if (opresult1297 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 443
  setline(443);
// Begin line 444
  setline(444);
// Begin line 443
  setline(443);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1300 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1300
// compilenode returning *var_depth
  Object num1301 = alloc_Float64(1.0);
// compilenode returning num1301
  params[0] = num1301;
  Object sum1303 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1303
// Begin line 444
  setline(444);
// Begin line 555
  setline(555);
// Begin line 443
  setline(443);
// compilenode returning self
  Object call1304 = callmethod(self, "index",
    0, params);
// compilenode returning call1304
// compilenode returning call1304
  params[0] = sum1303;
  Object call1305 = callmethod(call1304, "pretty",
    1, params);
// compilenode returning call1305
  params[0] = call1305;
  Object opresult1307 = callmethod(opresult1300, "++", 1, params);
// compilenode returning opresult1307
  *var_s = opresult1307;
  if (opresult1307 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 444
  setline(444);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astindex1254(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[19];
  Object *var_expr = alloc_var();
  *var_expr = args[0];
  Object *var_index_39_ = alloc_var();
  *var_index_39_ = args[1];
  Object params[1];
  Object obj1255 = alloc_obj2(7,7);
// OBJECT OUTER DEC outer
  adddatum2(obj1255, self, 0);
  addmethod2(obj1255, "outer", &reader_ast_outer_1256);
  adddatum2(obj1255, self, 0);
// Begin line 429
  setline(429);
  if (strlit1257 == NULL) {
    strlit1257 = alloc_String("index");
  }
// compilenode returning strlit1257
// OBJECT CONST DEC kind
  adddatum2(obj1255, strlit1257, 1);
  addmethod2(obj1255, "kind", &reader_ast_kind_1258);
// Begin line 430
  setline(430);
// compilenode returning *var_expr
// OBJECT CONST DEC value
  adddatum2(obj1255, *var_expr, 2);
  addmethod2(obj1255, "value", &reader_ast_value_1259);
// Begin line 431
  setline(431);
// compilenode returning *var_index_39_
// OBJECT CONST DEC index
  adddatum2(obj1255, *var_index_39_, 3);
  addmethod2(obj1255, "index", &reader_ast_index_1260);
// Begin line 432
  setline(432);
  if (strlit1261 == NULL) {
    strlit1261 = alloc_String("");
  }
// compilenode returning strlit1261
// OBJECT VAR DEC register
  adddatum2(obj1255, strlit1261, 4);
  addmethod2(obj1255, "register", &reader_ast_register_1262);
  addmethod2(obj1255, "register:=", &writer_ast_register_1262);
// Begin line 434
  setline(434);
// Begin line 555
  setline(555);
// Begin line 433
  setline(433);
// compilenode returning module_util
  Object call1263 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1263
// compilenode returning call1263
// OBJECT CONST DEC line
  adddatum2(obj1255, call1263, 5);
  addmethod2(obj1255, "line", &reader_ast_line_1264);
  addmethod2(obj1255, "pretty", &meth_ast_pretty1265);
  set_type(obj1255, 22);
// compilenode returning obj1255
  return obj1255;
}
Object meth_ast_apply1329(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 459
  setline(459);
// Begin line 458
  setline(458);
// compilenode returning *var_spc
  if (strlit1330 == NULL) {
    strlit1330 = alloc_String("  ");
  }
// compilenode returning strlit1330
  params[0] = strlit1330;
  Object opresult1332 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1332
  *var_spc = opresult1332;
  if (opresult1332 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1320(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 457
  setline(457);
// Begin line 456
  setline(456);
  if (strlit1321 == NULL) {
    strlit1321 = alloc_String("");
  }
// compilenode returning strlit1321
  var_spc = alloc_var();
  *var_spc = strlit1321;
  if (strlit1321 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 459
  setline(459);
// Begin line 460
  setline(460);
// Begin line 457
  setline(457);
  Object num1323 = alloc_Float64(0.0);
// compilenode returning num1323
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1325 = callmethod(num1323, "..", 1, params);
// compilenode returning opresult1325
// Begin line 459
  setline(459);
// Begin line 555
  setline(555);
  Object obj1327 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1327, self, 0);
  addmethod2(obj1327, "outer", &reader_ast_outer_1328);
  adddatum2(obj1327, self, 0);
  block_savedest(obj1327);
  Object **closure1329 = createclosure(2);
  addtoclosure(closure1329, var_spc);
  Object *selfpp1334 = alloc_var();
  *selfpp1334 = self;
  addtoclosure(closure1329, selfpp1334);
  struct UserObject *uo1329 = (struct UserObject*)obj1327;
  uo1329->data[1] = (Object)closure1329;
  addmethod2(obj1327, "apply", &meth_ast_apply1329);
  set_type(obj1327, 0);
// compilenode returning obj1327
  setclassname(obj1327, "Block<ast:1326>");
// compilenode returning obj1327
  params[0] = opresult1325;
  Object iter1322 = callmethod(opresult1325, "iter", 1, params);
  while(1) {
    Object cond1322 = callmethod(iter1322, "havemore", 0, NULL);
    if (!istrue(cond1322)) break;
    params[0] = callmethod(iter1322, "next", 0, NULL);
    callmethod(obj1327, "apply", 1, params);
  }
// compilenode returning opresult1325
// Begin line 461
  setline(461);
// Begin line 460
  setline(460);
  if (strlit1335 == NULL) {
    strlit1335 = alloc_String("Bind");
  }
// compilenode returning strlit1335
  var_s = alloc_var();
  *var_s = strlit1335;
  if (strlit1335 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 462
  setline(462);
// Begin line 461
  setline(461);
// compilenode returning *var_s
  if (strlit1336 == NULL) {
    strlit1336 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1336
  params[0] = strlit1336;
  Object opresult1338 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1338
  *var_s = opresult1338;
  if (opresult1338 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 462
  setline(462);
// Begin line 463
  setline(463);
// Begin line 462
  setline(462);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1341 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1341
// compilenode returning *var_depth
  Object num1342 = alloc_Float64(1.0);
// compilenode returning num1342
  params[0] = num1342;
  Object sum1344 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1344
// Begin line 463
  setline(463);
// Begin line 555
  setline(555);
// Begin line 462
  setline(462);
// compilenode returning self
  Object call1345 = callmethod(self, "dest",
    0, params);
// compilenode returning call1345
// compilenode returning call1345
  params[0] = sum1344;
  Object call1346 = callmethod(call1345, "pretty",
    1, params);
// compilenode returning call1346
  params[0] = call1346;
  Object opresult1348 = callmethod(opresult1341, "++", 1, params);
// compilenode returning opresult1348
  *var_s = opresult1348;
  if (opresult1348 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 464
  setline(464);
// Begin line 463
  setline(463);
// compilenode returning *var_s
  if (strlit1350 == NULL) {
    strlit1350 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1350
  params[0] = strlit1350;
  Object opresult1352 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1352
  *var_s = opresult1352;
  if (opresult1352 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 464
  setline(464);
// Begin line 465
  setline(465);
// Begin line 464
  setline(464);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1355 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1355
// compilenode returning *var_depth
  Object num1356 = alloc_Float64(1.0);
// compilenode returning num1356
  params[0] = num1356;
  Object sum1358 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1358
// Begin line 465
  setline(465);
// Begin line 555
  setline(555);
// Begin line 464
  setline(464);
// compilenode returning self
  Object call1359 = callmethod(self, "value",
    0, params);
// compilenode returning call1359
// compilenode returning call1359
  params[0] = sum1358;
  Object call1360 = callmethod(call1359, "pretty",
    1, params);
// compilenode returning call1360
  params[0] = call1360;
  Object opresult1362 = callmethod(opresult1355, "++", 1, params);
// compilenode returning opresult1362
  *var_s = opresult1362;
  if (opresult1362 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 465
  setline(465);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astbind1309(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[20];
  Object *var_dest_39_ = alloc_var();
  *var_dest_39_ = args[0];
  Object *var_val_39_ = alloc_var();
  *var_val_39_ = args[1];
  Object params[1];
  Object obj1310 = alloc_obj2(7,7);
// OBJECT OUTER DEC outer
  adddatum2(obj1310, self, 0);
  addmethod2(obj1310, "outer", &reader_ast_outer_1311);
  adddatum2(obj1310, self, 0);
// Begin line 450
  setline(450);
  if (strlit1312 == NULL) {
    strlit1312 = alloc_String("bind");
  }
// compilenode returning strlit1312
// OBJECT CONST DEC kind
  adddatum2(obj1310, strlit1312, 1);
  addmethod2(obj1310, "kind", &reader_ast_kind_1313);
// Begin line 451
  setline(451);
// compilenode returning *var_dest_39_
// OBJECT CONST DEC dest
  adddatum2(obj1310, *var_dest_39_, 2);
  addmethod2(obj1310, "dest", &reader_ast_dest_1314);
// Begin line 452
  setline(452);
// compilenode returning *var_val_39_
// OBJECT CONST DEC value
  adddatum2(obj1310, *var_val_39_, 3);
  addmethod2(obj1310, "value", &reader_ast_value_1315);
// Begin line 453
  setline(453);
  if (strlit1316 == NULL) {
    strlit1316 = alloc_String("");
  }
// compilenode returning strlit1316
// OBJECT VAR DEC register
  adddatum2(obj1310, strlit1316, 4);
  addmethod2(obj1310, "register", &reader_ast_register_1317);
  addmethod2(obj1310, "register:=", &writer_ast_register_1317);
// Begin line 455
  setline(455);
// Begin line 555
  setline(555);
// Begin line 454
  setline(454);
// compilenode returning module_util
  Object call1318 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1318
// compilenode returning call1318
// OBJECT CONST DEC line
  adddatum2(obj1310, call1318, 5);
  addmethod2(obj1310, "line", &reader_ast_line_1319);
  addmethod2(obj1310, "pretty", &meth_ast_pretty1320);
  set_type(obj1310, 23);
// compilenode returning obj1310
  return obj1310;
}
Object meth_ast_apply1385(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 481
  setline(481);
// Begin line 480
  setline(480);
// compilenode returning *var_spc
  if (strlit1386 == NULL) {
    strlit1386 = alloc_String("  ");
  }
// compilenode returning strlit1386
  params[0] = strlit1386;
  Object opresult1388 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1388
  *var_spc = opresult1388;
  if (opresult1388 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1376(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 479
  setline(479);
// Begin line 478
  setline(478);
  if (strlit1377 == NULL) {
    strlit1377 = alloc_String("");
  }
// compilenode returning strlit1377
  var_spc = alloc_var();
  *var_spc = strlit1377;
  if (strlit1377 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 481
  setline(481);
// Begin line 482
  setline(482);
// Begin line 479
  setline(479);
  Object num1379 = alloc_Float64(0.0);
// compilenode returning num1379
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1381 = callmethod(num1379, "..", 1, params);
// compilenode returning opresult1381
// Begin line 481
  setline(481);
// Begin line 555
  setline(555);
  Object obj1383 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1383, self, 0);
  addmethod2(obj1383, "outer", &reader_ast_outer_1384);
  adddatum2(obj1383, self, 0);
  block_savedest(obj1383);
  Object **closure1385 = createclosure(2);
  addtoclosure(closure1385, var_spc);
  Object *selfpp1390 = alloc_var();
  *selfpp1390 = self;
  addtoclosure(closure1385, selfpp1390);
  struct UserObject *uo1385 = (struct UserObject*)obj1383;
  uo1385->data[1] = (Object)closure1385;
  addmethod2(obj1383, "apply", &meth_ast_apply1385);
  set_type(obj1383, 0);
// compilenode returning obj1383
  setclassname(obj1383, "Block<ast:1382>");
// compilenode returning obj1383
  params[0] = opresult1381;
  Object iter1378 = callmethod(opresult1381, "iter", 1, params);
  while(1) {
    Object cond1378 = callmethod(iter1378, "havemore", 0, NULL);
    if (!istrue(cond1378)) break;
    params[0] = callmethod(iter1378, "next", 0, NULL);
    callmethod(obj1383, "apply", 1, params);
  }
// compilenode returning opresult1381
// Begin line 483
  setline(483);
// Begin line 482
  setline(482);
  if (strlit1391 == NULL) {
    strlit1391 = alloc_String("defdec");
  }
// compilenode returning strlit1391
  var_s = alloc_var();
  *var_s = strlit1391;
  if (strlit1391 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 484
  setline(484);
// Begin line 483
  setline(483);
// compilenode returning *var_s
  if (strlit1392 == NULL) {
    strlit1392 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1392
  params[0] = strlit1392;
  Object opresult1394 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1394
  *var_s = opresult1394;
  if (opresult1394 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 484
  setline(484);
// Begin line 485
  setline(485);
// Begin line 484
  setline(484);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1397 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1397
// compilenode returning *var_depth
// Begin line 485
  setline(485);
// Begin line 555
  setline(555);
// Begin line 484
  setline(484);
// compilenode returning self
  Object call1398 = callmethod(self, "name",
    0, params);
// compilenode returning call1398
// compilenode returning call1398
  params[0] = *var_depth;
  Object call1399 = callmethod(call1398, "pretty",
    1, params);
// compilenode returning call1399
  params[0] = call1399;
  Object opresult1401 = callmethod(opresult1397, "++", 1, params);
// compilenode returning opresult1401
  *var_s = opresult1401;
  if (opresult1401 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 486
  setline(486);
// Begin line 488
  setline(488);
// Begin line 555
  setline(555);
// Begin line 485
  setline(485);
// compilenode returning self
  Object call1404 = callmethod(self, "dtype",
    0, params);
// compilenode returning call1404
// compilenode returning call1404
  Object if1403;
  if (istrue(call1404)) {
// Begin line 486
  setline(486);
// Begin line 487
  setline(487);
// Begin line 486
  setline(486);
// compilenode returning *var_s
  if (strlit1405 == NULL) {
    strlit1405 = alloc_String(" : ");
  }
// compilenode returning strlit1405
  params[0] = strlit1405;
  Object opresult1407 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1407
  Object num1408 = alloc_Float64(0.0);
// compilenode returning num1408
// Begin line 487
  setline(487);
// Begin line 555
  setline(555);
// Begin line 486
  setline(486);
// compilenode returning self
  Object call1409 = callmethod(self, "dtype",
    0, params);
// compilenode returning call1409
// compilenode returning call1409
  params[0] = num1408;
  Object call1410 = callmethod(call1409, "pretty",
    1, params);
// compilenode returning call1410
  params[0] = call1410;
  Object opresult1412 = callmethod(opresult1407, "++", 1, params);
// compilenode returning opresult1412
  *var_s = opresult1412;
  if (opresult1412 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1403 = nothing;
  } else {
  }
// compilenode returning if1403
// Begin line 490
  setline(490);
// Begin line 492
  setline(492);
// Begin line 555
  setline(555);
// Begin line 488
  setline(488);
// compilenode returning self
  Object call1415 = callmethod(self, "value",
    0, params);
// compilenode returning call1415
// compilenode returning call1415
  Object if1414;
  if (istrue(call1415)) {
// Begin line 490
  setline(490);
// Begin line 489
  setline(489);
// compilenode returning *var_s
  if (strlit1416 == NULL) {
    strlit1416 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1416
  params[0] = strlit1416;
  Object opresult1418 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1418
  *var_s = opresult1418;
  if (opresult1418 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 490
  setline(490);
// Begin line 491
  setline(491);
// Begin line 490
  setline(490);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1421 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1421
// compilenode returning *var_depth
  Object num1422 = alloc_Float64(1.0);
// compilenode returning num1422
  params[0] = num1422;
  Object sum1424 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1424
// Begin line 491
  setline(491);
// Begin line 555
  setline(555);
// Begin line 490
  setline(490);
// compilenode returning self
  Object call1425 = callmethod(self, "value",
    0, params);
// compilenode returning call1425
// compilenode returning call1425
  params[0] = sum1424;
  Object call1426 = callmethod(call1425, "pretty",
    1, params);
// compilenode returning call1426
  params[0] = call1426;
  Object opresult1428 = callmethod(opresult1421, "++", 1, params);
// compilenode returning opresult1428
  *var_s = opresult1428;
  if (opresult1428 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1414 = nothing;
  } else {
  }
// compilenode returning if1414
// Begin line 492
  setline(492);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astdefdec1364(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[21];
  Object *var_name_39_ = alloc_var();
  *var_name_39_ = args[0];
  Object *var_val = alloc_var();
  *var_val = args[1];
  Object *var_dtype_39_ = alloc_var();
  *var_dtype_39_ = args[2];
  Object params[1];
  Object obj1365 = alloc_obj2(9,8);
// OBJECT OUTER DEC outer
  adddatum2(obj1365, self, 0);
  addmethod2(obj1365, "outer", &reader_ast_outer_1366);
  adddatum2(obj1365, self, 0);
// Begin line 471
  setline(471);
  if (strlit1367 == NULL) {
    strlit1367 = alloc_String("defdec");
  }
// compilenode returning strlit1367
// OBJECT CONST DEC kind
  adddatum2(obj1365, strlit1367, 1);
  addmethod2(obj1365, "kind", &reader_ast_kind_1368);
// Begin line 472
  setline(472);
// compilenode returning *var_name_39_
// OBJECT CONST DEC name
  adddatum2(obj1365, *var_name_39_, 2);
  addmethod2(obj1365, "name", &reader_ast_name_1369);
// Begin line 473
  setline(473);
// compilenode returning *var_val
// OBJECT CONST DEC value
  adddatum2(obj1365, *var_val, 3);
  addmethod2(obj1365, "value", &reader_ast_value_1370);
// Begin line 474
  setline(474);
// compilenode returning *var_dtype_39_
// OBJECT VAR DEC dtype
  adddatum2(obj1365, *var_dtype_39_, 4);
  addmethod2(obj1365, "dtype", &reader_ast_dtype_1371);
  addmethod2(obj1365, "dtype:=", &writer_ast_dtype_1371);
// Begin line 475
  setline(475);
  if (strlit1372 == NULL) {
    strlit1372 = alloc_String("");
  }
// compilenode returning strlit1372
// OBJECT VAR DEC register
  adddatum2(obj1365, strlit1372, 5);
  addmethod2(obj1365, "register", &reader_ast_register_1373);
  addmethod2(obj1365, "register:=", &writer_ast_register_1373);
// Begin line 477
  setline(477);
// Begin line 555
  setline(555);
// Begin line 476
  setline(476);
// compilenode returning module_util
  Object call1374 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1374
// compilenode returning call1374
// OBJECT CONST DEC line
  adddatum2(obj1365, call1374, 6);
  addmethod2(obj1365, "line", &reader_ast_line_1375);
  addmethod2(obj1365, "pretty", &meth_ast_pretty1376);
  set_type(obj1365, 24);
// compilenode returning obj1365
  return obj1365;
}
Object meth_ast_apply1451(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 508
  setline(508);
// Begin line 507
  setline(507);
// compilenode returning *var_spc
  if (strlit1452 == NULL) {
    strlit1452 = alloc_String("  ");
  }
// compilenode returning strlit1452
  params[0] = strlit1452;
  Object opresult1454 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1454
  *var_spc = opresult1454;
  if (opresult1454 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1442(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 506
  setline(506);
// Begin line 505
  setline(505);
  if (strlit1443 == NULL) {
    strlit1443 = alloc_String("");
  }
// compilenode returning strlit1443
  var_spc = alloc_var();
  *var_spc = strlit1443;
  if (strlit1443 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 508
  setline(508);
// Begin line 509
  setline(509);
// Begin line 506
  setline(506);
  Object num1445 = alloc_Float64(0.0);
// compilenode returning num1445
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1447 = callmethod(num1445, "..", 1, params);
// compilenode returning opresult1447
// Begin line 508
  setline(508);
// Begin line 555
  setline(555);
  Object obj1449 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1449, self, 0);
  addmethod2(obj1449, "outer", &reader_ast_outer_1450);
  adddatum2(obj1449, self, 0);
  block_savedest(obj1449);
  Object **closure1451 = createclosure(2);
  addtoclosure(closure1451, var_spc);
  Object *selfpp1456 = alloc_var();
  *selfpp1456 = self;
  addtoclosure(closure1451, selfpp1456);
  struct UserObject *uo1451 = (struct UserObject*)obj1449;
  uo1451->data[1] = (Object)closure1451;
  addmethod2(obj1449, "apply", &meth_ast_apply1451);
  set_type(obj1449, 0);
// compilenode returning obj1449
  setclassname(obj1449, "Block<ast:1448>");
// compilenode returning obj1449
  params[0] = opresult1447;
  Object iter1444 = callmethod(opresult1447, "iter", 1, params);
  while(1) {
    Object cond1444 = callmethod(iter1444, "havemore", 0, NULL);
    if (!istrue(cond1444)) break;
    params[0] = callmethod(iter1444, "next", 0, NULL);
    callmethod(obj1449, "apply", 1, params);
  }
// compilenode returning opresult1447
// Begin line 510
  setline(510);
// Begin line 509
  setline(509);
  if (strlit1457 == NULL) {
    strlit1457 = alloc_String("VarDec");
  }
// compilenode returning strlit1457
  var_s = alloc_var();
  *var_s = strlit1457;
  if (strlit1457 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 511
  setline(511);
// Begin line 510
  setline(510);
// compilenode returning *var_s
  if (strlit1458 == NULL) {
    strlit1458 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1458
  params[0] = strlit1458;
  Object opresult1460 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1460
  *var_s = opresult1460;
  if (opresult1460 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 511
  setline(511);
// Begin line 512
  setline(512);
// Begin line 511
  setline(511);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1463 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1463
// compilenode returning *var_depth
  Object num1464 = alloc_Float64(1.0);
// compilenode returning num1464
  params[0] = num1464;
  Object sum1466 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1466
// Begin line 512
  setline(512);
// Begin line 555
  setline(555);
// Begin line 511
  setline(511);
// compilenode returning self
  Object call1467 = callmethod(self, "name",
    0, params);
// compilenode returning call1467
// compilenode returning call1467
  params[0] = sum1466;
  Object call1468 = callmethod(call1467, "pretty",
    1, params);
// compilenode returning call1468
  params[0] = call1468;
  Object opresult1470 = callmethod(opresult1463, "++", 1, params);
// compilenode returning opresult1470
  *var_s = opresult1470;
  if (opresult1470 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 513
  setline(513);
// Begin line 515
  setline(515);
// Begin line 555
  setline(555);
// Begin line 512
  setline(512);
// compilenode returning self
  Object call1473 = callmethod(self, "dtype",
    0, params);
// compilenode returning call1473
// compilenode returning call1473
  Object if1472;
  if (istrue(call1473)) {
// Begin line 513
  setline(513);
// Begin line 514
  setline(514);
// Begin line 513
  setline(513);
// compilenode returning *var_s
  if (strlit1474 == NULL) {
    strlit1474 = alloc_String(" : ");
  }
// compilenode returning strlit1474
  params[0] = strlit1474;
  Object opresult1476 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1476
  Object num1477 = alloc_Float64(0.0);
// compilenode returning num1477
// Begin line 514
  setline(514);
// Begin line 555
  setline(555);
// Begin line 513
  setline(513);
// compilenode returning self
  Object call1478 = callmethod(self, "dtype",
    0, params);
// compilenode returning call1478
// compilenode returning call1478
  params[0] = num1477;
  Object call1479 = callmethod(call1478, "pretty",
    1, params);
// compilenode returning call1479
  params[0] = call1479;
  Object opresult1481 = callmethod(opresult1476, "++", 1, params);
// compilenode returning opresult1481
  *var_s = opresult1481;
  if (opresult1481 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1472 = nothing;
  } else {
  }
// compilenode returning if1472
// Begin line 517
  setline(517);
// Begin line 519
  setline(519);
// Begin line 555
  setline(555);
// Begin line 515
  setline(515);
// compilenode returning self
  Object call1484 = callmethod(self, "value",
    0, params);
// compilenode returning call1484
// compilenode returning call1484
  Object if1483;
  if (istrue(call1484)) {
// Begin line 517
  setline(517);
// Begin line 516
  setline(516);
// compilenode returning *var_s
  if (strlit1485 == NULL) {
    strlit1485 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1485
  params[0] = strlit1485;
  Object opresult1487 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1487
  *var_s = opresult1487;
  if (opresult1487 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 517
  setline(517);
// Begin line 518
  setline(518);
// Begin line 517
  setline(517);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1490 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1490
// compilenode returning *var_depth
  Object num1491 = alloc_Float64(1.0);
// compilenode returning num1491
  params[0] = num1491;
  Object sum1493 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1493
// Begin line 518
  setline(518);
// Begin line 555
  setline(555);
// Begin line 517
  setline(517);
// compilenode returning self
  Object call1494 = callmethod(self, "value",
    0, params);
// compilenode returning call1494
// compilenode returning call1494
  params[0] = sum1493;
  Object call1495 = callmethod(call1494, "pretty",
    1, params);
// compilenode returning call1495
  params[0] = call1495;
  Object opresult1497 = callmethod(opresult1490, "++", 1, params);
// compilenode returning opresult1497
  *var_s = opresult1497;
  if (opresult1497 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1483 = nothing;
  } else {
  }
// compilenode returning if1483
// Begin line 519
  setline(519);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astvardec1430(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[22];
  Object *var_name_39_ = alloc_var();
  *var_name_39_ = args[0];
  Object *var_val_39_ = alloc_var();
  *var_val_39_ = args[1];
  Object *var_dtype_39_ = alloc_var();
  *var_dtype_39_ = args[2];
  Object params[1];
  Object obj1431 = alloc_obj2(9,8);
// OBJECT OUTER DEC outer
  adddatum2(obj1431, self, 0);
  addmethod2(obj1431, "outer", &reader_ast_outer_1432);
  adddatum2(obj1431, self, 0);
// Begin line 498
  setline(498);
  if (strlit1433 == NULL) {
    strlit1433 = alloc_String("vardec");
  }
// compilenode returning strlit1433
// OBJECT CONST DEC kind
  adddatum2(obj1431, strlit1433, 1);
  addmethod2(obj1431, "kind", &reader_ast_kind_1434);
// Begin line 499
  setline(499);
// compilenode returning *var_name_39_
// OBJECT CONST DEC name
  adddatum2(obj1431, *var_name_39_, 2);
  addmethod2(obj1431, "name", &reader_ast_name_1435);
// Begin line 500
  setline(500);
// compilenode returning *var_val_39_
// OBJECT CONST DEC value
  adddatum2(obj1431, *var_val_39_, 3);
  addmethod2(obj1431, "value", &reader_ast_value_1436);
// Begin line 501
  setline(501);
// compilenode returning *var_dtype_39_
// OBJECT VAR DEC dtype
  adddatum2(obj1431, *var_dtype_39_, 4);
  addmethod2(obj1431, "dtype", &reader_ast_dtype_1437);
  addmethod2(obj1431, "dtype:=", &writer_ast_dtype_1437);
// Begin line 502
  setline(502);
  if (strlit1438 == NULL) {
    strlit1438 = alloc_String("");
  }
// compilenode returning strlit1438
// OBJECT VAR DEC register
  adddatum2(obj1431, strlit1438, 5);
  addmethod2(obj1431, "register", &reader_ast_register_1439);
  addmethod2(obj1431, "register:=", &writer_ast_register_1439);
// Begin line 504
  setline(504);
// Begin line 555
  setline(555);
// Begin line 503
  setline(503);
// compilenode returning module_util
  Object call1440 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1440
// compilenode returning call1440
// OBJECT CONST DEC line
  adddatum2(obj1431, call1440, 6);
  addmethod2(obj1431, "line", &reader_ast_line_1441);
  addmethod2(obj1431, "pretty", &meth_ast_pretty1442);
  set_type(obj1431, 25);
// compilenode returning obj1431
  return obj1431;
}
Object meth_ast_apply1518(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 533
  setline(533);
// Begin line 532
  setline(532);
// compilenode returning *var_spc
  if (strlit1519 == NULL) {
    strlit1519 = alloc_String("  ");
  }
// compilenode returning strlit1519
  params[0] = strlit1519;
  Object opresult1521 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1521
  *var_spc = opresult1521;
  if (opresult1521 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1509(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 531
  setline(531);
// Begin line 530
  setline(530);
  if (strlit1510 == NULL) {
    strlit1510 = alloc_String("");
  }
// compilenode returning strlit1510
  var_spc = alloc_var();
  *var_spc = strlit1510;
  if (strlit1510 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 533
  setline(533);
// Begin line 534
  setline(534);
// Begin line 531
  setline(531);
  Object num1512 = alloc_Float64(0.0);
// compilenode returning num1512
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1514 = callmethod(num1512, "..", 1, params);
// compilenode returning opresult1514
// Begin line 533
  setline(533);
// Begin line 555
  setline(555);
  Object obj1516 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1516, self, 0);
  addmethod2(obj1516, "outer", &reader_ast_outer_1517);
  adddatum2(obj1516, self, 0);
  block_savedest(obj1516);
  Object **closure1518 = createclosure(2);
  addtoclosure(closure1518, var_spc);
  Object *selfpp1523 = alloc_var();
  *selfpp1523 = self;
  addtoclosure(closure1518, selfpp1523);
  struct UserObject *uo1518 = (struct UserObject*)obj1516;
  uo1518->data[1] = (Object)closure1518;
  addmethod2(obj1516, "apply", &meth_ast_apply1518);
  set_type(obj1516, 0);
// compilenode returning obj1516
  setclassname(obj1516, "Block<ast:1515>");
// compilenode returning obj1516
  params[0] = opresult1514;
  Object iter1511 = callmethod(opresult1514, "iter", 1, params);
  while(1) {
    Object cond1511 = callmethod(iter1511, "havemore", 0, NULL);
    if (!istrue(cond1511)) break;
    params[0] = callmethod(iter1511, "next", 0, NULL);
    callmethod(obj1516, "apply", 1, params);
  }
// compilenode returning opresult1514
// Begin line 535
  setline(535);
// Begin line 534
  setline(534);
  if (strlit1524 == NULL) {
    strlit1524 = alloc_String("Import");
  }
// compilenode returning strlit1524
  var_s = alloc_var();
  *var_s = strlit1524;
  if (strlit1524 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 536
  setline(536);
// Begin line 535
  setline(535);
// compilenode returning *var_s
  if (strlit1525 == NULL) {
    strlit1525 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1525
  params[0] = strlit1525;
  Object opresult1527 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1527
  *var_s = opresult1527;
  if (opresult1527 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 536
  setline(536);
// Begin line 537
  setline(537);
// Begin line 536
  setline(536);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1530 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1530
// compilenode returning *var_depth
  Object num1531 = alloc_Float64(1.0);
// compilenode returning num1531
  params[0] = num1531;
  Object sum1533 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1533
// Begin line 537
  setline(537);
// Begin line 555
  setline(555);
// Begin line 536
  setline(536);
// compilenode returning self
  Object call1534 = callmethod(self, "value",
    0, params);
// compilenode returning call1534
// compilenode returning call1534
  params[0] = sum1533;
  Object call1535 = callmethod(call1534, "pretty",
    1, params);
// compilenode returning call1535
  params[0] = call1535;
  Object opresult1537 = callmethod(opresult1530, "++", 1, params);
// compilenode returning opresult1537
  *var_s = opresult1537;
  if (opresult1537 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 537
  setline(537);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astimport1499(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[23];
  Object *var_name = alloc_var();
  *var_name = args[0];
  Object params[1];
  Object obj1500 = alloc_obj2(6,6);
// OBJECT OUTER DEC outer
  adddatum2(obj1500, self, 0);
  addmethod2(obj1500, "outer", &reader_ast_outer_1501);
  adddatum2(obj1500, self, 0);
// Begin line 525
  setline(525);
  if (strlit1502 == NULL) {
    strlit1502 = alloc_String("import");
  }
// compilenode returning strlit1502
// OBJECT CONST DEC kind
  adddatum2(obj1500, strlit1502, 1);
  addmethod2(obj1500, "kind", &reader_ast_kind_1503);
// Begin line 526
  setline(526);
// compilenode returning *var_name
// OBJECT CONST DEC value
  adddatum2(obj1500, *var_name, 2);
  addmethod2(obj1500, "value", &reader_ast_value_1504);
// Begin line 527
  setline(527);
  if (strlit1505 == NULL) {
    strlit1505 = alloc_String("");
  }
// compilenode returning strlit1505
// OBJECT VAR DEC register
  adddatum2(obj1500, strlit1505, 3);
  addmethod2(obj1500, "register", &reader_ast_register_1506);
  addmethod2(obj1500, "register:=", &writer_ast_register_1506);
// Begin line 529
  setline(529);
// Begin line 555
  setline(555);
// Begin line 528
  setline(528);
// compilenode returning module_util
  Object call1507 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1507
// compilenode returning call1507
// OBJECT CONST DEC line
  adddatum2(obj1500, call1507, 4);
  addmethod2(obj1500, "line", &reader_ast_line_1508);
  addmethod2(obj1500, "pretty", &meth_ast_pretty1509);
  set_type(obj1500, 26);
// compilenode returning obj1500
  return obj1500;
}
Object meth_ast_apply1558(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_spc = closure[0];
  Object self = *closure[1];
// Begin line 551
  setline(551);
// Begin line 550
  setline(550);
// compilenode returning *var_spc
  if (strlit1559 == NULL) {
    strlit1559 = alloc_String("  ");
  }
// compilenode returning strlit1559
  params[0] = strlit1559;
  Object opresult1561 = callmethod(*var_spc, "++", 1, params);
// compilenode returning opresult1561
  *var_spc = opresult1561;
  if (opresult1561 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_ast_pretty1549(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_depth = alloc_var();
  *var_depth = args[0];
  Object params[1];
  Object *var_spc = alloc_var();
  *var_spc = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 549
  setline(549);
// Begin line 548
  setline(548);
  if (strlit1550 == NULL) {
    strlit1550 = alloc_String("");
  }
// compilenode returning strlit1550
  var_spc = alloc_var();
  *var_spc = strlit1550;
  if (strlit1550 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 551
  setline(551);
// Begin line 552
  setline(552);
// Begin line 549
  setline(549);
  Object num1552 = alloc_Float64(0.0);
// compilenode returning num1552
// compilenode returning *var_depth
  params[0] = *var_depth;
  Object opresult1554 = callmethod(num1552, "..", 1, params);
// compilenode returning opresult1554
// Begin line 551
  setline(551);
// Begin line 555
  setline(555);
  Object obj1556 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1556, self, 0);
  addmethod2(obj1556, "outer", &reader_ast_outer_1557);
  adddatum2(obj1556, self, 0);
  block_savedest(obj1556);
  Object **closure1558 = createclosure(2);
  addtoclosure(closure1558, var_spc);
  Object *selfpp1563 = alloc_var();
  *selfpp1563 = self;
  addtoclosure(closure1558, selfpp1563);
  struct UserObject *uo1558 = (struct UserObject*)obj1556;
  uo1558->data[1] = (Object)closure1558;
  addmethod2(obj1556, "apply", &meth_ast_apply1558);
  set_type(obj1556, 0);
// compilenode returning obj1556
  setclassname(obj1556, "Block<ast:1555>");
// compilenode returning obj1556
  params[0] = opresult1554;
  Object iter1551 = callmethod(opresult1554, "iter", 1, params);
  while(1) {
    Object cond1551 = callmethod(iter1551, "havemore", 0, NULL);
    if (!istrue(cond1551)) break;
    params[0] = callmethod(iter1551, "next", 0, NULL);
    callmethod(obj1556, "apply", 1, params);
  }
// compilenode returning opresult1554
// Begin line 553
  setline(553);
// Begin line 552
  setline(552);
  if (strlit1564 == NULL) {
    strlit1564 = alloc_String("Return");
  }
// compilenode returning strlit1564
  var_s = alloc_var();
  *var_s = strlit1564;
  if (strlit1564 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 554
  setline(554);
// Begin line 553
  setline(553);
// compilenode returning *var_s
  if (strlit1565 == NULL) {
    strlit1565 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1565
  params[0] = strlit1565;
  Object opresult1567 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1567
  *var_s = opresult1567;
  if (opresult1567 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 554
  setline(554);
// Begin line 555
  setline(555);
// Begin line 554
  setline(554);
// compilenode returning *var_s
// compilenode returning *var_spc
  params[0] = *var_spc;
  Object opresult1570 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult1570
// compilenode returning *var_depth
  Object num1571 = alloc_Float64(1.0);
// compilenode returning num1571
  params[0] = num1571;
  Object sum1573 = callmethod(*var_depth, "+", 1, params);
// compilenode returning sum1573
// Begin line 555
  setline(555);
// Begin line 554
  setline(554);
// compilenode returning self
  Object call1574 = callmethod(self, "value",
    0, params);
// compilenode returning call1574
// compilenode returning call1574
  params[0] = sum1573;
  Object call1575 = callmethod(call1574, "pretty",
    1, params);
// compilenode returning call1575
  params[0] = call1575;
  Object opresult1577 = callmethod(opresult1570, "++", 1, params);
// compilenode returning opresult1577
  *var_s = opresult1577;
  if (opresult1577 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 555
  setline(555);
// compilenode returning *var_s
  return *var_s;
}
Object meth_ast_astreturn1539(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[24];
  Object *var_expr = alloc_var();
  *var_expr = args[0];
  Object params[1];
  Object obj1540 = alloc_obj2(6,6);
// OBJECT OUTER DEC outer
  adddatum2(obj1540, self, 0);
  addmethod2(obj1540, "outer", &reader_ast_outer_1541);
  adddatum2(obj1540, self, 0);
// Begin line 543
  setline(543);
  if (strlit1542 == NULL) {
    strlit1542 = alloc_String("return");
  }
// compilenode returning strlit1542
// OBJECT CONST DEC kind
  adddatum2(obj1540, strlit1542, 1);
  addmethod2(obj1540, "kind", &reader_ast_kind_1543);
// Begin line 544
  setline(544);
// compilenode returning *var_expr
// OBJECT CONST DEC value
  adddatum2(obj1540, *var_expr, 2);
  addmethod2(obj1540, "value", &reader_ast_value_1544);
// Begin line 545
  setline(545);
  if (strlit1545 == NULL) {
    strlit1545 = alloc_String("");
  }
// compilenode returning strlit1545
// OBJECT VAR DEC register
  adddatum2(obj1540, strlit1545, 3);
  addmethod2(obj1540, "register", &reader_ast_register_1546);
  addmethod2(obj1540, "register:=", &writer_ast_register_1546);
// Begin line 547
  setline(547);
// Begin line 555
  setline(555);
// Begin line 546
  setline(546);
// compilenode returning module_util
  Object call1547 = callmethod(module_util, "linenum",
    0, params);
// compilenode returning call1547
// compilenode returning call1547
// OBJECT CONST DEC line
  adddatum2(obj1540, call1547, 4);
  addmethod2(obj1540, "line", &reader_ast_line_1548);
  addmethod2(obj1540, "pretty", &meth_ast_pretty1549);
  set_type(obj1540, 27);
// compilenode returning obj1540
  return obj1540;
}
Object module_ast_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<ast>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_kwyj1 = alloc_var();
  *var_kwyj1 = undefined;
  Object *var_kwyj2 = alloc_var();
  *var_kwyj2 = undefined;
// Begin line 2
  setline(2);
// Begin line 1
  setline(1);
  Object num0 = alloc_Float64(1.0);
// compilenode returning num0
  var_kwyj1 = alloc_var();
  *var_kwyj1 = num0;
  if (num0 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 3
  setline(3);
// Begin line 2
  setline(2);
  Object num1 = alloc_Float64(2.0);
// compilenode returning num1
  var_kwyj2 = alloc_var();
  *var_kwyj2 = num1;
  if (num1 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 22
  setline(22);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 39
  setline(39);
  addmethod2(self, "astfor", &meth_ast_astfor3);
// compilenode returning 
// Begin line 62
  setline(62);
  addmethod2(self, "astwhile", &meth_ast_astwhile66);
// compilenode returning 
// Begin line 91
  setline(91);
  addmethod2(self, "astif", &meth_ast_astif132);
// compilenode returning 
// Begin line 119
  setline(119);
  addmethod2(self, "astblock", &meth_ast_astblock228);
// compilenode returning 
// Begin line 148
  setline(148);
  addmethod2(self, "astmethodtype", &meth_ast_astmethodtype313);
// compilenode returning 
// Begin line 187
  setline(187);
  addmethod2(self, "asttype", &meth_ast_asttype432);
// compilenode returning 
// Begin line 220
  setline(220);
  addmethod2(self, "astmethod", &meth_ast_astmethod600);
// compilenode returning 
// Begin line 244
  setline(244);
  addmethod2(self, "astcall", &meth_ast_astcall706);
// compilenode returning 
// Begin line 275
  setline(275);
  addmethod2(self, "astclass", &meth_ast_astclass784);
// compilenode returning 
// Begin line 302
  setline(302);
  addmethod2(self, "astobject", &meth_ast_astobject904);
// compilenode returning 
// Begin line 321
  setline(321);
  addmethod2(self, "astarray", &meth_ast_astarray992);
// compilenode returning 
// Begin line 339
  setline(339);
  addmethod2(self, "astmember", &meth_ast_astmember1037);
// compilenode returning 
// Begin line 357
  setline(357);
  addmethod2(self, "astgeneric", &meth_ast_astgeneric1080);
// compilenode returning 
// Begin line 369
  setline(369);
  addmethod2(self, "astidentifier", &meth_ast_astidentifier1119);
// compilenode returning 
// Begin line 380
  setline(380);
  addmethod2(self, "astoctets", &meth_ast_astoctets1138);
// compilenode returning 
// Begin line 391
  setline(391);
  addmethod2(self, "aststring", &meth_ast_aststring1156);
// compilenode returning 
// Begin line 402
  setline(402);
  addmethod2(self, "astnum", &meth_ast_astnum1174);
// compilenode returning 
// Begin line 423
  setline(423);
  addmethod2(self, "astop", &meth_ast_astop1192);
// compilenode returning 
// Begin line 444
  setline(444);
  addmethod2(self, "astindex", &meth_ast_astindex1254);
// compilenode returning 
// Begin line 465
  setline(465);
  addmethod2(self, "astbind", &meth_ast_astbind1309);
// compilenode returning 
// Begin line 492
  setline(492);
  addmethod2(self, "astdefdec", &meth_ast_astdefdec1364);
// compilenode returning 
// Begin line 519
  setline(519);
  addmethod2(self, "astvardec", &meth_ast_astvardec1430);
// compilenode returning 
// Begin line 537
  setline(537);
  addmethod2(self, "astimport", &meth_ast_astimport1499);
// compilenode returning 
// Begin line 555
  setline(555);
  addmethod2(self, "astreturn", &meth_ast_astreturn1539);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_ast_init();
  gracelib_stats();
  return 0;
}
