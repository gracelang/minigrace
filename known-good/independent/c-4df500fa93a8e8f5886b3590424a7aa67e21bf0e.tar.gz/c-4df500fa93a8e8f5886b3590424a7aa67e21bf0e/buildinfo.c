#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
static Object strlit1;
static Object strlit3;
Object meth_buildinfo_gitrevision0(Object self, int nparams, Object *args, int32_t flags) {
  Object params[1];
  if (strlit1 == NULL) {
    strlit1 = alloc_String("4df500fa93a8e8f5886b3590424a7aa67e21bf0e");
  }
// compilenode returning strlit1
  return strlit1;
}
Object meth_buildinfo_gitgeneration2(Object self, int nparams, Object *args, int32_t flags) {
  Object params[1];
  if (strlit3 == NULL) {
    strlit3 = alloc_String("543");
  }
// compilenode returning strlit3
  return strlit3;
}
Object module_buildinfo_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<buildinfo>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  addmethod2(self, "gitrevision", &meth_buildinfo_gitrevision0);
// compilenode returning 
// Begin line 2
  setline(2);
  addmethod2(self, "gitgeneration", &meth_buildinfo_gitgeneration2);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_buildinfo_init();
  gracelib_stats();
  return 0;
}
