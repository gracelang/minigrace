#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_genc_outer_52(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_110(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_179(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_591(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_657(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_684(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_706(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_886(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_928(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_947(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_953(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_967(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1051(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1100(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1117(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1150(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1162(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1223(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1370(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1412(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1452(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1494(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1523(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_1565(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2012(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2047(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2103(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2162(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2334(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2622(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2631(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2778(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_2977(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_3047(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_3054(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_3069(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_3135(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_3142(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genc_outer_3226(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_sys_init();
Object module_sys;
Object module_ast_init();
Object module_ast;
Object module_util_init();
Object module_util;
Object module_buildinfo_init();
Object module_buildinfo;
Object module_subtype_init();
Object module_subtype;
static Object strlit14;
static Object strlit19;
static Object strlit20;
static Object strlit21;
static Object strlit22;
static Object strlit23;
static Object strlit39;
static Object strlit43;
static Object strlit48;
static Object strlit92;
static Object strlit95;
static Object strlit103;
static Object strlit113;
static Object strlit120;
static Object strlit125;
static Object strlit131;
static Object strlit148;
static Object strlit168;
static Object strlit171;
static Object strlit183;
static Object strlit186;
static Object strlit190;
static Object strlit193;
static Object strlit198;
static Object strlit212;
static Object strlit218;
static Object strlit222;
static Object strlit225;
static Object strlit229;
static Object strlit232;
static Object strlit237;
static Object strlit242;
static Object strlit245;
static Object strlit248;
static Object strlit252;
static Object strlit254;
static Object strlit256;
static Object strlit258;
static Object strlit261;
static Object strlit266;
static Object strlit271;
static Object strlit276;
static Object strlit281;
static Object strlit299;
static Object strlit303;
static Object strlit306;
static Object strlit311;
static Object strlit316;
static Object strlit320;
static Object strlit323;
static Object strlit328;
static Object strlit333;
static Object strlit336;
static Object strlit339;
static Object strlit343;
static Object strlit345;
static Object strlit348;
static Object strlit352;
static Object strlit354;
static Object strlit357;
static Object strlit362;
static Object strlit367;
static Object strlit372;
static Object strlit377;
static Object strlit382;
static Object strlit400;
static Object strlit404;
static Object strlit407;
static Object strlit412;
static Object strlit417;
static Object strlit421;
static Object strlit424;
static Object strlit429;
static Object strlit434;
static Object strlit437;
static Object strlit440;
static Object strlit444;
static Object strlit446;
static Object strlit449;
static Object strlit453;
static Object strlit455;
static Object strlit458;
static Object strlit463;
static Object strlit468;
static Object strlit473;
static Object strlit478;
static Object strlit482;
static Object strlit492;
static Object strlit495;
static Object strlit500;
static Object strlit505;
static Object strlit508;
static Object strlit511;
static Object strlit515;
static Object strlit517;
static Object strlit520;
static Object strlit524;
static Object strlit526;
static Object strlit528;
static Object strlit531;
static Object strlit536;
static Object strlit541;
static Object strlit546;
static Object strlit551;
static Object strlit561;
static Object strlit581;
static Object strlit595;
static Object strlit625;
static Object strlit628;
static Object strlit631;
static Object strlit636;
static Object strlit639;
static Object strlit646;
static Object strlit649;
static Object strlit661;
static Object strlit667;
static Object strlit673;
static Object strlit686;
static Object strlit689;
static Object strlit692;
static Object strlit697;
static Object strlit719;
static Object strlit732;
static Object strlit735;
static Object strlit740;
static Object strlit743;
static Object strlit746;
static Object strlit751;
static Object strlit766;
static Object strlit769;
static Object strlit773;
static Object strlit776;
static Object strlit781;
static Object strlit785;
static Object strlit787;
static Object strlit790;
static Object strlit795;
static Object strlit799;
static Object strlit802;
static Object strlit806;
static Object strlit809;
static Object strlit813;
static Object strlit816;
static Object strlit820;
static Object strlit849;
static Object strlit852;
static Object strlit857;
static Object strlit861;
static Object strlit864;
static Object strlit868;
static Object strlit871;
static Object strlit876;
static Object strlit881;
static Object strlit890;
static Object strlit894;
static Object strlit900;
static Object strlit909;
static Object strlit912;
static Object strlit916;
static Object strlit919;
static Object strlit933;
static Object strlit936;
static Object strlit940;
static Object strlit981;
static Object strlit983;
static Object strlit986;
static Object strlit992;
static Object strlit1003;
static Object strlit1006;
static Object strlit1009;
static Object strlit1013;
static Object strlit1015;
static Object strlit1018;
static Object strlit1021;
static Object strlit1025;
static Object strlit1027;
static Object strlit1030;
static Object strlit1034;
static Object strlit1037;
static Object strlit1040;
static Object strlit1057;
static Object strlit1060;
static Object strlit1064;
static Object strlit1067;
static Object strlit1072;
static Object strlit1077;
static Object strlit1080;
static Object strlit1085;
static Object strlit1106;
static Object strlit1109;
static Object strlit1120;
static Object strlit1123;
static Object strlit1126;
static Object strlit1130;
static Object strlit1133;
static Object strlit1138;
static Object strlit1165;
static Object strlit1182;
static Object strlit1185;
static Object strlit1191;
static Object strlit1196;
static Object strlit1200;
static Object strlit1203;
static Object strlit1207;
static Object strlit1210;
static Object strlit1216;
static Object strlit1226;
static Object strlit1229;
static Object strlit1232;
static Object strlit1235;
static Object strlit1239;
static Object strlit1242;
static Object strlit1246;
static Object strlit1249;
static Object strlit1254;
static Object strlit1262;
static Object strlit1265;
static Object strlit1270;
static Object strlit1275;
static Object strlit1278;
static Object strlit1281;
static Object strlit1284;
static Object strlit1289;
static Object strlit1293;
static Object strlit1296;
static Object strlit1301;
static Object strlit1306;
static Object strlit1310;
static Object strlit1313;
static Object strlit1319;
static Object strlit1324;
static Object strlit1335;
static Object strlit1338;
static Object strlit1342;
static Object strlit1346;
static Object strlit1349;
static Object strlit1354;
static Object strlit1358;
static Object strlit1361;
static Object strlit1365;
static Object strlit1374;
static Object strlit1378;
static Object strlit1384;
static Object strlit1393;
static Object strlit1396;
static Object strlit1400;
static Object strlit1403;
static Object strlit1417;
static Object strlit1419;
static Object strlit1430;
static Object strlit1433;
static Object strlit1437;
static Object strlit1440;
static Object strlit1444;
static Object strlit1445;
static Object strlit1446;
static Object strlit1447;
static Object strlit1456;
static Object strlit1460;
static Object strlit1466;
static Object strlit1475;
static Object strlit1478;
static Object strlit1482;
static Object strlit1485;
static Object strlit1499;
static Object strlit1502;
static Object strlit1507;
static Object strlit1511;
static Object strlit1527;
static Object strlit1531;
static Object strlit1537;
static Object strlit1546;
static Object strlit1549;
static Object strlit1553;
static Object strlit1556;
static Object strlit1570;
static Object strlit1573;
static Object strlit1578;
static Object strlit1582;
static Object strlit1584;
static Object strlit1592;
static Object strlit1595;
static Object strlit1598;
static Object strlit1601;
static Object strlit1604;
static Object strlit1608;
static Object strlit1620;
static Object strlit1625;
static Object strlit1628;
static Object strlit1634;
static Object strlit1635;
static Object strlit1636;
static Object strlit1639;
static Object strlit1649;
static Object strlit1652;
static Object strlit1657;
static Object strlit1661;
static Object strlit1664;
static Object strlit1668;
static Object strlit1677;
static Object strlit1681;
static Object strlit1694;
static Object strlit1697;
static Object strlit1708;
static Object strlit1714;
static Object strlit1731;
static Object strlit1733;
static Object strlit1736;
static Object strlit1741;
static Object strlit1745;
static Object strlit1748;
static Object strlit1752;
static Object strlit1754;
static Object strlit1768;
static Object strlit1770;
static Object strlit1773;
static Object strlit1777;
static Object strlit1780;
static Object strlit1785;
static Object strlit1790;
static Object strlit1793;
static Object strlit1797;
static Object strlit1799;
static Object strlit1806;
static Object strlit1809;
static Object strlit1813;
static Object strlit1816;
static Object strlit1821;
static Object strlit1825;
static Object strlit1844;
static Object strlit1848;
static Object strlit1854;
static Object strlit1860;
static Object strlit1866;
static Object strlit1871;
static Object strlit1874;
static Object strlit1877;
static Object strlit1881;
static Object strlit1884;
static Object strlit1888;
static Object strlit1891;
static Object strlit1895;
static Object strlit1898;
static Object strlit1900;
static Object strlit1903;
static Object strlit1907;
static Object strlit1910;
static Object strlit1915;
static Object strlit1920;
static Object strlit1926;
static Object strlit1929;
static Object strlit1947;
static Object strlit1951;
static Object strlit1954;
static Object strlit1959;
static Object strlit1964;
static Object strlit1967;
static Object strlit1970;
static Object strlit1974;
static Object strlit1977;
static Object strlit1980;
static Object strlit1983;
static Object strlit1989;
static Object strlit1995;
static Object strlit2005;
static Object strlit2030;
static Object strlit2049;
static Object strlit2052;
static Object strlit2057;
static Object strlit2066;
static Object strlit2069;
static Object strlit2074;
static Object strlit2079;
static Object strlit2083;
static Object strlit2087;
static Object strlit2091;
static Object strlit2105;
static Object strlit2108;
static Object strlit2113;
static Object strlit2122;
static Object strlit2125;
static Object strlit2130;
static Object strlit2134;
static Object strlit2138;
static Object strlit2142;
static Object strlit2151;
static Object strlit2171;
static Object strlit2183;
static Object strlit2186;
static Object strlit2190;
static Object strlit2193;
static Object strlit2198;
static Object strlit2202;
static Object strlit2204;
static Object strlit2207;
static Object strlit2211;
static Object strlit2220;
static Object strlit2232;
static Object strlit2235;
static Object strlit2238;
static Object strlit2244;
static Object strlit2247;
static Object strlit2252;
static Object strlit2256;
static Object strlit2259;
static Object strlit2264;
static Object strlit2268;
static Object strlit2271;
static Object strlit2275;
static Object strlit2278;
static Object strlit2283;
static Object strlit2288;
static Object strlit2291;
static Object strlit2295;
static Object strlit2298;
static Object strlit2306;
static Object strlit2312;
static Object strlit2315;
static Object strlit2319;
static Object strlit2322;
static Object strlit2326;
static Object strlit2337;
static Object strlit2345;
static Object strlit2349;
static Object strlit2352;
static Object strlit2357;
static Object strlit2361;
static Object strlit2376;
static Object strlit2380;
static Object strlit2383;
static Object strlit2389;
static Object strlit2393;
static Object strlit2396;
static Object strlit2409;
static Object strlit2412;
static Object strlit2416;
static Object strlit2419;
static Object strlit2425;
static Object strlit2429;
static Object strlit2431;
static Object strlit2434;
static Object strlit2438;
static Object strlit2448;
static Object strlit2454;
static Object strlit2460;
static Object strlit2466;
static Object strlit2472;
static Object strlit2480;
static Object strlit2484;
static Object strlit2488;
static Object strlit2498;
static Object strlit2503;
static Object strlit2506;
static Object strlit2509;
static Object strlit2515;
static Object strlit2525;
static Object strlit2531;
static Object strlit2537;
static Object strlit2543;
static Object strlit2549;
static Object strlit2552;
static Object strlit2560;
static Object strlit2566;
static Object strlit2572;
static Object strlit2578;
static Object strlit2584;
static Object strlit2590;
static Object strlit2596;
static Object strlit2602;
static Object strlit2608;
static Object strlit2614;
static Object strlit2633;
static Object strlit2636;
static Object strlit2641;
static Object strlit2650;
static Object strlit2653;
static Object strlit2659;
static Object strlit2663;
static Object strlit2674;
static Object strlit2679;
static Object strlit2690;
static Object strlit2695;
static Object strlit2701;
static Object strlit2704;
static Object strlit2707;
static Object strlit2713;
static Object strlit2724;
static Object strlit2729;
static Object strlit2737;
static Object strlit2748;
static Object strlit2752;
static Object strlit2770;
static Object strlit2773;
static Object strlit2782;
static Object strlit2789;
static Object strlit2796;
static Object strlit2801;
static Object strlit2804;
static Object strlit2810;
static Object strlit2818;
static Object strlit2822;
static Object strlit2825;
static Object strlit2829;
static Object strlit2836;
static Object strlit2844;
static Object strlit2848;
static Object strlit2859;
static Object strlit2865;
static Object strlit2872;
static Object strlit2879;
static Object strlit2882;
static Object strlit2888;
static Object strlit2896;
static Object strlit2899;
static Object strlit2909;
static Object strlit2912;
static Object strlit2917;
static Object strlit2918;
static Object strlit2919;
static Object strlit2924;
static Object strlit2928;
static Object strlit2930;
static Object strlit2932;
static Object strlit2936;
static Object strlit2940;
static Object strlit2942;
static Object strlit2944;
static Object strlit2946;
static Object strlit2949;
static Object strlit2953;
static Object strlit2955;
static Object strlit2958;
static Object strlit2961;
static Object strlit2964;
static Object strlit2968;
static Object strlit2970;
static Object strlit2981;
static Object strlit2985;
static Object strlit2994;
static Object strlit2997;
static Object strlit3001;
static Object strlit3004;
static Object strlit3010;
static Object strlit3016;
static Object strlit3029;
static Object strlit3032;
static Object strlit3036;
static Object strlit3039;
static Object strlit3059;
static Object strlit3062;
static Object strlit3075;
static Object strlit3077;
static Object strlit3079;
static Object strlit3081;
static Object strlit3084;
static Object strlit3087;
static Object strlit3090;
static Object strlit3093;
static Object strlit3097;
static Object strlit3099;
static Object strlit3101;
static Object strlit3103;
static Object strlit3105;
static Object strlit3107;
static Object strlit3109;
static Object strlit3111;
static Object strlit3113;
static Object strlit3115;
static Object strlit3117;
static Object strlit3120;
static Object strlit3124;
static Object strlit3126;
static Object strlit3128;
static Object strlit3130;
static Object strlit3147;
static Object strlit3150;
static Object strlit3153;
static Object strlit3156;
static Object strlit3161;
static Object strlit3168;
static Object strlit3171;
static Object strlit3176;
static Object strlit3178;
static Object strlit3179;
static Object strlit3180;
static Object strlit3184;
static Object strlit3186;
static Object strlit3190;
static Object strlit3192;
static Object strlit3195;
static Object strlit3200;
static Object strlit3205;
static Object strlit3208;
static Object strlit3211;
static Object strlit3219;
static Object strlit3228;
static Object strlit3238;
static Object strlit3241;
static Object strlit3243;
static Object strlit3246;
static Object strlit3249;
Object meth_genc_out28(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_output = closure[0];
// compilenode returning *var_s
// compilenode returning *var_output
  params[0] = *var_s;
  Object call29 = callmethod(*var_output, "push",
    1, params);
// compilenode returning call29
  return call29;
}
Object meth_genc_outprint30(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
// compilenode returning *var_s
// compilenode returning module_util
  params[0] = *var_s;
  Object call31 = callmethod(module_util, "outprint",
    1, params);
// compilenode returning call31
  return call31;
}
Object meth_genc_outswitchup32(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object params[1];
  Object *var_topOutput = closure[0];
  Object *var_output = closure[1];
// Begin line 47
  setline(47);
// compilenode returning *var_topOutput
  *var_output = *var_topOutput;
  if (*var_topOutput == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_outswitchdown34(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object params[1];
  Object *var_bottomOutput = closure[0];
  Object *var_output = closure[1];
// Begin line 50
  setline(50);
// compilenode returning *var_bottomOutput
  *var_output = *var_bottomOutput;
  if (*var_bottomOutput == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_log_verbose36(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
// compilenode returning *var_s
// compilenode returning module_util
  params[0] = *var_s;
  Object call37 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call37
  return call37;
}
Object meth_genc_beginblock38(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_bblock = closure[0];
// Begin line 56
  setline(56);
  if (strlit39 == NULL) {
    strlit39 = alloc_String("%");
  }
// compilenode returning strlit39
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult41 = callmethod(strlit39, "++", 1, params);
// compilenode returning opresult41
  *var_bblock = opresult41;
  if (opresult41 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 57
  setline(57);
// compilenode returning *var_s
  if (strlit43 == NULL) {
    strlit43 = alloc_String(":");
  }
// compilenode returning strlit43
  params[0] = strlit43;
  Object opresult45 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult45
// Begin line 58
  setline(58);
// compilenode returning self
  params[0] = opresult45;
  Object call46 = callmethod(self, "out",
    1, params);
// compilenode returning call46
  return call46;
}
Object meth_genc_apply53(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_ns = closure[0];
  Object self = *closure[1];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 63
  setline(63);
// Begin line 1035
  setline(1035);
// Begin line 62
  setline(62);
// compilenode returning *var_c
  Object call54 = callmethod(*var_c, "ord",
    0, params);
// compilenode returning call54
// compilenode returning call54
  *var_o = call54;
  if (call54 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 70
  setline(70);
// Begin line 71
  setline(71);
// Begin line 63
  setline(63);
// compilenode returning *var_o
  Object num56 = alloc_Float64(65.0);
// compilenode returning num56
  params[0] = num56;
  Object opresult58 = callmethod(*var_o, ">=", 1, params);
// compilenode returning opresult58
// Begin line 71
  setline(71);
// Begin line 63
  setline(63);
// compilenode returning *var_o
  Object num59 = alloc_Float64(90.0);
// compilenode returning num59
  params[0] = num59;
  Object opresult61 = callmethod(*var_o, "<=", 1, params);
// compilenode returning opresult61
  params[0] = opresult61;
  Object opresult63 = callmethod(opresult58, "&", 1, params);
// compilenode returning opresult63
// Begin line 71
  setline(71);
// Begin line 64
  setline(64);
// compilenode returning *var_o
  Object num64 = alloc_Float64(97.0);
// compilenode returning num64
  params[0] = num64;
  Object opresult66 = callmethod(*var_o, ">=", 1, params);
// compilenode returning opresult66
// Begin line 71
  setline(71);
// Begin line 64
  setline(64);
// compilenode returning *var_o
  Object num67 = alloc_Float64(122.0);
// compilenode returning num67
  params[0] = num67;
  Object opresult69 = callmethod(*var_o, "<=", 1, params);
// compilenode returning opresult69
  params[0] = opresult69;
  Object opresult71 = callmethod(opresult66, "&", 1, params);
// compilenode returning opresult71
  params[0] = opresult71;
  Object opresult73 = callmethod(opresult63, "|", 1, params);
// compilenode returning opresult73
// Begin line 71
  setline(71);
// Begin line 65
  setline(65);
// compilenode returning *var_o
  Object num74 = alloc_Float64(48.0);
// compilenode returning num74
  params[0] = num74;
  Object opresult76 = callmethod(*var_o, ">=", 1, params);
// compilenode returning opresult76
// Begin line 71
  setline(71);
// Begin line 65
  setline(65);
// compilenode returning *var_o
  Object num77 = alloc_Float64(57.0);
// compilenode returning num77
  params[0] = num77;
  Object opresult79 = callmethod(*var_o, "<=", 1, params);
// compilenode returning opresult79
  params[0] = opresult79;
  Object opresult81 = callmethod(opresult76, "&", 1, params);
// compilenode returning opresult81
  params[0] = opresult81;
  Object opresult83 = callmethod(opresult73, "|", 1, params);
// compilenode returning opresult83
// Begin line 71
  setline(71);
// Begin line 66
  setline(66);
// compilenode returning *var_o
  Object num84 = alloc_Float64(95.0);
// compilenode returning num84
  params[0] = num84;
  Object opresult86 = callmethod(*var_o, "==", 1, params);
// compilenode returning opresult86
  params[0] = opresult86;
  Object opresult88 = callmethod(opresult83, "|", 1, params);
// compilenode returning opresult88
  Object if55;
  if (istrue(opresult88)) {
// Begin line 68
  setline(68);
// Begin line 67
  setline(67);
// compilenode returning *var_ns
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult90 = callmethod(*var_ns, "++", 1, params);
// compilenode returning opresult90
  *var_ns = opresult90;
  if (opresult90 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if55 = nothing;
  } else {
// Begin line 70
  setline(70);
// Begin line 69
  setline(69);
// compilenode returning *var_ns
// Begin line 70
  setline(70);
// Begin line 69
  setline(69);
  if (strlit92 == NULL) {
    strlit92 = alloc_String("_");
  }
// compilenode returning strlit92
// compilenode returning *var_o
  params[0] = *var_o;
  Object opresult94 = callmethod(strlit92, "++", 1, params);
// compilenode returning opresult94
  if (strlit95 == NULL) {
    strlit95 = alloc_String("_");
  }
// compilenode returning strlit95
  params[0] = strlit95;
  Object opresult97 = callmethod(opresult94, "++", 1, params);
// compilenode returning opresult97
  params[0] = opresult97;
  Object opresult99 = callmethod(*var_ns, "++", 1, params);
// compilenode returning opresult99
  *var_ns = opresult99;
  if (opresult99 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if55 = nothing;
  }
// compilenode returning if55
  return if55;
}
Object meth_genc_escapeident47(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_ns = alloc_var();
  *var_ns = undefined;
// Begin line 61
  setline(61);
// Begin line 60
  setline(60);
  if (strlit48 == NULL) {
    strlit48 = alloc_String("");
  }
// compilenode returning strlit48
  var_ns = alloc_var();
  *var_ns = strlit48;
  if (strlit48 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 70
  setline(70);
// Begin line 61
  setline(61);
// compilenode returning *var_s
// Begin line 70
  setline(70);
// Begin line 1035
  setline(1035);
  Object obj51 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj51, self, 0);
  addmethod2(obj51, "outer", &reader_genc_outer_52);
  adddatum2(obj51, self, 0);
  block_savedest(obj51);
  Object **closure53 = createclosure(2);
  addtoclosure(closure53, var_ns);
  Object *selfpp101 = alloc_var();
  *selfpp101 = self;
  addtoclosure(closure53, selfpp101);
  struct UserObject *uo53 = (struct UserObject*)obj51;
  uo53->data[1] = (Object)closure53;
  addmethod2(obj51, "apply", &meth_genc_apply53);
  set_type(obj51, 0);
// compilenode returning obj51
  setclassname(obj51, "Block<genc:50>");
// compilenode returning obj51
  params[0] = *var_s;
  Object iter49 = callmethod(*var_s, "iter", 1, params);
  while(1) {
    Object cond49 = callmethod(iter49, "havemore", 0, NULL);
    if (!istrue(cond49)) break;
    params[0] = callmethod(iter49, "next", 0, NULL);
    callmethod(obj51, "apply", 1, params);
  }
// compilenode returning *var_s
// Begin line 72
  setline(72);
// compilenode returning *var_ns
  return *var_ns;
}
Object meth_genc_apply111(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_ls = closure[0];
  Object *var_ns = closure[1];
  Object *var_cd = closure[2];
  Object self = *closure[3];
// Begin line 90
  setline(90);
// Begin line 91
  setline(91);
// Begin line 79
  setline(79);
// compilenode returning *var_ls
// Begin line 91
  setline(91);
// Begin line 79
  setline(79);
// compilenode returning *var_c
  if (strlit113 == NULL) {
    strlit113 = alloc_String("\\");
  }
// compilenode returning strlit113
  params[0] = strlit113;
  Object opresult115 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult115
  params[0] = opresult115;
  Object opresult117 = callmethod(*var_ls, "&", 1, params);
// compilenode returning opresult117
  Object if112;
  if (istrue(opresult117)) {
// Begin line 81
  setline(81);
// Begin line 80
  setline(80);
  Object bool118 = alloc_Boolean(0);
// compilenode returning bool118
  *var_ls = bool118;
  if (bool118 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 82
  setline(82);
// Begin line 81
  setline(81);
// compilenode returning *var_ns
  if (strlit120 == NULL) {
    strlit120 = alloc_String("\\\\");
  }
// compilenode returning strlit120
  params[0] = strlit120;
  Object opresult122 = callmethod(*var_ns, "++", 1, params);
// compilenode returning opresult122
  *var_ns = opresult122;
  if (opresult122 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if112 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 84
  setline(84);
// Begin line 82
  setline(82);
// compilenode returning *var_c
  if (strlit125 == NULL) {
    strlit125 = alloc_String("\\");
  }
// compilenode returning strlit125
  params[0] = strlit125;
  Object opresult127 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult127
  Object if124;
  if (istrue(opresult127)) {
// Begin line 84
  setline(84);
// Begin line 83
  setline(83);
  Object bool128 = alloc_Boolean(1);
// compilenode returning bool128
  *var_ls = bool128;
  if (bool128 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if124 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 84
  setline(84);
// compilenode returning *var_ls
  Object if130;
  if (istrue(*var_ls)) {
// Begin line 86
  setline(86);
// Begin line 85
  setline(85);
// compilenode returning *var_ns
  if (strlit131 == NULL) {
    strlit131 = alloc_String("""\x22""""\x22""\\x");
  }
// compilenode returning strlit131
  params[0] = strlit131;
  Object opresult133 = callmethod(*var_ns, "++", 1, params);
// compilenode returning opresult133
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult135 = callmethod(opresult133, "++", 1, params);
// compilenode returning opresult135
  *var_ns = opresult135;
  if (opresult135 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 87
  setline(87);
// Begin line 86
  setline(86);
  Object bool137 = alloc_Boolean(0);
// compilenode returning bool137
  *var_ls = bool137;
  if (bool137 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 88
  setline(88);
// Begin line 87
  setline(87);
  Object num139 = alloc_Float64(2.0);
// compilenode returning num139
  *var_cd = num139;
  if (num139 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if130 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 89
  setline(89);
// compilenode returning *var_ns
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult142 = callmethod(*var_ns, "++", 1, params);
// compilenode returning opresult142
  *var_ns = opresult142;
  if (opresult142 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if130 = nothing;
  }
// compilenode returning if130
    if124 = if130;
  }
// compilenode returning if124
    if112 = if124;
  }
// compilenode returning if112
// Begin line 96
  setline(96);
// Begin line 97
  setline(97);
// Begin line 91
  setline(91);
// compilenode returning *var_cd
  Object num145 = alloc_Float64(1.0);
// compilenode returning num145
  params[0] = num145;
  Object opresult147 = callmethod(*var_cd, "==", 1, params);
// compilenode returning opresult147
  Object if144;
  if (istrue(opresult147)) {
// Begin line 93
  setline(93);
// Begin line 92
  setline(92);
// compilenode returning *var_ns
  if (strlit148 == NULL) {
    strlit148 = alloc_String("""\x22""""\x22""");
  }
// compilenode returning strlit148
  params[0] = strlit148;
  Object opresult150 = callmethod(*var_ns, "++", 1, params);
// compilenode returning opresult150
  *var_ns = opresult150;
  if (opresult150 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 94
  setline(94);
// Begin line 93
  setline(93);
  Object num152 = alloc_Float64(0.0);
// compilenode returning num152
  *var_cd = num152;
  if (num152 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if144 = nothing;
  } else {
// Begin line 96
  setline(96);
// Begin line 97
  setline(97);
// Begin line 94
  setline(94);
// compilenode returning *var_cd
  Object num155 = alloc_Float64(0.0);
// compilenode returning num155
  params[0] = num155;
  Object opresult157 = callmethod(*var_cd, ">", 1, params);
// compilenode returning opresult157
  Object if154;
  if (istrue(opresult157)) {
// Begin line 96
  setline(96);
// Begin line 95
  setline(95);
// compilenode returning *var_cd
  Object num158 = alloc_Float64(1.0);
// compilenode returning num158
  params[0] = num158;
  Object diff160 = callmethod(*var_cd, "-", 1, params);
// compilenode returning diff160
  *var_cd = diff160;
  if (diff160 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if154 = nothing;
  } else {
  }
// compilenode returning if154
    if144 = if154;
  }
// compilenode returning if144
  return if144;
}
Object meth_genc_escapestring2102(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_ns = alloc_var();
  *var_ns = undefined;
  Object *var_cd = alloc_var();
  *var_cd = undefined;
  Object *var_ls = alloc_var();
  *var_ls = undefined;
// Begin line 76
  setline(76);
// Begin line 75
  setline(75);
  if (strlit103 == NULL) {
    strlit103 = alloc_String("");
  }
// compilenode returning strlit103
  var_ns = alloc_var();
  *var_ns = strlit103;
  if (strlit103 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 77
  setline(77);
// Begin line 76
  setline(76);
  Object num104 = alloc_Float64(0.0);
// compilenode returning num104
  var_cd = alloc_var();
  *var_cd = num104;
  if (num104 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 78
  setline(78);
// Begin line 77
  setline(77);
  Object bool105 = alloc_Boolean(0);
// compilenode returning bool105
  var_ls = alloc_var();
  *var_ls = bool105;
  if (bool105 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 96
  setline(96);
// Begin line 78
  setline(78);
// Begin line 1035
  setline(1035);
// Begin line 78
  setline(78);
// compilenode returning *var_s
  Object call107 = callmethod(*var_s, "_escape",
    0, params);
// compilenode returning call107
// compilenode returning call107
// Begin line 96
  setline(96);
// Begin line 1035
  setline(1035);
  Object obj109 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj109, self, 0);
  addmethod2(obj109, "outer", &reader_genc_outer_110);
  adddatum2(obj109, self, 0);
  block_savedest(obj109);
  Object **closure111 = createclosure(4);
  addtoclosure(closure111, var_ls);
  addtoclosure(closure111, var_ns);
  addtoclosure(closure111, var_cd);
  Object *selfpp162 = alloc_var();
  *selfpp162 = self;
  addtoclosure(closure111, selfpp162);
  struct UserObject *uo111 = (struct UserObject*)obj109;
  uo111->data[1] = (Object)closure111;
  addmethod2(obj109, "apply", &meth_genc_apply111);
  set_type(obj109, 0);
// compilenode returning obj109
  setclassname(obj109, "Block<genc:108>");
// compilenode returning obj109
  params[0] = call107;
  Object iter106 = callmethod(call107, "iter", 1, params);
  while(1) {
    Object cond106 = callmethod(iter106, "havemore", 0, NULL);
    if (!istrue(cond106)) break;
    params[0] = callmethod(iter106, "next", 0, NULL);
    callmethod(obj109, "apply", 1, params);
  }
// compilenode returning call107
// Begin line 98
  setline(98);
// compilenode returning *var_ns
  return *var_ns;
}
Object meth_genc_apply180(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_a = alloc_var();
  *var_a = args[0];
  Object params[1];
  Object *var_r = closure[0];
  Object *var_myc = closure[1];
  Object self = *closure[2];
// Begin line 106
  setline(106);
// compilenode returning *var_a
// Begin line 107
  setline(107);
// compilenode returning self
  params[0] = *var_a;
  Object call181 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call181
  *var_r = call181;
  if (call181 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit183 == NULL) {
    strlit183 = alloc_String("  params[0] = ");
  }
// compilenode returning strlit183
// compilenode returning *var_r
  params[0] = *var_r;
  Object opresult185 = callmethod(strlit183, "++", 1, params);
// compilenode returning opresult185
  if (strlit186 == NULL) {
    strlit186 = alloc_String(";");
  }
// compilenode returning strlit186
  params[0] = strlit186;
  Object opresult188 = callmethod(opresult185, "++", 1, params);
// compilenode returning opresult188
// Begin line 108
  setline(108);
// compilenode returning self
  params[0] = opresult188;
  Object call189 = callmethod(self, "out",
    1, params);
// compilenode returning call189
  if (strlit190 == NULL) {
    strlit190 = alloc_String("  callmethod(array");
  }
// compilenode returning strlit190
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult192 = callmethod(strlit190, "++", 1, params);
// compilenode returning opresult192
  if (strlit193 == NULL) {
    strlit193 = alloc_String(", ""\x22""push""\x22"", 1, params);");
  }
// compilenode returning strlit193
  params[0] = strlit193;
  Object opresult195 = callmethod(opresult192, "++", 1, params);
// compilenode returning opresult195
// Begin line 109
  setline(109);
// compilenode returning self
  params[0] = opresult195;
  Object call196 = callmethod(self, "out",
    1, params);
// compilenode returning call196
  return call196;
}
Object meth_genc_compilearray163(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 102
  setline(102);
// Begin line 101
  setline(101);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 103
  setline(103);
// Begin line 102
  setline(102);
// compilenode returning *var_auto_count
  Object num164 = alloc_Float64(1.0);
// compilenode returning num164
  params[0] = num164;
  Object sum166 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum166
  *var_auto_count = sum166;
  if (sum166 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 104
  setline(104);
  var_r = alloc_var();
  *var_r = undefined;
// compilenode returning nothing
  if (strlit168 == NULL) {
    strlit168 = alloc_String("  Object array");
  }
// compilenode returning strlit168
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult170 = callmethod(strlit168, "++", 1, params);
// compilenode returning opresult170
  if (strlit171 == NULL) {
    strlit171 = alloc_String(" = alloc_List();");
  }
// compilenode returning strlit171
  params[0] = strlit171;
  Object opresult173 = callmethod(opresult170, "++", 1, params);
// compilenode returning opresult173
// Begin line 105
  setline(105);
// compilenode returning self
  params[0] = opresult173;
  Object call174 = callmethod(self, "out",
    1, params);
// compilenode returning call174
// Begin line 108
  setline(108);
// Begin line 110
  setline(110);
// Begin line 1035
  setline(1035);
// Begin line 105
  setline(105);
// compilenode returning *var_o
  Object call176 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call176
// compilenode returning call176
// Begin line 108
  setline(108);
// Begin line 1035
  setline(1035);
  Object obj178 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj178, self, 0);
  addmethod2(obj178, "outer", &reader_genc_outer_179);
  adddatum2(obj178, self, 0);
  block_savedest(obj178);
  Object **closure180 = createclosure(3);
  addtoclosure(closure180, var_r);
  addtoclosure(closure180, var_myc);
  Object *selfpp197 = alloc_var();
  *selfpp197 = self;
  addtoclosure(closure180, selfpp197);
  struct UserObject *uo180 = (struct UserObject*)obj178;
  uo180->data[1] = (Object)closure180;
  addmethod2(obj178, "apply", &meth_genc_apply180);
  set_type(obj178, 0);
// compilenode returning obj178
  setclassname(obj178, "Block<genc:177>");
// compilenode returning obj178
  params[0] = call176;
  Object iter175 = callmethod(call176, "iter", 1, params);
  while(1) {
    Object cond175 = callmethod(iter175, "havemore", 0, NULL);
    if (!istrue(cond175)) break;
    params[0] = callmethod(iter175, "next", 0, NULL);
    callmethod(obj178, "apply", 1, params);
  }
// compilenode returning call176
// Begin line 111
  setline(111);
// Begin line 1035
  setline(1035);
// Begin line 111
  setline(111);
// Begin line 110
  setline(110);
  if (strlit198 == NULL) {
    strlit198 = alloc_String("array");
  }
// compilenode returning strlit198
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult200 = callmethod(strlit198, "++", 1, params);
// compilenode returning opresult200
// compilenode returning *var_o
  params[0] = opresult200;
  Object call201 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call201
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilemember202(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_c = alloc_var();
  *var_c = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 115
  setline(115);
  Object array203 = alloc_List();
// compilenode returning array203
  var_l = alloc_var();
  *var_l = array203;
  if (array203 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_o
// compilenode returning *var_l
// compilenode returning module_ast
  params[0] = *var_o;
  params[1] = *var_l;
  Object call204 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call204
  var_c = alloc_var();
  *var_c = call204;
  if (call204 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 116
  setline(116);
// compilenode returning *var_c
// Begin line 117
  setline(117);
// compilenode returning self
  params[0] = *var_c;
  Object call205 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call205
  var_r = alloc_var();
  *var_r = call205;
  if (call205 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 118
  setline(118);
// Begin line 1035
  setline(1035);
// Begin line 117
  setline(117);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call206 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call206
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileobjouter207(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object *var_selfr = alloc_var();
  *var_selfr = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_escmodname = closure[1];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_enm = alloc_var();
  *var_enm = undefined;
// Begin line 121
  setline(121);
// Begin line 120
  setline(120);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 122
  setline(122);
// Begin line 121
  setline(121);
// compilenode returning *var_auto_count
  Object num208 = alloc_Float64(1.0);
// compilenode returning num208
  params[0] = num208;
  Object sum210 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum210
  *var_auto_count = sum210;
  if (sum210 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 123
  setline(123);
// Begin line 122
  setline(122);
  if (strlit212 == NULL) {
    strlit212 = alloc_String("outer");
  }
// compilenode returning strlit212
  var_nm = alloc_var();
  *var_nm = strlit212;
  if (strlit212 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 123
  setline(123);
// compilenode returning *var_nm
  Object call213 = gracelib_length(*var_nm);
// compilenode returning call213
  Object num214 = alloc_Float64(1.0);
// compilenode returning num214
  params[0] = num214;
  Object sum216 = callmethod(call213, "+", 1, params);
// compilenode returning sum216
  var_len = alloc_var();
  *var_len = sum216;
  if (sum216 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 124
  setline(124);
// compilenode returning *var_nm
// Begin line 125
  setline(125);
// compilenode returning self
  params[0] = *var_nm;
  Object call217 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call217
  var_enm = alloc_var();
  *var_enm = call217;
  if (call217 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit218 == NULL) {
    strlit218 = alloc_String("// OBJECT OUTER DEC ");
  }
// compilenode returning strlit218
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult220 = callmethod(strlit218, "++", 1, params);
// compilenode returning opresult220
// Begin line 126
  setline(126);
// compilenode returning self
  params[0] = opresult220;
  Object call221 = callmethod(self, "out",
    1, params);
// compilenode returning call221
  if (strlit222 == NULL) {
    strlit222 = alloc_String("  adddatum2(");
  }
// compilenode returning strlit222
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult224 = callmethod(strlit222, "++", 1, params);
// compilenode returning opresult224
  if (strlit225 == NULL) {
    strlit225 = alloc_String(", self, 0);");
  }
// compilenode returning strlit225
  params[0] = strlit225;
  Object opresult227 = callmethod(opresult224, "++", 1, params);
// compilenode returning opresult227
// Begin line 127
  setline(127);
// compilenode returning self
  params[0] = opresult227;
  Object call228 = callmethod(self, "out",
    1, params);
// compilenode returning call228
// Begin line 129
  setline(129);
// Begin line 127
  setline(127);
  if (strlit229 == NULL) {
    strlit229 = alloc_String("Object reader_");
  }
// compilenode returning strlit229
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult231 = callmethod(strlit229, "++", 1, params);
// compilenode returning opresult231
  if (strlit232 == NULL) {
    strlit232 = alloc_String("_");
  }
// compilenode returning strlit232
  params[0] = strlit232;
  Object opresult234 = callmethod(opresult231, "++", 1, params);
// compilenode returning opresult234
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult236 = callmethod(opresult234, "++", 1, params);
// compilenode returning opresult236
  if (strlit237 == NULL) {
    strlit237 = alloc_String("_");
  }
// compilenode returning strlit237
  params[0] = strlit237;
  Object opresult239 = callmethod(opresult236, "++", 1, params);
// compilenode returning opresult239
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult241 = callmethod(opresult239, "++", 1, params);
// compilenode returning opresult241
  if (strlit242 == NULL) {
    strlit242 = alloc_String("");
  }
// compilenode returning strlit242
  params[0] = strlit242;
  Object opresult244 = callmethod(opresult241, "++", 1, params);
// compilenode returning opresult244
// Begin line 128
  setline(128);
  if (strlit245 == NULL) {
    strlit245 = alloc_String("(Object self, int nparams, ");
  }
// compilenode returning strlit245
  params[0] = strlit245;
  Object opresult247 = callmethod(opresult244, "++", 1, params);
// compilenode returning opresult247
// Begin line 129
  setline(129);
  if (strlit248 == NULL) {
    strlit248 = alloc_String("Object* args, int flags) {");
  }
// compilenode returning strlit248
  params[0] = strlit248;
  Object opresult250 = callmethod(opresult247, "++", 1, params);
// compilenode returning opresult250
// Begin line 130
  setline(130);
// compilenode returning self
  params[0] = opresult250;
  Object call251 = callmethod(self, "outprint",
    1, params);
// compilenode returning call251
  if (strlit252 == NULL) {
    strlit252 = alloc_String("  struct UserObject *uo = (struct UserObject*)self;");
  }
// compilenode returning strlit252
// Begin line 131
  setline(131);
// compilenode returning self
  params[0] = strlit252;
  Object call253 = callmethod(self, "outprint",
    1, params);
// compilenode returning call253
  if (strlit254 == NULL) {
    strlit254 = alloc_String("  return uo->data[0];");
  }
// compilenode returning strlit254
// Begin line 132
  setline(132);
// compilenode returning self
  params[0] = strlit254;
  Object call255 = callmethod(self, "outprint",
    1, params);
// compilenode returning call255
  if (strlit256 == NULL) {
    strlit256 = alloc_String("}");
  }
// compilenode returning strlit256
// Begin line 133
  setline(133);
// compilenode returning self
  params[0] = strlit256;
  Object call257 = callmethod(self, "outprint",
    1, params);
// compilenode returning call257
  if (strlit258 == NULL) {
    strlit258 = alloc_String("  addmethod2(");
  }
// compilenode returning strlit258
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult260 = callmethod(strlit258, "++", 1, params);
// compilenode returning opresult260
  if (strlit261 == NULL) {
    strlit261 = alloc_String(", ""\x22""outer""\x22"", &reader_");
  }
// compilenode returning strlit261
  params[0] = strlit261;
  Object opresult263 = callmethod(opresult260, "++", 1, params);
// compilenode returning opresult263
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult265 = callmethod(opresult263, "++", 1, params);
// compilenode returning opresult265
  if (strlit266 == NULL) {
    strlit266 = alloc_String("_");
  }
// compilenode returning strlit266
  params[0] = strlit266;
  Object opresult268 = callmethod(opresult265, "++", 1, params);
// compilenode returning opresult268
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult270 = callmethod(opresult268, "++", 1, params);
// compilenode returning opresult270
  if (strlit271 == NULL) {
    strlit271 = alloc_String("_");
  }
// compilenode returning strlit271
  params[0] = strlit271;
  Object opresult273 = callmethod(opresult270, "++", 1, params);
// compilenode returning opresult273
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult275 = callmethod(opresult273, "++", 1, params);
// compilenode returning opresult275
  if (strlit276 == NULL) {
    strlit276 = alloc_String(");");
  }
// compilenode returning strlit276
  params[0] = strlit276;
  Object opresult278 = callmethod(opresult275, "++", 1, params);
// compilenode returning opresult278
// Begin line 134
  setline(134);
// compilenode returning self
  params[0] = opresult278;
  Object call279 = callmethod(self, "out",
    1, params);
// compilenode returning call279
  return call279;
}
Object meth_genc_compileobjdefdec280(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfr = alloc_var();
  *var_selfr = args[1];
  Object *var_pos = alloc_var();
  *var_pos = args[2];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_escmodname = closure[1];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_enm = alloc_var();
  *var_enm = undefined;
  Object *var_inm = alloc_var();
  *var_inm = undefined;
// Begin line 137
  setline(137);
// Begin line 136
  setline(136);
  if (strlit281 == NULL) {
    strlit281 = alloc_String("undefined");
  }
// compilenode returning strlit281
  var_val = alloc_var();
  *var_val = strlit281;
  if (strlit281 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 138
  setline(138);
// Begin line 140
  setline(140);
// Begin line 1035
  setline(1035);
// Begin line 137
  setline(137);
// compilenode returning *var_o
  Object call283 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call283
// compilenode returning call283
  Object if282;
  if (istrue(call283)) {
// Begin line 138
  setline(138);
// Begin line 1035
  setline(1035);
// Begin line 138
  setline(138);
// compilenode returning *var_o
  Object call284 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call284
// compilenode returning call284
// Begin line 139
  setline(139);
// compilenode returning self
  params[0] = call284;
  Object call285 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call285
  *var_val = call285;
  if (call285 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if282 = nothing;
  } else {
  }
// compilenode returning if282
// Begin line 141
  setline(141);
// Begin line 140
  setline(140);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 142
  setline(142);
// Begin line 141
  setline(141);
// compilenode returning *var_auto_count
  Object num287 = alloc_Float64(1.0);
// compilenode returning num287
  params[0] = num287;
  Object sum289 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum289
  *var_auto_count = sum289;
  if (sum289 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 143
  setline(143);
// Begin line 1035
  setline(1035);
// Begin line 143
  setline(143);
// Begin line 1035
  setline(1035);
// Begin line 142
  setline(142);
// compilenode returning *var_o
  Object call291 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call291
// compilenode returning call291
  Object call292 = callmethod(call291, "value",
    0, params);
// compilenode returning call292
// compilenode returning call292
  var_nm = alloc_var();
  *var_nm = call292;
  if (call292 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 143
  setline(143);
// compilenode returning *var_nm
  Object call293 = gracelib_length(*var_nm);
// compilenode returning call293
  Object num294 = alloc_Float64(1.0);
// compilenode returning num294
  params[0] = num294;
  Object sum296 = callmethod(call293, "+", 1, params);
// compilenode returning sum296
  var_len = alloc_var();
  *var_len = sum296;
  if (sum296 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 144
  setline(144);
// compilenode returning *var_nm
// Begin line 145
  setline(145);
// compilenode returning self
  params[0] = *var_nm;
  Object call297 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call297
  var_enm = alloc_var();
  *var_enm = call297;
  if (call297 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_nm
// Begin line 146
  setline(146);
// compilenode returning self
  params[0] = *var_nm;
  Object call298 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call298
  var_inm = alloc_var();
  *var_inm = call298;
  if (call298 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit299 == NULL) {
    strlit299 = alloc_String("// OBJECT CONST DEC ");
  }
// compilenode returning strlit299
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult301 = callmethod(strlit299, "++", 1, params);
// compilenode returning opresult301
// Begin line 147
  setline(147);
// compilenode returning self
  params[0] = opresult301;
  Object call302 = callmethod(self, "out",
    1, params);
// compilenode returning call302
  if (strlit303 == NULL) {
    strlit303 = alloc_String("  adddatum2(");
  }
// compilenode returning strlit303
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult305 = callmethod(strlit303, "++", 1, params);
// compilenode returning opresult305
  if (strlit306 == NULL) {
    strlit306 = alloc_String(", ");
  }
// compilenode returning strlit306
  params[0] = strlit306;
  Object opresult308 = callmethod(opresult305, "++", 1, params);
// compilenode returning opresult308
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult310 = callmethod(opresult308, "++", 1, params);
// compilenode returning opresult310
  if (strlit311 == NULL) {
    strlit311 = alloc_String(", ");
  }
// compilenode returning strlit311
  params[0] = strlit311;
  Object opresult313 = callmethod(opresult310, "++", 1, params);
// compilenode returning opresult313
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult315 = callmethod(opresult313, "++", 1, params);
// compilenode returning opresult315
  if (strlit316 == NULL) {
    strlit316 = alloc_String(");");
  }
// compilenode returning strlit316
  params[0] = strlit316;
  Object opresult318 = callmethod(opresult315, "++", 1, params);
// compilenode returning opresult318
// Begin line 148
  setline(148);
// compilenode returning self
  params[0] = opresult318;
  Object call319 = callmethod(self, "out",
    1, params);
// compilenode returning call319
// Begin line 150
  setline(150);
// Begin line 148
  setline(148);
  if (strlit320 == NULL) {
    strlit320 = alloc_String("Object reader_");
  }
// compilenode returning strlit320
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult322 = callmethod(strlit320, "++", 1, params);
// compilenode returning opresult322
  if (strlit323 == NULL) {
    strlit323 = alloc_String("_");
  }
// compilenode returning strlit323
  params[0] = strlit323;
  Object opresult325 = callmethod(opresult322, "++", 1, params);
// compilenode returning opresult325
// compilenode returning *var_inm
  params[0] = *var_inm;
  Object opresult327 = callmethod(opresult325, "++", 1, params);
// compilenode returning opresult327
  if (strlit328 == NULL) {
    strlit328 = alloc_String("_");
  }
// compilenode returning strlit328
  params[0] = strlit328;
  Object opresult330 = callmethod(opresult327, "++", 1, params);
// compilenode returning opresult330
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult332 = callmethod(opresult330, "++", 1, params);
// compilenode returning opresult332
  if (strlit333 == NULL) {
    strlit333 = alloc_String("");
  }
// compilenode returning strlit333
  params[0] = strlit333;
  Object opresult335 = callmethod(opresult332, "++", 1, params);
// compilenode returning opresult335
// Begin line 149
  setline(149);
  if (strlit336 == NULL) {
    strlit336 = alloc_String("(Object self, int nparams, ");
  }
// compilenode returning strlit336
  params[0] = strlit336;
  Object opresult338 = callmethod(opresult335, "++", 1, params);
// compilenode returning opresult338
// Begin line 150
  setline(150);
  if (strlit339 == NULL) {
    strlit339 = alloc_String("Object* args, int flags) {");
  }
// compilenode returning strlit339
  params[0] = strlit339;
  Object opresult341 = callmethod(opresult338, "++", 1, params);
// compilenode returning opresult341
// Begin line 151
  setline(151);
// compilenode returning self
  params[0] = opresult341;
  Object call342 = callmethod(self, "outprint",
    1, params);
// compilenode returning call342
  if (strlit343 == NULL) {
    strlit343 = alloc_String("  struct UserObject *uo = (struct UserObject *)self;");
  }
// compilenode returning strlit343
// Begin line 152
  setline(152);
// compilenode returning self
  params[0] = strlit343;
  Object call344 = callmethod(self, "outprint",
    1, params);
// compilenode returning call344
  if (strlit345 == NULL) {
    strlit345 = alloc_String("  return uo->data[");
  }
// compilenode returning strlit345
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult347 = callmethod(strlit345, "++", 1, params);
// compilenode returning opresult347
  if (strlit348 == NULL) {
    strlit348 = alloc_String("];");
  }
// compilenode returning strlit348
  params[0] = strlit348;
  Object opresult350 = callmethod(opresult347, "++", 1, params);
// compilenode returning opresult350
// Begin line 153
  setline(153);
// compilenode returning self
  params[0] = opresult350;
  Object call351 = callmethod(self, "outprint",
    1, params);
// compilenode returning call351
  if (strlit352 == NULL) {
    strlit352 = alloc_String("}");
  }
// compilenode returning strlit352
// Begin line 154
  setline(154);
// compilenode returning self
  params[0] = strlit352;
  Object call353 = callmethod(self, "outprint",
    1, params);
// compilenode returning call353
  if (strlit354 == NULL) {
    strlit354 = alloc_String("  addmethod2(");
  }
// compilenode returning strlit354
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult356 = callmethod(strlit354, "++", 1, params);
// compilenode returning opresult356
  if (strlit357 == NULL) {
    strlit357 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit357
  params[0] = strlit357;
  Object opresult359 = callmethod(opresult356, "++", 1, params);
// compilenode returning opresult359
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult361 = callmethod(opresult359, "++", 1, params);
// compilenode returning opresult361
  if (strlit362 == NULL) {
    strlit362 = alloc_String("""\x22"", &reader_");
  }
// compilenode returning strlit362
  params[0] = strlit362;
  Object opresult364 = callmethod(opresult361, "++", 1, params);
// compilenode returning opresult364
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult366 = callmethod(opresult364, "++", 1, params);
// compilenode returning opresult366
  if (strlit367 == NULL) {
    strlit367 = alloc_String("_");
  }
// compilenode returning strlit367
  params[0] = strlit367;
  Object opresult369 = callmethod(opresult366, "++", 1, params);
// compilenode returning opresult369
// compilenode returning *var_inm
  params[0] = *var_inm;
  Object opresult371 = callmethod(opresult369, "++", 1, params);
// compilenode returning opresult371
  if (strlit372 == NULL) {
    strlit372 = alloc_String("_");
  }
// compilenode returning strlit372
  params[0] = strlit372;
  Object opresult374 = callmethod(opresult371, "++", 1, params);
// compilenode returning opresult374
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult376 = callmethod(opresult374, "++", 1, params);
// compilenode returning opresult376
  if (strlit377 == NULL) {
    strlit377 = alloc_String(");");
  }
// compilenode returning strlit377
  params[0] = strlit377;
  Object opresult379 = callmethod(opresult376, "++", 1, params);
// compilenode returning opresult379
// Begin line 155
  setline(155);
// compilenode returning self
  params[0] = opresult379;
  Object call380 = callmethod(self, "out",
    1, params);
// compilenode returning call380
  return call380;
}
Object meth_genc_compileobjvardec381(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfr = alloc_var();
  *var_selfr = args[1];
  Object *var_pos = alloc_var();
  *var_pos = args[2];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_escmodname = closure[1];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_enm = alloc_var();
  *var_enm = undefined;
  Object *var_inm = alloc_var();
  *var_inm = undefined;
  Object *var_nmw = alloc_var();
  *var_nmw = undefined;
// Begin line 158
  setline(158);
// Begin line 157
  setline(157);
  if (strlit382 == NULL) {
    strlit382 = alloc_String("undefined");
  }
// compilenode returning strlit382
  var_val = alloc_var();
  *var_val = strlit382;
  if (strlit382 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 159
  setline(159);
// Begin line 161
  setline(161);
// Begin line 1035
  setline(1035);
// Begin line 158
  setline(158);
// compilenode returning *var_o
  Object call384 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call384
// compilenode returning call384
  Object if383;
  if (istrue(call384)) {
// Begin line 159
  setline(159);
// Begin line 1035
  setline(1035);
// Begin line 159
  setline(159);
// compilenode returning *var_o
  Object call385 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call385
// compilenode returning call385
// Begin line 160
  setline(160);
// compilenode returning self
  params[0] = call385;
  Object call386 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call386
  *var_val = call386;
  if (call386 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if383 = nothing;
  } else {
  }
// compilenode returning if383
// Begin line 162
  setline(162);
// Begin line 161
  setline(161);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 163
  setline(163);
// Begin line 162
  setline(162);
// compilenode returning *var_auto_count
  Object num388 = alloc_Float64(1.0);
// compilenode returning num388
  params[0] = num388;
  Object sum390 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum390
  *var_auto_count = sum390;
  if (sum390 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 164
  setline(164);
// Begin line 1035
  setline(1035);
// Begin line 164
  setline(164);
// Begin line 1035
  setline(1035);
// Begin line 163
  setline(163);
// compilenode returning *var_o
  Object call392 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call392
// compilenode returning call392
  Object call393 = callmethod(call392, "value",
    0, params);
// compilenode returning call393
// compilenode returning call393
  var_nm = alloc_var();
  *var_nm = call393;
  if (call393 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 164
  setline(164);
// compilenode returning *var_nm
  Object call394 = gracelib_length(*var_nm);
// compilenode returning call394
  Object num395 = alloc_Float64(1.0);
// compilenode returning num395
  params[0] = num395;
  Object sum397 = callmethod(call394, "+", 1, params);
// compilenode returning sum397
  var_len = alloc_var();
  *var_len = sum397;
  if (sum397 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 165
  setline(165);
// compilenode returning *var_nm
// Begin line 166
  setline(166);
// compilenode returning self
  params[0] = *var_nm;
  Object call398 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call398
  var_enm = alloc_var();
  *var_enm = call398;
  if (call398 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_nm
// Begin line 167
  setline(167);
// compilenode returning self
  params[0] = *var_nm;
  Object call399 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call399
  var_inm = alloc_var();
  *var_inm = call399;
  if (call399 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit400 == NULL) {
    strlit400 = alloc_String("// OBJECT VAR DEC ");
  }
// compilenode returning strlit400
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult402 = callmethod(strlit400, "++", 1, params);
// compilenode returning opresult402
// Begin line 168
  setline(168);
// compilenode returning self
  params[0] = opresult402;
  Object call403 = callmethod(self, "out",
    1, params);
// compilenode returning call403
  if (strlit404 == NULL) {
    strlit404 = alloc_String("  adddatum2(");
  }
// compilenode returning strlit404
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult406 = callmethod(strlit404, "++", 1, params);
// compilenode returning opresult406
  if (strlit407 == NULL) {
    strlit407 = alloc_String(", ");
  }
// compilenode returning strlit407
  params[0] = strlit407;
  Object opresult409 = callmethod(opresult406, "++", 1, params);
// compilenode returning opresult409
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult411 = callmethod(opresult409, "++", 1, params);
// compilenode returning opresult411
  if (strlit412 == NULL) {
    strlit412 = alloc_String(", ");
  }
// compilenode returning strlit412
  params[0] = strlit412;
  Object opresult414 = callmethod(opresult411, "++", 1, params);
// compilenode returning opresult414
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult416 = callmethod(opresult414, "++", 1, params);
// compilenode returning opresult416
  if (strlit417 == NULL) {
    strlit417 = alloc_String(");");
  }
// compilenode returning strlit417
  params[0] = strlit417;
  Object opresult419 = callmethod(opresult416, "++", 1, params);
// compilenode returning opresult419
// Begin line 169
  setline(169);
// compilenode returning self
  params[0] = opresult419;
  Object call420 = callmethod(self, "out",
    1, params);
// compilenode returning call420
// Begin line 171
  setline(171);
// Begin line 169
  setline(169);
  if (strlit421 == NULL) {
    strlit421 = alloc_String("Object reader_");
  }
// compilenode returning strlit421
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult423 = callmethod(strlit421, "++", 1, params);
// compilenode returning opresult423
  if (strlit424 == NULL) {
    strlit424 = alloc_String("_");
  }
// compilenode returning strlit424
  params[0] = strlit424;
  Object opresult426 = callmethod(opresult423, "++", 1, params);
// compilenode returning opresult426
// compilenode returning *var_inm
  params[0] = *var_inm;
  Object opresult428 = callmethod(opresult426, "++", 1, params);
// compilenode returning opresult428
  if (strlit429 == NULL) {
    strlit429 = alloc_String("_");
  }
// compilenode returning strlit429
  params[0] = strlit429;
  Object opresult431 = callmethod(opresult428, "++", 1, params);
// compilenode returning opresult431
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult433 = callmethod(opresult431, "++", 1, params);
// compilenode returning opresult433
  if (strlit434 == NULL) {
    strlit434 = alloc_String("");
  }
// compilenode returning strlit434
  params[0] = strlit434;
  Object opresult436 = callmethod(opresult433, "++", 1, params);
// compilenode returning opresult436
// Begin line 170
  setline(170);
  if (strlit437 == NULL) {
    strlit437 = alloc_String("(Object self, int nparams, ");
  }
// compilenode returning strlit437
  params[0] = strlit437;
  Object opresult439 = callmethod(opresult436, "++", 1, params);
// compilenode returning opresult439
// Begin line 171
  setline(171);
  if (strlit440 == NULL) {
    strlit440 = alloc_String("Object* args, int flags) {");
  }
// compilenode returning strlit440
  params[0] = strlit440;
  Object opresult442 = callmethod(opresult439, "++", 1, params);
// compilenode returning opresult442
// Begin line 172
  setline(172);
// compilenode returning self
  params[0] = opresult442;
  Object call443 = callmethod(self, "outprint",
    1, params);
// compilenode returning call443
  if (strlit444 == NULL) {
    strlit444 = alloc_String("  struct UserObject *uo = (struct UserObject *)self;");
  }
// compilenode returning strlit444
// Begin line 173
  setline(173);
// compilenode returning self
  params[0] = strlit444;
  Object call445 = callmethod(self, "outprint",
    1, params);
// compilenode returning call445
  if (strlit446 == NULL) {
    strlit446 = alloc_String("  return uo->data[");
  }
// compilenode returning strlit446
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult448 = callmethod(strlit446, "++", 1, params);
// compilenode returning opresult448
  if (strlit449 == NULL) {
    strlit449 = alloc_String("];");
  }
// compilenode returning strlit449
  params[0] = strlit449;
  Object opresult451 = callmethod(opresult448, "++", 1, params);
// compilenode returning opresult451
// Begin line 174
  setline(174);
// compilenode returning self
  params[0] = opresult451;
  Object call452 = callmethod(self, "outprint",
    1, params);
// compilenode returning call452
  if (strlit453 == NULL) {
    strlit453 = alloc_String("}");
  }
// compilenode returning strlit453
// Begin line 175
  setline(175);
// compilenode returning self
  params[0] = strlit453;
  Object call454 = callmethod(self, "outprint",
    1, params);
// compilenode returning call454
  if (strlit455 == NULL) {
    strlit455 = alloc_String("  addmethod2(");
  }
// compilenode returning strlit455
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult457 = callmethod(strlit455, "++", 1, params);
// compilenode returning opresult457
  if (strlit458 == NULL) {
    strlit458 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit458
  params[0] = strlit458;
  Object opresult460 = callmethod(opresult457, "++", 1, params);
// compilenode returning opresult460
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult462 = callmethod(opresult460, "++", 1, params);
// compilenode returning opresult462
  if (strlit463 == NULL) {
    strlit463 = alloc_String("""\x22"", &reader_");
  }
// compilenode returning strlit463
  params[0] = strlit463;
  Object opresult465 = callmethod(opresult462, "++", 1, params);
// compilenode returning opresult465
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult467 = callmethod(opresult465, "++", 1, params);
// compilenode returning opresult467
  if (strlit468 == NULL) {
    strlit468 = alloc_String("_");
  }
// compilenode returning strlit468
  params[0] = strlit468;
  Object opresult470 = callmethod(opresult467, "++", 1, params);
// compilenode returning opresult470
// compilenode returning *var_inm
  params[0] = *var_inm;
  Object opresult472 = callmethod(opresult470, "++", 1, params);
// compilenode returning opresult472
  if (strlit473 == NULL) {
    strlit473 = alloc_String("_");
  }
// compilenode returning strlit473
  params[0] = strlit473;
  Object opresult475 = callmethod(opresult472, "++", 1, params);
// compilenode returning opresult475
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult477 = callmethod(opresult475, "++", 1, params);
// compilenode returning opresult477
  if (strlit478 == NULL) {
    strlit478 = alloc_String(");");
  }
// compilenode returning strlit478
  params[0] = strlit478;
  Object opresult480 = callmethod(opresult477, "++", 1, params);
// compilenode returning opresult480
// Begin line 176
  setline(176);
// compilenode returning self
  params[0] = opresult480;
  Object call481 = callmethod(self, "out",
    1, params);
// compilenode returning call481
// Begin line 177
  setline(177);
// Begin line 176
  setline(176);
// compilenode returning *var_nm
  if (strlit482 == NULL) {
    strlit482 = alloc_String(":=");
  }
// compilenode returning strlit482
  params[0] = strlit482;
  Object opresult484 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult484
  var_nmw = alloc_var();
  *var_nmw = opresult484;
  if (opresult484 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 177
  setline(177);
// compilenode returning *var_nmw
  Object call485 = gracelib_length(*var_nmw);
// compilenode returning call485
  Object num486 = alloc_Float64(1.0);
// compilenode returning num486
  params[0] = num486;
  Object sum488 = callmethod(call485, "+", 1, params);
// compilenode returning sum488
  *var_len = sum488;
  if (sum488 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 178
  setline(178);
// compilenode returning *var_nmw
// Begin line 179
  setline(179);
// compilenode returning self
  params[0] = *var_nmw;
  Object call490 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call490
  *var_nmw = call490;
  if (call490 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 181
  setline(181);
// Begin line 179
  setline(179);
  if (strlit492 == NULL) {
    strlit492 = alloc_String("Object writer_");
  }
// compilenode returning strlit492
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult494 = callmethod(strlit492, "++", 1, params);
// compilenode returning opresult494
  if (strlit495 == NULL) {
    strlit495 = alloc_String("_");
  }
// compilenode returning strlit495
  params[0] = strlit495;
  Object opresult497 = callmethod(opresult494, "++", 1, params);
// compilenode returning opresult497
// compilenode returning *var_inm
  params[0] = *var_inm;
  Object opresult499 = callmethod(opresult497, "++", 1, params);
// compilenode returning opresult499
  if (strlit500 == NULL) {
    strlit500 = alloc_String("_");
  }
// compilenode returning strlit500
  params[0] = strlit500;
  Object opresult502 = callmethod(opresult499, "++", 1, params);
// compilenode returning opresult502
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult504 = callmethod(opresult502, "++", 1, params);
// compilenode returning opresult504
  if (strlit505 == NULL) {
    strlit505 = alloc_String("");
  }
// compilenode returning strlit505
  params[0] = strlit505;
  Object opresult507 = callmethod(opresult504, "++", 1, params);
// compilenode returning opresult507
// Begin line 180
  setline(180);
  if (strlit508 == NULL) {
    strlit508 = alloc_String("(Object self, int nparams, ");
  }
// compilenode returning strlit508
  params[0] = strlit508;
  Object opresult510 = callmethod(opresult507, "++", 1, params);
// compilenode returning opresult510
// Begin line 181
  setline(181);
  if (strlit511 == NULL) {
    strlit511 = alloc_String("Object* args, int flags) {");
  }
// compilenode returning strlit511
  params[0] = strlit511;
  Object opresult513 = callmethod(opresult510, "++", 1, params);
// compilenode returning opresult513
// Begin line 182
  setline(182);
// compilenode returning self
  params[0] = opresult513;
  Object call514 = callmethod(self, "outprint",
    1, params);
// compilenode returning call514
  if (strlit515 == NULL) {
    strlit515 = alloc_String("  struct UserObject *uo = (struct UserObject *)self;");
  }
// compilenode returning strlit515
// Begin line 183
  setline(183);
// compilenode returning self
  params[0] = strlit515;
  Object call516 = callmethod(self, "outprint",
    1, params);
// compilenode returning call516
  if (strlit517 == NULL) {
    strlit517 = alloc_String("  uo->data[");
  }
// compilenode returning strlit517
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult519 = callmethod(strlit517, "++", 1, params);
// compilenode returning opresult519
  if (strlit520 == NULL) {
    strlit520 = alloc_String("] = args[0];");
  }
// compilenode returning strlit520
  params[0] = strlit520;
  Object opresult522 = callmethod(opresult519, "++", 1, params);
// compilenode returning opresult522
// Begin line 184
  setline(184);
// compilenode returning self
  params[0] = opresult522;
  Object call523 = callmethod(self, "outprint",
    1, params);
// compilenode returning call523
  if (strlit524 == NULL) {
    strlit524 = alloc_String("  return nothing;");
  }
// compilenode returning strlit524
// compilenode returning self
  params[0] = strlit524;
  Object call525 = callmethod(self, "outprint",
    1, params);
// compilenode returning call525
// Begin line 185
  setline(185);
  if (strlit526 == NULL) {
    strlit526 = alloc_String("}");
  }
// compilenode returning strlit526
// Begin line 186
  setline(186);
// compilenode returning self
  params[0] = strlit526;
  Object call527 = callmethod(self, "outprint",
    1, params);
// compilenode returning call527
  if (strlit528 == NULL) {
    strlit528 = alloc_String("  addmethod2(");
  }
// compilenode returning strlit528
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult530 = callmethod(strlit528, "++", 1, params);
// compilenode returning opresult530
  if (strlit531 == NULL) {
    strlit531 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit531
  params[0] = strlit531;
  Object opresult533 = callmethod(opresult530, "++", 1, params);
// compilenode returning opresult533
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult535 = callmethod(opresult533, "++", 1, params);
// compilenode returning opresult535
  if (strlit536 == NULL) {
    strlit536 = alloc_String(":=""\x22"", &writer_");
  }
// compilenode returning strlit536
  params[0] = strlit536;
  Object opresult538 = callmethod(opresult535, "++", 1, params);
// compilenode returning opresult538
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult540 = callmethod(opresult538, "++", 1, params);
// compilenode returning opresult540
  if (strlit541 == NULL) {
    strlit541 = alloc_String("_");
  }
// compilenode returning strlit541
  params[0] = strlit541;
  Object opresult543 = callmethod(opresult540, "++", 1, params);
// compilenode returning opresult543
// compilenode returning *var_inm
  params[0] = *var_inm;
  Object opresult545 = callmethod(opresult543, "++", 1, params);
// compilenode returning opresult545
  if (strlit546 == NULL) {
    strlit546 = alloc_String("_");
  }
// compilenode returning strlit546
  params[0] = strlit546;
  Object opresult548 = callmethod(opresult545, "++", 1, params);
// compilenode returning opresult548
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult550 = callmethod(opresult548, "++", 1, params);
// compilenode returning opresult550
  if (strlit551 == NULL) {
    strlit551 = alloc_String(");");
  }
// compilenode returning strlit551
  params[0] = strlit551;
  Object opresult553 = callmethod(opresult550, "++", 1, params);
// compilenode returning opresult553
// Begin line 187
  setline(187);
// compilenode returning self
  params[0] = opresult553;
  Object call554 = callmethod(self, "out",
    1, params);
// compilenode returning call554
  return call554;
}
Object meth_genc_compileclass555(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[4];
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_mbody = alloc_var();
  *var_mbody = undefined;
  Object *var_newmeth = alloc_var();
  *var_newmeth = undefined;
  Object *var_obody = alloc_var();
  *var_obody = undefined;
  Object *var_cobj = alloc_var();
  *var_cobj = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 190
  setline(190);
// Begin line 1035
  setline(1035);
// Begin line 189
  setline(189);
// compilenode returning *var_o
  Object call556 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call556
// compilenode returning call556
  var_params = alloc_var();
  *var_params = call556;
  if (call556 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 190
  setline(190);
  Object array557 = alloc_List();
// Begin line 1035
  setline(1035);
// Begin line 190
  setline(190);
// compilenode returning *var_o
  Object call558 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call558
// compilenode returning call558
// Begin line 1035
  setline(1035);
// Begin line 190
  setline(190);
// compilenode returning *var_o
  Object call559 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call559
// compilenode returning call559
// compilenode returning module_ast
  params[0] = call558;
  params[1] = call559;
  Object call560 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call560
  params[0] = call560;
  callmethod(array557, "push", 1, params);
// compilenode returning array557
  var_mbody = alloc_var();
  *var_mbody = array557;
  if (array557 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 192
  setline(192);
// Begin line 191
  setline(191);
  if (strlit561 == NULL) {
    strlit561 = alloc_String("new");
  }
// compilenode returning strlit561
  Object bool562 = alloc_Boolean(0);
// compilenode returning bool562
// compilenode returning module_ast
  params[0] = strlit561;
  params[1] = bool562;
  Object call563 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call563
// compilenode returning *var_params
// compilenode returning *var_mbody
// Begin line 192
  setline(192);
  Object bool564 = alloc_Boolean(0);
// compilenode returning bool564
// Begin line 191
  setline(191);
// compilenode returning module_ast
  params[0] = call563;
  params[1] = *var_params;
  params[2] = *var_mbody;
  params[3] = bool564;
  Object call565 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call565
  var_newmeth = alloc_var();
  *var_newmeth = call565;
  if (call565 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 193
  setline(193);
  Object array566 = alloc_List();
// compilenode returning *var_newmeth
  params[0] = *var_newmeth;
  callmethod(array566, "push", 1, params);
// compilenode returning array566
  var_obody = alloc_var();
  *var_obody = array566;
  if (array566 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 194
  setline(194);
// compilenode returning *var_obody
  Object bool567 = alloc_Boolean(0);
// compilenode returning bool567
// compilenode returning module_ast
  params[0] = *var_obody;
  params[1] = bool567;
  Object call568 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call568
  var_cobj = alloc_var();
  *var_cobj = call568;
  if (call568 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 195
  setline(195);
// Begin line 1035
  setline(1035);
// Begin line 195
  setline(195);
// compilenode returning *var_o
  Object call569 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call569
// compilenode returning call569
// compilenode returning *var_cobj
  Object bool570 = alloc_Boolean(0);
// compilenode returning bool570
// compilenode returning module_ast
  params[0] = call569;
  params[1] = *var_cobj;
  params[2] = bool570;
  Object call571 = callmethod(module_ast, "astdefdec",
    3, params);
// compilenode returning call571
  var_con = alloc_var();
  *var_con = call571;
  if (call571 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 196
  setline(196);
// Begin line 1035
  setline(1035);
// Begin line 196
  setline(196);
// compilenode returning *var_con
// Begin line 197
  setline(197);
// compilenode returning self
  params[0] = *var_con;
  Object call572 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call572
// Begin line 196
  setline(196);
// compilenode returning *var_o
  params[0] = call572;
  Object call573 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call573
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply592(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object *var_numMethods = closure[0];
  Object *var_numFields = closure[1];
  Object self = *closure[2];
// Begin line 210
  setline(210);
// Begin line 211
  setline(211);
// Begin line 1035
  setline(1035);
// Begin line 208
  setline(208);
// compilenode returning *var_e
  Object call594 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call594
// compilenode returning call594
  if (strlit595 == NULL) {
    strlit595 = alloc_String("vardec");
  }
// compilenode returning strlit595
  params[0] = strlit595;
  Object opresult597 = callmethod(call594, "==", 1, params);
// compilenode returning opresult597
  Object if593;
  if (istrue(opresult597)) {
// Begin line 210
  setline(210);
// Begin line 209
  setline(209);
// compilenode returning *var_numMethods
  Object num598 = alloc_Float64(1.0);
// compilenode returning num598
  params[0] = num598;
  Object sum600 = callmethod(*var_numMethods, "+", 1, params);
// compilenode returning sum600
  *var_numMethods = sum600;
  if (sum600 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if593 = nothing;
  } else {
  }
// compilenode returning if593
// Begin line 212
  setline(212);
// Begin line 211
  setline(211);
// compilenode returning *var_numMethods
  Object num602 = alloc_Float64(1.0);
// compilenode returning num602
  params[0] = num602;
  Object sum604 = callmethod(*var_numMethods, "+", 1, params);
// compilenode returning sum604
  *var_numMethods = sum604;
  if (sum604 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 213
  setline(213);
// Begin line 212
  setline(212);
// compilenode returning *var_numFields
  Object num606 = alloc_Float64(1.0);
// compilenode returning num606
  params[0] = num606;
  Object sum608 = callmethod(*var_numFields, "+", 1, params);
// compilenode returning sum608
  *var_numFields = sum608;
  if (sum608 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply658(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[3];
  Object *var_selfr = closure[0];
  Object *var_pos = closure[1];
  Object self = *closure[2];
// Begin line 227
  setline(227);
// Begin line 229
  setline(229);
// Begin line 1035
  setline(1035);
// Begin line 226
  setline(226);
// compilenode returning *var_e
  Object call660 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call660
// compilenode returning call660
  if (strlit661 == NULL) {
    strlit661 = alloc_String("method");
  }
// compilenode returning strlit661
  params[0] = strlit661;
  Object opresult663 = callmethod(call660, "==", 1, params);
// compilenode returning opresult663
  Object if659;
  if (istrue(opresult663)) {
// Begin line 227
  setline(227);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 228
  setline(228);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call664 = callmethod(self, "compilemethod",
    3, params);
// compilenode returning call664
    if659 = call664;
  } else {
  }
// compilenode returning if659
// Begin line 230
  setline(230);
// Begin line 232
  setline(232);
// Begin line 1035
  setline(1035);
// Begin line 229
  setline(229);
// compilenode returning *var_e
  Object call666 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call666
// compilenode returning call666
  if (strlit667 == NULL) {
    strlit667 = alloc_String("vardec");
  }
// compilenode returning strlit667
  params[0] = strlit667;
  Object opresult669 = callmethod(call666, "==", 1, params);
// compilenode returning opresult669
  Object if665;
  if (istrue(opresult669)) {
// Begin line 230
  setline(230);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 231
  setline(231);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call670 = callmethod(self, "compileobjvardec",
    3, params);
// compilenode returning call670
    if665 = call670;
  } else {
  }
// compilenode returning if665
// Begin line 233
  setline(233);
// Begin line 235
  setline(235);
// Begin line 1035
  setline(1035);
// Begin line 232
  setline(232);
// compilenode returning *var_e
  Object call672 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call672
// compilenode returning call672
  if (strlit673 == NULL) {
    strlit673 = alloc_String("defdec");
  }
// compilenode returning strlit673
  params[0] = strlit673;
  Object opresult675 = callmethod(call672, "==", 1, params);
// compilenode returning opresult675
  Object if671;
  if (istrue(opresult675)) {
// Begin line 233
  setline(233);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 234
  setline(234);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call676 = callmethod(self, "compileobjdefdec",
    3, params);
// compilenode returning call676
    if671 = call676;
  } else {
  }
// compilenode returning if671
// Begin line 236
  setline(236);
// Begin line 235
  setline(235);
// compilenode returning *var_pos
  Object num677 = alloc_Float64(1.0);
// compilenode returning num677
  params[0] = num677;
  Object sum679 = callmethod(*var_pos, "+", 1, params);
// compilenode returning sum679
  *var_pos = sum679;
  if (sum679 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply685(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_selfr = closure[0];
  Object *var_o = closure[1];
  Object self = *closure[2];
// Begin line 239
  setline(239);
// Begin line 238
  setline(238);
  if (strlit686 == NULL) {
    strlit686 = alloc_String("  set_type(");
  }
// compilenode returning strlit686
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult688 = callmethod(strlit686, "++", 1, params);
// compilenode returning opresult688
  if (strlit689 == NULL) {
    strlit689 = alloc_String(", ");
  }
// compilenode returning strlit689
  params[0] = strlit689;
  Object opresult691 = callmethod(opresult688, "++", 1, params);
// compilenode returning opresult691
// Begin line 239
  setline(239);
  if (strlit692 == NULL) {
    strlit692 = alloc_String("");
  }
// compilenode returning strlit692
// Begin line 1035
  setline(1035);
// Begin line 239
  setline(239);
// compilenode returning *var_o
  Object call693 = callmethod(*var_o, "otype",
    0, params);
// compilenode returning call693
// compilenode returning call693
// compilenode returning module_subtype
  params[0] = call693;
  Object call694 = callmethod(module_subtype, "typeId",
    1, params);
// compilenode returning call694
  params[0] = call694;
  Object opresult696 = callmethod(strlit692, "++", 1, params);
// compilenode returning opresult696
  if (strlit697 == NULL) {
    strlit697 = alloc_String(");");
  }
// compilenode returning strlit697
  params[0] = strlit697;
  Object opresult699 = callmethod(opresult696, "++", 1, params);
// compilenode returning opresult699
  params[0] = opresult699;
  Object opresult701 = callmethod(opresult691, "++", 1, params);
// compilenode returning opresult701
// Begin line 240
  setline(240);
// compilenode returning self
  params[0] = opresult701;
  Object call702 = callmethod(self, "out",
    1, params);
// compilenode returning call702
  return call702;
}
Object meth_genc_apply707(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
  return nothing;
}
Object meth_genc_compileobject574(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_selfr = alloc_var();
  *var_selfr = undefined;
  Object *var_numFields = alloc_var();
  *var_numFields = undefined;
  Object *var_numMethods = alloc_var();
  *var_numMethods = undefined;
  Object *var_pos = alloc_var();
  *var_pos = undefined;
// Begin line 200
  setline(200);
// Begin line 199
  setline(199);
// compilenode returning *var_inBlock
  var_origInBlock = alloc_var();
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 201
  setline(201);
// Begin line 200
  setline(200);
  Object bool575 = alloc_Boolean(0);
// compilenode returning bool575
  *var_inBlock = bool575;
  if (bool575 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 202
  setline(202);
// Begin line 201
  setline(201);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 203
  setline(203);
// Begin line 202
  setline(202);
// compilenode returning *var_auto_count
  Object num577 = alloc_Float64(1.0);
// compilenode returning num577
  params[0] = num577;
  Object sum579 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum579
  *var_auto_count = sum579;
  if (sum579 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 204
  setline(204);
// Begin line 203
  setline(203);
  if (strlit581 == NULL) {
    strlit581 = alloc_String("obj");
  }
// compilenode returning strlit581
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult583 = callmethod(strlit581, "++", 1, params);
// compilenode returning opresult583
  var_selfr = alloc_var();
  *var_selfr = opresult583;
  if (opresult583 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 205
  setline(205);
// Begin line 204
  setline(204);
  Object num584 = alloc_Float64(1.0);
// compilenode returning num584
  var_numFields = alloc_var();
  *var_numFields = num584;
  if (num584 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 206
  setline(206);
// Begin line 205
  setline(205);
  Object num585 = alloc_Float64(0.0);
// compilenode returning num585
  var_numMethods = alloc_var();
  *var_numMethods = num585;
  if (num585 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 207
  setline(207);
// Begin line 206
  setline(206);
  Object num586 = alloc_Float64(1.0);
// compilenode returning num586
  var_pos = alloc_var();
  *var_pos = num586;
  if (num586 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 213
  setline(213);
// Begin line 214
  setline(214);
// Begin line 1035
  setline(1035);
// Begin line 207
  setline(207);
// compilenode returning *var_o
  Object call588 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call588
// compilenode returning call588
// Begin line 213
  setline(213);
// Begin line 1035
  setline(1035);
  Object obj590 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj590, self, 0);
  addmethod2(obj590, "outer", &reader_genc_outer_591);
  adddatum2(obj590, self, 0);
  block_savedest(obj590);
  Object **closure592 = createclosure(3);
  addtoclosure(closure592, var_numMethods);
  addtoclosure(closure592, var_numFields);
  Object *selfpp610 = alloc_var();
  *selfpp610 = self;
  addtoclosure(closure592, selfpp610);
  struct UserObject *uo592 = (struct UserObject*)obj590;
  uo592->data[1] = (Object)closure592;
  addmethod2(obj590, "apply", &meth_genc_apply592);
  set_type(obj590, 0);
// compilenode returning obj590
  setclassname(obj590, "Block<genc:589>");
// compilenode returning obj590
  params[0] = call588;
  Object iter587 = callmethod(call588, "iter", 1, params);
  while(1) {
    Object cond587 = callmethod(iter587, "havemore", 0, NULL);
    if (!istrue(cond587)) break;
    params[0] = callmethod(iter587, "next", 0, NULL);
    callmethod(obj590, "apply", 1, params);
  }
// compilenode returning call588
// Begin line 216
  setline(216);
// Begin line 217
  setline(217);
// Begin line 214
  setline(214);
// compilenode returning *var_numFields
  Object num612 = alloc_Float64(3.0);
// compilenode returning num612
  params[0] = num612;
  Object opresult614 = callmethod(*var_numFields, "==", 1, params);
// compilenode returning opresult614
  Object if611;
  if (istrue(opresult614)) {
// Begin line 216
  setline(216);
// Begin line 215
  setline(215);
  Object num615 = alloc_Float64(4.0);
// compilenode returning num615
  *var_numFields = num615;
  if (num615 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if611 = nothing;
  } else {
  }
// compilenode returning if611
// Begin line 221
  setline(221);
// Begin line 223
  setline(223);
// Begin line 1035
  setline(1035);
// Begin line 217
  setline(217);
// compilenode returning *var_o
  Object call618 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call618
// compilenode returning call618
  Object bool619 = alloc_Boolean(0);
// compilenode returning bool619
  params[0] = bool619;
  Object opresult621 = callmethod(call618, "/=", 1, params);
// compilenode returning opresult621
  Object if617;
  if (istrue(opresult621)) {
// Begin line 218
  setline(218);
// Begin line 1035
  setline(1035);
// Begin line 218
  setline(218);
// compilenode returning *var_o
  Object call622 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call622
// compilenode returning call622
// Begin line 219
  setline(219);
// compilenode returning self
  params[0] = call622;
  Object call623 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call623
  *var_selfr = call623;
  if (call623 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if617 = nothing;
  } else {
// Begin line 221
  setline(221);
// Begin line 220
  setline(220);
  if (strlit625 == NULL) {
    strlit625 = alloc_String("  Object ");
  }
// compilenode returning strlit625
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult627 = callmethod(strlit625, "++", 1, params);
// compilenode returning opresult627
// Begin line 221
  setline(221);
// Begin line 220
  setline(220);
  if (strlit628 == NULL) {
    strlit628 = alloc_String(" = alloc_obj2(");
  }
// compilenode returning strlit628
// compilenode returning *var_numMethods
  params[0] = *var_numMethods;
  Object opresult630 = callmethod(strlit628, "++", 1, params);
// compilenode returning opresult630
  if (strlit631 == NULL) {
    strlit631 = alloc_String(",");
  }
// compilenode returning strlit631
  params[0] = strlit631;
  Object opresult633 = callmethod(opresult630, "++", 1, params);
// compilenode returning opresult633
  params[0] = opresult633;
  Object opresult635 = callmethod(opresult627, "++", 1, params);
// compilenode returning opresult635
// Begin line 221
  setline(221);
  if (strlit636 == NULL) {
    strlit636 = alloc_String("");
  }
// compilenode returning strlit636
// compilenode returning *var_numFields
  params[0] = *var_numFields;
  Object opresult638 = callmethod(strlit636, "++", 1, params);
// compilenode returning opresult638
  if (strlit639 == NULL) {
    strlit639 = alloc_String(");");
  }
// compilenode returning strlit639
  params[0] = strlit639;
  Object opresult641 = callmethod(opresult638, "++", 1, params);
// compilenode returning opresult641
  params[0] = opresult641;
  Object opresult643 = callmethod(opresult635, "++", 1, params);
// compilenode returning opresult643
// Begin line 222
  setline(222);
// compilenode returning self
  params[0] = opresult643;
  Object call644 = callmethod(self, "out",
    1, params);
// compilenode returning call644
    if617 = call644;
  }
// compilenode returning if617
// Begin line 223
  setline(223);
// compilenode returning *var_selfr
// Begin line 224
  setline(224);
// compilenode returning self
  params[0] = *var_selfr;
  Object call645 = callmethod(self, "compileobjouter",
    1, params);
// compilenode returning call645
  if (strlit646 == NULL) {
    strlit646 = alloc_String("  adddatum2(");
  }
// compilenode returning strlit646
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult648 = callmethod(strlit646, "++", 1, params);
// compilenode returning opresult648
  if (strlit649 == NULL) {
    strlit649 = alloc_String(", self, 0);");
  }
// compilenode returning strlit649
  params[0] = strlit649;
  Object opresult651 = callmethod(opresult648, "++", 1, params);
// compilenode returning opresult651
// Begin line 225
  setline(225);
// compilenode returning self
  params[0] = opresult651;
  Object call652 = callmethod(self, "out",
    1, params);
// compilenode returning call652
// Begin line 236
  setline(236);
// Begin line 237
  setline(237);
// Begin line 1035
  setline(1035);
// Begin line 225
  setline(225);
// compilenode returning *var_o
  Object call654 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call654
// compilenode returning call654
// Begin line 236
  setline(236);
// Begin line 1035
  setline(1035);
  Object obj656 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj656, self, 0);
  addmethod2(obj656, "outer", &reader_genc_outer_657);
  adddatum2(obj656, self, 0);
  block_savedest(obj656);
  Object **closure658 = createclosure(3);
  addtoclosure(closure658, var_selfr);
  addtoclosure(closure658, var_pos);
  Object *selfpp681 = alloc_var();
  *selfpp681 = self;
  addtoclosure(closure658, selfpp681);
  struct UserObject *uo658 = (struct UserObject*)obj656;
  uo658->data[1] = (Object)closure658;
  addmethod2(obj656, "apply", &meth_genc_apply658);
  set_type(obj656, 0);
// compilenode returning obj656
  setclassname(obj656, "Block<genc:655>");
// compilenode returning obj656
  params[0] = call654;
  Object iter653 = callmethod(call654, "iter", 1, params);
  while(1) {
    Object cond653 = callmethod(iter653, "havemore", 0, NULL);
    if (!istrue(cond653)) break;
    params[0] = callmethod(iter653, "next", 0, NULL);
    callmethod(obj656, "apply", 1, params);
  }
// compilenode returning call654
// Begin line 241
  setline(241);
// Begin line 239
  setline(239);
// Begin line 1035
  setline(1035);
  Object obj683 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj683, self, 0);
  addmethod2(obj683, "outer", &reader_genc_outer_684);
  adddatum2(obj683, self, 0);
  block_savedest(obj683);
  Object **closure685 = createclosure(3);
  addtoclosure(closure685, var_selfr);
  addtoclosure(closure685, var_o);
  Object *selfpp703 = alloc_var();
  *selfpp703 = self;
  addtoclosure(closure685, selfpp703);
  struct UserObject *uo685 = (struct UserObject*)obj683;
  uo685->data[1] = (Object)closure685;
  addmethod2(obj683, "apply", &meth_genc_apply685);
  set_type(obj683, 0);
// compilenode returning obj683
  setclassname(obj683, "Block<genc:682>");
// compilenode returning obj683
// Begin line 241
  setline(241);
// Begin line 1035
  setline(1035);
  Object obj705 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj705, self, 0);
  addmethod2(obj705, "outer", &reader_genc_outer_706);
  adddatum2(obj705, self, 0);
  block_savedest(obj705);
  Object **closure707 = createclosure(1);
  Object *selfpp708 = alloc_var();
  *selfpp708 = self;
  addtoclosure(closure707, selfpp708);
  struct UserObject *uo707 = (struct UserObject*)obj705;
  uo707->data[1] = (Object)closure707;
  addmethod2(obj705, "apply", &meth_genc_apply707);
  set_type(obj705, 0);
// compilenode returning obj705
  setclassname(obj705, "Block<genc:704>");
// compilenode returning obj705
// Begin line 237
  setline(237);
// compilenode returning module_util
  params[0] = obj683;
  params[1] = obj705;
  Object call709 = callmethod(module_util, "runOnNew(1)else",
    2, params);
// compilenode returning call709
// Begin line 242
  setline(242);
// Begin line 1035
  setline(1035);
// Begin line 241
  setline(241);
// compilenode returning *var_selfr
// compilenode returning *var_o
  params[0] = *var_selfr;
  Object call710 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call710
// compilenode returning nothing
// Begin line 243
  setline(243);
// Begin line 242
  setline(242);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileblock712(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[4];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_modname = closure[2];
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_applymeth = alloc_var();
  *var_applymeth = undefined;
  Object *var_objbody = alloc_var();
  *var_objbody = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
  Object *var_modn = alloc_var();
  *var_modn = undefined;
// Begin line 246
  setline(246);
// Begin line 245
  setline(245);
// compilenode returning *var_inBlock
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 247
  setline(247);
// Begin line 246
  setline(246);
  Object bool713 = alloc_Boolean(1);
// compilenode returning bool713
  *var_inBlock = bool713;
  if (bool713 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 248
  setline(248);
// Begin line 247
  setline(247);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 249
  setline(249);
// Begin line 248
  setline(248);
// compilenode returning *var_auto_count
  Object num715 = alloc_Float64(1.0);
// compilenode returning num715
  params[0] = num715;
  Object sum717 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum717
  *var_auto_count = sum717;
  if (sum717 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 250
  setline(250);
// Begin line 249
  setline(249);
  if (strlit719 == NULL) {
    strlit719 = alloc_String("apply");
  }
// compilenode returning strlit719
  Object bool720 = alloc_Boolean(0);
// compilenode returning bool720
// compilenode returning module_ast
  params[0] = strlit719;
  params[1] = bool720;
  Object call721 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call721
// Begin line 250
  setline(250);
// Begin line 1035
  setline(1035);
// Begin line 250
  setline(250);
// compilenode returning *var_o
  Object call722 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call722
// compilenode returning call722
// Begin line 1035
  setline(1035);
// Begin line 250
  setline(250);
// compilenode returning *var_o
  Object call723 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call723
// compilenode returning call723
  Object bool724 = alloc_Boolean(0);
// compilenode returning bool724
// Begin line 249
  setline(249);
// compilenode returning module_ast
  params[0] = call721;
  params[1] = call722;
  params[2] = call723;
  params[3] = bool724;
  Object call725 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call725
  var_applymeth = alloc_var();
  *var_applymeth = call725;
  if (call725 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 252
  setline(252);
// Begin line 1035
  setline(1035);
// Begin line 251
  setline(251);
  Object bool726 = alloc_Boolean(1);
// compilenode returning bool726
// compilenode returning *var_applymeth
  params[0] = bool726;
  Object call727 = callmethod(*var_applymeth, "selfclosure:=",
    1, params);
// compilenode returning call727
// compilenode returning nothing
// Begin line 252
  setline(252);
  Object array728 = alloc_List();
// compilenode returning *var_applymeth
  params[0] = *var_applymeth;
  callmethod(array728, "push", 1, params);
// compilenode returning array728
  Object bool729 = alloc_Boolean(0);
// compilenode returning bool729
// compilenode returning module_ast
  params[0] = array728;
  params[1] = bool729;
  Object call730 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call730
  var_objbody = alloc_var();
  *var_objbody = call730;
  if (call730 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 253
  setline(253);
// compilenode returning *var_objbody
// Begin line 254
  setline(254);
// compilenode returning self
  params[0] = *var_objbody;
  Object call731 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call731
  var_obj = alloc_var();
  *var_obj = call731;
  if (call731 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 255
  setline(255);
// Begin line 254
  setline(254);
  if (strlit732 == NULL) {
    strlit732 = alloc_String("Block<");
  }
// compilenode returning strlit732
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult734 = callmethod(strlit732, "++", 1, params);
// compilenode returning opresult734
  if (strlit735 == NULL) {
    strlit735 = alloc_String(":");
  }
// compilenode returning strlit735
  params[0] = strlit735;
  Object opresult737 = callmethod(opresult734, "++", 1, params);
// compilenode returning opresult737
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult739 = callmethod(opresult737, "++", 1, params);
// compilenode returning opresult739
  if (strlit740 == NULL) {
    strlit740 = alloc_String(">");
  }
// compilenode returning strlit740
  params[0] = strlit740;
  Object opresult742 = callmethod(opresult739, "++", 1, params);
// compilenode returning opresult742
  var_modn = alloc_var();
  *var_modn = opresult742;
  if (opresult742 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 255
  setline(255);
  if (strlit743 == NULL) {
    strlit743 = alloc_String("  setclassname(");
  }
// compilenode returning strlit743
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult745 = callmethod(strlit743, "++", 1, params);
// compilenode returning opresult745
  if (strlit746 == NULL) {
    strlit746 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit746
  params[0] = strlit746;
  Object opresult748 = callmethod(opresult745, "++", 1, params);
// compilenode returning opresult748
// compilenode returning *var_modn
  params[0] = *var_modn;
  Object opresult750 = callmethod(opresult748, "++", 1, params);
// compilenode returning opresult750
  if (strlit751 == NULL) {
    strlit751 = alloc_String("""\x22"");");
  }
// compilenode returning strlit751
  params[0] = strlit751;
  Object opresult753 = callmethod(opresult750, "++", 1, params);
// compilenode returning opresult753
// Begin line 256
  setline(256);
// compilenode returning self
  params[0] = opresult753;
  Object call754 = callmethod(self, "out",
    1, params);
// compilenode returning call754
// Begin line 257
  setline(257);
// Begin line 1035
  setline(1035);
// Begin line 256
  setline(256);
// compilenode returning *var_obj
// compilenode returning *var_o
  params[0] = *var_obj;
  Object call755 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call755
// compilenode returning nothing
// Begin line 258
  setline(258);
// Begin line 257
  setline(257);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilefor757(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_over = alloc_var();
  *var_over = undefined;
  Object *var_blk = alloc_var();
  *var_blk = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
// Begin line 261
  setline(261);
// Begin line 260
  setline(260);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 262
  setline(262);
// Begin line 261
  setline(261);
// compilenode returning *var_auto_count
  Object num758 = alloc_Float64(1.0);
// compilenode returning num758
  params[0] = num758;
  Object sum760 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum760
  *var_auto_count = sum760;
  if (sum760 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 262
  setline(262);
// Begin line 1035
  setline(1035);
// Begin line 262
  setline(262);
// compilenode returning *var_o
  Object call762 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call762
// compilenode returning call762
// Begin line 263
  setline(263);
// compilenode returning self
  params[0] = call762;
  Object call763 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call763
  var_over = alloc_var();
  *var_over = call763;
  if (call763 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// Begin line 1035
  setline(1035);
// Begin line 263
  setline(263);
// compilenode returning *var_o
  Object call764 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call764
// compilenode returning call764
  var_blk = alloc_var();
  *var_blk = call764;
  if (call764 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// compilenode returning *var_blk
// Begin line 265
  setline(265);
// compilenode returning self
  params[0] = *var_blk;
  Object call765 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call765
  var_obj = alloc_var();
  *var_obj = call765;
  if (call765 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit766 == NULL) {
    strlit766 = alloc_String("  params[0] = ");
  }
// compilenode returning strlit766
// compilenode returning *var_over
  params[0] = *var_over;
  Object opresult768 = callmethod(strlit766, "++", 1, params);
// compilenode returning opresult768
  if (strlit769 == NULL) {
    strlit769 = alloc_String(";");
  }
// compilenode returning strlit769
  params[0] = strlit769;
  Object opresult771 = callmethod(opresult768, "++", 1, params);
// compilenode returning opresult771
// Begin line 266
  setline(266);
// compilenode returning self
  params[0] = opresult771;
  Object call772 = callmethod(self, "out",
    1, params);
// compilenode returning call772
  if (strlit773 == NULL) {
    strlit773 = alloc_String("  Object iter");
  }
// compilenode returning strlit773
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult775 = callmethod(strlit773, "++", 1, params);
// compilenode returning opresult775
  if (strlit776 == NULL) {
    strlit776 = alloc_String(" = callmethod(");
  }
// compilenode returning strlit776
  params[0] = strlit776;
  Object opresult778 = callmethod(opresult775, "++", 1, params);
// compilenode returning opresult778
// compilenode returning *var_over
  params[0] = *var_over;
  Object opresult780 = callmethod(opresult778, "++", 1, params);
// compilenode returning opresult780
  if (strlit781 == NULL) {
    strlit781 = alloc_String(", ""\x22""iter""\x22"", 1, params);");
  }
// compilenode returning strlit781
  params[0] = strlit781;
  Object opresult783 = callmethod(opresult780, "++", 1, params);
// compilenode returning opresult783
// Begin line 267
  setline(267);
// compilenode returning self
  params[0] = opresult783;
  Object call784 = callmethod(self, "out",
    1, params);
// compilenode returning call784
  if (strlit785 == NULL) {
    strlit785 = alloc_String("  while(1) {");
  }
// compilenode returning strlit785
// Begin line 268
  setline(268);
// compilenode returning self
  params[0] = strlit785;
  Object call786 = callmethod(self, "out",
    1, params);
// compilenode returning call786
  if (strlit787 == NULL) {
    strlit787 = alloc_String("    Object cond");
  }
// compilenode returning strlit787
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult789 = callmethod(strlit787, "++", 1, params);
// compilenode returning opresult789
  if (strlit790 == NULL) {
    strlit790 = alloc_String(" = callmethod(iter");
  }
// compilenode returning strlit790
  params[0] = strlit790;
  Object opresult792 = callmethod(opresult789, "++", 1, params);
// compilenode returning opresult792
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult794 = callmethod(opresult792, "++", 1, params);
// compilenode returning opresult794
  if (strlit795 == NULL) {
    strlit795 = alloc_String(", ""\x22""havemore""\x22"", 0, NULL);");
  }
// compilenode returning strlit795
  params[0] = strlit795;
  Object opresult797 = callmethod(opresult794, "++", 1, params);
// compilenode returning opresult797
// Begin line 269
  setline(269);
// compilenode returning self
  params[0] = opresult797;
  Object call798 = callmethod(self, "out",
    1, params);
// compilenode returning call798
  if (strlit799 == NULL) {
    strlit799 = alloc_String("    if (!istrue(cond");
  }
// compilenode returning strlit799
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult801 = callmethod(strlit799, "++", 1, params);
// compilenode returning opresult801
  if (strlit802 == NULL) {
    strlit802 = alloc_String(")) break;");
  }
// compilenode returning strlit802
  params[0] = strlit802;
  Object opresult804 = callmethod(opresult801, "++", 1, params);
// compilenode returning opresult804
// Begin line 270
  setline(270);
// compilenode returning self
  params[0] = opresult804;
  Object call805 = callmethod(self, "out",
    1, params);
// compilenode returning call805
  if (strlit806 == NULL) {
    strlit806 = alloc_String("    params[0] = callmethod(iter");
  }
// compilenode returning strlit806
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult808 = callmethod(strlit806, "++", 1, params);
// compilenode returning opresult808
  if (strlit809 == NULL) {
    strlit809 = alloc_String(", ""\x22""next""\x22"", 0, NULL);");
  }
// compilenode returning strlit809
  params[0] = strlit809;
  Object opresult811 = callmethod(opresult808, "++", 1, params);
// compilenode returning opresult811
// Begin line 271
  setline(271);
// compilenode returning self
  params[0] = opresult811;
  Object call812 = callmethod(self, "out",
    1, params);
// compilenode returning call812
  if (strlit813 == NULL) {
    strlit813 = alloc_String("    callmethod(");
  }
// compilenode returning strlit813
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult815 = callmethod(strlit813, "++", 1, params);
// compilenode returning opresult815
  if (strlit816 == NULL) {
    strlit816 = alloc_String(", ""\x22""apply""\x22"", 1, params);");
  }
// compilenode returning strlit816
  params[0] = strlit816;
  Object opresult818 = callmethod(opresult815, "++", 1, params);
// compilenode returning opresult818
// Begin line 272
  setline(272);
// compilenode returning self
  params[0] = opresult818;
  Object call819 = callmethod(self, "out",
    1, params);
// compilenode returning call819
  if (strlit820 == NULL) {
    strlit820 = alloc_String("  }");
  }
// compilenode returning strlit820
// Begin line 273
  setline(273);
// compilenode returning self
  params[0] = strlit820;
  Object call821 = callmethod(self, "out",
    1, params);
// compilenode returning call821
// Begin line 274
  setline(274);
// Begin line 1035
  setline(1035);
// Begin line 273
  setline(273);
// compilenode returning *var_over
// compilenode returning *var_o
  params[0] = *var_over;
  Object call822 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call822
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply887(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 310
  setline(310);
// Begin line 312
  setline(312);
// Begin line 1035
  setline(1035);
// Begin line 305
  setline(305);
// compilenode returning *var_l
  Object call889 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call889
// compilenode returning call889
  if (strlit890 == NULL) {
    strlit890 = alloc_String("vardec");
  }
// compilenode returning strlit890
  params[0] = strlit890;
  Object opresult892 = callmethod(call889, "==", 1, params);
// compilenode returning opresult892
// Begin line 312
  setline(312);
// Begin line 1035
  setline(1035);
// Begin line 305
  setline(305);
// compilenode returning *var_l
  Object call893 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call893
// compilenode returning call893
  if (strlit894 == NULL) {
    strlit894 = alloc_String("defdec");
  }
// compilenode returning strlit894
  params[0] = strlit894;
  Object opresult896 = callmethod(call893, "==", 1, params);
// compilenode returning opresult896
  params[0] = opresult896;
  Object opresult898 = callmethod(opresult892, "|", 1, params);
// compilenode returning opresult898
// Begin line 312
  setline(312);
// Begin line 1035
  setline(1035);
// Begin line 306
  setline(306);
// compilenode returning *var_l
  Object call899 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call899
// compilenode returning call899
  if (strlit900 == NULL) {
    strlit900 = alloc_String("class");
  }
// compilenode returning strlit900
  params[0] = strlit900;
  Object opresult902 = callmethod(call899, "==", 1, params);
// compilenode returning opresult902
  params[0] = opresult902;
  Object opresult904 = callmethod(opresult898, "|", 1, params);
// compilenode returning opresult904
  Object if888;
  if (istrue(opresult904)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 307
  setline(307);
// Begin line 1035
  setline(1035);
// Begin line 307
  setline(307);
// Begin line 1035
  setline(1035);
// Begin line 307
  setline(307);
// compilenode returning *var_l
  Object call905 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call905
// compilenode returning call905
  Object call906 = callmethod(call905, "value",
    0, params);
// compilenode returning call906
// compilenode returning call906
// Begin line 308
  setline(308);
// compilenode returning self
  params[0] = call906;
  Object call907 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call907
  var_tnm = alloc_var();
  *var_tnm = call907;
  if (call907 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call908 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call908
// Begin line 309
  setline(309);
  if (strlit909 == NULL) {
    strlit909 = alloc_String("  Object *var_");
  }
// compilenode returning strlit909
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult911 = callmethod(strlit909, "++", 1, params);
// compilenode returning opresult911
  if (strlit912 == NULL) {
    strlit912 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit912
  params[0] = strlit912;
  Object opresult914 = callmethod(opresult911, "++", 1, params);
// compilenode returning opresult914
// Begin line 310
  setline(310);
// compilenode returning self
  params[0] = opresult914;
  Object call915 = callmethod(self, "out",
    1, params);
// compilenode returning call915
  if (strlit916 == NULL) {
    strlit916 = alloc_String("  *var_");
  }
// compilenode returning strlit916
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult918 = callmethod(strlit916, "++", 1, params);
// compilenode returning opresult918
  if (strlit919 == NULL) {
    strlit919 = alloc_String(" = undefined;");
  }
// compilenode returning strlit919
  params[0] = strlit919;
  Object opresult921 = callmethod(opresult918, "++", 1, params);
// compilenode returning opresult921
// Begin line 311
  setline(311);
// compilenode returning self
  params[0] = opresult921;
  Object call922 = callmethod(self, "out",
    1, params);
// compilenode returning call922
    if888 = call922;
  } else {
  }
// compilenode returning if888
  return if888;
}
Object meth_genc_apply929(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_ret = closure[0];
  Object self = *closure[1];
// Begin line 314
  setline(314);
// compilenode returning *var_l
// Begin line 315
  setline(315);
// compilenode returning self
  params[0] = *var_l;
  Object call930 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call930
  *var_ret = call930;
  if (call930 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply954(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_d = alloc_var();
  *var_d = args[0];
  Object params[1];
  Object *var_u = closure[0];
  Object *var_decl = closure[1];
  Object self = *closure[2];
// Begin line 326
  setline(326);
// Begin line 327
  setline(327);
// Begin line 324
  setline(324);
// compilenode returning *var_d
// compilenode returning *var_u
  params[0] = *var_u;
  Object opresult957 = callmethod(*var_d, "==", 1, params);
// compilenode returning opresult957
  Object if955;
  if (istrue(opresult957)) {
// Begin line 326
  setline(326);
// Begin line 325
  setline(325);
  Object bool958 = alloc_Boolean(1);
// compilenode returning bool958
  *var_decl = bool958;
  if (bool958 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if955 = nothing;
  } else {
  }
// compilenode returning if955
  return if955;
}
Object meth_genc_apply968(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_u = closure[0];
  Object *var_found = closure[1];
  Object self = *closure[2];
// Begin line 335
  setline(335);
// Begin line 336
  setline(336);
// Begin line 333
  setline(333);
// compilenode returning *var_v
// compilenode returning *var_u
  params[0] = *var_u;
  Object opresult971 = callmethod(*var_v, "==", 1, params);
// compilenode returning opresult971
  Object if969;
  if (istrue(opresult971)) {
// Begin line 335
  setline(335);
// Begin line 334
  setline(334);
  Object bool972 = alloc_Boolean(1);
// compilenode returning bool972
  *var_found = bool972;
  if (bool972 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if969 = nothing;
  } else {
  }
// compilenode returning if969
  return if969;
}
Object meth_genc_apply948(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_u = alloc_var();
  *var_u = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_closurevars = closure[1];
  Object self = *closure[2];
  Object *var_decl = alloc_var();
  *var_decl = undefined;
// Begin line 323
  setline(323);
// Begin line 322
  setline(322);
  Object bool949 = alloc_Boolean(0);
// compilenode returning bool949
  var_decl = alloc_var();
  *var_decl = bool949;
  if (bool949 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 326
  setline(326);
// Begin line 323
  setline(323);
// compilenode returning *var_declaredvars
// Begin line 326
  setline(326);
// Begin line 1035
  setline(1035);
  Object obj952 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj952, self, 0);
  addmethod2(obj952, "outer", &reader_genc_outer_953);
  adddatum2(obj952, self, 0);
  block_savedest(obj952);
  Object **closure954 = createclosure(3);
  addtoclosure(closure954, var_u);
  addtoclosure(closure954, var_decl);
  Object *selfpp960 = alloc_var();
  *selfpp960 = self;
  addtoclosure(closure954, selfpp960);
  struct UserObject *uo954 = (struct UserObject*)obj952;
  uo954->data[1] = (Object)closure954;
  addmethod2(obj952, "apply", &meth_genc_apply954);
  set_type(obj952, 0);
// compilenode returning obj952
  setclassname(obj952, "Block<genc:951>");
// compilenode returning obj952
  params[0] = *var_declaredvars;
  Object iter950 = callmethod(*var_declaredvars, "iter", 1, params);
  while(1) {
    Object cond950 = callmethod(iter950, "havemore", 0, NULL);
    if (!istrue(cond950)) break;
    params[0] = callmethod(iter950, "next", 0, NULL);
    callmethod(obj952, "apply", 1, params);
  }
// compilenode returning *var_declaredvars
// Begin line 340
  setline(340);
// Begin line 328
  setline(328);
// compilenode returning *var_decl
  Object if961;
  if (istrue(*var_decl)) {
// Begin line 330
  setline(330);
// Begin line 329
  setline(329);
// compilenode returning *var_decl
  *var_decl = *var_decl;
  if (*var_decl == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if961 = nothing;
  } else {
  Object *var_found = alloc_var();
  *var_found = undefined;
// Begin line 332
  setline(332);
// Begin line 331
  setline(331);
  Object bool963 = alloc_Boolean(0);
// compilenode returning bool963
  var_found = alloc_var();
  *var_found = bool963;
  if (bool963 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 335
  setline(335);
// Begin line 332
  setline(332);
// compilenode returning *var_closurevars
// Begin line 335
  setline(335);
// Begin line 1035
  setline(1035);
  Object obj966 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj966, self, 0);
  addmethod2(obj966, "outer", &reader_genc_outer_967);
  adddatum2(obj966, self, 0);
  block_savedest(obj966);
  Object **closure968 = createclosure(3);
  addtoclosure(closure968, var_u);
  addtoclosure(closure968, var_found);
  Object *selfpp974 = alloc_var();
  *selfpp974 = self;
  addtoclosure(closure968, selfpp974);
  struct UserObject *uo968 = (struct UserObject*)obj966;
  uo968->data[1] = (Object)closure968;
  addmethod2(obj966, "apply", &meth_genc_apply968);
  set_type(obj966, 0);
// compilenode returning obj966
  setclassname(obj966, "Block<genc:965>");
// compilenode returning obj966
  params[0] = *var_closurevars;
  Object iter964 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond964 = callmethod(iter964, "havemore", 0, NULL);
    if (!istrue(cond964)) break;
    params[0] = callmethod(iter964, "next", 0, NULL);
    callmethod(obj966, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 340
  setline(340);
// Begin line 337
  setline(337);
// compilenode returning *var_found
  Object if975;
  if (istrue(*var_found)) {
// Begin line 339
  setline(339);
// Begin line 338
  setline(338);
// compilenode returning *var_found
  *var_found = *var_found;
  if (*var_found == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if975 = nothing;
  } else {
// Begin line 340
  setline(340);
// compilenode returning *var_u
// compilenode returning *var_closurevars
  params[0] = *var_u;
  Object call977 = callmethod(*var_closurevars, "push",
    1, params);
// compilenode returning call977
    if975 = call977;
  }
// compilenode returning if975
    if961 = if975;
  }
// compilenode returning if961
  return if961;
}
Object meth_genc_apply1052(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_closurevars = closure[0];
  Object *var_i = closure[1];
  Object *var_toremove = closure[2];
  Object *var_declaredvars = closure[3];
  Object self = *closure[4];
  Object *var_pn = alloc_var();
  *var_pn = undefined;
// Begin line 370
  setline(370);
// Begin line 1035
  setline(1035);
// Begin line 370
  setline(370);
// compilenode returning *var_p
  Object call1053 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call1053
// compilenode returning call1053
// Begin line 371
  setline(371);
// compilenode returning self
  params[0] = call1053;
  Object call1054 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1054
  var_pn = alloc_var();
  *var_pn = call1054;
  if (call1054 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 376
  setline(376);
// Begin line 371
  setline(371);
// compilenode returning *var_pn
// compilenode returning *var_closurevars
  params[0] = *var_pn;
  Object call1056 = callmethod(*var_closurevars, "contains",
    1, params);
// compilenode returning call1056
  Object if1055;
  if (istrue(call1056)) {
// Begin line 372
  setline(372);
  if (strlit1057 == NULL) {
    strlit1057 = alloc_String("  Object *var_");
  }
// compilenode returning strlit1057
// compilenode returning *var_pn
  params[0] = *var_pn;
  Object opresult1059 = callmethod(strlit1057, "++", 1, params);
// compilenode returning opresult1059
  if (strlit1060 == NULL) {
    strlit1060 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit1060
  params[0] = strlit1060;
  Object opresult1062 = callmethod(opresult1059, "++", 1, params);
// compilenode returning opresult1062
// compilenode returning self
  params[0] = opresult1062;
  Object call1063 = callmethod(self, "out",
    1, params);
// compilenode returning call1063
// Begin line 373
  setline(373);
  if (strlit1064 == NULL) {
    strlit1064 = alloc_String("  *var_");
  }
// compilenode returning strlit1064
// compilenode returning *var_pn
  params[0] = *var_pn;
  Object opresult1066 = callmethod(strlit1064, "++", 1, params);
// compilenode returning opresult1066
  if (strlit1067 == NULL) {
    strlit1067 = alloc_String(" = args[");
  }
// compilenode returning strlit1067
  params[0] = strlit1067;
  Object opresult1069 = callmethod(opresult1066, "++", 1, params);
// compilenode returning opresult1069
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1071 = callmethod(opresult1069, "++", 1, params);
// compilenode returning opresult1071
  if (strlit1072 == NULL) {
    strlit1072 = alloc_String("];");
  }
// compilenode returning strlit1072
  params[0] = strlit1072;
  Object opresult1074 = callmethod(opresult1071, "++", 1, params);
// compilenode returning opresult1074
// compilenode returning self
  params[0] = opresult1074;
  Object call1075 = callmethod(self, "out",
    1, params);
// compilenode returning call1075
// Begin line 374
  setline(374);
// compilenode returning *var_pn
// compilenode returning *var_toremove
  params[0] = *var_pn;
  Object call1076 = callmethod(*var_toremove, "push",
    1, params);
// compilenode returning call1076
    if1055 = call1076;
  } else {
// Begin line 376
  setline(376);
  if (strlit1077 == NULL) {
    strlit1077 = alloc_String("  Object *var_");
  }
// compilenode returning strlit1077
// compilenode returning *var_pn
  params[0] = *var_pn;
  Object opresult1079 = callmethod(strlit1077, "++", 1, params);
// compilenode returning opresult1079
  if (strlit1080 == NULL) {
    strlit1080 = alloc_String(" = args + ");
  }
// compilenode returning strlit1080
  params[0] = strlit1080;
  Object opresult1082 = callmethod(opresult1079, "++", 1, params);
// compilenode returning opresult1082
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1084 = callmethod(opresult1082, "++", 1, params);
// compilenode returning opresult1084
  if (strlit1085 == NULL) {
    strlit1085 = alloc_String(";");
  }
// compilenode returning strlit1085
  params[0] = strlit1085;
  Object opresult1087 = callmethod(opresult1084, "++", 1, params);
// compilenode returning opresult1087
// Begin line 377
  setline(377);
// compilenode returning self
  params[0] = opresult1087;
  Object call1088 = callmethod(self, "out",
    1, params);
// compilenode returning call1088
    if1055 = call1088;
  }
// compilenode returning if1055
// Begin line 378
  setline(378);
// compilenode returning *var_pn
// compilenode returning *var_declaredvars
  params[0] = *var_pn;
  Object call1089 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1089
// Begin line 380
  setline(380);
// Begin line 379
  setline(379);
// compilenode returning *var_i
  Object num1090 = alloc_Float64(1.0);
// compilenode returning num1090
  params[0] = num1090;
  Object sum1092 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum1092
  *var_i = sum1092;
  if (sum1092 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply1101(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_pn = alloc_var();
  *var_pn = args[0];
  Object params[1];
  Object *var_toremove = closure[0];
  Object *var_closurevars = closure[1];
  Object self = *closure[2];
// Begin line 387
  setline(387);
// Begin line 384
  setline(384);
// compilenode returning *var_pn
// compilenode returning *var_toremove
  params[0] = *var_pn;
  Object call1103 = callmethod(*var_toremove, "contains",
    1, params);
// compilenode returning call1103
  Object if1102;
  if (istrue(call1103)) {
    if1102 = undefined;
  } else {
// Begin line 387
  setline(387);
// compilenode returning *var_pn
// compilenode returning *var_closurevars
  params[0] = *var_pn;
  Object call1104 = callmethod(*var_closurevars, "push",
    1, params);
// compilenode returning call1104
    if1102 = call1104;
  }
// compilenode returning if1102
  return if1102;
}
Object meth_genc_apply1118(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_cv = alloc_var();
  *var_cv = args[0];
  Object params[1];
  Object *var_j = closure[0];
  Object self = *closure[1];
// Begin line 396
  setline(396);
// Begin line 398
  setline(398);
// Begin line 393
  setline(393);
// compilenode returning *var_cv
  if (strlit1120 == NULL) {
    strlit1120 = alloc_String("self");
  }
// compilenode returning strlit1120
  params[0] = strlit1120;
  Object opresult1122 = callmethod(*var_cv, "==", 1, params);
// compilenode returning opresult1122
  Object if1119;
  if (istrue(opresult1122)) {
// Begin line 394
  setline(394);
  if (strlit1123 == NULL) {
    strlit1123 = alloc_String("  Object self = *closure[");
  }
// compilenode returning strlit1123
// compilenode returning *var_j
  params[0] = *var_j;
  Object opresult1125 = callmethod(strlit1123, "++", 1, params);
// compilenode returning opresult1125
  if (strlit1126 == NULL) {
    strlit1126 = alloc_String("];");
  }
// compilenode returning strlit1126
  params[0] = strlit1126;
  Object opresult1128 = callmethod(opresult1125, "++", 1, params);
// compilenode returning opresult1128
// Begin line 395
  setline(395);
// compilenode returning self
  params[0] = opresult1128;
  Object call1129 = callmethod(self, "out",
    1, params);
// compilenode returning call1129
    if1119 = call1129;
  } else {
// Begin line 396
  setline(396);
  if (strlit1130 == NULL) {
    strlit1130 = alloc_String("  Object *var_");
  }
// compilenode returning strlit1130
// compilenode returning *var_cv
  params[0] = *var_cv;
  Object opresult1132 = callmethod(strlit1130, "++", 1, params);
// compilenode returning opresult1132
  if (strlit1133 == NULL) {
    strlit1133 = alloc_String(" = closure[");
  }
// compilenode returning strlit1133
  params[0] = strlit1133;
  Object opresult1135 = callmethod(opresult1132, "++", 1, params);
// compilenode returning opresult1135
// compilenode returning *var_j
  params[0] = *var_j;
  Object opresult1137 = callmethod(opresult1135, "++", 1, params);
// compilenode returning opresult1137
  if (strlit1138 == NULL) {
    strlit1138 = alloc_String("];");
  }
// compilenode returning strlit1138
  params[0] = strlit1138;
  Object opresult1140 = callmethod(opresult1137, "++", 1, params);
// compilenode returning opresult1140
// Begin line 397
  setline(397);
// compilenode returning self
  params[0] = opresult1140;
  Object call1141 = callmethod(self, "out",
    1, params);
// compilenode returning call1141
    if1119 = call1141;
  }
// compilenode returning if1119
// Begin line 399
  setline(399);
// Begin line 398
  setline(398);
// compilenode returning *var_j
  Object num1142 = alloc_Float64(1.0);
// compilenode returning num1142
  params[0] = num1142;
  Object sum1144 = callmethod(*var_j, "+", 1, params);
// compilenode returning sum1144
  *var_j = sum1144;
  if (sum1144 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply1151(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 401
  setline(401);
// compilenode returning *var_l
// Begin line 402
  setline(402);
// compilenode returning self
  params[0] = *var_l;
  Object call1152 = callmethod(self, "out",
    1, params);
// compilenode returning call1152
  return call1152;
}
Object meth_genc_apply1163(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_cv = alloc_var();
  *var_cv = args[0];
  Object params[1];
  Object *var_usedvars = closure[0];
  Object self = *closure[1];
// Begin line 411
  setline(411);
// Begin line 414
  setline(414);
// Begin line 409
  setline(409);
// compilenode returning *var_cv
  if (strlit1165 == NULL) {
    strlit1165 = alloc_String("self");
  }
// compilenode returning strlit1165
  params[0] = strlit1165;
  Object opresult1167 = callmethod(*var_cv, "/=", 1, params);
// compilenode returning opresult1167
  Object if1164;
  if (istrue(opresult1167)) {
// Begin line 411
  setline(411);
// Begin line 410
  setline(410);
// Begin line 1035
  setline(1035);
// Begin line 410
  setline(410);
// compilenode returning *var_cv
// compilenode returning *var_usedvars
  params[0] = *var_cv;
  Object call1169 = callmethod(*var_usedvars, "contains",
    1, params);
// compilenode returning call1169
  Object call1170 = callmethod(call1169, "not",
    0, params);
// compilenode returning call1170
// compilenode returning call1170
  Object if1168;
  if (istrue(call1170)) {
// Begin line 411
  setline(411);
// compilenode returning *var_cv
// compilenode returning *var_usedvars
  params[0] = *var_cv;
  Object call1171 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call1171
    if1168 = call1171;
  } else {
  }
// compilenode returning if1168
    if1164 = if1168;
  } else {
  }
// compilenode returning if1164
  return if1164;
}
Object meth_genc_apply1224(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = closure[1];
  Object self = *closure[2];
// Begin line 430
  setline(430);
// Begin line 432
  setline(432);
// Begin line 423
  setline(423);
// compilenode returning *var_v
  if (strlit1226 == NULL) {
    strlit1226 = alloc_String("self");
  }
// compilenode returning strlit1226
  params[0] = strlit1226;
  Object opresult1228 = callmethod(*var_v, "==", 1, params);
// compilenode returning opresult1228
  Object if1225;
  if (istrue(opresult1228)) {
// Begin line 425
  setline(425);
// Begin line 424
  setline(424);
  if (strlit1229 == NULL) {
    strlit1229 = alloc_String("  Object *selfpp");
  }
// compilenode returning strlit1229
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1231 = callmethod(strlit1229, "++", 1, params);
// compilenode returning opresult1231
  if (strlit1232 == NULL) {
    strlit1232 = alloc_String(" = ");
  }
// compilenode returning strlit1232
  params[0] = strlit1232;
  Object opresult1234 = callmethod(opresult1231, "++", 1, params);
// compilenode returning opresult1234
// Begin line 425
  setline(425);
  if (strlit1235 == NULL) {
    strlit1235 = alloc_String("alloc_var();");
  }
// compilenode returning strlit1235
  params[0] = strlit1235;
  Object opresult1237 = callmethod(opresult1234, "++", 1, params);
// compilenode returning opresult1237
// Begin line 426
  setline(426);
// compilenode returning self
  params[0] = opresult1237;
  Object call1238 = callmethod(self, "out",
    1, params);
// compilenode returning call1238
  if (strlit1239 == NULL) {
    strlit1239 = alloc_String("  *selfpp");
  }
// compilenode returning strlit1239
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1241 = callmethod(strlit1239, "++", 1, params);
// compilenode returning opresult1241
  if (strlit1242 == NULL) {
    strlit1242 = alloc_String(" = self;");
  }
// compilenode returning strlit1242
  params[0] = strlit1242;
  Object opresult1244 = callmethod(opresult1241, "++", 1, params);
// compilenode returning opresult1244
// Begin line 427
  setline(427);
// compilenode returning self
  params[0] = opresult1244;
  Object call1245 = callmethod(self, "out",
    1, params);
// compilenode returning call1245
  if (strlit1246 == NULL) {
    strlit1246 = alloc_String("  addtoclosure(closure");
  }
// compilenode returning strlit1246
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1248 = callmethod(strlit1246, "++", 1, params);
// compilenode returning opresult1248
  if (strlit1249 == NULL) {
    strlit1249 = alloc_String(", selfpp");
  }
// compilenode returning strlit1249
  params[0] = strlit1249;
  Object opresult1251 = callmethod(opresult1248, "++", 1, params);
// compilenode returning opresult1251
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1253 = callmethod(opresult1251, "++", 1, params);
// compilenode returning opresult1253
  if (strlit1254 == NULL) {
    strlit1254 = alloc_String(");");
  }
// compilenode returning strlit1254
  params[0] = strlit1254;
  Object opresult1256 = callmethod(opresult1253, "++", 1, params);
// compilenode returning opresult1256
// Begin line 428
  setline(428);
// compilenode returning self
  params[0] = opresult1256;
  Object call1257 = callmethod(self, "out",
    1, params);
// compilenode returning call1257
// Begin line 429
  setline(429);
// Begin line 428
  setline(428);
// compilenode returning *var_auto_count
  Object num1258 = alloc_Float64(1.0);
// compilenode returning num1258
  params[0] = num1258;
  Object sum1260 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1260
  *var_auto_count = sum1260;
  if (sum1260 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1225 = nothing;
  } else {
// Begin line 430
  setline(430);
  if (strlit1262 == NULL) {
    strlit1262 = alloc_String("  addtoclosure(closure");
  }
// compilenode returning strlit1262
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1264 = callmethod(strlit1262, "++", 1, params);
// compilenode returning opresult1264
  if (strlit1265 == NULL) {
    strlit1265 = alloc_String(", var_");
  }
// compilenode returning strlit1265
  params[0] = strlit1265;
  Object opresult1267 = callmethod(opresult1264, "++", 1, params);
// compilenode returning opresult1267
// compilenode returning *var_v
  params[0] = *var_v;
  Object opresult1269 = callmethod(opresult1267, "++", 1, params);
// compilenode returning opresult1269
  if (strlit1270 == NULL) {
    strlit1270 = alloc_String(");");
  }
// compilenode returning strlit1270
  params[0] = strlit1270;
  Object opresult1272 = callmethod(opresult1269, "++", 1, params);
// compilenode returning opresult1272
// Begin line 431
  setline(431);
// compilenode returning self
  params[0] = opresult1272;
  Object call1273 = callmethod(self, "out",
    1, params);
// compilenode returning call1273
    if1225 = call1273;
  }
// compilenode returning if1225
  return if1225;
}
Object meth_genc_compilemethod823(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[18];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfobj = alloc_var();
  *var_selfobj = args[1];
  Object *var_pos = alloc_var();
  *var_pos = args[2];
  Object params[1];
  Object *var_paramsUsed = closure[0];
  Object *var_inBlock = closure[1];
  Object *var_output = closure[2];
  Object *var_bblock = closure[3];
  Object *var_usedvars = closure[4];
  Object *var_declaredvars = closure[5];
  Object *var_auto_count = closure[6];
  Object *var_modname = closure[7];
  Object *var_origParamsUsed = alloc_var();
  *var_origParamsUsed = undefined;
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_oldout = alloc_var();
  *var_oldout = undefined;
  Object *var_oldbblock = alloc_var();
  *var_oldbblock = undefined;
  Object *var_oldusedvars = alloc_var();
  *var_oldusedvars = undefined;
  Object *var_olddeclaredvars = alloc_var();
  *var_olddeclaredvars = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_name = alloc_var();
  *var_name = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
  Object *var_ret = alloc_var();
  *var_ret = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_closurevars = alloc_var();
  *var_closurevars = undefined;
  Object *var_litname = alloc_var();
  *var_litname = undefined;
  Object *var_toremove = alloc_var();
  *var_toremove = undefined;
  Object *var_origclosurevars = alloc_var();
  *var_origclosurevars = undefined;
  Object *var_j = alloc_var();
  *var_j = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
// Begin line 281
  setline(281);
// Begin line 280
  setline(280);
// compilenode returning *var_paramsUsed
  var_origParamsUsed = alloc_var();
  *var_origParamsUsed = *var_paramsUsed;
  if (*var_paramsUsed == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 282
  setline(282);
// Begin line 281
  setline(281);
  Object num824 = alloc_Float64(1.0);
// compilenode returning num824
  *var_paramsUsed = num824;
  if (num824 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 283
  setline(283);
// Begin line 282
  setline(282);
// compilenode returning *var_inBlock
  var_origInBlock = alloc_var();
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 284
  setline(284);
// Begin line 1035
  setline(1035);
// Begin line 283
  setline(283);
// compilenode returning *var_o
  Object call826 = callmethod(*var_o, "selfclosure",
    0, params);
// compilenode returning call826
// compilenode returning call826
  *var_inBlock = call826;
  if (call826 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 285
  setline(285);
// Begin line 284
  setline(284);
// compilenode returning *var_output
  var_oldout = alloc_var();
  *var_oldout = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 286
  setline(286);
// Begin line 285
  setline(285);
// compilenode returning *var_bblock
  var_oldbblock = alloc_var();
  *var_oldbblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 287
  setline(287);
// Begin line 286
  setline(286);
// compilenode returning *var_usedvars
  var_oldusedvars = alloc_var();
  *var_oldusedvars = *var_usedvars;
  if (*var_usedvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 288
  setline(288);
// Begin line 287
  setline(287);
// compilenode returning *var_declaredvars
  var_olddeclaredvars = alloc_var();
  *var_olddeclaredvars = *var_declaredvars;
  if (*var_declaredvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 289
  setline(289);
  Object array828 = alloc_List();
// compilenode returning array828
  *var_output = array828;
  if (array828 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 290
  setline(290);
  Object array830 = alloc_List();
// compilenode returning array830
  *var_usedvars = array830;
  if (array830 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 291
  setline(291);
  Object array832 = alloc_List();
// compilenode returning array832
  *var_declaredvars = array832;
  if (array832 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 292
  setline(292);
// Begin line 291
  setline(291);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 293
  setline(293);
// Begin line 292
  setline(292);
// compilenode returning *var_auto_count
  Object num834 = alloc_Float64(1.0);
// compilenode returning num834
  params[0] = num834;
  Object sum836 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum836
  *var_auto_count = sum836;
  if (sum836 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 294
  setline(294);
// Begin line 1035
  setline(1035);
// Begin line 294
  setline(294);
// Begin line 1035
  setline(1035);
// Begin line 293
  setline(293);
// compilenode returning *var_o
  Object call838 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call838
// compilenode returning call838
  Object call839 = callmethod(call838, "value",
    0, params);
// compilenode returning call839
// compilenode returning call839
  var_name = alloc_var();
  *var_name = call839;
  if (call839 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 295
  setline(295);
// Begin line 294
  setline(294);
// compilenode returning *var_name
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult841 = callmethod(*var_name, "++", 1, params);
// compilenode returning opresult841
  var_nm = alloc_var();
  *var_nm = opresult841;
  if (opresult841 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 296
  setline(296);
// Begin line 1035
  setline(1035);
// Begin line 296
  setline(296);
// Begin line 1035
  setline(1035);
// Begin line 295
  setline(295);
// compilenode returning *var_o
  Object call842 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call842
// compilenode returning call842
  Object call843 = callmethod(call842, "size",
    0, params);
// compilenode returning call843
// compilenode returning call843
  var_i = alloc_var();
  *var_i = call843;
  if (call843 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 301
  setline(301);
// Begin line 303
  setline(303);
// Begin line 1035
  setline(1035);
// Begin line 296
  setline(296);
// compilenode returning *var_o
  Object call845 = callmethod(*var_o, "varargs",
    0, params);
// compilenode returning call845
// compilenode returning call845
  Object if844;
  if (istrue(call845)) {
  Object *var_van = alloc_var();
  *var_van = undefined;
// Begin line 297
  setline(297);
// Begin line 1035
  setline(1035);
// Begin line 297
  setline(297);
// Begin line 1035
  setline(1035);
// Begin line 297
  setline(297);
// compilenode returning *var_o
  Object call846 = callmethod(*var_o, "vararg",
    0, params);
// compilenode returning call846
// compilenode returning call846
  Object call847 = callmethod(call846, "value",
    0, params);
// compilenode returning call847
// compilenode returning call847
// Begin line 298
  setline(298);
// compilenode returning self
  params[0] = call847;
  Object call848 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call848
  var_van = alloc_var();
  *var_van = call848;
  if (call848 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit849 == NULL) {
    strlit849 = alloc_String("  Object var_init_");
  }
// compilenode returning strlit849
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult851 = callmethod(strlit849, "++", 1, params);
// compilenode returning opresult851
  if (strlit852 == NULL) {
    strlit852 = alloc_String(" = process_varargs(args, ");
  }
// compilenode returning strlit852
  params[0] = strlit852;
  Object opresult854 = callmethod(opresult851, "++", 1, params);
// compilenode returning opresult854
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult856 = callmethod(opresult854, "++", 1, params);
// compilenode returning opresult856
  if (strlit857 == NULL) {
    strlit857 = alloc_String(", nparams);");
  }
// compilenode returning strlit857
  params[0] = strlit857;
  Object opresult859 = callmethod(opresult856, "++", 1, params);
// compilenode returning opresult859
// Begin line 299
  setline(299);
// compilenode returning self
  params[0] = opresult859;
  Object call860 = callmethod(self, "out",
    1, params);
// compilenode returning call860
  if (strlit861 == NULL) {
    strlit861 = alloc_String("  Object *var_");
  }
// compilenode returning strlit861
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult863 = callmethod(strlit861, "++", 1, params);
// compilenode returning opresult863
  if (strlit864 == NULL) {
    strlit864 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit864
  params[0] = strlit864;
  Object opresult866 = callmethod(opresult863, "++", 1, params);
// compilenode returning opresult866
// Begin line 300
  setline(300);
// compilenode returning self
  params[0] = opresult866;
  Object call867 = callmethod(self, "out",
    1, params);
// compilenode returning call867
  if (strlit868 == NULL) {
    strlit868 = alloc_String("  *var_");
  }
// compilenode returning strlit868
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult870 = callmethod(strlit868, "++", 1, params);
// compilenode returning opresult870
  if (strlit871 == NULL) {
    strlit871 = alloc_String(" = var_init_");
  }
// compilenode returning strlit871
  params[0] = strlit871;
  Object opresult873 = callmethod(opresult870, "++", 1, params);
// compilenode returning opresult873
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult875 = callmethod(opresult873, "++", 1, params);
// compilenode returning opresult875
  if (strlit876 == NULL) {
    strlit876 = alloc_String(";");
  }
// compilenode returning strlit876
  params[0] = strlit876;
  Object opresult878 = callmethod(opresult875, "++", 1, params);
// compilenode returning opresult878
// Begin line 301
  setline(301);
// compilenode returning self
  params[0] = opresult878;
  Object call879 = callmethod(self, "out",
    1, params);
// compilenode returning call879
// compilenode returning *var_van
// compilenode returning *var_declaredvars
  params[0] = *var_van;
  Object call880 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call880
    if844 = call880;
  } else {
  }
// compilenode returning if844
// Begin line 304
  setline(304);
// Begin line 303
  setline(303);
  if (strlit881 == NULL) {
    strlit881 = alloc_String("nothing");
  }
// compilenode returning strlit881
  var_ret = alloc_var();
  *var_ret = strlit881;
  if (strlit881 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 310
  setline(310);
// Begin line 313
  setline(313);
// Begin line 1035
  setline(1035);
// Begin line 304
  setline(304);
// compilenode returning *var_o
  Object call883 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call883
// compilenode returning call883
// Begin line 310
  setline(310);
// Begin line 1035
  setline(1035);
  Object obj885 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj885, self, 0);
  addmethod2(obj885, "outer", &reader_genc_outer_886);
  adddatum2(obj885, self, 0);
  block_savedest(obj885);
  Object **closure887 = createclosure(2);
  addtoclosure(closure887, var_declaredvars);
  Object *selfpp923 = alloc_var();
  *selfpp923 = self;
  addtoclosure(closure887, selfpp923);
  struct UserObject *uo887 = (struct UserObject*)obj885;
  uo887->data[1] = (Object)closure887;
  addmethod2(obj885, "apply", &meth_genc_apply887);
  set_type(obj885, 0);
// compilenode returning obj885
  setclassname(obj885, "Block<genc:884>");
// compilenode returning obj885
  params[0] = call883;
  Object iter882 = callmethod(call883, "iter", 1, params);
  while(1) {
    Object cond882 = callmethod(iter882, "havemore", 0, NULL);
    if (!istrue(cond882)) break;
    params[0] = callmethod(iter882, "next", 0, NULL);
    callmethod(obj885, "apply", 1, params);
  }
// compilenode returning call883
// Begin line 314
  setline(314);
// Begin line 316
  setline(316);
// Begin line 1035
  setline(1035);
// Begin line 313
  setline(313);
// compilenode returning *var_o
  Object call925 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call925
// compilenode returning call925
// Begin line 314
  setline(314);
// Begin line 1035
  setline(1035);
  Object obj927 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj927, self, 0);
  addmethod2(obj927, "outer", &reader_genc_outer_928);
  adddatum2(obj927, self, 0);
  block_savedest(obj927);
  Object **closure929 = createclosure(2);
  addtoclosure(closure929, var_ret);
  Object *selfpp932 = alloc_var();
  *selfpp932 = self;
  addtoclosure(closure929, selfpp932);
  struct UserObject *uo929 = (struct UserObject*)obj927;
  uo929->data[1] = (Object)closure929;
  addmethod2(obj927, "apply", &meth_genc_apply929);
  set_type(obj927, 0);
// compilenode returning obj927
  setclassname(obj927, "Block<genc:926>");
// compilenode returning obj927
  params[0] = call925;
  Object iter924 = callmethod(call925, "iter", 1, params);
  while(1) {
    Object cond924 = callmethod(iter924, "havemore", 0, NULL);
    if (!istrue(cond924)) break;
    params[0] = callmethod(iter924, "next", 0, NULL);
    callmethod(obj927, "apply", 1, params);
  }
// compilenode returning call925
// Begin line 316
  setline(316);
  if (strlit933 == NULL) {
    strlit933 = alloc_String("  return ");
  }
// compilenode returning strlit933
// compilenode returning *var_ret
  params[0] = *var_ret;
  Object opresult935 = callmethod(strlit933, "++", 1, params);
// compilenode returning opresult935
  if (strlit936 == NULL) {
    strlit936 = alloc_String(";");
  }
// compilenode returning strlit936
  params[0] = strlit936;
  Object opresult938 = callmethod(opresult935, "++", 1, params);
// compilenode returning opresult938
// Begin line 317
  setline(317);
// compilenode returning self
  params[0] = opresult938;
  Object call939 = callmethod(self, "out",
    1, params);
// compilenode returning call939
  if (strlit940 == NULL) {
    strlit940 = alloc_String("}");
  }
// compilenode returning strlit940
// Begin line 318
  setline(318);
// compilenode returning self
  params[0] = strlit940;
  Object call941 = callmethod(self, "out",
    1, params);
// compilenode returning call941
// Begin line 319
  setline(319);
// Begin line 318
  setline(318);
// compilenode returning *var_output
  var_body = alloc_var();
  *var_body = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 319
  setline(319);
// compilenode returning self
  Object call942 = callmethod(self, "outswitchup",
    0, params);
// compilenode returning call942
// Begin line 321
  setline(321);
  Object array943 = alloc_List();
// compilenode returning array943
  var_closurevars = alloc_var();
  *var_closurevars = array943;
  if (array943 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 340
  setline(340);
// Begin line 321
  setline(321);
// compilenode returning *var_usedvars
// Begin line 340
  setline(340);
// Begin line 1035
  setline(1035);
  Object obj946 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj946, self, 0);
  addmethod2(obj946, "outer", &reader_genc_outer_947);
  adddatum2(obj946, self, 0);
  block_savedest(obj946);
  Object **closure948 = createclosure(3);
  addtoclosure(closure948, var_declaredvars);
  addtoclosure(closure948, var_closurevars);
  Object *selfpp978 = alloc_var();
  *selfpp978 = self;
  addtoclosure(closure948, selfpp978);
  struct UserObject *uo948 = (struct UserObject*)obj946;
  uo948->data[1] = (Object)closure948;
  addmethod2(obj946, "apply", &meth_genc_apply948);
  set_type(obj946, 0);
// compilenode returning obj946
  setclassname(obj946, "Block<genc:945>");
// compilenode returning obj946
  params[0] = *var_usedvars;
  Object iter944 = callmethod(*var_usedvars, "iter", 1, params);
  while(1) {
    Object cond944 = callmethod(iter944, "havemore", 0, NULL);
    if (!istrue(cond944)) break;
    params[0] = callmethod(iter944, "next", 0, NULL);
    callmethod(obj946, "apply", 1, params);
  }
// compilenode returning *var_usedvars
// Begin line 345
  setline(345);
// Begin line 347
  setline(347);
// Begin line 1035
  setline(1035);
// Begin line 344
  setline(344);
// compilenode returning *var_o
  Object call980 = callmethod(*var_o, "selfclosure",
    0, params);
// compilenode returning call980
// compilenode returning call980
  Object if979;
  if (istrue(call980)) {
// Begin line 345
  setline(345);
  if (strlit981 == NULL) {
    strlit981 = alloc_String("self");
  }
// compilenode returning strlit981
// compilenode returning *var_closurevars
  params[0] = strlit981;
  Object call982 = callmethod(*var_closurevars, "push",
    1, params);
// compilenode returning call982
    if979 = call982;
  } else {
  }
// compilenode returning if979
// Begin line 347
  setline(347);
  if (strlit983 == NULL) {
    strlit983 = alloc_String("meth_");
  }
// compilenode returning strlit983
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult985 = callmethod(strlit983, "++", 1, params);
// compilenode returning opresult985
  if (strlit986 == NULL) {
    strlit986 = alloc_String("_");
  }
// compilenode returning strlit986
  params[0] = strlit986;
  Object opresult988 = callmethod(opresult985, "++", 1, params);
// compilenode returning opresult988
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call989 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call989
  params[0] = call989;
  Object opresult991 = callmethod(opresult988, "++", 1, params);
// compilenode returning opresult991
  if (strlit992 == NULL) {
    strlit992 = alloc_String("");
  }
// compilenode returning strlit992
  params[0] = strlit992;
  Object opresult994 = callmethod(opresult991, "++", 1, params);
// compilenode returning opresult994
// Begin line 348
  setline(348);
// compilenode returning self
  params[0] = opresult994;
  Object call995 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call995
  var_litname = alloc_var();
  *var_litname = call995;
  if (call995 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 361
  setline(361);
// Begin line 367
  setline(367);
// Begin line 1035
  setline(1035);
// Begin line 348
  setline(348);
// compilenode returning *var_closurevars
  Object call997 = callmethod(*var_closurevars, "size",
    0, params);
// compilenode returning call997
// compilenode returning call997
  Object num998 = alloc_Float64(0.0);
// compilenode returning num998
  params[0] = num998;
  Object opresult1000 = callmethod(call997, ">", 1, params);
// compilenode returning opresult1000
  Object if996;
  if (istrue(opresult1000)) {
// Begin line 356
  setline(356);
// Begin line 358
  setline(358);
// Begin line 1035
  setline(1035);
// Begin line 349
  setline(349);
// compilenode returning *var_o
  Object call1002 = callmethod(*var_o, "selfclosure",
    0, params);
// compilenode returning call1002
// compilenode returning call1002
  Object if1001;
  if (istrue(call1002)) {
// Begin line 351
  setline(351);
// Begin line 350
  setline(350);
  if (strlit1003 == NULL) {
    strlit1003 = alloc_String("Object ");
  }
// compilenode returning strlit1003
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1005 = callmethod(strlit1003, "++", 1, params);
// compilenode returning opresult1005
  if (strlit1006 == NULL) {
    strlit1006 = alloc_String("(Object realself, int nparams, ");
  }
// compilenode returning strlit1006
  params[0] = strlit1006;
  Object opresult1008 = callmethod(opresult1005, "++", 1, params);
// compilenode returning opresult1008
// Begin line 351
  setline(351);
  if (strlit1009 == NULL) {
    strlit1009 = alloc_String("Object *args, int32_t flags) {");
  }
// compilenode returning strlit1009
  params[0] = strlit1009;
  Object opresult1011 = callmethod(opresult1008, "++", 1, params);
// compilenode returning opresult1011
// Begin line 352
  setline(352);
// compilenode returning self
  params[0] = opresult1011;
  Object call1012 = callmethod(self, "out",
    1, params);
// compilenode returning call1012
  if (strlit1013 == NULL) {
    strlit1013 = alloc_String("  struct UserObject *uo = (struct UserObject*)realself;");
  }
// compilenode returning strlit1013
// Begin line 353
  setline(353);
// compilenode returning self
  params[0] = strlit1013;
  Object call1014 = callmethod(self, "out",
    1, params);
// compilenode returning call1014
    if1001 = call1014;
  } else {
// Begin line 355
  setline(355);
// Begin line 354
  setline(354);
  if (strlit1015 == NULL) {
    strlit1015 = alloc_String("Object ");
  }
// compilenode returning strlit1015
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1017 = callmethod(strlit1015, "++", 1, params);
// compilenode returning opresult1017
  if (strlit1018 == NULL) {
    strlit1018 = alloc_String("(Object self, int nparams, Object *args, ");
  }
// compilenode returning strlit1018
  params[0] = strlit1018;
  Object opresult1020 = callmethod(opresult1017, "++", 1, params);
// compilenode returning opresult1020
// Begin line 355
  setline(355);
  if (strlit1021 == NULL) {
    strlit1021 = alloc_String("int32_t flags) {");
  }
// compilenode returning strlit1021
  params[0] = strlit1021;
  Object opresult1023 = callmethod(opresult1020, "++", 1, params);
// compilenode returning opresult1023
// Begin line 356
  setline(356);
// compilenode returning self
  params[0] = opresult1023;
  Object call1024 = callmethod(self, "out",
    1, params);
// compilenode returning call1024
  if (strlit1025 == NULL) {
    strlit1025 = alloc_String("  struct UserObject *uo = (struct UserObject*)self;");
  }
// compilenode returning strlit1025
// Begin line 357
  setline(357);
// compilenode returning self
  params[0] = strlit1025;
  Object call1026 = callmethod(self, "out",
    1, params);
// compilenode returning call1026
    if1001 = call1026;
  }
// compilenode returning if1001
// Begin line 358
  setline(358);
  if (strlit1027 == NULL) {
    strlit1027 = alloc_String("  Object **closure = uo->data[");
  }
// compilenode returning strlit1027
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult1029 = callmethod(strlit1027, "++", 1, params);
// compilenode returning opresult1029
  if (strlit1030 == NULL) {
    strlit1030 = alloc_String("];");
  }
// compilenode returning strlit1030
  params[0] = strlit1030;
  Object opresult1032 = callmethod(opresult1029, "++", 1, params);
// compilenode returning opresult1032
// Begin line 359
  setline(359);
// compilenode returning self
  params[0] = opresult1032;
  Object call1033 = callmethod(self, "out",
    1, params);
// compilenode returning call1033
    if996 = call1033;
  } else {
// Begin line 361
  setline(361);
// Begin line 360
  setline(360);
  if (strlit1034 == NULL) {
    strlit1034 = alloc_String("Object ");
  }
// compilenode returning strlit1034
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1036 = callmethod(strlit1034, "++", 1, params);
// compilenode returning opresult1036
  if (strlit1037 == NULL) {
    strlit1037 = alloc_String("(Object self, int nparams, Object *args, ");
  }
// compilenode returning strlit1037
  params[0] = strlit1037;
  Object opresult1039 = callmethod(opresult1036, "++", 1, params);
// compilenode returning opresult1039
// Begin line 361
  setline(361);
  if (strlit1040 == NULL) {
    strlit1040 = alloc_String("int32_t flags) {");
  }
// compilenode returning strlit1040
  params[0] = strlit1040;
  Object opresult1042 = callmethod(opresult1039, "++", 1, params);
// compilenode returning opresult1042
// Begin line 362
  setline(362);
// compilenode returning self
  params[0] = opresult1042;
  Object call1043 = callmethod(self, "out",
    1, params);
// compilenode returning call1043
    if996 = call1043;
  }
// compilenode returning if996
// Begin line 368
  setline(368);
// Begin line 367
  setline(367);
  Object num1044 = alloc_Float64(0.0);
// compilenode returning num1044
  *var_i = num1044;
  if (num1044 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 369
  setline(369);
  Object array1046 = alloc_List();
// compilenode returning array1046
  *var_toremove = array1046;
  if (array1046 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 380
  setline(380);
// Begin line 381
  setline(381);
// Begin line 1035
  setline(1035);
// Begin line 369
  setline(369);
// compilenode returning *var_o
  Object call1048 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call1048
// compilenode returning call1048
// Begin line 380
  setline(380);
// Begin line 1035
  setline(1035);
  Object obj1050 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1050, self, 0);
  addmethod2(obj1050, "outer", &reader_genc_outer_1051);
  adddatum2(obj1050, self, 0);
  block_savedest(obj1050);
  Object **closure1052 = createclosure(5);
  addtoclosure(closure1052, var_closurevars);
  addtoclosure(closure1052, var_i);
  addtoclosure(closure1052, var_toremove);
  addtoclosure(closure1052, var_declaredvars);
  Object *selfpp1094 = alloc_var();
  *selfpp1094 = self;
  addtoclosure(closure1052, selfpp1094);
  struct UserObject *uo1052 = (struct UserObject*)obj1050;
  uo1052->data[1] = (Object)closure1052;
  addmethod2(obj1050, "apply", &meth_genc_apply1052);
  set_type(obj1050, 0);
// compilenode returning obj1050
  setclassname(obj1050, "Block<genc:1049>");
// compilenode returning obj1050
  params[0] = call1048;
  Object iter1047 = callmethod(call1048, "iter", 1, params);
  while(1) {
    Object cond1047 = callmethod(iter1047, "havemore", 0, NULL);
    if (!istrue(cond1047)) break;
    params[0] = callmethod(iter1047, "next", 0, NULL);
    callmethod(obj1050, "apply", 1, params);
  }
// compilenode returning call1048
// Begin line 382
  setline(382);
// Begin line 381
  setline(381);
// compilenode returning *var_closurevars
  *var_origclosurevars = *var_closurevars;
  if (*var_closurevars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 383
  setline(383);
  Object array1095 = alloc_List();
// compilenode returning array1095
  *var_closurevars = array1095;
  if (array1095 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 387
  setline(387);
// Begin line 383
  setline(383);
// compilenode returning *var_origclosurevars
// Begin line 387
  setline(387);
// Begin line 1035
  setline(1035);
  Object obj1099 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1099, self, 0);
  addmethod2(obj1099, "outer", &reader_genc_outer_1100);
  adddatum2(obj1099, self, 0);
  block_savedest(obj1099);
  Object **closure1101 = createclosure(3);
  addtoclosure(closure1101, var_toremove);
  addtoclosure(closure1101, var_closurevars);
  Object *selfpp1105 = alloc_var();
  *selfpp1105 = self;
  addtoclosure(closure1101, selfpp1105);
  struct UserObject *uo1101 = (struct UserObject*)obj1099;
  uo1101->data[1] = (Object)closure1101;
  addmethod2(obj1099, "apply", &meth_genc_apply1101);
  set_type(obj1099, 0);
// compilenode returning obj1099
  setclassname(obj1099, "Block<genc:1098>");
// compilenode returning obj1099
  params[0] = *var_origclosurevars;
  Object iter1097 = callmethod(*var_origclosurevars, "iter", 1, params);
  while(1) {
    Object cond1097 = callmethod(iter1097, "havemore", 0, NULL);
    if (!istrue(cond1097)) break;
    params[0] = callmethod(iter1097, "next", 0, NULL);
    callmethod(obj1099, "apply", 1, params);
  }
// compilenode returning *var_origclosurevars
// Begin line 390
  setline(390);
  if (strlit1106 == NULL) {
    strlit1106 = alloc_String("  Object params[");
  }
// compilenode returning strlit1106
// compilenode returning *var_paramsUsed
  params[0] = *var_paramsUsed;
  Object opresult1108 = callmethod(strlit1106, "++", 1, params);
// compilenode returning opresult1108
  if (strlit1109 == NULL) {
    strlit1109 = alloc_String("];");
  }
// compilenode returning strlit1109
  params[0] = strlit1109;
  Object opresult1111 = callmethod(opresult1108, "++", 1, params);
// compilenode returning opresult1111
// Begin line 391
  setline(391);
// compilenode returning self
  params[0] = opresult1111;
  Object call1112 = callmethod(self, "out",
    1, params);
// compilenode returning call1112
// Begin line 392
  setline(392);
// Begin line 391
  setline(391);
  Object num1113 = alloc_Float64(0.0);
// compilenode returning num1113
  var_j = alloc_var();
  *var_j = num1113;
  if (num1113 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 399
  setline(399);
// Begin line 392
  setline(392);
// compilenode returning *var_closurevars
// Begin line 399
  setline(399);
// Begin line 1035
  setline(1035);
  Object obj1116 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1116, self, 0);
  addmethod2(obj1116, "outer", &reader_genc_outer_1117);
  adddatum2(obj1116, self, 0);
  block_savedest(obj1116);
  Object **closure1118 = createclosure(2);
  addtoclosure(closure1118, var_j);
  Object *selfpp1146 = alloc_var();
  *selfpp1146 = self;
  addtoclosure(closure1118, selfpp1146);
  struct UserObject *uo1118 = (struct UserObject*)obj1116;
  uo1118->data[1] = (Object)closure1118;
  addmethod2(obj1116, "apply", &meth_genc_apply1118);
  set_type(obj1116, 0);
// compilenode returning obj1116
  setclassname(obj1116, "Block<genc:1115>");
// compilenode returning obj1116
  params[0] = *var_closurevars;
  Object iter1114 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1114 = callmethod(iter1114, "havemore", 0, NULL);
    if (!istrue(cond1114)) break;
    params[0] = callmethod(iter1114, "next", 0, NULL);
    callmethod(obj1116, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 401
  setline(401);
// Begin line 400
  setline(400);
// compilenode returning *var_body
// Begin line 401
  setline(401);
// Begin line 1035
  setline(1035);
  Object obj1149 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1149, self, 0);
  addmethod2(obj1149, "outer", &reader_genc_outer_1150);
  adddatum2(obj1149, self, 0);
  block_savedest(obj1149);
  Object **closure1151 = createclosure(1);
  Object *selfpp1153 = alloc_var();
  *selfpp1153 = self;
  addtoclosure(closure1151, selfpp1153);
  struct UserObject *uo1151 = (struct UserObject*)obj1149;
  uo1151->data[1] = (Object)closure1151;
  addmethod2(obj1149, "apply", &meth_genc_apply1151);
  set_type(obj1149, 0);
// compilenode returning obj1149
  setclassname(obj1149, "Block<genc:1148>");
// compilenode returning obj1149
  params[0] = *var_body;
  Object iter1147 = callmethod(*var_body, "iter", 1, params);
  while(1) {
    Object cond1147 = callmethod(iter1147, "havemore", 0, NULL);
    if (!istrue(cond1147)) break;
    params[0] = callmethod(iter1147, "next", 0, NULL);
    callmethod(obj1149, "apply", 1, params);
  }
// compilenode returning *var_body
// Begin line 403
  setline(403);
// compilenode returning self
  Object call1154 = callmethod(self, "outswitchdown",
    0, params);
// compilenode returning call1154
// Begin line 405
  setline(405);
// Begin line 404
  setline(404);
// compilenode returning *var_oldout
  *var_output = *var_oldout;
  if (*var_oldout == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 406
  setline(406);
// Begin line 405
  setline(405);
// compilenode returning *var_oldbblock
  *var_bblock = *var_oldbblock;
  if (*var_oldbblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 407
  setline(407);
// Begin line 406
  setline(406);
// compilenode returning *var_oldusedvars
  *var_usedvars = *var_oldusedvars;
  if (*var_oldusedvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 408
  setline(408);
// Begin line 407
  setline(407);
// compilenode returning *var_olddeclaredvars
  *var_declaredvars = *var_olddeclaredvars;
  if (*var_olddeclaredvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 411
  setline(411);
// Begin line 408
  setline(408);
// compilenode returning *var_closurevars
// Begin line 411
  setline(411);
// Begin line 1035
  setline(1035);
  Object obj1161 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1161, self, 0);
  addmethod2(obj1161, "outer", &reader_genc_outer_1162);
  adddatum2(obj1161, self, 0);
  block_savedest(obj1161);
  Object **closure1163 = createclosure(2);
  addtoclosure(closure1163, var_usedvars);
  Object *selfpp1172 = alloc_var();
  *selfpp1172 = self;
  addtoclosure(closure1163, selfpp1172);
  struct UserObject *uo1163 = (struct UserObject*)obj1161;
  uo1163->data[1] = (Object)closure1163;
  addmethod2(obj1161, "apply", &meth_genc_apply1163);
  set_type(obj1161, 0);
// compilenode returning obj1161
  setclassname(obj1161, "Block<genc:1160>");
// compilenode returning obj1161
  params[0] = *var_closurevars;
  Object iter1159 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1159 = callmethod(iter1159, "havemore", 0, NULL);
    if (!istrue(cond1159)) break;
    params[0] = callmethod(iter1159, "next", 0, NULL);
    callmethod(obj1161, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 415
  setline(415);
// compilenode returning *var_name
  Object call1173 = gracelib_length(*var_name);
// compilenode returning call1173
  Object num1174 = alloc_Float64(1.0);
// compilenode returning num1174
  params[0] = num1174;
  Object sum1176 = callmethod(call1173, "+", 1, params);
// compilenode returning sum1176
  var_len = alloc_var();
  *var_len = sum1176;
  if (sum1176 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 436
  setline(436);
// Begin line 438
  setline(438);
// Begin line 1035
  setline(1035);
// Begin line 416
  setline(416);
// compilenode returning *var_closurevars
  Object call1178 = callmethod(*var_closurevars, "size",
    0, params);
// compilenode returning call1178
// compilenode returning call1178
  Object num1179 = alloc_Float64(0.0);
// compilenode returning num1179
  params[0] = num1179;
  Object opresult1181 = callmethod(call1178, "==", 1, params);
// compilenode returning opresult1181
  Object if1177;
  if (istrue(opresult1181)) {
// Begin line 417
  setline(417);
  if (strlit1182 == NULL) {
    strlit1182 = alloc_String("  addmethod2(");
  }
// compilenode returning strlit1182
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1184 = callmethod(strlit1182, "++", 1, params);
// compilenode returning opresult1184
  if (strlit1185 == NULL) {
    strlit1185 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit1185
  params[0] = strlit1185;
  Object opresult1187 = callmethod(opresult1184, "++", 1, params);
// compilenode returning opresult1187
// compilenode returning *var_name
// compilenode returning self
  params[0] = *var_name;
  Object call1188 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call1188
  params[0] = call1188;
  Object opresult1190 = callmethod(opresult1187, "++", 1, params);
// compilenode returning opresult1190
  if (strlit1191 == NULL) {
    strlit1191 = alloc_String("""\x22"", &");
  }
// compilenode returning strlit1191
  params[0] = strlit1191;
  Object opresult1193 = callmethod(opresult1190, "++", 1, params);
// compilenode returning opresult1193
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1195 = callmethod(opresult1193, "++", 1, params);
// compilenode returning opresult1195
  if (strlit1196 == NULL) {
    strlit1196 = alloc_String(");");
  }
// compilenode returning strlit1196
  params[0] = strlit1196;
  Object opresult1198 = callmethod(opresult1195, "++", 1, params);
// compilenode returning opresult1198
// Begin line 418
  setline(418);
// compilenode returning self
  params[0] = opresult1198;
  Object call1199 = callmethod(self, "out",
    1, params);
// compilenode returning call1199
    if1177 = call1199;
  } else {
  Object *var_uo = alloc_var();
  *var_uo = undefined;
// Begin line 419
  setline(419);
  if (strlit1200 == NULL) {
    strlit1200 = alloc_String("  block_savedest(");
  }
// compilenode returning strlit1200
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1202 = callmethod(strlit1200, "++", 1, params);
// compilenode returning opresult1202
  if (strlit1203 == NULL) {
    strlit1203 = alloc_String(");");
  }
// compilenode returning strlit1203
  params[0] = strlit1203;
  Object opresult1205 = callmethod(opresult1202, "++", 1, params);
// compilenode returning opresult1205
// Begin line 420
  setline(420);
// compilenode returning self
  params[0] = opresult1205;
  Object call1206 = callmethod(self, "out",
    1, params);
// compilenode returning call1206
// Begin line 421
  setline(421);
// Begin line 420
  setline(420);
  if (strlit1207 == NULL) {
    strlit1207 = alloc_String("  Object **closure");
  }
// compilenode returning strlit1207
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1209 = callmethod(strlit1207, "++", 1, params);
// compilenode returning opresult1209
  if (strlit1210 == NULL) {
    strlit1210 = alloc_String(" = createclosure(");
  }
// compilenode returning strlit1210
  params[0] = strlit1210;
  Object opresult1212 = callmethod(opresult1209, "++", 1, params);
// compilenode returning opresult1212
// Begin line 421
  setline(421);
// Begin line 1035
  setline(1035);
// Begin line 421
  setline(421);
// compilenode returning *var_closurevars
  Object call1213 = callmethod(*var_closurevars, "size",
    0, params);
// compilenode returning call1213
// compilenode returning call1213
  params[0] = call1213;
  Object opresult1215 = callmethod(opresult1212, "++", 1, params);
// compilenode returning opresult1215
  if (strlit1216 == NULL) {
    strlit1216 = alloc_String(");");
  }
// compilenode returning strlit1216
  params[0] = strlit1216;
  Object opresult1218 = callmethod(opresult1215, "++", 1, params);
// compilenode returning opresult1218
// Begin line 422
  setline(422);
// compilenode returning self
  params[0] = opresult1218;
  Object call1219 = callmethod(self, "out",
    1, params);
// compilenode returning call1219
// Begin line 430
  setline(430);
// Begin line 422
  setline(422);
// compilenode returning *var_closurevars
// Begin line 430
  setline(430);
// Begin line 1035
  setline(1035);
  Object obj1222 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1222, self, 0);
  addmethod2(obj1222, "outer", &reader_genc_outer_1223);
  adddatum2(obj1222, self, 0);
  block_savedest(obj1222);
  Object **closure1224 = createclosure(3);
  addtoclosure(closure1224, var_auto_count);
  addtoclosure(closure1224, var_myc);
  Object *selfpp1274 = alloc_var();
  *selfpp1274 = self;
  addtoclosure(closure1224, selfpp1274);
  struct UserObject *uo1224 = (struct UserObject*)obj1222;
  uo1224->data[1] = (Object)closure1224;
  addmethod2(obj1222, "apply", &meth_genc_apply1224);
  set_type(obj1222, 0);
// compilenode returning obj1222
  setclassname(obj1222, "Block<genc:1221>");
// compilenode returning obj1222
  params[0] = *var_closurevars;
  Object iter1220 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1220 = callmethod(iter1220, "havemore", 0, NULL);
    if (!istrue(cond1220)) break;
    params[0] = callmethod(iter1220, "next", 0, NULL);
    callmethod(obj1222, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 434
  setline(434);
// Begin line 433
  setline(433);
  if (strlit1275 == NULL) {
    strlit1275 = alloc_String("uo");
  }
// compilenode returning strlit1275
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1277 = callmethod(strlit1275, "++", 1, params);
// compilenode returning opresult1277
  if (strlit1278 == NULL) {
    strlit1278 = alloc_String("");
  }
// compilenode returning strlit1278
  params[0] = strlit1278;
  Object opresult1280 = callmethod(opresult1277, "++", 1, params);
// compilenode returning opresult1280
  var_uo = alloc_var();
  *var_uo = opresult1280;
  if (opresult1280 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 434
  setline(434);
  if (strlit1281 == NULL) {
    strlit1281 = alloc_String("  struct UserObject *");
  }
// compilenode returning strlit1281
// compilenode returning *var_uo
  params[0] = *var_uo;
  Object opresult1283 = callmethod(strlit1281, "++", 1, params);
// compilenode returning opresult1283
  if (strlit1284 == NULL) {
    strlit1284 = alloc_String(" = (struct UserObject*)");
  }
// compilenode returning strlit1284
  params[0] = strlit1284;
  Object opresult1286 = callmethod(opresult1283, "++", 1, params);
// compilenode returning opresult1286
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1288 = callmethod(opresult1286, "++", 1, params);
// compilenode returning opresult1288
  if (strlit1289 == NULL) {
    strlit1289 = alloc_String(";");
  }
// compilenode returning strlit1289
  params[0] = strlit1289;
  Object opresult1291 = callmethod(opresult1288, "++", 1, params);
// compilenode returning opresult1291
// Begin line 435
  setline(435);
// compilenode returning self
  params[0] = opresult1291;
  Object call1292 = callmethod(self, "out",
    1, params);
// compilenode returning call1292
  if (strlit1293 == NULL) {
    strlit1293 = alloc_String("  ");
  }
// compilenode returning strlit1293
// compilenode returning *var_uo
  params[0] = *var_uo;
  Object opresult1295 = callmethod(strlit1293, "++", 1, params);
// compilenode returning opresult1295
  if (strlit1296 == NULL) {
    strlit1296 = alloc_String("->data[");
  }
// compilenode returning strlit1296
  params[0] = strlit1296;
  Object opresult1298 = callmethod(opresult1295, "++", 1, params);
// compilenode returning opresult1298
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult1300 = callmethod(opresult1298, "++", 1, params);
// compilenode returning opresult1300
  if (strlit1301 == NULL) {
    strlit1301 = alloc_String("] = (Object)closure");
  }
// compilenode returning strlit1301
  params[0] = strlit1301;
  Object opresult1303 = callmethod(opresult1300, "++", 1, params);
// compilenode returning opresult1303
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1305 = callmethod(opresult1303, "++", 1, params);
// compilenode returning opresult1305
  if (strlit1306 == NULL) {
    strlit1306 = alloc_String(";");
  }
// compilenode returning strlit1306
  params[0] = strlit1306;
  Object opresult1308 = callmethod(opresult1305, "++", 1, params);
// compilenode returning opresult1308
// Begin line 436
  setline(436);
// compilenode returning self
  params[0] = opresult1308;
  Object call1309 = callmethod(self, "out",
    1, params);
// compilenode returning call1309
  if (strlit1310 == NULL) {
    strlit1310 = alloc_String("  addmethod2(");
  }
// compilenode returning strlit1310
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1312 = callmethod(strlit1310, "++", 1, params);
// compilenode returning opresult1312
  if (strlit1313 == NULL) {
    strlit1313 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit1313
  params[0] = strlit1313;
  Object opresult1315 = callmethod(opresult1312, "++", 1, params);
// compilenode returning opresult1315
// compilenode returning *var_name
// compilenode returning self
  params[0] = *var_name;
  Object call1316 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call1316
  params[0] = call1316;
  Object opresult1318 = callmethod(opresult1315, "++", 1, params);
// compilenode returning opresult1318
  if (strlit1319 == NULL) {
    strlit1319 = alloc_String("""\x22"", &");
  }
// compilenode returning strlit1319
  params[0] = strlit1319;
  Object opresult1321 = callmethod(opresult1318, "++", 1, params);
// compilenode returning opresult1321
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1323 = callmethod(opresult1321, "++", 1, params);
// compilenode returning opresult1323
  if (strlit1324 == NULL) {
    strlit1324 = alloc_String(");");
  }
// compilenode returning strlit1324
  params[0] = strlit1324;
  Object opresult1326 = callmethod(opresult1323, "++", 1, params);
// compilenode returning opresult1326
// Begin line 437
  setline(437);
// compilenode returning self
  params[0] = opresult1326;
  Object call1327 = callmethod(self, "out",
    1, params);
// compilenode returning call1327
    if1177 = call1327;
  }
// compilenode returning if1177
// Begin line 439
  setline(439);
// Begin line 438
  setline(438);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 440
  setline(440);
// Begin line 439
  setline(439);
// compilenode returning *var_origParamsUsed
  *var_paramsUsed = *var_origParamsUsed;
  if (*var_origParamsUsed == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply1371(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 456
  setline(456);
// Begin line 458
  setline(458);
// Begin line 1035
  setline(1035);
// Begin line 451
  setline(451);
// compilenode returning *var_l
  Object call1373 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1373
// compilenode returning call1373
  if (strlit1374 == NULL) {
    strlit1374 = alloc_String("vardec");
  }
// compilenode returning strlit1374
  params[0] = strlit1374;
  Object opresult1376 = callmethod(call1373, "==", 1, params);
// compilenode returning opresult1376
// Begin line 458
  setline(458);
// Begin line 1035
  setline(1035);
// Begin line 451
  setline(451);
// compilenode returning *var_l
  Object call1377 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1377
// compilenode returning call1377
  if (strlit1378 == NULL) {
    strlit1378 = alloc_String("defdec");
  }
// compilenode returning strlit1378
  params[0] = strlit1378;
  Object opresult1380 = callmethod(call1377, "==", 1, params);
// compilenode returning opresult1380
  params[0] = opresult1380;
  Object opresult1382 = callmethod(opresult1376, "|", 1, params);
// compilenode returning opresult1382
// Begin line 458
  setline(458);
// Begin line 1035
  setline(1035);
// Begin line 452
  setline(452);
// compilenode returning *var_l
  Object call1383 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1383
// compilenode returning call1383
  if (strlit1384 == NULL) {
    strlit1384 = alloc_String("class");
  }
// compilenode returning strlit1384
  params[0] = strlit1384;
  Object opresult1386 = callmethod(call1383, "==", 1, params);
// compilenode returning opresult1386
  params[0] = opresult1386;
  Object opresult1388 = callmethod(opresult1382, "|", 1, params);
// compilenode returning opresult1388
  Object if1372;
  if (istrue(opresult1388)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 453
  setline(453);
// Begin line 1035
  setline(1035);
// Begin line 453
  setline(453);
// Begin line 1035
  setline(1035);
// Begin line 453
  setline(453);
// compilenode returning *var_l
  Object call1389 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1389
// compilenode returning call1389
  Object call1390 = callmethod(call1389, "value",
    0, params);
// compilenode returning call1390
// compilenode returning call1390
// Begin line 454
  setline(454);
// compilenode returning self
  params[0] = call1390;
  Object call1391 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1391
  var_tnm = alloc_var();
  *var_tnm = call1391;
  if (call1391 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1392 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1392
// Begin line 455
  setline(455);
  if (strlit1393 == NULL) {
    strlit1393 = alloc_String("  Object *var_");
  }
// compilenode returning strlit1393
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1395 = callmethod(strlit1393, "++", 1, params);
// compilenode returning opresult1395
  if (strlit1396 == NULL) {
    strlit1396 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit1396
  params[0] = strlit1396;
  Object opresult1398 = callmethod(opresult1395, "++", 1, params);
// compilenode returning opresult1398
// Begin line 456
  setline(456);
// compilenode returning self
  params[0] = opresult1398;
  Object call1399 = callmethod(self, "out",
    1, params);
// compilenode returning call1399
  if (strlit1400 == NULL) {
    strlit1400 = alloc_String("  *var_");
  }
// compilenode returning strlit1400
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1402 = callmethod(strlit1400, "++", 1, params);
// compilenode returning opresult1402
  if (strlit1403 == NULL) {
    strlit1403 = alloc_String(" = undefined;");
  }
// compilenode returning strlit1403
  params[0] = strlit1403;
  Object opresult1405 = callmethod(opresult1402, "++", 1, params);
// compilenode returning opresult1405
// Begin line 457
  setline(457);
// compilenode returning self
  params[0] = opresult1405;
  Object call1406 = callmethod(self, "out",
    1, params);
// compilenode returning call1406
    if1372 = call1406;
  } else {
  }
// compilenode returning if1372
  return if1372;
}
Object meth_genc_apply1413(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_tret = closure[0];
  Object self = *closure[1];
// Begin line 460
  setline(460);
// compilenode returning *var_l
// Begin line 461
  setline(461);
// compilenode returning self
  params[0] = *var_l;
  Object call1414 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1414
  *var_tret = call1414;
  if (call1414 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilewhile1330(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[19];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_declaredvars = closure[1];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
// Begin line 443
  setline(443);
// Begin line 442
  setline(442);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 444
  setline(444);
// Begin line 443
  setline(443);
// compilenode returning *var_auto_count
  Object num1331 = alloc_Float64(1.0);
// compilenode returning num1331
  params[0] = num1331;
  Object sum1333 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1333
  *var_auto_count = sum1333;
  if (sum1333 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 444
  setline(444);
  if (strlit1335 == NULL) {
    strlit1335 = alloc_String("  Object while");
  }
// compilenode returning strlit1335
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1337 = callmethod(strlit1335, "++", 1, params);
// compilenode returning opresult1337
  if (strlit1338 == NULL) {
    strlit1338 = alloc_String(";");
  }
// compilenode returning strlit1338
  params[0] = strlit1338;
  Object opresult1340 = callmethod(opresult1337, "++", 1, params);
// compilenode returning opresult1340
// Begin line 445
  setline(445);
// compilenode returning self
  params[0] = opresult1340;
  Object call1341 = callmethod(self, "out",
    1, params);
// compilenode returning call1341
  if (strlit1342 == NULL) {
    strlit1342 = alloc_String("  while (1) {");
  }
// compilenode returning strlit1342
// Begin line 446
  setline(446);
// compilenode returning self
  params[0] = strlit1342;
  Object call1343 = callmethod(self, "out",
    1, params);
// compilenode returning call1343
// Begin line 1035
  setline(1035);
// Begin line 446
  setline(446);
// compilenode returning *var_o
  Object call1344 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1344
// compilenode returning call1344
// Begin line 447
  setline(447);
// compilenode returning self
  params[0] = call1344;
  Object call1345 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1345
  *var_cond = call1345;
  if (call1345 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit1346 == NULL) {
    strlit1346 = alloc_String("    while");
  }
// compilenode returning strlit1346
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1348 = callmethod(strlit1346, "++", 1, params);
// compilenode returning opresult1348
  if (strlit1349 == NULL) {
    strlit1349 = alloc_String(" = ");
  }
// compilenode returning strlit1349
  params[0] = strlit1349;
  Object opresult1351 = callmethod(opresult1348, "++", 1, params);
// compilenode returning opresult1351
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult1353 = callmethod(opresult1351, "++", 1, params);
// compilenode returning opresult1353
  if (strlit1354 == NULL) {
    strlit1354 = alloc_String(";");
  }
// compilenode returning strlit1354
  params[0] = strlit1354;
  Object opresult1356 = callmethod(opresult1353, "++", 1, params);
// compilenode returning opresult1356
// Begin line 448
  setline(448);
// compilenode returning self
  params[0] = opresult1356;
  Object call1357 = callmethod(self, "out",
    1, params);
// compilenode returning call1357
  if (strlit1358 == NULL) {
    strlit1358 = alloc_String("    if (!istrue(");
  }
// compilenode returning strlit1358
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult1360 = callmethod(strlit1358, "++", 1, params);
// compilenode returning opresult1360
  if (strlit1361 == NULL) {
    strlit1361 = alloc_String(")) break;");
  }
// compilenode returning strlit1361
  params[0] = strlit1361;
  Object opresult1363 = callmethod(opresult1360, "++", 1, params);
// compilenode returning opresult1363
// Begin line 449
  setline(449);
// compilenode returning self
  params[0] = opresult1363;
  Object call1364 = callmethod(self, "out",
    1, params);
// compilenode returning call1364
// Begin line 450
  setline(450);
// Begin line 449
  setline(449);
  if (strlit1365 == NULL) {
    strlit1365 = alloc_String("null");
  }
// compilenode returning strlit1365
  var_tret = alloc_var();
  *var_tret = strlit1365;
  if (strlit1365 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 456
  setline(456);
// Begin line 459
  setline(459);
// Begin line 1035
  setline(1035);
// Begin line 450
  setline(450);
// compilenode returning *var_o
  Object call1367 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call1367
// compilenode returning call1367
// Begin line 456
  setline(456);
// Begin line 1035
  setline(1035);
  Object obj1369 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1369, self, 0);
  addmethod2(obj1369, "outer", &reader_genc_outer_1370);
  adddatum2(obj1369, self, 0);
  block_savedest(obj1369);
  Object **closure1371 = createclosure(2);
  addtoclosure(closure1371, var_declaredvars);
  Object *selfpp1407 = alloc_var();
  *selfpp1407 = self;
  addtoclosure(closure1371, selfpp1407);
  struct UserObject *uo1371 = (struct UserObject*)obj1369;
  uo1371->data[1] = (Object)closure1371;
  addmethod2(obj1369, "apply", &meth_genc_apply1371);
  set_type(obj1369, 0);
// compilenode returning obj1369
  setclassname(obj1369, "Block<genc:1368>");
// compilenode returning obj1369
  params[0] = call1367;
  Object iter1366 = callmethod(call1367, "iter", 1, params);
  while(1) {
    Object cond1366 = callmethod(iter1366, "havemore", 0, NULL);
    if (!istrue(cond1366)) break;
    params[0] = callmethod(iter1366, "next", 0, NULL);
    callmethod(obj1369, "apply", 1, params);
  }
// compilenode returning call1367
// Begin line 460
  setline(460);
// Begin line 462
  setline(462);
// Begin line 1035
  setline(1035);
// Begin line 459
  setline(459);
// compilenode returning *var_o
  Object call1409 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call1409
// compilenode returning call1409
// Begin line 460
  setline(460);
// Begin line 1035
  setline(1035);
  Object obj1411 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1411, self, 0);
  addmethod2(obj1411, "outer", &reader_genc_outer_1412);
  adddatum2(obj1411, self, 0);
  block_savedest(obj1411);
  Object **closure1413 = createclosure(2);
  addtoclosure(closure1413, var_tret);
  Object *selfpp1416 = alloc_var();
  *selfpp1416 = self;
  addtoclosure(closure1413, selfpp1416);
  struct UserObject *uo1413 = (struct UserObject*)obj1411;
  uo1413->data[1] = (Object)closure1413;
  addmethod2(obj1411, "apply", &meth_genc_apply1413);
  set_type(obj1411, 0);
// compilenode returning obj1411
  setclassname(obj1411, "Block<genc:1410>");
// compilenode returning obj1411
  params[0] = call1409;
  Object iter1408 = callmethod(call1409, "iter", 1, params);
  while(1) {
    Object cond1408 = callmethod(iter1408, "havemore", 0, NULL);
    if (!istrue(cond1408)) break;
    params[0] = callmethod(iter1408, "next", 0, NULL);
    callmethod(obj1411, "apply", 1, params);
  }
// compilenode returning call1409
// Begin line 462
  setline(462);
  if (strlit1417 == NULL) {
    strlit1417 = alloc_String("  }");
  }
// compilenode returning strlit1417
// Begin line 463
  setline(463);
// compilenode returning self
  params[0] = strlit1417;
  Object call1418 = callmethod(self, "out",
    1, params);
// compilenode returning call1418
// Begin line 464
  setline(464);
// Begin line 1035
  setline(1035);
// Begin line 464
  setline(464);
// Begin line 463
  setline(463);
  if (strlit1419 == NULL) {
    strlit1419 = alloc_String("while");
  }
// compilenode returning strlit1419
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1421 = callmethod(strlit1419, "++", 1, params);
// compilenode returning opresult1421
// compilenode returning *var_o
  params[0] = opresult1421;
  Object call1422 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1422
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply1453(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 481
  setline(481);
// Begin line 483
  setline(483);
// Begin line 1035
  setline(1035);
// Begin line 476
  setline(476);
// compilenode returning *var_l
  Object call1455 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1455
// compilenode returning call1455
  if (strlit1456 == NULL) {
    strlit1456 = alloc_String("vardec");
  }
// compilenode returning strlit1456
  params[0] = strlit1456;
  Object opresult1458 = callmethod(call1455, "==", 1, params);
// compilenode returning opresult1458
// Begin line 483
  setline(483);
// Begin line 1035
  setline(1035);
// Begin line 476
  setline(476);
// compilenode returning *var_l
  Object call1459 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1459
// compilenode returning call1459
  if (strlit1460 == NULL) {
    strlit1460 = alloc_String("defdec");
  }
// compilenode returning strlit1460
  params[0] = strlit1460;
  Object opresult1462 = callmethod(call1459, "==", 1, params);
// compilenode returning opresult1462
  params[0] = opresult1462;
  Object opresult1464 = callmethod(opresult1458, "|", 1, params);
// compilenode returning opresult1464
// Begin line 483
  setline(483);
// Begin line 1035
  setline(1035);
// Begin line 477
  setline(477);
// compilenode returning *var_l
  Object call1465 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1465
// compilenode returning call1465
  if (strlit1466 == NULL) {
    strlit1466 = alloc_String("class");
  }
// compilenode returning strlit1466
  params[0] = strlit1466;
  Object opresult1468 = callmethod(call1465, "==", 1, params);
// compilenode returning opresult1468
  params[0] = opresult1468;
  Object opresult1470 = callmethod(opresult1464, "|", 1, params);
// compilenode returning opresult1470
  Object if1454;
  if (istrue(opresult1470)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 478
  setline(478);
// Begin line 1035
  setline(1035);
// Begin line 478
  setline(478);
// Begin line 1035
  setline(1035);
// Begin line 478
  setline(478);
// compilenode returning *var_l
  Object call1471 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1471
// compilenode returning call1471
  Object call1472 = callmethod(call1471, "value",
    0, params);
// compilenode returning call1472
// compilenode returning call1472
// Begin line 479
  setline(479);
// compilenode returning self
  params[0] = call1472;
  Object call1473 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1473
  var_tnm = alloc_var();
  *var_tnm = call1473;
  if (call1473 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1474 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1474
// Begin line 480
  setline(480);
  if (strlit1475 == NULL) {
    strlit1475 = alloc_String("  Object *var_");
  }
// compilenode returning strlit1475
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1477 = callmethod(strlit1475, "++", 1, params);
// compilenode returning opresult1477
  if (strlit1478 == NULL) {
    strlit1478 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit1478
  params[0] = strlit1478;
  Object opresult1480 = callmethod(opresult1477, "++", 1, params);
// compilenode returning opresult1480
// Begin line 481
  setline(481);
// compilenode returning self
  params[0] = opresult1480;
  Object call1481 = callmethod(self, "out",
    1, params);
// compilenode returning call1481
  if (strlit1482 == NULL) {
    strlit1482 = alloc_String("  *var_");
  }
// compilenode returning strlit1482
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1484 = callmethod(strlit1482, "++", 1, params);
// compilenode returning opresult1484
  if (strlit1485 == NULL) {
    strlit1485 = alloc_String(" = undefined;");
  }
// compilenode returning strlit1485
  params[0] = strlit1485;
  Object opresult1487 = callmethod(opresult1484, "++", 1, params);
// compilenode returning opresult1487
// Begin line 482
  setline(482);
// compilenode returning self
  params[0] = opresult1487;
  Object call1488 = callmethod(self, "out",
    1, params);
// compilenode returning call1488
    if1454 = call1488;
  } else {
  }
// compilenode returning if1454
  return if1454;
}
Object meth_genc_apply1495(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_tret = closure[0];
  Object self = *closure[1];
// Begin line 485
  setline(485);
// compilenode returning *var_l
// Begin line 486
  setline(486);
// compilenode returning self
  params[0] = *var_l;
  Object call1496 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1496
  *var_tret = call1496;
  if (call1496 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply1524(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 496
  setline(496);
// Begin line 498
  setline(498);
// Begin line 1035
  setline(1035);
// Begin line 491
  setline(491);
// compilenode returning *var_l
  Object call1526 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1526
// compilenode returning call1526
  if (strlit1527 == NULL) {
    strlit1527 = alloc_String("vardec");
  }
// compilenode returning strlit1527
  params[0] = strlit1527;
  Object opresult1529 = callmethod(call1526, "==", 1, params);
// compilenode returning opresult1529
// Begin line 498
  setline(498);
// Begin line 1035
  setline(1035);
// Begin line 491
  setline(491);
// compilenode returning *var_l
  Object call1530 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1530
// compilenode returning call1530
  if (strlit1531 == NULL) {
    strlit1531 = alloc_String("defdec");
  }
// compilenode returning strlit1531
  params[0] = strlit1531;
  Object opresult1533 = callmethod(call1530, "==", 1, params);
// compilenode returning opresult1533
  params[0] = opresult1533;
  Object opresult1535 = callmethod(opresult1529, "|", 1, params);
// compilenode returning opresult1535
// Begin line 498
  setline(498);
// Begin line 1035
  setline(1035);
// Begin line 492
  setline(492);
// compilenode returning *var_l
  Object call1536 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1536
// compilenode returning call1536
  if (strlit1537 == NULL) {
    strlit1537 = alloc_String("class");
  }
// compilenode returning strlit1537
  params[0] = strlit1537;
  Object opresult1539 = callmethod(call1536, "==", 1, params);
// compilenode returning opresult1539
  params[0] = opresult1539;
  Object opresult1541 = callmethod(opresult1535, "|", 1, params);
// compilenode returning opresult1541
  Object if1525;
  if (istrue(opresult1541)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 493
  setline(493);
// Begin line 1035
  setline(1035);
// Begin line 493
  setline(493);
// Begin line 1035
  setline(1035);
// Begin line 493
  setline(493);
// compilenode returning *var_l
  Object call1542 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1542
// compilenode returning call1542
  Object call1543 = callmethod(call1542, "value",
    0, params);
// compilenode returning call1543
// compilenode returning call1543
// Begin line 494
  setline(494);
// compilenode returning self
  params[0] = call1543;
  Object call1544 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1544
  var_tnm = alloc_var();
  *var_tnm = call1544;
  if (call1544 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1545 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1545
// Begin line 495
  setline(495);
  if (strlit1546 == NULL) {
    strlit1546 = alloc_String("  Object *var_");
  }
// compilenode returning strlit1546
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1548 = callmethod(strlit1546, "++", 1, params);
// compilenode returning opresult1548
  if (strlit1549 == NULL) {
    strlit1549 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit1549
  params[0] = strlit1549;
  Object opresult1551 = callmethod(opresult1548, "++", 1, params);
// compilenode returning opresult1551
// Begin line 496
  setline(496);
// compilenode returning self
  params[0] = opresult1551;
  Object call1552 = callmethod(self, "out",
    1, params);
// compilenode returning call1552
  if (strlit1553 == NULL) {
    strlit1553 = alloc_String("  *var_");
  }
// compilenode returning strlit1553
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1555 = callmethod(strlit1553, "++", 1, params);
// compilenode returning opresult1555
  if (strlit1556 == NULL) {
    strlit1556 = alloc_String(" = undefined;");
  }
// compilenode returning strlit1556
  params[0] = strlit1556;
  Object opresult1558 = callmethod(opresult1555, "++", 1, params);
// compilenode returning opresult1558
// Begin line 497
  setline(497);
// compilenode returning self
  params[0] = opresult1558;
  Object call1559 = callmethod(self, "out",
    1, params);
// compilenode returning call1559
    if1525 = call1559;
  } else {
  }
// compilenode returning if1525
  return if1525;
}
Object meth_genc_apply1566(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_fret = closure[0];
  Object self = *closure[1];
// Begin line 500
  setline(500);
// compilenode returning *var_l
// Begin line 501
  setline(501);
// compilenode returning self
  params[0] = *var_l;
  Object call1567 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1567
  *var_fret = call1567;
  if (call1567 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileif1423(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[20];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_declaredvars = closure[1];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
  Object *var_fret = alloc_var();
  *var_fret = undefined;
  Object *var_tblock = alloc_var();
  *var_tblock = undefined;
  Object *var_fblock = alloc_var();
  *var_fblock = undefined;
// Begin line 467
  setline(467);
// Begin line 466
  setline(466);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 468
  setline(468);
// Begin line 467
  setline(467);
// compilenode returning *var_auto_count
  Object num1424 = alloc_Float64(1.0);
// compilenode returning num1424
  params[0] = num1424;
  Object sum1426 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1426
  *var_auto_count = sum1426;
  if (sum1426 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 468
  setline(468);
// Begin line 1035
  setline(1035);
// Begin line 468
  setline(468);
// compilenode returning *var_o
  Object call1428 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1428
// compilenode returning call1428
// Begin line 469
  setline(469);
// compilenode returning self
  params[0] = call1428;
  Object call1429 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1429
  var_cond = alloc_var();
  *var_cond = call1429;
  if (call1429 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit1430 == NULL) {
    strlit1430 = alloc_String("  Object if");
  }
// compilenode returning strlit1430
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1432 = callmethod(strlit1430, "++", 1, params);
// compilenode returning opresult1432
  if (strlit1433 == NULL) {
    strlit1433 = alloc_String(";");
  }
// compilenode returning strlit1433
  params[0] = strlit1433;
  Object opresult1435 = callmethod(opresult1432, "++", 1, params);
// compilenode returning opresult1435
// Begin line 470
  setline(470);
// compilenode returning self
  params[0] = opresult1435;
  Object call1436 = callmethod(self, "out",
    1, params);
// compilenode returning call1436
  if (strlit1437 == NULL) {
    strlit1437 = alloc_String("  if (istrue(");
  }
// compilenode returning strlit1437
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult1439 = callmethod(strlit1437, "++", 1, params);
// compilenode returning opresult1439
  if (strlit1440 == NULL) {
    strlit1440 = alloc_String(")) {");
  }
// compilenode returning strlit1440
  params[0] = strlit1440;
  Object opresult1442 = callmethod(opresult1439, "++", 1, params);
// compilenode returning opresult1442
// Begin line 471
  setline(471);
// compilenode returning self
  params[0] = opresult1442;
  Object call1443 = callmethod(self, "out",
    1, params);
// compilenode returning call1443
// Begin line 472
  setline(472);
// Begin line 471
  setline(471);
  if (strlit1444 == NULL) {
    strlit1444 = alloc_String("undefined");
  }
// compilenode returning strlit1444
  var_tret = alloc_var();
  *var_tret = strlit1444;
  if (strlit1444 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 473
  setline(473);
// Begin line 472
  setline(472);
  if (strlit1445 == NULL) {
    strlit1445 = alloc_String("undefined");
  }
// compilenode returning strlit1445
  var_fret = alloc_var();
  *var_fret = strlit1445;
  if (strlit1445 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 474
  setline(474);
// Begin line 473
  setline(473);
  if (strlit1446 == NULL) {
    strlit1446 = alloc_String("ERROR");
  }
// compilenode returning strlit1446
  var_tblock = alloc_var();
  *var_tblock = strlit1446;
  if (strlit1446 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 475
  setline(475);
// Begin line 474
  setline(474);
  if (strlit1447 == NULL) {
    strlit1447 = alloc_String("ERROR");
  }
// compilenode returning strlit1447
  var_fblock = alloc_var();
  *var_fblock = strlit1447;
  if (strlit1447 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 481
  setline(481);
// Begin line 484
  setline(484);
// Begin line 1035
  setline(1035);
// Begin line 475
  setline(475);
// compilenode returning *var_o
  Object call1449 = callmethod(*var_o, "thenblock",
    0, params);
// compilenode returning call1449
// compilenode returning call1449
// Begin line 481
  setline(481);
// Begin line 1035
  setline(1035);
  Object obj1451 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1451, self, 0);
  addmethod2(obj1451, "outer", &reader_genc_outer_1452);
  adddatum2(obj1451, self, 0);
  block_savedest(obj1451);
  Object **closure1453 = createclosure(2);
  addtoclosure(closure1453, var_declaredvars);
  Object *selfpp1489 = alloc_var();
  *selfpp1489 = self;
  addtoclosure(closure1453, selfpp1489);
  struct UserObject *uo1453 = (struct UserObject*)obj1451;
  uo1453->data[1] = (Object)closure1453;
  addmethod2(obj1451, "apply", &meth_genc_apply1453);
  set_type(obj1451, 0);
// compilenode returning obj1451
  setclassname(obj1451, "Block<genc:1450>");
// compilenode returning obj1451
  params[0] = call1449;
  Object iter1448 = callmethod(call1449, "iter", 1, params);
  while(1) {
    Object cond1448 = callmethod(iter1448, "havemore", 0, NULL);
    if (!istrue(cond1448)) break;
    params[0] = callmethod(iter1448, "next", 0, NULL);
    callmethod(obj1451, "apply", 1, params);
  }
// compilenode returning call1449
// Begin line 485
  setline(485);
// Begin line 487
  setline(487);
// Begin line 1035
  setline(1035);
// Begin line 484
  setline(484);
// compilenode returning *var_o
  Object call1491 = callmethod(*var_o, "thenblock",
    0, params);
// compilenode returning call1491
// compilenode returning call1491
// Begin line 485
  setline(485);
// Begin line 1035
  setline(1035);
  Object obj1493 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1493, self, 0);
  addmethod2(obj1493, "outer", &reader_genc_outer_1494);
  adddatum2(obj1493, self, 0);
  block_savedest(obj1493);
  Object **closure1495 = createclosure(2);
  addtoclosure(closure1495, var_tret);
  Object *selfpp1498 = alloc_var();
  *selfpp1498 = self;
  addtoclosure(closure1495, selfpp1498);
  struct UserObject *uo1495 = (struct UserObject*)obj1493;
  uo1495->data[1] = (Object)closure1495;
  addmethod2(obj1493, "apply", &meth_genc_apply1495);
  set_type(obj1493, 0);
// compilenode returning obj1493
  setclassname(obj1493, "Block<genc:1492>");
// compilenode returning obj1493
  params[0] = call1491;
  Object iter1490 = callmethod(call1491, "iter", 1, params);
  while(1) {
    Object cond1490 = callmethod(iter1490, "havemore", 0, NULL);
    if (!istrue(cond1490)) break;
    params[0] = callmethod(iter1490, "next", 0, NULL);
    callmethod(obj1493, "apply", 1, params);
  }
// compilenode returning call1491
// Begin line 487
  setline(487);
  if (strlit1499 == NULL) {
    strlit1499 = alloc_String("    if");
  }
// compilenode returning strlit1499
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1501 = callmethod(strlit1499, "++", 1, params);
// compilenode returning opresult1501
  if (strlit1502 == NULL) {
    strlit1502 = alloc_String(" = ");
  }
// compilenode returning strlit1502
  params[0] = strlit1502;
  Object opresult1504 = callmethod(opresult1501, "++", 1, params);
// compilenode returning opresult1504
// compilenode returning *var_tret
  params[0] = *var_tret;
  Object opresult1506 = callmethod(opresult1504, "++", 1, params);
// compilenode returning opresult1506
  if (strlit1507 == NULL) {
    strlit1507 = alloc_String(";");
  }
// compilenode returning strlit1507
  params[0] = strlit1507;
  Object opresult1509 = callmethod(opresult1506, "++", 1, params);
// compilenode returning opresult1509
// Begin line 488
  setline(488);
// compilenode returning self
  params[0] = opresult1509;
  Object call1510 = callmethod(self, "out",
    1, params);
// compilenode returning call1510
  if (strlit1511 == NULL) {
    strlit1511 = alloc_String("  } else {");
  }
// compilenode returning strlit1511
// Begin line 489
  setline(489);
// compilenode returning self
  params[0] = strlit1511;
  Object call1512 = callmethod(self, "out",
    1, params);
// compilenode returning call1512
// Begin line 502
  setline(502);
// Begin line 504
  setline(504);
// Begin line 1035
  setline(1035);
// Begin line 504
  setline(504);
// Begin line 1035
  setline(1035);
// Begin line 489
  setline(489);
// compilenode returning *var_o
  Object call1514 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call1514
// compilenode returning call1514
  Object call1515 = callmethod(call1514, "size",
    0, params);
// compilenode returning call1515
// compilenode returning call1515
  Object num1516 = alloc_Float64(0.0);
// compilenode returning num1516
  params[0] = num1516;
  Object opresult1518 = callmethod(call1515, ">", 1, params);
// compilenode returning opresult1518
  Object if1513;
  if (istrue(opresult1518)) {
// Begin line 496
  setline(496);
// Begin line 499
  setline(499);
// Begin line 1035
  setline(1035);
// Begin line 490
  setline(490);
// compilenode returning *var_o
  Object call1520 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call1520
// compilenode returning call1520
// Begin line 496
  setline(496);
// Begin line 1035
  setline(1035);
  Object obj1522 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1522, self, 0);
  addmethod2(obj1522, "outer", &reader_genc_outer_1523);
  adddatum2(obj1522, self, 0);
  block_savedest(obj1522);
  Object **closure1524 = createclosure(2);
  addtoclosure(closure1524, var_declaredvars);
  Object *selfpp1560 = alloc_var();
  *selfpp1560 = self;
  addtoclosure(closure1524, selfpp1560);
  struct UserObject *uo1524 = (struct UserObject*)obj1522;
  uo1524->data[1] = (Object)closure1524;
  addmethod2(obj1522, "apply", &meth_genc_apply1524);
  set_type(obj1522, 0);
// compilenode returning obj1522
  setclassname(obj1522, "Block<genc:1521>");
// compilenode returning obj1522
  params[0] = call1520;
  Object iter1519 = callmethod(call1520, "iter", 1, params);
  while(1) {
    Object cond1519 = callmethod(iter1519, "havemore", 0, NULL);
    if (!istrue(cond1519)) break;
    params[0] = callmethod(iter1519, "next", 0, NULL);
    callmethod(obj1522, "apply", 1, params);
  }
// compilenode returning call1520
// Begin line 500
  setline(500);
// Begin line 502
  setline(502);
// Begin line 1035
  setline(1035);
// Begin line 499
  setline(499);
// compilenode returning *var_o
  Object call1562 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call1562
// compilenode returning call1562
// Begin line 500
  setline(500);
// Begin line 1035
  setline(1035);
  Object obj1564 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1564, self, 0);
  addmethod2(obj1564, "outer", &reader_genc_outer_1565);
  adddatum2(obj1564, self, 0);
  block_savedest(obj1564);
  Object **closure1566 = createclosure(2);
  addtoclosure(closure1566, var_fret);
  Object *selfpp1569 = alloc_var();
  *selfpp1569 = self;
  addtoclosure(closure1566, selfpp1569);
  struct UserObject *uo1566 = (struct UserObject*)obj1564;
  uo1566->data[1] = (Object)closure1566;
  addmethod2(obj1564, "apply", &meth_genc_apply1566);
  set_type(obj1564, 0);
// compilenode returning obj1564
  setclassname(obj1564, "Block<genc:1563>");
// compilenode returning obj1564
  params[0] = call1562;
  Object iter1561 = callmethod(call1562, "iter", 1, params);
  while(1) {
    Object cond1561 = callmethod(iter1561, "havemore", 0, NULL);
    if (!istrue(cond1561)) break;
    params[0] = callmethod(iter1561, "next", 0, NULL);
    callmethod(obj1564, "apply", 1, params);
  }
// compilenode returning call1562
// Begin line 502
  setline(502);
  if (strlit1570 == NULL) {
    strlit1570 = alloc_String("    if");
  }
// compilenode returning strlit1570
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1572 = callmethod(strlit1570, "++", 1, params);
// compilenode returning opresult1572
  if (strlit1573 == NULL) {
    strlit1573 = alloc_String(" = ");
  }
// compilenode returning strlit1573
  params[0] = strlit1573;
  Object opresult1575 = callmethod(opresult1572, "++", 1, params);
// compilenode returning opresult1575
// compilenode returning *var_fret
  params[0] = *var_fret;
  Object opresult1577 = callmethod(opresult1575, "++", 1, params);
// compilenode returning opresult1577
  if (strlit1578 == NULL) {
    strlit1578 = alloc_String(";");
  }
// compilenode returning strlit1578
  params[0] = strlit1578;
  Object opresult1580 = callmethod(opresult1577, "++", 1, params);
// compilenode returning opresult1580
// Begin line 503
  setline(503);
// compilenode returning self
  params[0] = opresult1580;
  Object call1581 = callmethod(self, "out",
    1, params);
// compilenode returning call1581
    if1513 = call1581;
  } else {
  }
// compilenode returning if1513
// Begin line 504
  setline(504);
  if (strlit1582 == NULL) {
    strlit1582 = alloc_String("  }");
  }
// compilenode returning strlit1582
// Begin line 505
  setline(505);
// compilenode returning self
  params[0] = strlit1582;
  Object call1583 = callmethod(self, "out",
    1, params);
// compilenode returning call1583
// Begin line 506
  setline(506);
// Begin line 1035
  setline(1035);
// Begin line 506
  setline(506);
// Begin line 505
  setline(505);
  if (strlit1584 == NULL) {
    strlit1584 = alloc_String("if");
  }
// compilenode returning strlit1584
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1586 = callmethod(strlit1584, "++", 1, params);
// compilenode returning opresult1586
// compilenode returning *var_o
  params[0] = opresult1586;
  Object call1587 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1587
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileidentifier1588(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[21];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_modules = closure[1];
  Object *var_usedvars = closure[2];
  Object *var_name = alloc_var();
  *var_name = undefined;
// Begin line 508
  setline(508);
// Begin line 1035
  setline(1035);
// Begin line 508
  setline(508);
// compilenode returning *var_o
  Object call1589 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1589
// compilenode returning call1589
// Begin line 509
  setline(509);
// compilenode returning self
  params[0] = call1589;
  Object call1590 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1590
  var_name = alloc_var();
  *var_name = call1590;
  if (call1590 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 523
  setline(523);
// Begin line 525
  setline(525);
// Begin line 509
  setline(509);
// compilenode returning *var_name
  if (strlit1592 == NULL) {
    strlit1592 = alloc_String("self");
  }
// compilenode returning strlit1592
  params[0] = strlit1592;
  Object opresult1594 = callmethod(*var_name, "==", 1, params);
// compilenode returning opresult1594
  Object if1591;
  if (istrue(opresult1594)) {
// Begin line 511
  setline(511);
// Begin line 1035
  setline(1035);
// Begin line 510
  setline(510);
  if (strlit1595 == NULL) {
    strlit1595 = alloc_String("self");
  }
// compilenode returning strlit1595
// compilenode returning *var_o
  params[0] = strlit1595;
  Object call1596 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1596
// compilenode returning nothing
    if1591 = nothing;
  } else {
// Begin line 523
  setline(523);
// Begin line 516
  setline(516);
// Begin line 511
  setline(511);
// compilenode returning *var_name
  if (strlit1598 == NULL) {
    strlit1598 = alloc_String("__compilerRevision");
  }
// compilenode returning strlit1598
  params[0] = strlit1598;
  Object opresult1600 = callmethod(*var_name, "==", 1, params);
// compilenode returning opresult1600
  Object if1597;
  if (istrue(opresult1600)) {
// Begin line 513
  setline(513);
// Begin line 512
  setline(512);
  if (strlit1601 == NULL) {
    strlit1601 = alloc_String("  Object var_val___compilerRevision");
  }
// compilenode returning strlit1601
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1603 = callmethod(strlit1601, "++", 1, params);
// compilenode returning opresult1603
// Begin line 513
  setline(513);
  if (strlit1604 == NULL) {
    strlit1604 = alloc_String(" = alloc_String(compilerRevision);");
  }
// compilenode returning strlit1604
  params[0] = strlit1604;
  Object opresult1606 = callmethod(opresult1603, "++", 1, params);
// compilenode returning opresult1606
// Begin line 514
  setline(514);
// compilenode returning self
  params[0] = opresult1606;
  Object call1607 = callmethod(self, "out",
    1, params);
// compilenode returning call1607
// Begin line 515
  setline(515);
// Begin line 1035
  setline(1035);
// Begin line 515
  setline(515);
// Begin line 514
  setline(514);
  if (strlit1608 == NULL) {
    strlit1608 = alloc_String("var_val___compilerRevision");
  }
// compilenode returning strlit1608
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1610 = callmethod(strlit1608, "++", 1, params);
// compilenode returning opresult1610
// compilenode returning *var_o
  params[0] = opresult1610;
  Object call1611 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1611
// compilenode returning nothing
// Begin line 516
  setline(516);
// Begin line 515
  setline(515);
// compilenode returning *var_auto_count
  Object num1612 = alloc_Float64(1.0);
// compilenode returning num1612
  params[0] = num1612;
  Object sum1614 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1614
  *var_auto_count = sum1614;
  if (sum1614 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1597 = nothing;
  } else {
// Begin line 517
  setline(517);
// compilenode returning *var_name
// Begin line 518
  setline(518);
// compilenode returning self
  params[0] = *var_name;
  Object call1616 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call1616
  *var_name = call1616;
  if (call1616 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 523
  setline(523);
// Begin line 518
  setline(518);
// compilenode returning *var_name
// compilenode returning *var_modules
  params[0] = *var_name;
  Object call1619 = callmethod(*var_modules, "contains",
    1, params);
// compilenode returning call1619
  Object if1618;
  if (istrue(call1619)) {
// Begin line 520
  setline(520);
// Begin line 1035
  setline(1035);
// Begin line 520
  setline(520);
// Begin line 519
  setline(519);
  if (strlit1620 == NULL) {
    strlit1620 = alloc_String("module_");
  }
// compilenode returning strlit1620
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult1622 = callmethod(strlit1620, "++", 1, params);
// compilenode returning opresult1622
// compilenode returning *var_o
  params[0] = opresult1622;
  Object call1623 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1623
// compilenode returning nothing
    if1618 = nothing;
  } else {
// Begin line 521
  setline(521);
// compilenode returning *var_name
// compilenode returning *var_usedvars
  params[0] = *var_name;
  Object call1624 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call1624
// Begin line 523
  setline(523);
// Begin line 1035
  setline(1035);
// Begin line 523
  setline(523);
// Begin line 522
  setline(522);
  if (strlit1625 == NULL) {
    strlit1625 = alloc_String("*var_");
  }
// compilenode returning strlit1625
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult1627 = callmethod(strlit1625, "++", 1, params);
// compilenode returning opresult1627
  if (strlit1628 == NULL) {
    strlit1628 = alloc_String("");
  }
// compilenode returning strlit1628
  params[0] = strlit1628;
  Object opresult1630 = callmethod(opresult1627, "++", 1, params);
// compilenode returning opresult1630
// compilenode returning *var_o
  params[0] = opresult1630;
  Object call1631 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1631
// compilenode returning nothing
    if1618 = nothing;
  }
// compilenode returning if1618
    if1597 = if1618;
  }
// compilenode returning if1597
    if1591 = if1597;
  }
// compilenode returning if1591
  return if1591;
}
Object meth_genc_compilebind1632(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[22];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_usedvars = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_dest = alloc_var();
  *var_dest = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_c = alloc_var();
  *var_c = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 528
  setline(528);
// Begin line 1035
  setline(1035);
// Begin line 527
  setline(527);
// compilenode returning *var_o
  Object call1633 = callmethod(*var_o, "dest",
    0, params);
// compilenode returning call1633
// compilenode returning call1633
  var_dest = alloc_var();
  *var_dest = call1633;
  if (call1633 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 529
  setline(529);
// Begin line 528
  setline(528);
  if (strlit1634 == NULL) {
    strlit1634 = alloc_String("");
  }
// compilenode returning strlit1634
  var_val = alloc_var();
  *var_val = strlit1634;
  if (strlit1634 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 530
  setline(530);
// Begin line 529
  setline(529);
  if (strlit1635 == NULL) {
    strlit1635 = alloc_String("");
  }
// compilenode returning strlit1635
  var_c = alloc_var();
  *var_c = strlit1635;
  if (strlit1635 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 531
  setline(531);
// Begin line 530
  setline(530);
  if (strlit1636 == NULL) {
    strlit1636 = alloc_String("");
  }
// compilenode returning strlit1636
  var_r = alloc_var();
  *var_r = strlit1636;
  if (strlit1636 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 551
  setline(551);
// Begin line 552
  setline(552);
// Begin line 1035
  setline(1035);
// Begin line 531
  setline(531);
// compilenode returning *var_dest
  Object call1638 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call1638
// compilenode returning call1638
  if (strlit1639 == NULL) {
    strlit1639 = alloc_String("identifier");
  }
// compilenode returning strlit1639
  params[0] = strlit1639;
  Object opresult1641 = callmethod(call1638, "==", 1, params);
// compilenode returning opresult1641
  Object if1637;
  if (istrue(opresult1641)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
// Begin line 533
  setline(533);
// Begin line 1035
  setline(1035);
// Begin line 532
  setline(532);
// compilenode returning *var_o
  Object call1642 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1642
// compilenode returning call1642
  *var_val = call1642;
  if (call1642 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 533
  setline(533);
// compilenode returning *var_val
// Begin line 534
  setline(534);
// compilenode returning self
  params[0] = *var_val;
  Object call1644 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1644
  *var_val = call1644;
  if (call1644 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// Begin line 534
  setline(534);
// compilenode returning *var_dest
  Object call1646 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call1646
// compilenode returning call1646
// Begin line 535
  setline(535);
// compilenode returning self
  params[0] = call1646;
  Object call1647 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call1647
  var_nm = alloc_var();
  *var_nm = call1647;
  if (call1647 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_nm
// compilenode returning *var_usedvars
  params[0] = *var_nm;
  Object call1648 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call1648
// Begin line 536
  setline(536);
  if (strlit1649 == NULL) {
    strlit1649 = alloc_String("  *var_");
  }
// compilenode returning strlit1649
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1651 = callmethod(strlit1649, "++", 1, params);
// compilenode returning opresult1651
  if (strlit1652 == NULL) {
    strlit1652 = alloc_String(" = ");
  }
// compilenode returning strlit1652
  params[0] = strlit1652;
  Object opresult1654 = callmethod(opresult1651, "++", 1, params);
// compilenode returning opresult1654
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1656 = callmethod(opresult1654, "++", 1, params);
// compilenode returning opresult1656
  if (strlit1657 == NULL) {
    strlit1657 = alloc_String(";");
  }
// compilenode returning strlit1657
  params[0] = strlit1657;
  Object opresult1659 = callmethod(opresult1656, "++", 1, params);
// compilenode returning opresult1659
// Begin line 537
  setline(537);
// compilenode returning self
  params[0] = opresult1659;
  Object call1660 = callmethod(self, "out",
    1, params);
// compilenode returning call1660
  if (strlit1661 == NULL) {
    strlit1661 = alloc_String("  if (");
  }
// compilenode returning strlit1661
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1663 = callmethod(strlit1661, "++", 1, params);
// compilenode returning opresult1663
  if (strlit1664 == NULL) {
    strlit1664 = alloc_String(" == undefined)");
  }
// compilenode returning strlit1664
  params[0] = strlit1664;
  Object opresult1666 = callmethod(opresult1663, "++", 1, params);
// compilenode returning opresult1666
// Begin line 538
  setline(538);
// compilenode returning self
  params[0] = opresult1666;
  Object call1667 = callmethod(self, "out",
    1, params);
// compilenode returning call1667
  if (strlit1668 == NULL) {
    strlit1668 = alloc_String("    callmethod(nothing, ""\x22""assignment""\x22"", 0, NULL);");
  }
// compilenode returning strlit1668
// Begin line 539
  setline(539);
// compilenode returning self
  params[0] = strlit1668;
  Object call1669 = callmethod(self, "out",
    1, params);
// compilenode returning call1669
// Begin line 540
  setline(540);
// Begin line 539
  setline(539);
// compilenode returning *var_auto_count
  Object num1670 = alloc_Float64(1.0);
// compilenode returning num1670
  params[0] = num1670;
  Object sum1672 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1672
  *var_auto_count = sum1672;
  if (sum1672 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 541
  setline(541);
// Begin line 1035
  setline(1035);
// Begin line 540
  setline(540);
// compilenode returning *var_val
// compilenode returning *var_o
  params[0] = *var_val;
  Object call1674 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1674
// compilenode returning nothing
    if1637 = nothing;
  } else {
// Begin line 551
  setline(551);
// Begin line 546
  setline(546);
// Begin line 1035
  setline(1035);
// Begin line 541
  setline(541);
// compilenode returning *var_dest
  Object call1676 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call1676
// compilenode returning call1676
  if (strlit1677 == NULL) {
    strlit1677 = alloc_String("member");
  }
// compilenode returning strlit1677
  params[0] = strlit1677;
  Object opresult1679 = callmethod(call1676, "==", 1, params);
// compilenode returning opresult1679
  Object if1675;
  if (istrue(opresult1679)) {
// Begin line 543
  setline(543);
// Begin line 1035
  setline(1035);
// Begin line 543
  setline(543);
// Begin line 1035
  setline(1035);
// Begin line 542
  setline(542);
// compilenode returning *var_dest
  Object call1680 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call1680
// compilenode returning call1680
  if (strlit1681 == NULL) {
    strlit1681 = alloc_String(":=");
  }
// compilenode returning strlit1681
  params[0] = strlit1681;
  Object opresult1683 = callmethod(call1680, "++", 1, params);
// compilenode returning opresult1683
// compilenode returning *var_dest
  params[0] = opresult1683;
  Object call1684 = callmethod(*var_dest, "value:=",
    1, params);
// compilenode returning call1684
// compilenode returning nothing
// Begin line 543
  setline(543);
// compilenode returning *var_dest
  Object array1685 = alloc_List();
// Begin line 1035
  setline(1035);
// Begin line 543
  setline(543);
// compilenode returning *var_o
  Object call1686 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1686
// compilenode returning call1686
  params[0] = call1686;
  callmethod(array1685, "push", 1, params);
// compilenode returning array1685
// compilenode returning module_ast
  params[0] = *var_dest;
  params[1] = array1685;
  Object call1687 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1687
  *var_c = call1687;
  if (call1687 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 544
  setline(544);
// compilenode returning *var_c
// Begin line 545
  setline(545);
// compilenode returning self
  params[0] = *var_c;
  Object call1689 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1689
  *var_r = call1689;
  if (call1689 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 546
  setline(546);
// Begin line 1035
  setline(1035);
// Begin line 545
  setline(545);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call1691 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1691
// compilenode returning nothing
    if1675 = nothing;
  } else {
// Begin line 551
  setline(551);
// Begin line 552
  setline(552);
// Begin line 1035
  setline(1035);
// Begin line 546
  setline(546);
// compilenode returning *var_dest
  Object call1693 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call1693
// compilenode returning call1693
  if (strlit1694 == NULL) {
    strlit1694 = alloc_String("index");
  }
// compilenode returning strlit1694
  params[0] = strlit1694;
  Object opresult1696 = callmethod(call1693, "==", 1, params);
// compilenode returning opresult1696
  Object if1692;
  if (istrue(opresult1696)) {
  Object *var_imem = alloc_var();
  *var_imem = undefined;
// Begin line 547
  setline(547);
  if (strlit1697 == NULL) {
    strlit1697 = alloc_String("[]:=");
  }
// compilenode returning strlit1697
// Begin line 1035
  setline(1035);
// Begin line 547
  setline(547);
// compilenode returning *var_dest
  Object call1698 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call1698
// compilenode returning call1698
// compilenode returning module_ast
  params[0] = strlit1697;
  params[1] = call1698;
  Object call1699 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1699
  var_imem = alloc_var();
  *var_imem = call1699;
  if (call1699 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 548
  setline(548);
// compilenode returning *var_imem
  Object array1700 = alloc_List();
// Begin line 1035
  setline(1035);
// Begin line 548
  setline(548);
// compilenode returning *var_dest
  Object call1701 = callmethod(*var_dest, "index",
    0, params);
// compilenode returning call1701
// compilenode returning call1701
  params[0] = call1701;
  callmethod(array1700, "push", 1, params);
// Begin line 1035
  setline(1035);
// Begin line 548
  setline(548);
// compilenode returning *var_o
  Object call1702 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1702
// compilenode returning call1702
  params[0] = call1702;
  callmethod(array1700, "push", 1, params);
// compilenode returning array1700
// compilenode returning module_ast
  params[0] = *var_imem;
  params[1] = array1700;
  Object call1703 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1703
  *var_c = call1703;
  if (call1703 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 549
  setline(549);
// compilenode returning *var_c
// Begin line 550
  setline(550);
// compilenode returning self
  params[0] = *var_c;
  Object call1705 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1705
  *var_r = call1705;
  if (call1705 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 551
  setline(551);
// Begin line 1035
  setline(1035);
// Begin line 550
  setline(550);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call1707 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1707
// compilenode returning nothing
    if1692 = nothing;
  } else {
  }
// compilenode returning if1692
    if1675 = if1692;
  }
// compilenode returning if1675
    if1637 = if1675;
  }
// compilenode returning if1637
// Begin line 553
  setline(553);
// Begin line 1035
  setline(1035);
// Begin line 552
  setline(552);
  if (strlit1708 == NULL) {
    strlit1708 = alloc_String("nothing");
  }
// compilenode returning strlit1708
// compilenode returning *var_o
  params[0] = strlit1708;
  Object call1709 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1709
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compiledefdec1710(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[23];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 556
  setline(556);
  var_nm = alloc_var();
  *var_nm = undefined;
// compilenode returning nothing
// Begin line 559
  setline(559);
// Begin line 561
  setline(561);
// Begin line 1035
  setline(1035);
// Begin line 561
  setline(561);
// Begin line 1035
  setline(1035);
// Begin line 556
  setline(556);
// compilenode returning *var_o
  Object call1712 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1712
// compilenode returning call1712
  Object call1713 = callmethod(call1712, "kind",
    0, params);
// compilenode returning call1713
// compilenode returning call1713
  if (strlit1714 == NULL) {
    strlit1714 = alloc_String("generic");
  }
// compilenode returning strlit1714
  params[0] = strlit1714;
  Object opresult1716 = callmethod(call1713, "==", 1, params);
// compilenode returning opresult1716
  Object if1711;
  if (istrue(opresult1716)) {
// Begin line 557
  setline(557);
// Begin line 1035
  setline(1035);
// Begin line 557
  setline(557);
// Begin line 1035
  setline(1035);
// Begin line 557
  setline(557);
// Begin line 1035
  setline(1035);
// Begin line 557
  setline(557);
// compilenode returning *var_o
  Object call1717 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1717
// compilenode returning call1717
  Object call1718 = callmethod(call1717, "value",
    0, params);
// compilenode returning call1718
// compilenode returning call1718
  Object call1719 = callmethod(call1718, "value",
    0, params);
// compilenode returning call1719
// compilenode returning call1719
// Begin line 558
  setline(558);
// compilenode returning self
  params[0] = call1719;
  Object call1720 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1720
  *var_nm = call1720;
  if (call1720 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1711 = nothing;
  } else {
// Begin line 559
  setline(559);
// Begin line 1035
  setline(1035);
// Begin line 559
  setline(559);
// Begin line 1035
  setline(1035);
// Begin line 559
  setline(559);
// compilenode returning *var_o
  Object call1722 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1722
// compilenode returning call1722
  Object call1723 = callmethod(call1722, "value",
    0, params);
// compilenode returning call1723
// compilenode returning call1723
// Begin line 560
  setline(560);
// compilenode returning self
  params[0] = call1723;
  Object call1724 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1724
  *var_nm = call1724;
  if (call1724 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1711 = nothing;
  }
// compilenode returning if1711
// Begin line 561
  setline(561);
// compilenode returning *var_nm
// compilenode returning *var_declaredvars
  params[0] = *var_nm;
  Object call1726 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1726
// Begin line 563
  setline(563);
// Begin line 1035
  setline(1035);
// Begin line 562
  setline(562);
// compilenode returning *var_o
  Object call1727 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1727
// compilenode returning call1727
  var_val = alloc_var();
  *var_val = call1727;
  if (call1727 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 566
  setline(566);
// Begin line 563
  setline(563);
// compilenode returning *var_val
  Object if1728;
  if (istrue(*var_val)) {
// Begin line 564
  setline(564);
// compilenode returning *var_val
// Begin line 565
  setline(565);
// compilenode returning self
  params[0] = *var_val;
  Object call1729 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1729
  *var_val = call1729;
  if (call1729 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1728 = nothing;
  } else {
// Begin line 566
  setline(566);
  if (strlit1731 == NULL) {
    strlit1731 = alloc_String("const must have value bound.");
  }
// compilenode returning strlit1731
// compilenode returning module_util
  params[0] = strlit1731;
  Object call1732 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1732
    if1728 = call1732;
  }
// compilenode returning if1728
// Begin line 568
  setline(568);
  if (strlit1733 == NULL) {
    strlit1733 = alloc_String("  *var_");
  }
// compilenode returning strlit1733
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1735 = callmethod(strlit1733, "++", 1, params);
// compilenode returning opresult1735
  if (strlit1736 == NULL) {
    strlit1736 = alloc_String(" = ");
  }
// compilenode returning strlit1736
  params[0] = strlit1736;
  Object opresult1738 = callmethod(opresult1735, "++", 1, params);
// compilenode returning opresult1738
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1740 = callmethod(opresult1738, "++", 1, params);
// compilenode returning opresult1740
  if (strlit1741 == NULL) {
    strlit1741 = alloc_String(";");
  }
// compilenode returning strlit1741
  params[0] = strlit1741;
  Object opresult1743 = callmethod(opresult1740, "++", 1, params);
// compilenode returning opresult1743
// Begin line 569
  setline(569);
// compilenode returning self
  params[0] = opresult1743;
  Object call1744 = callmethod(self, "out",
    1, params);
// compilenode returning call1744
  if (strlit1745 == NULL) {
    strlit1745 = alloc_String("  if (");
  }
// compilenode returning strlit1745
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1747 = callmethod(strlit1745, "++", 1, params);
// compilenode returning opresult1747
  if (strlit1748 == NULL) {
    strlit1748 = alloc_String(" == undefined)");
  }
// compilenode returning strlit1748
  params[0] = strlit1748;
  Object opresult1750 = callmethod(opresult1747, "++", 1, params);
// compilenode returning opresult1750
// Begin line 570
  setline(570);
// compilenode returning self
  params[0] = opresult1750;
  Object call1751 = callmethod(self, "out",
    1, params);
// compilenode returning call1751
  if (strlit1752 == NULL) {
    strlit1752 = alloc_String("    callmethod(nothing, ""\x22""assignment""\x22"", 0, NULL);");
  }
// compilenode returning strlit1752
// Begin line 571
  setline(571);
// compilenode returning self
  params[0] = strlit1752;
  Object call1753 = callmethod(self, "out",
    1, params);
// compilenode returning call1753
// Begin line 572
  setline(572);
// Begin line 1035
  setline(1035);
// Begin line 571
  setline(571);
  if (strlit1754 == NULL) {
    strlit1754 = alloc_String("nothing");
  }
// compilenode returning strlit1754
// compilenode returning *var_o
  params[0] = strlit1754;
  Object call1755 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1755
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilevardec1756(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[24];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_hadval = alloc_var();
  *var_hadval = undefined;
// Begin line 574
  setline(574);
// Begin line 1035
  setline(1035);
// Begin line 574
  setline(574);
// Begin line 1035
  setline(1035);
// Begin line 574
  setline(574);
// compilenode returning *var_o
  Object call1757 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1757
// compilenode returning call1757
  Object call1758 = callmethod(call1757, "value",
    0, params);
// compilenode returning call1758
// compilenode returning call1758
// Begin line 575
  setline(575);
// compilenode returning self
  params[0] = call1758;
  Object call1759 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call1759
  var_nm = alloc_var();
  *var_nm = call1759;
  if (call1759 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_nm
// compilenode returning *var_declaredvars
  params[0] = *var_nm;
  Object call1760 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1760
// Begin line 577
  setline(577);
// Begin line 1035
  setline(1035);
// Begin line 576
  setline(576);
// compilenode returning *var_o
  Object call1761 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1761
// compilenode returning call1761
  var_val = alloc_var();
  *var_val = call1761;
  if (call1761 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 578
  setline(578);
// Begin line 577
  setline(577);
  Object bool1762 = alloc_Boolean(0);
// compilenode returning bool1762
  var_hadval = alloc_var();
  *var_hadval = bool1762;
  if (bool1762 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 583
  setline(583);
// Begin line 578
  setline(578);
// compilenode returning *var_val
  Object if1763;
  if (istrue(*var_val)) {
// Begin line 579
  setline(579);
// compilenode returning *var_val
// Begin line 580
  setline(580);
// compilenode returning self
  params[0] = *var_val;
  Object call1764 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1764
  *var_val = call1764;
  if (call1764 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 581
  setline(581);
// Begin line 580
  setline(580);
  Object bool1766 = alloc_Boolean(1);
// compilenode returning bool1766
  *var_hadval = bool1766;
  if (bool1766 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1763 = nothing;
  } else {
// Begin line 583
  setline(583);
// Begin line 582
  setline(582);
  if (strlit1768 == NULL) {
    strlit1768 = alloc_String("undefined");
  }
// compilenode returning strlit1768
  *var_val = strlit1768;
  if (strlit1768 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1763 = nothing;
  }
// compilenode returning if1763
// Begin line 584
  setline(584);
  if (strlit1770 == NULL) {
    strlit1770 = alloc_String("  var_");
  }
// compilenode returning strlit1770
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1772 = callmethod(strlit1770, "++", 1, params);
// compilenode returning opresult1772
  if (strlit1773 == NULL) {
    strlit1773 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit1773
  params[0] = strlit1773;
  Object opresult1775 = callmethod(opresult1772, "++", 1, params);
// compilenode returning opresult1775
// Begin line 585
  setline(585);
// compilenode returning self
  params[0] = opresult1775;
  Object call1776 = callmethod(self, "out",
    1, params);
// compilenode returning call1776
  if (strlit1777 == NULL) {
    strlit1777 = alloc_String("  *var_");
  }
// compilenode returning strlit1777
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1779 = callmethod(strlit1777, "++", 1, params);
// compilenode returning opresult1779
  if (strlit1780 == NULL) {
    strlit1780 = alloc_String(" = ");
  }
// compilenode returning strlit1780
  params[0] = strlit1780;
  Object opresult1782 = callmethod(opresult1779, "++", 1, params);
// compilenode returning opresult1782
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1784 = callmethod(opresult1782, "++", 1, params);
// compilenode returning opresult1784
  if (strlit1785 == NULL) {
    strlit1785 = alloc_String(";");
  }
// compilenode returning strlit1785
  params[0] = strlit1785;
  Object opresult1787 = callmethod(opresult1784, "++", 1, params);
// compilenode returning opresult1787
// Begin line 586
  setline(586);
// compilenode returning self
  params[0] = opresult1787;
  Object call1788 = callmethod(self, "out",
    1, params);
// compilenode returning call1788
// Begin line 588
  setline(588);
// Begin line 586
  setline(586);
// compilenode returning *var_hadval
  Object if1789;
  if (istrue(*var_hadval)) {
// Begin line 587
  setline(587);
  if (strlit1790 == NULL) {
    strlit1790 = alloc_String("  if (");
  }
// compilenode returning strlit1790
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1792 = callmethod(strlit1790, "++", 1, params);
// compilenode returning opresult1792
  if (strlit1793 == NULL) {
    strlit1793 = alloc_String(" == undefined)");
  }
// compilenode returning strlit1793
  params[0] = strlit1793;
  Object opresult1795 = callmethod(opresult1792, "++", 1, params);
// compilenode returning opresult1795
// Begin line 588
  setline(588);
// compilenode returning self
  params[0] = opresult1795;
  Object call1796 = callmethod(self, "out",
    1, params);
// compilenode returning call1796
  if (strlit1797 == NULL) {
    strlit1797 = alloc_String("    callmethod(nothing, ""\x22""assignment""\x22"", 0, NULL);");
  }
// compilenode returning strlit1797
// Begin line 589
  setline(589);
// compilenode returning self
  params[0] = strlit1797;
  Object call1798 = callmethod(self, "out",
    1, params);
// compilenode returning call1798
    if1789 = call1798;
  } else {
  }
// compilenode returning if1789
// Begin line 591
  setline(591);
// Begin line 1035
  setline(1035);
// Begin line 590
  setline(590);
  if (strlit1799 == NULL) {
    strlit1799 = alloc_String("nothing");
  }
// compilenode returning strlit1799
// compilenode returning *var_o
  params[0] = strlit1799;
  Object call1800 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1800
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileindex1801(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[25];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_of = alloc_var();
  *var_of = undefined;
  Object *var_index = alloc_var();
  *var_index = undefined;
// Begin line 593
  setline(593);
// Begin line 1035
  setline(1035);
// Begin line 593
  setline(593);
// compilenode returning *var_o
  Object call1802 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1802
// compilenode returning call1802
// Begin line 594
  setline(594);
// compilenode returning self
  params[0] = call1802;
  Object call1803 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1803
  var_of = alloc_var();
  *var_of = call1803;
  if (call1803 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// Begin line 594
  setline(594);
// compilenode returning *var_o
  Object call1804 = callmethod(*var_o, "index",
    0, params);
// compilenode returning call1804
// compilenode returning call1804
// Begin line 595
  setline(595);
// compilenode returning self
  params[0] = call1804;
  Object call1805 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1805
  var_index = alloc_var();
  *var_index = call1805;
  if (call1805 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit1806 == NULL) {
    strlit1806 = alloc_String("  params[0] = ");
  }
// compilenode returning strlit1806
// compilenode returning *var_index
  params[0] = *var_index;
  Object opresult1808 = callmethod(strlit1806, "++", 1, params);
// compilenode returning opresult1808
  if (strlit1809 == NULL) {
    strlit1809 = alloc_String(";");
  }
// compilenode returning strlit1809
  params[0] = strlit1809;
  Object opresult1811 = callmethod(opresult1808, "++", 1, params);
// compilenode returning opresult1811
// Begin line 596
  setline(596);
// compilenode returning self
  params[0] = opresult1811;
  Object call1812 = callmethod(self, "out",
    1, params);
// compilenode returning call1812
  if (strlit1813 == NULL) {
    strlit1813 = alloc_String("  Object idxres");
  }
// compilenode returning strlit1813
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1815 = callmethod(strlit1813, "++", 1, params);
// compilenode returning opresult1815
  if (strlit1816 == NULL) {
    strlit1816 = alloc_String(" = callmethod(");
  }
// compilenode returning strlit1816
  params[0] = strlit1816;
  Object opresult1818 = callmethod(opresult1815, "++", 1, params);
// compilenode returning opresult1818
// compilenode returning *var_of
  params[0] = *var_of;
  Object opresult1820 = callmethod(opresult1818, "++", 1, params);
// compilenode returning opresult1820
  if (strlit1821 == NULL) {
    strlit1821 = alloc_String(", ""\x22""[]""\x22"", 1, params);");
  }
// compilenode returning strlit1821
  params[0] = strlit1821;
  Object opresult1823 = callmethod(opresult1820, "++", 1, params);
// compilenode returning opresult1823
// Begin line 597
  setline(597);
// compilenode returning self
  params[0] = opresult1823;
  Object call1824 = callmethod(self, "out",
    1, params);
// compilenode returning call1824
// Begin line 598
  setline(598);
// Begin line 1035
  setline(1035);
// Begin line 598
  setline(598);
// Begin line 597
  setline(597);
  if (strlit1825 == NULL) {
    strlit1825 = alloc_String("idxres");
  }
// compilenode returning strlit1825
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1827 = callmethod(strlit1825, "++", 1, params);
// compilenode returning opresult1827
// compilenode returning *var_o
  params[0] = opresult1827;
  Object call1828 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1828
// compilenode returning nothing
// Begin line 599
  setline(599);
// Begin line 598
  setline(598);
// compilenode returning *var_auto_count
  Object num1829 = alloc_Float64(1.0);
// compilenode returning num1829
  params[0] = num1829;
  Object sum1831 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1831
  *var_auto_count = sum1831;
  if (sum1831 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileop1833(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[26];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_left = alloc_var();
  *var_left = undefined;
  Object *var_right = alloc_var();
  *var_right = undefined;
// Begin line 601
  setline(601);
// Begin line 1035
  setline(1035);
// Begin line 601
  setline(601);
// compilenode returning *var_o
  Object call1834 = callmethod(*var_o, "left",
    0, params);
// compilenode returning call1834
// compilenode returning call1834
// Begin line 602
  setline(602);
// compilenode returning self
  params[0] = call1834;
  Object call1835 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1835
  var_left = alloc_var();
  *var_left = call1835;
  if (call1835 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// Begin line 602
  setline(602);
// compilenode returning *var_o
  Object call1836 = callmethod(*var_o, "right",
    0, params);
// compilenode returning call1836
// compilenode returning call1836
// Begin line 603
  setline(603);
// compilenode returning self
  params[0] = call1836;
  Object call1837 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1837
  var_right = alloc_var();
  *var_right = call1837;
  if (call1837 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 604
  setline(604);
// Begin line 603
  setline(603);
// compilenode returning *var_auto_count
  Object num1838 = alloc_Float64(1.0);
// compilenode returning num1838
  params[0] = num1838;
  Object sum1840 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1840
  *var_auto_count = sum1840;
  if (sum1840 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 634
  setline(634);
// Begin line 635
  setline(635);
// Begin line 1035
  setline(1035);
// Begin line 604
  setline(604);
// compilenode returning *var_o
  Object call1843 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1843
// compilenode returning call1843
  if (strlit1844 == NULL) {
    strlit1844 = alloc_String("+");
  }
// compilenode returning strlit1844
  params[0] = strlit1844;
  Object opresult1846 = callmethod(call1843, "==", 1, params);
// compilenode returning opresult1846
// Begin line 635
  setline(635);
// Begin line 1035
  setline(1035);
// Begin line 604
  setline(604);
// compilenode returning *var_o
  Object call1847 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1847
// compilenode returning call1847
  if (strlit1848 == NULL) {
    strlit1848 = alloc_String("*");
  }
// compilenode returning strlit1848
  params[0] = strlit1848;
  Object opresult1850 = callmethod(call1847, "==", 1, params);
// compilenode returning opresult1850
  params[0] = opresult1850;
  Object opresult1852 = callmethod(opresult1846, "|", 1, params);
// compilenode returning opresult1852
// Begin line 635
  setline(635);
// Begin line 1035
  setline(1035);
// Begin line 604
  setline(604);
// compilenode returning *var_o
  Object call1853 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1853
// compilenode returning call1853
  if (strlit1854 == NULL) {
    strlit1854 = alloc_String("/");
  }
// compilenode returning strlit1854
  params[0] = strlit1854;
  Object opresult1856 = callmethod(call1853, "==", 1, params);
// compilenode returning opresult1856
  params[0] = opresult1856;
  Object opresult1858 = callmethod(opresult1852, "|", 1, params);
// compilenode returning opresult1858
// Begin line 635
  setline(635);
// Begin line 1035
  setline(1035);
// Begin line 605
  setline(605);
// compilenode returning *var_o
  Object call1859 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1859
// compilenode returning call1859
  if (strlit1860 == NULL) {
    strlit1860 = alloc_String("-");
  }
// compilenode returning strlit1860
  params[0] = strlit1860;
  Object opresult1862 = callmethod(call1859, "==", 1, params);
// compilenode returning opresult1862
  params[0] = opresult1862;
  Object opresult1864 = callmethod(opresult1858, "|", 1, params);
// compilenode returning opresult1864
// Begin line 635
  setline(635);
// Begin line 1035
  setline(1035);
// Begin line 605
  setline(605);
// compilenode returning *var_o
  Object call1865 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1865
// compilenode returning call1865
  if (strlit1866 == NULL) {
    strlit1866 = alloc_String("%");
  }
// compilenode returning strlit1866
  params[0] = strlit1866;
  Object opresult1868 = callmethod(call1865, "==", 1, params);
// compilenode returning opresult1868
  params[0] = opresult1868;
  Object opresult1870 = callmethod(opresult1864, "|", 1, params);
// compilenode returning opresult1870
  Object if1842;
  if (istrue(opresult1870)) {
  Object *var_rnm = alloc_var();
  *var_rnm = undefined;
// Begin line 607
  setline(607);
// Begin line 606
  setline(606);
  if (strlit1871 == NULL) {
    strlit1871 = alloc_String("sum");
  }
// compilenode returning strlit1871
  var_rnm = alloc_var();
  *var_rnm = strlit1871;
  if (strlit1871 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 609
  setline(609);
// Begin line 610
  setline(610);
// Begin line 1035
  setline(1035);
// Begin line 607
  setline(607);
// compilenode returning *var_o
  Object call1873 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1873
// compilenode returning call1873
  if (strlit1874 == NULL) {
    strlit1874 = alloc_String("*");
  }
// compilenode returning strlit1874
  params[0] = strlit1874;
  Object opresult1876 = callmethod(call1873, "==", 1, params);
// compilenode returning opresult1876
  Object if1872;
  if (istrue(opresult1876)) {
// Begin line 609
  setline(609);
// Begin line 608
  setline(608);
  if (strlit1877 == NULL) {
    strlit1877 = alloc_String("prod");
  }
// compilenode returning strlit1877
  *var_rnm = strlit1877;
  if (strlit1877 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1872 = nothing;
  } else {
  }
// compilenode returning if1872
// Begin line 612
  setline(612);
// Begin line 613
  setline(613);
// Begin line 1035
  setline(1035);
// Begin line 610
  setline(610);
// compilenode returning *var_o
  Object call1880 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1880
// compilenode returning call1880
  if (strlit1881 == NULL) {
    strlit1881 = alloc_String("/");
  }
// compilenode returning strlit1881
  params[0] = strlit1881;
  Object opresult1883 = callmethod(call1880, "==", 1, params);
// compilenode returning opresult1883
  Object if1879;
  if (istrue(opresult1883)) {
// Begin line 612
  setline(612);
// Begin line 611
  setline(611);
  if (strlit1884 == NULL) {
    strlit1884 = alloc_String("quotient");
  }
// compilenode returning strlit1884
  *var_rnm = strlit1884;
  if (strlit1884 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1879 = nothing;
  } else {
  }
// compilenode returning if1879
// Begin line 615
  setline(615);
// Begin line 616
  setline(616);
// Begin line 1035
  setline(1035);
// Begin line 613
  setline(613);
// compilenode returning *var_o
  Object call1887 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1887
// compilenode returning call1887
  if (strlit1888 == NULL) {
    strlit1888 = alloc_String("-");
  }
// compilenode returning strlit1888
  params[0] = strlit1888;
  Object opresult1890 = callmethod(call1887, "==", 1, params);
// compilenode returning opresult1890
  Object if1886;
  if (istrue(opresult1890)) {
// Begin line 615
  setline(615);
// Begin line 614
  setline(614);
  if (strlit1891 == NULL) {
    strlit1891 = alloc_String("diff");
  }
// compilenode returning strlit1891
  *var_rnm = strlit1891;
  if (strlit1891 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1886 = nothing;
  } else {
  }
// compilenode returning if1886
// Begin line 618
  setline(618);
// Begin line 619
  setline(619);
// Begin line 1035
  setline(1035);
// Begin line 616
  setline(616);
// compilenode returning *var_o
  Object call1894 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1894
// compilenode returning call1894
  if (strlit1895 == NULL) {
    strlit1895 = alloc_String("%");
  }
// compilenode returning strlit1895
  params[0] = strlit1895;
  Object opresult1897 = callmethod(call1894, "==", 1, params);
// compilenode returning opresult1897
  Object if1893;
  if (istrue(opresult1897)) {
// Begin line 618
  setline(618);
// Begin line 617
  setline(617);
  if (strlit1898 == NULL) {
    strlit1898 = alloc_String("modulus");
  }
// compilenode returning strlit1898
  *var_rnm = strlit1898;
  if (strlit1898 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1893 = nothing;
  } else {
  }
// compilenode returning if1893
// Begin line 619
  setline(619);
  if (strlit1900 == NULL) {
    strlit1900 = alloc_String("  params[0] = ");
  }
// compilenode returning strlit1900
// compilenode returning *var_right
  params[0] = *var_right;
  Object opresult1902 = callmethod(strlit1900, "++", 1, params);
// compilenode returning opresult1902
  if (strlit1903 == NULL) {
    strlit1903 = alloc_String(";");
  }
// compilenode returning strlit1903
  params[0] = strlit1903;
  Object opresult1905 = callmethod(opresult1902, "++", 1, params);
// compilenode returning opresult1905
// Begin line 620
  setline(620);
// compilenode returning self
  params[0] = opresult1905;
  Object call1906 = callmethod(self, "out",
    1, params);
// compilenode returning call1906
// Begin line 621
  setline(621);
// Begin line 620
  setline(620);
  if (strlit1907 == NULL) {
    strlit1907 = alloc_String("  Object ");
  }
// compilenode returning strlit1907
// compilenode returning *var_rnm
  params[0] = *var_rnm;
  Object opresult1909 = callmethod(strlit1907, "++", 1, params);
// compilenode returning opresult1909
  if (strlit1910 == NULL) {
    strlit1910 = alloc_String("");
  }
// compilenode returning strlit1910
  params[0] = strlit1910;
  Object opresult1912 = callmethod(opresult1909, "++", 1, params);
// compilenode returning opresult1912
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1914 = callmethod(opresult1912, "++", 1, params);
// compilenode returning opresult1914
  if (strlit1915 == NULL) {
    strlit1915 = alloc_String(" = callmethod(");
  }
// compilenode returning strlit1915
  params[0] = strlit1915;
  Object opresult1917 = callmethod(opresult1914, "++", 1, params);
// compilenode returning opresult1917
// compilenode returning *var_left
  params[0] = *var_left;
  Object opresult1919 = callmethod(opresult1917, "++", 1, params);
// compilenode returning opresult1919
  if (strlit1920 == NULL) {
    strlit1920 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit1920
  params[0] = strlit1920;
  Object opresult1922 = callmethod(opresult1919, "++", 1, params);
// compilenode returning opresult1922
// Begin line 621
  setline(621);
// Begin line 1035
  setline(1035);
// Begin line 620
  setline(620);
// compilenode returning *var_o
  Object call1923 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1923
// compilenode returning call1923
  params[0] = call1923;
  Object opresult1925 = callmethod(opresult1922, "++", 1, params);
// compilenode returning opresult1925
  if (strlit1926 == NULL) {
    strlit1926 = alloc_String("""\x22"", ");
  }
// compilenode returning strlit1926
  params[0] = strlit1926;
  Object opresult1928 = callmethod(opresult1925, "++", 1, params);
// compilenode returning opresult1928
// Begin line 621
  setline(621);
  if (strlit1929 == NULL) {
    strlit1929 = alloc_String("1, params);");
  }
// compilenode returning strlit1929
  params[0] = strlit1929;
  Object opresult1931 = callmethod(opresult1928, "++", 1, params);
// compilenode returning opresult1931
// Begin line 622
  setline(622);
// compilenode returning self
  params[0] = opresult1931;
  Object call1932 = callmethod(self, "out",
    1, params);
// compilenode returning call1932
// Begin line 623
  setline(623);
// Begin line 1035
  setline(1035);
// Begin line 623
  setline(623);
// Begin line 622
  setline(622);
// compilenode returning *var_rnm
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1934 = callmethod(*var_rnm, "++", 1, params);
// compilenode returning opresult1934
// compilenode returning *var_o
  params[0] = opresult1934;
  Object call1935 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1935
// compilenode returning nothing
// Begin line 624
  setline(624);
// Begin line 623
  setline(623);
// compilenode returning *var_auto_count
  Object num1936 = alloc_Float64(1.0);
// compilenode returning num1936
  params[0] = num1936;
  Object sum1938 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1938
  *var_auto_count = sum1938;
  if (sum1938 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1842 = nothing;
  } else {
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_evl = alloc_var();
  *var_evl = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 625
  setline(625);
// Begin line 1035
  setline(1035);
// Begin line 625
  setline(625);
// compilenode returning *var_o
  Object call1940 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1940
// compilenode returning call1940
  Object call1941 = gracelib_length(call1940);
// compilenode returning call1941
  Object num1942 = alloc_Float64(1.0);
// compilenode returning num1942
  params[0] = num1942;
  Object sum1944 = callmethod(call1941, "+", 1, params);
// compilenode returning sum1944
  var_len = alloc_var();
  *var_len = sum1944;
  if (sum1944 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 626
  setline(626);
// Begin line 1035
  setline(1035);
// Begin line 626
  setline(626);
// compilenode returning *var_o
  Object call1945 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1945
// compilenode returning call1945
// Begin line 627
  setline(627);
// compilenode returning self
  params[0] = call1945;
  Object call1946 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call1946
  var_evl = alloc_var();
  *var_evl = call1946;
  if (call1946 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 629
  setline(629);
// Begin line 627
  setline(627);
  if (strlit1947 == NULL) {
    strlit1947 = alloc_String("@.str");
  }
// compilenode returning strlit1947
// Begin line 629
  setline(629);
// Begin line 1035
  setline(1035);
// Begin line 627
  setline(627);
// compilenode returning *var_constants
  Object call1948 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call1948
// compilenode returning call1948
  params[0] = call1948;
  Object opresult1950 = callmethod(strlit1947, "++", 1, params);
// compilenode returning opresult1950
  if (strlit1951 == NULL) {
    strlit1951 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit1951
  params[0] = strlit1951;
  Object opresult1953 = callmethod(opresult1950, "++", 1, params);
// compilenode returning opresult1953
// Begin line 628
  setline(628);
  if (strlit1954 == NULL) {
    strlit1954 = alloc_String("constant [");
  }
// compilenode returning strlit1954
  params[0] = strlit1954;
  Object opresult1956 = callmethod(opresult1953, "++", 1, params);
// compilenode returning opresult1956
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult1958 = callmethod(opresult1956, "++", 1, params);
// compilenode returning opresult1958
  if (strlit1959 == NULL) {
    strlit1959 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit1959
  params[0] = strlit1959;
  Object opresult1961 = callmethod(opresult1958, "++", 1, params);
// compilenode returning opresult1961
// compilenode returning *var_evl
  params[0] = *var_evl;
  Object opresult1963 = callmethod(opresult1961, "++", 1, params);
// compilenode returning opresult1963
  if (strlit1964 == NULL) {
    strlit1964 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit1964
  params[0] = strlit1964;
  Object opresult1966 = callmethod(opresult1963, "++", 1, params);
// compilenode returning opresult1966
  var_con = alloc_var();
  *var_con = opresult1966;
  if (opresult1966 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 629
  setline(629);
  if (strlit1967 == NULL) {
    strlit1967 = alloc_String("  params[0] = ");
  }
// compilenode returning strlit1967
// compilenode returning *var_right
  params[0] = *var_right;
  Object opresult1969 = callmethod(strlit1967, "++", 1, params);
// compilenode returning opresult1969
  if (strlit1970 == NULL) {
    strlit1970 = alloc_String(";");
  }
// compilenode returning strlit1970
  params[0] = strlit1970;
  Object opresult1972 = callmethod(opresult1969, "++", 1, params);
// compilenode returning opresult1972
// Begin line 630
  setline(630);
// compilenode returning self
  params[0] = opresult1972;
  Object call1973 = callmethod(self, "out",
    1, params);
// compilenode returning call1973
// Begin line 631
  setline(631);
// Begin line 630
  setline(630);
  if (strlit1974 == NULL) {
    strlit1974 = alloc_String("  Object opresult");
  }
// compilenode returning strlit1974
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1976 = callmethod(strlit1974, "++", 1, params);
// compilenode returning opresult1976
  if (strlit1977 == NULL) {
    strlit1977 = alloc_String(" = ");
  }
// compilenode returning strlit1977
  params[0] = strlit1977;
  Object opresult1979 = callmethod(opresult1976, "++", 1, params);
// compilenode returning opresult1979
// Begin line 631
  setline(631);
  if (strlit1980 == NULL) {
    strlit1980 = alloc_String("callmethod(");
  }
// compilenode returning strlit1980
// compilenode returning *var_left
  params[0] = *var_left;
  Object opresult1982 = callmethod(strlit1980, "++", 1, params);
// compilenode returning opresult1982
  if (strlit1983 == NULL) {
    strlit1983 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit1983
  params[0] = strlit1983;
  Object opresult1985 = callmethod(opresult1982, "++", 1, params);
// compilenode returning opresult1985
// Begin line 1035
  setline(1035);
// Begin line 631
  setline(631);
// compilenode returning *var_o
  Object call1986 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1986
// compilenode returning call1986
  params[0] = call1986;
  Object opresult1988 = callmethod(opresult1985, "++", 1, params);
// compilenode returning opresult1988
  if (strlit1989 == NULL) {
    strlit1989 = alloc_String("""\x22"", 1, params);");
  }
// compilenode returning strlit1989
  params[0] = strlit1989;
  Object opresult1991 = callmethod(opresult1988, "++", 1, params);
// compilenode returning opresult1991
  params[0] = opresult1991;
  Object opresult1993 = callmethod(opresult1979, "++", 1, params);
// compilenode returning opresult1993
// Begin line 632
  setline(632);
// compilenode returning self
  params[0] = opresult1993;
  Object call1994 = callmethod(self, "out",
    1, params);
// compilenode returning call1994
// Begin line 633
  setline(633);
// Begin line 1035
  setline(1035);
// Begin line 633
  setline(633);
// Begin line 632
  setline(632);
  if (strlit1995 == NULL) {
    strlit1995 = alloc_String("opresult");
  }
// compilenode returning strlit1995
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1997 = callmethod(strlit1995, "++", 1, params);
// compilenode returning opresult1997
// compilenode returning *var_o
  params[0] = opresult1997;
  Object call1998 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1998
// compilenode returning nothing
// Begin line 634
  setline(634);
// Begin line 633
  setline(633);
// compilenode returning *var_auto_count
  Object num1999 = alloc_Float64(1.0);
// compilenode returning num1999
  params[0] = num1999;
  Object sum2001 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2001
  *var_auto_count = sum2001;
  if (sum2001 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1842 = nothing;
  }
// compilenode returning if1842
  return if1842;
}
Object meth_genc_apply2013(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_args = closure[0];
  Object self = *closure[1];
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 643
  setline(643);
// compilenode returning *var_p
// Begin line 644
  setline(644);
// compilenode returning self
  params[0] = *var_p;
  Object call2014 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2014
  var_r = alloc_var();
  *var_r = call2014;
  if (call2014 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_args
  params[0] = *var_r;
  Object call2015 = callmethod(*var_args, "push",
    1, params);
// compilenode returning call2015
  return call2015;
}
Object meth_genc_apply2048(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object self = *closure[1];
// Begin line 654
  setline(654);
  if (strlit2049 == NULL) {
    strlit2049 = alloc_String("  params[");
  }
// compilenode returning strlit2049
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult2051 = callmethod(strlit2049, "++", 1, params);
// compilenode returning opresult2051
  if (strlit2052 == NULL) {
    strlit2052 = alloc_String("] = ");
  }
// compilenode returning strlit2052
  params[0] = strlit2052;
  Object opresult2054 = callmethod(opresult2051, "++", 1, params);
// compilenode returning opresult2054
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult2056 = callmethod(opresult2054, "++", 1, params);
// compilenode returning opresult2056
  if (strlit2057 == NULL) {
    strlit2057 = alloc_String(";");
  }
// compilenode returning strlit2057
  params[0] = strlit2057;
  Object opresult2059 = callmethod(opresult2056, "++", 1, params);
// compilenode returning opresult2059
// Begin line 655
  setline(655);
// compilenode returning self
  params[0] = opresult2059;
  Object call2060 = callmethod(self, "out",
    1, params);
// compilenode returning call2060
// Begin line 656
  setline(656);
// Begin line 655
  setline(655);
// compilenode returning *var_i
  Object num2061 = alloc_Float64(1.0);
// compilenode returning num2061
  params[0] = num2061;
  Object sum2063 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum2063
  *var_i = sum2063;
  if (sum2063 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply2104(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object self = *closure[1];
// Begin line 663
  setline(663);
  if (strlit2105 == NULL) {
    strlit2105 = alloc_String("  params[");
  }
// compilenode returning strlit2105
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult2107 = callmethod(strlit2105, "++", 1, params);
// compilenode returning opresult2107
  if (strlit2108 == NULL) {
    strlit2108 = alloc_String("] = ");
  }
// compilenode returning strlit2108
  params[0] = strlit2108;
  Object opresult2110 = callmethod(opresult2107, "++", 1, params);
// compilenode returning opresult2110
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult2112 = callmethod(opresult2110, "++", 1, params);
// compilenode returning opresult2112
  if (strlit2113 == NULL) {
    strlit2113 = alloc_String(";");
  }
// compilenode returning strlit2113
  params[0] = strlit2113;
  Object opresult2115 = callmethod(opresult2112, "++", 1, params);
// compilenode returning opresult2115
// Begin line 664
  setline(664);
// compilenode returning self
  params[0] = opresult2115;
  Object call2116 = callmethod(self, "out",
    1, params);
// compilenode returning call2116
// Begin line 665
  setline(665);
// Begin line 664
  setline(664);
// compilenode returning *var_i
  Object num2117 = alloc_Float64(1.0);
// compilenode returning num2117
  params[0] = num2117;
  Object sum2119 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum2119
  *var_i = sum2119;
  if (sum2119 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilecall2003(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[27];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_paramsUsed = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_args = alloc_var();
  *var_args = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_evl = alloc_var();
  *var_evl = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
// Begin line 638
  setline(638);
  Object array2004 = alloc_List();
// compilenode returning array2004
  var_args = alloc_var();
  *var_args = array2004;
  if (array2004 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 639
  setline(639);
// Begin line 638
  setline(638);
  if (strlit2005 == NULL) {
    strlit2005 = alloc_String("");
  }
// compilenode returning strlit2005
  var_obj = alloc_var();
  *var_obj = strlit2005;
  if (strlit2005 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 640
  setline(640);
// Begin line 639
  setline(639);
  Object num2006 = alloc_Float64(0.0);
// compilenode returning num2006
  var_len = alloc_var();
  *var_len = num2006;
  if (num2006 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 641
  setline(641);
  var_evl = alloc_var();
  *var_evl = undefined;
// compilenode returning nothing
// Begin line 642
  setline(642);
// Begin line 641
  setline(641);
  Object num2007 = alloc_Float64(0.0);
// compilenode returning num2007
  var_i = alloc_var();
  *var_i = num2007;
  if (num2007 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 644
  setline(644);
// Begin line 646
  setline(646);
// Begin line 1035
  setline(1035);
// Begin line 642
  setline(642);
// compilenode returning *var_o
  Object call2009 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call2009
// compilenode returning call2009
// Begin line 644
  setline(644);
// Begin line 1035
  setline(1035);
  Object obj2011 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2011, self, 0);
  addmethod2(obj2011, "outer", &reader_genc_outer_2012);
  adddatum2(obj2011, self, 0);
  block_savedest(obj2011);
  Object **closure2013 = createclosure(2);
  addtoclosure(closure2013, var_args);
  Object *selfpp2016 = alloc_var();
  *selfpp2016 = self;
  addtoclosure(closure2013, selfpp2016);
  struct UserObject *uo2013 = (struct UserObject*)obj2011;
  uo2013->data[1] = (Object)closure2013;
  addmethod2(obj2011, "apply", &meth_genc_apply2013);
  set_type(obj2011, 0);
// compilenode returning obj2011
  setclassname(obj2011, "Block<genc:2010>");
// compilenode returning obj2011
  params[0] = call2009;
  Object iter2008 = callmethod(call2009, "iter", 1, params);
  while(1) {
    Object cond2008 = callmethod(iter2008, "havemore", 0, NULL);
    if (!istrue(cond2008)) break;
    params[0] = callmethod(iter2008, "next", 0, NULL);
    callmethod(obj2011, "apply", 1, params);
  }
// compilenode returning call2009
// Begin line 648
  setline(648);
// Begin line 649
  setline(649);
// Begin line 1035
  setline(1035);
// Begin line 646
  setline(646);
// compilenode returning *var_args
  Object call2018 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2018
// compilenode returning call2018
// compilenode returning *var_paramsUsed
  params[0] = *var_paramsUsed;
  Object opresult2020 = callmethod(call2018, ">", 1, params);
// compilenode returning opresult2020
  Object if2017;
  if (istrue(opresult2020)) {
// Begin line 648
  setline(648);
// Begin line 1035
  setline(1035);
// Begin line 647
  setline(647);
// compilenode returning *var_args
  Object call2021 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2021
// compilenode returning call2021
  *var_paramsUsed = call2021;
  if (call2021 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2017 = nothing;
  } else {
  }
// compilenode returning if2017
// Begin line 649
  setline(649);
// Begin line 1035
  setline(1035);
// Begin line 649
  setline(649);
// Begin line 1035
  setline(1035);
// Begin line 649
  setline(649);
// compilenode returning *var_o
  Object call2023 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2023
// compilenode returning call2023
  Object call2024 = callmethod(call2023, "value",
    0, params);
// compilenode returning call2024
// compilenode returning call2024
// Begin line 650
  setline(650);
// compilenode returning self
  params[0] = call2024;
  Object call2025 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call2025
  *var_evl = call2025;
  if (call2025 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 667
  setline(667);
// Begin line 669
  setline(669);
// Begin line 1035
  setline(1035);
// Begin line 669
  setline(669);
// Begin line 1035
  setline(1035);
// Begin line 650
  setline(650);
// compilenode returning *var_o
  Object call2028 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2028
// compilenode returning call2028
  Object call2029 = callmethod(call2028, "kind",
    0, params);
// compilenode returning call2029
// compilenode returning call2029
  if (strlit2030 == NULL) {
    strlit2030 = alloc_String("member");
  }
// compilenode returning strlit2030
  params[0] = strlit2030;
  Object opresult2032 = callmethod(call2029, "==", 1, params);
// compilenode returning opresult2032
  Object if2027;
  if (istrue(opresult2032)) {
// Begin line 651
  setline(651);
// Begin line 1035
  setline(1035);
// Begin line 651
  setline(651);
// Begin line 1035
  setline(1035);
// Begin line 651
  setline(651);
// compilenode returning *var_o
  Object call2033 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2033
// compilenode returning call2033
  Object call2034 = callmethod(call2033, "in",
    0, params);
// compilenode returning call2034
// compilenode returning call2034
// Begin line 652
  setline(652);
// compilenode returning self
  params[0] = call2034;
  Object call2035 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2035
  *var_obj = call2035;
  if (call2035 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// Begin line 652
  setline(652);
// Begin line 1035
  setline(1035);
// Begin line 652
  setline(652);
// compilenode returning *var_o
  Object call2037 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2037
// compilenode returning call2037
  Object call2038 = callmethod(call2037, "value",
    0, params);
// compilenode returning call2038
// compilenode returning call2038
  Object call2039 = gracelib_length(call2038);
// compilenode returning call2039
  Object num2040 = alloc_Float64(1.0);
// compilenode returning num2040
  params[0] = num2040;
  Object sum2042 = callmethod(call2039, "+", 1, params);
// compilenode returning sum2042
  *var_len = sum2042;
  if (sum2042 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 656
  setline(656);
// Begin line 653
  setline(653);
// compilenode returning *var_args
// Begin line 656
  setline(656);
// Begin line 1035
  setline(1035);
  Object obj2046 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2046, self, 0);
  addmethod2(obj2046, "outer", &reader_genc_outer_2047);
  adddatum2(obj2046, self, 0);
  block_savedest(obj2046);
  Object **closure2048 = createclosure(2);
  addtoclosure(closure2048, var_i);
  Object *selfpp2065 = alloc_var();
  *selfpp2065 = self;
  addtoclosure(closure2048, selfpp2065);
  struct UserObject *uo2048 = (struct UserObject*)obj2046;
  uo2048->data[1] = (Object)closure2048;
  addmethod2(obj2046, "apply", &meth_genc_apply2048);
  set_type(obj2046, 0);
// compilenode returning obj2046
  setclassname(obj2046, "Block<genc:2045>");
// compilenode returning obj2046
  params[0] = *var_args;
  Object iter2044 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond2044 = callmethod(iter2044, "havemore", 0, NULL);
    if (!istrue(cond2044)) break;
    params[0] = callmethod(iter2044, "next", 0, NULL);
    callmethod(obj2046, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 657
  setline(657);
  if (strlit2066 == NULL) {
    strlit2066 = alloc_String("  Object call");
  }
// compilenode returning strlit2066
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2068 = callmethod(strlit2066, "++", 1, params);
// compilenode returning opresult2068
  if (strlit2069 == NULL) {
    strlit2069 = alloc_String(" = callmethod(");
  }
// compilenode returning strlit2069
  params[0] = strlit2069;
  Object opresult2071 = callmethod(opresult2068, "++", 1, params);
// compilenode returning opresult2071
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult2073 = callmethod(opresult2071, "++", 1, params);
// compilenode returning opresult2073
  if (strlit2074 == NULL) {
    strlit2074 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit2074
  params[0] = strlit2074;
  Object opresult2076 = callmethod(opresult2073, "++", 1, params);
// compilenode returning opresult2076
// compilenode returning *var_evl
  params[0] = *var_evl;
  Object opresult2078 = callmethod(opresult2076, "++", 1, params);
// compilenode returning opresult2078
  if (strlit2079 == NULL) {
    strlit2079 = alloc_String("""\x22"",");
  }
// compilenode returning strlit2079
  params[0] = strlit2079;
  Object opresult2081 = callmethod(opresult2078, "++", 1, params);
// compilenode returning opresult2081
// Begin line 658
  setline(658);
// compilenode returning self
  params[0] = opresult2081;
  Object call2082 = callmethod(self, "out",
    1, params);
// compilenode returning call2082
  if (strlit2083 == NULL) {
    strlit2083 = alloc_String("    ");
  }
// compilenode returning strlit2083
// Begin line 1035
  setline(1035);
// Begin line 658
  setline(658);
// compilenode returning *var_args
  Object call2084 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2084
// compilenode returning call2084
  params[0] = call2084;
  Object opresult2086 = callmethod(strlit2083, "++", 1, params);
// compilenode returning opresult2086
  if (strlit2087 == NULL) {
    strlit2087 = alloc_String(", params);");
  }
// compilenode returning strlit2087
  params[0] = strlit2087;
  Object opresult2089 = callmethod(opresult2086, "++", 1, params);
// compilenode returning opresult2089
// Begin line 659
  setline(659);
// compilenode returning self
  params[0] = opresult2089;
  Object call2090 = callmethod(self, "out",
    1, params);
// compilenode returning call2090
    if2027 = call2090;
  } else {
// Begin line 661
  setline(661);
// Begin line 660
  setline(660);
  if (strlit2091 == NULL) {
    strlit2091 = alloc_String("self");
  }
// compilenode returning strlit2091
  *var_obj = strlit2091;
  if (strlit2091 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 661
  setline(661);
// Begin line 1035
  setline(1035);
// Begin line 661
  setline(661);
// Begin line 1035
  setline(1035);
// Begin line 661
  setline(661);
// compilenode returning *var_o
  Object call2093 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2093
// compilenode returning call2093
  Object call2094 = callmethod(call2093, "value",
    0, params);
// compilenode returning call2094
// compilenode returning call2094
  Object call2095 = gracelib_length(call2094);
// compilenode returning call2095
  Object num2096 = alloc_Float64(1.0);
// compilenode returning num2096
  params[0] = num2096;
  Object sum2098 = callmethod(call2095, "+", 1, params);
// compilenode returning sum2098
  *var_len = sum2098;
  if (sum2098 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 665
  setline(665);
// Begin line 662
  setline(662);
// compilenode returning *var_args
// Begin line 665
  setline(665);
// Begin line 1035
  setline(1035);
  Object obj2102 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2102, self, 0);
  addmethod2(obj2102, "outer", &reader_genc_outer_2103);
  adddatum2(obj2102, self, 0);
  block_savedest(obj2102);
  Object **closure2104 = createclosure(2);
  addtoclosure(closure2104, var_i);
  Object *selfpp2121 = alloc_var();
  *selfpp2121 = self;
  addtoclosure(closure2104, selfpp2121);
  struct UserObject *uo2104 = (struct UserObject*)obj2102;
  uo2104->data[1] = (Object)closure2104;
  addmethod2(obj2102, "apply", &meth_genc_apply2104);
  set_type(obj2102, 0);
// compilenode returning obj2102
  setclassname(obj2102, "Block<genc:2101>");
// compilenode returning obj2102
  params[0] = *var_args;
  Object iter2100 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond2100 = callmethod(iter2100, "havemore", 0, NULL);
    if (!istrue(cond2100)) break;
    params[0] = callmethod(iter2100, "next", 0, NULL);
    callmethod(obj2102, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 666
  setline(666);
  if (strlit2122 == NULL) {
    strlit2122 = alloc_String("  Object call");
  }
// compilenode returning strlit2122
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2124 = callmethod(strlit2122, "++", 1, params);
// compilenode returning opresult2124
  if (strlit2125 == NULL) {
    strlit2125 = alloc_String(" = callmethod(self, ""\x22""");
  }
// compilenode returning strlit2125
  params[0] = strlit2125;
  Object opresult2127 = callmethod(opresult2124, "++", 1, params);
// compilenode returning opresult2127
// compilenode returning *var_evl
  params[0] = *var_evl;
  Object opresult2129 = callmethod(opresult2127, "++", 1, params);
// compilenode returning opresult2129
  if (strlit2130 == NULL) {
    strlit2130 = alloc_String("""\x22"",");
  }
// compilenode returning strlit2130
  params[0] = strlit2130;
  Object opresult2132 = callmethod(opresult2129, "++", 1, params);
// compilenode returning opresult2132
// Begin line 667
  setline(667);
// compilenode returning self
  params[0] = opresult2132;
  Object call2133 = callmethod(self, "out",
    1, params);
// compilenode returning call2133
  if (strlit2134 == NULL) {
    strlit2134 = alloc_String("    ");
  }
// compilenode returning strlit2134
// Begin line 1035
  setline(1035);
// Begin line 667
  setline(667);
// compilenode returning *var_args
  Object call2135 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2135
// compilenode returning call2135
  params[0] = call2135;
  Object opresult2137 = callmethod(strlit2134, "++", 1, params);
// compilenode returning opresult2137
  if (strlit2138 == NULL) {
    strlit2138 = alloc_String(", params);");
  }
// compilenode returning strlit2138
  params[0] = strlit2138;
  Object opresult2140 = callmethod(opresult2137, "++", 1, params);
// compilenode returning opresult2140
// Begin line 668
  setline(668);
// compilenode returning self
  params[0] = opresult2140;
  Object call2141 = callmethod(self, "out",
    1, params);
// compilenode returning call2141
    if2027 = call2141;
  }
// compilenode returning if2027
// Begin line 670
  setline(670);
// Begin line 1035
  setline(1035);
// Begin line 670
  setline(670);
// Begin line 669
  setline(669);
  if (strlit2142 == NULL) {
    strlit2142 = alloc_String("call");
  }
// compilenode returning strlit2142
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2144 = callmethod(strlit2142, "++", 1, params);
// compilenode returning opresult2144
// compilenode returning *var_o
  params[0] = opresult2144;
  Object call2145 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2145
// compilenode returning nothing
// Begin line 671
  setline(671);
// Begin line 670
  setline(670);
// compilenode returning *var_auto_count
  Object num2146 = alloc_Float64(1.0);
// compilenode returning num2146
  params[0] = num2146;
  Object sum2148 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2148
  *var_auto_count = sum2148;
  if (sum2148 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply2163(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object *var_escval = closure[1];
  Object self = *closure[2];
// Begin line 679
  setline(679);
// Begin line 680
  setline(680);
// Begin line 677
  setline(677);
// compilenode returning *var_i
  Object num2165 = alloc_Float64(2.0);
// compilenode returning num2165
  params[0] = num2165;
  Object modulus2167 = callmethod(*var_i, "%", 1, params);
// compilenode returning modulus2167
  Object num2168 = alloc_Float64(0.0);
// compilenode returning num2168
  params[0] = num2168;
  Object opresult2170 = callmethod(modulus2167, "==", 1, params);
// compilenode returning opresult2170
  Object if2164;
  if (istrue(opresult2170)) {
// Begin line 679
  setline(679);
// Begin line 678
  setline(678);
// compilenode returning *var_escval
  if (strlit2171 == NULL) {
    strlit2171 = alloc_String("""\x22""""\x22""\\x""\x22""""\x22""");
  }
// compilenode returning strlit2171
  params[0] = strlit2171;
  Object opresult2173 = callmethod(*var_escval, "++", 1, params);
// compilenode returning opresult2173
  *var_escval = opresult2173;
  if (opresult2173 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2164 = nothing;
  } else {
  }
// compilenode returning if2164
// Begin line 681
  setline(681);
// Begin line 680
  setline(680);
// compilenode returning *var_escval
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult2176 = callmethod(*var_escval, "++", 1, params);
// compilenode returning opresult2176
  *var_escval = opresult2176;
  if (opresult2176 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 682
  setline(682);
// Begin line 681
  setline(681);
// compilenode returning *var_i
  Object num2178 = alloc_Float64(1.0);
// compilenode returning num2178
  params[0] = num2178;
  Object sum2180 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum2180
  *var_i = sum2180;
  if (sum2180 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileoctets2150(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[28];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_globals = closure[1];
  Object *var_escval = alloc_var();
  *var_escval = undefined;
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
// Begin line 674
  setline(674);
// Begin line 673
  setline(673);
  if (strlit2151 == NULL) {
    strlit2151 = alloc_String("");
  }
// compilenode returning strlit2151
  var_escval = alloc_var();
  *var_escval = strlit2151;
  if (strlit2151 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 674
  setline(674);
// Begin line 1035
  setline(1035);
// Begin line 674
  setline(674);
// compilenode returning *var_o
  Object call2152 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2152
// compilenode returning call2152
  Object call2153 = gracelib_length(call2152);
// compilenode returning call2153
  Object num2154 = alloc_Float64(2.0);
// compilenode returning num2154
  params[0] = num2154;
  Object quotient2156 = callmethod(call2153, "/", 1, params);
// compilenode returning quotient2156
  var_l = alloc_var();
  *var_l = quotient2156;
  if (quotient2156 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 676
  setline(676);
// Begin line 675
  setline(675);
  Object num2157 = alloc_Float64(0.0);
// compilenode returning num2157
  var_i = alloc_var();
  *var_i = num2157;
  if (num2157 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 682
  setline(682);
// Begin line 683
  setline(683);
// Begin line 1035
  setline(1035);
// Begin line 676
  setline(676);
// compilenode returning *var_o
  Object call2159 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2159
// compilenode returning call2159
// Begin line 682
  setline(682);
// Begin line 1035
  setline(1035);
  Object obj2161 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2161, self, 0);
  addmethod2(obj2161, "outer", &reader_genc_outer_2162);
  adddatum2(obj2161, self, 0);
  block_savedest(obj2161);
  Object **closure2163 = createclosure(3);
  addtoclosure(closure2163, var_i);
  addtoclosure(closure2163, var_escval);
  Object *selfpp2182 = alloc_var();
  *selfpp2182 = self;
  addtoclosure(closure2163, selfpp2182);
  struct UserObject *uo2163 = (struct UserObject*)obj2161;
  uo2163->data[1] = (Object)closure2163;
  addmethod2(obj2161, "apply", &meth_genc_apply2163);
  set_type(obj2161, 0);
// compilenode returning obj2161
  setclassname(obj2161, "Block<genc:2160>");
// compilenode returning obj2161
  params[0] = call2159;
  Object iter2158 = callmethod(call2159, "iter", 1, params);
  while(1) {
    Object cond2158 = callmethod(iter2158, "havemore", 0, NULL);
    if (!istrue(cond2158)) break;
    params[0] = callmethod(iter2158, "next", 0, NULL);
    callmethod(obj2161, "apply", 1, params);
  }
// compilenode returning call2159
// Begin line 683
  setline(683);
  if (strlit2183 == NULL) {
    strlit2183 = alloc_String("  if (octlit");
  }
// compilenode returning strlit2183
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2185 = callmethod(strlit2183, "++", 1, params);
// compilenode returning opresult2185
  if (strlit2186 == NULL) {
    strlit2186 = alloc_String(" == NULL) {");
  }
// compilenode returning strlit2186
  params[0] = strlit2186;
  Object opresult2188 = callmethod(opresult2185, "++", 1, params);
// compilenode returning opresult2188
// Begin line 684
  setline(684);
// compilenode returning self
  params[0] = opresult2188;
  Object call2189 = callmethod(self, "out",
    1, params);
// compilenode returning call2189
  if (strlit2190 == NULL) {
    strlit2190 = alloc_String("    octlit");
  }
// compilenode returning strlit2190
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2192 = callmethod(strlit2190, "++", 1, params);
// compilenode returning opresult2192
  if (strlit2193 == NULL) {
    strlit2193 = alloc_String(" = alloc_Octets(""\x22""");
  }
// compilenode returning strlit2193
  params[0] = strlit2193;
  Object opresult2195 = callmethod(opresult2192, "++", 1, params);
// compilenode returning opresult2195
// compilenode returning *var_escval
  params[0] = *var_escval;
  Object opresult2197 = callmethod(opresult2195, "++", 1, params);
// compilenode returning opresult2197
  if (strlit2198 == NULL) {
    strlit2198 = alloc_String("""\x22"");");
  }
// compilenode returning strlit2198
  params[0] = strlit2198;
  Object opresult2200 = callmethod(opresult2197, "++", 1, params);
// compilenode returning opresult2200
// Begin line 685
  setline(685);
// compilenode returning self
  params[0] = opresult2200;
  Object call2201 = callmethod(self, "out",
    1, params);
// compilenode returning call2201
  if (strlit2202 == NULL) {
    strlit2202 = alloc_String("  }");
  }
// compilenode returning strlit2202
// Begin line 686
  setline(686);
// compilenode returning self
  params[0] = strlit2202;
  Object call2203 = callmethod(self, "out",
    1, params);
// compilenode returning call2203
  if (strlit2204 == NULL) {
    strlit2204 = alloc_String("static Object octlit");
  }
// compilenode returning strlit2204
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2206 = callmethod(strlit2204, "++", 1, params);
// compilenode returning opresult2206
  if (strlit2207 == NULL) {
    strlit2207 = alloc_String(";");
  }
// compilenode returning strlit2207
  params[0] = strlit2207;
  Object opresult2209 = callmethod(opresult2206, "++", 1, params);
// compilenode returning opresult2209
// compilenode returning *var_globals
  params[0] = opresult2209;
  Object call2210 = callmethod(*var_globals, "push",
    1, params);
// compilenode returning call2210
// Begin line 688
  setline(688);
// Begin line 1035
  setline(1035);
// Begin line 688
  setline(688);
// Begin line 687
  setline(687);
  if (strlit2211 == NULL) {
    strlit2211 = alloc_String("octlit");
  }
// compilenode returning strlit2211
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2213 = callmethod(strlit2211, "++", 1, params);
// compilenode returning opresult2213
// compilenode returning *var_o
  params[0] = opresult2213;
  Object call2214 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2214
// compilenode returning nothing
// Begin line 689
  setline(689);
// Begin line 688
  setline(688);
// compilenode returning *var_auto_count
  Object num2215 = alloc_Float64(1.0);
// compilenode returning num2215
  params[0] = num2215;
  Object sum2217 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2217
  *var_auto_count = sum2217;
  if (sum2217 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compileimport2219(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[29];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_staticmodules = closure[0];
  Object *var_modules = closure[1];
  Object *var_globals = closure[2];
  Object *var_auto_count = closure[3];
  Object *var_con = alloc_var();
  *var_con = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_fn = alloc_var();
  *var_fn = undefined;
  Object *var_modg = alloc_var();
  *var_modg = undefined;
// Begin line 691
  setline(691);
  if (strlit2220 == NULL) {
    strlit2220 = alloc_String("// Import of ");
  }
// compilenode returning strlit2220
// Begin line 1035
  setline(1035);
// Begin line 691
  setline(691);
// Begin line 1035
  setline(1035);
// Begin line 691
  setline(691);
// compilenode returning *var_o
  Object call2221 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2221
// compilenode returning call2221
  Object call2222 = callmethod(call2221, "value",
    0, params);
// compilenode returning call2222
// compilenode returning call2222
  params[0] = call2222;
  Object opresult2224 = callmethod(strlit2220, "++", 1, params);
// compilenode returning opresult2224
// Begin line 692
  setline(692);
// compilenode returning self
  params[0] = opresult2224;
  Object call2225 = callmethod(self, "out",
    1, params);
// compilenode returning call2225
// Begin line 693
  setline(693);
  var_con = alloc_var();
  *var_con = undefined;
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// Begin line 693
  setline(693);
// Begin line 1035
  setline(1035);
// Begin line 693
  setline(693);
// compilenode returning *var_o
  Object call2226 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2226
// compilenode returning call2226
  Object call2227 = callmethod(call2226, "value",
    0, params);
// compilenode returning call2227
// compilenode returning call2227
// Begin line 694
  setline(694);
// compilenode returning self
  params[0] = call2227;
  Object call2228 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call2228
  var_nm = alloc_var();
  *var_nm = call2228;
  if (call2228 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// Begin line 694
  setline(694);
// Begin line 1035
  setline(1035);
// Begin line 694
  setline(694);
// compilenode returning *var_o
  Object call2229 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2229
// compilenode returning call2229
  Object call2230 = callmethod(call2229, "value",
    0, params);
// compilenode returning call2230
// compilenode returning call2230
// Begin line 695
  setline(695);
// compilenode returning self
  params[0] = call2230;
  Object call2231 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call2231
  var_fn = alloc_var();
  *var_fn = call2231;
  if (call2231 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 696
  setline(696);
// Begin line 695
  setline(695);
  if (strlit2232 == NULL) {
    strlit2232 = alloc_String("module_");
  }
// compilenode returning strlit2232
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2234 = callmethod(strlit2232, "++", 1, params);
// compilenode returning opresult2234
  var_modg = alloc_var();
  *var_modg = opresult2234;
  if (opresult2234 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 696
  setline(696);
  if (strlit2235 == NULL) {
    strlit2235 = alloc_String("  if (");
  }
// compilenode returning strlit2235
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2237 = callmethod(strlit2235, "++", 1, params);
// compilenode returning opresult2237
  if (strlit2238 == NULL) {
    strlit2238 = alloc_String(" == NULL)");
  }
// compilenode returning strlit2238
  params[0] = strlit2238;
  Object opresult2240 = callmethod(opresult2237, "++", 1, params);
// compilenode returning opresult2240
// Begin line 697
  setline(697);
// compilenode returning self
  params[0] = opresult2240;
  Object call2241 = callmethod(self, "out",
    1, params);
// compilenode returning call2241
// Begin line 700
  setline(700);
// Begin line 697
  setline(697);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call2243 = callmethod(*var_staticmodules, "contains",
    1, params);
// compilenode returning call2243
  Object if2242;
  if (istrue(call2243)) {
// Begin line 698
  setline(698);
  if (strlit2244 == NULL) {
    strlit2244 = alloc_String("    ");
  }
// compilenode returning strlit2244
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2246 = callmethod(strlit2244, "++", 1, params);
// compilenode returning opresult2246
  if (strlit2247 == NULL) {
    strlit2247 = alloc_String(" = ");
  }
// compilenode returning strlit2247
  params[0] = strlit2247;
  Object opresult2249 = callmethod(opresult2246, "++", 1, params);
// compilenode returning opresult2249
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2251 = callmethod(opresult2249, "++", 1, params);
// compilenode returning opresult2251
  if (strlit2252 == NULL) {
    strlit2252 = alloc_String("_init();");
  }
// compilenode returning strlit2252
  params[0] = strlit2252;
  Object opresult2254 = callmethod(opresult2251, "++", 1, params);
// compilenode returning opresult2254
// Begin line 699
  setline(699);
// compilenode returning self
  params[0] = opresult2254;
  Object call2255 = callmethod(self, "out",
    1, params);
// compilenode returning call2255
    if2242 = call2255;
  } else {
// Begin line 700
  setline(700);
  if (strlit2256 == NULL) {
    strlit2256 = alloc_String("    ");
  }
// compilenode returning strlit2256
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2258 = callmethod(strlit2256, "++", 1, params);
// compilenode returning opresult2258
  if (strlit2259 == NULL) {
    strlit2259 = alloc_String(" = dlmodule(""\x22""");
  }
// compilenode returning strlit2259
  params[0] = strlit2259;
  Object opresult2261 = callmethod(opresult2258, "++", 1, params);
// compilenode returning opresult2261
// compilenode returning *var_fn
  params[0] = *var_fn;
  Object opresult2263 = callmethod(opresult2261, "++", 1, params);
// compilenode returning opresult2263
  if (strlit2264 == NULL) {
    strlit2264 = alloc_String("""\x22"");");
  }
// compilenode returning strlit2264
  params[0] = strlit2264;
  Object opresult2266 = callmethod(opresult2263, "++", 1, params);
// compilenode returning opresult2266
// Begin line 701
  setline(701);
// compilenode returning self
  params[0] = opresult2266;
  Object call2267 = callmethod(self, "out",
    1, params);
// compilenode returning call2267
    if2242 = call2267;
  }
// compilenode returning if2242
// Begin line 702
  setline(702);
  if (strlit2268 == NULL) {
    strlit2268 = alloc_String("  Object *var_");
  }
// compilenode returning strlit2268
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2270 = callmethod(strlit2268, "++", 1, params);
// compilenode returning opresult2270
  if (strlit2271 == NULL) {
    strlit2271 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit2271
  params[0] = strlit2271;
  Object opresult2273 = callmethod(opresult2270, "++", 1, params);
// compilenode returning opresult2273
// Begin line 703
  setline(703);
// compilenode returning self
  params[0] = opresult2273;
  Object call2274 = callmethod(self, "out",
    1, params);
// compilenode returning call2274
  if (strlit2275 == NULL) {
    strlit2275 = alloc_String("  *var_");
  }
// compilenode returning strlit2275
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2277 = callmethod(strlit2275, "++", 1, params);
// compilenode returning opresult2277
  if (strlit2278 == NULL) {
    strlit2278 = alloc_String(" = ");
  }
// compilenode returning strlit2278
  params[0] = strlit2278;
  Object opresult2280 = callmethod(opresult2277, "++", 1, params);
// compilenode returning opresult2280
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2282 = callmethod(opresult2280, "++", 1, params);
// compilenode returning opresult2282
  if (strlit2283 == NULL) {
    strlit2283 = alloc_String(";");
  }
// compilenode returning strlit2283
  params[0] = strlit2283;
  Object opresult2285 = callmethod(opresult2282, "++", 1, params);
// compilenode returning opresult2285
// Begin line 704
  setline(704);
// compilenode returning self
  params[0] = opresult2285;
  Object call2286 = callmethod(self, "out",
    1, params);
// compilenode returning call2286
// compilenode returning *var_nm
// compilenode returning *var_modules
  params[0] = *var_nm;
  Object call2287 = callmethod(*var_modules, "push",
    1, params);
// compilenode returning call2287
// Begin line 705
  setline(705);
  if (strlit2288 == NULL) {
    strlit2288 = alloc_String("Object ");
  }
// compilenode returning strlit2288
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2290 = callmethod(strlit2288, "++", 1, params);
// compilenode returning opresult2290
  if (strlit2291 == NULL) {
    strlit2291 = alloc_String("_init();");
  }
// compilenode returning strlit2291
  params[0] = strlit2291;
  Object opresult2293 = callmethod(opresult2290, "++", 1, params);
// compilenode returning opresult2293
// compilenode returning *var_globals
  params[0] = opresult2293;
  Object call2294 = callmethod(*var_globals, "push",
    1, params);
// compilenode returning call2294
// Begin line 706
  setline(706);
  if (strlit2295 == NULL) {
    strlit2295 = alloc_String("Object ");
  }
// compilenode returning strlit2295
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult2297 = callmethod(strlit2295, "++", 1, params);
// compilenode returning opresult2297
  if (strlit2298 == NULL) {
    strlit2298 = alloc_String(";");
  }
// compilenode returning strlit2298
  params[0] = strlit2298;
  Object opresult2300 = callmethod(opresult2297, "++", 1, params);
// compilenode returning opresult2300
// compilenode returning *var_globals
  params[0] = opresult2300;
  Object call2301 = callmethod(*var_globals, "push",
    1, params);
// compilenode returning call2301
// Begin line 708
  setline(708);
// Begin line 707
  setline(707);
// compilenode returning *var_auto_count
  Object num2302 = alloc_Float64(1.0);
// compilenode returning num2302
  params[0] = num2302;
  Object sum2304 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2304
  *var_auto_count = sum2304;
  if (sum2304 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 709
  setline(709);
// Begin line 1035
  setline(1035);
// Begin line 708
  setline(708);
  if (strlit2306 == NULL) {
    strlit2306 = alloc_String("undefined");
  }
// compilenode returning strlit2306
// compilenode returning *var_o
  params[0] = strlit2306;
  Object call2307 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2307
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilereturn2308(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[30];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_inBlock = closure[0];
  Object *var_reg = alloc_var();
  *var_reg = undefined;
// Begin line 711
  setline(711);
// Begin line 1035
  setline(1035);
// Begin line 711
  setline(711);
// compilenode returning *var_o
  Object call2309 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2309
// compilenode returning call2309
// Begin line 712
  setline(712);
// compilenode returning self
  params[0] = call2309;
  Object call2310 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2310
  var_reg = alloc_var();
  *var_reg = call2310;
  if (call2310 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 715
  setline(715);
// Begin line 712
  setline(712);
// compilenode returning *var_inBlock
  Object if2311;
  if (istrue(*var_inBlock)) {
// Begin line 713
  setline(713);
  if (strlit2312 == NULL) {
    strlit2312 = alloc_String("  block_return(realself, ");
  }
// compilenode returning strlit2312
// compilenode returning *var_reg
  params[0] = *var_reg;
  Object opresult2314 = callmethod(strlit2312, "++", 1, params);
// compilenode returning opresult2314
  if (strlit2315 == NULL) {
    strlit2315 = alloc_String(");");
  }
// compilenode returning strlit2315
  params[0] = strlit2315;
  Object opresult2317 = callmethod(opresult2314, "++", 1, params);
// compilenode returning opresult2317
// Begin line 714
  setline(714);
// compilenode returning self
  params[0] = opresult2317;
  Object call2318 = callmethod(self, "out",
    1, params);
// compilenode returning call2318
    if2311 = call2318;
  } else {
// Begin line 715
  setline(715);
  if (strlit2319 == NULL) {
    strlit2319 = alloc_String("  return ");
  }
// compilenode returning strlit2319
// compilenode returning *var_reg
  params[0] = *var_reg;
  Object opresult2321 = callmethod(strlit2319, "++", 1, params);
// compilenode returning opresult2321
  if (strlit2322 == NULL) {
    strlit2322 = alloc_String(";");
  }
// compilenode returning strlit2322
  params[0] = strlit2322;
  Object opresult2324 = callmethod(opresult2321, "++", 1, params);
// compilenode returning opresult2324
// Begin line 716
  setline(716);
// compilenode returning self
  params[0] = opresult2324;
  Object call2325 = callmethod(self, "out",
    1, params);
// compilenode returning call2325
    if2311 = call2325;
  }
// compilenode returning if2311
// Begin line 718
  setline(718);
// Begin line 1035
  setline(1035);
// Begin line 717
  setline(717);
  if (strlit2326 == NULL) {
    strlit2326 = alloc_String("undefined");
  }
// compilenode returning strlit2326
// compilenode returning *var_o
  params[0] = strlit2326;
  Object call2327 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2327
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply2335(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_havedot = closure[0];
  Object self = *closure[1];
// Begin line 725
  setline(725);
// Begin line 726
  setline(726);
// Begin line 723
  setline(723);
// compilenode returning *var_c
  if (strlit2337 == NULL) {
    strlit2337 = alloc_String(".");
  }
// compilenode returning strlit2337
  params[0] = strlit2337;
  Object opresult2339 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult2339
  Object if2336;
  if (istrue(opresult2339)) {
// Begin line 725
  setline(725);
// Begin line 724
  setline(724);
  Object bool2340 = alloc_Boolean(1);
// compilenode returning bool2340
  *var_havedot = bool2340;
  if (bool2340 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2336 = nothing;
  } else {
  }
// compilenode returning if2336
  return if2336;
}
Object meth_genc_compilenum2328(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[31];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_cnum = alloc_var();
  *var_cnum = undefined;
  Object *var_havedot = alloc_var();
  *var_havedot = undefined;
// Begin line 721
  setline(721);
// Begin line 1035
  setline(1035);
// Begin line 720
  setline(720);
// compilenode returning *var_o
  Object call2329 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2329
// compilenode returning call2329
  var_cnum = alloc_var();
  *var_cnum = call2329;
  if (call2329 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 722
  setline(722);
// Begin line 721
  setline(721);
  Object bool2330 = alloc_Boolean(0);
// compilenode returning bool2330
  var_havedot = alloc_var();
  *var_havedot = bool2330;
  if (bool2330 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 725
  setline(725);
// Begin line 722
  setline(722);
// compilenode returning *var_cnum
// Begin line 725
  setline(725);
// Begin line 1035
  setline(1035);
  Object obj2333 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2333, self, 0);
  addmethod2(obj2333, "outer", &reader_genc_outer_2334);
  adddatum2(obj2333, self, 0);
  block_savedest(obj2333);
  Object **closure2335 = createclosure(2);
  addtoclosure(closure2335, var_havedot);
  Object *selfpp2342 = alloc_var();
  *selfpp2342 = self;
  addtoclosure(closure2335, selfpp2342);
  struct UserObject *uo2335 = (struct UserObject*)obj2333;
  uo2335->data[1] = (Object)closure2335;
  addmethod2(obj2333, "apply", &meth_genc_apply2335);
  set_type(obj2333, 0);
// compilenode returning obj2333
  setclassname(obj2333, "Block<genc:2332>");
// compilenode returning obj2333
  params[0] = *var_cnum;
  Object iter2331 = callmethod(*var_cnum, "iter", 1, params);
  while(1) {
    Object cond2331 = callmethod(iter2331, "havemore", 0, NULL);
    if (!istrue(cond2331)) break;
    params[0] = callmethod(iter2331, "next", 0, NULL);
    callmethod(obj2333, "apply", 1, params);
  }
// compilenode returning *var_cnum
// Begin line 729
  setline(729);
// Begin line 730
  setline(730);
// Begin line 1035
  setline(1035);
// Begin line 727
  setline(727);
// compilenode returning *var_havedot
  Object call2344 = callmethod(*var_havedot, "not",
    0, params);
// compilenode returning call2344
// compilenode returning call2344
  Object if2343;
  if (istrue(call2344)) {
// Begin line 729
  setline(729);
// Begin line 728
  setline(728);
// compilenode returning *var_cnum
  if (strlit2345 == NULL) {
    strlit2345 = alloc_String(".0");
  }
// compilenode returning strlit2345
  params[0] = strlit2345;
  Object opresult2347 = callmethod(*var_cnum, "++", 1, params);
// compilenode returning opresult2347
  *var_cnum = opresult2347;
  if (opresult2347 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2343 = nothing;
  } else {
  }
// compilenode returning if2343
// Begin line 730
  setline(730);
  if (strlit2349 == NULL) {
    strlit2349 = alloc_String("  Object num");
  }
// compilenode returning strlit2349
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2351 = callmethod(strlit2349, "++", 1, params);
// compilenode returning opresult2351
  if (strlit2352 == NULL) {
    strlit2352 = alloc_String(" = alloc_Float64(");
  }
// compilenode returning strlit2352
  params[0] = strlit2352;
  Object opresult2354 = callmethod(opresult2351, "++", 1, params);
// compilenode returning opresult2354
// compilenode returning *var_cnum
  params[0] = *var_cnum;
  Object opresult2356 = callmethod(opresult2354, "++", 1, params);
// compilenode returning opresult2356
  if (strlit2357 == NULL) {
    strlit2357 = alloc_String(");");
  }
// compilenode returning strlit2357
  params[0] = strlit2357;
  Object opresult2359 = callmethod(opresult2356, "++", 1, params);
// compilenode returning opresult2359
// Begin line 731
  setline(731);
// compilenode returning self
  params[0] = opresult2359;
  Object call2360 = callmethod(self, "out",
    1, params);
// compilenode returning call2360
// Begin line 732
  setline(732);
// Begin line 1035
  setline(1035);
// Begin line 732
  setline(732);
// Begin line 731
  setline(731);
  if (strlit2361 == NULL) {
    strlit2361 = alloc_String("num");
  }
// compilenode returning strlit2361
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2363 = callmethod(strlit2361, "++", 1, params);
// compilenode returning opresult2363
// compilenode returning *var_o
  params[0] = opresult2363;
  Object call2364 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2364
// compilenode returning nothing
// Begin line 733
  setline(733);
// Begin line 732
  setline(732);
// compilenode returning *var_auto_count
  Object num2365 = alloc_Float64(1.0);
// compilenode returning num2365
  params[0] = num2365;
  Object sum2367 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2367
  *var_auto_count = sum2367;
  if (sum2367 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_apply2623(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_prm = alloc_var();
  *var_prm = args[0];
  Object params[1];
  Object *var_args = closure[0];
  Object self = *closure[1];
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 823
  setline(823);
// compilenode returning *var_prm
// Begin line 824
  setline(824);
// compilenode returning self
  params[0] = *var_prm;
  Object call2624 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2624
  var_r = alloc_var();
  *var_r = call2624;
  if (call2624 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_args
  params[0] = *var_r;
  Object call2625 = callmethod(*var_args, "push",
    1, params);
// compilenode returning call2625
  return call2625;
}
Object meth_genc_apply2632(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object *var_parami = closure[0];
  Object self = *closure[1];
// Begin line 828
  setline(828);
  if (strlit2633 == NULL) {
    strlit2633 = alloc_String("  params[");
  }
// compilenode returning strlit2633
// compilenode returning *var_parami
  params[0] = *var_parami;
  Object opresult2635 = callmethod(strlit2633, "++", 1, params);
// compilenode returning opresult2635
  if (strlit2636 == NULL) {
    strlit2636 = alloc_String("] = ");
  }
// compilenode returning strlit2636
  params[0] = strlit2636;
  Object opresult2638 = callmethod(opresult2635, "++", 1, params);
// compilenode returning opresult2638
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult2640 = callmethod(opresult2638, "++", 1, params);
// compilenode returning opresult2640
  if (strlit2641 == NULL) {
    strlit2641 = alloc_String(";");
  }
// compilenode returning strlit2641
  params[0] = strlit2641;
  Object opresult2643 = callmethod(opresult2640, "++", 1, params);
// compilenode returning opresult2643
// Begin line 829
  setline(829);
// compilenode returning self
  params[0] = opresult2643;
  Object call2644 = callmethod(self, "out",
    1, params);
// compilenode returning call2644
// Begin line 830
  setline(830);
// Begin line 829
  setline(829);
// compilenode returning *var_parami
  Object num2645 = alloc_Float64(1.0);
// compilenode returning num2645
  params[0] = num2645;
  Object sum2647 = callmethod(*var_parami, "+", 1, params);
// compilenode returning sum2647
  *var_parami = sum2647;
  if (sum2647 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compilenode2369(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[32];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[3];
  Object *var_linenum = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_globals = closure[2];
  Object *var_topLevelMethodPos = closure[3];
  Object *var_tmp = closure[4];
  Object *var_l = alloc_var();
  *var_l = undefined;
// Begin line 738
  setline(738);
// Begin line 740
  setline(740);
// Begin line 735
  setline(735);
// compilenode returning *var_linenum
// Begin line 740
  setline(740);
// Begin line 1035
  setline(1035);
// Begin line 735
  setline(735);
// compilenode returning *var_o
  Object call2371 = callmethod(*var_o, "line",
    0, params);
// compilenode returning call2371
// compilenode returning call2371
  params[0] = call2371;
  Object opresult2373 = callmethod(*var_linenum, "/=", 1, params);
// compilenode returning opresult2373
  Object if2370;
  if (istrue(opresult2373)) {
// Begin line 737
  setline(737);
// Begin line 1035
  setline(1035);
// Begin line 736
  setline(736);
// compilenode returning *var_o
  Object call2374 = callmethod(*var_o, "line",
    0, params);
// compilenode returning call2374
// compilenode returning call2374
  *var_linenum = call2374;
  if (call2374 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 737
  setline(737);
  if (strlit2376 == NULL) {
    strlit2376 = alloc_String("// Begin line ");
  }
// compilenode returning strlit2376
// compilenode returning *var_linenum
  params[0] = *var_linenum;
  Object opresult2378 = callmethod(strlit2376, "++", 1, params);
// compilenode returning opresult2378
// Begin line 738
  setline(738);
// compilenode returning self
  params[0] = opresult2378;
  Object call2379 = callmethod(self, "out",
    1, params);
// compilenode returning call2379
  if (strlit2380 == NULL) {
    strlit2380 = alloc_String("  setline(");
  }
// compilenode returning strlit2380
// compilenode returning *var_linenum
  params[0] = *var_linenum;
  Object opresult2382 = callmethod(strlit2380, "++", 1, params);
// compilenode returning opresult2382
  if (strlit2383 == NULL) {
    strlit2383 = alloc_String(");");
  }
// compilenode returning strlit2383
  params[0] = strlit2383;
  Object opresult2385 = callmethod(opresult2382, "++", 1, params);
// compilenode returning opresult2385
// Begin line 739
  setline(739);
// compilenode returning self
  params[0] = opresult2385;
  Object call2386 = callmethod(self, "out",
    1, params);
// compilenode returning call2386
    if2370 = call2386;
  } else {
  }
// compilenode returning if2370
// Begin line 741
  setline(741);
// Begin line 743
  setline(743);
// Begin line 1035
  setline(1035);
// Begin line 740
  setline(740);
// compilenode returning *var_o
  Object call2388 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2388
// compilenode returning call2388
  if (strlit2389 == NULL) {
    strlit2389 = alloc_String("num");
  }
// compilenode returning strlit2389
  params[0] = strlit2389;
  Object opresult2391 = callmethod(call2388, "==", 1, params);
// compilenode returning opresult2391
  Object if2387;
  if (istrue(opresult2391)) {
// Begin line 741
  setline(741);
// compilenode returning *var_o
// Begin line 742
  setline(742);
// compilenode returning self
  params[0] = *var_o;
  Object call2392 = callmethod(self, "compilenum",
    1, params);
// compilenode returning call2392
    if2387 = call2392;
  } else {
  }
// compilenode returning if2387
// Begin line 744
  setline(744);
// Begin line 743
  setline(743);
  if (strlit2393 == NULL) {
    strlit2393 = alloc_String("");
  }
// compilenode returning strlit2393
  var_l = alloc_var();
  *var_l = strlit2393;
  if (strlit2393 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 754
  setline(754);
// Begin line 755
  setline(755);
// Begin line 1035
  setline(1035);
// Begin line 744
  setline(744);
// compilenode returning *var_o
  Object call2395 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2395
// compilenode returning call2395
  if (strlit2396 == NULL) {
    strlit2396 = alloc_String("string");
  }
// compilenode returning strlit2396
  params[0] = strlit2396;
  Object opresult2398 = callmethod(call2395, "==", 1, params);
// compilenode returning opresult2398
  Object if2394;
  if (istrue(opresult2398)) {
// Begin line 745
  setline(745);
// Begin line 1035
  setline(1035);
// Begin line 745
  setline(745);
// compilenode returning *var_o
  Object call2399 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2399
// compilenode returning call2399
  Object call2400 = gracelib_length(call2399);
// compilenode returning call2400
  *var_l = call2400;
  if (call2400 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 747
  setline(747);
// Begin line 746
  setline(746);
// compilenode returning *var_l
  Object num2402 = alloc_Float64(1.0);
// compilenode returning num2402
  params[0] = num2402;
  Object sum2404 = callmethod(*var_l, "+", 1, params);
// compilenode returning sum2404
  *var_l = sum2404;
  if (sum2404 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 747
  setline(747);
// Begin line 1035
  setline(1035);
// Begin line 747
  setline(747);
// Begin line 1035
  setline(1035);
// Begin line 747
  setline(747);
// compilenode returning *var_o
  Object call2406 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2406
// compilenode returning call2406
// Begin line 748
  setline(748);
// compilenode returning self
  params[0] = call2406;
  Object call2407 = callmethod(self, "escapestring2",
    1, params);
// compilenode returning call2407
// Begin line 747
  setline(747);
// compilenode returning *var_o
  params[0] = call2407;
  Object call2408 = callmethod(*var_o, "value:=",
    1, params);
// compilenode returning call2408
// compilenode returning nothing
// Begin line 748
  setline(748);
  if (strlit2409 == NULL) {
    strlit2409 = alloc_String("  if (strlit");
  }
// compilenode returning strlit2409
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2411 = callmethod(strlit2409, "++", 1, params);
// compilenode returning opresult2411
  if (strlit2412 == NULL) {
    strlit2412 = alloc_String(" == NULL) {");
  }
// compilenode returning strlit2412
  params[0] = strlit2412;
  Object opresult2414 = callmethod(opresult2411, "++", 1, params);
// compilenode returning opresult2414
// Begin line 749
  setline(749);
// compilenode returning self
  params[0] = opresult2414;
  Object call2415 = callmethod(self, "out",
    1, params);
// compilenode returning call2415
  if (strlit2416 == NULL) {
    strlit2416 = alloc_String("    strlit");
  }
// compilenode returning strlit2416
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2418 = callmethod(strlit2416, "++", 1, params);
// compilenode returning opresult2418
  if (strlit2419 == NULL) {
    strlit2419 = alloc_String(" = alloc_String(""\x22""");
  }
// compilenode returning strlit2419
  params[0] = strlit2419;
  Object opresult2421 = callmethod(opresult2418, "++", 1, params);
// compilenode returning opresult2421
// Begin line 1035
  setline(1035);
// Begin line 749
  setline(749);
// compilenode returning *var_o
  Object call2422 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2422
// compilenode returning call2422
  params[0] = call2422;
  Object opresult2424 = callmethod(opresult2421, "++", 1, params);
// compilenode returning opresult2424
  if (strlit2425 == NULL) {
    strlit2425 = alloc_String("""\x22"");");
  }
// compilenode returning strlit2425
  params[0] = strlit2425;
  Object opresult2427 = callmethod(opresult2424, "++", 1, params);
// compilenode returning opresult2427
// Begin line 750
  setline(750);
// compilenode returning self
  params[0] = opresult2427;
  Object call2428 = callmethod(self, "out",
    1, params);
// compilenode returning call2428
  if (strlit2429 == NULL) {
    strlit2429 = alloc_String("  }");
  }
// compilenode returning strlit2429
// Begin line 751
  setline(751);
// compilenode returning self
  params[0] = strlit2429;
  Object call2430 = callmethod(self, "out",
    1, params);
// compilenode returning call2430
  if (strlit2431 == NULL) {
    strlit2431 = alloc_String("static Object strlit");
  }
// compilenode returning strlit2431
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2433 = callmethod(strlit2431, "++", 1, params);
// compilenode returning opresult2433
  if (strlit2434 == NULL) {
    strlit2434 = alloc_String(";");
  }
// compilenode returning strlit2434
  params[0] = strlit2434;
  Object opresult2436 = callmethod(opresult2433, "++", 1, params);
// compilenode returning opresult2436
// compilenode returning *var_globals
  params[0] = opresult2436;
  Object call2437 = callmethod(*var_globals, "push",
    1, params);
// compilenode returning call2437
// Begin line 753
  setline(753);
// Begin line 1035
  setline(1035);
// Begin line 753
  setline(753);
// Begin line 752
  setline(752);
  if (strlit2438 == NULL) {
    strlit2438 = alloc_String("strlit");
  }
// compilenode returning strlit2438
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2440 = callmethod(strlit2438, "++", 1, params);
// compilenode returning opresult2440
// compilenode returning *var_o
  params[0] = opresult2440;
  Object call2441 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2441
// compilenode returning nothing
// Begin line 754
  setline(754);
// Begin line 753
  setline(753);
// compilenode returning *var_auto_count
  Object num2442 = alloc_Float64(1.0);
// compilenode returning num2442
  params[0] = num2442;
  Object sum2444 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2444
  *var_auto_count = sum2444;
  if (sum2444 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2394 = nothing;
  } else {
  }
// compilenode returning if2394
// Begin line 756
  setline(756);
// Begin line 758
  setline(758);
// Begin line 1035
  setline(1035);
// Begin line 755
  setline(755);
// compilenode returning *var_o
  Object call2447 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2447
// compilenode returning call2447
  if (strlit2448 == NULL) {
    strlit2448 = alloc_String("index");
  }
// compilenode returning strlit2448
  params[0] = strlit2448;
  Object opresult2450 = callmethod(call2447, "==", 1, params);
// compilenode returning opresult2450
  Object if2446;
  if (istrue(opresult2450)) {
// Begin line 756
  setline(756);
// compilenode returning *var_o
// Begin line 757
  setline(757);
// compilenode returning self
  params[0] = *var_o;
  Object call2451 = callmethod(self, "compileindex",
    1, params);
// compilenode returning call2451
    if2446 = call2451;
  } else {
  }
// compilenode returning if2446
// Begin line 759
  setline(759);
// Begin line 761
  setline(761);
// Begin line 1035
  setline(1035);
// Begin line 758
  setline(758);
// compilenode returning *var_o
  Object call2453 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2453
// compilenode returning call2453
  if (strlit2454 == NULL) {
    strlit2454 = alloc_String("octets");
  }
// compilenode returning strlit2454
  params[0] = strlit2454;
  Object opresult2456 = callmethod(call2453, "==", 1, params);
// compilenode returning opresult2456
  Object if2452;
  if (istrue(opresult2456)) {
// Begin line 759
  setline(759);
// compilenode returning *var_o
// Begin line 760
  setline(760);
// compilenode returning self
  params[0] = *var_o;
  Object call2457 = callmethod(self, "compileoctets",
    1, params);
// compilenode returning call2457
    if2452 = call2457;
  } else {
  }
// compilenode returning if2452
// Begin line 762
  setline(762);
// Begin line 764
  setline(764);
// Begin line 1035
  setline(1035);
// Begin line 761
  setline(761);
// compilenode returning *var_o
  Object call2459 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2459
// compilenode returning call2459
  if (strlit2460 == NULL) {
    strlit2460 = alloc_String("import");
  }
// compilenode returning strlit2460
  params[0] = strlit2460;
  Object opresult2462 = callmethod(call2459, "==", 1, params);
// compilenode returning opresult2462
  Object if2458;
  if (istrue(opresult2462)) {
// Begin line 762
  setline(762);
// compilenode returning *var_o
// Begin line 763
  setline(763);
// compilenode returning self
  params[0] = *var_o;
  Object call2463 = callmethod(self, "compileimport",
    1, params);
// compilenode returning call2463
    if2458 = call2463;
  } else {
  }
// compilenode returning if2458
// Begin line 765
  setline(765);
// Begin line 767
  setline(767);
// Begin line 1035
  setline(1035);
// Begin line 764
  setline(764);
// compilenode returning *var_o
  Object call2465 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2465
// compilenode returning call2465
  if (strlit2466 == NULL) {
    strlit2466 = alloc_String("return");
  }
// compilenode returning strlit2466
  params[0] = strlit2466;
  Object opresult2468 = callmethod(call2465, "==", 1, params);
// compilenode returning opresult2468
  Object if2464;
  if (istrue(opresult2468)) {
// Begin line 765
  setline(765);
// compilenode returning *var_o
// Begin line 766
  setline(766);
// compilenode returning self
  params[0] = *var_o;
  Object call2469 = callmethod(self, "compilereturn",
    1, params);
// compilenode returning call2469
    if2464 = call2469;
  } else {
  }
// compilenode returning if2464
// Begin line 768
  setline(768);
// Begin line 770
  setline(770);
// Begin line 1035
  setline(1035);
// Begin line 767
  setline(767);
// compilenode returning *var_o
  Object call2471 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2471
// compilenode returning call2471
  if (strlit2472 == NULL) {
    strlit2472 = alloc_String("generic");
  }
// compilenode returning strlit2472
  params[0] = strlit2472;
  Object opresult2474 = callmethod(call2471, "==", 1, params);
// compilenode returning opresult2474
  Object if2470;
  if (istrue(opresult2474)) {
// Begin line 768
  setline(768);
// Begin line 1035
  setline(1035);
// Begin line 768
  setline(768);
// Begin line 1035
  setline(1035);
// Begin line 768
  setline(768);
// compilenode returning *var_o
  Object call2475 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2475
// compilenode returning call2475
// Begin line 769
  setline(769);
// compilenode returning self
  params[0] = call2475;
  Object call2476 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2476
// Begin line 768
  setline(768);
// compilenode returning *var_o
  params[0] = call2476;
  Object call2477 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2477
// compilenode returning nothing
    if2470 = nothing;
  } else {
  }
// compilenode returning if2470
// Begin line 780
  setline(780);
// Begin line 782
  setline(782);
// Begin line 1035
  setline(1035);
// Begin line 770
  setline(770);
// compilenode returning *var_o
  Object call2479 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2479
// compilenode returning call2479
  if (strlit2480 == NULL) {
    strlit2480 = alloc_String("identifier");
  }
// compilenode returning strlit2480
  params[0] = strlit2480;
  Object opresult2482 = callmethod(call2479, "==", 1, params);
// compilenode returning opresult2482
// Begin line 782
  setline(782);
// Begin line 1035
  setline(1035);
// Begin line 771
  setline(771);
// compilenode returning *var_o
  Object call2483 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2483
// compilenode returning call2483
  if (strlit2484 == NULL) {
    strlit2484 = alloc_String("true");
  }
// compilenode returning strlit2484
  params[0] = strlit2484;
  Object opresult2486 = callmethod(call2483, "==", 1, params);
// compilenode returning opresult2486
// Begin line 782
  setline(782);
// Begin line 1035
  setline(1035);
// Begin line 771
  setline(771);
// compilenode returning *var_o
  Object call2487 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2487
// compilenode returning call2487
  if (strlit2488 == NULL) {
    strlit2488 = alloc_String("false");
  }
// compilenode returning strlit2488
  params[0] = strlit2488;
  Object opresult2490 = callmethod(call2487, "==", 1, params);
// compilenode returning opresult2490
  params[0] = opresult2490;
  Object opresult2492 = callmethod(opresult2486, "|", 1, params);
// compilenode returning opresult2492
  params[0] = opresult2492;
  Object opresult2494 = callmethod(opresult2482, "&", 1, params);
// compilenode returning opresult2494
  Object if2478;
  if (istrue(opresult2494)) {
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 773
  setline(773);
// Begin line 772
  setline(772);
  Object num2495 = alloc_Float64(0.0);
// compilenode returning num2495
  var_val = alloc_var();
  *var_val = num2495;
  if (num2495 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 775
  setline(775);
// Begin line 776
  setline(776);
// Begin line 1035
  setline(1035);
// Begin line 773
  setline(773);
// compilenode returning *var_o
  Object call2497 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2497
// compilenode returning call2497
  if (strlit2498 == NULL) {
    strlit2498 = alloc_String("true");
  }
// compilenode returning strlit2498
  params[0] = strlit2498;
  Object opresult2500 = callmethod(call2497, "==", 1, params);
// compilenode returning opresult2500
  Object if2496;
  if (istrue(opresult2500)) {
// Begin line 775
  setline(775);
// Begin line 774
  setline(774);
  Object num2501 = alloc_Float64(1.0);
// compilenode returning num2501
  *var_val = num2501;
  if (num2501 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2496 = nothing;
  } else {
  }
// compilenode returning if2496
// Begin line 776
  setline(776);
  if (strlit2503 == NULL) {
    strlit2503 = alloc_String("  Object bool");
  }
// compilenode returning strlit2503
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2505 = callmethod(strlit2503, "++", 1, params);
// compilenode returning opresult2505
  if (strlit2506 == NULL) {
    strlit2506 = alloc_String(" = alloc_Boolean(");
  }
// compilenode returning strlit2506
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2508 = callmethod(strlit2506, "++", 1, params);
// compilenode returning opresult2508
  if (strlit2509 == NULL) {
    strlit2509 = alloc_String(");");
  }
// compilenode returning strlit2509
  params[0] = strlit2509;
  Object opresult2511 = callmethod(opresult2508, "++", 1, params);
// compilenode returning opresult2511
  params[0] = opresult2511;
  Object opresult2513 = callmethod(opresult2505, "++", 1, params);
// compilenode returning opresult2513
// Begin line 777
  setline(777);
// compilenode returning self
  params[0] = opresult2513;
  Object call2514 = callmethod(self, "out",
    1, params);
// compilenode returning call2514
// Begin line 778
  setline(778);
// Begin line 1035
  setline(1035);
// Begin line 778
  setline(778);
// Begin line 777
  setline(777);
  if (strlit2515 == NULL) {
    strlit2515 = alloc_String("bool");
  }
// compilenode returning strlit2515
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2517 = callmethod(strlit2515, "++", 1, params);
// compilenode returning opresult2517
// compilenode returning *var_o
  params[0] = opresult2517;
  Object call2518 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2518
// compilenode returning nothing
// Begin line 779
  setline(779);
// Begin line 778
  setline(778);
// compilenode returning *var_auto_count
  Object num2519 = alloc_Float64(1.0);
// compilenode returning num2519
  params[0] = num2519;
  Object sum2521 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2521
  *var_auto_count = sum2521;
  if (sum2521 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2478 = nothing;
  } else {
// Begin line 780
  setline(780);
// Begin line 782
  setline(782);
// Begin line 1035
  setline(1035);
// Begin line 779
  setline(779);
// compilenode returning *var_o
  Object call2524 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2524
// compilenode returning call2524
  if (strlit2525 == NULL) {
    strlit2525 = alloc_String("identifier");
  }
// compilenode returning strlit2525
  params[0] = strlit2525;
  Object opresult2527 = callmethod(call2524, "==", 1, params);
// compilenode returning opresult2527
  Object if2523;
  if (istrue(opresult2527)) {
// Begin line 780
  setline(780);
// compilenode returning *var_o
// Begin line 781
  setline(781);
// compilenode returning self
  params[0] = *var_o;
  Object call2528 = callmethod(self, "compileidentifier",
    1, params);
// compilenode returning call2528
    if2523 = call2528;
  } else {
  }
// compilenode returning if2523
    if2478 = if2523;
  }
// compilenode returning if2478
// Begin line 783
  setline(783);
// Begin line 785
  setline(785);
// Begin line 1035
  setline(1035);
// Begin line 782
  setline(782);
// compilenode returning *var_o
  Object call2530 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2530
// compilenode returning call2530
  if (strlit2531 == NULL) {
    strlit2531 = alloc_String("defdec");
  }
// compilenode returning strlit2531
  params[0] = strlit2531;
  Object opresult2533 = callmethod(call2530, "==", 1, params);
// compilenode returning opresult2533
  Object if2529;
  if (istrue(opresult2533)) {
// Begin line 783
  setline(783);
// compilenode returning *var_o
// Begin line 784
  setline(784);
// compilenode returning self
  params[0] = *var_o;
  Object call2534 = callmethod(self, "compiledefdec",
    1, params);
// compilenode returning call2534
    if2529 = call2534;
  } else {
  }
// compilenode returning if2529
// Begin line 786
  setline(786);
// Begin line 788
  setline(788);
// Begin line 1035
  setline(1035);
// Begin line 785
  setline(785);
// compilenode returning *var_o
  Object call2536 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2536
// compilenode returning call2536
  if (strlit2537 == NULL) {
    strlit2537 = alloc_String("vardec");
  }
// compilenode returning strlit2537
  params[0] = strlit2537;
  Object opresult2539 = callmethod(call2536, "==", 1, params);
// compilenode returning opresult2539
  Object if2535;
  if (istrue(opresult2539)) {
// Begin line 786
  setline(786);
// compilenode returning *var_o
// Begin line 787
  setline(787);
// compilenode returning self
  params[0] = *var_o;
  Object call2540 = callmethod(self, "compilevardec",
    1, params);
// compilenode returning call2540
    if2535 = call2540;
  } else {
  }
// compilenode returning if2535
// Begin line 789
  setline(789);
// Begin line 791
  setline(791);
// Begin line 1035
  setline(1035);
// Begin line 788
  setline(788);
// compilenode returning *var_o
  Object call2542 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2542
// compilenode returning call2542
  if (strlit2543 == NULL) {
    strlit2543 = alloc_String("block");
  }
// compilenode returning strlit2543
  params[0] = strlit2543;
  Object opresult2545 = callmethod(call2542, "==", 1, params);
// compilenode returning opresult2545
  Object if2541;
  if (istrue(opresult2545)) {
// Begin line 789
  setline(789);
// compilenode returning *var_o
// Begin line 790
  setline(790);
// compilenode returning self
  params[0] = *var_o;
  Object call2546 = callmethod(self, "compileblock",
    1, params);
// compilenode returning call2546
    if2541 = call2546;
  } else {
  }
// compilenode returning if2541
// Begin line 794
  setline(794);
// Begin line 795
  setline(795);
// Begin line 1035
  setline(1035);
// Begin line 791
  setline(791);
// compilenode returning *var_o
  Object call2548 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2548
// compilenode returning call2548
  if (strlit2549 == NULL) {
    strlit2549 = alloc_String("method");
  }
// compilenode returning strlit2549
  params[0] = strlit2549;
  Object opresult2551 = callmethod(call2548, "==", 1, params);
// compilenode returning opresult2551
  Object if2547;
  if (istrue(opresult2551)) {
// Begin line 792
  setline(792);
// compilenode returning *var_o
  if (strlit2552 == NULL) {
    strlit2552 = alloc_String("self");
  }
// compilenode returning strlit2552
// compilenode returning *var_topLevelMethodPos
// Begin line 793
  setline(793);
// compilenode returning self
  params[0] = *var_o;
  params[1] = strlit2552;
  params[2] = *var_topLevelMethodPos;
  Object call2553 = callmethod(self, "compilemethod",
    3, params);
// compilenode returning call2553
// Begin line 794
  setline(794);
// Begin line 793
  setline(793);
// compilenode returning *var_topLevelMethodPos
  Object num2554 = alloc_Float64(1.0);
// compilenode returning num2554
  params[0] = num2554;
  Object sum2556 = callmethod(*var_topLevelMethodPos, "+", 1, params);
// compilenode returning sum2556
  *var_topLevelMethodPos = sum2556;
  if (sum2556 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2547 = nothing;
  } else {
  }
// compilenode returning if2547
// Begin line 796
  setline(796);
// Begin line 798
  setline(798);
// Begin line 1035
  setline(1035);
// Begin line 795
  setline(795);
// compilenode returning *var_o
  Object call2559 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2559
// compilenode returning call2559
  if (strlit2560 == NULL) {
    strlit2560 = alloc_String("array");
  }
// compilenode returning strlit2560
  params[0] = strlit2560;
  Object opresult2562 = callmethod(call2559, "==", 1, params);
// compilenode returning opresult2562
  Object if2558;
  if (istrue(opresult2562)) {
// Begin line 796
  setline(796);
// compilenode returning *var_o
// Begin line 797
  setline(797);
// compilenode returning self
  params[0] = *var_o;
  Object call2563 = callmethod(self, "compilearray",
    1, params);
// compilenode returning call2563
    if2558 = call2563;
  } else {
  }
// compilenode returning if2558
// Begin line 799
  setline(799);
// Begin line 801
  setline(801);
// Begin line 1035
  setline(1035);
// Begin line 798
  setline(798);
// compilenode returning *var_o
  Object call2565 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2565
// compilenode returning call2565
  if (strlit2566 == NULL) {
    strlit2566 = alloc_String("bind");
  }
// compilenode returning strlit2566
  params[0] = strlit2566;
  Object opresult2568 = callmethod(call2565, "==", 1, params);
// compilenode returning opresult2568
  Object if2564;
  if (istrue(opresult2568)) {
// Begin line 799
  setline(799);
// compilenode returning *var_o
// Begin line 800
  setline(800);
// compilenode returning self
  params[0] = *var_o;
  Object call2569 = callmethod(self, "compilebind",
    1, params);
// compilenode returning call2569
    if2564 = call2569;
  } else {
  }
// compilenode returning if2564
// Begin line 802
  setline(802);
// Begin line 804
  setline(804);
// Begin line 1035
  setline(1035);
// Begin line 801
  setline(801);
// compilenode returning *var_o
  Object call2571 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2571
// compilenode returning call2571
  if (strlit2572 == NULL) {
    strlit2572 = alloc_String("while");
  }
// compilenode returning strlit2572
  params[0] = strlit2572;
  Object opresult2574 = callmethod(call2571, "==", 1, params);
// compilenode returning opresult2574
  Object if2570;
  if (istrue(opresult2574)) {
// Begin line 802
  setline(802);
// compilenode returning *var_o
// Begin line 803
  setline(803);
// compilenode returning self
  params[0] = *var_o;
  Object call2575 = callmethod(self, "compilewhile",
    1, params);
// compilenode returning call2575
    if2570 = call2575;
  } else {
  }
// compilenode returning if2570
// Begin line 805
  setline(805);
// Begin line 807
  setline(807);
// Begin line 1035
  setline(1035);
// Begin line 804
  setline(804);
// compilenode returning *var_o
  Object call2577 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2577
// compilenode returning call2577
  if (strlit2578 == NULL) {
    strlit2578 = alloc_String("if");
  }
// compilenode returning strlit2578
  params[0] = strlit2578;
  Object opresult2580 = callmethod(call2577, "==", 1, params);
// compilenode returning opresult2580
  Object if2576;
  if (istrue(opresult2580)) {
// Begin line 805
  setline(805);
// compilenode returning *var_o
// Begin line 806
  setline(806);
// compilenode returning self
  params[0] = *var_o;
  Object call2581 = callmethod(self, "compileif",
    1, params);
// compilenode returning call2581
    if2576 = call2581;
  } else {
  }
// compilenode returning if2576
// Begin line 808
  setline(808);
// Begin line 810
  setline(810);
// Begin line 1035
  setline(1035);
// Begin line 807
  setline(807);
// compilenode returning *var_o
  Object call2583 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2583
// compilenode returning call2583
  if (strlit2584 == NULL) {
    strlit2584 = alloc_String("class");
  }
// compilenode returning strlit2584
  params[0] = strlit2584;
  Object opresult2586 = callmethod(call2583, "==", 1, params);
// compilenode returning opresult2586
  Object if2582;
  if (istrue(opresult2586)) {
// Begin line 808
  setline(808);
// compilenode returning *var_o
// Begin line 809
  setline(809);
// compilenode returning self
  params[0] = *var_o;
  Object call2587 = callmethod(self, "compileclass",
    1, params);
// compilenode returning call2587
    if2582 = call2587;
  } else {
  }
// compilenode returning if2582
// Begin line 811
  setline(811);
// Begin line 813
  setline(813);
// Begin line 1035
  setline(1035);
// Begin line 810
  setline(810);
// compilenode returning *var_o
  Object call2589 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2589
// compilenode returning call2589
  if (strlit2590 == NULL) {
    strlit2590 = alloc_String("object");
  }
// compilenode returning strlit2590
  params[0] = strlit2590;
  Object opresult2592 = callmethod(call2589, "==", 1, params);
// compilenode returning opresult2592
  Object if2588;
  if (istrue(opresult2592)) {
// Begin line 811
  setline(811);
// compilenode returning *var_o
// Begin line 812
  setline(812);
// compilenode returning self
  params[0] = *var_o;
  Object call2593 = callmethod(self, "compileobject",
    1, params);
// compilenode returning call2593
    if2588 = call2593;
  } else {
  }
// compilenode returning if2588
// Begin line 814
  setline(814);
// Begin line 816
  setline(816);
// Begin line 1035
  setline(1035);
// Begin line 813
  setline(813);
// compilenode returning *var_o
  Object call2595 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2595
// compilenode returning call2595
  if (strlit2596 == NULL) {
    strlit2596 = alloc_String("member");
  }
// compilenode returning strlit2596
  params[0] = strlit2596;
  Object opresult2598 = callmethod(call2595, "==", 1, params);
// compilenode returning opresult2598
  Object if2594;
  if (istrue(opresult2598)) {
// Begin line 814
  setline(814);
// compilenode returning *var_o
// Begin line 815
  setline(815);
// compilenode returning self
  params[0] = *var_o;
  Object call2599 = callmethod(self, "compilemember",
    1, params);
// compilenode returning call2599
    if2594 = call2599;
  } else {
  }
// compilenode returning if2594
// Begin line 817
  setline(817);
// Begin line 819
  setline(819);
// Begin line 1035
  setline(1035);
// Begin line 816
  setline(816);
// compilenode returning *var_o
  Object call2601 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2601
// compilenode returning call2601
  if (strlit2602 == NULL) {
    strlit2602 = alloc_String("for");
  }
// compilenode returning strlit2602
  params[0] = strlit2602;
  Object opresult2604 = callmethod(call2601, "==", 1, params);
// compilenode returning opresult2604
  Object if2600;
  if (istrue(opresult2604)) {
// Begin line 817
  setline(817);
// compilenode returning *var_o
// Begin line 818
  setline(818);
// compilenode returning self
  params[0] = *var_o;
  Object call2605 = callmethod(self, "compilefor",
    1, params);
// compilenode returning call2605
    if2600 = call2605;
  } else {
  }
// compilenode returning if2600
// Begin line 854
  setline(854);
// Begin line 857
  setline(857);
// Begin line 1035
  setline(1035);
// Begin line 819
  setline(819);
// compilenode returning *var_o
  Object call2607 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2607
// compilenode returning call2607
  if (strlit2608 == NULL) {
    strlit2608 = alloc_String("call");
  }
// compilenode returning strlit2608
  params[0] = strlit2608;
  Object opresult2610 = callmethod(call2607, "==", 1, params);
// compilenode returning opresult2610
  Object if2606;
  if (istrue(opresult2610)) {
// Begin line 854
  setline(854);
// Begin line 856
  setline(856);
// Begin line 1035
  setline(1035);
// Begin line 856
  setline(856);
// Begin line 1035
  setline(1035);
// Begin line 820
  setline(820);
// compilenode returning *var_o
  Object call2612 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2612
// compilenode returning call2612
  Object call2613 = callmethod(call2612, "value",
    0, params);
// compilenode returning call2613
// compilenode returning call2613
  if (strlit2614 == NULL) {
    strlit2614 = alloc_String("print");
  }
// compilenode returning strlit2614
  params[0] = strlit2614;
  Object opresult2616 = callmethod(call2613, "==", 1, params);
// compilenode returning opresult2616
  Object if2611;
  if (istrue(opresult2616)) {
  Object *var_args = alloc_var();
  *var_args = undefined;
  Object *var_parami = alloc_var();
  *var_parami = undefined;
// Begin line 822
  setline(822);
  Object array2617 = alloc_List();
// compilenode returning array2617
  var_args = alloc_var();
  *var_args = array2617;
  if (array2617 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 824
  setline(824);
// Begin line 826
  setline(826);
// Begin line 1035
  setline(1035);
// Begin line 822
  setline(822);
// compilenode returning *var_o
  Object call2619 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call2619
// compilenode returning call2619
// Begin line 824
  setline(824);
// Begin line 1035
  setline(1035);
  Object obj2621 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2621, self, 0);
  addmethod2(obj2621, "outer", &reader_genc_outer_2622);
  adddatum2(obj2621, self, 0);
  block_savedest(obj2621);
  Object **closure2623 = createclosure(2);
  addtoclosure(closure2623, var_args);
  Object *selfpp2626 = alloc_var();
  *selfpp2626 = self;
  addtoclosure(closure2623, selfpp2626);
  struct UserObject *uo2623 = (struct UserObject*)obj2621;
  uo2623->data[1] = (Object)closure2623;
  addmethod2(obj2621, "apply", &meth_genc_apply2623);
  set_type(obj2621, 0);
// compilenode returning obj2621
  setclassname(obj2621, "Block<genc:2620>");
// compilenode returning obj2621
  params[0] = call2619;
  Object iter2618 = callmethod(call2619, "iter", 1, params);
  while(1) {
    Object cond2618 = callmethod(iter2618, "havemore", 0, NULL);
    if (!istrue(cond2618)) break;
    params[0] = callmethod(iter2618, "next", 0, NULL);
    callmethod(obj2621, "apply", 1, params);
  }
// compilenode returning call2619
// Begin line 827
  setline(827);
// Begin line 826
  setline(826);
  Object num2627 = alloc_Float64(0.0);
// compilenode returning num2627
  var_parami = alloc_var();
  *var_parami = num2627;
  if (num2627 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 830
  setline(830);
// Begin line 827
  setline(827);
// compilenode returning *var_args
// Begin line 830
  setline(830);
// Begin line 1035
  setline(1035);
  Object obj2630 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2630, self, 0);
  addmethod2(obj2630, "outer", &reader_genc_outer_2631);
  adddatum2(obj2630, self, 0);
  block_savedest(obj2630);
  Object **closure2632 = createclosure(2);
  addtoclosure(closure2632, var_parami);
  Object *selfpp2649 = alloc_var();
  *selfpp2649 = self;
  addtoclosure(closure2632, selfpp2649);
  struct UserObject *uo2632 = (struct UserObject*)obj2630;
  uo2632->data[1] = (Object)closure2632;
  addmethod2(obj2630, "apply", &meth_genc_apply2632);
  set_type(obj2630, 0);
// compilenode returning obj2630
  setclassname(obj2630, "Block<genc:2629>");
// compilenode returning obj2630
  params[0] = *var_args;
  Object iter2628 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond2628 = callmethod(iter2628, "havemore", 0, NULL);
    if (!istrue(cond2628)) break;
    params[0] = callmethod(iter2628, "next", 0, NULL);
    callmethod(obj2630, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 832
  setline(832);
// Begin line 831
  setline(831);
  if (strlit2650 == NULL) {
    strlit2650 = alloc_String("  Object call");
  }
// compilenode returning strlit2650
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2652 = callmethod(strlit2650, "++", 1, params);
// compilenode returning opresult2652
  if (strlit2653 == NULL) {
    strlit2653 = alloc_String(" = gracelib_print(NULL, ");
  }
// compilenode returning strlit2653
  params[0] = strlit2653;
  Object opresult2655 = callmethod(opresult2652, "++", 1, params);
// compilenode returning opresult2655
// Begin line 832
  setline(832);
// Begin line 1035
  setline(1035);
// Begin line 832
  setline(832);
// compilenode returning *var_args
  Object call2656 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2656
// compilenode returning call2656
  params[0] = call2656;
  Object opresult2658 = callmethod(opresult2655, "++", 1, params);
// compilenode returning opresult2658
  if (strlit2659 == NULL) {
    strlit2659 = alloc_String(",  params);");
  }
// compilenode returning strlit2659
  params[0] = strlit2659;
  Object opresult2661 = callmethod(opresult2658, "++", 1, params);
// compilenode returning opresult2661
// Begin line 833
  setline(833);
// compilenode returning self
  params[0] = opresult2661;
  Object call2662 = callmethod(self, "out",
    1, params);
// compilenode returning call2662
// Begin line 834
  setline(834);
// Begin line 1035
  setline(1035);
// Begin line 834
  setline(834);
// Begin line 833
  setline(833);
  if (strlit2663 == NULL) {
    strlit2663 = alloc_String("call");
  }
// compilenode returning strlit2663
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2665 = callmethod(strlit2663, "++", 1, params);
// compilenode returning opresult2665
// compilenode returning *var_o
  params[0] = opresult2665;
  Object call2666 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2666
// compilenode returning nothing
// Begin line 835
  setline(835);
// Begin line 834
  setline(834);
// compilenode returning *var_auto_count
  Object num2667 = alloc_Float64(1.0);
// compilenode returning num2667
  params[0] = num2667;
  Object sum2669 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2669
  *var_auto_count = sum2669;
  if (sum2669 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2611 = nothing;
  } else {
// Begin line 854
  setline(854);
// Begin line 847
  setline(847);
// Begin line 1035
  setline(1035);
// Begin line 847
  setline(847);
// Begin line 1035
  setline(1035);
// Begin line 835
  setline(835);
// compilenode returning *var_o
  Object call2672 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2672
// compilenode returning call2672
  Object call2673 = callmethod(call2672, "kind",
    0, params);
// compilenode returning call2673
// compilenode returning call2673
  if (strlit2674 == NULL) {
    strlit2674 = alloc_String("identifier");
  }
// compilenode returning strlit2674
  params[0] = strlit2674;
  Object opresult2676 = callmethod(call2673, "==", 1, params);
// compilenode returning opresult2676
// Begin line 847
  setline(847);
// Begin line 1035
  setline(1035);
// Begin line 847
  setline(847);
// Begin line 1035
  setline(1035);
// Begin line 836
  setline(836);
// compilenode returning *var_o
  Object call2677 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2677
// compilenode returning call2677
  Object call2678 = callmethod(call2677, "value",
    0, params);
// compilenode returning call2678
// compilenode returning call2678
  if (strlit2679 == NULL) {
    strlit2679 = alloc_String("length");
  }
// compilenode returning strlit2679
  params[0] = strlit2679;
  Object opresult2681 = callmethod(call2678, "==", 1, params);
// compilenode returning opresult2681
  params[0] = opresult2681;
  Object opresult2683 = callmethod(opresult2676, "&", 1, params);
// compilenode returning opresult2683
  Object if2671;
  if (istrue(opresult2683)) {
// Begin line 842
  setline(842);
// Begin line 844
  setline(844);
// Begin line 1035
  setline(1035);
// Begin line 844
  setline(844);
// Begin line 1035
  setline(1035);
// Begin line 837
  setline(837);
// compilenode returning *var_o
  Object call2685 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call2685
// compilenode returning call2685
  Object call2686 = callmethod(call2685, "size",
    0, params);
// compilenode returning call2686
// compilenode returning call2686
  Object num2687 = alloc_Float64(0.0);
// compilenode returning num2687
  params[0] = num2687;
  Object opresult2689 = callmethod(call2686, "==", 1, params);
// compilenode returning opresult2689
  Object if2684;
  if (istrue(opresult2689)) {
// Begin line 838
  setline(838);
  if (strlit2690 == NULL) {
    strlit2690 = alloc_String("; PP FOLLOWS");
  }
// compilenode returning strlit2690
// Begin line 839
  setline(839);
// compilenode returning self
  params[0] = strlit2690;
  Object call2691 = callmethod(self, "out",
    1, params);
// compilenode returning call2691
  Object num2692 = alloc_Float64(0.0);
// compilenode returning num2692
// compilenode returning *var_o
  params[0] = num2692;
  Object call2693 = callmethod(*var_o, "pretty",
    1, params);
// compilenode returning call2693
// Begin line 840
  setline(840);
// compilenode returning self
  params[0] = call2693;
  Object call2694 = callmethod(self, "out",
    1, params);
// compilenode returning call2694
// Begin line 841
  setline(841);
// Begin line 840
  setline(840);
  if (strlit2695 == NULL) {
    strlit2695 = alloc_String("null");
  }
// compilenode returning strlit2695
  *var_tmp = strlit2695;
  if (strlit2695 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2684 = nothing;
  } else {
// Begin line 842
  setline(842);
// Begin line 1035
  setline(1035);
// Begin line 842
  setline(842);
// Begin line 1035
  setline(1035);
// Begin line 842
  setline(842);
// compilenode returning *var_o
  Object call2697 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call2697
// compilenode returning call2697
  Object call2698 = callmethod(call2697, "first",
    0, params);
// compilenode returning call2698
// compilenode returning call2698
// Begin line 843
  setline(843);
// compilenode returning self
  params[0] = call2698;
  Object call2699 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2699
  *var_tmp = call2699;
  if (call2699 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2684 = nothing;
  }
// compilenode returning if2684
// Begin line 844
  setline(844);
  if (strlit2701 == NULL) {
    strlit2701 = alloc_String("  Object call");
  }
// compilenode returning strlit2701
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2703 = callmethod(strlit2701, "++", 1, params);
// compilenode returning opresult2703
  if (strlit2704 == NULL) {
    strlit2704 = alloc_String(" = gracelib_length(");
  }
// compilenode returning strlit2704
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult2706 = callmethod(strlit2704, "++", 1, params);
// compilenode returning opresult2706
  if (strlit2707 == NULL) {
    strlit2707 = alloc_String(");");
  }
// compilenode returning strlit2707
  params[0] = strlit2707;
  Object opresult2709 = callmethod(opresult2706, "++", 1, params);
// compilenode returning opresult2709
  params[0] = opresult2709;
  Object opresult2711 = callmethod(opresult2703, "++", 1, params);
// compilenode returning opresult2711
// Begin line 845
  setline(845);
// compilenode returning self
  params[0] = opresult2711;
  Object call2712 = callmethod(self, "out",
    1, params);
// compilenode returning call2712
// Begin line 846
  setline(846);
// Begin line 1035
  setline(1035);
// Begin line 846
  setline(846);
// Begin line 845
  setline(845);
  if (strlit2713 == NULL) {
    strlit2713 = alloc_String("call");
  }
// compilenode returning strlit2713
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2715 = callmethod(strlit2713, "++", 1, params);
// compilenode returning opresult2715
// compilenode returning *var_o
  params[0] = opresult2715;
  Object call2716 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2716
// compilenode returning nothing
// Begin line 847
  setline(847);
// Begin line 846
  setline(846);
// compilenode returning *var_auto_count
  Object num2717 = alloc_Float64(1.0);
// compilenode returning num2717
  params[0] = num2717;
  Object sum2719 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2719
  *var_auto_count = sum2719;
  if (sum2719 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2671 = nothing;
  } else {
// Begin line 854
  setline(854);
// Begin line 853
  setline(853);
// Begin line 1035
  setline(1035);
// Begin line 853
  setline(853);
// Begin line 1035
  setline(1035);
// Begin line 847
  setline(847);
// compilenode returning *var_o
  Object call2722 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2722
// compilenode returning call2722
  Object call2723 = callmethod(call2722, "kind",
    0, params);
// compilenode returning call2723
// compilenode returning call2723
  if (strlit2724 == NULL) {
    strlit2724 = alloc_String("identifier");
  }
// compilenode returning strlit2724
  params[0] = strlit2724;
  Object opresult2726 = callmethod(call2723, "==", 1, params);
// compilenode returning opresult2726
// Begin line 853
  setline(853);
// Begin line 1035
  setline(1035);
// Begin line 853
  setline(853);
// Begin line 1035
  setline(1035);
// Begin line 848
  setline(848);
// compilenode returning *var_o
  Object call2727 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2727
// compilenode returning call2727
  Object call2728 = callmethod(call2727, "value",
    0, params);
// compilenode returning call2728
// compilenode returning call2728
  if (strlit2729 == NULL) {
    strlit2729 = alloc_String("escapestring");
  }
// compilenode returning strlit2729
  params[0] = strlit2729;
  Object opresult2731 = callmethod(call2728, "==", 1, params);
// compilenode returning opresult2731
  params[0] = opresult2731;
  Object opresult2733 = callmethod(opresult2726, "&", 1, params);
// compilenode returning opresult2733
  Object if2721;
  if (istrue(opresult2733)) {
// Begin line 850
  setline(850);
// Begin line 1035
  setline(1035);
// Begin line 850
  setline(850);
// Begin line 1035
  setline(1035);
// Begin line 849
  setline(849);
// compilenode returning *var_o
  Object call2734 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call2734
// compilenode returning call2734
  Object call2735 = callmethod(call2734, "first",
    0, params);
// compilenode returning call2735
// compilenode returning call2735
  *var_tmp = call2735;
  if (call2735 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 850
  setline(850);
  if (strlit2737 == NULL) {
    strlit2737 = alloc_String("_escape");
  }
// compilenode returning strlit2737
// compilenode returning *var_tmp
// compilenode returning module_ast
  params[0] = strlit2737;
  params[1] = *var_tmp;
  Object call2738 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call2738
  *var_tmp = call2738;
  if (call2738 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 851
  setline(851);
// compilenode returning *var_tmp
  Object array2740 = alloc_List();
// compilenode returning array2740
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = array2740;
  Object call2741 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call2741
  *var_tmp = call2741;
  if (call2741 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 852
  setline(852);
// Begin line 1035
  setline(1035);
// Begin line 852
  setline(852);
// compilenode returning *var_tmp
// Begin line 853
  setline(853);
// compilenode returning self
  params[0] = *var_tmp;
  Object call2743 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2743
// Begin line 852
  setline(852);
// compilenode returning *var_o
  params[0] = call2743;
  Object call2744 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2744
// compilenode returning nothing
    if2721 = nothing;
  } else {
// Begin line 854
  setline(854);
// compilenode returning *var_o
// Begin line 855
  setline(855);
// compilenode returning self
  params[0] = *var_o;
  Object call2745 = callmethod(self, "compilecall",
    1, params);
// compilenode returning call2745
    if2721 = call2745;
  }
// compilenode returning if2721
    if2671 = if2721;
  }
// compilenode returning if2671
    if2611 = if2671;
  }
// compilenode returning if2611
    if2606 = if2611;
  } else {
  }
// compilenode returning if2606
// Begin line 858
  setline(858);
// Begin line 860
  setline(860);
// Begin line 1035
  setline(1035);
// Begin line 857
  setline(857);
// compilenode returning *var_o
  Object call2747 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call2747
// compilenode returning call2747
  if (strlit2748 == NULL) {
    strlit2748 = alloc_String("op");
  }
// compilenode returning strlit2748
  params[0] = strlit2748;
  Object opresult2750 = callmethod(call2747, "==", 1, params);
// compilenode returning opresult2750
  Object if2746;
  if (istrue(opresult2750)) {
// Begin line 858
  setline(858);
// compilenode returning *var_o
// Begin line 859
  setline(859);
// compilenode returning self
  params[0] = *var_o;
  Object call2751 = callmethod(self, "compileop",
    1, params);
// compilenode returning call2751
    if2746 = call2751;
  } else {
  }
// compilenode returning if2746
// Begin line 860
  setline(860);
  if (strlit2752 == NULL) {
    strlit2752 = alloc_String("// compilenode returning ");
  }
// compilenode returning strlit2752
// Begin line 1035
  setline(1035);
// Begin line 860
  setline(860);
// compilenode returning *var_o
  Object call2753 = callmethod(*var_o, "register",
    0, params);
// compilenode returning call2753
// compilenode returning call2753
  params[0] = call2753;
  Object opresult2755 = callmethod(strlit2752, "++", 1, params);
// compilenode returning opresult2755
// Begin line 861
  setline(861);
// compilenode returning self
  params[0] = opresult2755;
  Object call2756 = callmethod(self, "out",
    1, params);
// compilenode returning call2756
// Begin line 1035
  setline(1035);
// Begin line 861
  setline(861);
// compilenode returning *var_o
  Object call2757 = callmethod(*var_o, "register",
    0, params);
// compilenode returning call2757
// compilenode returning call2757
  return call2757;
}
Object meth_genc_apply2779(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[2];
  Object *var_linkfiles = closure[0];
  Object *var_staticmodules = closure[1];
  Object *var_ext = closure[2];
  Object *var_argv = closure[3];
  Object *var_cmd = closure[4];
  Object self = *closure[5];
// Begin line 920
  setline(920);
// Begin line 923
  setline(923);
// Begin line 1035
  setline(1035);
// Begin line 877
  setline(877);
// compilenode returning *var_v
  Object call2781 = callmethod(*var_v, "kind",
    0, params);
// compilenode returning call2781
// compilenode returning call2781
  if (strlit2782 == NULL) {
    strlit2782 = alloc_String("import");
  }
// compilenode returning strlit2782
  params[0] = strlit2782;
  Object opresult2784 = callmethod(call2781, "==", 1, params);
// compilenode returning opresult2784
  Object if2780;
  if (istrue(opresult2784)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_exists = alloc_var();
  *var_exists = undefined;
// Begin line 879
  setline(879);
// Begin line 1035
  setline(1035);
// Begin line 879
  setline(879);
// Begin line 1035
  setline(1035);
// Begin line 878
  setline(878);
// compilenode returning *var_v
  Object call2785 = callmethod(*var_v, "value",
    0, params);
// compilenode returning call2785
// compilenode returning call2785
  Object call2786 = callmethod(call2785, "value",
    0, params);
// compilenode returning call2786
// compilenode returning call2786
  var_nm = alloc_var();
  *var_nm = call2786;
  if (call2786 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 880
  setline(880);
// Begin line 879
  setline(879);
  Object bool2787 = alloc_Boolean(0);
// compilenode returning bool2787
  var_exists = alloc_var();
  *var_exists = bool2787;
  if (bool2787 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 886
  setline(886);
// Begin line 880
  setline(880);
// compilenode returning *var_nm
  if (strlit2789 == NULL) {
    strlit2789 = alloc_String(".gso");
  }
// compilenode returning strlit2789
  params[0] = strlit2789;
  Object opresult2791 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2791
// compilenode returning module_io
  params[0] = opresult2791;
  Object call2792 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call2792
  Object if2788;
  if (istrue(call2792)) {
// Begin line 882
  setline(882);
// Begin line 881
  setline(881);
  Object bool2793 = alloc_Boolean(1);
// compilenode returning bool2793
  *var_exists = bool2793;
  if (bool2793 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2788 = nothing;
  } else {
// Begin line 886
  setline(886);
// Begin line 882
  setline(882);
// compilenode returning *var_nm
  if (strlit2796 == NULL) {
    strlit2796 = alloc_String(".gcn");
  }
// compilenode returning strlit2796
  params[0] = strlit2796;
  Object opresult2798 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2798
// compilenode returning module_io
  params[0] = opresult2798;
  Object call2799 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call2799
  Object if2795;
  if (istrue(call2799)) {
// Begin line 886
  setline(886);
// Begin line 883
  setline(883);
// compilenode returning *var_nm
  if (strlit2801 == NULL) {
    strlit2801 = alloc_String(".gcn");
  }
// compilenode returning strlit2801
  params[0] = strlit2801;
  Object opresult2803 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2803
// compilenode returning *var_nm
  if (strlit2804 == NULL) {
    strlit2804 = alloc_String(".grace");
  }
// compilenode returning strlit2804
  params[0] = strlit2804;
  Object opresult2806 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2806
// compilenode returning module_io
  params[0] = opresult2803;
  params[1] = opresult2806;
  Object call2807 = callmethod(module_io, "newer",
    2, params);
// compilenode returning call2807
  Object if2800;
  if (istrue(call2807)) {
// Begin line 885
  setline(885);
// Begin line 884
  setline(884);
  Object bool2808 = alloc_Boolean(1);
// compilenode returning bool2808
  *var_exists = bool2808;
  if (bool2808 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 885
  setline(885);
// compilenode returning *var_nm
  if (strlit2810 == NULL) {
    strlit2810 = alloc_String(".gcn");
  }
// compilenode returning strlit2810
  params[0] = strlit2810;
  Object opresult2812 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2812
// compilenode returning *var_linkfiles
  params[0] = opresult2812;
  Object call2813 = callmethod(*var_linkfiles, "push",
    1, params);
// compilenode returning call2813
// Begin line 886
  setline(886);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call2814 = callmethod(*var_staticmodules, "push",
    1, params);
// compilenode returning call2814
    if2800 = call2814;
  } else {
  }
// compilenode returning if2800
    if2795 = if2800;
  } else {
  }
// compilenode returning if2795
    if2788 = if2795;
  }
// compilenode returning if2788
// Begin line 913
  setline(913);
// Begin line 915
  setline(915);
// Begin line 1035
  setline(1035);
// Begin line 889
  setline(889);
// compilenode returning *var_exists
  Object call2816 = callmethod(*var_exists, "not",
    0, params);
// compilenode returning call2816
// compilenode returning call2816
  Object if2815;
  if (istrue(call2816)) {
// Begin line 892
  setline(892);
// Begin line 890
  setline(890);
// compilenode returning *var_nm
  if (strlit2818 == NULL) {
    strlit2818 = alloc_String(".gc");
  }
// compilenode returning strlit2818
  params[0] = strlit2818;
  Object opresult2820 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2820
// compilenode returning module_io
  params[0] = opresult2820;
  Object call2821 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call2821
  Object if2817;
  if (istrue(call2821)) {
// Begin line 892
  setline(892);
// Begin line 891
  setline(891);
  if (strlit2822 == NULL) {
    strlit2822 = alloc_String(".gc");
  }
// compilenode returning strlit2822
  *var_ext = strlit2822;
  if (strlit2822 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2817 = nothing;
  } else {
  }
// compilenode returning if2817
// Begin line 895
  setline(895);
// Begin line 893
  setline(893);
// compilenode returning *var_nm
  if (strlit2825 == NULL) {
    strlit2825 = alloc_String(".grace");
  }
// compilenode returning strlit2825
  params[0] = strlit2825;
  Object opresult2827 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2827
// compilenode returning module_io
  params[0] = opresult2827;
  Object call2828 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call2828
  Object if2824;
  if (istrue(call2828)) {
// Begin line 895
  setline(895);
// Begin line 894
  setline(894);
  if (strlit2829 == NULL) {
    strlit2829 = alloc_String(".grace");
  }
// compilenode returning strlit2829
  *var_ext = strlit2829;
  if (strlit2829 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2824 = nothing;
  } else {
  }
// compilenode returning if2824
// Begin line 913
  setline(913);
// Begin line 914
  setline(914);
// Begin line 896
  setline(896);
// compilenode returning *var_ext
  Object bool2832 = alloc_Boolean(0);
// compilenode returning bool2832
  params[0] = bool2832;
  Object opresult2834 = callmethod(*var_ext, "/=", 1, params);
// compilenode returning opresult2834
  Object if2831;
  if (istrue(opresult2834)) {
// Begin line 898
  setline(898);
// Begin line 1035
  setline(1035);
// Begin line 897
  setline(897);
// compilenode returning *var_argv
  Object call2835 = callmethod(*var_argv, "first",
    0, params);
// compilenode returning call2835
// compilenode returning call2835
  if (strlit2836 == NULL) {
    strlit2836 = alloc_String(" --target c --make ");
  }
// compilenode returning strlit2836
  params[0] = strlit2836;
  Object opresult2838 = callmethod(call2835, "++", 1, params);
// compilenode returning opresult2838
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2840 = callmethod(opresult2838, "++", 1, params);
// compilenode returning opresult2840
// compilenode returning *var_ext
  params[0] = *var_ext;
  Object opresult2842 = callmethod(opresult2840, "++", 1, params);
// compilenode returning opresult2842
  *var_cmd = opresult2842;
  if (opresult2842 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 899
  setline(899);
// Begin line 898
  setline(898);
// compilenode returning *var_cmd
// Begin line 899
  setline(899);
// Begin line 898
  setline(898);
  if (strlit2844 == NULL) {
    strlit2844 = alloc_String(" --gracelib ""\x22""");
  }
// compilenode returning strlit2844
// Begin line 899
  setline(899);
// Begin line 1035
  setline(1035);
// Begin line 898
  setline(898);
// compilenode returning module_util
  Object call2845 = callmethod(module_util, "gracelibPath",
    0, params);
// compilenode returning call2845
// compilenode returning call2845
  params[0] = call2845;
  Object opresult2847 = callmethod(strlit2844, "++", 1, params);
// compilenode returning opresult2847
  if (strlit2848 == NULL) {
    strlit2848 = alloc_String("""\x22""");
  }
// compilenode returning strlit2848
  params[0] = strlit2848;
  Object opresult2850 = callmethod(opresult2847, "++", 1, params);
// compilenode returning opresult2850
  params[0] = opresult2850;
  Object opresult2852 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult2852
  *var_cmd = opresult2852;
  if (opresult2852 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 901
  setline(901);
// Begin line 902
  setline(902);
// Begin line 1035
  setline(1035);
// Begin line 899
  setline(899);
// compilenode returning module_util
  Object call2855 = callmethod(module_util, "verbosity",
    0, params);
// compilenode returning call2855
// compilenode returning call2855
  Object num2856 = alloc_Float64(30.0);
// compilenode returning num2856
  params[0] = num2856;
  Object opresult2858 = callmethod(call2855, ">", 1, params);
// compilenode returning opresult2858
  Object if2854;
  if (istrue(opresult2858)) {
// Begin line 901
  setline(901);
// Begin line 900
  setline(900);
// compilenode returning *var_cmd
  if (strlit2859 == NULL) {
    strlit2859 = alloc_String(" --verbose");
  }
// compilenode returning strlit2859
  params[0] = strlit2859;
  Object opresult2861 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult2861
  *var_cmd = opresult2861;
  if (opresult2861 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2854 = nothing;
  } else {
  }
// compilenode returning if2854
// Begin line 904
  setline(904);
// Begin line 905
  setline(905);
// Begin line 1035
  setline(1035);
// Begin line 902
  setline(902);
// compilenode returning module_util
  Object call2864 = callmethod(module_util, "vtag",
    0, params);
// compilenode returning call2864
// compilenode returning call2864
  Object if2863;
  if (istrue(call2864)) {
// Begin line 904
  setline(904);
// Begin line 903
  setline(903);
// compilenode returning *var_cmd
  if (strlit2865 == NULL) {
    strlit2865 = alloc_String(" --vtag ");
  }
// compilenode returning strlit2865
  params[0] = strlit2865;
  Object opresult2867 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult2867
// Begin line 904
  setline(904);
// Begin line 1035
  setline(1035);
// Begin line 903
  setline(903);
// compilenode returning module_util
  Object call2868 = callmethod(module_util, "vtag",
    0, params);
// compilenode returning call2868
// compilenode returning call2868
  params[0] = call2868;
  Object opresult2870 = callmethod(opresult2867, "++", 1, params);
// compilenode returning opresult2870
  *var_cmd = opresult2870;
  if (opresult2870 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2863 = nothing;
  } else {
  }
// compilenode returning if2863
// Begin line 906
  setline(906);
// Begin line 905
  setline(905);
// compilenode returning *var_cmd
  if (strlit2872 == NULL) {
    strlit2872 = alloc_String(" --noexec");
  }
// compilenode returning strlit2872
  params[0] = strlit2872;
  Object opresult2874 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult2874
  *var_cmd = opresult2874;
  if (opresult2874 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 907
  setline(907);
// Begin line 906
  setline(906);
// Begin line 1035
  setline(1035);
// Begin line 906
  setline(906);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call2877 = callmethod(module_io, "system",
    1, params);
// compilenode returning call2877
  Object call2878 = callmethod(call2877, "not",
    0, params);
// compilenode returning call2878
// compilenode returning call2878
  Object if2876;
  if (istrue(call2878)) {
// Begin line 907
  setline(907);
  if (strlit2879 == NULL) {
    strlit2879 = alloc_String("failed processing import of ");
  }
// compilenode returning strlit2879
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2881 = callmethod(strlit2879, "++", 1, params);
// compilenode returning opresult2881
  if (strlit2882 == NULL) {
    strlit2882 = alloc_String(".");
  }
// compilenode returning strlit2882
  params[0] = strlit2882;
  Object opresult2884 = callmethod(opresult2881, "++", 1, params);
// compilenode returning opresult2884
// compilenode returning module_util
  params[0] = opresult2884;
  Object call2885 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2885
    if2876 = call2885;
  } else {
  }
// compilenode returning if2876
// Begin line 910
  setline(910);
// Begin line 909
  setline(909);
  Object bool2886 = alloc_Boolean(1);
// compilenode returning bool2886
  *var_exists = bool2886;
  if (bool2886 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 910
  setline(910);
// compilenode returning *var_nm
  if (strlit2888 == NULL) {
    strlit2888 = alloc_String(".gcn");
  }
// compilenode returning strlit2888
  params[0] = strlit2888;
  Object opresult2890 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult2890
// compilenode returning *var_linkfiles
  params[0] = opresult2890;
  Object call2891 = callmethod(*var_linkfiles, "push",
    1, params);
// compilenode returning call2891
// Begin line 911
  setline(911);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call2892 = callmethod(*var_staticmodules, "push",
    1, params);
// compilenode returning call2892
// Begin line 913
  setline(913);
// Begin line 912
  setline(912);
  Object bool2893 = alloc_Boolean(0);
// compilenode returning bool2893
  *var_ext = bool2893;
  if (bool2893 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2831 = nothing;
  } else {
  }
// compilenode returning if2831
    if2815 = if2831;
  } else {
  }
// compilenode returning if2815
// Begin line 917
  setline(917);
// Begin line 919
  setline(919);
// Begin line 915
  setline(915);
// compilenode returning *var_nm
  if (strlit2896 == NULL) {
    strlit2896 = alloc_String("sys");
  }
// compilenode returning strlit2896
  params[0] = strlit2896;
  Object opresult2898 = callmethod(*var_nm, "==", 1, params);
// compilenode returning opresult2898
// Begin line 919
  setline(919);
// Begin line 915
  setline(915);
// compilenode returning *var_nm
  if (strlit2899 == NULL) {
    strlit2899 = alloc_String("io");
  }
// compilenode returning strlit2899
  params[0] = strlit2899;
  Object opresult2901 = callmethod(*var_nm, "==", 1, params);
// compilenode returning opresult2901
  params[0] = opresult2901;
  Object opresult2903 = callmethod(opresult2898, "|", 1, params);
// compilenode returning opresult2903
  Object if2895;
  if (istrue(opresult2903)) {
// Begin line 917
  setline(917);
// Begin line 916
  setline(916);
  Object bool2904 = alloc_Boolean(1);
// compilenode returning bool2904
  *var_exists = bool2904;
  if (bool2904 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 917
  setline(917);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call2906 = callmethod(*var_staticmodules, "push",
    1, params);
// compilenode returning call2906
    if2895 = call2906;
  } else {
  }
// compilenode returning if2895
// Begin line 920
  setline(920);
// Begin line 922
  setline(922);
// Begin line 1035
  setline(1035);
// Begin line 919
  setline(919);
// compilenode returning *var_exists
  Object call2908 = callmethod(*var_exists, "not",
    0, params);
// compilenode returning call2908
// compilenode returning call2908
  Object if2907;
  if (istrue(call2908)) {
// Begin line 920
  setline(920);
  if (strlit2909 == NULL) {
    strlit2909 = alloc_String("failed finding import of ");
  }
// compilenode returning strlit2909
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2911 = callmethod(strlit2909, "++", 1, params);
// compilenode returning opresult2911
  if (strlit2912 == NULL) {
    strlit2912 = alloc_String(".");
  }
// compilenode returning strlit2912
  params[0] = strlit2912;
  Object opresult2914 = callmethod(opresult2911, "++", 1, params);
// compilenode returning opresult2914
// compilenode returning module_util
  params[0] = opresult2914;
  Object call2915 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2915
    if2907 = call2915;
  } else {
  }
// compilenode returning if2907
    if2780 = if2907;
  } else {
  }
// compilenode returning if2780
  return if2780;
}
Object meth_genc_apply2978(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 955
  setline(955);
// Begin line 957
  setline(957);
// Begin line 1035
  setline(1035);
// Begin line 941
  setline(941);
// compilenode returning *var_l
  Object call2980 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call2980
// compilenode returning call2980
  if (strlit2981 == NULL) {
    strlit2981 = alloc_String("vardec");
  }
// compilenode returning strlit2981
  params[0] = strlit2981;
  Object opresult2983 = callmethod(call2980, "==", 1, params);
// compilenode returning opresult2983
// Begin line 957
  setline(957);
// Begin line 1035
  setline(1035);
// Begin line 941
  setline(941);
// compilenode returning *var_l
  Object call2984 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call2984
// compilenode returning call2984
  if (strlit2985 == NULL) {
    strlit2985 = alloc_String("defdec");
  }
// compilenode returning strlit2985
  params[0] = strlit2985;
  Object opresult2987 = callmethod(call2984, "==", 1, params);
// compilenode returning opresult2987
  params[0] = opresult2987;
  Object opresult2989 = callmethod(opresult2983, "|", 1, params);
// compilenode returning opresult2989
  Object if2979;
  if (istrue(opresult2989)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 942
  setline(942);
// Begin line 1035
  setline(1035);
// Begin line 942
  setline(942);
// Begin line 1035
  setline(1035);
// Begin line 942
  setline(942);
// compilenode returning *var_l
  Object call2990 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call2990
// compilenode returning call2990
  Object call2991 = callmethod(call2990, "value",
    0, params);
// compilenode returning call2991
// compilenode returning call2991
// Begin line 943
  setline(943);
// compilenode returning self
  params[0] = call2991;
  Object call2992 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call2992
  var_tnm = alloc_var();
  *var_tnm = call2992;
  if (call2992 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call2993 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call2993
// Begin line 944
  setline(944);
  if (strlit2994 == NULL) {
    strlit2994 = alloc_String("  Object *var_");
  }
// compilenode returning strlit2994
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult2996 = callmethod(strlit2994, "++", 1, params);
// compilenode returning opresult2996
  if (strlit2997 == NULL) {
    strlit2997 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit2997
  params[0] = strlit2997;
  Object opresult2999 = callmethod(opresult2996, "++", 1, params);
// compilenode returning opresult2999
// Begin line 945
  setline(945);
// compilenode returning self
  params[0] = opresult2999;
  Object call3000 = callmethod(self, "out",
    1, params);
// compilenode returning call3000
  if (strlit3001 == NULL) {
    strlit3001 = alloc_String("  *var_");
  }
// compilenode returning strlit3001
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult3003 = callmethod(strlit3001, "++", 1, params);
// compilenode returning opresult3003
  if (strlit3004 == NULL) {
    strlit3004 = alloc_String(" = undefined;");
  }
// compilenode returning strlit3004
  params[0] = strlit3004;
  Object opresult3006 = callmethod(opresult3003, "++", 1, params);
// compilenode returning opresult3006
// Begin line 946
  setline(946);
// compilenode returning self
  params[0] = opresult3006;
  Object call3007 = callmethod(self, "out",
    1, params);
// compilenode returning call3007
    if2979 = call3007;
  } else {
// Begin line 955
  setline(955);
// Begin line 957
  setline(957);
// Begin line 1035
  setline(1035);
// Begin line 946
  setline(946);
// compilenode returning *var_l
  Object call3009 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call3009
// compilenode returning call3009
  if (strlit3010 == NULL) {
    strlit3010 = alloc_String("class");
  }
// compilenode returning strlit3010
  params[0] = strlit3010;
  Object opresult3012 = callmethod(call3009, "==", 1, params);
// compilenode returning opresult3012
  Object if3008;
  if (istrue(opresult3012)) {
  Object *var_tnmc = alloc_var();
  *var_tnmc = undefined;
// Begin line 948
  setline(948);
  var_tnmc = alloc_var();
  *var_tnmc = undefined;
// compilenode returning nothing
// Begin line 951
  setline(951);
// Begin line 953
  setline(953);
// Begin line 1035
  setline(1035);
// Begin line 953
  setline(953);
// Begin line 1035
  setline(1035);
// Begin line 948
  setline(948);
// compilenode returning *var_l
  Object call3014 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call3014
// compilenode returning call3014
  Object call3015 = callmethod(call3014, "kind",
    0, params);
// compilenode returning call3015
// compilenode returning call3015
  if (strlit3016 == NULL) {
    strlit3016 = alloc_String("generic");
  }
// compilenode returning strlit3016
  params[0] = strlit3016;
  Object opresult3018 = callmethod(call3015, "==", 1, params);
// compilenode returning opresult3018
  Object if3013;
  if (istrue(opresult3018)) {
// Begin line 949
  setline(949);
// Begin line 1035
  setline(1035);
// Begin line 949
  setline(949);
// Begin line 1035
  setline(1035);
// Begin line 949
  setline(949);
// Begin line 1035
  setline(1035);
// Begin line 949
  setline(949);
// compilenode returning *var_l
  Object call3019 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call3019
// compilenode returning call3019
  Object call3020 = callmethod(call3019, "value",
    0, params);
// compilenode returning call3020
// compilenode returning call3020
  Object call3021 = callmethod(call3020, "value",
    0, params);
// compilenode returning call3021
// compilenode returning call3021
// Begin line 950
  setline(950);
// compilenode returning self
  params[0] = call3021;
  Object call3022 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call3022
  *var_tnmc = call3022;
  if (call3022 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3013 = nothing;
  } else {
// Begin line 951
  setline(951);
// Begin line 1035
  setline(1035);
// Begin line 951
  setline(951);
// Begin line 1035
  setline(1035);
// Begin line 951
  setline(951);
// compilenode returning *var_l
  Object call3024 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call3024
// compilenode returning call3024
  Object call3025 = callmethod(call3024, "value",
    0, params);
// compilenode returning call3025
// compilenode returning call3025
// Begin line 952
  setline(952);
// compilenode returning self
  params[0] = call3025;
  Object call3026 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call3026
  *var_tnmc = call3026;
  if (call3026 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3013 = nothing;
  }
// compilenode returning if3013
// Begin line 953
  setline(953);
// compilenode returning *var_tnmc
// compilenode returning *var_declaredvars
  params[0] = *var_tnmc;
  Object call3028 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call3028
// Begin line 954
  setline(954);
  if (strlit3029 == NULL) {
    strlit3029 = alloc_String("  Object *var_");
  }
// compilenode returning strlit3029
// compilenode returning *var_tnmc
  params[0] = *var_tnmc;
  Object opresult3031 = callmethod(strlit3029, "++", 1, params);
// compilenode returning opresult3031
  if (strlit3032 == NULL) {
    strlit3032 = alloc_String(" = alloc_var();");
  }
// compilenode returning strlit3032
  params[0] = strlit3032;
  Object opresult3034 = callmethod(opresult3031, "++", 1, params);
// compilenode returning opresult3034
// Begin line 955
  setline(955);
// compilenode returning self
  params[0] = opresult3034;
  Object call3035 = callmethod(self, "out",
    1, params);
// compilenode returning call3035
  if (strlit3036 == NULL) {
    strlit3036 = alloc_String("  *var_");
  }
// compilenode returning strlit3036
// compilenode returning *var_tnmc
  params[0] = *var_tnmc;
  Object opresult3038 = callmethod(strlit3036, "++", 1, params);
// compilenode returning opresult3038
  if (strlit3039 == NULL) {
    strlit3039 = alloc_String(" = undefined;");
  }
// compilenode returning strlit3039
  params[0] = strlit3039;
  Object opresult3041 = callmethod(opresult3038, "++", 1, params);
// compilenode returning opresult3041
// Begin line 956
  setline(956);
// compilenode returning self
  params[0] = opresult3041;
  Object call3042 = callmethod(self, "out",
    1, params);
// compilenode returning call3042
    if3008 = call3042;
  } else {
  }
// compilenode returning if3008
    if2979 = if3008;
  }
// compilenode returning if2979
  return if2979;
}
Object meth_genc_apply3048(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 959
  setline(959);
// compilenode returning *var_o
// Begin line 960
  setline(960);
// compilenode returning self
  params[0] = *var_o;
  Object call3049 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call3049
  return call3049;
}
Object meth_genc_apply3055(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 962
  setline(962);
// compilenode returning *var_e
// Begin line 963
  setline(963);
// compilenode returning self
  params[0] = *var_e;
  Object call3056 = callmethod(self, "outprint",
    1, params);
// compilenode returning call3056
  return call3056;
}
Object meth_genc_apply3070(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 968
  setline(968);
// compilenode returning *var_l
// Begin line 969
  setline(969);
// compilenode returning self
  params[0] = *var_l;
  Object call3071 = callmethod(self, "out",
    1, params);
// compilenode returning call3071
  return call3071;
}
Object meth_genc_apply3136(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 995
  setline(995);
// compilenode returning *var_x
// Begin line 996
  setline(996);
// compilenode returning self
  params[0] = *var_x;
  Object call3137 = callmethod(self, "outprint",
    1, params);
// compilenode returning call3137
  return call3137;
}
Object meth_genc_apply3143(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 998
  setline(998);
// compilenode returning *var_x
// Begin line 999
  setline(999);
// compilenode returning self
  params[0] = *var_x;
  Object call3144 = callmethod(self, "outprint",
    1, params);
// compilenode returning call3144
  return call3144;
}
Object meth_genc_apply3227(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_fn = alloc_var();
  *var_fn = args[0];
  Object params[1];
  Object *var_cmd = closure[0];
  Object self = *closure[1];
// Begin line 1026
  setline(1026);
// Begin line 1025
  setline(1025);
// compilenode returning *var_cmd
  if (strlit3228 == NULL) {
    strlit3228 = alloc_String(" ");
  }
// compilenode returning strlit3228
  params[0] = strlit3228;
  Object opresult3230 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult3230
// compilenode returning *var_fn
  params[0] = *var_fn;
  Object opresult3232 = callmethod(opresult3230, "++", 1, params);
// compilenode returning opresult3232
  *var_cmd = opresult3232;
  if (opresult3232 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genc_compile2758(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[33];
  Object *var_vl = alloc_var();
  *var_vl = args[0];
  Object *var_of = alloc_var();
  *var_of = args[1];
  Object *var_mn = alloc_var();
  *var_mn = args[2];
  Object *var_rm = alloc_var();
  *var_rm = args[3];
  Object *var_bt = alloc_var();
  *var_bt = args[4];
  Object params[2];
  Object *var_values = closure[0];
  Object *var_outfile = closure[1];
  Object *var_modname = closure[2];
  Object *var_escmodname = closure[3];
  Object *var_runmode = closure[4];
  Object *var_buildtype = closure[5];
  Object *var_staticmodules = closure[6];
  Object *var_output = closure[7];
  Object *var_declaredvars = closure[8];
  Object *var_globals = closure[9];
  Object *var_paramsUsed = closure[10];
  Object *var_topOutput = closure[11];
  Object *var_argv = alloc_var();
  *var_argv = undefined;
  Object *var_cmd = alloc_var();
  *var_cmd = undefined;
  Object *var_linkfiles = alloc_var();
  *var_linkfiles = undefined;
  Object *var_ext = alloc_var();
  *var_ext = undefined;
  Object *var_modn = alloc_var();
  *var_modn = undefined;
  Object *var_tmpo = alloc_var();
  *var_tmpo = undefined;
  Object *var_tmpo2 = alloc_var();
  *var_tmpo2 = undefined;
// Begin line 865
  setline(865);
// Begin line 1035
  setline(1035);
// Begin line 864
  setline(864);
// compilenode returning module_sys
  Object call2759 = callmethod(module_sys, "argv",
    0, params);
// compilenode returning call2759
// compilenode returning call2759
  var_argv = alloc_var();
  *var_argv = call2759;
  if (call2759 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 866
  setline(866);
  var_cmd = alloc_var();
  *var_cmd = undefined;
// compilenode returning nothing
// Begin line 867
  setline(867);
// Begin line 866
  setline(866);
// compilenode returning *var_vl
  *var_values = *var_vl;
  if (*var_vl == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 868
  setline(868);
// Begin line 867
  setline(867);
// compilenode returning *var_of
  *var_outfile = *var_of;
  if (*var_of == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 869
  setline(869);
// Begin line 868
  setline(868);
// compilenode returning *var_mn
  *var_modname = *var_mn;
  if (*var_mn == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 869
  setline(869);
// compilenode returning *var_modname
// Begin line 870
  setline(870);
// compilenode returning self
  params[0] = *var_modname;
  Object call2763 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call2763
  *var_escmodname = call2763;
  if (call2763 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 871
  setline(871);
// Begin line 870
  setline(870);
// compilenode returning *var_rm
  *var_runmode = *var_rm;
  if (*var_rm == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 872
  setline(872);
// Begin line 871
  setline(871);
// compilenode returning *var_bt
  *var_buildtype = *var_bt;
  if (*var_bt == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 873
  setline(873);
  Object array2767 = alloc_List();
// compilenode returning array2767
  var_linkfiles = alloc_var();
  *var_linkfiles = array2767;
  if (array2767 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 874
  setline(874);
// Begin line 873
  setline(873);
  Object bool2768 = alloc_Boolean(0);
// compilenode returning bool2768
  var_ext = alloc_var();
  *var_ext = bool2768;
  if (bool2768 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 920
  setline(920);
// Begin line 925
  setline(925);
// Begin line 874
  setline(874);
// compilenode returning *var_runmode
  if (strlit2770 == NULL) {
    strlit2770 = alloc_String("make");
  }
// compilenode returning strlit2770
  params[0] = strlit2770;
  Object opresult2772 = callmethod(*var_runmode, "==", 1, params);
// compilenode returning opresult2772
  Object if2769;
  if (istrue(opresult2772)) {
// Begin line 875
  setline(875);
  if (strlit2773 == NULL) {
    strlit2773 = alloc_String("checking imports.");
  }
// compilenode returning strlit2773
// Begin line 876
  setline(876);
// compilenode returning self
  params[0] = strlit2773;
  Object call2774 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call2774
// Begin line 920
  setline(920);
// Begin line 876
  setline(876);
// compilenode returning *var_values
// Begin line 920
  setline(920);
// Begin line 1035
  setline(1035);
  Object obj2777 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2777, self, 0);
  addmethod2(obj2777, "outer", &reader_genc_outer_2778);
  adddatum2(obj2777, self, 0);
  block_savedest(obj2777);
  Object **closure2779 = createclosure(6);
  addtoclosure(closure2779, var_linkfiles);
  addtoclosure(closure2779, var_staticmodules);
  addtoclosure(closure2779, var_ext);
  addtoclosure(closure2779, var_argv);
  addtoclosure(closure2779, var_cmd);
  Object *selfpp2916 = alloc_var();
  *selfpp2916 = self;
  addtoclosure(closure2779, selfpp2916);
  struct UserObject *uo2779 = (struct UserObject*)obj2777;
  uo2779->data[1] = (Object)closure2779;
  addmethod2(obj2777, "apply", &meth_genc_apply2779);
  set_type(obj2777, 0);
// compilenode returning obj2777
  setclassname(obj2777, "Block<genc:2776>");
// compilenode returning obj2777
  params[0] = *var_values;
  Object iter2775 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond2775 = callmethod(iter2775, "havemore", 0, NULL);
    if (!istrue(cond2775)) break;
    params[0] = callmethod(iter2775, "next", 0, NULL);
    callmethod(obj2777, "apply", 1, params);
  }
// compilenode returning *var_values
    if2769 = *var_values;
  } else {
  }
// compilenode returning if2769
// Begin line 925
  setline(925);
  if (strlit2917 == NULL) {
    strlit2917 = alloc_String("#include ""\x22""");
  }
// compilenode returning strlit2917
  if (strlit2918 == NULL) {
    strlit2918 = alloc_String(".o");
  }
// compilenode returning strlit2918
  if (strlit2919 == NULL) {
    strlit2919 = alloc_String(".h");
  }
// compilenode returning strlit2919
// Begin line 1035
  setline(1035);
// Begin line 925
  setline(925);
// compilenode returning module_util
  Object call2920 = callmethod(module_util, "gracelibPath",
    0, params);
// compilenode returning call2920
// compilenode returning call2920
  params[0] = strlit2918;
  params[1] = strlit2919;
  Object call2921 = callmethod(call2920, "replace(1)with",
    2, params);
// compilenode returning call2921
  params[0] = call2921;
  Object opresult2923 = callmethod(strlit2917, "++", 1, params);
// compilenode returning opresult2923
  if (strlit2924 == NULL) {
    strlit2924 = alloc_String("""\x22""");
  }
// compilenode returning strlit2924
  params[0] = strlit2924;
  Object opresult2926 = callmethod(opresult2923, "++", 1, params);
// compilenode returning opresult2926
// Begin line 926
  setline(926);
// compilenode returning self
  params[0] = opresult2926;
  Object call2927 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2927
  if (strlit2928 == NULL) {
    strlit2928 = alloc_String("#include <stdlib.h>");
  }
// compilenode returning strlit2928
// Begin line 927
  setline(927);
// compilenode returning self
  params[0] = strlit2928;
  Object call2929 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2929
  if (strlit2930 == NULL) {
    strlit2930 = alloc_String("#pragma weak main");
  }
// compilenode returning strlit2930
// Begin line 928
  setline(928);
// compilenode returning self
  params[0] = strlit2930;
  Object call2931 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2931
  if (strlit2932 == NULL) {
    strlit2932 = alloc_String("static char compilerRevision[] = ""\x22""");
  }
// compilenode returning strlit2932
// Begin line 1035
  setline(1035);
// Begin line 928
  setline(928);
// compilenode returning module_buildinfo
  Object call2933 = callmethod(module_buildinfo, "gitrevision",
    0, params);
// compilenode returning call2933
// compilenode returning call2933
  params[0] = call2933;
  Object opresult2935 = callmethod(strlit2932, "++", 1, params);
// compilenode returning opresult2935
  if (strlit2936 == NULL) {
    strlit2936 = alloc_String("""\x22"";");
  }
// compilenode returning strlit2936
  params[0] = strlit2936;
  Object opresult2938 = callmethod(opresult2935, "++", 1, params);
// compilenode returning opresult2938
// Begin line 929
  setline(929);
// compilenode returning self
  params[0] = opresult2938;
  Object call2939 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2939
  if (strlit2940 == NULL) {
    strlit2940 = alloc_String("static Object undefined;");
  }
// compilenode returning strlit2940
// Begin line 930
  setline(930);
// compilenode returning self
  params[0] = strlit2940;
  Object call2941 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2941
  if (strlit2942 == NULL) {
    strlit2942 = alloc_String("static Object nothing;");
  }
// compilenode returning strlit2942
// Begin line 931
  setline(931);
// compilenode returning self
  params[0] = strlit2942;
  Object call2943 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2943
  if (strlit2944 == NULL) {
    strlit2944 = alloc_String("static Object argv;");
  }
// compilenode returning strlit2944
// Begin line 932
  setline(932);
// compilenode returning self
  params[0] = strlit2944;
  Object call2945 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2945
  if (strlit2946 == NULL) {
    strlit2946 = alloc_String("Object module_");
  }
// compilenode returning strlit2946
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult2948 = callmethod(strlit2946, "++", 1, params);
// compilenode returning opresult2948
  if (strlit2949 == NULL) {
    strlit2949 = alloc_String("_init() {");
  }
// compilenode returning strlit2949
  params[0] = strlit2949;
  Object opresult2951 = callmethod(opresult2948, "++", 1, params);
// compilenode returning opresult2951
// Begin line 933
  setline(933);
// compilenode returning self
  params[0] = opresult2951;
  Object call2952 = callmethod(self, "out",
    1, params);
// compilenode returning call2952
  if (strlit2953 == NULL) {
    strlit2953 = alloc_String("  Object self = alloc_obj2(100, 100);");
  }
// compilenode returning strlit2953
// Begin line 934
  setline(934);
// compilenode returning self
  params[0] = strlit2953;
  Object call2954 = callmethod(self, "out",
    1, params);
// compilenode returning call2954
// Begin line 935
  setline(935);
// Begin line 934
  setline(934);
  if (strlit2955 == NULL) {
    strlit2955 = alloc_String("Module<");
  }
// compilenode returning strlit2955
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult2957 = callmethod(strlit2955, "++", 1, params);
// compilenode returning opresult2957
  if (strlit2958 == NULL) {
    strlit2958 = alloc_String(">");
  }
// compilenode returning strlit2958
  params[0] = strlit2958;
  Object opresult2960 = callmethod(opresult2957, "++", 1, params);
// compilenode returning opresult2960
  var_modn = alloc_var();
  *var_modn = opresult2960;
  if (opresult2960 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 935
  setline(935);
  if (strlit2961 == NULL) {
    strlit2961 = alloc_String("  setclassname(self, ""\x22""");
  }
// compilenode returning strlit2961
// compilenode returning *var_modn
  params[0] = *var_modn;
  Object opresult2963 = callmethod(strlit2961, "++", 1, params);
// compilenode returning opresult2963
  if (strlit2964 == NULL) {
    strlit2964 = alloc_String("""\x22"");");
  }
// compilenode returning strlit2964
  params[0] = strlit2964;
  Object opresult2966 = callmethod(opresult2963, "++", 1, params);
// compilenode returning opresult2966
// Begin line 936
  setline(936);
// compilenode returning self
  params[0] = opresult2966;
  Object call2967 = callmethod(self, "out",
    1, params);
// compilenode returning call2967
  if (strlit2968 == NULL) {
    strlit2968 = alloc_String("  Object *var_HashMap = alloc_var();");
  }
// compilenode returning strlit2968
// Begin line 937
  setline(937);
// compilenode returning self
  params[0] = strlit2968;
  Object call2969 = callmethod(self, "out",
    1, params);
// compilenode returning call2969
  if (strlit2970 == NULL) {
    strlit2970 = alloc_String("  *var_HashMap = alloc_HashMapClassObject();");
  }
// compilenode returning strlit2970
// Begin line 938
  setline(938);
// compilenode returning self
  params[0] = strlit2970;
  Object call2971 = callmethod(self, "out",
    1, params);
// compilenode returning call2971
// Begin line 939
  setline(939);
// Begin line 938
  setline(938);
// compilenode returning *var_output
  var_tmpo = alloc_var();
  *var_tmpo = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 940
  setline(940);
  Object array2972 = alloc_List();
// compilenode returning array2972
  *var_output = array2972;
  if (array2972 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 955
  setline(955);
// Begin line 940
  setline(940);
// compilenode returning *var_values
// Begin line 955
  setline(955);
// Begin line 1035
  setline(1035);
  Object obj2976 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2976, self, 0);
  addmethod2(obj2976, "outer", &reader_genc_outer_2977);
  adddatum2(obj2976, self, 0);
  block_savedest(obj2976);
  Object **closure2978 = createclosure(2);
  addtoclosure(closure2978, var_declaredvars);
  Object *selfpp3043 = alloc_var();
  *selfpp3043 = self;
  addtoclosure(closure2978, selfpp3043);
  struct UserObject *uo2978 = (struct UserObject*)obj2976;
  uo2978->data[1] = (Object)closure2978;
  addmethod2(obj2976, "apply", &meth_genc_apply2978);
  set_type(obj2976, 0);
// compilenode returning obj2976
  setclassname(obj2976, "Block<genc:2975>");
// compilenode returning obj2976
  params[0] = *var_values;
  Object iter2974 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond2974 = callmethod(iter2974, "havemore", 0, NULL);
    if (!istrue(cond2974)) break;
    params[0] = callmethod(iter2974, "next", 0, NULL);
    callmethod(obj2976, "apply", 1, params);
  }
// compilenode returning *var_values
// Begin line 959
  setline(959);
// Begin line 958
  setline(958);
// compilenode returning *var_values
// Begin line 959
  setline(959);
// Begin line 1035
  setline(1035);
  Object obj3046 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3046, self, 0);
  addmethod2(obj3046, "outer", &reader_genc_outer_3047);
  adddatum2(obj3046, self, 0);
  block_savedest(obj3046);
  Object **closure3048 = createclosure(1);
  Object *selfpp3050 = alloc_var();
  *selfpp3050 = self;
  addtoclosure(closure3048, selfpp3050);
  struct UserObject *uo3048 = (struct UserObject*)obj3046;
  uo3048->data[1] = (Object)closure3048;
  addmethod2(obj3046, "apply", &meth_genc_apply3048);
  set_type(obj3046, 0);
// compilenode returning obj3046
  setclassname(obj3046, "Block<genc:3045>");
// compilenode returning obj3046
  params[0] = *var_values;
  Object iter3044 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond3044 = callmethod(iter3044, "havemore", 0, NULL);
    if (!istrue(cond3044)) break;
    params[0] = callmethod(iter3044, "next", 0, NULL);
    callmethod(obj3046, "apply", 1, params);
  }
// compilenode returning *var_values
// Begin line 962
  setline(962);
// Begin line 961
  setline(961);
// compilenode returning *var_globals
// Begin line 962
  setline(962);
// Begin line 1035
  setline(1035);
  Object obj3053 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3053, self, 0);
  addmethod2(obj3053, "outer", &reader_genc_outer_3054);
  adddatum2(obj3053, self, 0);
  block_savedest(obj3053);
  Object **closure3055 = createclosure(1);
  Object *selfpp3057 = alloc_var();
  *selfpp3057 = self;
  addtoclosure(closure3055, selfpp3057);
  struct UserObject *uo3055 = (struct UserObject*)obj3053;
  uo3055->data[1] = (Object)closure3055;
  addmethod2(obj3053, "apply", &meth_genc_apply3055);
  set_type(obj3053, 0);
// compilenode returning obj3053
  setclassname(obj3053, "Block<genc:3052>");
// compilenode returning obj3053
  params[0] = *var_globals;
  Object iter3051 = callmethod(*var_globals, "iter", 1, params);
  while(1) {
    Object cond3051 = callmethod(iter3051, "havemore", 0, NULL);
    if (!istrue(cond3051)) break;
    params[0] = callmethod(iter3051, "next", 0, NULL);
    callmethod(obj3053, "apply", 1, params);
  }
// compilenode returning *var_globals
// Begin line 965
  setline(965);
// Begin line 964
  setline(964);
// compilenode returning *var_output
  var_tmpo2 = alloc_var();
  *var_tmpo2 = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 966
  setline(966);
// Begin line 965
  setline(965);
// compilenode returning *var_tmpo
  *var_output = *var_tmpo;
  if (*var_tmpo == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 966
  setline(966);
  if (strlit3059 == NULL) {
    strlit3059 = alloc_String("  Object params[");
  }
// compilenode returning strlit3059
// compilenode returning *var_paramsUsed
  params[0] = *var_paramsUsed;
  Object opresult3061 = callmethod(strlit3059, "++", 1, params);
// compilenode returning opresult3061
  if (strlit3062 == NULL) {
    strlit3062 = alloc_String("];");
  }
// compilenode returning strlit3062
  params[0] = strlit3062;
  Object opresult3064 = callmethod(opresult3061, "++", 1, params);
// compilenode returning opresult3064
// Begin line 967
  setline(967);
// compilenode returning self
  params[0] = opresult3064;
  Object call3065 = callmethod(self, "out",
    1, params);
// compilenode returning call3065
// Begin line 968
  setline(968);
// Begin line 967
  setline(967);
// compilenode returning *var_tmpo2
// Begin line 968
  setline(968);
// Begin line 1035
  setline(1035);
  Object obj3068 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3068, self, 0);
  addmethod2(obj3068, "outer", &reader_genc_outer_3069);
  adddatum2(obj3068, self, 0);
  block_savedest(obj3068);
  Object **closure3070 = createclosure(1);
  Object *selfpp3072 = alloc_var();
  *selfpp3072 = self;
  addtoclosure(closure3070, selfpp3072);
  struct UserObject *uo3070 = (struct UserObject*)obj3068;
  uo3070->data[1] = (Object)closure3070;
  addmethod2(obj3068, "apply", &meth_genc_apply3070);
  set_type(obj3068, 0);
// compilenode returning obj3068
  setclassname(obj3068, "Block<genc:3067>");
// compilenode returning obj3068
  params[0] = *var_tmpo2;
  Object iter3066 = callmethod(*var_tmpo2, "iter", 1, params);
  while(1) {
    Object cond3066 = callmethod(iter3066, "havemore", 0, NULL);
    if (!istrue(cond3066)) break;
    params[0] = callmethod(iter3066, "next", 0, NULL);
    callmethod(obj3068, "apply", 1, params);
  }
// compilenode returning *var_tmpo2
// Begin line 971
  setline(971);
// Begin line 970
  setline(970);
  Object num3073 = alloc_Float64(1.0);
// compilenode returning num3073
  *var_paramsUsed = num3073;
  if (num3073 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 971
  setline(971);
  if (strlit3075 == NULL) {
    strlit3075 = alloc_String("  return self;");
  }
// compilenode returning strlit3075
// Begin line 972
  setline(972);
// compilenode returning self
  params[0] = strlit3075;
  Object call3076 = callmethod(self, "out",
    1, params);
// compilenode returning call3076
  if (strlit3077 == NULL) {
    strlit3077 = alloc_String("}");
  }
// compilenode returning strlit3077
// Begin line 973
  setline(973);
// compilenode returning self
  params[0] = strlit3077;
  Object call3078 = callmethod(self, "out",
    1, params);
// compilenode returning call3078
  if (strlit3079 == NULL) {
    strlit3079 = alloc_String("int main(int argc, char **argv) {");
  }
// compilenode returning strlit3079
// Begin line 974
  setline(974);
// compilenode returning self
  params[0] = strlit3079;
  Object call3080 = callmethod(self, "out",
    1, params);
// compilenode returning call3080
  if (strlit3081 == NULL) {
    strlit3081 = alloc_String("  initprofiling();");
  }
// compilenode returning strlit3081
// Begin line 975
  setline(975);
// compilenode returning self
  params[0] = strlit3081;
  Object call3082 = callmethod(self, "out",
    1, params);
// compilenode returning call3082
// Begin line 977
  setline(977);
// Begin line 975
  setline(975);
  if (strlit3084 == NULL) {
    strlit3084 = alloc_String("LogCallGraph");
  }
// compilenode returning strlit3084
// Begin line 979
  setline(979);
// Begin line 1035
  setline(1035);
// Begin line 975
  setline(975);
// compilenode returning module_util
  Object call3085 = callmethod(module_util, "extensions",
    0, params);
// compilenode returning call3085
// compilenode returning call3085
  params[0] = strlit3084;
  Object call3086 = callmethod(call3085, "contains",
    1, params);
// compilenode returning call3086
  Object if3083;
  if (istrue(call3086)) {
  Object *var_lcgfile = alloc_var();
  *var_lcgfile = undefined;
// Begin line 976
  setline(976);
  if (strlit3087 == NULL) {
    strlit3087 = alloc_String("LogCallGraph");
  }
// compilenode returning strlit3087
// Begin line 977
  setline(977);
// Begin line 1035
  setline(1035);
// Begin line 976
  setline(976);
// compilenode returning module_util
  Object call3088 = callmethod(module_util, "extensions",
    0, params);
// compilenode returning call3088
// compilenode returning call3088
  params[0] = strlit3087;
  Object call3089 = callmethod(call3088, "get",
    1, params);
// compilenode returning call3089
  var_lcgfile = alloc_var();
  *var_lcgfile = call3089;
  if (call3089 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 977
  setline(977);
  if (strlit3090 == NULL) {
    strlit3090 = alloc_String("  enable_callgraph(""\x22""");
  }
// compilenode returning strlit3090
// compilenode returning *var_lcgfile
  params[0] = *var_lcgfile;
  Object opresult3092 = callmethod(strlit3090, "++", 1, params);
// compilenode returning opresult3092
  if (strlit3093 == NULL) {
    strlit3093 = alloc_String("""\x22"");");
  }
// compilenode returning strlit3093
  params[0] = strlit3093;
  Object opresult3095 = callmethod(opresult3092, "++", 1, params);
// compilenode returning opresult3095
// Begin line 978
  setline(978);
// compilenode returning self
  params[0] = opresult3095;
  Object call3096 = callmethod(self, "out",
    1, params);
// compilenode returning call3096
    if3083 = call3096;
  } else {
  }
// compilenode returning if3083
// Begin line 979
  setline(979);
  if (strlit3097 == NULL) {
    strlit3097 = alloc_String("  gracelib_argv(argv);");
  }
// compilenode returning strlit3097
// Begin line 980
  setline(980);
// compilenode returning self
  params[0] = strlit3097;
  Object call3098 = callmethod(self, "out",
    1, params);
// compilenode returning call3098
  if (strlit3099 == NULL) {
    strlit3099 = alloc_String("  Object params[1];");
  }
// compilenode returning strlit3099
// Begin line 981
  setline(981);
// compilenode returning self
  params[0] = strlit3099;
  Object call3100 = callmethod(self, "out",
    1, params);
// compilenode returning call3100
  if (strlit3101 == NULL) {
    strlit3101 = alloc_String("  undefined = alloc_Undefined();");
  }
// compilenode returning strlit3101
// Begin line 982
  setline(982);
// compilenode returning self
  params[0] = strlit3101;
  Object call3102 = callmethod(self, "out",
    1, params);
// compilenode returning call3102
  if (strlit3103 == NULL) {
    strlit3103 = alloc_String("  nothing = alloc_Nothing();");
  }
// compilenode returning strlit3103
// Begin line 983
  setline(983);
// compilenode returning self
  params[0] = strlit3103;
  Object call3104 = callmethod(self, "out",
    1, params);
// compilenode returning call3104
  if (strlit3105 == NULL) {
    strlit3105 = alloc_String("  Object tmp_argv = alloc_List();");
  }
// compilenode returning strlit3105
// Begin line 984
  setline(984);
// compilenode returning self
  params[0] = strlit3105;
  Object call3106 = callmethod(self, "out",
    1, params);
// compilenode returning call3106
  if (strlit3107 == NULL) {
    strlit3107 = alloc_String("  int i; for (i=0; i<argc; i++) {");
  }
// compilenode returning strlit3107
// Begin line 985
  setline(985);
// compilenode returning self
  params[0] = strlit3107;
  Object call3108 = callmethod(self, "out",
    1, params);
// compilenode returning call3108
  if (strlit3109 == NULL) {
    strlit3109 = alloc_String("    params[0] = alloc_String(argv[i]);");
  }
// compilenode returning strlit3109
// Begin line 986
  setline(986);
// compilenode returning self
  params[0] = strlit3109;
  Object call3110 = callmethod(self, "out",
    1, params);
// compilenode returning call3110
  if (strlit3111 == NULL) {
    strlit3111 = alloc_String("    callmethod(tmp_argv, ""\x22""push""\x22"", 1,params);");
  }
// compilenode returning strlit3111
// Begin line 987
  setline(987);
// compilenode returning self
  params[0] = strlit3111;
  Object call3112 = callmethod(self, "out",
    1, params);
// compilenode returning call3112
  if (strlit3113 == NULL) {
    strlit3113 = alloc_String("  }");
  }
// compilenode returning strlit3113
// Begin line 988
  setline(988);
// compilenode returning self
  params[0] = strlit3113;
  Object call3114 = callmethod(self, "out",
    1, params);
// compilenode returning call3114
  if (strlit3115 == NULL) {
    strlit3115 = alloc_String("  module_sys_init_argv(tmp_argv);");
  }
// compilenode returning strlit3115
// Begin line 989
  setline(989);
// compilenode returning self
  params[0] = strlit3115;
  Object call3116 = callmethod(self, "out",
    1, params);
// compilenode returning call3116
  if (strlit3117 == NULL) {
    strlit3117 = alloc_String("  module_");
  }
// compilenode returning strlit3117
// compilenode returning *var_escmodname
  params[0] = *var_escmodname;
  Object opresult3119 = callmethod(strlit3117, "++", 1, params);
// compilenode returning opresult3119
  if (strlit3120 == NULL) {
    strlit3120 = alloc_String("_init();");
  }
// compilenode returning strlit3120
  params[0] = strlit3120;
  Object opresult3122 = callmethod(opresult3119, "++", 1, params);
// compilenode returning opresult3122
// Begin line 990
  setline(990);
// compilenode returning self
  params[0] = opresult3122;
  Object call3123 = callmethod(self, "out",
    1, params);
// compilenode returning call3123
  if (strlit3124 == NULL) {
    strlit3124 = alloc_String("  gracelib_stats();");
  }
// compilenode returning strlit3124
// Begin line 991
  setline(991);
// compilenode returning self
  params[0] = strlit3124;
  Object call3125 = callmethod(self, "out",
    1, params);
// compilenode returning call3125
  if (strlit3126 == NULL) {
    strlit3126 = alloc_String("  return 0;");
  }
// compilenode returning strlit3126
// Begin line 992
  setline(992);
// compilenode returning self
  params[0] = strlit3126;
  Object call3127 = callmethod(self, "out",
    1, params);
// compilenode returning call3127
  if (strlit3128 == NULL) {
    strlit3128 = alloc_String("}");
  }
// compilenode returning strlit3128
// Begin line 993
  setline(993);
// compilenode returning self
  params[0] = strlit3128;
  Object call3129 = callmethod(self, "out",
    1, params);
// compilenode returning call3129
  if (strlit3130 == NULL) {
    strlit3130 = alloc_String("writing file.");
  }
// compilenode returning strlit3130
// Begin line 994
  setline(994);
// compilenode returning self
  params[0] = strlit3130;
  Object call3131 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call3131
// Begin line 995
  setline(995);
// Begin line 994
  setline(994);
// compilenode returning *var_topOutput
// Begin line 995
  setline(995);
// Begin line 1035
  setline(1035);
  Object obj3134 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3134, self, 0);
  addmethod2(obj3134, "outer", &reader_genc_outer_3135);
  adddatum2(obj3134, self, 0);
  block_savedest(obj3134);
  Object **closure3136 = createclosure(1);
  Object *selfpp3138 = alloc_var();
  *selfpp3138 = self;
  addtoclosure(closure3136, selfpp3138);
  struct UserObject *uo3136 = (struct UserObject*)obj3134;
  uo3136->data[1] = (Object)closure3136;
  addmethod2(obj3134, "apply", &meth_genc_apply3136);
  set_type(obj3134, 0);
// compilenode returning obj3134
  setclassname(obj3134, "Block<genc:3133>");
// compilenode returning obj3134
  params[0] = *var_topOutput;
  Object iter3132 = callmethod(*var_topOutput, "iter", 1, params);
  while(1) {
    Object cond3132 = callmethod(iter3132, "havemore", 0, NULL);
    if (!istrue(cond3132)) break;
    params[0] = callmethod(iter3132, "next", 0, NULL);
    callmethod(obj3134, "apply", 1, params);
  }
// compilenode returning *var_topOutput
// Begin line 998
  setline(998);
// Begin line 997
  setline(997);
// compilenode returning *var_output
// Begin line 998
  setline(998);
// Begin line 1035
  setline(1035);
  Object obj3141 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3141, self, 0);
  addmethod2(obj3141, "outer", &reader_genc_outer_3142);
  adddatum2(obj3141, self, 0);
  block_savedest(obj3141);
  Object **closure3143 = createclosure(1);
  Object *selfpp3145 = alloc_var();
  *selfpp3145 = self;
  addtoclosure(closure3143, selfpp3145);
  struct UserObject *uo3143 = (struct UserObject*)obj3141;
  uo3143->data[1] = (Object)closure3143;
  addmethod2(obj3141, "apply", &meth_genc_apply3143);
  set_type(obj3141, 0);
// compilenode returning obj3141
  setclassname(obj3141, "Block<genc:3140>");
// compilenode returning obj3141
  params[0] = *var_output;
  Object iter3139 = callmethod(*var_output, "iter", 1, params);
  while(1) {
    Object cond3139 = callmethod(iter3139, "havemore", 0, NULL);
    if (!istrue(cond3139)) break;
    params[0] = callmethod(iter3139, "next", 0, NULL);
    callmethod(obj3141, "apply", 1, params);
  }
// compilenode returning *var_output
// Begin line 1035
  setline(1035);
// Begin line 1038
  setline(1038);
// Begin line 1001
  setline(1001);
// compilenode returning *var_runmode
  if (strlit3147 == NULL) {
    strlit3147 = alloc_String("make");
  }
// compilenode returning strlit3147
  params[0] = strlit3147;
  Object opresult3149 = callmethod(*var_runmode, "==", 1, params);
// compilenode returning opresult3149
  Object if3146;
  if (istrue(opresult3149)) {
// Begin line 1002
  setline(1002);
  if (strlit3150 == NULL) {
    strlit3150 = alloc_String("compiling C code.");
  }
// compilenode returning strlit3150
// Begin line 1003
  setline(1003);
// compilenode returning self
  params[0] = strlit3150;
  Object call3151 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call3151
// Begin line 1035
  setline(1035);
// Begin line 1003
  setline(1003);
// compilenode returning *var_outfile
  Object call3152 = callmethod(*var_outfile, "close",
    0, params);
// compilenode returning call3152
// compilenode returning call3152
// Begin line 1005
  setline(1005);
// Begin line 1004
  setline(1004);
  if (strlit3153 == NULL) {
    strlit3153 = alloc_String("gcc -o ");
  }
// compilenode returning strlit3153
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult3155 = callmethod(strlit3153, "++", 1, params);
// compilenode returning opresult3155
  if (strlit3156 == NULL) {
    strlit3156 = alloc_String(".gcn -c ");
  }
// compilenode returning strlit3156
  params[0] = strlit3156;
  Object opresult3158 = callmethod(opresult3155, "++", 1, params);
// compilenode returning opresult3158
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult3160 = callmethod(opresult3158, "++", 1, params);
// compilenode returning opresult3160
  if (strlit3161 == NULL) {
    strlit3161 = alloc_String(".c");
  }
// compilenode returning strlit3161
  params[0] = strlit3161;
  Object opresult3163 = callmethod(opresult3160, "++", 1, params);
// compilenode returning opresult3163
  *var_cmd = opresult3163;
  if (opresult3163 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1007
  setline(1007);
// Begin line 1005
  setline(1005);
// Begin line 1035
  setline(1035);
// Begin line 1005
  setline(1005);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call3166 = callmethod(module_io, "system",
    1, params);
// compilenode returning call3166
  Object call3167 = callmethod(call3166, "not",
    0, params);
// compilenode returning call3167
// compilenode returning call3167
  Object if3165;
  if (istrue(call3167)) {
// Begin line 1006
  setline(1006);
  if (strlit3168 == NULL) {
    strlit3168 = alloc_String("Failed C compilation");
  }
// compilenode returning strlit3168
// Begin line 1007
  setline(1007);
// Begin line 1035
  setline(1035);
// Begin line 1006
  setline(1006);
// compilenode returning module_io
  Object call3169 = callmethod(module_io, "error",
    0, params);
// compilenode returning call3169
// compilenode returning call3169
  params[0] = strlit3168;
  Object call3170 = callmethod(call3169, "write",
    1, params);
// compilenode returning call3170
// Begin line 1007
  setline(1007);
  if (strlit3171 == NULL) {
    strlit3171 = alloc_String("Fatal.");
  }
// compilenode returning strlit3171
  params[0] = strlit3171;
  Object call3172 = callmethod(self, "raise",
    1, params);
// compilenode returning call3172
    if3165 = call3172;
  } else {
  }
// compilenode returning if3165
// Begin line 1029
  setline(1029);
// Begin line 1032
  setline(1032);
// Begin line 1035
  setline(1035);
// Begin line 1032
  setline(1032);
// Begin line 1035
  setline(1035);
// Begin line 1009
  setline(1009);
// compilenode returning module_util
  Object call3174 = callmethod(module_util, "noexec",
    0, params);
// compilenode returning call3174
// compilenode returning call3174
  Object call3175 = callmethod(call3174, "not",
    0, params);
// compilenode returning call3175
// compilenode returning call3175
  Object if3173;
  if (istrue(call3175)) {
  Object *var_dlbit = alloc_var();
  *var_dlbit = undefined;
  Object *var_exportDynamicBit = alloc_var();
  *var_exportDynamicBit = undefined;
// Begin line 1010
  setline(1010);
  if (strlit3176 == NULL) {
    strlit3176 = alloc_String("linking.");
  }
// compilenode returning strlit3176
// Begin line 1011
  setline(1011);
// compilenode returning self
  params[0] = strlit3176;
  Object call3177 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call3177
// Begin line 1012
  setline(1012);
// Begin line 1011
  setline(1011);
  if (strlit3178 == NULL) {
    strlit3178 = alloc_String("");
  }
// compilenode returning strlit3178
  var_dlbit = alloc_var();
  *var_dlbit = strlit3178;
  if (strlit3178 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1013
  setline(1013);
// Begin line 1012
  setline(1012);
  if (strlit3179 == NULL) {
    strlit3179 = alloc_String("");
  }
// compilenode returning strlit3179
  var_exportDynamicBit = alloc_var();
  *var_exportDynamicBit = strlit3179;
  if (strlit3179 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1014
  setline(1014);
// Begin line 1013
  setline(1013);
  if (strlit3180 == NULL) {
    strlit3180 = alloc_String("ld -ldl -o /dev/null 2>/dev/null");
  }
// compilenode returning strlit3180
  *var_cmd = strlit3180;
  if (strlit3180 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1016
  setline(1016);
// Begin line 1014
  setline(1014);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call3183 = callmethod(module_io, "system",
    1, params);
// compilenode returning call3183
  Object if3182;
  if (istrue(call3183)) {
// Begin line 1016
  setline(1016);
// Begin line 1015
  setline(1015);
  if (strlit3184 == NULL) {
    strlit3184 = alloc_String("-ldl");
  }
// compilenode returning strlit3184
  *var_dlbit = strlit3184;
  if (strlit3184 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3182 = nothing;
  } else {
  }
// compilenode returning if3182
// Begin line 1018
  setline(1018);
// Begin line 1017
  setline(1017);
  if (strlit3186 == NULL) {
    strlit3186 = alloc_String("ld -o /dev/null --export-dynamic -lc >/dev/null 2>&1");
  }
// compilenode returning strlit3186
  *var_cmd = strlit3186;
  if (strlit3186 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1020
  setline(1020);
// Begin line 1018
  setline(1018);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call3189 = callmethod(module_io, "system",
    1, params);
// compilenode returning call3189
  Object if3188;
  if (istrue(call3189)) {
// Begin line 1020
  setline(1020);
// Begin line 1019
  setline(1019);
  if (strlit3190 == NULL) {
    strlit3190 = alloc_String("-Wl,--export-dynamic");
  }
// compilenode returning strlit3190
  *var_exportDynamicBit = strlit3190;
  if (strlit3190 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3188 = nothing;
  } else {
  }
// compilenode returning if3188
// Begin line 1024
  setline(1024);
// Begin line 1021
  setline(1021);
  if (strlit3192 == NULL) {
    strlit3192 = alloc_String("gcc -o ");
  }
// compilenode returning strlit3192
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult3194 = callmethod(strlit3192, "++", 1, params);
// compilenode returning opresult3194
  if (strlit3195 == NULL) {
    strlit3195 = alloc_String(" -fPIC ");
  }
// compilenode returning strlit3195
  params[0] = strlit3195;
  Object opresult3197 = callmethod(opresult3194, "++", 1, params);
// compilenode returning opresult3197
// compilenode returning *var_exportDynamicBit
  params[0] = *var_exportDynamicBit;
  Object opresult3199 = callmethod(opresult3197, "++", 1, params);
// compilenode returning opresult3199
  if (strlit3200 == NULL) {
    strlit3200 = alloc_String(" ");
  }
// compilenode returning strlit3200
  params[0] = strlit3200;
  Object opresult3202 = callmethod(opresult3199, "++", 1, params);
// compilenode returning opresult3202
// compilenode returning *var_dlbit
  params[0] = *var_dlbit;
  Object opresult3204 = callmethod(opresult3202, "++", 1, params);
// compilenode returning opresult3204
  if (strlit3205 == NULL) {
    strlit3205 = alloc_String(" ");
  }
// compilenode returning strlit3205
  params[0] = strlit3205;
  Object opresult3207 = callmethod(opresult3204, "++", 1, params);
// compilenode returning opresult3207
// Begin line 1024
  setline(1024);
// Begin line 1022
  setline(1022);
  if (strlit3208 == NULL) {
    strlit3208 = alloc_String("");
  }
// compilenode returning strlit3208
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult3210 = callmethod(strlit3208, "++", 1, params);
// compilenode returning opresult3210
  if (strlit3211 == NULL) {
    strlit3211 = alloc_String(".gcn ");
  }
// compilenode returning strlit3211
  params[0] = strlit3211;
  Object opresult3213 = callmethod(opresult3210, "++", 1, params);
// compilenode returning opresult3213
  params[0] = opresult3213;
  Object opresult3215 = callmethod(opresult3207, "++", 1, params);
// compilenode returning opresult3215
// Begin line 1024
  setline(1024);
// Begin line 1035
  setline(1035);
// Begin line 1023
  setline(1023);
// compilenode returning module_util
  Object call3216 = callmethod(module_util, "gracelibPath",
    0, params);
// compilenode returning call3216
// compilenode returning call3216
  params[0] = call3216;
  Object opresult3218 = callmethod(opresult3215, "++", 1, params);
// compilenode returning opresult3218
  if (strlit3219 == NULL) {
    strlit3219 = alloc_String(" ");
  }
// compilenode returning strlit3219
  params[0] = strlit3219;
  Object opresult3221 = callmethod(opresult3218, "++", 1, params);
// compilenode returning opresult3221
  *var_cmd = opresult3221;
  if (opresult3221 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1026
  setline(1026);
// Begin line 1024
  setline(1024);
// compilenode returning *var_linkfiles
// Begin line 1026
  setline(1026);
// Begin line 1035
  setline(1035);
  Object obj3225 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3225, self, 0);
  addmethod2(obj3225, "outer", &reader_genc_outer_3226);
  adddatum2(obj3225, self, 0);
  block_savedest(obj3225);
  Object **closure3227 = createclosure(2);
  addtoclosure(closure3227, var_cmd);
  Object *selfpp3234 = alloc_var();
  *selfpp3234 = self;
  addtoclosure(closure3227, selfpp3234);
  struct UserObject *uo3227 = (struct UserObject*)obj3225;
  uo3227->data[1] = (Object)closure3227;
  addmethod2(obj3225, "apply", &meth_genc_apply3227);
  set_type(obj3225, 0);
// compilenode returning obj3225
  setclassname(obj3225, "Block<genc:3224>");
// compilenode returning obj3225
  params[0] = *var_linkfiles;
  Object iter3223 = callmethod(*var_linkfiles, "iter", 1, params);
  while(1) {
    Object cond3223 = callmethod(iter3223, "havemore", 0, NULL);
    if (!istrue(cond3223)) break;
    params[0] = callmethod(iter3223, "next", 0, NULL);
    callmethod(obj3225, "apply", 1, params);
  }
// compilenode returning *var_linkfiles
// Begin line 1029
  setline(1029);
// Begin line 1027
  setline(1027);
// Begin line 1035
  setline(1035);
// Begin line 1027
  setline(1027);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call3236 = callmethod(module_io, "system",
    1, params);
// compilenode returning call3236
  Object call3237 = callmethod(call3236, "not",
    0, params);
// compilenode returning call3237
// compilenode returning call3237
  Object if3235;
  if (istrue(call3237)) {
// Begin line 1028
  setline(1028);
  if (strlit3238 == NULL) {
    strlit3238 = alloc_String("Failed linking");
  }
// compilenode returning strlit3238
// Begin line 1029
  setline(1029);
// Begin line 1035
  setline(1035);
// Begin line 1028
  setline(1028);
// compilenode returning module_io
  Object call3239 = callmethod(module_io, "error",
    0, params);
// compilenode returning call3239
// compilenode returning call3239
  params[0] = strlit3238;
  Object call3240 = callmethod(call3239, "write",
    1, params);
// compilenode returning call3240
// Begin line 1029
  setline(1029);
  if (strlit3241 == NULL) {
    strlit3241 = alloc_String("Fatal.");
  }
// compilenode returning strlit3241
  params[0] = strlit3241;
  Object call3242 = callmethod(self, "raise",
    1, params);
// compilenode returning call3242
    if3235 = call3242;
  } else {
  }
// compilenode returning if3235
    if3173 = if3235;
  } else {
  }
// compilenode returning if3173
// Begin line 1032
  setline(1032);
  if (strlit3243 == NULL) {
    strlit3243 = alloc_String("done.");
  }
// compilenode returning strlit3243
// Begin line 1033
  setline(1033);
// compilenode returning self
  params[0] = strlit3243;
  Object call3244 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call3244
// Begin line 1035
  setline(1035);
// Begin line 1037
  setline(1037);
// Begin line 1033
  setline(1033);
// compilenode returning *var_buildtype
  if (strlit3246 == NULL) {
    strlit3246 = alloc_String("run");
  }
// compilenode returning strlit3246
  params[0] = strlit3246;
  Object opresult3248 = callmethod(*var_buildtype, "==", 1, params);
// compilenode returning opresult3248
  Object if3245;
  if (istrue(opresult3248)) {
// Begin line 1035
  setline(1035);
// Begin line 1034
  setline(1034);
  if (strlit3249 == NULL) {
    strlit3249 = alloc_String("./");
  }
// compilenode returning strlit3249
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult3251 = callmethod(strlit3249, "++", 1, params);
// compilenode returning opresult3251
  *var_cmd = opresult3251;
  if (opresult3251 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1035
  setline(1035);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call3253 = callmethod(module_io, "system",
    1, params);
// compilenode returning call3253
    if3245 = call3253;
  } else {
  }
// compilenode returning if3245
    if3146 = if3245;
  } else {
  }
// compilenode returning if3146
  return if3146;
}
Object module_genc_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<genc>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_verbosity = alloc_var();
  *var_verbosity = undefined;
  Object *var_pad1 = alloc_var();
  *var_pad1 = undefined;
  Object *var_auto_count = alloc_var();
  *var_auto_count = undefined;
  Object *var_constants = alloc_var();
  *var_constants = undefined;
  Object *var_globals = alloc_var();
  *var_globals = undefined;
  Object *var_output = alloc_var();
  *var_output = undefined;
  Object *var_usedvars = alloc_var();
  *var_usedvars = undefined;
  Object *var_declaredvars = alloc_var();
  *var_declaredvars = undefined;
  Object *var_bblock = alloc_var();
  *var_bblock = undefined;
  Object *var_linenum = alloc_var();
  *var_linenum = undefined;
  Object *var_modules = alloc_var();
  *var_modules = undefined;
  Object *var_staticmodules = alloc_var();
  *var_staticmodules = undefined;
  Object *var_values = alloc_var();
  *var_values = undefined;
  Object *var_outfile = alloc_var();
  *var_outfile = undefined;
  Object *var_modname = alloc_var();
  *var_modname = undefined;
  Object *var_escmodname = alloc_var();
  *var_escmodname = undefined;
  Object *var_runmode = alloc_var();
  *var_runmode = undefined;
  Object *var_buildtype = alloc_var();
  *var_buildtype = undefined;
  Object *var_gracelibPath = alloc_var();
  *var_gracelibPath = undefined;
  Object *var_inBlock = alloc_var();
  *var_inBlock = undefined;
  Object *var_paramsUsed = alloc_var();
  *var_paramsUsed = undefined;
  Object *var_topLevelMethodPos = alloc_var();
  *var_topLevelMethodPos = undefined;
  Object *var_topOutput = alloc_var();
  *var_topOutput = undefined;
  Object *var_bottomOutput = alloc_var();
  *var_bottomOutput = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of sys
  if (module_sys == NULL)
    module_sys = module_sys_init();
  Object *var_sys = alloc_var();
  *var_sys = module_sys;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of ast
  if (module_ast == NULL)
    module_ast = module_ast_init();
  Object *var_ast = alloc_var();
  *var_ast = module_ast;
// compilenode returning undefined
// Begin line 5
  setline(5);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Import of buildinfo
  if (module_buildinfo == NULL)
    module_buildinfo = module_buildinfo_init();
  Object *var_buildinfo = alloc_var();
  *var_buildinfo = module_buildinfo;
// compilenode returning undefined
// Begin line 14
  setline(14);
// Import of subtype
  if (module_subtype == NULL)
    module_subtype = module_subtype_init();
  Object *var_subtype = alloc_var();
  *var_subtype = module_subtype;
// compilenode returning undefined
// Begin line 15
  setline(15);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 16
  setline(16);
// Begin line 15
  setline(15);
  Object num6 = alloc_Float64(30.0);
// compilenode returning num6
  var_verbosity = alloc_var();
  *var_verbosity = num6;
  if (num6 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 17
  setline(17);
// Begin line 16
  setline(16);
  Object num7 = alloc_Float64(1.0);
// compilenode returning num7
  var_pad1 = alloc_var();
  *var_pad1 = num7;
  if (num7 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 18
  setline(18);
// Begin line 17
  setline(17);
  Object num8 = alloc_Float64(0.0);
// compilenode returning num8
  var_auto_count = alloc_var();
  *var_auto_count = num8;
  if (num8 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 19
  setline(19);
  Object array9 = alloc_List();
// compilenode returning array9
  var_constants = alloc_var();
  *var_constants = array9;
  if (array9 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 20
  setline(20);
  Object array10 = alloc_List();
// compilenode returning array10
  var_globals = alloc_var();
  *var_globals = array10;
  if (array10 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 21
  setline(21);
  Object array11 = alloc_List();
// compilenode returning array11
  var_output = alloc_var();
  *var_output = array11;
  if (array11 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 22
  setline(22);
  Object array12 = alloc_List();
// compilenode returning array12
  var_usedvars = alloc_var();
  *var_usedvars = array12;
  if (array12 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 23
  setline(23);
  Object array13 = alloc_List();
// compilenode returning array13
  var_declaredvars = alloc_var();
  *var_declaredvars = array13;
  if (array13 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 24
  setline(24);
// Begin line 23
  setline(23);
  if (strlit14 == NULL) {
    strlit14 = alloc_String("entry");
  }
// compilenode returning strlit14
  var_bblock = alloc_var();
  *var_bblock = strlit14;
  if (strlit14 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 25
  setline(25);
// Begin line 24
  setline(24);
  Object num15 = alloc_Float64(1.0);
// compilenode returning num15
  var_linenum = alloc_var();
  *var_linenum = num15;
  if (num15 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 26
  setline(26);
  Object array16 = alloc_List();
// compilenode returning array16
  var_modules = alloc_var();
  *var_modules = array16;
  if (array16 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 27
  setline(27);
  Object array17 = alloc_List();
// compilenode returning array17
  var_staticmodules = alloc_var();
  *var_staticmodules = array17;
  if (array17 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 28
  setline(28);
  Object array18 = alloc_List();
// compilenode returning array18
  var_values = alloc_var();
  *var_values = array18;
  if (array18 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 29
  setline(29);
  var_outfile = alloc_var();
  *var_outfile = undefined;
// compilenode returning nothing
// Begin line 30
  setline(30);
// Begin line 29
  setline(29);
  if (strlit19 == NULL) {
    strlit19 = alloc_String("main");
  }
// compilenode returning strlit19
  var_modname = alloc_var();
  *var_modname = strlit19;
  if (strlit19 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 31
  setline(31);
// Begin line 30
  setline(30);
  if (strlit20 == NULL) {
    strlit20 = alloc_String("main");
  }
// compilenode returning strlit20
  var_escmodname = alloc_var();
  *var_escmodname = strlit20;
  if (strlit20 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 32
  setline(32);
// Begin line 31
  setline(31);
  if (strlit21 == NULL) {
    strlit21 = alloc_String("build");
  }
// compilenode returning strlit21
  var_runmode = alloc_var();
  *var_runmode = strlit21;
  if (strlit21 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 33
  setline(33);
// Begin line 32
  setline(32);
  if (strlit22 == NULL) {
    strlit22 = alloc_String("bc");
  }
// compilenode returning strlit22
  var_buildtype = alloc_var();
  *var_buildtype = strlit22;
  if (strlit22 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 34
  setline(34);
// Begin line 33
  setline(33);
  if (strlit23 == NULL) {
    strlit23 = alloc_String("gracelib.o");
  }
// compilenode returning strlit23
  var_gracelibPath = alloc_var();
  *var_gracelibPath = strlit23;
  if (strlit23 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 35
  setline(35);
// Begin line 34
  setline(34);
  Object bool24 = alloc_Boolean(0);
// compilenode returning bool24
  var_inBlock = alloc_var();
  *var_inBlock = bool24;
  if (bool24 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 36
  setline(36);
// Begin line 35
  setline(35);
  Object num25 = alloc_Float64(1.0);
// compilenode returning num25
  var_paramsUsed = alloc_var();
  *var_paramsUsed = num25;
  if (num25 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 37
  setline(37);
// Begin line 36
  setline(36);
  Object num26 = alloc_Float64(1.0);
// compilenode returning num26
  var_topLevelMethodPos = alloc_var();
  *var_topLevelMethodPos = num26;
  if (num26 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 38
  setline(38);
  Object array27 = alloc_List();
// compilenode returning array27
  var_topOutput = alloc_var();
  *var_topOutput = array27;
  if (array27 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 40
  setline(40);
// Begin line 38
  setline(38);
// compilenode returning *var_output
  var_bottomOutput = alloc_var();
  *var_bottomOutput = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 41
  setline(41);
  block_savedest(self);
  Object **closure28 = createclosure(1);
  addtoclosure(closure28, var_output);
  struct UserObject *uo28 = (struct UserObject*)self;
  uo28->data[1] = (Object)closure28;
  addmethod2(self, "out", &meth_genc_out28);
// compilenode returning 
// Begin line 44
  setline(44);
  addmethod2(self, "outprint", &meth_genc_outprint30);
// compilenode returning 
// Begin line 48
  setline(48);
  block_savedest(self);
  Object **closure32 = createclosure(2);
  addtoclosure(closure32, var_topOutput);
  addtoclosure(closure32, var_output);
  struct UserObject *uo32 = (struct UserObject*)self;
  uo32->data[3] = (Object)closure32;
  addmethod2(self, "outswitchup", &meth_genc_outswitchup32);
// compilenode returning 
// Begin line 51
  setline(51);
  block_savedest(self);
  Object **closure34 = createclosure(2);
  addtoclosure(closure34, var_bottomOutput);
  addtoclosure(closure34, var_output);
  struct UserObject *uo34 = (struct UserObject*)self;
  uo34->data[4] = (Object)closure34;
  addmethod2(self, "outswitchdown", &meth_genc_outswitchdown34);
// compilenode returning 
// Begin line 53
  setline(53);
  addmethod2(self, "log_verbose", &meth_genc_log_verbose36);
// compilenode returning 
// Begin line 57
  setline(57);
  block_savedest(self);
  Object **closure38 = createclosure(1);
  addtoclosure(closure38, var_bblock);
  struct UserObject *uo38 = (struct UserObject*)self;
  uo38->data[6] = (Object)closure38;
  addmethod2(self, "beginblock", &meth_genc_beginblock38);
// compilenode returning 
// Begin line 72
  setline(72);
  addmethod2(self, "escapeident", &meth_genc_escapeident47);
// compilenode returning 
// Begin line 98
  setline(98);
  addmethod2(self, "escapestring2", &meth_genc_escapestring2102);
// compilenode returning 
// Begin line 111
  setline(111);
  block_savedest(self);
  Object **closure163 = createclosure(1);
  addtoclosure(closure163, var_auto_count);
  struct UserObject *uo163 = (struct UserObject*)self;
  uo163->data[9] = (Object)closure163;
  addmethod2(self, "compilearray", &meth_genc_compilearray163);
// compilenode returning 
// Begin line 118
  setline(118);
  addmethod2(self, "compilemember", &meth_genc_compilemember202);
// compilenode returning 
// Begin line 133
  setline(133);
  block_savedest(self);
  Object **closure207 = createclosure(2);
  addtoclosure(closure207, var_auto_count);
  addtoclosure(closure207, var_escmodname);
  struct UserObject *uo207 = (struct UserObject*)self;
  uo207->data[11] = (Object)closure207;
  addmethod2(self, "compileobjouter", &meth_genc_compileobjouter207);
// compilenode returning 
// Begin line 154
  setline(154);
  block_savedest(self);
  Object **closure280 = createclosure(2);
  addtoclosure(closure280, var_auto_count);
  addtoclosure(closure280, var_escmodname);
  struct UserObject *uo280 = (struct UserObject*)self;
  uo280->data[12] = (Object)closure280;
  addmethod2(self, "compileobjdefdec", &meth_genc_compileobjdefdec280);
// compilenode returning 
// Begin line 186
  setline(186);
  block_savedest(self);
  Object **closure381 = createclosure(2);
  addtoclosure(closure381, var_auto_count);
  addtoclosure(closure381, var_escmodname);
  struct UserObject *uo381 = (struct UserObject*)self;
  uo381->data[13] = (Object)closure381;
  addmethod2(self, "compileobjvardec", &meth_genc_compileobjvardec381);
// compilenode returning 
// Begin line 196
  setline(196);
  addmethod2(self, "compileclass", &meth_genc_compileclass555);
// compilenode returning 
// Begin line 243
  setline(243);
  block_savedest(self);
  Object **closure574 = createclosure(2);
  addtoclosure(closure574, var_inBlock);
  addtoclosure(closure574, var_auto_count);
  struct UserObject *uo574 = (struct UserObject*)self;
  uo574->data[15] = (Object)closure574;
  addmethod2(self, "compileobject", &meth_genc_compileobject574);
// compilenode returning 
// Begin line 258
  setline(258);
  block_savedest(self);
  Object **closure712 = createclosure(3);
  addtoclosure(closure712, var_inBlock);
  addtoclosure(closure712, var_auto_count);
  addtoclosure(closure712, var_modname);
  struct UserObject *uo712 = (struct UserObject*)self;
  uo712->data[16] = (Object)closure712;
  addmethod2(self, "compileblock", &meth_genc_compileblock712);
// compilenode returning 
// Begin line 274
  setline(274);
  block_savedest(self);
  Object **closure757 = createclosure(1);
  addtoclosure(closure757, var_auto_count);
  struct UserObject *uo757 = (struct UserObject*)self;
  uo757->data[17] = (Object)closure757;
  addmethod2(self, "compilefor", &meth_genc_compilefor757);
// compilenode returning 
// Begin line 440
  setline(440);
  block_savedest(self);
  Object **closure823 = createclosure(8);
  addtoclosure(closure823, var_paramsUsed);
  addtoclosure(closure823, var_inBlock);
  addtoclosure(closure823, var_output);
  addtoclosure(closure823, var_bblock);
  addtoclosure(closure823, var_usedvars);
  addtoclosure(closure823, var_declaredvars);
  addtoclosure(closure823, var_auto_count);
  addtoclosure(closure823, var_modname);
  struct UserObject *uo823 = (struct UserObject*)self;
  uo823->data[18] = (Object)closure823;
  addmethod2(self, "compilemethod", &meth_genc_compilemethod823);
// compilenode returning 
// Begin line 464
  setline(464);
  block_savedest(self);
  Object **closure1330 = createclosure(2);
  addtoclosure(closure1330, var_auto_count);
  addtoclosure(closure1330, var_declaredvars);
  struct UserObject *uo1330 = (struct UserObject*)self;
  uo1330->data[19] = (Object)closure1330;
  addmethod2(self, "compilewhile", &meth_genc_compilewhile1330);
// compilenode returning 
// Begin line 506
  setline(506);
  block_savedest(self);
  Object **closure1423 = createclosure(2);
  addtoclosure(closure1423, var_auto_count);
  addtoclosure(closure1423, var_declaredvars);
  struct UserObject *uo1423 = (struct UserObject*)self;
  uo1423->data[20] = (Object)closure1423;
  addmethod2(self, "compileif", &meth_genc_compileif1423);
// compilenode returning 
// Begin line 523
  setline(523);
  block_savedest(self);
  Object **closure1588 = createclosure(3);
  addtoclosure(closure1588, var_auto_count);
  addtoclosure(closure1588, var_modules);
  addtoclosure(closure1588, var_usedvars);
  struct UserObject *uo1588 = (struct UserObject*)self;
  uo1588->data[21] = (Object)closure1588;
  addmethod2(self, "compileidentifier", &meth_genc_compileidentifier1588);
// compilenode returning 
// Begin line 553
  setline(553);
  block_savedest(self);
  Object **closure1632 = createclosure(2);
  addtoclosure(closure1632, var_usedvars);
  addtoclosure(closure1632, var_auto_count);
  struct UserObject *uo1632 = (struct UserObject*)self;
  uo1632->data[22] = (Object)closure1632;
  addmethod2(self, "compilebind", &meth_genc_compilebind1632);
// compilenode returning 
// Begin line 572
  setline(572);
  block_savedest(self);
  Object **closure1710 = createclosure(1);
  addtoclosure(closure1710, var_declaredvars);
  struct UserObject *uo1710 = (struct UserObject*)self;
  uo1710->data[23] = (Object)closure1710;
  addmethod2(self, "compiledefdec", &meth_genc_compiledefdec1710);
// compilenode returning 
// Begin line 591
  setline(591);
  block_savedest(self);
  Object **closure1756 = createclosure(1);
  addtoclosure(closure1756, var_declaredvars);
  struct UserObject *uo1756 = (struct UserObject*)self;
  uo1756->data[24] = (Object)closure1756;
  addmethod2(self, "compilevardec", &meth_genc_compilevardec1756);
// compilenode returning 
// Begin line 599
  setline(599);
  block_savedest(self);
  Object **closure1801 = createclosure(1);
  addtoclosure(closure1801, var_auto_count);
  struct UserObject *uo1801 = (struct UserObject*)self;
  uo1801->data[25] = (Object)closure1801;
  addmethod2(self, "compileindex", &meth_genc_compileindex1801);
// compilenode returning 
// Begin line 634
  setline(634);
  block_savedest(self);
  Object **closure1833 = createclosure(2);
  addtoclosure(closure1833, var_auto_count);
  addtoclosure(closure1833, var_constants);
  struct UserObject *uo1833 = (struct UserObject*)self;
  uo1833->data[26] = (Object)closure1833;
  addmethod2(self, "compileop", &meth_genc_compileop1833);
// compilenode returning 
// Begin line 671
  setline(671);
  block_savedest(self);
  Object **closure2003 = createclosure(2);
  addtoclosure(closure2003, var_paramsUsed);
  addtoclosure(closure2003, var_auto_count);
  struct UserObject *uo2003 = (struct UserObject*)self;
  uo2003->data[27] = (Object)closure2003;
  addmethod2(self, "compilecall", &meth_genc_compilecall2003);
// compilenode returning 
// Begin line 689
  setline(689);
  block_savedest(self);
  Object **closure2150 = createclosure(2);
  addtoclosure(closure2150, var_auto_count);
  addtoclosure(closure2150, var_globals);
  struct UserObject *uo2150 = (struct UserObject*)self;
  uo2150->data[28] = (Object)closure2150;
  addmethod2(self, "compileoctets", &meth_genc_compileoctets2150);
// compilenode returning 
// Begin line 709
  setline(709);
  block_savedest(self);
  Object **closure2219 = createclosure(4);
  addtoclosure(closure2219, var_staticmodules);
  addtoclosure(closure2219, var_modules);
  addtoclosure(closure2219, var_globals);
  addtoclosure(closure2219, var_auto_count);
  struct UserObject *uo2219 = (struct UserObject*)self;
  uo2219->data[29] = (Object)closure2219;
  addmethod2(self, "compileimport", &meth_genc_compileimport2219);
// compilenode returning 
// Begin line 718
  setline(718);
  block_savedest(self);
  Object **closure2308 = createclosure(1);
  addtoclosure(closure2308, var_inBlock);
  struct UserObject *uo2308 = (struct UserObject*)self;
  uo2308->data[30] = (Object)closure2308;
  addmethod2(self, "compilereturn", &meth_genc_compilereturn2308);
// compilenode returning 
// Begin line 733
  setline(733);
  block_savedest(self);
  Object **closure2328 = createclosure(1);
  addtoclosure(closure2328, var_auto_count);
  struct UserObject *uo2328 = (struct UserObject*)self;
  uo2328->data[31] = (Object)closure2328;
  addmethod2(self, "compilenum", &meth_genc_compilenum2328);
// compilenode returning 
// Begin line 861
  setline(861);
  block_savedest(self);
  Object **closure2369 = createclosure(5);
  addtoclosure(closure2369, var_linenum);
  addtoclosure(closure2369, var_auto_count);
  addtoclosure(closure2369, var_globals);
  addtoclosure(closure2369, var_topLevelMethodPos);
  addtoclosure(closure2369, var_tmp);
  struct UserObject *uo2369 = (struct UserObject*)self;
  uo2369->data[32] = (Object)closure2369;
  addmethod2(self, "compilenode", &meth_genc_compilenode2369);
// compilenode returning 
// Begin line 1035
  setline(1035);
  block_savedest(self);
  Object **closure2758 = createclosure(12);
  addtoclosure(closure2758, var_values);
  addtoclosure(closure2758, var_outfile);
  addtoclosure(closure2758, var_modname);
  addtoclosure(closure2758, var_escmodname);
  addtoclosure(closure2758, var_runmode);
  addtoclosure(closure2758, var_buildtype);
  addtoclosure(closure2758, var_staticmodules);
  addtoclosure(closure2758, var_output);
  addtoclosure(closure2758, var_declaredvars);
  addtoclosure(closure2758, var_globals);
  addtoclosure(closure2758, var_paramsUsed);
  addtoclosure(closure2758, var_topOutput);
  struct UserObject *uo2758 = (struct UserObject*)self;
  uo2758->data[33] = (Object)closure2758;
  addmethod2(self, "compile", &meth_genc_compile2758);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_genc_init();
  gracelib_stats();
  return 0;
}
