#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_genjs_outer_32(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_101(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_117(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_485(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_560(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_579(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_706(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_753(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_828(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_871(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_900(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1200(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1238(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1270(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1299(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1611(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1874(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_1991(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genjs_outer_2003(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_sys_init();
Object module_sys;
Object module_ast_init();
Object module_ast;
Object module_util_init();
Object module_util;
static Object strlit11;
static Object strlit16;
static Object strlit17;
static Object strlit18;
static Object strlit19;
static Object strlit28;
static Object strlit67;
static Object strlit72;
static Object strlit78;
static Object strlit83;
static Object strlit87;
static Object strlit107;
static Object strlit110;
static Object strlit119;
static Object strlit124;
static Object strlit126;
static Object strlit136;
static Object strlit141;
static Object strlit143;
static Object strlit145;
static Object strlit148;
static Object strlit153;
static Object strlit158;
static Object strlit162;
static Object strlit165;
static Object strlit172;
static Object strlit176;
static Object strlit179;
static Object strlit183;
static Object strlit185;
static Object strlit188;
static Object strlit193;
static Object strlit198;
static Object strlit205;
static Object strlit210;
static Object strlit226;
static Object strlit229;
static Object strlit234;
static Object strlit239;
static Object strlit243;
static Object strlit246;
static Object strlit253;
static Object strlit257;
static Object strlit260;
static Object strlit264;
static Object strlit266;
static Object strlit269;
static Object strlit274;
static Object strlit279;
static Object strlit286;
static Object strlit291;
static Object strlit307;
static Object strlit310;
static Object strlit315;
static Object strlit320;
static Object strlit324;
static Object strlit327;
static Object strlit334;
static Object strlit338;
static Object strlit341;
static Object strlit345;
static Object strlit347;
static Object strlit350;
static Object strlit355;
static Object strlit360;
static Object strlit367;
static Object strlit371;
static Object strlit374;
static Object strlit379;
static Object strlit384;
static Object strlit388;
static Object strlit391;
static Object strlit398;
static Object strlit402;
static Object strlit405;
static Object strlit409;
static Object strlit411;
static Object strlit414;
static Object strlit419;
static Object strlit424;
static Object strlit431;
static Object strlit441;
static Object strlit461;
static Object strlit472;
static Object strlit475;
static Object strlit489;
static Object strlit495;
static Object strlit505;
static Object strlit523;
static Object strlit526;
static Object strlit530;
static Object strlit533;
static Object strlit537;
static Object strlit539;
static Object strlit541;
static Object strlit544;
static Object strlit548;
static Object strlit551;
static Object strlit564;
static Object strlit572;
static Object strlit574;
static Object strlit584;
static Object strlit587;
static Object strlit591;
static Object strlit593;
static Object strlit607;
static Object strlit610;
static Object strlit615;
static Object strlit620;
static Object strlit624;
static Object strlit627;
static Object strlit630;
static Object strlit635;
static Object strlit639;
static Object strlit642;
static Object strlit647;
static Object strlit650;
static Object strlit655;
static Object strlit659;
static Object strlit662;
static Object strlit667;
static Object strlit672;
static Object strlit676;
static Object strlit694;
static Object strlit697;
static Object strlit710;
static Object strlit718;
static Object strlit722;
static Object strlit728;
static Object strlit731;
static Object strlit736;
static Object strlit742;
static Object strlit744;
static Object strlit746;
static Object strlit748;
static Object strlit758;
static Object strlit762;
static Object strlit764;
static Object strlit766;
static Object strlit768;
static Object strlit770;
static Object strlit772;
static Object strlit774;
static Object strlit776;
static Object strlit780;
static Object strlit783;
static Object strlit788;
static Object strlit793;
static Object strlit804;
static Object strlit807;
static Object strlit812;
static Object strlit816;
static Object strlit819;
static Object strlit823;
static Object strlit836;
static Object strlit839;
static Object strlit844;
static Object strlit848;
static Object strlit856;
static Object strlit861;
static Object strlit865;
static Object strlit866;
static Object strlit876;
static Object strlit879;
static Object strlit884;
static Object strlit894;
static Object strlit905;
static Object strlit908;
static Object strlit913;
static Object strlit917;
static Object strlit919;
static Object strlit926;
static Object strlit929;
static Object strlit933;
static Object strlit935;
static Object strlit940;
static Object strlit951;
static Object strlit952;
static Object strlit953;
static Object strlit956;
static Object strlit966;
static Object strlit970;
static Object strlit975;
static Object strlit982;
static Object strlit986;
static Object strlit999;
static Object strlit1002;
static Object strlit1017;
static Object strlit1034;
static Object strlit1036;
static Object strlit1040;
static Object strlit1045;
static Object strlit1059;
static Object strlit1063;
static Object strlit1068;
static Object strlit1072;
static Object strlit1076;
static Object strlit1080;
static Object strlit1088;
static Object strlit1091;
static Object strlit1096;
static Object strlit1099;
static Object strlit1104;
static Object strlit1109;
static Object strlit1113;
static Object strlit1130;
static Object strlit1133;
static Object strlit1136;
static Object strlit1140;
static Object strlit1143;
static Object strlit1147;
static Object strlit1150;
static Object strlit1154;
static Object strlit1157;
static Object strlit1159;
static Object strlit1164;
static Object strlit1169;
static Object strlit1175;
static Object strlit1180;
static Object strlit1193;
static Object strlit1195;
static Object strlit1208;
static Object strlit1215;
static Object strlit1218;
static Object strlit1223;
static Object strlit1231;
static Object strlit1240;
static Object strlit1245;
static Object strlit1247;
static Object strlit1249;
static Object strlit1252;
static Object strlit1255;
static Object strlit1263;
static Object strlit1272;
static Object strlit1277;
static Object strlit1279;
static Object strlit1288;
static Object strlit1308;
static Object strlit1320;
static Object strlit1323;
static Object strlit1329;
static Object strlit1332;
static Object strlit1337;
static Object strlit1341;
static Object strlit1344;
static Object strlit1349;
static Object strlit1354;
static Object strlit1358;
static Object strlit1361;
static Object strlit1365;
static Object strlit1368;
static Object strlit1374;
static Object strlit1377;
static Object strlit1381;
static Object strlit1384;
static Object strlit1388;
static Object strlit1391;
static Object strlit1396;
static Object strlit1402;
static Object strlit1406;
static Object strlit1409;
static Object strlit1412;
static Object strlit1415;
static Object strlit1420;
static Object strlit1425;
static Object strlit1429;
static Object strlit1432;
static Object strlit1435;
static Object strlit1441;
static Object strlit1444;
static Object strlit1448;
static Object strlit1451;
static Object strlit1455;
static Object strlit1458;
static Object strlit1463;
static Object strlit1468;
static Object strlit1471;
static Object strlit1476;
static Object strlit1481;
static Object strlit1485;
static Object strlit1489;
static Object strlit1492;
static Object strlit1497;
static Object strlit1502;
static Object strlit1506;
static Object strlit1509;
static Object strlit1514;
static Object strlit1523;
static Object strlit1532;
static Object strlit1536;
static Object strlit1539;
static Object strlit1544;
static Object strlit1550;
static Object strlit1556;
static Object strlit1559;
static Object strlit1563;
static Object strlit1567;
static Object strlit1576;
static Object strlit1582;
static Object strlit1585;
static Object strlit1589;
static Object strlit1593;
static Object strlit1596;
static Object strlit1606;
static Object strlit1614;
static Object strlit1617;
static Object strlit1622;
static Object strlit1625;
static Object strlit1630;
static Object strlit1633;
static Object strlit1655;
static Object strlit1659;
static Object strlit1669;
static Object strlit1670;
static Object strlit1673;
static Object strlit1674;
static Object strlit1677;
static Object strlit1678;
static Object strlit1681;
static Object strlit1684;
static Object strlit1689;
static Object strlit1693;
static Object strlit1703;
static Object strlit1709;
static Object strlit1715;
static Object strlit1721;
static Object strlit1727;
static Object strlit1735;
static Object strlit1739;
static Object strlit1743;
static Object strlit1753;
static Object strlit1758;
static Object strlit1761;
static Object strlit1767;
static Object strlit1771;
static Object strlit1781;
static Object strlit1787;
static Object strlit1793;
static Object strlit1799;
static Object strlit1805;
static Object strlit1808;
static Object strlit1812;
static Object strlit1818;
static Object strlit1824;
static Object strlit1830;
static Object strlit1836;
static Object strlit1842;
static Object strlit1848;
static Object strlit1854;
static Object strlit1860;
static Object strlit1866;
static Object strlit1879;
static Object strlit1882;
static Object strlit1888;
static Object strlit1892;
static Object strlit1903;
static Object strlit1908;
static Object strlit1917;
static Object strlit1920;
static Object strlit1925;
static Object strlit1929;
static Object strlit1940;
static Object strlit1945;
static Object strlit1953;
static Object strlit1964;
static Object strlit1977;
static Object strlit1981;
static Object strlit1984;
static Object strlit1995;
static Object strlit1997;
static Object strlit2006;
static Object strlit2022;
Object meth_genjs_out21(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_output = closure[0];
// compilenode returning *var_s
// compilenode returning *var_output
  params[0] = *var_s;
  Object call22 = callmethod(*var_output, "push",
    1, params);
// compilenode returning call22
  return call22;
}
Object meth_genjs_outprint23(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
// compilenode returning *var_s
// compilenode returning module_util
  params[0] = *var_s;
  Object call24 = callmethod(module_util, "outprint",
    1, params);
// compilenode returning call24
  return call24;
}
Object meth_genjs_log_verbose25(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
// compilenode returning *var_s
// compilenode returning module_util
  params[0] = *var_s;
  Object call26 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call26
  return call26;
}
Object meth_genjs_apply33(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_nm = closure[0];
  Object self = *closure[1];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 39
  setline(39);
// Begin line 643
  setline(643);
// Begin line 38
  setline(38);
// compilenode returning *var_c
  Object call34 = callmethod(*var_c, "ord",
    0, params);
// compilenode returning call34
// compilenode returning call34
  var_o = alloc_var();
  *var_o = call34;
  if (call34 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 44
  setline(44);
// Begin line 45
  setline(45);
// Begin line 39
  setline(39);
// compilenode returning *var_o
  Object num36 = alloc_Float64(97.0);
// compilenode returning num36
  params[0] = num36;
  Object opresult38 = callmethod(*var_o, ">=", 1, params);
// compilenode returning opresult38
// Begin line 45
  setline(45);
// Begin line 39
  setline(39);
// compilenode returning *var_o
  Object num39 = alloc_Float64(122.0);
// compilenode returning num39
  params[0] = num39;
  Object opresult41 = callmethod(*var_o, "<=", 1, params);
// compilenode returning opresult41
  params[0] = opresult41;
  Object opresult43 = callmethod(opresult38, "&", 1, params);
// compilenode returning opresult43
// Begin line 45
  setline(45);
// Begin line 39
  setline(39);
// compilenode returning *var_o
  Object num44 = alloc_Float64(65.0);
// compilenode returning num44
  params[0] = num44;
  Object opresult46 = callmethod(*var_o, ">=", 1, params);
// compilenode returning opresult46
// Begin line 45
  setline(45);
// Begin line 39
  setline(39);
// compilenode returning *var_o
  Object num47 = alloc_Float64(90.0);
// compilenode returning num47
  params[0] = num47;
  Object opresult49 = callmethod(*var_o, "<=", 1, params);
// compilenode returning opresult49
  params[0] = opresult49;
  Object opresult51 = callmethod(opresult46, "&", 1, params);
// compilenode returning opresult51
  params[0] = opresult51;
  Object opresult53 = callmethod(opresult43, "|", 1, params);
// compilenode returning opresult53
// Begin line 45
  setline(45);
// Begin line 40
  setline(40);
// compilenode returning *var_o
  Object num54 = alloc_Float64(48.0);
// compilenode returning num54
  params[0] = num54;
  Object opresult56 = callmethod(*var_o, ">=", 1, params);
// compilenode returning opresult56
// Begin line 45
  setline(45);
// Begin line 40
  setline(40);
// compilenode returning *var_o
  Object num57 = alloc_Float64(57.0);
// compilenode returning num57
  params[0] = num57;
  Object opresult59 = callmethod(*var_o, "<=", 1, params);
// compilenode returning opresult59
  params[0] = opresult59;
  Object opresult61 = callmethod(opresult56, "&", 1, params);
// compilenode returning opresult61
  params[0] = opresult61;
  Object opresult63 = callmethod(opresult53, "|", 1, params);
// compilenode returning opresult63
  Object if35;
  if (istrue(opresult63)) {
// Begin line 42
  setline(42);
// Begin line 41
  setline(41);
// compilenode returning *var_nm
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult65 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult65
  *var_nm = opresult65;
  if (opresult65 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if35 = nothing;
  } else {
// Begin line 44
  setline(44);
// Begin line 43
  setline(43);
// compilenode returning *var_nm
  if (strlit67 == NULL) {
    strlit67 = alloc_String("__");
  }
// compilenode returning strlit67
  params[0] = strlit67;
  Object opresult69 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult69
// compilenode returning *var_o
  params[0] = *var_o;
  Object opresult71 = callmethod(opresult69, "++", 1, params);
// compilenode returning opresult71
  if (strlit72 == NULL) {
    strlit72 = alloc_String("__");
  }
// compilenode returning strlit72
  params[0] = strlit72;
  Object opresult74 = callmethod(opresult71, "++", 1, params);
// compilenode returning opresult74
  *var_nm = opresult74;
  if (opresult74 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if35 = nothing;
  }
// compilenode returning if35
  return if35;
}
Object meth_genjs_escapeident27(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object *var_vn = alloc_var();
  *var_vn = args[0];
  Object params[1];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
// Begin line 37
  setline(37);
// Begin line 36
  setline(36);
  if (strlit28 == NULL) {
    strlit28 = alloc_String("");
  }
// compilenode returning strlit28
  var_nm = alloc_var();
  *var_nm = strlit28;
  if (strlit28 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 44
  setline(44);
// Begin line 37
  setline(37);
// compilenode returning *var_vn
// Begin line 44
  setline(44);
// Begin line 643
  setline(643);
  Object obj31 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj31, self, 0);
  addmethod2(obj31, "outer", &reader_genjs_outer_32);
  adddatum2(obj31, self, 0);
  block_savedest(obj31);
  Object **closure33 = createclosure(2);
  addtoclosure(closure33, var_nm);
  Object *selfpp76 = alloc_var();
  *selfpp76 = self;
  addtoclosure(closure33, selfpp76);
  struct UserObject *uo33 = (struct UserObject*)obj31;
  uo33->data[1] = (Object)closure33;
  addmethod2(obj31, "apply", &meth_genjs_apply33);
  set_type(obj31, 0);
// compilenode returning obj31
  setclassname(obj31, "Block<genjs:30>");
// compilenode returning obj31
  params[0] = *var_vn;
  Object iter29 = callmethod(*var_vn, "iter", 1, params);
  while(1) {
    Object cond29 = callmethod(iter29, "havemore", 0, NULL);
    if (!istrue(cond29)) break;
    params[0] = callmethod(iter29, "next", 0, NULL);
    callmethod(obj31, "apply", 1, params);
  }
// compilenode returning *var_vn
// Begin line 46
  setline(46);
// compilenode returning *var_nm
  return *var_nm;
}
Object meth_genjs_varf77(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_vn = alloc_var();
  *var_vn = args[0];
  Object params[1];
  if (strlit78 == NULL) {
    strlit78 = alloc_String("var_");
  }
// compilenode returning strlit78
// compilenode returning *var_vn
// Begin line 50
  setline(50);
// compilenode returning self
  params[0] = *var_vn;
  Object call79 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call79
  params[0] = call79;
  Object opresult81 = callmethod(strlit78, "++", 1, params);
// compilenode returning opresult81
  return opresult81;
}
Object meth_genjs_beginblock82(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_bblock = closure[0];
// Begin line 52
  setline(52);
  if (strlit83 == NULL) {
    strlit83 = alloc_String("%");
  }
// compilenode returning strlit83
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult85 = callmethod(strlit83, "++", 1, params);
// compilenode returning opresult85
  *var_bblock = opresult85;
  if (opresult85 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 53
  setline(53);
// compilenode returning *var_s
  if (strlit87 == NULL) {
    strlit87 = alloc_String(":");
  }
// compilenode returning strlit87
  params[0] = strlit87;
  Object opresult89 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult89
// Begin line 54
  setline(54);
// compilenode returning self
  params[0] = opresult89;
  Object call90 = callmethod(self, "out",
    1, params);
// compilenode returning call90
  return call90;
}
Object meth_genjs_apply102(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_a = alloc_var();
  *var_a = args[0];
  Object params[1];
  Object *var_r = closure[0];
  Object *var_vals = closure[1];
  Object self = *closure[2];
// Begin line 61
  setline(61);
// compilenode returning *var_a
// Begin line 62
  setline(62);
// compilenode returning self
  params[0] = *var_a;
  Object call103 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call103
  *var_r = call103;
  if (call103 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_vals
  params[0] = *var_r;
  Object call105 = callmethod(*var_vals, "push",
    1, params);
// compilenode returning call105
  return call105;
}
Object meth_genjs_apply118(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 66
  setline(66);
// compilenode returning *var_v
  if (strlit119 == NULL) {
    strlit119 = alloc_String(",");
  }
// compilenode returning strlit119
  params[0] = strlit119;
  Object opresult121 = callmethod(*var_v, "++", 1, params);
// compilenode returning opresult121
// Begin line 67
  setline(67);
// compilenode returning self
  params[0] = opresult121;
  Object call122 = callmethod(self, "out",
    1, params);
// compilenode returning call122
  return call122;
}
Object meth_genjs_compilearray91(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
  Object *var_vals = alloc_var();
  *var_vals = undefined;
// Begin line 57
  setline(57);
// Begin line 56
  setline(56);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 58
  setline(58);
// Begin line 57
  setline(57);
// compilenode returning *var_auto_count
  Object num92 = alloc_Float64(1.0);
// compilenode returning num92
  params[0] = num92;
  Object sum94 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum94
  *var_auto_count = sum94;
  if (sum94 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 59
  setline(59);
  var_r = alloc_var();
  *var_r = undefined;
// compilenode returning nothing
// Begin line 60
  setline(60);
  Object array96 = alloc_List();
// compilenode returning array96
  var_vals = alloc_var();
  *var_vals = array96;
  if (array96 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 62
  setline(62);
// Begin line 64
  setline(64);
// Begin line 643
  setline(643);
// Begin line 60
  setline(60);
// compilenode returning *var_o
  Object call98 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call98
// compilenode returning call98
// Begin line 62
  setline(62);
// Begin line 643
  setline(643);
  Object obj100 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj100, self, 0);
  addmethod2(obj100, "outer", &reader_genjs_outer_101);
  adddatum2(obj100, self, 0);
  block_savedest(obj100);
  Object **closure102 = createclosure(3);
  addtoclosure(closure102, var_r);
  addtoclosure(closure102, var_vals);
  Object *selfpp106 = alloc_var();
  *selfpp106 = self;
  addtoclosure(closure102, selfpp106);
  struct UserObject *uo102 = (struct UserObject*)obj100;
  uo102->data[1] = (Object)closure102;
  addmethod2(obj100, "apply", &meth_genjs_apply102);
  set_type(obj100, 0);
// compilenode returning obj100
  setclassname(obj100, "Block<genjs:99>");
// compilenode returning obj100
  params[0] = call98;
  Object iter97 = callmethod(call98, "iter", 1, params);
  while(1) {
    Object cond97 = callmethod(iter97, "havemore", 0, NULL);
    if (!istrue(cond97)) break;
    params[0] = callmethod(iter97, "next", 0, NULL);
    callmethod(obj100, "apply", 1, params);
  }
// compilenode returning call98
// Begin line 64
  setline(64);
  if (strlit107 == NULL) {
    strlit107 = alloc_String("  var array");
  }
// compilenode returning strlit107
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult109 = callmethod(strlit107, "++", 1, params);
// compilenode returning opresult109
  if (strlit110 == NULL) {
    strlit110 = alloc_String(" = new GraceList([");
  }
// compilenode returning strlit110
  params[0] = strlit110;
  Object opresult112 = callmethod(opresult109, "++", 1, params);
// compilenode returning opresult112
// Begin line 65
  setline(65);
// compilenode returning self
  params[0] = opresult112;
  Object call113 = callmethod(self, "out",
    1, params);
// compilenode returning call113
// Begin line 66
  setline(66);
// Begin line 65
  setline(65);
// compilenode returning *var_vals
// Begin line 66
  setline(66);
// Begin line 643
  setline(643);
  Object obj116 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj116, self, 0);
  addmethod2(obj116, "outer", &reader_genjs_outer_117);
  adddatum2(obj116, self, 0);
  block_savedest(obj116);
  Object **closure118 = createclosure(1);
  Object *selfpp123 = alloc_var();
  *selfpp123 = self;
  addtoclosure(closure118, selfpp123);
  struct UserObject *uo118 = (struct UserObject*)obj116;
  uo118->data[1] = (Object)closure118;
  addmethod2(obj116, "apply", &meth_genjs_apply118);
  set_type(obj116, 0);
// compilenode returning obj116
  setclassname(obj116, "Block<genjs:115>");
// compilenode returning obj116
  params[0] = *var_vals;
  Object iter114 = callmethod(*var_vals, "iter", 1, params);
  while(1) {
    Object cond114 = callmethod(iter114, "havemore", 0, NULL);
    if (!istrue(cond114)) break;
    params[0] = callmethod(iter114, "next", 0, NULL);
    callmethod(obj116, "apply", 1, params);
  }
// compilenode returning *var_vals
// Begin line 68
  setline(68);
  if (strlit124 == NULL) {
    strlit124 = alloc_String("]);""\x0a""");
  }
// compilenode returning strlit124
// Begin line 69
  setline(69);
// compilenode returning self
  params[0] = strlit124;
  Object call125 = callmethod(self, "out",
    1, params);
// compilenode returning call125
// Begin line 70
  setline(70);
// Begin line 643
  setline(643);
// Begin line 70
  setline(70);
// Begin line 69
  setline(69);
  if (strlit126 == NULL) {
    strlit126 = alloc_String("array");
  }
// compilenode returning strlit126
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult128 = callmethod(strlit126, "++", 1, params);
// compilenode returning opresult128
// compilenode returning *var_o
  params[0] = opresult128;
  Object call129 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call129
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compilemember130(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_c = alloc_var();
  *var_c = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 74
  setline(74);
  Object array131 = alloc_List();
// compilenode returning array131
  var_l = alloc_var();
  *var_l = array131;
  if (array131 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_o
// compilenode returning *var_l
// compilenode returning module_ast
  params[0] = *var_o;
  params[1] = *var_l;
  Object call132 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call132
  var_c = alloc_var();
  *var_c = call132;
  if (call132 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 75
  setline(75);
// compilenode returning *var_c
// Begin line 76
  setline(76);
// compilenode returning self
  params[0] = *var_c;
  Object call133 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call133
  var_r = alloc_var();
  *var_r = call133;
  if (call133 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 77
  setline(77);
// Begin line 643
  setline(643);
// Begin line 76
  setline(76);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call134 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call134
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileobjouter135(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_selfr = alloc_var();
  *var_selfr = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_modname = closure[1];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_nmi = alloc_var();
  *var_nmi = undefined;
// Begin line 79
  setline(79);
  if (strlit136 == NULL) {
    strlit136 = alloc_String("this");
  }
// compilenode returning strlit136
  var_val = alloc_var();
  *var_val = strlit136;
  if (strlit136 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 81
  setline(81);
// Begin line 80
  setline(80);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 82
  setline(82);
// Begin line 81
  setline(81);
// compilenode returning *var_auto_count
  Object num137 = alloc_Float64(1.0);
// compilenode returning num137
  params[0] = num137;
  Object sum139 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum139
  *var_auto_count = sum139;
  if (sum139 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 82
  setline(82);
// Begin line 643
  setline(643);
// Begin line 82
  setline(82);
  if (strlit141 == NULL) {
    strlit141 = alloc_String("outer");
  }
// compilenode returning strlit141
  Object call142 = callmethod(strlit141, "_escape",
    0, params);
// compilenode returning call142
// compilenode returning call142
  var_nm = alloc_var();
  *var_nm = call142;
  if (call142 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 83
  setline(83);
  if (strlit143 == NULL) {
    strlit143 = alloc_String("outer");
  }
// compilenode returning strlit143
// Begin line 84
  setline(84);
// compilenode returning self
  params[0] = strlit143;
  Object call144 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call144
  var_nmi = alloc_var();
  *var_nmi = call144;
  if (call144 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit145 == NULL) {
    strlit145 = alloc_String("  ");
  }
// compilenode returning strlit145
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult147 = callmethod(strlit145, "++", 1, params);
// compilenode returning opresult147
  if (strlit148 == NULL) {
    strlit148 = alloc_String(".data[""\x22""");
  }
// compilenode returning strlit148
  params[0] = strlit148;
  Object opresult150 = callmethod(opresult147, "++", 1, params);
// compilenode returning opresult150
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult152 = callmethod(opresult150, "++", 1, params);
// compilenode returning opresult152
  if (strlit153 == NULL) {
    strlit153 = alloc_String("""\x22""] = ");
  }
// compilenode returning strlit153
  params[0] = strlit153;
  Object opresult155 = callmethod(opresult152, "++", 1, params);
// compilenode returning opresult155
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult157 = callmethod(opresult155, "++", 1, params);
// compilenode returning opresult157
  if (strlit158 == NULL) {
    strlit158 = alloc_String(";");
  }
// compilenode returning strlit158
  params[0] = strlit158;
  Object opresult160 = callmethod(opresult157, "++", 1, params);
// compilenode returning opresult160
// Begin line 85
  setline(85);
// compilenode returning self
  params[0] = opresult160;
  Object call161 = callmethod(self, "out",
    1, params);
// compilenode returning call161
  if (strlit162 == NULL) {
    strlit162 = alloc_String("    var reader_");
  }
// compilenode returning strlit162
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult164 = callmethod(strlit162, "++", 1, params);
// compilenode returning opresult164
  if (strlit165 == NULL) {
    strlit165 = alloc_String("_");
  }
// compilenode returning strlit165
  params[0] = strlit165;
  Object opresult167 = callmethod(opresult164, "++", 1, params);
// compilenode returning opresult167
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult169 = callmethod(opresult167, "++", 1, params);
// compilenode returning opresult169
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult171 = callmethod(opresult169, "++", 1, params);
// compilenode returning opresult171
  if (strlit172 == NULL) {
    strlit172 = alloc_String(" = function() {");
  }
// compilenode returning strlit172
  params[0] = strlit172;
  Object opresult174 = callmethod(opresult171, "++", 1, params);
// compilenode returning opresult174
// Begin line 86
  setline(86);
// compilenode returning self
  params[0] = opresult174;
  Object call175 = callmethod(self, "out",
    1, params);
// compilenode returning call175
  if (strlit176 == NULL) {
    strlit176 = alloc_String("    return this.data[""\x22""");
  }
// compilenode returning strlit176
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult178 = callmethod(strlit176, "++", 1, params);
// compilenode returning opresult178
  if (strlit179 == NULL) {
    strlit179 = alloc_String("""\x22""];");
  }
// compilenode returning strlit179
  params[0] = strlit179;
  Object opresult181 = callmethod(opresult178, "++", 1, params);
// compilenode returning opresult181
// Begin line 87
  setline(87);
// compilenode returning self
  params[0] = opresult181;
  Object call182 = callmethod(self, "out",
    1, params);
// compilenode returning call182
  if (strlit183 == NULL) {
    strlit183 = alloc_String("  }");
  }
// compilenode returning strlit183
// Begin line 88
  setline(88);
// compilenode returning self
  params[0] = strlit183;
  Object call184 = callmethod(self, "out",
    1, params);
// compilenode returning call184
// Begin line 89
  setline(89);
// Begin line 88
  setline(88);
  if (strlit185 == NULL) {
    strlit185 = alloc_String("  ");
  }
// compilenode returning strlit185
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult187 = callmethod(strlit185, "++", 1, params);
// compilenode returning opresult187
  if (strlit188 == NULL) {
    strlit188 = alloc_String(".methods[""\x22""");
  }
// compilenode returning strlit188
  params[0] = strlit188;
  Object opresult190 = callmethod(opresult187, "++", 1, params);
// compilenode returning opresult190
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult192 = callmethod(opresult190, "++", 1, params);
// compilenode returning opresult192
  if (strlit193 == NULL) {
    strlit193 = alloc_String("""\x22""] = reader_");
  }
// compilenode returning strlit193
  params[0] = strlit193;
  Object opresult195 = callmethod(opresult192, "++", 1, params);
// compilenode returning opresult195
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult197 = callmethod(opresult195, "++", 1, params);
// compilenode returning opresult197
// Begin line 89
  setline(89);
  if (strlit198 == NULL) {
    strlit198 = alloc_String("_");
  }
// compilenode returning strlit198
  params[0] = strlit198;
  Object opresult200 = callmethod(opresult197, "++", 1, params);
// compilenode returning opresult200
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult202 = callmethod(opresult200, "++", 1, params);
// compilenode returning opresult202
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult204 = callmethod(opresult202, "++", 1, params);
// compilenode returning opresult204
  if (strlit205 == NULL) {
    strlit205 = alloc_String(";");
  }
// compilenode returning strlit205
  params[0] = strlit205;
  Object opresult207 = callmethod(opresult204, "++", 1, params);
// compilenode returning opresult207
// Begin line 90
  setline(90);
// compilenode returning self
  params[0] = opresult207;
  Object call208 = callmethod(self, "out",
    1, params);
// compilenode returning call208
  return call208;
}
Object meth_genjs_compileobjdefdec209(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfr = alloc_var();
  *var_selfr = args[1];
  Object *var_pos = args + 2;
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_modname = closure[1];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_nmi = alloc_var();
  *var_nmi = undefined;
// Begin line 93
  setline(93);
// Begin line 92
  setline(92);
  if (strlit210 == NULL) {
    strlit210 = alloc_String("undefined");
  }
// compilenode returning strlit210
  var_val = alloc_var();
  *var_val = strlit210;
  if (strlit210 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 94
  setline(94);
// Begin line 96
  setline(96);
// Begin line 643
  setline(643);
// Begin line 93
  setline(93);
// compilenode returning *var_o
  Object call212 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call212
// compilenode returning call212
  Object if211;
  if (istrue(call212)) {
// Begin line 94
  setline(94);
// Begin line 643
  setline(643);
// Begin line 94
  setline(94);
// compilenode returning *var_o
  Object call213 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call213
// compilenode returning call213
// Begin line 95
  setline(95);
// compilenode returning self
  params[0] = call213;
  Object call214 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call214
  *var_val = call214;
  if (call214 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if211 = nothing;
  } else {
  }
// compilenode returning if211
// Begin line 97
  setline(97);
// Begin line 96
  setline(96);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 98
  setline(98);
// Begin line 97
  setline(97);
// compilenode returning *var_auto_count
  Object num216 = alloc_Float64(1.0);
// compilenode returning num216
  params[0] = num216;
  Object sum218 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum218
  *var_auto_count = sum218;
  if (sum218 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 98
  setline(98);
// Begin line 643
  setline(643);
// Begin line 98
  setline(98);
// Begin line 643
  setline(643);
// Begin line 98
  setline(98);
// Begin line 643
  setline(643);
// Begin line 98
  setline(98);
// compilenode returning *var_o
  Object call220 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call220
// compilenode returning call220
  Object call221 = callmethod(call220, "value",
    0, params);
// compilenode returning call221
// compilenode returning call221
  Object call222 = callmethod(call221, "_escape",
    0, params);
// compilenode returning call222
// compilenode returning call222
  var_nm = alloc_var();
  *var_nm = call222;
  if (call222 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 99
  setline(99);
// Begin line 643
  setline(643);
// Begin line 99
  setline(99);
// Begin line 643
  setline(643);
// Begin line 99
  setline(99);
// compilenode returning *var_o
  Object call223 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call223
// compilenode returning call223
  Object call224 = callmethod(call223, "value",
    0, params);
// compilenode returning call224
// compilenode returning call224
// Begin line 100
  setline(100);
// compilenode returning self
  params[0] = call224;
  Object call225 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call225
  var_nmi = alloc_var();
  *var_nmi = call225;
  if (call225 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit226 == NULL) {
    strlit226 = alloc_String("  ");
  }
// compilenode returning strlit226
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult228 = callmethod(strlit226, "++", 1, params);
// compilenode returning opresult228
  if (strlit229 == NULL) {
    strlit229 = alloc_String(".data[""\x22""");
  }
// compilenode returning strlit229
  params[0] = strlit229;
  Object opresult231 = callmethod(opresult228, "++", 1, params);
// compilenode returning opresult231
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult233 = callmethod(opresult231, "++", 1, params);
// compilenode returning opresult233
  if (strlit234 == NULL) {
    strlit234 = alloc_String("""\x22""] = ");
  }
// compilenode returning strlit234
  params[0] = strlit234;
  Object opresult236 = callmethod(opresult233, "++", 1, params);
// compilenode returning opresult236
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult238 = callmethod(opresult236, "++", 1, params);
// compilenode returning opresult238
  if (strlit239 == NULL) {
    strlit239 = alloc_String(";");
  }
// compilenode returning strlit239
  params[0] = strlit239;
  Object opresult241 = callmethod(opresult238, "++", 1, params);
// compilenode returning opresult241
// Begin line 101
  setline(101);
// compilenode returning self
  params[0] = opresult241;
  Object call242 = callmethod(self, "out",
    1, params);
// compilenode returning call242
  if (strlit243 == NULL) {
    strlit243 = alloc_String("    var reader_");
  }
// compilenode returning strlit243
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult245 = callmethod(strlit243, "++", 1, params);
// compilenode returning opresult245
  if (strlit246 == NULL) {
    strlit246 = alloc_String("_");
  }
// compilenode returning strlit246
  params[0] = strlit246;
  Object opresult248 = callmethod(opresult245, "++", 1, params);
// compilenode returning opresult248
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult250 = callmethod(opresult248, "++", 1, params);
// compilenode returning opresult250
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult252 = callmethod(opresult250, "++", 1, params);
// compilenode returning opresult252
  if (strlit253 == NULL) {
    strlit253 = alloc_String(" = function() {");
  }
// compilenode returning strlit253
  params[0] = strlit253;
  Object opresult255 = callmethod(opresult252, "++", 1, params);
// compilenode returning opresult255
// Begin line 102
  setline(102);
// compilenode returning self
  params[0] = opresult255;
  Object call256 = callmethod(self, "out",
    1, params);
// compilenode returning call256
  if (strlit257 == NULL) {
    strlit257 = alloc_String("    return this.data[""\x22""");
  }
// compilenode returning strlit257
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult259 = callmethod(strlit257, "++", 1, params);
// compilenode returning opresult259
  if (strlit260 == NULL) {
    strlit260 = alloc_String("""\x22""];");
  }
// compilenode returning strlit260
  params[0] = strlit260;
  Object opresult262 = callmethod(opresult259, "++", 1, params);
// compilenode returning opresult262
// Begin line 103
  setline(103);
// compilenode returning self
  params[0] = opresult262;
  Object call263 = callmethod(self, "out",
    1, params);
// compilenode returning call263
  if (strlit264 == NULL) {
    strlit264 = alloc_String("  }");
  }
// compilenode returning strlit264
// Begin line 104
  setline(104);
// compilenode returning self
  params[0] = strlit264;
  Object call265 = callmethod(self, "out",
    1, params);
// compilenode returning call265
// Begin line 105
  setline(105);
// Begin line 104
  setline(104);
  if (strlit266 == NULL) {
    strlit266 = alloc_String("  ");
  }
// compilenode returning strlit266
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult268 = callmethod(strlit266, "++", 1, params);
// compilenode returning opresult268
  if (strlit269 == NULL) {
    strlit269 = alloc_String(".methods[""\x22""");
  }
// compilenode returning strlit269
  params[0] = strlit269;
  Object opresult271 = callmethod(opresult268, "++", 1, params);
// compilenode returning opresult271
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult273 = callmethod(opresult271, "++", 1, params);
// compilenode returning opresult273
  if (strlit274 == NULL) {
    strlit274 = alloc_String("""\x22""] = reader_");
  }
// compilenode returning strlit274
  params[0] = strlit274;
  Object opresult276 = callmethod(opresult273, "++", 1, params);
// compilenode returning opresult276
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult278 = callmethod(opresult276, "++", 1, params);
// compilenode returning opresult278
// Begin line 105
  setline(105);
  if (strlit279 == NULL) {
    strlit279 = alloc_String("_");
  }
// compilenode returning strlit279
  params[0] = strlit279;
  Object opresult281 = callmethod(opresult278, "++", 1, params);
// compilenode returning opresult281
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult283 = callmethod(opresult281, "++", 1, params);
// compilenode returning opresult283
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult285 = callmethod(opresult283, "++", 1, params);
// compilenode returning opresult285
  if (strlit286 == NULL) {
    strlit286 = alloc_String(";");
  }
// compilenode returning strlit286
  params[0] = strlit286;
  Object opresult288 = callmethod(opresult285, "++", 1, params);
// compilenode returning opresult288
// Begin line 106
  setline(106);
// compilenode returning self
  params[0] = opresult288;
  Object call289 = callmethod(self, "out",
    1, params);
// compilenode returning call289
  return call289;
}
Object meth_genjs_compileobjvardec290(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfr = alloc_var();
  *var_selfr = args[1];
  Object *var_pos = args + 2;
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_modname = closure[1];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_nmi = alloc_var();
  *var_nmi = undefined;
// Begin line 109
  setline(109);
// Begin line 108
  setline(108);
  if (strlit291 == NULL) {
    strlit291 = alloc_String("undefined");
  }
// compilenode returning strlit291
  var_val = alloc_var();
  *var_val = strlit291;
  if (strlit291 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 110
  setline(110);
// Begin line 112
  setline(112);
// Begin line 643
  setline(643);
// Begin line 109
  setline(109);
// compilenode returning *var_o
  Object call293 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call293
// compilenode returning call293
  Object if292;
  if (istrue(call293)) {
// Begin line 110
  setline(110);
// Begin line 643
  setline(643);
// Begin line 110
  setline(110);
// compilenode returning *var_o
  Object call294 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call294
// compilenode returning call294
// Begin line 111
  setline(111);
// compilenode returning self
  params[0] = call294;
  Object call295 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call295
  *var_val = call295;
  if (call295 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if292 = nothing;
  } else {
  }
// compilenode returning if292
// Begin line 113
  setline(113);
// Begin line 112
  setline(112);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 114
  setline(114);
// Begin line 113
  setline(113);
// compilenode returning *var_auto_count
  Object num297 = alloc_Float64(1.0);
// compilenode returning num297
  params[0] = num297;
  Object sum299 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum299
  *var_auto_count = sum299;
  if (sum299 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 114
  setline(114);
// Begin line 643
  setline(643);
// Begin line 114
  setline(114);
// Begin line 643
  setline(643);
// Begin line 114
  setline(114);
// Begin line 643
  setline(643);
// Begin line 114
  setline(114);
// compilenode returning *var_o
  Object call301 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call301
// compilenode returning call301
  Object call302 = callmethod(call301, "value",
    0, params);
// compilenode returning call302
// compilenode returning call302
  Object call303 = callmethod(call302, "_escape",
    0, params);
// compilenode returning call303
// compilenode returning call303
  var_nm = alloc_var();
  *var_nm = call303;
  if (call303 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 115
  setline(115);
// Begin line 643
  setline(643);
// Begin line 115
  setline(115);
// Begin line 643
  setline(643);
// Begin line 115
  setline(115);
// compilenode returning *var_o
  Object call304 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call304
// compilenode returning call304
  Object call305 = callmethod(call304, "value",
    0, params);
// compilenode returning call305
// compilenode returning call305
// Begin line 116
  setline(116);
// compilenode returning self
  params[0] = call305;
  Object call306 = callmethod(self, "escapeident",
    1, params);
// compilenode returning call306
  var_nmi = alloc_var();
  *var_nmi = call306;
  if (call306 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit307 == NULL) {
    strlit307 = alloc_String("  ");
  }
// compilenode returning strlit307
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult309 = callmethod(strlit307, "++", 1, params);
// compilenode returning opresult309
  if (strlit310 == NULL) {
    strlit310 = alloc_String(".data[""\x22""");
  }
// compilenode returning strlit310
  params[0] = strlit310;
  Object opresult312 = callmethod(opresult309, "++", 1, params);
// compilenode returning opresult312
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult314 = callmethod(opresult312, "++", 1, params);
// compilenode returning opresult314
  if (strlit315 == NULL) {
    strlit315 = alloc_String("""\x22""] = ");
  }
// compilenode returning strlit315
  params[0] = strlit315;
  Object opresult317 = callmethod(opresult314, "++", 1, params);
// compilenode returning opresult317
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult319 = callmethod(opresult317, "++", 1, params);
// compilenode returning opresult319
  if (strlit320 == NULL) {
    strlit320 = alloc_String(";");
  }
// compilenode returning strlit320
  params[0] = strlit320;
  Object opresult322 = callmethod(opresult319, "++", 1, params);
// compilenode returning opresult322
// Begin line 117
  setline(117);
// compilenode returning self
  params[0] = opresult322;
  Object call323 = callmethod(self, "out",
    1, params);
// compilenode returning call323
  if (strlit324 == NULL) {
    strlit324 = alloc_String("    var reader_");
  }
// compilenode returning strlit324
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult326 = callmethod(strlit324, "++", 1, params);
// compilenode returning opresult326
  if (strlit327 == NULL) {
    strlit327 = alloc_String("_");
  }
// compilenode returning strlit327
  params[0] = strlit327;
  Object opresult329 = callmethod(opresult326, "++", 1, params);
// compilenode returning opresult329
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult331 = callmethod(opresult329, "++", 1, params);
// compilenode returning opresult331
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult333 = callmethod(opresult331, "++", 1, params);
// compilenode returning opresult333
  if (strlit334 == NULL) {
    strlit334 = alloc_String(" = function() {");
  }
// compilenode returning strlit334
  params[0] = strlit334;
  Object opresult336 = callmethod(opresult333, "++", 1, params);
// compilenode returning opresult336
// Begin line 118
  setline(118);
// compilenode returning self
  params[0] = opresult336;
  Object call337 = callmethod(self, "out",
    1, params);
// compilenode returning call337
  if (strlit338 == NULL) {
    strlit338 = alloc_String("    return this.data[""\x22""");
  }
// compilenode returning strlit338
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult340 = callmethod(strlit338, "++", 1, params);
// compilenode returning opresult340
  if (strlit341 == NULL) {
    strlit341 = alloc_String("""\x22""];");
  }
// compilenode returning strlit341
  params[0] = strlit341;
  Object opresult343 = callmethod(opresult340, "++", 1, params);
// compilenode returning opresult343
// Begin line 119
  setline(119);
// compilenode returning self
  params[0] = opresult343;
  Object call344 = callmethod(self, "out",
    1, params);
// compilenode returning call344
  if (strlit345 == NULL) {
    strlit345 = alloc_String("  }");
  }
// compilenode returning strlit345
// Begin line 120
  setline(120);
// compilenode returning self
  params[0] = strlit345;
  Object call346 = callmethod(self, "out",
    1, params);
// compilenode returning call346
// Begin line 121
  setline(121);
// Begin line 120
  setline(120);
  if (strlit347 == NULL) {
    strlit347 = alloc_String("  ");
  }
// compilenode returning strlit347
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult349 = callmethod(strlit347, "++", 1, params);
// compilenode returning opresult349
  if (strlit350 == NULL) {
    strlit350 = alloc_String(".methods[""\x22""");
  }
// compilenode returning strlit350
  params[0] = strlit350;
  Object opresult352 = callmethod(opresult349, "++", 1, params);
// compilenode returning opresult352
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult354 = callmethod(opresult352, "++", 1, params);
// compilenode returning opresult354
  if (strlit355 == NULL) {
    strlit355 = alloc_String("""\x22""] = reader_");
  }
// compilenode returning strlit355
  params[0] = strlit355;
  Object opresult357 = callmethod(opresult354, "++", 1, params);
// compilenode returning opresult357
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult359 = callmethod(opresult357, "++", 1, params);
// compilenode returning opresult359
// Begin line 121
  setline(121);
  if (strlit360 == NULL) {
    strlit360 = alloc_String("_");
  }
// compilenode returning strlit360
  params[0] = strlit360;
  Object opresult362 = callmethod(opresult359, "++", 1, params);
// compilenode returning opresult362
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult364 = callmethod(opresult362, "++", 1, params);
// compilenode returning opresult364
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult366 = callmethod(opresult364, "++", 1, params);
// compilenode returning opresult366
  if (strlit367 == NULL) {
    strlit367 = alloc_String(";");
  }
// compilenode returning strlit367
  params[0] = strlit367;
  Object opresult369 = callmethod(opresult366, "++", 1, params);
// compilenode returning opresult369
// Begin line 122
  setline(122);
// compilenode returning self
  params[0] = opresult369;
  Object call370 = callmethod(self, "out",
    1, params);
// compilenode returning call370
  if (strlit371 == NULL) {
    strlit371 = alloc_String("  ");
  }
// compilenode returning strlit371
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult373 = callmethod(strlit371, "++", 1, params);
// compilenode returning opresult373
  if (strlit374 == NULL) {
    strlit374 = alloc_String(".data[""\x22""");
  }
// compilenode returning strlit374
  params[0] = strlit374;
  Object opresult376 = callmethod(opresult373, "++", 1, params);
// compilenode returning opresult376
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult378 = callmethod(opresult376, "++", 1, params);
// compilenode returning opresult378
  if (strlit379 == NULL) {
    strlit379 = alloc_String("""\x22""] = ");
  }
// compilenode returning strlit379
  params[0] = strlit379;
  Object opresult381 = callmethod(opresult378, "++", 1, params);
// compilenode returning opresult381
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult383 = callmethod(opresult381, "++", 1, params);
// compilenode returning opresult383
  if (strlit384 == NULL) {
    strlit384 = alloc_String(";");
  }
// compilenode returning strlit384
  params[0] = strlit384;
  Object opresult386 = callmethod(opresult383, "++", 1, params);
// compilenode returning opresult386
// Begin line 123
  setline(123);
// compilenode returning self
  params[0] = opresult386;
  Object call387 = callmethod(self, "out",
    1, params);
// compilenode returning call387
  if (strlit388 == NULL) {
    strlit388 = alloc_String("  var writer_");
  }
// compilenode returning strlit388
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult390 = callmethod(strlit388, "++", 1, params);
// compilenode returning opresult390
  if (strlit391 == NULL) {
    strlit391 = alloc_String("_");
  }
// compilenode returning strlit391
  params[0] = strlit391;
  Object opresult393 = callmethod(opresult390, "++", 1, params);
// compilenode returning opresult393
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult395 = callmethod(opresult393, "++", 1, params);
// compilenode returning opresult395
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult397 = callmethod(opresult395, "++", 1, params);
// compilenode returning opresult397
  if (strlit398 == NULL) {
    strlit398 = alloc_String(" = function(o) {");
  }
// compilenode returning strlit398
  params[0] = strlit398;
  Object opresult400 = callmethod(opresult397, "++", 1, params);
// compilenode returning opresult400
// Begin line 124
  setline(124);
// compilenode returning self
  params[0] = opresult400;
  Object call401 = callmethod(self, "out",
    1, params);
// compilenode returning call401
  if (strlit402 == NULL) {
    strlit402 = alloc_String("    this.data[""\x22""");
  }
// compilenode returning strlit402
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult404 = callmethod(strlit402, "++", 1, params);
// compilenode returning opresult404
  if (strlit405 == NULL) {
    strlit405 = alloc_String("""\x22""] = o;");
  }
// compilenode returning strlit405
  params[0] = strlit405;
  Object opresult407 = callmethod(opresult404, "++", 1, params);
// compilenode returning opresult407
// Begin line 125
  setline(125);
// compilenode returning self
  params[0] = opresult407;
  Object call408 = callmethod(self, "out",
    1, params);
// compilenode returning call408
  if (strlit409 == NULL) {
    strlit409 = alloc_String("  }");
  }
// compilenode returning strlit409
// Begin line 126
  setline(126);
// compilenode returning self
  params[0] = strlit409;
  Object call410 = callmethod(self, "out",
    1, params);
// compilenode returning call410
// Begin line 127
  setline(127);
// Begin line 126
  setline(126);
  if (strlit411 == NULL) {
    strlit411 = alloc_String("  ");
  }
// compilenode returning strlit411
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult413 = callmethod(strlit411, "++", 1, params);
// compilenode returning opresult413
  if (strlit414 == NULL) {
    strlit414 = alloc_String(".methods[""\x22""");
  }
// compilenode returning strlit414
  params[0] = strlit414;
  Object opresult416 = callmethod(opresult413, "++", 1, params);
// compilenode returning opresult416
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult418 = callmethod(opresult416, "++", 1, params);
// compilenode returning opresult418
  if (strlit419 == NULL) {
    strlit419 = alloc_String(":=""\x22""] = writer_");
  }
// compilenode returning strlit419
  params[0] = strlit419;
  Object opresult421 = callmethod(opresult418, "++", 1, params);
// compilenode returning opresult421
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult423 = callmethod(opresult421, "++", 1, params);
// compilenode returning opresult423
// Begin line 127
  setline(127);
  if (strlit424 == NULL) {
    strlit424 = alloc_String("_");
  }
// compilenode returning strlit424
  params[0] = strlit424;
  Object opresult426 = callmethod(opresult423, "++", 1, params);
// compilenode returning opresult426
// compilenode returning *var_nmi
  params[0] = *var_nmi;
  Object opresult428 = callmethod(opresult426, "++", 1, params);
// compilenode returning opresult428
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult430 = callmethod(opresult428, "++", 1, params);
// compilenode returning opresult430
  if (strlit431 == NULL) {
    strlit431 = alloc_String(";");
  }
// compilenode returning strlit431
  params[0] = strlit431;
  Object opresult433 = callmethod(opresult430, "++", 1, params);
// compilenode returning opresult433
// Begin line 128
  setline(128);
// compilenode returning self
  params[0] = opresult433;
  Object call434 = callmethod(self, "out",
    1, params);
// compilenode returning call434
  return call434;
}
Object meth_genjs_compileclass435(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[4];
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_mbody = alloc_var();
  *var_mbody = undefined;
  Object *var_newmeth = alloc_var();
  *var_newmeth = undefined;
  Object *var_obody = alloc_var();
  *var_obody = undefined;
  Object *var_cobj = alloc_var();
  *var_cobj = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 131
  setline(131);
// Begin line 643
  setline(643);
// Begin line 130
  setline(130);
// compilenode returning *var_o
  Object call436 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call436
// compilenode returning call436
  var_params = alloc_var();
  *var_params = call436;
  if (call436 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 131
  setline(131);
  Object array437 = alloc_List();
// Begin line 643
  setline(643);
// Begin line 131
  setline(131);
// compilenode returning *var_o
  Object call438 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call438
// compilenode returning call438
// Begin line 643
  setline(643);
// Begin line 131
  setline(131);
// compilenode returning *var_o
  Object call439 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call439
// compilenode returning call439
// compilenode returning module_ast
  params[0] = call438;
  params[1] = call439;
  Object call440 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call440
  params[0] = call440;
  callmethod(array437, "push", 1, params);
// compilenode returning array437
  var_mbody = alloc_var();
  *var_mbody = array437;
  if (array437 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 133
  setline(133);
// Begin line 132
  setline(132);
  if (strlit441 == NULL) {
    strlit441 = alloc_String("new");
  }
// compilenode returning strlit441
  Object bool442 = alloc_Boolean(0);
// compilenode returning bool442
// compilenode returning module_ast
  params[0] = strlit441;
  params[1] = bool442;
  Object call443 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call443
// compilenode returning *var_params
// compilenode returning *var_mbody
// Begin line 133
  setline(133);
  Object bool444 = alloc_Boolean(0);
// compilenode returning bool444
// Begin line 132
  setline(132);
// compilenode returning module_ast
  params[0] = call443;
  params[1] = *var_params;
  params[2] = *var_mbody;
  params[3] = bool444;
  Object call445 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call445
  var_newmeth = alloc_var();
  *var_newmeth = call445;
  if (call445 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 134
  setline(134);
  Object array446 = alloc_List();
// compilenode returning *var_newmeth
  params[0] = *var_newmeth;
  callmethod(array446, "push", 1, params);
// compilenode returning array446
  var_obody = alloc_var();
  *var_obody = array446;
  if (array446 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 135
  setline(135);
// compilenode returning *var_obody
  Object bool447 = alloc_Boolean(0);
// compilenode returning bool447
// compilenode returning module_ast
  params[0] = *var_obody;
  params[1] = bool447;
  Object call448 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call448
  var_cobj = alloc_var();
  *var_cobj = call448;
  if (call448 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 136
  setline(136);
// Begin line 643
  setline(643);
// Begin line 136
  setline(136);
// compilenode returning *var_o
  Object call449 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call449
// compilenode returning call449
// compilenode returning *var_cobj
  Object bool450 = alloc_Boolean(0);
// compilenode returning bool450
// compilenode returning module_ast
  params[0] = call449;
  params[1] = *var_cobj;
  params[2] = bool450;
  Object call451 = callmethod(module_ast, "astdefdec",
    3, params);
// compilenode returning call451
  var_con = alloc_var();
  *var_con = call451;
  if (call451 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 137
  setline(137);
// Begin line 643
  setline(643);
// Begin line 137
  setline(137);
// compilenode returning *var_con
// Begin line 138
  setline(138);
// compilenode returning self
  params[0] = *var_con;
  Object call452 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call452
// Begin line 137
  setline(137);
// compilenode returning *var_o
  params[0] = call452;
  Object call453 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call453
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply486(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[3];
  Object *var_selfr = closure[0];
  Object *var_pos = closure[1];
  Object self = *closure[2];
// Begin line 154
  setline(154);
// Begin line 156
  setline(156);
// Begin line 643
  setline(643);
// Begin line 153
  setline(153);
// compilenode returning *var_e
  Object call488 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call488
// compilenode returning call488
  if (strlit489 == NULL) {
    strlit489 = alloc_String("method");
  }
// compilenode returning strlit489
  params[0] = strlit489;
  Object opresult491 = callmethod(call488, "==", 1, params);
// compilenode returning opresult491
  Object if487;
  if (istrue(opresult491)) {
// Begin line 154
  setline(154);
// compilenode returning *var_e
// compilenode returning *var_selfr
// Begin line 155
  setline(155);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  Object call492 = callmethod(self, "compilemethod",
    2, params);
// compilenode returning call492
    if487 = call492;
  } else {
  }
// compilenode returning if487
// Begin line 159
  setline(159);
// Begin line 160
  setline(160);
// Begin line 643
  setline(643);
// Begin line 156
  setline(156);
// compilenode returning *var_e
  Object call494 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call494
// compilenode returning call494
  if (strlit495 == NULL) {
    strlit495 = alloc_String("vardec");
  }
// compilenode returning strlit495
  params[0] = strlit495;
  Object opresult497 = callmethod(call494, "==", 1, params);
// compilenode returning opresult497
  Object if493;
  if (istrue(opresult497)) {
// Begin line 157
  setline(157);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 158
  setline(158);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call498 = callmethod(self, "compileobjvardec",
    3, params);
// compilenode returning call498
// Begin line 159
  setline(159);
// Begin line 158
  setline(158);
// compilenode returning *var_pos
  Object num499 = alloc_Float64(1.0);
// compilenode returning num499
  params[0] = num499;
  Object sum501 = callmethod(*var_pos, "+", 1, params);
// compilenode returning sum501
  *var_pos = sum501;
  if (sum501 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if493 = nothing;
  } else {
  }
// compilenode returning if493
// Begin line 163
  setline(163);
// Begin line 164
  setline(164);
// Begin line 643
  setline(643);
// Begin line 160
  setline(160);
// compilenode returning *var_e
  Object call504 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call504
// compilenode returning call504
  if (strlit505 == NULL) {
    strlit505 = alloc_String("defdec");
  }
// compilenode returning strlit505
  params[0] = strlit505;
  Object opresult507 = callmethod(call504, "==", 1, params);
// compilenode returning opresult507
  Object if503;
  if (istrue(opresult507)) {
// Begin line 161
  setline(161);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 162
  setline(162);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call508 = callmethod(self, "compileobjdefdec",
    3, params);
// compilenode returning call508
// Begin line 163
  setline(163);
// Begin line 162
  setline(162);
// compilenode returning *var_pos
  Object num509 = alloc_Float64(1.0);
// compilenode returning num509
  params[0] = num509;
  Object sum511 = callmethod(*var_pos, "+", 1, params);
// compilenode returning sum511
  *var_pos = sum511;
  if (sum511 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if503 = nothing;
  } else {
  }
// compilenode returning if503
  return if503;
}
Object meth_genjs_compileobject454(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_selfr = alloc_var();
  *var_selfr = undefined;
  Object *var_pos = alloc_var();
  *var_pos = undefined;
// Begin line 141
  setline(141);
// Begin line 140
  setline(140);
// compilenode returning *var_inBlock
  var_origInBlock = alloc_var();
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 142
  setline(142);
// Begin line 141
  setline(141);
  Object bool455 = alloc_Boolean(0);
// compilenode returning bool455
  *var_inBlock = bool455;
  if (bool455 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 143
  setline(143);
// Begin line 142
  setline(142);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 144
  setline(144);
// Begin line 143
  setline(143);
// compilenode returning *var_auto_count
  Object num457 = alloc_Float64(1.0);
// compilenode returning num457
  params[0] = num457;
  Object sum459 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum459
  *var_auto_count = sum459;
  if (sum459 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 145
  setline(145);
// Begin line 144
  setline(144);
  if (strlit461 == NULL) {
    strlit461 = alloc_String("obj");
  }
// compilenode returning strlit461
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult463 = callmethod(strlit461, "++", 1, params);
// compilenode returning opresult463
  var_selfr = alloc_var();
  *var_selfr = opresult463;
  if (opresult463 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 148
  setline(148);
// Begin line 150
  setline(150);
// Begin line 643
  setline(643);
// Begin line 145
  setline(145);
// compilenode returning *var_o
  Object call465 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call465
// compilenode returning call465
  Object bool466 = alloc_Boolean(0);
// compilenode returning bool466
  params[0] = bool466;
  Object opresult468 = callmethod(call465, "/=", 1, params);
// compilenode returning opresult468
  Object if464;
  if (istrue(opresult468)) {
// Begin line 146
  setline(146);
// Begin line 643
  setline(643);
// Begin line 146
  setline(146);
// compilenode returning *var_o
  Object call469 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call469
// compilenode returning call469
// Begin line 147
  setline(147);
// compilenode returning self
  params[0] = call469;
  Object call470 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call470
  *var_selfr = call470;
  if (call470 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if464 = nothing;
  } else {
// Begin line 148
  setline(148);
  if (strlit472 == NULL) {
    strlit472 = alloc_String("  var ");
  }
// compilenode returning strlit472
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult474 = callmethod(strlit472, "++", 1, params);
// compilenode returning opresult474
  if (strlit475 == NULL) {
    strlit475 = alloc_String(" = Grace_allocObject();");
  }
// compilenode returning strlit475
  params[0] = strlit475;
  Object opresult477 = callmethod(opresult474, "++", 1, params);
// compilenode returning opresult477
// Begin line 149
  setline(149);
// compilenode returning self
  params[0] = opresult477;
  Object call478 = callmethod(self, "out",
    1, params);
// compilenode returning call478
    if464 = call478;
  }
// compilenode returning if464
// Begin line 150
  setline(150);
// compilenode returning *var_selfr
// Begin line 151
  setline(151);
// compilenode returning self
  params[0] = *var_selfr;
  Object call479 = callmethod(self, "compileobjouter",
    1, params);
// compilenode returning call479
// Begin line 152
  setline(152);
// Begin line 151
  setline(151);
  Object num480 = alloc_Float64(0.0);
// compilenode returning num480
  var_pos = alloc_var();
  *var_pos = num480;
  if (num480 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 163
  setline(163);
// Begin line 165
  setline(165);
// Begin line 643
  setline(643);
// Begin line 152
  setline(152);
// compilenode returning *var_o
  Object call482 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call482
// compilenode returning call482
// Begin line 163
  setline(163);
// Begin line 643
  setline(643);
  Object obj484 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj484, self, 0);
  addmethod2(obj484, "outer", &reader_genjs_outer_485);
  adddatum2(obj484, self, 0);
  block_savedest(obj484);
  Object **closure486 = createclosure(3);
  addtoclosure(closure486, var_selfr);
  addtoclosure(closure486, var_pos);
  Object *selfpp513 = alloc_var();
  *selfpp513 = self;
  addtoclosure(closure486, selfpp513);
  struct UserObject *uo486 = (struct UserObject*)obj484;
  uo486->data[1] = (Object)closure486;
  addmethod2(obj484, "apply", &meth_genjs_apply486);
  set_type(obj484, 0);
// compilenode returning obj484
  setclassname(obj484, "Block<genjs:483>");
// compilenode returning obj484
  params[0] = call482;
  Object iter481 = callmethod(call482, "iter", 1, params);
  while(1) {
    Object cond481 = callmethod(iter481, "havemore", 0, NULL);
    if (!istrue(cond481)) break;
    params[0] = callmethod(iter481, "next", 0, NULL);
    callmethod(obj484, "apply", 1, params);
  }
// compilenode returning call482
// Begin line 166
  setline(166);
// Begin line 643
  setline(643);
// Begin line 165
  setline(165);
// compilenode returning *var_selfr
// compilenode returning *var_o
  params[0] = *var_selfr;
  Object call514 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call514
// compilenode returning nothing
// Begin line 167
  setline(167);
// Begin line 166
  setline(166);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply561(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_first = closure[0];
  Object self = *closure[1];
// Begin line 182
  setline(182);
// Begin line 184
  setline(184);
// Begin line 643
  setline(643);
// Begin line 181
  setline(181);
// compilenode returning *var_first
  Object call563 = callmethod(*var_first, "not",
    0, params);
// compilenode returning call563
// compilenode returning call563
  Object if562;
  if (istrue(call563)) {
// Begin line 182
  setline(182);
  if (strlit564 == NULL) {
    strlit564 = alloc_String(",");
  }
// compilenode returning strlit564
// Begin line 183
  setline(183);
// compilenode returning self
  params[0] = strlit564;
  Object call565 = callmethod(self, "out",
    1, params);
// compilenode returning call565
    if562 = call565;
  } else {
  }
// compilenode returning if562
// Begin line 185
  setline(185);
// Begin line 184
  setline(184);
  Object bool566 = alloc_Boolean(0);
// compilenode returning bool566
  *var_first = bool566;
  if (bool566 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 185
  setline(185);
// Begin line 643
  setline(643);
// Begin line 185
  setline(185);
// compilenode returning *var_p
  Object call568 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call568
// compilenode returning call568
// compilenode returning self
  params[0] = call568;
  Object call569 = callmethod(self, "varf",
    1, params);
// compilenode returning call569
// Begin line 186
  setline(186);
// compilenode returning self
  params[0] = call569;
  Object call570 = callmethod(self, "out",
    1, params);
// compilenode returning call570
  return call570;
}
Object meth_genjs_apply580(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_ret = closure[0];
  Object self = *closure[1];
// Begin line 190
  setline(190);
// compilenode returning *var_l
// Begin line 191
  setline(191);
// compilenode returning self
  params[0] = *var_l;
  Object call581 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call581
  *var_ret = call581;
  if (call581 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileblock516(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_first = alloc_var();
  *var_first = undefined;
  Object *var_ret = alloc_var();
  *var_ret = undefined;
// Begin line 170
  setline(170);
// Begin line 169
  setline(169);
// compilenode returning *var_inBlock
  var_origInBlock = alloc_var();
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 171
  setline(171);
// Begin line 170
  setline(170);
  Object bool517 = alloc_Boolean(1);
// compilenode returning bool517
  *var_inBlock = bool517;
  if (bool517 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 172
  setline(172);
// Begin line 171
  setline(171);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 173
  setline(173);
// Begin line 172
  setline(172);
// compilenode returning *var_auto_count
  Object num519 = alloc_Float64(1.0);
// compilenode returning num519
  params[0] = num519;
  Object sum521 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum521
  *var_auto_count = sum521;
  if (sum521 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 173
  setline(173);
  if (strlit523 == NULL) {
    strlit523 = alloc_String("  var block");
  }
// compilenode returning strlit523
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult525 = callmethod(strlit523, "++", 1, params);
// compilenode returning opresult525
  if (strlit526 == NULL) {
    strlit526 = alloc_String(" = Grace_allocObject();");
  }
// compilenode returning strlit526
  params[0] = strlit526;
  Object opresult528 = callmethod(opresult525, "++", 1, params);
// compilenode returning opresult528
// Begin line 174
  setline(174);
// compilenode returning self
  params[0] = opresult528;
  Object call529 = callmethod(self, "out",
    1, params);
// compilenode returning call529
  if (strlit530 == NULL) {
    strlit530 = alloc_String("  block");
  }
// compilenode returning strlit530
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult532 = callmethod(strlit530, "++", 1, params);
// compilenode returning opresult532
  if (strlit533 == NULL) {
    strlit533 = alloc_String(".methods[""\x22""apply""\x22""] = function() {");
  }
// compilenode returning strlit533
  params[0] = strlit533;
  Object opresult535 = callmethod(opresult532, "++", 1, params);
// compilenode returning opresult535
// Begin line 175
  setline(175);
// compilenode returning self
  params[0] = opresult535;
  Object call536 = callmethod(self, "out",
    1, params);
// compilenode returning call536
  if (strlit537 == NULL) {
    strlit537 = alloc_String("    return this.real.apply(this.receiver, arguments);");
  }
// compilenode returning strlit537
// Begin line 176
  setline(176);
// compilenode returning self
  params[0] = strlit537;
  Object call538 = callmethod(self, "out",
    1, params);
// compilenode returning call538
  if (strlit539 == NULL) {
    strlit539 = alloc_String("  }");
  }
// compilenode returning strlit539
// Begin line 177
  setline(177);
// compilenode returning self
  params[0] = strlit539;
  Object call540 = callmethod(self, "out",
    1, params);
// compilenode returning call540
  if (strlit541 == NULL) {
    strlit541 = alloc_String("  block");
  }
// compilenode returning strlit541
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult543 = callmethod(strlit541, "++", 1, params);
// compilenode returning opresult543
  if (strlit544 == NULL) {
    strlit544 = alloc_String(".receiver = this;");
  }
// compilenode returning strlit544
  params[0] = strlit544;
  Object opresult546 = callmethod(opresult543, "++", 1, params);
// compilenode returning opresult546
// Begin line 178
  setline(178);
// compilenode returning self
  params[0] = opresult546;
  Object call547 = callmethod(self, "out",
    1, params);
// compilenode returning call547
  if (strlit548 == NULL) {
    strlit548 = alloc_String("  block");
  }
// compilenode returning strlit548
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult550 = callmethod(strlit548, "++", 1, params);
// compilenode returning opresult550
  if (strlit551 == NULL) {
    strlit551 = alloc_String(".real = function(");
  }
// compilenode returning strlit551
  params[0] = strlit551;
  Object opresult553 = callmethod(opresult550, "++", 1, params);
// compilenode returning opresult553
// Begin line 179
  setline(179);
// compilenode returning self
  params[0] = opresult553;
  Object call554 = callmethod(self, "out",
    1, params);
// compilenode returning call554
// Begin line 180
  setline(180);
// Begin line 179
  setline(179);
  Object bool555 = alloc_Boolean(1);
// compilenode returning bool555
  var_first = alloc_var();
  *var_first = bool555;
  if (bool555 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 185
  setline(185);
// Begin line 187
  setline(187);
// Begin line 643
  setline(643);
// Begin line 180
  setline(180);
// compilenode returning *var_o
  Object call557 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call557
// compilenode returning call557
// Begin line 185
  setline(185);
// Begin line 643
  setline(643);
  Object obj559 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj559, self, 0);
  addmethod2(obj559, "outer", &reader_genjs_outer_560);
  adddatum2(obj559, self, 0);
  block_savedest(obj559);
  Object **closure561 = createclosure(2);
  addtoclosure(closure561, var_first);
  Object *selfpp571 = alloc_var();
  *selfpp571 = self;
  addtoclosure(closure561, selfpp571);
  struct UserObject *uo561 = (struct UserObject*)obj559;
  uo561->data[1] = (Object)closure561;
  addmethod2(obj559, "apply", &meth_genjs_apply561);
  set_type(obj559, 0);
// compilenode returning obj559
  setclassname(obj559, "Block<genjs:558>");
// compilenode returning obj559
  params[0] = call557;
  Object iter556 = callmethod(call557, "iter", 1, params);
  while(1) {
    Object cond556 = callmethod(iter556, "havemore", 0, NULL);
    if (!istrue(cond556)) break;
    params[0] = callmethod(iter556, "next", 0, NULL);
    callmethod(obj559, "apply", 1, params);
  }
// compilenode returning call557
// Begin line 187
  setline(187);
  if (strlit572 == NULL) {
    strlit572 = alloc_String(") {");
  }
// compilenode returning strlit572
// Begin line 188
  setline(188);
// compilenode returning self
  params[0] = strlit572;
  Object call573 = callmethod(self, "out",
    1, params);
// compilenode returning call573
// Begin line 189
  setline(189);
// Begin line 188
  setline(188);
  if (strlit574 == NULL) {
    strlit574 = alloc_String("undefined");
  }
// compilenode returning strlit574
  var_ret = alloc_var();
  *var_ret = strlit574;
  if (strlit574 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 190
  setline(190);
// Begin line 192
  setline(192);
// Begin line 643
  setline(643);
// Begin line 189
  setline(189);
// compilenode returning *var_o
  Object call576 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call576
// compilenode returning call576
// Begin line 190
  setline(190);
// Begin line 643
  setline(643);
  Object obj578 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj578, self, 0);
  addmethod2(obj578, "outer", &reader_genjs_outer_579);
  adddatum2(obj578, self, 0);
  block_savedest(obj578);
  Object **closure580 = createclosure(2);
  addtoclosure(closure580, var_ret);
  Object *selfpp583 = alloc_var();
  *selfpp583 = self;
  addtoclosure(closure580, selfpp583);
  struct UserObject *uo580 = (struct UserObject*)obj578;
  uo580->data[1] = (Object)closure580;
  addmethod2(obj578, "apply", &meth_genjs_apply580);
  set_type(obj578, 0);
// compilenode returning obj578
  setclassname(obj578, "Block<genjs:577>");
// compilenode returning obj578
  params[0] = call576;
  Object iter575 = callmethod(call576, "iter", 1, params);
  while(1) {
    Object cond575 = callmethod(iter575, "havemore", 0, NULL);
    if (!istrue(cond575)) break;
    params[0] = callmethod(iter575, "next", 0, NULL);
    callmethod(obj578, "apply", 1, params);
  }
// compilenode returning call576
// Begin line 192
  setline(192);
  if (strlit584 == NULL) {
    strlit584 = alloc_String("  return ");
  }
// compilenode returning strlit584
// compilenode returning *var_ret
  params[0] = *var_ret;
  Object opresult586 = callmethod(strlit584, "++", 1, params);
// compilenode returning opresult586
  if (strlit587 == NULL) {
    strlit587 = alloc_String(";");
  }
// compilenode returning strlit587
  params[0] = strlit587;
  Object opresult589 = callmethod(opresult586, "++", 1, params);
// compilenode returning opresult589
// Begin line 193
  setline(193);
// compilenode returning self
  params[0] = opresult589;
  Object call590 = callmethod(self, "out",
    1, params);
// compilenode returning call590
  if (strlit591 == NULL) {
    strlit591 = alloc_String("};");
  }
// compilenode returning strlit591
// Begin line 194
  setline(194);
// compilenode returning self
  params[0] = strlit591;
  Object call592 = callmethod(self, "out",
    1, params);
// compilenode returning call592
// Begin line 195
  setline(195);
// Begin line 643
  setline(643);
// Begin line 195
  setline(195);
// Begin line 194
  setline(194);
  if (strlit593 == NULL) {
    strlit593 = alloc_String("block");
  }
// compilenode returning strlit593
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult595 = callmethod(strlit593, "++", 1, params);
// compilenode returning opresult595
// compilenode returning *var_o
  params[0] = opresult595;
  Object call596 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call596
// compilenode returning nothing
// Begin line 196
  setline(196);
// Begin line 195
  setline(195);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compilefor598(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_over = alloc_var();
  *var_over = undefined;
  Object *var_blk = alloc_var();
  *var_blk = undefined;
  Object *var_blko = alloc_var();
  *var_blko = undefined;
// Begin line 199
  setline(199);
// Begin line 198
  setline(198);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 200
  setline(200);
// Begin line 199
  setline(199);
// compilenode returning *var_auto_count
  Object num599 = alloc_Float64(1.0);
// compilenode returning num599
  params[0] = num599;
  Object sum601 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum601
  *var_auto_count = sum601;
  if (sum601 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 200
  setline(200);
// Begin line 643
  setline(643);
// Begin line 200
  setline(200);
// compilenode returning *var_o
  Object call603 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call603
// compilenode returning call603
// Begin line 201
  setline(201);
// compilenode returning self
  params[0] = call603;
  Object call604 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call604
  var_over = alloc_var();
  *var_over = call604;
  if (call604 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 202
  setline(202);
// Begin line 643
  setline(643);
// Begin line 201
  setline(201);
// compilenode returning *var_o
  Object call605 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call605
// compilenode returning call605
  var_blk = alloc_var();
  *var_blk = call605;
  if (call605 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 202
  setline(202);
// compilenode returning *var_blk
// Begin line 203
  setline(203);
// compilenode returning self
  params[0] = *var_blk;
  Object call606 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call606
  var_blko = alloc_var();
  *var_blko = call606;
  if (call606 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 204
  setline(204);
// Begin line 203
  setline(203);
  if (strlit607 == NULL) {
    strlit607 = alloc_String("  var it");
  }
// compilenode returning strlit607
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult609 = callmethod(strlit607, "++", 1, params);
// compilenode returning opresult609
  if (strlit610 == NULL) {
    strlit610 = alloc_String(" = ");
  }
// compilenode returning strlit610
  params[0] = strlit610;
  Object opresult612 = callmethod(opresult609, "++", 1, params);
// compilenode returning opresult612
// compilenode returning *var_over
  params[0] = *var_over;
  Object opresult614 = callmethod(opresult612, "++", 1, params);
// compilenode returning opresult614
  if (strlit615 == NULL) {
    strlit615 = alloc_String(".methods[""\x22""iterator""\x22""].call(");
  }
// compilenode returning strlit615
  params[0] = strlit615;
  Object opresult617 = callmethod(opresult614, "++", 1, params);
// compilenode returning opresult617
// Begin line 204
  setline(204);
// compilenode returning *var_over
  params[0] = *var_over;
  Object opresult619 = callmethod(opresult617, "++", 1, params);
// compilenode returning opresult619
  if (strlit620 == NULL) {
    strlit620 = alloc_String(");");
  }
// compilenode returning strlit620
  params[0] = strlit620;
  Object opresult622 = callmethod(opresult619, "++", 1, params);
// compilenode returning opresult622
// Begin line 205
  setline(205);
// compilenode returning self
  params[0] = opresult622;
  Object call623 = callmethod(self, "out",
    1, params);
// compilenode returning call623
// Begin line 206
  setline(206);
// Begin line 205
  setline(205);
  if (strlit624 == NULL) {
    strlit624 = alloc_String("while (Grace_isTrue(it");
  }
// compilenode returning strlit624
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult626 = callmethod(strlit624, "++", 1, params);
// compilenode returning opresult626
  if (strlit627 == NULL) {
    strlit627 = alloc_String(".methods[""\x22""havemore""\x22""].call(");
  }
// compilenode returning strlit627
  params[0] = strlit627;
  Object opresult629 = callmethod(opresult626, "++", 1, params);
// compilenode returning opresult629
// Begin line 206
  setline(206);
  if (strlit630 == NULL) {
    strlit630 = alloc_String("it");
  }
// compilenode returning strlit630
  params[0] = strlit630;
  Object opresult632 = callmethod(opresult629, "++", 1, params);
// compilenode returning opresult632
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult634 = callmethod(opresult632, "++", 1, params);
// compilenode returning opresult634
  if (strlit635 == NULL) {
    strlit635 = alloc_String("))) {");
  }
// compilenode returning strlit635
  params[0] = strlit635;
  Object opresult637 = callmethod(opresult634, "++", 1, params);
// compilenode returning opresult637
// Begin line 207
  setline(207);
// compilenode returning self
  params[0] = opresult637;
  Object call638 = callmethod(self, "out",
    1, params);
// compilenode returning call638
// Begin line 208
  setline(208);
// Begin line 207
  setline(207);
  if (strlit639 == NULL) {
    strlit639 = alloc_String("    var fv");
  }
// compilenode returning strlit639
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult641 = callmethod(strlit639, "++", 1, params);
// compilenode returning opresult641
  if (strlit642 == NULL) {
    strlit642 = alloc_String(" = it");
  }
// compilenode returning strlit642
  params[0] = strlit642;
  Object opresult644 = callmethod(opresult641, "++", 1, params);
// compilenode returning opresult644
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult646 = callmethod(opresult644, "++", 1, params);
// compilenode returning opresult646
  if (strlit647 == NULL) {
    strlit647 = alloc_String(".methods[""\x22""next""\x22""].call(");
  }
// compilenode returning strlit647
  params[0] = strlit647;
  Object opresult649 = callmethod(opresult646, "++", 1, params);
// compilenode returning opresult649
// Begin line 208
  setline(208);
  if (strlit650 == NULL) {
    strlit650 = alloc_String("it");
  }
// compilenode returning strlit650
  params[0] = strlit650;
  Object opresult652 = callmethod(opresult649, "++", 1, params);
// compilenode returning opresult652
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult654 = callmethod(opresult652, "++", 1, params);
// compilenode returning opresult654
  if (strlit655 == NULL) {
    strlit655 = alloc_String(");");
  }
// compilenode returning strlit655
  params[0] = strlit655;
  Object opresult657 = callmethod(opresult654, "++", 1, params);
// compilenode returning opresult657
// Begin line 209
  setline(209);
// compilenode returning self
  params[0] = opresult657;
  Object call658 = callmethod(self, "out",
    1, params);
// compilenode returning call658
  if (strlit659 == NULL) {
    strlit659 = alloc_String("    ");
  }
// compilenode returning strlit659
// compilenode returning *var_blko
  params[0] = *var_blko;
  Object opresult661 = callmethod(strlit659, "++", 1, params);
// compilenode returning opresult661
  if (strlit662 == NULL) {
    strlit662 = alloc_String(".methods[""\x22""apply""\x22""].call(");
  }
// compilenode returning strlit662
  params[0] = strlit662;
  Object opresult664 = callmethod(opresult661, "++", 1, params);
// compilenode returning opresult664
// compilenode returning *var_blko
  params[0] = *var_blko;
  Object opresult666 = callmethod(opresult664, "++", 1, params);
// compilenode returning opresult666
  if (strlit667 == NULL) {
    strlit667 = alloc_String(", fv");
  }
// compilenode returning strlit667
  params[0] = strlit667;
  Object opresult669 = callmethod(opresult666, "++", 1, params);
// compilenode returning opresult669
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult671 = callmethod(opresult669, "++", 1, params);
// compilenode returning opresult671
  if (strlit672 == NULL) {
    strlit672 = alloc_String(");");
  }
// compilenode returning strlit672
  params[0] = strlit672;
  Object opresult674 = callmethod(opresult671, "++", 1, params);
// compilenode returning opresult674
// Begin line 210
  setline(210);
// compilenode returning self
  params[0] = opresult674;
  Object call675 = callmethod(self, "out",
    1, params);
// compilenode returning call675
  if (strlit676 == NULL) {
    strlit676 = alloc_String("  }");
  }
// compilenode returning strlit676
// Begin line 211
  setline(211);
// compilenode returning self
  params[0] = strlit676;
  Object call677 = callmethod(self, "out",
    1, params);
// compilenode returning call677
// Begin line 212
  setline(212);
// Begin line 643
  setline(643);
// Begin line 211
  setline(211);
// compilenode returning *var_over
// compilenode returning *var_o
  params[0] = *var_over;
  Object call678 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call678
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply707(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_first = closure[0];
  Object self = *closure[1];
// Begin line 227
  setline(227);
// Begin line 229
  setline(229);
// Begin line 643
  setline(643);
// Begin line 226
  setline(226);
// compilenode returning *var_first
  Object call709 = callmethod(*var_first, "not",
    0, params);
// compilenode returning call709
// compilenode returning call709
  Object if708;
  if (istrue(call709)) {
// Begin line 227
  setline(227);
  if (strlit710 == NULL) {
    strlit710 = alloc_String(",");
  }
// compilenode returning strlit710
// Begin line 228
  setline(228);
// compilenode returning self
  params[0] = strlit710;
  Object call711 = callmethod(self, "out",
    1, params);
// compilenode returning call711
    if708 = call711;
  } else {
  }
// compilenode returning if708
// Begin line 229
  setline(229);
// Begin line 643
  setline(643);
// Begin line 229
  setline(229);
// compilenode returning *var_p
  Object call712 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call712
// compilenode returning call712
// compilenode returning self
  params[0] = call712;
  Object call713 = callmethod(self, "varf",
    1, params);
// compilenode returning call713
// Begin line 230
  setline(230);
// compilenode returning self
  params[0] = call713;
  Object call714 = callmethod(self, "out",
    1, params);
// compilenode returning call714
// Begin line 231
  setline(231);
// Begin line 230
  setline(230);
  Object bool715 = alloc_Boolean(0);
// compilenode returning bool715
  *var_first = bool715;
  if (bool715 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply754(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_ret = closure[0];
  Object self = *closure[1];
// Begin line 242
  setline(242);
// compilenode returning *var_l
// Begin line 243
  setline(243);
// compilenode returning self
  params[0] = *var_l;
  Object call755 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call755
  *var_ret = call755;
  if (call755 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compilemethod679(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfobj = alloc_var();
  *var_selfobj = args[1];
  Object params[1];
  Object *var_usedvars = closure[0];
  Object *var_declaredvars = closure[1];
  Object *var_auto_count = closure[2];
  Object *var_oldusedvars = alloc_var();
  *var_oldusedvars = undefined;
  Object *var_olddeclaredvars = alloc_var();
  *var_olddeclaredvars = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_name = alloc_var();
  *var_name = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_closurevars = alloc_var();
  *var_closurevars = undefined;
  Object *var_first = alloc_var();
  *var_first = undefined;
  Object *var_ret = alloc_var();
  *var_ret = undefined;
// Begin line 215
  setline(215);
// Begin line 214
  setline(214);
// compilenode returning *var_usedvars
  var_oldusedvars = alloc_var();
  *var_oldusedvars = *var_usedvars;
  if (*var_usedvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 216
  setline(216);
// Begin line 215
  setline(215);
// compilenode returning *var_declaredvars
  var_olddeclaredvars = alloc_var();
  *var_olddeclaredvars = *var_declaredvars;
  if (*var_declaredvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 217
  setline(217);
  Object array680 = alloc_List();
// compilenode returning array680
  *var_usedvars = array680;
  if (array680 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 218
  setline(218);
  Object array682 = alloc_List();
// compilenode returning array682
  *var_declaredvars = array682;
  if (array682 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 219
  setline(219);
// Begin line 218
  setline(218);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 220
  setline(220);
// Begin line 219
  setline(219);
// compilenode returning *var_auto_count
  Object num684 = alloc_Float64(1.0);
// compilenode returning num684
  params[0] = num684;
  Object sum686 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum686
  *var_auto_count = sum686;
  if (sum686 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 220
  setline(220);
// Begin line 643
  setline(643);
// Begin line 220
  setline(220);
// Begin line 643
  setline(643);
// Begin line 220
  setline(220);
// Begin line 643
  setline(643);
// Begin line 220
  setline(220);
// compilenode returning *var_o
  Object call688 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call688
// compilenode returning call688
  Object call689 = callmethod(call688, "value",
    0, params);
// compilenode returning call689
// compilenode returning call689
  Object call690 = callmethod(call689, "_escape",
    0, params);
// compilenode returning call690
// compilenode returning call690
  var_name = alloc_var();
  *var_name = call690;
  if (call690 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 222
  setline(222);
// Begin line 221
  setline(221);
// compilenode returning *var_name
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult692 = callmethod(*var_name, "++", 1, params);
// compilenode returning opresult692
  var_nm = alloc_var();
  *var_nm = opresult692;
  if (opresult692 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 223
  setline(223);
  Object array693 = alloc_List();
// compilenode returning array693
  var_closurevars = alloc_var();
  *var_closurevars = array693;
  if (array693 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit694 == NULL) {
    strlit694 = alloc_String("var func");
  }
// compilenode returning strlit694
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult696 = callmethod(strlit694, "++", 1, params);
// compilenode returning opresult696
  if (strlit697 == NULL) {
    strlit697 = alloc_String(" = function(");
  }
// compilenode returning strlit697
  params[0] = strlit697;
  Object opresult699 = callmethod(opresult696, "++", 1, params);
// compilenode returning opresult699
// Begin line 224
  setline(224);
// compilenode returning self
  params[0] = opresult699;
  Object call700 = callmethod(self, "out",
    1, params);
// compilenode returning call700
// Begin line 225
  setline(225);
// Begin line 224
  setline(224);
  Object bool701 = alloc_Boolean(1);
// compilenode returning bool701
  var_first = alloc_var();
  *var_first = bool701;
  if (bool701 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 231
  setline(231);
// Begin line 232
  setline(232);
// Begin line 643
  setline(643);
// Begin line 225
  setline(225);
// compilenode returning *var_o
  Object call703 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call703
// compilenode returning call703
// Begin line 231
  setline(231);
// Begin line 643
  setline(643);
  Object obj705 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj705, self, 0);
  addmethod2(obj705, "outer", &reader_genjs_outer_706);
  adddatum2(obj705, self, 0);
  block_savedest(obj705);
  Object **closure707 = createclosure(2);
  addtoclosure(closure707, var_first);
  Object *selfpp717 = alloc_var();
  *selfpp717 = self;
  addtoclosure(closure707, selfpp717);
  struct UserObject *uo707 = (struct UserObject*)obj705;
  uo707->data[1] = (Object)closure707;
  addmethod2(obj705, "apply", &meth_genjs_apply707);
  set_type(obj705, 0);
// compilenode returning obj705
  setclassname(obj705, "Block<genjs:704>");
// compilenode returning obj705
  params[0] = call703;
  Object iter702 = callmethod(call703, "iter", 1, params);
  while(1) {
    Object cond702 = callmethod(iter702, "havemore", 0, NULL);
    if (!istrue(cond702)) break;
    params[0] = callmethod(iter702, "next", 0, NULL);
    callmethod(obj705, "apply", 1, params);
  }
// compilenode returning call703
// Begin line 232
  setline(232);
  if (strlit718 == NULL) {
    strlit718 = alloc_String(") {");
  }
// compilenode returning strlit718
// Begin line 233
  setline(233);
// compilenode returning self
  params[0] = strlit718;
  Object call719 = callmethod(self, "out",
    1, params);
// compilenode returning call719
// Begin line 234
  setline(234);
// Begin line 237
  setline(237);
// Begin line 643
  setline(643);
// Begin line 233
  setline(233);
// compilenode returning *var_o
  Object call721 = callmethod(*var_o, "varargs",
    0, params);
// compilenode returning call721
// compilenode returning call721
  Object if720;
  if (istrue(call721)) {
// Begin line 234
  setline(234);
  if (strlit722 == NULL) {
    strlit722 = alloc_String("  var ");
  }
// compilenode returning strlit722
// Begin line 643
  setline(643);
// Begin line 234
  setline(234);
// Begin line 643
  setline(643);
// Begin line 234
  setline(234);
// compilenode returning *var_o
  Object call723 = callmethod(*var_o, "vararg",
    0, params);
// compilenode returning call723
// compilenode returning call723
  Object call724 = callmethod(call723, "value",
    0, params);
// compilenode returning call724
// compilenode returning call724
// Begin line 235
  setline(235);
// compilenode returning self
  params[0] = call724;
  Object call725 = callmethod(self, "varf",
    1, params);
// compilenode returning call725
  params[0] = call725;
  Object opresult727 = callmethod(strlit722, "++", 1, params);
// compilenode returning opresult727
// Begin line 234
  setline(234);
  if (strlit728 == NULL) {
    strlit728 = alloc_String(" = new GraceList(Array.prototype.slice");
  }
// compilenode returning strlit728
  params[0] = strlit728;
  Object opresult730 = callmethod(opresult727, "++", 1, params);
// compilenode returning opresult730
// Begin line 235
  setline(235);
  if (strlit731 == NULL) {
    strlit731 = alloc_String(".call(arguments, ");
  }
// compilenode returning strlit731
// Begin line 234
  setline(234);
// Begin line 643
  setline(643);
// Begin line 234
  setline(234);
// Begin line 643
  setline(643);
// Begin line 235
  setline(235);
// compilenode returning *var_o
  Object call732 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call732
// compilenode returning call732
  Object call733 = callmethod(call732, "size",
    0, params);
// compilenode returning call733
// compilenode returning call733
  params[0] = call733;
  Object opresult735 = callmethod(strlit731, "++", 1, params);
// compilenode returning opresult735
  if (strlit736 == NULL) {
    strlit736 = alloc_String("));");
  }
// compilenode returning strlit736
  params[0] = strlit736;
  Object opresult738 = callmethod(opresult735, "++", 1, params);
// compilenode returning opresult738
  params[0] = opresult738;
  Object opresult740 = callmethod(opresult730, "++", 1, params);
// compilenode returning opresult740
// Begin line 236
  setline(236);
// compilenode returning self
  params[0] = opresult740;
  Object call741 = callmethod(self, "out",
    1, params);
// compilenode returning call741
    if720 = call741;
  } else {
  }
// compilenode returning if720
// Begin line 237
  setline(237);
  if (strlit742 == NULL) {
    strlit742 = alloc_String("  var returnTarget = invocationCount;");
  }
// compilenode returning strlit742
// Begin line 238
  setline(238);
// compilenode returning self
  params[0] = strlit742;
  Object call743 = callmethod(self, "out",
    1, params);
// compilenode returning call743
  if (strlit744 == NULL) {
    strlit744 = alloc_String("  invocationCount++;");
  }
// compilenode returning strlit744
// Begin line 239
  setline(239);
// compilenode returning self
  params[0] = strlit744;
  Object call745 = callmethod(self, "out",
    1, params);
// compilenode returning call745
  if (strlit746 == NULL) {
    strlit746 = alloc_String("  try {");
  }
// compilenode returning strlit746
// Begin line 240
  setline(240);
// compilenode returning self
  params[0] = strlit746;
  Object call747 = callmethod(self, "out",
    1, params);
// compilenode returning call747
// Begin line 241
  setline(241);
// Begin line 240
  setline(240);
  if (strlit748 == NULL) {
    strlit748 = alloc_String("undefined");
  }
// compilenode returning strlit748
  var_ret = alloc_var();
  *var_ret = strlit748;
  if (strlit748 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 242
  setline(242);
// Begin line 244
  setline(244);
// Begin line 643
  setline(643);
// Begin line 241
  setline(241);
// compilenode returning *var_o
  Object call750 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call750
// compilenode returning call750
// Begin line 242
  setline(242);
// Begin line 643
  setline(643);
  Object obj752 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj752, self, 0);
  addmethod2(obj752, "outer", &reader_genjs_outer_753);
  adddatum2(obj752, self, 0);
  block_savedest(obj752);
  Object **closure754 = createclosure(2);
  addtoclosure(closure754, var_ret);
  Object *selfpp757 = alloc_var();
  *selfpp757 = self;
  addtoclosure(closure754, selfpp757);
  struct UserObject *uo754 = (struct UserObject*)obj752;
  uo754->data[1] = (Object)closure754;
  addmethod2(obj752, "apply", &meth_genjs_apply754);
  set_type(obj752, 0);
// compilenode returning obj752
  setclassname(obj752, "Block<genjs:751>");
// compilenode returning obj752
  params[0] = call750;
  Object iter749 = callmethod(call750, "iter", 1, params);
  while(1) {
    Object cond749 = callmethod(iter749, "havemore", 0, NULL);
    if (!istrue(cond749)) break;
    params[0] = callmethod(iter749, "next", 0, NULL);
    callmethod(obj752, "apply", 1, params);
  }
// compilenode returning call750
// Begin line 244
  setline(244);
  if (strlit758 == NULL) {
    strlit758 = alloc_String("  return ");
  }
// compilenode returning strlit758
// compilenode returning *var_ret
  params[0] = *var_ret;
  Object opresult760 = callmethod(strlit758, "++", 1, params);
// compilenode returning opresult760
// Begin line 245
  setline(245);
// compilenode returning self
  params[0] = opresult760;
  Object call761 = callmethod(self, "out",
    1, params);
// compilenode returning call761
  if (strlit762 == NULL) {
    strlit762 = alloc_String("  } catch(e) {");
  }
// compilenode returning strlit762
// Begin line 246
  setline(246);
// compilenode returning self
  params[0] = strlit762;
  Object call763 = callmethod(self, "out",
    1, params);
// compilenode returning call763
  if (strlit764 == NULL) {
    strlit764 = alloc_String("    if ((e.exctype == 'return') && (e.target == returnTarget)) {");
  }
// compilenode returning strlit764
// Begin line 247
  setline(247);
// compilenode returning self
  params[0] = strlit764;
  Object call765 = callmethod(self, "out",
    1, params);
// compilenode returning call765
  if (strlit766 == NULL) {
    strlit766 = alloc_String("      return e.returnvalue;");
  }
// compilenode returning strlit766
// Begin line 248
  setline(248);
// compilenode returning self
  params[0] = strlit766;
  Object call767 = callmethod(self, "out",
    1, params);
// compilenode returning call767
  if (strlit768 == NULL) {
    strlit768 = alloc_String("    } else {");
  }
// compilenode returning strlit768
// Begin line 249
  setline(249);
// compilenode returning self
  params[0] = strlit768;
  Object call769 = callmethod(self, "out",
    1, params);
// compilenode returning call769
  if (strlit770 == NULL) {
    strlit770 = alloc_String("      throw e;");
  }
// compilenode returning strlit770
// Begin line 250
  setline(250);
// compilenode returning self
  params[0] = strlit770;
  Object call771 = callmethod(self, "out",
    1, params);
// compilenode returning call771
  if (strlit772 == NULL) {
    strlit772 = alloc_String("    }");
  }
// compilenode returning strlit772
// Begin line 251
  setline(251);
// compilenode returning self
  params[0] = strlit772;
  Object call773 = callmethod(self, "out",
    1, params);
// compilenode returning call773
  if (strlit774 == NULL) {
    strlit774 = alloc_String("  }");
  }
// compilenode returning strlit774
// Begin line 252
  setline(252);
// compilenode returning self
  params[0] = strlit774;
  Object call775 = callmethod(self, "out",
    1, params);
// compilenode returning call775
  if (strlit776 == NULL) {
    strlit776 = alloc_String("}");
  }
// compilenode returning strlit776
// Begin line 253
  setline(253);
// compilenode returning self
  params[0] = strlit776;
  Object call777 = callmethod(self, "out",
    1, params);
// compilenode returning call777
// Begin line 254
  setline(254);
// Begin line 253
  setline(253);
// compilenode returning *var_oldusedvars
  *var_usedvars = *var_oldusedvars;
  if (*var_oldusedvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 255
  setline(255);
// Begin line 254
  setline(254);
// compilenode returning *var_olddeclaredvars
  *var_declaredvars = *var_olddeclaredvars;
  if (*var_olddeclaredvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 255
  setline(255);
  if (strlit780 == NULL) {
    strlit780 = alloc_String("  ");
  }
// compilenode returning strlit780
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult782 = callmethod(strlit780, "++", 1, params);
// compilenode returning opresult782
  if (strlit783 == NULL) {
    strlit783 = alloc_String(".methods[""\x22""");
  }
// compilenode returning strlit783
  params[0] = strlit783;
  Object opresult785 = callmethod(opresult782, "++", 1, params);
// compilenode returning opresult785
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult787 = callmethod(opresult785, "++", 1, params);
// compilenode returning opresult787
  if (strlit788 == NULL) {
    strlit788 = alloc_String("""\x22""] = func");
  }
// compilenode returning strlit788
  params[0] = strlit788;
  Object opresult790 = callmethod(opresult787, "++", 1, params);
// compilenode returning opresult790
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult792 = callmethod(opresult790, "++", 1, params);
// compilenode returning opresult792
  if (strlit793 == NULL) {
    strlit793 = alloc_String(";");
  }
// compilenode returning strlit793
  params[0] = strlit793;
  Object opresult795 = callmethod(opresult792, "++", 1, params);
// compilenode returning opresult795
// Begin line 256
  setline(256);
// compilenode returning self
  params[0] = opresult795;
  Object call796 = callmethod(self, "out",
    1, params);
// compilenode returning call796
  return call796;
}
Object meth_genjs_apply829(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_tret = closure[0];
  Object self = *closure[1];
// Begin line 265
  setline(265);
// compilenode returning *var_l
// Begin line 266
  setline(266);
// compilenode returning self
  params[0] = *var_l;
  Object call830 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call830
  *var_tret = call830;
  if (call830 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compilewhile797(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
// Begin line 259
  setline(259);
// Begin line 258
  setline(258);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 260
  setline(260);
// Begin line 259
  setline(259);
// compilenode returning *var_auto_count
  Object num798 = alloc_Float64(1.0);
// compilenode returning num798
  params[0] = num798;
  Object sum800 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum800
  *var_auto_count = sum800;
  if (sum800 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 260
  setline(260);
// Begin line 643
  setline(643);
// Begin line 260
  setline(260);
// compilenode returning *var_o
  Object call802 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call802
// compilenode returning call802
// Begin line 261
  setline(261);
// compilenode returning self
  params[0] = call802;
  Object call803 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call803
  var_cond = alloc_var();
  *var_cond = call803;
  if (call803 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit804 == NULL) {
    strlit804 = alloc_String("  var wcond");
  }
// compilenode returning strlit804
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult806 = callmethod(strlit804, "++", 1, params);
// compilenode returning opresult806
  if (strlit807 == NULL) {
    strlit807 = alloc_String(" = Grace_isTrue(");
  }
// compilenode returning strlit807
  params[0] = strlit807;
  Object opresult809 = callmethod(opresult806, "++", 1, params);
// compilenode returning opresult809
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult811 = callmethod(opresult809, "++", 1, params);
// compilenode returning opresult811
  if (strlit812 == NULL) {
    strlit812 = alloc_String(");");
  }
// compilenode returning strlit812
  params[0] = strlit812;
  Object opresult814 = callmethod(opresult811, "++", 1, params);
// compilenode returning opresult814
// Begin line 262
  setline(262);
// compilenode returning self
  params[0] = opresult814;
  Object call815 = callmethod(self, "out",
    1, params);
// compilenode returning call815
  if (strlit816 == NULL) {
    strlit816 = alloc_String("  while (wcond");
  }
// compilenode returning strlit816
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult818 = callmethod(strlit816, "++", 1, params);
// compilenode returning opresult818
  if (strlit819 == NULL) {
    strlit819 = alloc_String(") {");
  }
// compilenode returning strlit819
  params[0] = strlit819;
  Object opresult821 = callmethod(opresult818, "++", 1, params);
// compilenode returning opresult821
// Begin line 263
  setline(263);
// compilenode returning self
  params[0] = opresult821;
  Object call822 = callmethod(self, "out",
    1, params);
// compilenode returning call822
// Begin line 264
  setline(264);
// Begin line 263
  setline(263);
  if (strlit823 == NULL) {
    strlit823 = alloc_String("null");
  }
// compilenode returning strlit823
  var_tret = alloc_var();
  *var_tret = strlit823;
  if (strlit823 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 265
  setline(265);
// Begin line 267
  setline(267);
// Begin line 643
  setline(643);
// Begin line 264
  setline(264);
// compilenode returning *var_o
  Object call825 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call825
// compilenode returning call825
// Begin line 265
  setline(265);
// Begin line 643
  setline(643);
  Object obj827 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj827, self, 0);
  addmethod2(obj827, "outer", &reader_genjs_outer_828);
  adddatum2(obj827, self, 0);
  block_savedest(obj827);
  Object **closure829 = createclosure(2);
  addtoclosure(closure829, var_tret);
  Object *selfpp832 = alloc_var();
  *selfpp832 = self;
  addtoclosure(closure829, selfpp832);
  struct UserObject *uo829 = (struct UserObject*)obj827;
  uo829->data[1] = (Object)closure829;
  addmethod2(obj827, "apply", &meth_genjs_apply829);
  set_type(obj827, 0);
// compilenode returning obj827
  setclassname(obj827, "Block<genjs:826>");
// compilenode returning obj827
  params[0] = call825;
  Object iter824 = callmethod(call825, "iter", 1, params);
  while(1) {
    Object cond824 = callmethod(iter824, "havemore", 0, NULL);
    if (!istrue(cond824)) break;
    params[0] = callmethod(iter824, "next", 0, NULL);
    callmethod(obj827, "apply", 1, params);
  }
// compilenode returning call825
// Begin line 267
  setline(267);
// Begin line 643
  setline(643);
// Begin line 267
  setline(267);
// compilenode returning *var_o
  Object call833 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call833
// compilenode returning call833
// Begin line 268
  setline(268);
// compilenode returning self
  params[0] = call833;
  Object call834 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call834
  *var_cond = call834;
  if (call834 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit836 == NULL) {
    strlit836 = alloc_String("  wcond");
  }
// compilenode returning strlit836
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult838 = callmethod(strlit836, "++", 1, params);
// compilenode returning opresult838
  if (strlit839 == NULL) {
    strlit839 = alloc_String(" = Grace_isTrue(");
  }
// compilenode returning strlit839
  params[0] = strlit839;
  Object opresult841 = callmethod(opresult838, "++", 1, params);
// compilenode returning opresult841
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult843 = callmethod(opresult841, "++", 1, params);
// compilenode returning opresult843
  if (strlit844 == NULL) {
    strlit844 = alloc_String(");");
  }
// compilenode returning strlit844
  params[0] = strlit844;
  Object opresult846 = callmethod(opresult843, "++", 1, params);
// compilenode returning opresult846
// Begin line 269
  setline(269);
// compilenode returning self
  params[0] = opresult846;
  Object call847 = callmethod(self, "out",
    1, params);
// compilenode returning call847
  if (strlit848 == NULL) {
    strlit848 = alloc_String("  }");
  }
// compilenode returning strlit848
// Begin line 270
  setline(270);
// compilenode returning self
  params[0] = strlit848;
  Object call849 = callmethod(self, "out",
    1, params);
// compilenode returning call849
// Begin line 271
  setline(271);
// Begin line 643
  setline(643);
// Begin line 270
  setline(270);
// compilenode returning *var_cond
// compilenode returning *var_o
  params[0] = *var_cond;
  Object call850 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call850
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply872(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_tret = closure[0];
  Object self = *closure[1];
// Begin line 279
  setline(279);
// compilenode returning *var_l
// Begin line 280
  setline(280);
// compilenode returning self
  params[0] = *var_l;
  Object call873 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call873
  *var_tret = call873;
  if (call873 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply901(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_fret = closure[0];
  Object self = *closure[1];
// Begin line 285
  setline(285);
// compilenode returning *var_l
// Begin line 286
  setline(286);
// compilenode returning self
  params[0] = *var_l;
  Object call902 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call902
  *var_fret = call902;
  if (call902 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileif851(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[18];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
  Object *var_fret = alloc_var();
  *var_fret = undefined;
// Begin line 274
  setline(274);
// Begin line 273
  setline(273);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 275
  setline(275);
// Begin line 274
  setline(274);
// compilenode returning *var_auto_count
  Object num852 = alloc_Float64(1.0);
// compilenode returning num852
  params[0] = num852;
  Object sum854 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum854
  *var_auto_count = sum854;
  if (sum854 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 275
  setline(275);
  if (strlit856 == NULL) {
    strlit856 = alloc_String("  if (Grace_isTrue(");
  }
// compilenode returning strlit856
// Begin line 643
  setline(643);
// Begin line 275
  setline(275);
// compilenode returning *var_o
  Object call857 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call857
// compilenode returning call857
// compilenode returning self
  params[0] = call857;
  Object call858 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call858
  params[0] = call858;
  Object opresult860 = callmethod(strlit856, "++", 1, params);
// compilenode returning opresult860
  if (strlit861 == NULL) {
    strlit861 = alloc_String(")) {");
  }
// compilenode returning strlit861
  params[0] = strlit861;
  Object opresult863 = callmethod(opresult860, "++", 1, params);
// compilenode returning opresult863
// Begin line 276
  setline(276);
// compilenode returning self
  params[0] = opresult863;
  Object call864 = callmethod(self, "out",
    1, params);
// compilenode returning call864
// Begin line 277
  setline(277);
// Begin line 276
  setline(276);
  if (strlit865 == NULL) {
    strlit865 = alloc_String("undefined");
  }
// compilenode returning strlit865
  var_tret = alloc_var();
  *var_tret = strlit865;
  if (strlit865 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 278
  setline(278);
// Begin line 277
  setline(277);
  if (strlit866 == NULL) {
    strlit866 = alloc_String("undefined");
  }
// compilenode returning strlit866
  var_fret = alloc_var();
  *var_fret = strlit866;
  if (strlit866 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 279
  setline(279);
// Begin line 281
  setline(281);
// Begin line 643
  setline(643);
// Begin line 278
  setline(278);
// compilenode returning *var_o
  Object call868 = callmethod(*var_o, "thenblock",
    0, params);
// compilenode returning call868
// compilenode returning call868
// Begin line 279
  setline(279);
// Begin line 643
  setline(643);
  Object obj870 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj870, self, 0);
  addmethod2(obj870, "outer", &reader_genjs_outer_871);
  adddatum2(obj870, self, 0);
  block_savedest(obj870);
  Object **closure872 = createclosure(2);
  addtoclosure(closure872, var_tret);
  Object *selfpp875 = alloc_var();
  *selfpp875 = self;
  addtoclosure(closure872, selfpp875);
  struct UserObject *uo872 = (struct UserObject*)obj870;
  uo872->data[1] = (Object)closure872;
  addmethod2(obj870, "apply", &meth_genjs_apply872);
  set_type(obj870, 0);
// compilenode returning obj870
  setclassname(obj870, "Block<genjs:869>");
// compilenode returning obj870
  params[0] = call868;
  Object iter867 = callmethod(call868, "iter", 1, params);
  while(1) {
    Object cond867 = callmethod(iter867, "havemore", 0, NULL);
    if (!istrue(cond867)) break;
    params[0] = callmethod(iter867, "next", 0, NULL);
    callmethod(obj870, "apply", 1, params);
  }
// compilenode returning call868
// Begin line 281
  setline(281);
  if (strlit876 == NULL) {
    strlit876 = alloc_String("  var if");
  }
// compilenode returning strlit876
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult878 = callmethod(strlit876, "++", 1, params);
// compilenode returning opresult878
  if (strlit879 == NULL) {
    strlit879 = alloc_String(" = ");
  }
// compilenode returning strlit879
  params[0] = strlit879;
  Object opresult881 = callmethod(opresult878, "++", 1, params);
// compilenode returning opresult881
// compilenode returning *var_tret
  params[0] = *var_tret;
  Object opresult883 = callmethod(opresult881, "++", 1, params);
// compilenode returning opresult883
  if (strlit884 == NULL) {
    strlit884 = alloc_String(";");
  }
// compilenode returning strlit884
  params[0] = strlit884;
  Object opresult886 = callmethod(opresult883, "++", 1, params);
// compilenode returning opresult886
// Begin line 282
  setline(282);
// compilenode returning self
  params[0] = opresult886;
  Object call887 = callmethod(self, "out",
    1, params);
// compilenode returning call887
// Begin line 287
  setline(287);
// Begin line 289
  setline(289);
// Begin line 643
  setline(643);
// Begin line 289
  setline(289);
// Begin line 643
  setline(643);
// Begin line 282
  setline(282);
// compilenode returning *var_o
  Object call889 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call889
// compilenode returning call889
  Object call890 = callmethod(call889, "size",
    0, params);
// compilenode returning call890
// compilenode returning call890
  Object num891 = alloc_Float64(0.0);
// compilenode returning num891
  params[0] = num891;
  Object opresult893 = callmethod(call890, ">", 1, params);
// compilenode returning opresult893
  Object if888;
  if (istrue(opresult893)) {
// Begin line 283
  setline(283);
  if (strlit894 == NULL) {
    strlit894 = alloc_String("  } else {");
  }
// compilenode returning strlit894
// Begin line 284
  setline(284);
// compilenode returning self
  params[0] = strlit894;
  Object call895 = callmethod(self, "out",
    1, params);
// compilenode returning call895
// Begin line 285
  setline(285);
// Begin line 287
  setline(287);
// Begin line 643
  setline(643);
// Begin line 284
  setline(284);
// compilenode returning *var_o
  Object call897 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call897
// compilenode returning call897
// Begin line 285
  setline(285);
// Begin line 643
  setline(643);
  Object obj899 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj899, self, 0);
  addmethod2(obj899, "outer", &reader_genjs_outer_900);
  adddatum2(obj899, self, 0);
  block_savedest(obj899);
  Object **closure901 = createclosure(2);
  addtoclosure(closure901, var_fret);
  Object *selfpp904 = alloc_var();
  *selfpp904 = self;
  addtoclosure(closure901, selfpp904);
  struct UserObject *uo901 = (struct UserObject*)obj899;
  uo901->data[1] = (Object)closure901;
  addmethod2(obj899, "apply", &meth_genjs_apply901);
  set_type(obj899, 0);
// compilenode returning obj899
  setclassname(obj899, "Block<genjs:898>");
// compilenode returning obj899
  params[0] = call897;
  Object iter896 = callmethod(call897, "iter", 1, params);
  while(1) {
    Object cond896 = callmethod(iter896, "havemore", 0, NULL);
    if (!istrue(cond896)) break;
    params[0] = callmethod(iter896, "next", 0, NULL);
    callmethod(obj899, "apply", 1, params);
  }
// compilenode returning call897
// Begin line 287
  setline(287);
  if (strlit905 == NULL) {
    strlit905 = alloc_String("  var if");
  }
// compilenode returning strlit905
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult907 = callmethod(strlit905, "++", 1, params);
// compilenode returning opresult907
  if (strlit908 == NULL) {
    strlit908 = alloc_String(" = ");
  }
// compilenode returning strlit908
  params[0] = strlit908;
  Object opresult910 = callmethod(opresult907, "++", 1, params);
// compilenode returning opresult910
// compilenode returning *var_fret
  params[0] = *var_fret;
  Object opresult912 = callmethod(opresult910, "++", 1, params);
// compilenode returning opresult912
  if (strlit913 == NULL) {
    strlit913 = alloc_String(";");
  }
// compilenode returning strlit913
  params[0] = strlit913;
  Object opresult915 = callmethod(opresult912, "++", 1, params);
// compilenode returning opresult915
// Begin line 288
  setline(288);
// compilenode returning self
  params[0] = opresult915;
  Object call916 = callmethod(self, "out",
    1, params);
// compilenode returning call916
    if888 = call916;
  } else {
  }
// compilenode returning if888
// Begin line 289
  setline(289);
  if (strlit917 == NULL) {
    strlit917 = alloc_String("}");
  }
// compilenode returning strlit917
// Begin line 290
  setline(290);
// compilenode returning self
  params[0] = strlit917;
  Object call918 = callmethod(self, "out",
    1, params);
// compilenode returning call918
// Begin line 291
  setline(291);
// Begin line 643
  setline(643);
// Begin line 291
  setline(291);
// Begin line 290
  setline(290);
  if (strlit919 == NULL) {
    strlit919 = alloc_String("if");
  }
// compilenode returning strlit919
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult921 = callmethod(strlit919, "++", 1, params);
// compilenode returning opresult921
// compilenode returning *var_o
  params[0] = opresult921;
  Object call922 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call922
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileidentifier923(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[19];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_modules = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_usedvars = closure[2];
  Object *var_name = alloc_var();
  *var_name = undefined;
// Begin line 294
  setline(294);
// Begin line 643
  setline(643);
// Begin line 293
  setline(293);
// compilenode returning *var_o
  Object call924 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call924
// compilenode returning call924
  var_name = alloc_var();
  *var_name = call924;
  if (call924 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 303
  setline(303);
// Begin line 306
  setline(306);
// Begin line 294
  setline(294);
// compilenode returning *var_name
  if (strlit926 == NULL) {
    strlit926 = alloc_String("self");
  }
// compilenode returning strlit926
  params[0] = strlit926;
  Object opresult928 = callmethod(*var_name, "==", 1, params);
// compilenode returning opresult928
  Object if925;
  if (istrue(opresult928)) {
// Begin line 296
  setline(296);
// Begin line 643
  setline(643);
// Begin line 295
  setline(295);
  if (strlit929 == NULL) {
    strlit929 = alloc_String("this");
  }
// compilenode returning strlit929
// compilenode returning *var_o
  params[0] = strlit929;
  Object call930 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call930
// compilenode returning nothing
    if925 = nothing;
  } else {
// Begin line 303
  setline(303);
// Begin line 297
  setline(297);
// compilenode returning *var_name
// compilenode returning *var_modules
  params[0] = *var_name;
  Object call932 = callmethod(*var_modules, "contains",
    1, params);
// compilenode returning call932
  Object if931;
  if (istrue(call932)) {
// Begin line 298
  setline(298);
  if (strlit933 == NULL) {
    strlit933 = alloc_String("  // WARNING: module support not implemented in JS backend");
  }
// compilenode returning strlit933
// Begin line 299
  setline(299);
// compilenode returning self
  params[0] = strlit933;
  Object call934 = callmethod(self, "out",
    1, params);
// compilenode returning call934
// Begin line 300
  setline(300);
// Begin line 299
  setline(299);
  if (strlit935 == NULL) {
    strlit935 = alloc_String("  ""\x22""var_val_");
  }
// compilenode returning strlit935
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult937 = callmethod(strlit935, "++", 1, params);
// compilenode returning opresult937
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult939 = callmethod(opresult937, "++", 1, params);
// compilenode returning opresult939
// Begin line 300
  setline(300);
  if (strlit940 == NULL) {
    strlit940 = alloc_String("""\x22"" = load %object** @.module.");
  }
// compilenode returning strlit940
  params[0] = strlit940;
  Object opresult942 = callmethod(opresult939, "++", 1, params);
// compilenode returning opresult942
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult944 = callmethod(opresult942, "++", 1, params);
// compilenode returning opresult944
// Begin line 301
  setline(301);
// compilenode returning self
  params[0] = opresult944;
  Object call945 = callmethod(self, "out",
    1, params);
// compilenode returning call945
    if931 = call945;
  } else {
// Begin line 302
  setline(302);
// compilenode returning *var_name
// compilenode returning *var_usedvars
  params[0] = *var_name;
  Object call946 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call946
// Begin line 303
  setline(303);
// Begin line 643
  setline(643);
// Begin line 303
  setline(303);
// compilenode returning *var_name
// Begin line 304
  setline(304);
// compilenode returning self
  params[0] = *var_name;
  Object call947 = callmethod(self, "varf",
    1, params);
// compilenode returning call947
// Begin line 303
  setline(303);
// compilenode returning *var_o
  params[0] = call947;
  Object call948 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call948
// compilenode returning nothing
    if931 = nothing;
  }
// compilenode returning if931
    if925 = if931;
  }
// compilenode returning if925
  return if925;
}
Object meth_genjs_compilebind949(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[20];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_usedvars = closure[0];
  Object *var_dest = alloc_var();
  *var_dest = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_c = alloc_var();
  *var_c = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 309
  setline(309);
// Begin line 643
  setline(643);
// Begin line 308
  setline(308);
// compilenode returning *var_o
  Object call950 = callmethod(*var_o, "dest",
    0, params);
// compilenode returning call950
// compilenode returning call950
  var_dest = alloc_var();
  *var_dest = call950;
  if (call950 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 310
  setline(310);
// Begin line 309
  setline(309);
  if (strlit951 == NULL) {
    strlit951 = alloc_String("");
  }
// compilenode returning strlit951
  var_val = alloc_var();
  *var_val = strlit951;
  if (strlit951 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 311
  setline(311);
// Begin line 310
  setline(310);
  if (strlit952 == NULL) {
    strlit952 = alloc_String("");
  }
// compilenode returning strlit952
  var_c = alloc_var();
  *var_c = strlit952;
  if (strlit952 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 312
  setline(312);
// Begin line 311
  setline(311);
  if (strlit953 == NULL) {
    strlit953 = alloc_String("");
  }
// compilenode returning strlit953
  var_r = alloc_var();
  *var_r = strlit953;
  if (strlit953 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 329
  setline(329);
// Begin line 330
  setline(330);
// Begin line 643
  setline(643);
// Begin line 312
  setline(312);
// compilenode returning *var_dest
  Object call955 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call955
// compilenode returning call955
  if (strlit956 == NULL) {
    strlit956 = alloc_String("identifier");
  }
// compilenode returning strlit956
  params[0] = strlit956;
  Object opresult958 = callmethod(call955, "==", 1, params);
// compilenode returning opresult958
  Object if954;
  if (istrue(opresult958)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
// Begin line 314
  setline(314);
// Begin line 643
  setline(643);
// Begin line 313
  setline(313);
// compilenode returning *var_o
  Object call959 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call959
// compilenode returning call959
  *var_val = call959;
  if (call959 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 314
  setline(314);
// compilenode returning *var_val
// Begin line 315
  setline(315);
// compilenode returning self
  params[0] = *var_val;
  Object call961 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call961
  *var_val = call961;
  if (call961 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 643
  setline(643);
// Begin line 315
  setline(315);
// Begin line 643
  setline(643);
// Begin line 315
  setline(315);
// compilenode returning *var_dest
  Object call963 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call963
// compilenode returning call963
  Object call964 = callmethod(call963, "_escape",
    0, params);
// compilenode returning call964
// compilenode returning call964
  var_nm = alloc_var();
  *var_nm = call964;
  if (call964 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 316
  setline(316);
// compilenode returning *var_nm
// compilenode returning *var_usedvars
  params[0] = *var_nm;
  Object call965 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call965
// Begin line 317
  setline(317);
  if (strlit966 == NULL) {
    strlit966 = alloc_String("  ");
  }
// compilenode returning strlit966
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call967 = callmethod(self, "varf",
    1, params);
// compilenode returning call967
  params[0] = call967;
  Object opresult969 = callmethod(strlit966, "++", 1, params);
// compilenode returning opresult969
  if (strlit970 == NULL) {
    strlit970 = alloc_String(" = ");
  }
// compilenode returning strlit970
  params[0] = strlit970;
  Object opresult972 = callmethod(opresult969, "++", 1, params);
// compilenode returning opresult972
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult974 = callmethod(opresult972, "++", 1, params);
// compilenode returning opresult974
  if (strlit975 == NULL) {
    strlit975 = alloc_String(";");
  }
// compilenode returning strlit975
  params[0] = strlit975;
  Object opresult977 = callmethod(opresult974, "++", 1, params);
// compilenode returning opresult977
// Begin line 318
  setline(318);
// compilenode returning self
  params[0] = opresult977;
  Object call978 = callmethod(self, "out",
    1, params);
// compilenode returning call978
// Begin line 319
  setline(319);
// Begin line 643
  setline(643);
// Begin line 318
  setline(318);
// compilenode returning *var_val
// compilenode returning *var_o
  params[0] = *var_val;
  Object call979 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call979
// compilenode returning nothing
    if954 = nothing;
  } else {
// Begin line 329
  setline(329);
// Begin line 324
  setline(324);
// Begin line 643
  setline(643);
// Begin line 319
  setline(319);
// compilenode returning *var_dest
  Object call981 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call981
// compilenode returning call981
  if (strlit982 == NULL) {
    strlit982 = alloc_String("member");
  }
// compilenode returning strlit982
  params[0] = strlit982;
  Object opresult984 = callmethod(call981, "==", 1, params);
// compilenode returning opresult984
  Object if980;
  if (istrue(opresult984)) {
// Begin line 321
  setline(321);
// Begin line 643
  setline(643);
// Begin line 321
  setline(321);
// Begin line 643
  setline(643);
// Begin line 320
  setline(320);
// compilenode returning *var_dest
  Object call985 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call985
// compilenode returning call985
  if (strlit986 == NULL) {
    strlit986 = alloc_String(":=");
  }
// compilenode returning strlit986
  params[0] = strlit986;
  Object opresult988 = callmethod(call985, "++", 1, params);
// compilenode returning opresult988
// compilenode returning *var_dest
  params[0] = opresult988;
  Object call989 = callmethod(*var_dest, "value:=",
    1, params);
// compilenode returning call989
// compilenode returning nothing
// Begin line 321
  setline(321);
// compilenode returning *var_dest
  Object array990 = alloc_List();
// Begin line 643
  setline(643);
// Begin line 321
  setline(321);
// compilenode returning *var_o
  Object call991 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call991
// compilenode returning call991
  params[0] = call991;
  callmethod(array990, "push", 1, params);
// compilenode returning array990
// compilenode returning module_ast
  params[0] = *var_dest;
  params[1] = array990;
  Object call992 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call992
  *var_c = call992;
  if (call992 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 322
  setline(322);
// compilenode returning *var_c
// Begin line 323
  setline(323);
// compilenode returning self
  params[0] = *var_c;
  Object call994 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call994
  *var_r = call994;
  if (call994 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 324
  setline(324);
// Begin line 643
  setline(643);
// Begin line 323
  setline(323);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call996 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call996
// compilenode returning nothing
    if980 = nothing;
  } else {
// Begin line 329
  setline(329);
// Begin line 330
  setline(330);
// Begin line 643
  setline(643);
// Begin line 324
  setline(324);
// compilenode returning *var_dest
  Object call998 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call998
// compilenode returning call998
  if (strlit999 == NULL) {
    strlit999 = alloc_String("index");
  }
// compilenode returning strlit999
  params[0] = strlit999;
  Object opresult1001 = callmethod(call998, "==", 1, params);
// compilenode returning opresult1001
  Object if997;
  if (istrue(opresult1001)) {
  Object *var_imem = alloc_var();
  *var_imem = undefined;
// Begin line 325
  setline(325);
  if (strlit1002 == NULL) {
    strlit1002 = alloc_String("[]:=");
  }
// compilenode returning strlit1002
// Begin line 643
  setline(643);
// Begin line 325
  setline(325);
// compilenode returning *var_dest
  Object call1003 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call1003
// compilenode returning call1003
// compilenode returning module_ast
  params[0] = strlit1002;
  params[1] = call1003;
  Object call1004 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1004
  var_imem = alloc_var();
  *var_imem = call1004;
  if (call1004 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 326
  setline(326);
// compilenode returning *var_imem
  Object array1005 = alloc_List();
// Begin line 643
  setline(643);
// Begin line 326
  setline(326);
// compilenode returning *var_dest
  Object call1006 = callmethod(*var_dest, "index",
    0, params);
// compilenode returning call1006
// compilenode returning call1006
  params[0] = call1006;
  callmethod(array1005, "push", 1, params);
// Begin line 643
  setline(643);
// Begin line 326
  setline(326);
// compilenode returning *var_o
  Object call1007 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1007
// compilenode returning call1007
  params[0] = call1007;
  callmethod(array1005, "push", 1, params);
// compilenode returning array1005
// compilenode returning module_ast
  params[0] = *var_imem;
  params[1] = array1005;
  Object call1008 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1008
  *var_c = call1008;
  if (call1008 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 327
  setline(327);
// compilenode returning *var_c
// Begin line 328
  setline(328);
// compilenode returning self
  params[0] = *var_c;
  Object call1010 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1010
  *var_r = call1010;
  if (call1010 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 329
  setline(329);
// Begin line 643
  setline(643);
// Begin line 328
  setline(328);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call1012 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1012
// compilenode returning nothing
    if997 = nothing;
  } else {
  }
// compilenode returning if997
    if980 = if997;
  }
// compilenode returning if980
    if954 = if980;
  }
// compilenode returning if954
  return if954;
}
Object meth_genjs_compiledefdec1013(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[21];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 333
  setline(333);
  var_nm = alloc_var();
  *var_nm = undefined;
// compilenode returning nothing
// Begin line 336
  setline(336);
// Begin line 338
  setline(338);
// Begin line 643
  setline(643);
// Begin line 338
  setline(338);
// Begin line 643
  setline(643);
// Begin line 333
  setline(333);
// compilenode returning *var_o
  Object call1015 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1015
// compilenode returning call1015
  Object call1016 = callmethod(call1015, "kind",
    0, params);
// compilenode returning call1016
// compilenode returning call1016
  if (strlit1017 == NULL) {
    strlit1017 = alloc_String("generic");
  }
// compilenode returning strlit1017
  params[0] = strlit1017;
  Object opresult1019 = callmethod(call1016, "==", 1, params);
// compilenode returning opresult1019
  Object if1014;
  if (istrue(opresult1019)) {
// Begin line 334
  setline(334);
// Begin line 643
  setline(643);
// Begin line 334
  setline(334);
// Begin line 643
  setline(643);
// Begin line 334
  setline(334);
// Begin line 643
  setline(643);
// Begin line 334
  setline(334);
// Begin line 643
  setline(643);
// Begin line 334
  setline(334);
// compilenode returning *var_o
  Object call1020 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1020
// compilenode returning call1020
  Object call1021 = callmethod(call1020, "value",
    0, params);
// compilenode returning call1021
// compilenode returning call1021
  Object call1022 = callmethod(call1021, "value",
    0, params);
// compilenode returning call1022
// compilenode returning call1022
  Object call1023 = callmethod(call1022, "_escape",
    0, params);
// compilenode returning call1023
// compilenode returning call1023
  *var_nm = call1023;
  if (call1023 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1014 = nothing;
  } else {
// Begin line 336
  setline(336);
// Begin line 643
  setline(643);
// Begin line 336
  setline(336);
// Begin line 643
  setline(643);
// Begin line 336
  setline(336);
// Begin line 643
  setline(643);
// Begin line 336
  setline(336);
// compilenode returning *var_o
  Object call1025 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1025
// compilenode returning call1025
  Object call1026 = callmethod(call1025, "value",
    0, params);
// compilenode returning call1026
// compilenode returning call1026
  Object call1027 = callmethod(call1026, "_escape",
    0, params);
// compilenode returning call1027
// compilenode returning call1027
  *var_nm = call1027;
  if (call1027 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1014 = nothing;
  }
// compilenode returning if1014
// Begin line 338
  setline(338);
// compilenode returning *var_nm
// compilenode returning *var_declaredvars
  params[0] = *var_nm;
  Object call1029 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1029
// Begin line 340
  setline(340);
// Begin line 643
  setline(643);
// Begin line 339
  setline(339);
// compilenode returning *var_o
  Object call1030 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1030
// compilenode returning call1030
  var_val = alloc_var();
  *var_val = call1030;
  if (call1030 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 343
  setline(343);
// Begin line 340
  setline(340);
// compilenode returning *var_val
  Object if1031;
  if (istrue(*var_val)) {
// Begin line 341
  setline(341);
// compilenode returning *var_val
// Begin line 342
  setline(342);
// compilenode returning self
  params[0] = *var_val;
  Object call1032 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1032
  *var_val = call1032;
  if (call1032 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1031 = nothing;
  } else {
// Begin line 343
  setline(343);
  if (strlit1034 == NULL) {
    strlit1034 = alloc_String("const must have value bound.");
  }
// compilenode returning strlit1034
// compilenode returning module_util
  params[0] = strlit1034;
  Object call1035 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1035
    if1031 = call1035;
  }
// compilenode returning if1031
// Begin line 345
  setline(345);
  if (strlit1036 == NULL) {
    strlit1036 = alloc_String("  var ");
  }
// compilenode returning strlit1036
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call1037 = callmethod(self, "varf",
    1, params);
// compilenode returning call1037
  params[0] = call1037;
  Object opresult1039 = callmethod(strlit1036, "++", 1, params);
// compilenode returning opresult1039
  if (strlit1040 == NULL) {
    strlit1040 = alloc_String(" = ");
  }
// compilenode returning strlit1040
  params[0] = strlit1040;
  Object opresult1042 = callmethod(opresult1039, "++", 1, params);
// compilenode returning opresult1042
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1044 = callmethod(opresult1042, "++", 1, params);
// compilenode returning opresult1044
  if (strlit1045 == NULL) {
    strlit1045 = alloc_String(";");
  }
// compilenode returning strlit1045
  params[0] = strlit1045;
  Object opresult1047 = callmethod(opresult1044, "++", 1, params);
// compilenode returning opresult1047
// Begin line 346
  setline(346);
// compilenode returning self
  params[0] = opresult1047;
  Object call1048 = callmethod(self, "out",
    1, params);
// compilenode returning call1048
// Begin line 347
  setline(347);
// Begin line 643
  setline(643);
// Begin line 346
  setline(346);
// compilenode returning *var_val
// compilenode returning *var_o
  params[0] = *var_val;
  Object call1049 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1049
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compilevardec1050(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[22];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 349
  setline(349);
// Begin line 643
  setline(643);
// Begin line 349
  setline(349);
// Begin line 643
  setline(643);
// Begin line 349
  setline(349);
// Begin line 643
  setline(643);
// Begin line 349
  setline(349);
// compilenode returning *var_o
  Object call1051 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call1051
// compilenode returning call1051
  Object call1052 = callmethod(call1051, "value",
    0, params);
// compilenode returning call1052
// compilenode returning call1052
  Object call1053 = callmethod(call1052, "_escape",
    0, params);
// compilenode returning call1053
// compilenode returning call1053
  var_nm = alloc_var();
  *var_nm = call1053;
  if (call1053 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 350
  setline(350);
// compilenode returning *var_nm
// compilenode returning *var_declaredvars
  params[0] = *var_nm;
  Object call1054 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1054
// Begin line 352
  setline(352);
// Begin line 643
  setline(643);
// Begin line 351
  setline(351);
// compilenode returning *var_o
  Object call1055 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1055
// compilenode returning call1055
  var_val = alloc_var();
  *var_val = call1055;
  if (call1055 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 358
  setline(358);
// Begin line 352
  setline(352);
// compilenode returning *var_val
  Object if1056;
  if (istrue(*var_val)) {
// Begin line 353
  setline(353);
// compilenode returning *var_val
// Begin line 354
  setline(354);
// compilenode returning self
  params[0] = *var_val;
  Object call1057 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1057
  *var_val = call1057;
  if (call1057 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit1059 == NULL) {
    strlit1059 = alloc_String("  var ");
  }
// compilenode returning strlit1059
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call1060 = callmethod(self, "varf",
    1, params);
// compilenode returning call1060
  params[0] = call1060;
  Object opresult1062 = callmethod(strlit1059, "++", 1, params);
// compilenode returning opresult1062
  if (strlit1063 == NULL) {
    strlit1063 = alloc_String(" = ");
  }
// compilenode returning strlit1063
  params[0] = strlit1063;
  Object opresult1065 = callmethod(opresult1062, "++", 1, params);
// compilenode returning opresult1065
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult1067 = callmethod(opresult1065, "++", 1, params);
// compilenode returning opresult1067
  if (strlit1068 == NULL) {
    strlit1068 = alloc_String(";");
  }
// compilenode returning strlit1068
  params[0] = strlit1068;
  Object opresult1070 = callmethod(opresult1067, "++", 1, params);
// compilenode returning opresult1070
// Begin line 355
  setline(355);
// compilenode returning self
  params[0] = opresult1070;
  Object call1071 = callmethod(self, "out",
    1, params);
// compilenode returning call1071
    if1056 = call1071;
  } else {
// Begin line 356
  setline(356);
  if (strlit1072 == NULL) {
    strlit1072 = alloc_String("  var ");
  }
// compilenode returning strlit1072
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call1073 = callmethod(self, "varf",
    1, params);
// compilenode returning call1073
  params[0] = call1073;
  Object opresult1075 = callmethod(strlit1072, "++", 1, params);
// compilenode returning opresult1075
  if (strlit1076 == NULL) {
    strlit1076 = alloc_String(";");
  }
// compilenode returning strlit1076
  params[0] = strlit1076;
  Object opresult1078 = callmethod(opresult1075, "++", 1, params);
// compilenode returning opresult1078
// Begin line 357
  setline(357);
// compilenode returning self
  params[0] = opresult1078;
  Object call1079 = callmethod(self, "out",
    1, params);
// compilenode returning call1079
// Begin line 358
  setline(358);
// Begin line 357
  setline(357);
  if (strlit1080 == NULL) {
    strlit1080 = alloc_String("false");
  }
// compilenode returning strlit1080
  *var_val = strlit1080;
  if (strlit1080 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1056 = nothing;
  }
// compilenode returning if1056
// Begin line 360
  setline(360);
// Begin line 643
  setline(643);
// Begin line 359
  setline(359);
// compilenode returning *var_val
// compilenode returning *var_o
  params[0] = *var_val;
  Object call1082 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1082
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileindex1083(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[23];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_of = alloc_var();
  *var_of = undefined;
  Object *var_index = alloc_var();
  *var_index = undefined;
// Begin line 362
  setline(362);
// Begin line 643
  setline(643);
// Begin line 362
  setline(362);
// compilenode returning *var_o
  Object call1084 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1084
// compilenode returning call1084
// Begin line 363
  setline(363);
// compilenode returning self
  params[0] = call1084;
  Object call1085 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1085
  var_of = alloc_var();
  *var_of = call1085;
  if (call1085 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 643
  setline(643);
// Begin line 363
  setline(363);
// compilenode returning *var_o
  Object call1086 = callmethod(*var_o, "index",
    0, params);
// compilenode returning call1086
// compilenode returning call1086
// Begin line 364
  setline(364);
// compilenode returning self
  params[0] = call1086;
  Object call1087 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1087
  var_index = alloc_var();
  *var_index = call1087;
  if (call1087 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 365
  setline(365);
// Begin line 364
  setline(364);
  if (strlit1088 == NULL) {
    strlit1088 = alloc_String("  var idxres");
  }
// compilenode returning strlit1088
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1090 = callmethod(strlit1088, "++", 1, params);
// compilenode returning opresult1090
  if (strlit1091 == NULL) {
    strlit1091 = alloc_String(" = ");
  }
// compilenode returning strlit1091
  params[0] = strlit1091;
  Object opresult1093 = callmethod(opresult1090, "++", 1, params);
// compilenode returning opresult1093
// compilenode returning *var_of
  params[0] = *var_of;
  Object opresult1095 = callmethod(opresult1093, "++", 1, params);
// compilenode returning opresult1095
  if (strlit1096 == NULL) {
    strlit1096 = alloc_String(".methods[""\x22""[]""\x22""]");
  }
// compilenode returning strlit1096
  params[0] = strlit1096;
  Object opresult1098 = callmethod(opresult1095, "++", 1, params);
// compilenode returning opresult1098
// Begin line 365
  setline(365);
  if (strlit1099 == NULL) {
    strlit1099 = alloc_String(".call(");
  }
// compilenode returning strlit1099
  params[0] = strlit1099;
  Object opresult1101 = callmethod(opresult1098, "++", 1, params);
// compilenode returning opresult1101
// compilenode returning *var_of
  params[0] = *var_of;
  Object opresult1103 = callmethod(opresult1101, "++", 1, params);
// compilenode returning opresult1103
  if (strlit1104 == NULL) {
    strlit1104 = alloc_String(", ");
  }
// compilenode returning strlit1104
  params[0] = strlit1104;
  Object opresult1106 = callmethod(opresult1103, "++", 1, params);
// compilenode returning opresult1106
// compilenode returning *var_index
  params[0] = *var_index;
  Object opresult1108 = callmethod(opresult1106, "++", 1, params);
// compilenode returning opresult1108
  if (strlit1109 == NULL) {
    strlit1109 = alloc_String(");");
  }
// compilenode returning strlit1109
  params[0] = strlit1109;
  Object opresult1111 = callmethod(opresult1108, "++", 1, params);
// compilenode returning opresult1111
// Begin line 366
  setline(366);
// compilenode returning self
  params[0] = opresult1111;
  Object call1112 = callmethod(self, "out",
    1, params);
// compilenode returning call1112
// Begin line 367
  setline(367);
// Begin line 643
  setline(643);
// Begin line 367
  setline(367);
// Begin line 366
  setline(366);
  if (strlit1113 == NULL) {
    strlit1113 = alloc_String("idxres");
  }
// compilenode returning strlit1113
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1115 = callmethod(strlit1113, "++", 1, params);
// compilenode returning opresult1115
// compilenode returning *var_o
  params[0] = opresult1115;
  Object call1116 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1116
// compilenode returning nothing
// Begin line 368
  setline(368);
// Begin line 367
  setline(367);
// compilenode returning *var_auto_count
  Object num1117 = alloc_Float64(1.0);
// compilenode returning num1117
  params[0] = num1117;
  Object sum1119 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1119
  *var_auto_count = sum1119;
  if (sum1119 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileop1121(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[24];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_left = alloc_var();
  *var_left = undefined;
  Object *var_right = alloc_var();
  *var_right = undefined;
  Object *var_rnm = alloc_var();
  *var_rnm = undefined;
// Begin line 370
  setline(370);
// Begin line 643
  setline(643);
// Begin line 370
  setline(370);
// compilenode returning *var_o
  Object call1122 = callmethod(*var_o, "left",
    0, params);
// compilenode returning call1122
// compilenode returning call1122
// Begin line 371
  setline(371);
// compilenode returning self
  params[0] = call1122;
  Object call1123 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1123
  var_left = alloc_var();
  *var_left = call1123;
  if (call1123 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 643
  setline(643);
// Begin line 371
  setline(371);
// compilenode returning *var_o
  Object call1124 = callmethod(*var_o, "right",
    0, params);
// compilenode returning call1124
// compilenode returning call1124
// Begin line 372
  setline(372);
// compilenode returning self
  params[0] = call1124;
  Object call1125 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1125
  var_right = alloc_var();
  *var_right = call1125;
  if (call1125 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 373
  setline(373);
// Begin line 372
  setline(372);
// compilenode returning *var_auto_count
  Object num1126 = alloc_Float64(1.0);
// compilenode returning num1126
  params[0] = num1126;
  Object sum1128 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1128
  *var_auto_count = sum1128;
  if (sum1128 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 374
  setline(374);
// Begin line 373
  setline(373);
  if (strlit1130 == NULL) {
    strlit1130 = alloc_String("opresult");
  }
// compilenode returning strlit1130
  var_rnm = alloc_var();
  *var_rnm = strlit1130;
  if (strlit1130 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 376
  setline(376);
// Begin line 377
  setline(377);
// Begin line 643
  setline(643);
// Begin line 374
  setline(374);
// compilenode returning *var_o
  Object call1132 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1132
// compilenode returning call1132
  if (strlit1133 == NULL) {
    strlit1133 = alloc_String("*");
  }
// compilenode returning strlit1133
  params[0] = strlit1133;
  Object opresult1135 = callmethod(call1132, "==", 1, params);
// compilenode returning opresult1135
  Object if1131;
  if (istrue(opresult1135)) {
// Begin line 376
  setline(376);
// Begin line 375
  setline(375);
  if (strlit1136 == NULL) {
    strlit1136 = alloc_String("prod");
  }
// compilenode returning strlit1136
  *var_rnm = strlit1136;
  if (strlit1136 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1131 = nothing;
  } else {
  }
// compilenode returning if1131
// Begin line 379
  setline(379);
// Begin line 380
  setline(380);
// Begin line 643
  setline(643);
// Begin line 377
  setline(377);
// compilenode returning *var_o
  Object call1139 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1139
// compilenode returning call1139
  if (strlit1140 == NULL) {
    strlit1140 = alloc_String("/");
  }
// compilenode returning strlit1140
  params[0] = strlit1140;
  Object opresult1142 = callmethod(call1139, "==", 1, params);
// compilenode returning opresult1142
  Object if1138;
  if (istrue(opresult1142)) {
// Begin line 379
  setline(379);
// Begin line 378
  setline(378);
  if (strlit1143 == NULL) {
    strlit1143 = alloc_String("quotient");
  }
// compilenode returning strlit1143
  *var_rnm = strlit1143;
  if (strlit1143 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1138 = nothing;
  } else {
  }
// compilenode returning if1138
// Begin line 382
  setline(382);
// Begin line 383
  setline(383);
// Begin line 643
  setline(643);
// Begin line 380
  setline(380);
// compilenode returning *var_o
  Object call1146 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1146
// compilenode returning call1146
  if (strlit1147 == NULL) {
    strlit1147 = alloc_String("-");
  }
// compilenode returning strlit1147
  params[0] = strlit1147;
  Object opresult1149 = callmethod(call1146, "==", 1, params);
// compilenode returning opresult1149
  Object if1145;
  if (istrue(opresult1149)) {
// Begin line 382
  setline(382);
// Begin line 381
  setline(381);
  if (strlit1150 == NULL) {
    strlit1150 = alloc_String("diff");
  }
// compilenode returning strlit1150
  *var_rnm = strlit1150;
  if (strlit1150 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1145 = nothing;
  } else {
  }
// compilenode returning if1145
// Begin line 385
  setline(385);
// Begin line 386
  setline(386);
// Begin line 643
  setline(643);
// Begin line 383
  setline(383);
// compilenode returning *var_o
  Object call1153 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1153
// compilenode returning call1153
  if (strlit1154 == NULL) {
    strlit1154 = alloc_String("%");
  }
// compilenode returning strlit1154
  params[0] = strlit1154;
  Object opresult1156 = callmethod(call1153, "==", 1, params);
// compilenode returning opresult1156
  Object if1152;
  if (istrue(opresult1156)) {
// Begin line 385
  setline(385);
// Begin line 384
  setline(384);
  if (strlit1157 == NULL) {
    strlit1157 = alloc_String("modulus");
  }
// compilenode returning strlit1157
  *var_rnm = strlit1157;
  if (strlit1157 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1152 = nothing;
  } else {
  }
// compilenode returning if1152
// Begin line 388
  setline(388);
// Begin line 386
  setline(386);
  if (strlit1159 == NULL) {
    strlit1159 = alloc_String("  var ");
  }
// compilenode returning strlit1159
// compilenode returning *var_rnm
  params[0] = *var_rnm;
  Object opresult1161 = callmethod(strlit1159, "++", 1, params);
// compilenode returning opresult1161
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1163 = callmethod(opresult1161, "++", 1, params);
// compilenode returning opresult1163
  if (strlit1164 == NULL) {
    strlit1164 = alloc_String(" = callmethod(");
  }
// compilenode returning strlit1164
  params[0] = strlit1164;
  Object opresult1166 = callmethod(opresult1163, "++", 1, params);
// compilenode returning opresult1166
// compilenode returning *var_left
  params[0] = *var_left;
  Object opresult1168 = callmethod(opresult1166, "++", 1, params);
// compilenode returning opresult1168
// Begin line 387
  setline(387);
  if (strlit1169 == NULL) {
    strlit1169 = alloc_String(", ""\x22""");
  }
// compilenode returning strlit1169
  params[0] = strlit1169;
  Object opresult1171 = callmethod(opresult1168, "++", 1, params);
// compilenode returning opresult1171
// Begin line 388
  setline(388);
// Begin line 643
  setline(643);
// Begin line 387
  setline(387);
// compilenode returning *var_o
  Object call1172 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1172
// compilenode returning call1172
  params[0] = call1172;
  Object opresult1174 = callmethod(opresult1171, "++", 1, params);
// compilenode returning opresult1174
  if (strlit1175 == NULL) {
    strlit1175 = alloc_String("""\x22"", ");
  }
// compilenode returning strlit1175
  params[0] = strlit1175;
  Object opresult1177 = callmethod(opresult1174, "++", 1, params);
// compilenode returning opresult1177
// Begin line 388
  setline(388);
// compilenode returning *var_right
  params[0] = *var_right;
  Object opresult1179 = callmethod(opresult1177, "++", 1, params);
// compilenode returning opresult1179
  if (strlit1180 == NULL) {
    strlit1180 = alloc_String(");");
  }
// compilenode returning strlit1180
  params[0] = strlit1180;
  Object opresult1182 = callmethod(opresult1179, "++", 1, params);
// compilenode returning opresult1182
// Begin line 389
  setline(389);
// compilenode returning self
  params[0] = opresult1182;
  Object call1183 = callmethod(self, "out",
    1, params);
// compilenode returning call1183
// Begin line 390
  setline(390);
// Begin line 643
  setline(643);
// Begin line 390
  setline(390);
// Begin line 389
  setline(389);
// compilenode returning *var_rnm
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1185 = callmethod(*var_rnm, "++", 1, params);
// compilenode returning opresult1185
// compilenode returning *var_o
  params[0] = opresult1185;
  Object call1186 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1186
// compilenode returning nothing
// Begin line 391
  setline(391);
// Begin line 390
  setline(390);
// compilenode returning *var_auto_count
  Object num1187 = alloc_Float64(1.0);
// compilenode returning num1187
  params[0] = num1187;
  Object sum1189 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1189
  *var_auto_count = sum1189;
  if (sum1189 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply1201(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_args = closure[0];
  Object self = *closure[1];
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 398
  setline(398);
// compilenode returning *var_p
// Begin line 399
  setline(399);
// compilenode returning self
  params[0] = *var_p;
  Object call1202 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1202
  var_r = alloc_var();
  *var_r = call1202;
  if (call1202 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_args
  params[0] = *var_r;
  Object call1203 = callmethod(*var_args, "push",
    1, params);
// compilenode returning call1203
  return call1203;
}
Object meth_genjs_apply1239(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 406
  setline(406);
  if (strlit1240 == NULL) {
    strlit1240 = alloc_String(", ");
  }
// compilenode returning strlit1240
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult1242 = callmethod(strlit1240, "++", 1, params);
// compilenode returning opresult1242
// Begin line 407
  setline(407);
// compilenode returning self
  params[0] = opresult1242;
  Object call1243 = callmethod(self, "out",
    1, params);
// compilenode returning call1243
  return call1243;
}
Object meth_genjs_apply1271(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 414
  setline(414);
  if (strlit1272 == NULL) {
    strlit1272 = alloc_String(", ");
  }
// compilenode returning strlit1272
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult1274 = callmethod(strlit1272, "++", 1, params);
// compilenode returning opresult1274
// Begin line 415
  setline(415);
// compilenode returning self
  params[0] = opresult1274;
  Object call1275 = callmethod(self, "out",
    1, params);
// compilenode returning call1275
  return call1275;
}
Object meth_genjs_compilecall1191(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[25];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_args = alloc_var();
  *var_args = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 394
  setline(394);
  Object array1192 = alloc_List();
// compilenode returning array1192
  var_args = alloc_var();
  *var_args = array1192;
  if (array1192 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 395
  setline(395);
// Begin line 394
  setline(394);
  if (strlit1193 == NULL) {
    strlit1193 = alloc_String("");
  }
// compilenode returning strlit1193
  var_obj = alloc_var();
  *var_obj = strlit1193;
  if (strlit1193 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 396
  setline(396);
// Begin line 395
  setline(395);
  Object num1194 = alloc_Float64(0.0);
// compilenode returning num1194
  var_len = alloc_var();
  *var_len = num1194;
  if (num1194 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 397
  setline(397);
// Begin line 396
  setline(396);
  if (strlit1195 == NULL) {
    strlit1195 = alloc_String("");
  }
// compilenode returning strlit1195
  var_con = alloc_var();
  *var_con = strlit1195;
  if (strlit1195 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 399
  setline(399);
// Begin line 401
  setline(401);
// Begin line 643
  setline(643);
// Begin line 397
  setline(397);
// compilenode returning *var_o
  Object call1197 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call1197
// compilenode returning call1197
// Begin line 399
  setline(399);
// Begin line 643
  setline(643);
  Object obj1199 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1199, self, 0);
  addmethod2(obj1199, "outer", &reader_genjs_outer_1200);
  adddatum2(obj1199, self, 0);
  block_savedest(obj1199);
  Object **closure1201 = createclosure(2);
  addtoclosure(closure1201, var_args);
  Object *selfpp1204 = alloc_var();
  *selfpp1204 = self;
  addtoclosure(closure1201, selfpp1204);
  struct UserObject *uo1201 = (struct UserObject*)obj1199;
  uo1201->data[1] = (Object)closure1201;
  addmethod2(obj1199, "apply", &meth_genjs_apply1201);
  set_type(obj1199, 0);
// compilenode returning obj1199
  setclassname(obj1199, "Block<genjs:1198>");
// compilenode returning obj1199
  params[0] = call1197;
  Object iter1196 = callmethod(call1197, "iter", 1, params);
  while(1) {
    Object cond1196 = callmethod(iter1196, "havemore", 0, NULL);
    if (!istrue(cond1196)) break;
    params[0] = callmethod(iter1196, "next", 0, NULL);
    callmethod(obj1199, "apply", 1, params);
  }
// compilenode returning call1197
// Begin line 416
  setline(416);
// Begin line 418
  setline(418);
// Begin line 643
  setline(643);
// Begin line 418
  setline(418);
// Begin line 643
  setline(643);
// Begin line 401
  setline(401);
// compilenode returning *var_o
  Object call1206 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1206
// compilenode returning call1206
  Object call1207 = callmethod(call1206, "kind",
    0, params);
// compilenode returning call1207
// compilenode returning call1207
  if (strlit1208 == NULL) {
    strlit1208 = alloc_String("member");
  }
// compilenode returning strlit1208
  params[0] = strlit1208;
  Object opresult1210 = callmethod(call1207, "==", 1, params);
// compilenode returning opresult1210
  Object if1205;
  if (istrue(opresult1210)) {
// Begin line 402
  setline(402);
// Begin line 643
  setline(643);
// Begin line 402
  setline(402);
// Begin line 643
  setline(643);
// Begin line 402
  setline(402);
// compilenode returning *var_o
  Object call1211 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1211
// compilenode returning call1211
  Object call1212 = callmethod(call1211, "in",
    0, params);
// compilenode returning call1212
// compilenode returning call1212
// Begin line 403
  setline(403);
// compilenode returning self
  params[0] = call1212;
  Object call1213 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1213
  *var_obj = call1213;
  if (call1213 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 404
  setline(404);
// Begin line 403
  setline(403);
  if (strlit1215 == NULL) {
    strlit1215 = alloc_String("  var call");
  }
// compilenode returning strlit1215
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1217 = callmethod(strlit1215, "++", 1, params);
// compilenode returning opresult1217
  if (strlit1218 == NULL) {
    strlit1218 = alloc_String(" = callmethod(");
  }
// compilenode returning strlit1218
  params[0] = strlit1218;
  Object opresult1220 = callmethod(opresult1217, "++", 1, params);
// compilenode returning opresult1220
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult1222 = callmethod(opresult1220, "++", 1, params);
// compilenode returning opresult1222
// Begin line 404
  setline(404);
  if (strlit1223 == NULL) {
    strlit1223 = alloc_String(",""\x22""");
  }
// compilenode returning strlit1223
  params[0] = strlit1223;
  Object opresult1225 = callmethod(opresult1222, "++", 1, params);
// compilenode returning opresult1225
// Begin line 643
  setline(643);
// Begin line 404
  setline(404);
// Begin line 643
  setline(643);
// Begin line 404
  setline(404);
// Begin line 643
  setline(643);
// Begin line 404
  setline(404);
// compilenode returning *var_o
  Object call1226 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1226
// compilenode returning call1226
  Object call1227 = callmethod(call1226, "value",
    0, params);
// compilenode returning call1227
// compilenode returning call1227
  Object call1228 = callmethod(call1227, "_escape",
    0, params);
// compilenode returning call1228
// compilenode returning call1228
  params[0] = call1228;
  Object opresult1230 = callmethod(opresult1225, "++", 1, params);
// compilenode returning opresult1230
  if (strlit1231 == NULL) {
    strlit1231 = alloc_String("""\x22""");
  }
// compilenode returning strlit1231
  params[0] = strlit1231;
  Object opresult1233 = callmethod(opresult1230, "++", 1, params);
// compilenode returning opresult1233
// Begin line 405
  setline(405);
// compilenode returning self
  params[0] = opresult1233;
  Object call1234 = callmethod(self, "out",
    1, params);
// compilenode returning call1234
// Begin line 406
  setline(406);
// Begin line 405
  setline(405);
// compilenode returning *var_args
// Begin line 406
  setline(406);
// Begin line 643
  setline(643);
  Object obj1237 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1237, self, 0);
  addmethod2(obj1237, "outer", &reader_genjs_outer_1238);
  adddatum2(obj1237, self, 0);
  block_savedest(obj1237);
  Object **closure1239 = createclosure(1);
  Object *selfpp1244 = alloc_var();
  *selfpp1244 = self;
  addtoclosure(closure1239, selfpp1244);
  struct UserObject *uo1239 = (struct UserObject*)obj1237;
  uo1239->data[1] = (Object)closure1239;
  addmethod2(obj1237, "apply", &meth_genjs_apply1239);
  set_type(obj1237, 0);
// compilenode returning obj1237
  setclassname(obj1237, "Block<genjs:1236>");
// compilenode returning obj1237
  params[0] = *var_args;
  Object iter1235 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond1235 = callmethod(iter1235, "havemore", 0, NULL);
    if (!istrue(cond1235)) break;
    params[0] = callmethod(iter1235, "next", 0, NULL);
    callmethod(obj1237, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 408
  setline(408);
  if (strlit1245 == NULL) {
    strlit1245 = alloc_String(");");
  }
// compilenode returning strlit1245
// Begin line 409
  setline(409);
// compilenode returning self
  params[0] = strlit1245;
  Object call1246 = callmethod(self, "out",
    1, params);
// compilenode returning call1246
    if1205 = call1246;
  } else {
// Begin line 411
  setline(411);
// Begin line 410
  setline(410);
  if (strlit1247 == NULL) {
    strlit1247 = alloc_String("this");
  }
// compilenode returning strlit1247
  *var_obj = strlit1247;
  if (strlit1247 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 412
  setline(412);
// Begin line 411
  setline(411);
  if (strlit1249 == NULL) {
    strlit1249 = alloc_String("  var call");
  }
// compilenode returning strlit1249
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1251 = callmethod(strlit1249, "++", 1, params);
// compilenode returning opresult1251
  if (strlit1252 == NULL) {
    strlit1252 = alloc_String(" = callmethod(this,");
  }
// compilenode returning strlit1252
  params[0] = strlit1252;
  Object opresult1254 = callmethod(opresult1251, "++", 1, params);
// compilenode returning opresult1254
// Begin line 412
  setline(412);
  if (strlit1255 == NULL) {
    strlit1255 = alloc_String("""\x22""");
  }
// compilenode returning strlit1255
  params[0] = strlit1255;
  Object opresult1257 = callmethod(opresult1254, "++", 1, params);
// compilenode returning opresult1257
// Begin line 643
  setline(643);
// Begin line 412
  setline(412);
// Begin line 643
  setline(643);
// Begin line 412
  setline(412);
// Begin line 643
  setline(643);
// Begin line 412
  setline(412);
// compilenode returning *var_o
  Object call1258 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1258
// compilenode returning call1258
  Object call1259 = callmethod(call1258, "value",
    0, params);
// compilenode returning call1259
// compilenode returning call1259
  Object call1260 = callmethod(call1259, "_escape",
    0, params);
// compilenode returning call1260
// compilenode returning call1260
  params[0] = call1260;
  Object opresult1262 = callmethod(opresult1257, "++", 1, params);
// compilenode returning opresult1262
  if (strlit1263 == NULL) {
    strlit1263 = alloc_String("""\x22""");
  }
// compilenode returning strlit1263
  params[0] = strlit1263;
  Object opresult1265 = callmethod(opresult1262, "++", 1, params);
// compilenode returning opresult1265
// Begin line 413
  setline(413);
// compilenode returning self
  params[0] = opresult1265;
  Object call1266 = callmethod(self, "out",
    1, params);
// compilenode returning call1266
// Begin line 414
  setline(414);
// Begin line 413
  setline(413);
// compilenode returning *var_args
// Begin line 414
  setline(414);
// Begin line 643
  setline(643);
  Object obj1269 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1269, self, 0);
  addmethod2(obj1269, "outer", &reader_genjs_outer_1270);
  adddatum2(obj1269, self, 0);
  block_savedest(obj1269);
  Object **closure1271 = createclosure(1);
  Object *selfpp1276 = alloc_var();
  *selfpp1276 = self;
  addtoclosure(closure1271, selfpp1276);
  struct UserObject *uo1271 = (struct UserObject*)obj1269;
  uo1271->data[1] = (Object)closure1271;
  addmethod2(obj1269, "apply", &meth_genjs_apply1271);
  set_type(obj1269, 0);
// compilenode returning obj1269
  setclassname(obj1269, "Block<genjs:1268>");
// compilenode returning obj1269
  params[0] = *var_args;
  Object iter1267 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond1267 = callmethod(iter1267, "havemore", 0, NULL);
    if (!istrue(cond1267)) break;
    params[0] = callmethod(iter1267, "next", 0, NULL);
    callmethod(obj1269, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 416
  setline(416);
  if (strlit1277 == NULL) {
    strlit1277 = alloc_String(");");
  }
// compilenode returning strlit1277
// Begin line 417
  setline(417);
// compilenode returning self
  params[0] = strlit1277;
  Object call1278 = callmethod(self, "out",
    1, params);
// compilenode returning call1278
    if1205 = call1278;
  }
// compilenode returning if1205
// Begin line 419
  setline(419);
// Begin line 643
  setline(643);
// Begin line 419
  setline(419);
// Begin line 418
  setline(418);
  if (strlit1279 == NULL) {
    strlit1279 = alloc_String("call");
  }
// compilenode returning strlit1279
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1281 = callmethod(strlit1279, "++", 1, params);
// compilenode returning opresult1281
// compilenode returning *var_o
  params[0] = opresult1281;
  Object call1282 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1282
// compilenode returning nothing
// Begin line 420
  setline(420);
// Begin line 419
  setline(419);
// compilenode returning *var_auto_count
  Object num1283 = alloc_Float64(1.0);
// compilenode returning num1283
  params[0] = num1283;
  Object sum1285 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1285
  *var_auto_count = sum1285;
  if (sum1285 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply1300(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object *var_escval = closure[1];
  Object self = *closure[2];
// Begin line 428
  setline(428);
// Begin line 429
  setline(429);
// Begin line 426
  setline(426);
// compilenode returning *var_i
  Object num1302 = alloc_Float64(2.0);
// compilenode returning num1302
  params[0] = num1302;
  Object modulus1304 = callmethod(*var_i, "%", 1, params);
// compilenode returning modulus1304
  Object num1305 = alloc_Float64(0.0);
// compilenode returning num1305
  params[0] = num1305;
  Object opresult1307 = callmethod(modulus1304, "==", 1, params);
// compilenode returning opresult1307
  Object if1301;
  if (istrue(opresult1307)) {
// Begin line 428
  setline(428);
// Begin line 427
  setline(427);
// compilenode returning *var_escval
  if (strlit1308 == NULL) {
    strlit1308 = alloc_String("\\");
  }
// compilenode returning strlit1308
  params[0] = strlit1308;
  Object opresult1310 = callmethod(*var_escval, "++", 1, params);
// compilenode returning opresult1310
  *var_escval = opresult1310;
  if (opresult1310 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1301 = nothing;
  } else {
  }
// compilenode returning if1301
// Begin line 430
  setline(430);
// Begin line 429
  setline(429);
// compilenode returning *var_escval
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult1313 = callmethod(*var_escval, "++", 1, params);
// compilenode returning opresult1313
  *var_escval = opresult1313;
  if (opresult1313 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 431
  setline(431);
// Begin line 430
  setline(430);
// compilenode returning *var_i
  Object num1315 = alloc_Float64(1.0);
// compilenode returning num1315
  params[0] = num1315;
  Object sum1317 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum1317
  *var_i = sum1317;
  if (sum1317 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileoctets1287(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[26];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_escval = alloc_var();
  *var_escval = undefined;
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 423
  setline(423);
// Begin line 422
  setline(422);
  if (strlit1288 == NULL) {
    strlit1288 = alloc_String("");
  }
// compilenode returning strlit1288
  var_escval = alloc_var();
  *var_escval = strlit1288;
  if (strlit1288 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 423
  setline(423);
// Begin line 643
  setline(643);
// Begin line 423
  setline(423);
// compilenode returning *var_o
  Object call1289 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1289
// compilenode returning call1289
  Object call1290 = gracelib_length(call1289);
// compilenode returning call1290
  Object num1291 = alloc_Float64(2.0);
// compilenode returning num1291
  params[0] = num1291;
  Object quotient1293 = callmethod(call1290, "/", 1, params);
// compilenode returning quotient1293
  var_l = alloc_var();
  *var_l = quotient1293;
  if (quotient1293 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 425
  setline(425);
// Begin line 424
  setline(424);
  Object num1294 = alloc_Float64(0.0);
// compilenode returning num1294
  var_i = alloc_var();
  *var_i = num1294;
  if (num1294 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 431
  setline(431);
// Begin line 432
  setline(432);
// Begin line 643
  setline(643);
// Begin line 425
  setline(425);
// compilenode returning *var_o
  Object call1296 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1296
// compilenode returning call1296
// Begin line 431
  setline(431);
// Begin line 643
  setline(643);
  Object obj1298 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1298, self, 0);
  addmethod2(obj1298, "outer", &reader_genjs_outer_1299);
  adddatum2(obj1298, self, 0);
  block_savedest(obj1298);
  Object **closure1300 = createclosure(3);
  addtoclosure(closure1300, var_i);
  addtoclosure(closure1300, var_escval);
  Object *selfpp1319 = alloc_var();
  *selfpp1319 = self;
  addtoclosure(closure1300, selfpp1319);
  struct UserObject *uo1300 = (struct UserObject*)obj1298;
  uo1300->data[1] = (Object)closure1300;
  addmethod2(obj1298, "apply", &meth_genjs_apply1300);
  set_type(obj1298, 0);
// compilenode returning obj1298
  setclassname(obj1298, "Block<genjs:1297>");
// compilenode returning obj1298
  params[0] = call1296;
  Object iter1295 = callmethod(call1296, "iter", 1, params);
  while(1) {
    Object cond1295 = callmethod(iter1295, "havemore", 0, NULL);
    if (!istrue(cond1295)) break;
    params[0] = callmethod(iter1295, "next", 0, NULL);
    callmethod(obj1298, "apply", 1, params);
  }
// compilenode returning call1296
// Begin line 433
  setline(433);
// Begin line 432
  setline(432);
  if (strlit1320 == NULL) {
    strlit1320 = alloc_String("  %tmp");
  }
// compilenode returning strlit1320
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1322 = callmethod(strlit1320, "++", 1, params);
// compilenode returning opresult1322
  if (strlit1323 == NULL) {
    strlit1323 = alloc_String(" = load %object** @.octlit");
  }
// compilenode returning strlit1323
  params[0] = strlit1323;
  Object opresult1325 = callmethod(opresult1322, "++", 1, params);
// compilenode returning opresult1325
// Begin line 433
  setline(433);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1327 = callmethod(opresult1325, "++", 1, params);
// compilenode returning opresult1327
// Begin line 434
  setline(434);
// compilenode returning self
  params[0] = opresult1327;
  Object call1328 = callmethod(self, "out",
    1, params);
// compilenode returning call1328
// Begin line 435
  setline(435);
// Begin line 434
  setline(434);
  if (strlit1329 == NULL) {
    strlit1329 = alloc_String("  %cmp");
  }
// compilenode returning strlit1329
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1331 = callmethod(strlit1329, "++", 1, params);
// compilenode returning opresult1331
  if (strlit1332 == NULL) {
    strlit1332 = alloc_String(" = icmp ne %object* %tmp");
  }
// compilenode returning strlit1332
  params[0] = strlit1332;
  Object opresult1334 = callmethod(opresult1331, "++", 1, params);
// compilenode returning opresult1334
// Begin line 435
  setline(435);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1336 = callmethod(opresult1334, "++", 1, params);
// compilenode returning opresult1336
  if (strlit1337 == NULL) {
    strlit1337 = alloc_String(", null");
  }
// compilenode returning strlit1337
  params[0] = strlit1337;
  Object opresult1339 = callmethod(opresult1336, "++", 1, params);
// compilenode returning opresult1339
// Begin line 436
  setline(436);
// compilenode returning self
  params[0] = opresult1339;
  Object call1340 = callmethod(self, "out",
    1, params);
// compilenode returning call1340
// Begin line 438
  setline(438);
// Begin line 436
  setline(436);
  if (strlit1341 == NULL) {
    strlit1341 = alloc_String("  br i1 %cmp");
  }
// compilenode returning strlit1341
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1343 = callmethod(strlit1341, "++", 1, params);
// compilenode returning opresult1343
  if (strlit1344 == NULL) {
    strlit1344 = alloc_String(", label %octlit");
  }
// compilenode returning strlit1344
  params[0] = strlit1344;
  Object opresult1346 = callmethod(opresult1343, "++", 1, params);
// compilenode returning opresult1346
// Begin line 437
  setline(437);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1348 = callmethod(opresult1346, "++", 1, params);
// compilenode returning opresult1348
  if (strlit1349 == NULL) {
    strlit1349 = alloc_String(".already, label %octlit");
  }
// compilenode returning strlit1349
  params[0] = strlit1349;
  Object opresult1351 = callmethod(opresult1348, "++", 1, params);
// compilenode returning opresult1351
// Begin line 438
  setline(438);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1353 = callmethod(opresult1351, "++", 1, params);
// compilenode returning opresult1353
  if (strlit1354 == NULL) {
    strlit1354 = alloc_String(".define");
  }
// compilenode returning strlit1354
  params[0] = strlit1354;
  Object opresult1356 = callmethod(opresult1353, "++", 1, params);
// compilenode returning opresult1356
// Begin line 439
  setline(439);
// compilenode returning self
  params[0] = opresult1356;
  Object call1357 = callmethod(self, "out",
    1, params);
// compilenode returning call1357
  if (strlit1358 == NULL) {
    strlit1358 = alloc_String("octlit");
  }
// compilenode returning strlit1358
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1360 = callmethod(strlit1358, "++", 1, params);
// compilenode returning opresult1360
  if (strlit1361 == NULL) {
    strlit1361 = alloc_String(".already");
  }
// compilenode returning strlit1361
  params[0] = strlit1361;
  Object opresult1363 = callmethod(opresult1360, "++", 1, params);
// compilenode returning opresult1363
// Begin line 440
  setline(440);
// compilenode returning self
  params[0] = opresult1363;
  Object call1364 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1364
// Begin line 441
  setline(441);
// Begin line 440
  setline(440);
  if (strlit1365 == NULL) {
    strlit1365 = alloc_String("  %alreadyoctets");
  }
// compilenode returning strlit1365
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1367 = callmethod(strlit1365, "++", 1, params);
// compilenode returning opresult1367
  if (strlit1368 == NULL) {
    strlit1368 = alloc_String(" = load %object** @.octlit");
  }
// compilenode returning strlit1368
  params[0] = strlit1368;
  Object opresult1370 = callmethod(opresult1367, "++", 1, params);
// compilenode returning opresult1370
// Begin line 441
  setline(441);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1372 = callmethod(opresult1370, "++", 1, params);
// compilenode returning opresult1372
// Begin line 442
  setline(442);
// compilenode returning self
  params[0] = opresult1372;
  Object call1373 = callmethod(self, "out",
    1, params);
// compilenode returning call1373
  if (strlit1374 == NULL) {
    strlit1374 = alloc_String("  br label %octlit");
  }
// compilenode returning strlit1374
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1376 = callmethod(strlit1374, "++", 1, params);
// compilenode returning opresult1376
  if (strlit1377 == NULL) {
    strlit1377 = alloc_String(".end");
  }
// compilenode returning strlit1377
  params[0] = strlit1377;
  Object opresult1379 = callmethod(opresult1376, "++", 1, params);
// compilenode returning opresult1379
// Begin line 443
  setline(443);
// compilenode returning self
  params[0] = opresult1379;
  Object call1380 = callmethod(self, "out",
    1, params);
// compilenode returning call1380
  if (strlit1381 == NULL) {
    strlit1381 = alloc_String("octlit");
  }
// compilenode returning strlit1381
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1383 = callmethod(strlit1381, "++", 1, params);
// compilenode returning opresult1383
  if (strlit1384 == NULL) {
    strlit1384 = alloc_String(".define");
  }
// compilenode returning strlit1384
  params[0] = strlit1384;
  Object opresult1386 = callmethod(opresult1383, "++", 1, params);
// compilenode returning opresult1386
// Begin line 444
  setline(444);
// compilenode returning self
  params[0] = opresult1386;
  Object call1387 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1387
  if (strlit1388 == NULL) {
    strlit1388 = alloc_String("  %oct");
  }
// compilenode returning strlit1388
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1390 = callmethod(strlit1388, "++", 1, params);
// compilenode returning opresult1390
  if (strlit1391 == NULL) {
    strlit1391 = alloc_String(" = getelementptr [");
  }
// compilenode returning strlit1391
  params[0] = strlit1391;
  Object opresult1393 = callmethod(opresult1390, "++", 1, params);
// compilenode returning opresult1393
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult1395 = callmethod(opresult1393, "++", 1, params);
// compilenode returning opresult1395
  if (strlit1396 == NULL) {
    strlit1396 = alloc_String(" x i8]* @.oct");
  }
// compilenode returning strlit1396
  params[0] = strlit1396;
  Object opresult1398 = callmethod(opresult1395, "++", 1, params);
// compilenode returning opresult1398
// Begin line 643
  setline(643);
// Begin line 444
  setline(444);
// compilenode returning *var_constants
  Object call1399 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call1399
// compilenode returning call1399
  params[0] = call1399;
  Object opresult1401 = callmethod(opresult1398, "++", 1, params);
// compilenode returning opresult1401
  if (strlit1402 == NULL) {
    strlit1402 = alloc_String(", i32 0, i32 0");
  }
// compilenode returning strlit1402
  params[0] = strlit1402;
  Object opresult1404 = callmethod(opresult1401, "++", 1, params);
// compilenode returning opresult1404
// Begin line 445
  setline(445);
// compilenode returning self
  params[0] = opresult1404;
  Object call1405 = callmethod(self, "out",
    1, params);
// compilenode returning call1405
// Begin line 447
  setline(447);
// Begin line 445
  setline(445);
  if (strlit1406 == NULL) {
    strlit1406 = alloc_String("  %defoctets");
  }
// compilenode returning strlit1406
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1408 = callmethod(strlit1406, "++", 1, params);
// compilenode returning opresult1408
  if (strlit1409 == NULL) {
    strlit1409 = alloc_String(" = call %object* ");
  }
// compilenode returning strlit1409
  params[0] = strlit1409;
  Object opresult1411 = callmethod(opresult1408, "++", 1, params);
// compilenode returning opresult1411
// Begin line 446
  setline(446);
  if (strlit1412 == NULL) {
    strlit1412 = alloc_String("@alloc_Octets(i8* ");
  }
// compilenode returning strlit1412
  params[0] = strlit1412;
  Object opresult1414 = callmethod(opresult1411, "++", 1, params);
// compilenode returning opresult1414
// Begin line 447
  setline(447);
  if (strlit1415 == NULL) {
    strlit1415 = alloc_String("%oct");
  }
// compilenode returning strlit1415
  params[0] = strlit1415;
  Object opresult1417 = callmethod(opresult1414, "++", 1, params);
// compilenode returning opresult1417
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1419 = callmethod(opresult1417, "++", 1, params);
// compilenode returning opresult1419
  if (strlit1420 == NULL) {
    strlit1420 = alloc_String(", i32 ");
  }
// compilenode returning strlit1420
  params[0] = strlit1420;
  Object opresult1422 = callmethod(opresult1419, "++", 1, params);
// compilenode returning opresult1422
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult1424 = callmethod(opresult1422, "++", 1, params);
// compilenode returning opresult1424
  if (strlit1425 == NULL) {
    strlit1425 = alloc_String(")");
  }
// compilenode returning strlit1425
  params[0] = strlit1425;
  Object opresult1427 = callmethod(opresult1424, "++", 1, params);
// compilenode returning opresult1427
// Begin line 448
  setline(448);
// compilenode returning self
  params[0] = opresult1427;
  Object call1428 = callmethod(self, "out",
    1, params);
// compilenode returning call1428
// Begin line 449
  setline(449);
// Begin line 448
  setline(448);
  if (strlit1429 == NULL) {
    strlit1429 = alloc_String("  store %object* %defoctets");
  }
// compilenode returning strlit1429
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1431 = callmethod(strlit1429, "++", 1, params);
// compilenode returning opresult1431
  if (strlit1432 == NULL) {
    strlit1432 = alloc_String(", %object** ");
  }
// compilenode returning strlit1432
  params[0] = strlit1432;
  Object opresult1434 = callmethod(opresult1431, "++", 1, params);
// compilenode returning opresult1434
// Begin line 449
  setline(449);
  if (strlit1435 == NULL) {
    strlit1435 = alloc_String("@.octlit");
  }
// compilenode returning strlit1435
  params[0] = strlit1435;
  Object opresult1437 = callmethod(opresult1434, "++", 1, params);
// compilenode returning opresult1437
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1439 = callmethod(opresult1437, "++", 1, params);
// compilenode returning opresult1439
// Begin line 450
  setline(450);
// compilenode returning self
  params[0] = opresult1439;
  Object call1440 = callmethod(self, "out",
    1, params);
// compilenode returning call1440
  if (strlit1441 == NULL) {
    strlit1441 = alloc_String("br label %octlit");
  }
// compilenode returning strlit1441
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1443 = callmethod(strlit1441, "++", 1, params);
// compilenode returning opresult1443
  if (strlit1444 == NULL) {
    strlit1444 = alloc_String(".end");
  }
// compilenode returning strlit1444
  params[0] = strlit1444;
  Object opresult1446 = callmethod(opresult1443, "++", 1, params);
// compilenode returning opresult1446
// Begin line 451
  setline(451);
// compilenode returning self
  params[0] = opresult1446;
  Object call1447 = callmethod(self, "out",
    1, params);
// compilenode returning call1447
  if (strlit1448 == NULL) {
    strlit1448 = alloc_String("octlit");
  }
// compilenode returning strlit1448
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1450 = callmethod(strlit1448, "++", 1, params);
// compilenode returning opresult1450
  if (strlit1451 == NULL) {
    strlit1451 = alloc_String(".end");
  }
// compilenode returning strlit1451
  params[0] = strlit1451;
  Object opresult1453 = callmethod(opresult1450, "++", 1, params);
// compilenode returning opresult1453
// Begin line 452
  setline(452);
// compilenode returning self
  params[0] = opresult1453;
  Object call1454 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1454
// Begin line 455
  setline(455);
// Begin line 452
  setline(452);
  if (strlit1455 == NULL) {
    strlit1455 = alloc_String(" %octets");
  }
// compilenode returning strlit1455
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1457 = callmethod(strlit1455, "++", 1, params);
// compilenode returning opresult1457
  if (strlit1458 == NULL) {
    strlit1458 = alloc_String(" = phi %object* [%alreadyoctets");
  }
// compilenode returning strlit1458
  params[0] = strlit1458;
  Object opresult1460 = callmethod(opresult1457, "++", 1, params);
// compilenode returning opresult1460
// Begin line 453
  setline(453);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1462 = callmethod(opresult1460, "++", 1, params);
// compilenode returning opresult1462
  if (strlit1463 == NULL) {
    strlit1463 = alloc_String(", %octlit");
  }
// compilenode returning strlit1463
  params[0] = strlit1463;
  Object opresult1465 = callmethod(opresult1462, "++", 1, params);
// compilenode returning opresult1465
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1467 = callmethod(opresult1465, "++", 1, params);
// compilenode returning opresult1467
  if (strlit1468 == NULL) {
    strlit1468 = alloc_String(".already], ");
  }
// compilenode returning strlit1468
  params[0] = strlit1468;
  Object opresult1470 = callmethod(opresult1467, "++", 1, params);
// compilenode returning opresult1470
// Begin line 454
  setline(454);
  if (strlit1471 == NULL) {
    strlit1471 = alloc_String("[%defoctets");
  }
// compilenode returning strlit1471
  params[0] = strlit1471;
  Object opresult1473 = callmethod(opresult1470, "++", 1, params);
// compilenode returning opresult1473
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1475 = callmethod(opresult1473, "++", 1, params);
// compilenode returning opresult1475
  if (strlit1476 == NULL) {
    strlit1476 = alloc_String(", %octlit");
  }
// compilenode returning strlit1476
  params[0] = strlit1476;
  Object opresult1478 = callmethod(opresult1475, "++", 1, params);
// compilenode returning opresult1478
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1480 = callmethod(opresult1478, "++", 1, params);
// compilenode returning opresult1480
// Begin line 455
  setline(455);
  if (strlit1481 == NULL) {
    strlit1481 = alloc_String(".define]");
  }
// compilenode returning strlit1481
  params[0] = strlit1481;
  Object opresult1483 = callmethod(opresult1480, "++", 1, params);
// compilenode returning opresult1483
// Begin line 456
  setline(456);
// compilenode returning self
  params[0] = opresult1483;
  Object call1484 = callmethod(self, "out",
    1, params);
// compilenode returning call1484
// Begin line 458
  setline(458);
// Begin line 456
  setline(456);
  if (strlit1485 == NULL) {
    strlit1485 = alloc_String("@.oct");
  }
// compilenode returning strlit1485
// Begin line 458
  setline(458);
// Begin line 643
  setline(643);
// Begin line 456
  setline(456);
// compilenode returning *var_constants
  Object call1486 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call1486
// compilenode returning call1486
  params[0] = call1486;
  Object opresult1488 = callmethod(strlit1485, "++", 1, params);
// compilenode returning opresult1488
  if (strlit1489 == NULL) {
    strlit1489 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit1489
  params[0] = strlit1489;
  Object opresult1491 = callmethod(opresult1488, "++", 1, params);
// compilenode returning opresult1491
// Begin line 457
  setline(457);
  if (strlit1492 == NULL) {
    strlit1492 = alloc_String("constant [");
  }
// compilenode returning strlit1492
  params[0] = strlit1492;
  Object opresult1494 = callmethod(opresult1491, "++", 1, params);
// compilenode returning opresult1494
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult1496 = callmethod(opresult1494, "++", 1, params);
// compilenode returning opresult1496
  if (strlit1497 == NULL) {
    strlit1497 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit1497
  params[0] = strlit1497;
  Object opresult1499 = callmethod(opresult1496, "++", 1, params);
// compilenode returning opresult1499
// compilenode returning *var_escval
  params[0] = *var_escval;
  Object opresult1501 = callmethod(opresult1499, "++", 1, params);
// compilenode returning opresult1501
  if (strlit1502 == NULL) {
    strlit1502 = alloc_String("""\x22""");
  }
// compilenode returning strlit1502
  params[0] = strlit1502;
  Object opresult1504 = callmethod(opresult1501, "++", 1, params);
// compilenode returning opresult1504
  var_con = alloc_var();
  *var_con = opresult1504;
  if (opresult1504 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 458
  setline(458);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call1505 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call1505
// Begin line 461
  setline(461);
// Begin line 459
  setline(459);
  if (strlit1506 == NULL) {
    strlit1506 = alloc_String("@.octlit");
  }
// compilenode returning strlit1506
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1508 = callmethod(strlit1506, "++", 1, params);
// compilenode returning opresult1508
// Begin line 460
  setline(460);
  if (strlit1509 == NULL) {
    strlit1509 = alloc_String(" = private global %object* null");
  }
// compilenode returning strlit1509
  params[0] = strlit1509;
  Object opresult1511 = callmethod(opresult1508, "++", 1, params);
// compilenode returning opresult1511
  *var_con = opresult1511;
  if (opresult1511 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 461
  setline(461);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call1513 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call1513
// Begin line 463
  setline(463);
// Begin line 643
  setline(643);
// Begin line 463
  setline(463);
// Begin line 462
  setline(462);
  if (strlit1514 == NULL) {
    strlit1514 = alloc_String("%octets");
  }
// compilenode returning strlit1514
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1516 = callmethod(strlit1514, "++", 1, params);
// compilenode returning opresult1516
// compilenode returning *var_o
  params[0] = opresult1516;
  Object call1517 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1517
// compilenode returning nothing
// Begin line 464
  setline(464);
// Begin line 463
  setline(463);
// compilenode returning *var_auto_count
  Object num1518 = alloc_Float64(1.0);
// compilenode returning num1518
  params[0] = num1518;
  Object sum1520 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1520
  *var_auto_count = sum1520;
  if (sum1520 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compileimport1522(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[27];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_con = alloc_var();
  *var_con = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
// Begin line 466
  setline(466);
  if (strlit1523 == NULL) {
    strlit1523 = alloc_String("// Import of ");
  }
// compilenode returning strlit1523
// Begin line 643
  setline(643);
// Begin line 466
  setline(466);
// Begin line 643
  setline(643);
// Begin line 466
  setline(466);
// compilenode returning *var_o
  Object call1524 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1524
// compilenode returning call1524
  Object call1525 = callmethod(call1524, "value",
    0, params);
// compilenode returning call1525
// compilenode returning call1525
  params[0] = call1525;
  Object opresult1527 = callmethod(strlit1523, "++", 1, params);
// compilenode returning opresult1527
// Begin line 467
  setline(467);
// compilenode returning self
  params[0] = opresult1527;
  Object call1528 = callmethod(self, "out",
    1, params);
// compilenode returning call1528
// Begin line 468
  setline(468);
  var_con = alloc_var();
  *var_con = undefined;
// compilenode returning nothing
// Begin line 643
  setline(643);
// Begin line 468
  setline(468);
// Begin line 643
  setline(643);
// Begin line 468
  setline(468);
// Begin line 643
  setline(643);
// Begin line 468
  setline(468);
// compilenode returning *var_o
  Object call1529 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1529
// compilenode returning call1529
  Object call1530 = callmethod(call1529, "value",
    0, params);
// compilenode returning call1530
// compilenode returning call1530
  Object call1531 = callmethod(call1530, "_escape",
    0, params);
// compilenode returning call1531
// compilenode returning call1531
  var_nm = alloc_var();
  *var_nm = call1531;
  if (call1531 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 469
  setline(469);
  if (strlit1532 == NULL) {
    strlit1532 = alloc_String("  var ");
  }
// compilenode returning strlit1532
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call1533 = callmethod(self, "varf",
    1, params);
// compilenode returning call1533
  params[0] = call1533;
  Object opresult1535 = callmethod(strlit1532, "++", 1, params);
// compilenode returning opresult1535
  if (strlit1536 == NULL) {
    strlit1536 = alloc_String(" = do_import(""\x22""");
  }
// compilenode returning strlit1536
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1538 = callmethod(strlit1536, "++", 1, params);
// compilenode returning opresult1538
  if (strlit1539 == NULL) {
    strlit1539 = alloc_String("""\x22"", gracecode_");
  }
// compilenode returning strlit1539
  params[0] = strlit1539;
  Object opresult1541 = callmethod(opresult1538, "++", 1, params);
// compilenode returning opresult1541
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1543 = callmethod(opresult1541, "++", 1, params);
// compilenode returning opresult1543
  if (strlit1544 == NULL) {
    strlit1544 = alloc_String(");");
  }
// compilenode returning strlit1544
  params[0] = strlit1544;
  Object opresult1546 = callmethod(opresult1543, "++", 1, params);
// compilenode returning opresult1546
  params[0] = opresult1546;
  Object opresult1548 = callmethod(opresult1535, "++", 1, params);
// compilenode returning opresult1548
// Begin line 470
  setline(470);
// compilenode returning self
  params[0] = opresult1548;
  Object call1549 = callmethod(self, "out",
    1, params);
// compilenode returning call1549
// Begin line 471
  setline(471);
// Begin line 643
  setline(643);
// Begin line 470
  setline(470);
  if (strlit1550 == NULL) {
    strlit1550 = alloc_String("undefined");
  }
// compilenode returning strlit1550
// compilenode returning *var_o
  params[0] = strlit1550;
  Object call1551 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1551
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_compilereturn1552(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[28];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_inBlock = closure[0];
  Object *var_reg = alloc_var();
  *var_reg = undefined;
// Begin line 473
  setline(473);
// Begin line 643
  setline(643);
// Begin line 473
  setline(473);
// compilenode returning *var_o
  Object call1553 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1553
// compilenode returning call1553
// Begin line 474
  setline(474);
// compilenode returning self
  params[0] = call1553;
  Object call1554 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1554
  var_reg = alloc_var();
  *var_reg = call1554;
  if (call1554 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 477
  setline(477);
// Begin line 474
  setline(474);
// compilenode returning *var_inBlock
  Object if1555;
  if (istrue(*var_inBlock)) {
// Begin line 475
  setline(475);
  if (strlit1556 == NULL) {
    strlit1556 = alloc_String("  throw new ReturnException(");
  }
// compilenode returning strlit1556
// compilenode returning *var_reg
  params[0] = *var_reg;
  Object opresult1558 = callmethod(strlit1556, "++", 1, params);
// compilenode returning opresult1558
  if (strlit1559 == NULL) {
    strlit1559 = alloc_String(", returnTarget);");
  }
// compilenode returning strlit1559
  params[0] = strlit1559;
  Object opresult1561 = callmethod(opresult1558, "++", 1, params);
// compilenode returning opresult1561
// Begin line 476
  setline(476);
// compilenode returning self
  params[0] = opresult1561;
  Object call1562 = callmethod(self, "out",
    1, params);
// compilenode returning call1562
    if1555 = call1562;
  } else {
// Begin line 477
  setline(477);
  if (strlit1563 == NULL) {
    strlit1563 = alloc_String("  return ");
  }
// compilenode returning strlit1563
// compilenode returning *var_reg
  params[0] = *var_reg;
  Object opresult1565 = callmethod(strlit1563, "++", 1, params);
// compilenode returning opresult1565
// Begin line 478
  setline(478);
// compilenode returning self
  params[0] = opresult1565;
  Object call1566 = callmethod(self, "out",
    1, params);
// compilenode returning call1566
    if1555 = call1566;
  }
// compilenode returning if1555
// Begin line 480
  setline(480);
// Begin line 643
  setline(643);
// Begin line 479
  setline(479);
  if (strlit1567 == NULL) {
    strlit1567 = alloc_String("undefined");
  }
// compilenode returning strlit1567
// compilenode returning *var_o
  params[0] = strlit1567;
  Object call1568 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1568
// compilenode returning nothing
  return nothing;
}
Object meth_genjs_apply1612(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_os = closure[0];
  Object self = *closure[1];
// Begin line 510
  setline(510);
// Begin line 511
  setline(511);
// Begin line 496
  setline(496);
// compilenode returning *var_c
  if (strlit1614 == NULL) {
    strlit1614 = alloc_String("""\x22""");
  }
// compilenode returning strlit1614
  params[0] = strlit1614;
  Object opresult1616 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1616
  Object if1613;
  if (istrue(opresult1616)) {
// Begin line 498
  setline(498);
// Begin line 497
  setline(497);
// compilenode returning *var_os
  if (strlit1617 == NULL) {
    strlit1617 = alloc_String("\\""\x22""");
  }
// compilenode returning strlit1617
  params[0] = strlit1617;
  Object opresult1619 = callmethod(*var_os, "++", 1, params);
// compilenode returning opresult1619
  *var_os = opresult1619;
  if (opresult1619 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1613 = nothing;
  } else {
// Begin line 510
  setline(510);
// Begin line 500
  setline(500);
// Begin line 498
  setline(498);
// compilenode returning *var_c
  if (strlit1622 == NULL) {
    strlit1622 = alloc_String("\\");
  }
// compilenode returning strlit1622
  params[0] = strlit1622;
  Object opresult1624 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1624
  Object if1621;
  if (istrue(opresult1624)) {
// Begin line 500
  setline(500);
// Begin line 499
  setline(499);
// compilenode returning *var_os
  if (strlit1625 == NULL) {
    strlit1625 = alloc_String("\\\\");
  }
// compilenode returning strlit1625
  params[0] = strlit1625;
  Object opresult1627 = callmethod(*var_os, "++", 1, params);
// compilenode returning opresult1627
  *var_os = opresult1627;
  if (opresult1627 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1621 = nothing;
  } else {
// Begin line 510
  setline(510);
// Begin line 502
  setline(502);
// Begin line 500
  setline(500);
// compilenode returning *var_c
  if (strlit1630 == NULL) {
    strlit1630 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1630
  params[0] = strlit1630;
  Object opresult1632 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1632
  Object if1629;
  if (istrue(opresult1632)) {
// Begin line 502
  setline(502);
// Begin line 501
  setline(501);
// compilenode returning *var_os
  if (strlit1633 == NULL) {
    strlit1633 = alloc_String("\\n");
  }
// compilenode returning strlit1633
  params[0] = strlit1633;
  Object opresult1635 = callmethod(*var_os, "++", 1, params);
// compilenode returning opresult1635
  *var_os = opresult1635;
  if (opresult1635 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1629 = nothing;
  } else {
// Begin line 510
  setline(510);
// Begin line 508
  setline(508);
// Begin line 643
  setline(643);
// Begin line 502
  setline(502);
// compilenode returning *var_c
  Object call1638 = callmethod(*var_c, "ord",
    0, params);
// compilenode returning call1638
// compilenode returning call1638
  Object num1639 = alloc_Float64(32.0);
// compilenode returning num1639
  params[0] = num1639;
  Object opresult1641 = callmethod(call1638, "<", 1, params);
// compilenode returning opresult1641
// Begin line 508
  setline(508);
// Begin line 643
  setline(643);
// Begin line 502
  setline(502);
// compilenode returning *var_c
  Object call1642 = callmethod(*var_c, "ord",
    0, params);
// compilenode returning call1642
// compilenode returning call1642
  Object num1643 = alloc_Float64(126.0);
// compilenode returning num1643
  params[0] = num1643;
  Object opresult1645 = callmethod(call1642, ">", 1, params);
// compilenode returning opresult1645
  params[0] = opresult1645;
  Object opresult1647 = callmethod(opresult1641, "|", 1, params);
// compilenode returning opresult1647
  Object if1637;
  if (istrue(opresult1647)) {
  Object *var_uh = alloc_var();
  *var_uh = undefined;
// Begin line 503
  setline(503);
// Begin line 643
  setline(643);
// Begin line 503
  setline(503);
// compilenode returning *var_c
  Object call1648 = callmethod(*var_c, "ord",
    0, params);
// compilenode returning call1648
// compilenode returning call1648
// compilenode returning module_util
  params[0] = call1648;
  Object call1649 = callmethod(module_util, "hex",
    1, params);
// compilenode returning call1649
  var_uh = alloc_var();
  *var_uh = call1649;
  if (call1649 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 506
  setline(506);
  Object while1650;
  while (1) {
// Begin line 507
  setline(507);
// Begin line 643
  setline(643);
// Begin line 504
  setline(504);
// compilenode returning *var_uh
  Object call1651 = callmethod(*var_uh, "size",
    0, params);
// compilenode returning call1651
// compilenode returning call1651
  Object num1652 = alloc_Float64(4.0);
// compilenode returning num1652
  params[0] = num1652;
  Object opresult1654 = callmethod(call1651, "<", 1, params);
// compilenode returning opresult1654
    while1650 = opresult1654;
    if (!istrue(opresult1654)) break;
// Begin line 506
  setline(506);
// Begin line 505
  setline(505);
  if (strlit1655 == NULL) {
    strlit1655 = alloc_String("0");
  }
// compilenode returning strlit1655
// compilenode returning *var_uh
  params[0] = *var_uh;
  Object opresult1657 = callmethod(strlit1655, "++", 1, params);
// compilenode returning opresult1657
  *var_uh = opresult1657;
  if (opresult1657 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while1650
// Begin line 508
  setline(508);
// Begin line 507
  setline(507);
// compilenode returning *var_os
  if (strlit1659 == NULL) {
    strlit1659 = alloc_String("\\u");
  }
// compilenode returning strlit1659
  params[0] = strlit1659;
  Object opresult1661 = callmethod(*var_os, "++", 1, params);
// compilenode returning opresult1661
// compilenode returning *var_uh
  params[0] = *var_uh;
  Object opresult1663 = callmethod(opresult1661, "++", 1, params);
// compilenode returning opresult1663
  *var_os = opresult1663;
  if (opresult1663 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1637 = nothing;
  } else {
// Begin line 510
  setline(510);
// Begin line 509
  setline(509);
// compilenode returning *var_os
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult1666 = callmethod(*var_os, "++", 1, params);
// compilenode returning opresult1666
  *var_os = opresult1666;
  if (opresult1666 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1637 = nothing;
  }
// compilenode returning if1637
    if1629 = if1637;
  }
// compilenode returning if1629
    if1621 = if1629;
  }
// compilenode returning if1621
    if1613 = if1621;
  }
// compilenode returning if1613
  return if1613;
}
Object meth_genjs_apply1875(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_prm = alloc_var();
  *var_prm = args[0];
  Object params[1];
  Object *var_args = closure[0];
  Object self = *closure[1];
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 587
  setline(587);
// compilenode returning *var_prm
// Begin line 588
  setline(588);
// compilenode returning self
  params[0] = *var_prm;
  Object call1876 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1876
  var_r = alloc_var();
  *var_r = call1876;
  if (call1876 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_args
  params[0] = *var_r;
  Object call1877 = callmethod(*var_args, "push",
    1, params);
// compilenode returning call1877
  return call1877;
}
Object meth_genjs_compilenode1569(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[29];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_linenum = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_tmp = closure[2];
  Object *var_l = alloc_var();
  *var_l = undefined;
// Begin line 484
  setline(484);
// Begin line 486
  setline(486);
// Begin line 482
  setline(482);
// compilenode returning *var_linenum
// Begin line 486
  setline(486);
// Begin line 643
  setline(643);
// Begin line 482
  setline(482);
// compilenode returning *var_o
  Object call1571 = callmethod(*var_o, "line",
    0, params);
// compilenode returning call1571
// compilenode returning call1571
  params[0] = call1571;
  Object opresult1573 = callmethod(*var_linenum, "/=", 1, params);
// compilenode returning opresult1573
  Object if1570;
  if (istrue(opresult1573)) {
// Begin line 484
  setline(484);
// Begin line 643
  setline(643);
// Begin line 483
  setline(483);
// compilenode returning *var_o
  Object call1574 = callmethod(*var_o, "line",
    0, params);
// compilenode returning call1574
// compilenode returning call1574
  *var_linenum = call1574;
  if (call1574 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 484
  setline(484);
  if (strlit1576 == NULL) {
    strlit1576 = alloc_String("  lineNumber = ");
  }
// compilenode returning strlit1576
// compilenode returning *var_linenum
  params[0] = *var_linenum;
  Object opresult1578 = callmethod(strlit1576, "++", 1, params);
// compilenode returning opresult1578
// compilenode returning self
  params[0] = opresult1578;
  Object call1579 = callmethod(self, "out",
    1, params);
// compilenode returning call1579
    if1570 = call1579;
  } else {
  }
// compilenode returning if1570
// Begin line 488
  setline(488);
// Begin line 489
  setline(489);
// Begin line 643
  setline(643);
// Begin line 486
  setline(486);
// compilenode returning *var_o
  Object call1581 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1581
// compilenode returning call1581
  if (strlit1582 == NULL) {
    strlit1582 = alloc_String("num");
  }
// compilenode returning strlit1582
  params[0] = strlit1582;
  Object opresult1584 = callmethod(call1581, "==", 1, params);
// compilenode returning opresult1584
  Object if1580;
  if (istrue(opresult1584)) {
// Begin line 488
  setline(488);
// Begin line 643
  setline(643);
// Begin line 488
  setline(488);
// Begin line 487
  setline(487);
  if (strlit1585 == NULL) {
    strlit1585 = alloc_String("new GraceNum(");
  }
// compilenode returning strlit1585
// Begin line 488
  setline(488);
// Begin line 643
  setline(643);
// Begin line 487
  setline(487);
// compilenode returning *var_o
  Object call1586 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1586
// compilenode returning call1586
  params[0] = call1586;
  Object opresult1588 = callmethod(strlit1585, "++", 1, params);
// compilenode returning opresult1588
  if (strlit1589 == NULL) {
    strlit1589 = alloc_String(")");
  }
// compilenode returning strlit1589
  params[0] = strlit1589;
  Object opresult1591 = callmethod(opresult1588, "++", 1, params);
// compilenode returning opresult1591
// compilenode returning *var_o
  params[0] = opresult1591;
  Object call1592 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1592
// compilenode returning nothing
    if1580 = nothing;
  } else {
  }
// compilenode returning if1580
// Begin line 490
  setline(490);
// Begin line 489
  setline(489);
  if (strlit1593 == NULL) {
    strlit1593 = alloc_String("");
  }
// compilenode returning strlit1593
  var_l = alloc_var();
  *var_l = strlit1593;
  if (strlit1593 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 519
  setline(519);
// Begin line 520
  setline(520);
// Begin line 643
  setline(643);
// Begin line 490
  setline(490);
// compilenode returning *var_o
  Object call1595 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1595
// compilenode returning call1595
  if (strlit1596 == NULL) {
    strlit1596 = alloc_String("string");
  }
// compilenode returning strlit1596
  params[0] = strlit1596;
  Object opresult1598 = callmethod(call1595, "==", 1, params);
// compilenode returning opresult1598
  Object if1594;
  if (istrue(opresult1598)) {
  Object *var_os = alloc_var();
  *var_os = undefined;
  Object *var_sval = alloc_var();
  *var_sval = undefined;
// Begin line 491
  setline(491);
// Begin line 643
  setline(643);
// Begin line 491
  setline(491);
// compilenode returning *var_o
  Object call1599 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1599
// compilenode returning call1599
  Object call1600 = gracelib_length(call1599);
// compilenode returning call1600
  *var_l = call1600;
  if (call1600 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 493
  setline(493);
// Begin line 492
  setline(492);
// compilenode returning *var_l
  Object num1602 = alloc_Float64(1.0);
// compilenode returning num1602
  params[0] = num1602;
  Object sum1604 = callmethod(*var_l, "+", 1, params);
// compilenode returning sum1604
  *var_l = sum1604;
  if (sum1604 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 495
  setline(495);
// Begin line 493
  setline(493);
  if (strlit1606 == NULL) {
    strlit1606 = alloc_String("");
  }
// compilenode returning strlit1606
  var_os = alloc_var();
  *var_os = strlit1606;
  if (strlit1606 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 510
  setline(510);
// Begin line 512
  setline(512);
// Begin line 643
  setline(643);
// Begin line 495
  setline(495);
// compilenode returning *var_o
  Object call1608 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1608
// compilenode returning call1608
// Begin line 510
  setline(510);
// Begin line 643
  setline(643);
  Object obj1610 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1610, self, 0);
  addmethod2(obj1610, "outer", &reader_genjs_outer_1611);
  adddatum2(obj1610, self, 0);
  block_savedest(obj1610);
  Object **closure1612 = createclosure(2);
  addtoclosure(closure1612, var_os);
  Object *selfpp1668 = alloc_var();
  *selfpp1668 = self;
  addtoclosure(closure1612, selfpp1668);
  struct UserObject *uo1612 = (struct UserObject*)obj1610;
  uo1612->data[1] = (Object)closure1612;
  addmethod2(obj1610, "apply", &meth_genjs_apply1612);
  set_type(obj1610, 0);
// compilenode returning obj1610
  setclassname(obj1610, "Block<genjs:1609>");
// compilenode returning obj1610
  params[0] = call1608;
  Object iter1607 = callmethod(call1608, "iter", 1, params);
  while(1) {
    Object cond1607 = callmethod(iter1607, "havemore", 0, NULL);
    if (!istrue(cond1607)) break;
    params[0] = callmethod(iter1607, "next", 0, NULL);
    callmethod(obj1610, "apply", 1, params);
  }
// compilenode returning call1608
// Begin line 512
  setline(512);
  if (strlit1669 == NULL) {
    strlit1669 = alloc_String("\\");
  }
// compilenode returning strlit1669
  if (strlit1670 == NULL) {
    strlit1670 = alloc_String("\\\\");
  }
// compilenode returning strlit1670
// Begin line 513
  setline(513);
// Begin line 643
  setline(643);
// Begin line 512
  setline(512);
// compilenode returning *var_o
  Object call1671 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1671
// compilenode returning call1671
  params[0] = strlit1669;
  params[1] = strlit1670;
  Object call1672 = callmethod(call1671, "replace(1)with",
    2, params);
// compilenode returning call1672
  var_sval = alloc_var();
  *var_sval = call1672;
  if (call1672 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 513
  setline(513);
  if (strlit1673 == NULL) {
    strlit1673 = alloc_String("""\x22""");
  }
// compilenode returning strlit1673
  if (strlit1674 == NULL) {
    strlit1674 = alloc_String("\\""\x22""");
  }
// compilenode returning strlit1674
// compilenode returning *var_sval
  params[0] = strlit1673;
  params[1] = strlit1674;
  Object call1675 = callmethod(*var_sval, "replace(1)with",
    2, params);
// compilenode returning call1675
  *var_sval = call1675;
  if (call1675 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 514
  setline(514);
  if (strlit1677 == NULL) {
    strlit1677 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1677
  if (strlit1678 == NULL) {
    strlit1678 = alloc_String("\\n");
  }
// compilenode returning strlit1678
// compilenode returning *var_sval
  params[0] = strlit1677;
  params[1] = strlit1678;
  Object call1679 = callmethod(*var_sval, "replace(1)with",
    2, params);
// compilenode returning call1679
  *var_sval = call1679;
  if (call1679 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 516
  setline(516);
// Begin line 515
  setline(515);
  if (strlit1681 == NULL) {
    strlit1681 = alloc_String("  var string");
  }
// compilenode returning strlit1681
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1683 = callmethod(strlit1681, "++", 1, params);
// compilenode returning opresult1683
  if (strlit1684 == NULL) {
    strlit1684 = alloc_String(" = new GraceString(""\x22""");
  }
// compilenode returning strlit1684
  params[0] = strlit1684;
  Object opresult1686 = callmethod(opresult1683, "++", 1, params);
// compilenode returning opresult1686
// Begin line 516
  setline(516);
// compilenode returning *var_os
  params[0] = *var_os;
  Object opresult1688 = callmethod(opresult1686, "++", 1, params);
// compilenode returning opresult1688
  if (strlit1689 == NULL) {
    strlit1689 = alloc_String("""\x22"");");
  }
// compilenode returning strlit1689
  params[0] = strlit1689;
  Object opresult1691 = callmethod(opresult1688, "++", 1, params);
// compilenode returning opresult1691
// Begin line 517
  setline(517);
// compilenode returning self
  params[0] = opresult1691;
  Object call1692 = callmethod(self, "out",
    1, params);
// compilenode returning call1692
// Begin line 518
  setline(518);
// Begin line 643
  setline(643);
// Begin line 518
  setline(518);
// Begin line 517
  setline(517);
  if (strlit1693 == NULL) {
    strlit1693 = alloc_String("string");
  }
// compilenode returning strlit1693
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1695 = callmethod(strlit1693, "++", 1, params);
// compilenode returning opresult1695
// compilenode returning *var_o
  params[0] = opresult1695;
  Object call1696 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1696
// compilenode returning nothing
// Begin line 519
  setline(519);
// Begin line 518
  setline(518);
// compilenode returning *var_auto_count
  Object num1697 = alloc_Float64(1.0);
// compilenode returning num1697
  params[0] = num1697;
  Object sum1699 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1699
  *var_auto_count = sum1699;
  if (sum1699 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1594 = nothing;
  } else {
  }
// compilenode returning if1594
// Begin line 521
  setline(521);
// Begin line 523
  setline(523);
// Begin line 643
  setline(643);
// Begin line 520
  setline(520);
// compilenode returning *var_o
  Object call1702 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1702
// compilenode returning call1702
  if (strlit1703 == NULL) {
    strlit1703 = alloc_String("index");
  }
// compilenode returning strlit1703
  params[0] = strlit1703;
  Object opresult1705 = callmethod(call1702, "==", 1, params);
// compilenode returning opresult1705
  Object if1701;
  if (istrue(opresult1705)) {
// Begin line 521
  setline(521);
// compilenode returning *var_o
// Begin line 522
  setline(522);
// compilenode returning self
  params[0] = *var_o;
  Object call1706 = callmethod(self, "compileindex",
    1, params);
// compilenode returning call1706
    if1701 = call1706;
  } else {
  }
// compilenode returning if1701
// Begin line 524
  setline(524);
// Begin line 526
  setline(526);
// Begin line 643
  setline(643);
// Begin line 523
  setline(523);
// compilenode returning *var_o
  Object call1708 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1708
// compilenode returning call1708
  if (strlit1709 == NULL) {
    strlit1709 = alloc_String("octets");
  }
// compilenode returning strlit1709
  params[0] = strlit1709;
  Object opresult1711 = callmethod(call1708, "==", 1, params);
// compilenode returning opresult1711
  Object if1707;
  if (istrue(opresult1711)) {
// Begin line 524
  setline(524);
// compilenode returning *var_o
// Begin line 525
  setline(525);
// compilenode returning self
  params[0] = *var_o;
  Object call1712 = callmethod(self, "compileoctets",
    1, params);
// compilenode returning call1712
    if1707 = call1712;
  } else {
  }
// compilenode returning if1707
// Begin line 527
  setline(527);
// Begin line 529
  setline(529);
// Begin line 643
  setline(643);
// Begin line 526
  setline(526);
// compilenode returning *var_o
  Object call1714 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1714
// compilenode returning call1714
  if (strlit1715 == NULL) {
    strlit1715 = alloc_String("import");
  }
// compilenode returning strlit1715
  params[0] = strlit1715;
  Object opresult1717 = callmethod(call1714, "==", 1, params);
// compilenode returning opresult1717
  Object if1713;
  if (istrue(opresult1717)) {
// Begin line 527
  setline(527);
// compilenode returning *var_o
// Begin line 528
  setline(528);
// compilenode returning self
  params[0] = *var_o;
  Object call1718 = callmethod(self, "compileimport",
    1, params);
// compilenode returning call1718
    if1713 = call1718;
  } else {
  }
// compilenode returning if1713
// Begin line 530
  setline(530);
// Begin line 532
  setline(532);
// Begin line 643
  setline(643);
// Begin line 529
  setline(529);
// compilenode returning *var_o
  Object call1720 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1720
// compilenode returning call1720
  if (strlit1721 == NULL) {
    strlit1721 = alloc_String("return");
  }
// compilenode returning strlit1721
  params[0] = strlit1721;
  Object opresult1723 = callmethod(call1720, "==", 1, params);
// compilenode returning opresult1723
  Object if1719;
  if (istrue(opresult1723)) {
// Begin line 530
  setline(530);
// compilenode returning *var_o
// Begin line 531
  setline(531);
// compilenode returning self
  params[0] = *var_o;
  Object call1724 = callmethod(self, "compilereturn",
    1, params);
// compilenode returning call1724
    if1719 = call1724;
  } else {
  }
// compilenode returning if1719
// Begin line 533
  setline(533);
// Begin line 535
  setline(535);
// Begin line 643
  setline(643);
// Begin line 532
  setline(532);
// compilenode returning *var_o
  Object call1726 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1726
// compilenode returning call1726
  if (strlit1727 == NULL) {
    strlit1727 = alloc_String("generic");
  }
// compilenode returning strlit1727
  params[0] = strlit1727;
  Object opresult1729 = callmethod(call1726, "==", 1, params);
// compilenode returning opresult1729
  Object if1725;
  if (istrue(opresult1729)) {
// Begin line 533
  setline(533);
// Begin line 643
  setline(643);
// Begin line 533
  setline(533);
// Begin line 643
  setline(643);
// Begin line 533
  setline(533);
// compilenode returning *var_o
  Object call1730 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1730
// compilenode returning call1730
// Begin line 534
  setline(534);
// compilenode returning self
  params[0] = call1730;
  Object call1731 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1731
// Begin line 533
  setline(533);
// compilenode returning *var_o
  params[0] = call1731;
  Object call1732 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1732
// compilenode returning nothing
    if1725 = nothing;
  } else {
  }
// compilenode returning if1725
// Begin line 545
  setline(545);
// Begin line 547
  setline(547);
// Begin line 643
  setline(643);
// Begin line 535
  setline(535);
// compilenode returning *var_o
  Object call1734 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1734
// compilenode returning call1734
  if (strlit1735 == NULL) {
    strlit1735 = alloc_String("identifier");
  }
// compilenode returning strlit1735
  params[0] = strlit1735;
  Object opresult1737 = callmethod(call1734, "==", 1, params);
// compilenode returning opresult1737
// Begin line 547
  setline(547);
// Begin line 643
  setline(643);
// Begin line 536
  setline(536);
// compilenode returning *var_o
  Object call1738 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1738
// compilenode returning call1738
  if (strlit1739 == NULL) {
    strlit1739 = alloc_String("true");
  }
// compilenode returning strlit1739
  params[0] = strlit1739;
  Object opresult1741 = callmethod(call1738, "==", 1, params);
// compilenode returning opresult1741
// Begin line 547
  setline(547);
// Begin line 643
  setline(643);
// Begin line 536
  setline(536);
// compilenode returning *var_o
  Object call1742 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1742
// compilenode returning call1742
  if (strlit1743 == NULL) {
    strlit1743 = alloc_String("false");
  }
// compilenode returning strlit1743
  params[0] = strlit1743;
  Object opresult1745 = callmethod(call1742, "==", 1, params);
// compilenode returning opresult1745
  params[0] = opresult1745;
  Object opresult1747 = callmethod(opresult1741, "|", 1, params);
// compilenode returning opresult1747
  params[0] = opresult1747;
  Object opresult1749 = callmethod(opresult1737, "&", 1, params);
// compilenode returning opresult1749
  Object if1733;
  if (istrue(opresult1749)) {
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 538
  setline(538);
// Begin line 537
  setline(537);
  Object num1750 = alloc_Float64(0.0);
// compilenode returning num1750
  var_val = alloc_var();
  *var_val = num1750;
  if (num1750 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 540
  setline(540);
// Begin line 541
  setline(541);
// Begin line 643
  setline(643);
// Begin line 538
  setline(538);
// compilenode returning *var_o
  Object call1752 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1752
// compilenode returning call1752
  if (strlit1753 == NULL) {
    strlit1753 = alloc_String("true");
  }
// compilenode returning strlit1753
  params[0] = strlit1753;
  Object opresult1755 = callmethod(call1752, "==", 1, params);
// compilenode returning opresult1755
  Object if1751;
  if (istrue(opresult1755)) {
// Begin line 540
  setline(540);
// Begin line 539
  setline(539);
  Object num1756 = alloc_Float64(1.0);
// compilenode returning num1756
  *var_val = num1756;
  if (num1756 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1751 = nothing;
  } else {
  }
// compilenode returning if1751
// Begin line 541
  setline(541);
  if (strlit1758 == NULL) {
    strlit1758 = alloc_String("  var bool");
  }
// compilenode returning strlit1758
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1760 = callmethod(strlit1758, "++", 1, params);
// compilenode returning opresult1760
  if (strlit1761 == NULL) {
    strlit1761 = alloc_String(" = new GraceBoolean(");
  }
// compilenode returning strlit1761
  params[0] = strlit1761;
  Object opresult1763 = callmethod(opresult1760, "++", 1, params);
// compilenode returning opresult1763
// Begin line 643
  setline(643);
// Begin line 541
  setline(541);
// compilenode returning *var_o
  Object call1764 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1764
// compilenode returning call1764
  params[0] = call1764;
  Object opresult1766 = callmethod(opresult1763, "++", 1, params);
// compilenode returning opresult1766
  if (strlit1767 == NULL) {
    strlit1767 = alloc_String(")");
  }
// compilenode returning strlit1767
  params[0] = strlit1767;
  Object opresult1769 = callmethod(opresult1766, "++", 1, params);
// compilenode returning opresult1769
// Begin line 542
  setline(542);
// compilenode returning self
  params[0] = opresult1769;
  Object call1770 = callmethod(self, "out",
    1, params);
// compilenode returning call1770
// Begin line 543
  setline(543);
// Begin line 643
  setline(643);
// Begin line 543
  setline(543);
// Begin line 542
  setline(542);
  if (strlit1771 == NULL) {
    strlit1771 = alloc_String("bool");
  }
// compilenode returning strlit1771
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1773 = callmethod(strlit1771, "++", 1, params);
// compilenode returning opresult1773
// compilenode returning *var_o
  params[0] = opresult1773;
  Object call1774 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1774
// compilenode returning nothing
// Begin line 544
  setline(544);
// Begin line 543
  setline(543);
// compilenode returning *var_auto_count
  Object num1775 = alloc_Float64(1.0);
// compilenode returning num1775
  params[0] = num1775;
  Object sum1777 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1777
  *var_auto_count = sum1777;
  if (sum1777 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1733 = nothing;
  } else {
// Begin line 545
  setline(545);
// Begin line 547
  setline(547);
// Begin line 643
  setline(643);
// Begin line 544
  setline(544);
// compilenode returning *var_o
  Object call1780 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1780
// compilenode returning call1780
  if (strlit1781 == NULL) {
    strlit1781 = alloc_String("identifier");
  }
// compilenode returning strlit1781
  params[0] = strlit1781;
  Object opresult1783 = callmethod(call1780, "==", 1, params);
// compilenode returning opresult1783
  Object if1779;
  if (istrue(opresult1783)) {
// Begin line 545
  setline(545);
// compilenode returning *var_o
// Begin line 546
  setline(546);
// compilenode returning self
  params[0] = *var_o;
  Object call1784 = callmethod(self, "compileidentifier",
    1, params);
// compilenode returning call1784
    if1779 = call1784;
  } else {
  }
// compilenode returning if1779
    if1733 = if1779;
  }
// compilenode returning if1733
// Begin line 548
  setline(548);
// Begin line 550
  setline(550);
// Begin line 643
  setline(643);
// Begin line 547
  setline(547);
// compilenode returning *var_o
  Object call1786 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1786
// compilenode returning call1786
  if (strlit1787 == NULL) {
    strlit1787 = alloc_String("defdec");
  }
// compilenode returning strlit1787
  params[0] = strlit1787;
  Object opresult1789 = callmethod(call1786, "==", 1, params);
// compilenode returning opresult1789
  Object if1785;
  if (istrue(opresult1789)) {
// Begin line 548
  setline(548);
// compilenode returning *var_o
// Begin line 549
  setline(549);
// compilenode returning self
  params[0] = *var_o;
  Object call1790 = callmethod(self, "compiledefdec",
    1, params);
// compilenode returning call1790
    if1785 = call1790;
  } else {
  }
// compilenode returning if1785
// Begin line 551
  setline(551);
// Begin line 553
  setline(553);
// Begin line 643
  setline(643);
// Begin line 550
  setline(550);
// compilenode returning *var_o
  Object call1792 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1792
// compilenode returning call1792
  if (strlit1793 == NULL) {
    strlit1793 = alloc_String("vardec");
  }
// compilenode returning strlit1793
  params[0] = strlit1793;
  Object opresult1795 = callmethod(call1792, "==", 1, params);
// compilenode returning opresult1795
  Object if1791;
  if (istrue(opresult1795)) {
// Begin line 551
  setline(551);
// compilenode returning *var_o
// Begin line 552
  setline(552);
// compilenode returning self
  params[0] = *var_o;
  Object call1796 = callmethod(self, "compilevardec",
    1, params);
// compilenode returning call1796
    if1791 = call1796;
  } else {
  }
// compilenode returning if1791
// Begin line 554
  setline(554);
// Begin line 556
  setline(556);
// Begin line 643
  setline(643);
// Begin line 553
  setline(553);
// compilenode returning *var_o
  Object call1798 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1798
// compilenode returning call1798
  if (strlit1799 == NULL) {
    strlit1799 = alloc_String("block");
  }
// compilenode returning strlit1799
  params[0] = strlit1799;
  Object opresult1801 = callmethod(call1798, "==", 1, params);
// compilenode returning opresult1801
  Object if1797;
  if (istrue(opresult1801)) {
// Begin line 554
  setline(554);
// compilenode returning *var_o
// Begin line 555
  setline(555);
// compilenode returning self
  params[0] = *var_o;
  Object call1802 = callmethod(self, "compileblock",
    1, params);
// compilenode returning call1802
    if1797 = call1802;
  } else {
  }
// compilenode returning if1797
// Begin line 557
  setline(557);
// Begin line 559
  setline(559);
// Begin line 643
  setline(643);
// Begin line 556
  setline(556);
// compilenode returning *var_o
  Object call1804 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1804
// compilenode returning call1804
  if (strlit1805 == NULL) {
    strlit1805 = alloc_String("method");
  }
// compilenode returning strlit1805
  params[0] = strlit1805;
  Object opresult1807 = callmethod(call1804, "==", 1, params);
// compilenode returning opresult1807
  Object if1803;
  if (istrue(opresult1807)) {
// Begin line 557
  setline(557);
// compilenode returning *var_o
  if (strlit1808 == NULL) {
    strlit1808 = alloc_String("this");
  }
// compilenode returning strlit1808
// Begin line 558
  setline(558);
// compilenode returning self
  params[0] = *var_o;
  params[1] = strlit1808;
  Object call1809 = callmethod(self, "compilemethod",
    2, params);
// compilenode returning call1809
    if1803 = call1809;
  } else {
  }
// compilenode returning if1803
// Begin line 560
  setline(560);
// Begin line 562
  setline(562);
// Begin line 643
  setline(643);
// Begin line 559
  setline(559);
// compilenode returning *var_o
  Object call1811 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1811
// compilenode returning call1811
  if (strlit1812 == NULL) {
    strlit1812 = alloc_String("array");
  }
// compilenode returning strlit1812
  params[0] = strlit1812;
  Object opresult1814 = callmethod(call1811, "==", 1, params);
// compilenode returning opresult1814
  Object if1810;
  if (istrue(opresult1814)) {
// Begin line 560
  setline(560);
// compilenode returning *var_o
// Begin line 561
  setline(561);
// compilenode returning self
  params[0] = *var_o;
  Object call1815 = callmethod(self, "compilearray",
    1, params);
// compilenode returning call1815
    if1810 = call1815;
  } else {
  }
// compilenode returning if1810
// Begin line 563
  setline(563);
// Begin line 565
  setline(565);
// Begin line 643
  setline(643);
// Begin line 562
  setline(562);
// compilenode returning *var_o
  Object call1817 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1817
// compilenode returning call1817
  if (strlit1818 == NULL) {
    strlit1818 = alloc_String("bind");
  }
// compilenode returning strlit1818
  params[0] = strlit1818;
  Object opresult1820 = callmethod(call1817, "==", 1, params);
// compilenode returning opresult1820
  Object if1816;
  if (istrue(opresult1820)) {
// Begin line 563
  setline(563);
// compilenode returning *var_o
// Begin line 564
  setline(564);
// compilenode returning self
  params[0] = *var_o;
  Object call1821 = callmethod(self, "compilebind",
    1, params);
// compilenode returning call1821
    if1816 = call1821;
  } else {
  }
// compilenode returning if1816
// Begin line 566
  setline(566);
// Begin line 568
  setline(568);
// Begin line 643
  setline(643);
// Begin line 565
  setline(565);
// compilenode returning *var_o
  Object call1823 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1823
// compilenode returning call1823
  if (strlit1824 == NULL) {
    strlit1824 = alloc_String("while");
  }
// compilenode returning strlit1824
  params[0] = strlit1824;
  Object opresult1826 = callmethod(call1823, "==", 1, params);
// compilenode returning opresult1826
  Object if1822;
  if (istrue(opresult1826)) {
// Begin line 566
  setline(566);
// compilenode returning *var_o
// Begin line 567
  setline(567);
// compilenode returning self
  params[0] = *var_o;
  Object call1827 = callmethod(self, "compilewhile",
    1, params);
// compilenode returning call1827
    if1822 = call1827;
  } else {
  }
// compilenode returning if1822
// Begin line 569
  setline(569);
// Begin line 571
  setline(571);
// Begin line 643
  setline(643);
// Begin line 568
  setline(568);
// compilenode returning *var_o
  Object call1829 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1829
// compilenode returning call1829
  if (strlit1830 == NULL) {
    strlit1830 = alloc_String("if");
  }
// compilenode returning strlit1830
  params[0] = strlit1830;
  Object opresult1832 = callmethod(call1829, "==", 1, params);
// compilenode returning opresult1832
  Object if1828;
  if (istrue(opresult1832)) {
// Begin line 569
  setline(569);
// compilenode returning *var_o
// Begin line 570
  setline(570);
// compilenode returning self
  params[0] = *var_o;
  Object call1833 = callmethod(self, "compileif",
    1, params);
// compilenode returning call1833
    if1828 = call1833;
  } else {
  }
// compilenode returning if1828
// Begin line 572
  setline(572);
// Begin line 574
  setline(574);
// Begin line 643
  setline(643);
// Begin line 571
  setline(571);
// compilenode returning *var_o
  Object call1835 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1835
// compilenode returning call1835
  if (strlit1836 == NULL) {
    strlit1836 = alloc_String("class");
  }
// compilenode returning strlit1836
  params[0] = strlit1836;
  Object opresult1838 = callmethod(call1835, "==", 1, params);
// compilenode returning opresult1838
  Object if1834;
  if (istrue(opresult1838)) {
// Begin line 572
  setline(572);
// compilenode returning *var_o
// Begin line 573
  setline(573);
// compilenode returning self
  params[0] = *var_o;
  Object call1839 = callmethod(self, "compileclass",
    1, params);
// compilenode returning call1839
    if1834 = call1839;
  } else {
  }
// compilenode returning if1834
// Begin line 575
  setline(575);
// Begin line 577
  setline(577);
// Begin line 643
  setline(643);
// Begin line 574
  setline(574);
// compilenode returning *var_o
  Object call1841 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1841
// compilenode returning call1841
  if (strlit1842 == NULL) {
    strlit1842 = alloc_String("object");
  }
// compilenode returning strlit1842
  params[0] = strlit1842;
  Object opresult1844 = callmethod(call1841, "==", 1, params);
// compilenode returning opresult1844
  Object if1840;
  if (istrue(opresult1844)) {
// Begin line 575
  setline(575);
// compilenode returning *var_o
// Begin line 576
  setline(576);
// compilenode returning self
  params[0] = *var_o;
  Object call1845 = callmethod(self, "compileobject",
    1, params);
// compilenode returning call1845
    if1840 = call1845;
  } else {
  }
// compilenode returning if1840
// Begin line 578
  setline(578);
// Begin line 580
  setline(580);
// Begin line 643
  setline(643);
// Begin line 577
  setline(577);
// compilenode returning *var_o
  Object call1847 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1847
// compilenode returning call1847
  if (strlit1848 == NULL) {
    strlit1848 = alloc_String("member");
  }
// compilenode returning strlit1848
  params[0] = strlit1848;
  Object opresult1850 = callmethod(call1847, "==", 1, params);
// compilenode returning opresult1850
  Object if1846;
  if (istrue(opresult1850)) {
// Begin line 578
  setline(578);
// compilenode returning *var_o
// Begin line 579
  setline(579);
// compilenode returning self
  params[0] = *var_o;
  Object call1851 = callmethod(self, "compilemember",
    1, params);
// compilenode returning call1851
    if1846 = call1851;
  } else {
  }
// compilenode returning if1846
// Begin line 581
  setline(581);
// Begin line 583
  setline(583);
// Begin line 643
  setline(643);
// Begin line 580
  setline(580);
// compilenode returning *var_o
  Object call1853 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1853
// compilenode returning call1853
  if (strlit1854 == NULL) {
    strlit1854 = alloc_String("for");
  }
// compilenode returning strlit1854
  params[0] = strlit1854;
  Object opresult1856 = callmethod(call1853, "==", 1, params);
// compilenode returning opresult1856
  Object if1852;
  if (istrue(opresult1856)) {
// Begin line 581
  setline(581);
// compilenode returning *var_o
// Begin line 582
  setline(582);
// compilenode returning self
  params[0] = *var_o;
  Object call1857 = callmethod(self, "compilefor",
    1, params);
// compilenode returning call1857
    if1852 = call1857;
  } else {
  }
// compilenode returning if1852
// Begin line 606
  setline(606);
// Begin line 609
  setline(609);
// Begin line 643
  setline(643);
// Begin line 583
  setline(583);
// compilenode returning *var_o
  Object call1859 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1859
// compilenode returning call1859
  if (strlit1860 == NULL) {
    strlit1860 = alloc_String("call");
  }
// compilenode returning strlit1860
  params[0] = strlit1860;
  Object opresult1862 = callmethod(call1859, "==", 1, params);
// compilenode returning opresult1862
  Object if1858;
  if (istrue(opresult1862)) {
// Begin line 606
  setline(606);
// Begin line 608
  setline(608);
// Begin line 643
  setline(643);
// Begin line 608
  setline(608);
// Begin line 643
  setline(643);
// Begin line 584
  setline(584);
// compilenode returning *var_o
  Object call1864 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1864
// compilenode returning call1864
  Object call1865 = callmethod(call1864, "value",
    0, params);
// compilenode returning call1865
// compilenode returning call1865
  if (strlit1866 == NULL) {
    strlit1866 = alloc_String("print");
  }
// compilenode returning strlit1866
  params[0] = strlit1866;
  Object opresult1868 = callmethod(call1865, "==", 1, params);
// compilenode returning opresult1868
  Object if1863;
  if (istrue(opresult1868)) {
  Object *var_args = alloc_var();
  *var_args = undefined;
// Begin line 586
  setline(586);
  Object array1869 = alloc_List();
// compilenode returning array1869
  var_args = alloc_var();
  *var_args = array1869;
  if (array1869 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 588
  setline(588);
// Begin line 590
  setline(590);
// Begin line 643
  setline(643);
// Begin line 586
  setline(586);
// compilenode returning *var_o
  Object call1871 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call1871
// compilenode returning call1871
// Begin line 588
  setline(588);
// Begin line 643
  setline(643);
  Object obj1873 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1873, self, 0);
  addmethod2(obj1873, "outer", &reader_genjs_outer_1874);
  adddatum2(obj1873, self, 0);
  block_savedest(obj1873);
  Object **closure1875 = createclosure(2);
  addtoclosure(closure1875, var_args);
  Object *selfpp1878 = alloc_var();
  *selfpp1878 = self;
  addtoclosure(closure1875, selfpp1878);
  struct UserObject *uo1875 = (struct UserObject*)obj1873;
  uo1875->data[1] = (Object)closure1875;
  addmethod2(obj1873, "apply", &meth_genjs_apply1875);
  set_type(obj1873, 0);
// compilenode returning obj1873
  setclassname(obj1873, "Block<genjs:1872>");
// compilenode returning obj1873
  params[0] = call1871;
  Object iter1870 = callmethod(call1871, "iter", 1, params);
  while(1) {
    Object cond1870 = callmethod(iter1870, "havemore", 0, NULL);
    if (!istrue(cond1870)) break;
    params[0] = callmethod(iter1870, "next", 0, NULL);
    callmethod(obj1873, "apply", 1, params);
  }
// compilenode returning call1871
// Begin line 590
  setline(590);
  if (strlit1879 == NULL) {
    strlit1879 = alloc_String("  var call");
  }
// compilenode returning strlit1879
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1881 = callmethod(strlit1879, "++", 1, params);
// compilenode returning opresult1881
  if (strlit1882 == NULL) {
    strlit1882 = alloc_String(" = Grace_print(");
  }
// compilenode returning strlit1882
  params[0] = strlit1882;
  Object opresult1884 = callmethod(opresult1881, "++", 1, params);
// compilenode returning opresult1884
// Begin line 643
  setline(643);
// Begin line 590
  setline(590);
// compilenode returning *var_args
  Object call1885 = callmethod(*var_args, "first",
    0, params);
// compilenode returning call1885
// compilenode returning call1885
  params[0] = call1885;
  Object opresult1887 = callmethod(opresult1884, "++", 1, params);
// compilenode returning opresult1887
  if (strlit1888 == NULL) {
    strlit1888 = alloc_String(");");
  }
// compilenode returning strlit1888
  params[0] = strlit1888;
  Object opresult1890 = callmethod(opresult1887, "++", 1, params);
// compilenode returning opresult1890
// Begin line 591
  setline(591);
// compilenode returning self
  params[0] = opresult1890;
  Object call1891 = callmethod(self, "out",
    1, params);
// compilenode returning call1891
// Begin line 592
  setline(592);
// Begin line 643
  setline(643);
// Begin line 592
  setline(592);
// Begin line 591
  setline(591);
  if (strlit1892 == NULL) {
    strlit1892 = alloc_String("call");
  }
// compilenode returning strlit1892
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1894 = callmethod(strlit1892, "++", 1, params);
// compilenode returning opresult1894
// compilenode returning *var_o
  params[0] = opresult1894;
  Object call1895 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1895
// compilenode returning nothing
// Begin line 593
  setline(593);
// Begin line 592
  setline(592);
// compilenode returning *var_auto_count
  Object num1896 = alloc_Float64(1.0);
// compilenode returning num1896
  params[0] = num1896;
  Object sum1898 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1898
  *var_auto_count = sum1898;
  if (sum1898 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1863 = nothing;
  } else {
// Begin line 606
  setline(606);
// Begin line 599
  setline(599);
// Begin line 643
  setline(643);
// Begin line 599
  setline(599);
// Begin line 643
  setline(643);
// Begin line 593
  setline(593);
// compilenode returning *var_o
  Object call1901 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1901
// compilenode returning call1901
  Object call1902 = callmethod(call1901, "kind",
    0, params);
// compilenode returning call1902
// compilenode returning call1902
  if (strlit1903 == NULL) {
    strlit1903 = alloc_String("identifier");
  }
// compilenode returning strlit1903
  params[0] = strlit1903;
  Object opresult1905 = callmethod(call1902, "==", 1, params);
// compilenode returning opresult1905
// Begin line 599
  setline(599);
// Begin line 643
  setline(643);
// Begin line 599
  setline(599);
// Begin line 643
  setline(643);
// Begin line 594
  setline(594);
// compilenode returning *var_o
  Object call1906 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1906
// compilenode returning call1906
  Object call1907 = callmethod(call1906, "value",
    0, params);
// compilenode returning call1907
// compilenode returning call1907
  if (strlit1908 == NULL) {
    strlit1908 = alloc_String("length");
  }
// compilenode returning strlit1908
  params[0] = strlit1908;
  Object opresult1910 = callmethod(call1907, "==", 1, params);
// compilenode returning opresult1910
  params[0] = opresult1910;
  Object opresult1912 = callmethod(opresult1905, "&", 1, params);
// compilenode returning opresult1912
  Object if1900;
  if (istrue(opresult1912)) {
// Begin line 595
  setline(595);
// Begin line 643
  setline(643);
// Begin line 595
  setline(595);
// Begin line 643
  setline(643);
// Begin line 595
  setline(595);
// compilenode returning *var_o
  Object call1913 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call1913
// compilenode returning call1913
  Object call1914 = callmethod(call1913, "first",
    0, params);
// compilenode returning call1914
// compilenode returning call1914
// Begin line 596
  setline(596);
// compilenode returning self
  params[0] = call1914;
  Object call1915 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1915
  *var_tmp = call1915;
  if (call1915 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit1917 == NULL) {
    strlit1917 = alloc_String("  var call");
  }
// compilenode returning strlit1917
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1919 = callmethod(strlit1917, "++", 1, params);
// compilenode returning opresult1919
  if (strlit1920 == NULL) {
    strlit1920 = alloc_String(" = Grace_length(");
  }
// compilenode returning strlit1920
  params[0] = strlit1920;
  Object opresult1922 = callmethod(opresult1919, "++", 1, params);
// compilenode returning opresult1922
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult1924 = callmethod(opresult1922, "++", 1, params);
// compilenode returning opresult1924
  if (strlit1925 == NULL) {
    strlit1925 = alloc_String(");");
  }
// compilenode returning strlit1925
  params[0] = strlit1925;
  Object opresult1927 = callmethod(opresult1924, "++", 1, params);
// compilenode returning opresult1927
// Begin line 597
  setline(597);
// compilenode returning self
  params[0] = opresult1927;
  Object call1928 = callmethod(self, "out",
    1, params);
// compilenode returning call1928
// Begin line 598
  setline(598);
// Begin line 643
  setline(643);
// Begin line 598
  setline(598);
// Begin line 597
  setline(597);
  if (strlit1929 == NULL) {
    strlit1929 = alloc_String("call");
  }
// compilenode returning strlit1929
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1931 = callmethod(strlit1929, "++", 1, params);
// compilenode returning opresult1931
// compilenode returning *var_o
  params[0] = opresult1931;
  Object call1932 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1932
// compilenode returning nothing
// Begin line 599
  setline(599);
// Begin line 598
  setline(598);
// compilenode returning *var_auto_count
  Object num1933 = alloc_Float64(1.0);
// compilenode returning num1933
  params[0] = num1933;
  Object sum1935 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1935
  *var_auto_count = sum1935;
  if (sum1935 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1900 = nothing;
  } else {
// Begin line 606
  setline(606);
// Begin line 605
  setline(605);
// Begin line 643
  setline(643);
// Begin line 605
  setline(605);
// Begin line 643
  setline(643);
// Begin line 599
  setline(599);
// compilenode returning *var_o
  Object call1938 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1938
// compilenode returning call1938
  Object call1939 = callmethod(call1938, "kind",
    0, params);
// compilenode returning call1939
// compilenode returning call1939
  if (strlit1940 == NULL) {
    strlit1940 = alloc_String("identifier");
  }
// compilenode returning strlit1940
  params[0] = strlit1940;
  Object opresult1942 = callmethod(call1939, "==", 1, params);
// compilenode returning opresult1942
// Begin line 605
  setline(605);
// Begin line 643
  setline(643);
// Begin line 605
  setline(605);
// Begin line 643
  setline(643);
// Begin line 600
  setline(600);
// compilenode returning *var_o
  Object call1943 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1943
// compilenode returning call1943
  Object call1944 = callmethod(call1943, "value",
    0, params);
// compilenode returning call1944
// compilenode returning call1944
  if (strlit1945 == NULL) {
    strlit1945 = alloc_String("escapestring");
  }
// compilenode returning strlit1945
  params[0] = strlit1945;
  Object opresult1947 = callmethod(call1944, "==", 1, params);
// compilenode returning opresult1947
  params[0] = opresult1947;
  Object opresult1949 = callmethod(opresult1942, "&", 1, params);
// compilenode returning opresult1949
  Object if1937;
  if (istrue(opresult1949)) {
// Begin line 602
  setline(602);
// Begin line 643
  setline(643);
// Begin line 602
  setline(602);
// Begin line 643
  setline(643);
// Begin line 601
  setline(601);
// compilenode returning *var_o
  Object call1950 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call1950
// compilenode returning call1950
  Object call1951 = callmethod(call1950, "first",
    0, params);
// compilenode returning call1951
// compilenode returning call1951
  *var_tmp = call1951;
  if (call1951 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 602
  setline(602);
  if (strlit1953 == NULL) {
    strlit1953 = alloc_String("_escape");
  }
// compilenode returning strlit1953
// compilenode returning *var_tmp
// compilenode returning module_ast
  params[0] = strlit1953;
  params[1] = *var_tmp;
  Object call1954 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1954
  *var_tmp = call1954;
  if (call1954 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 603
  setline(603);
// compilenode returning *var_tmp
  Object array1956 = alloc_List();
// compilenode returning array1956
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = array1956;
  Object call1957 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1957
  *var_tmp = call1957;
  if (call1957 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 604
  setline(604);
// Begin line 643
  setline(643);
// Begin line 604
  setline(604);
// compilenode returning *var_tmp
// Begin line 605
  setline(605);
// compilenode returning self
  params[0] = *var_tmp;
  Object call1959 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1959
// Begin line 604
  setline(604);
// compilenode returning *var_o
  params[0] = call1959;
  Object call1960 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1960
// compilenode returning nothing
    if1937 = nothing;
  } else {
// Begin line 606
  setline(606);
// compilenode returning *var_o
// Begin line 607
  setline(607);
// compilenode returning self
  params[0] = *var_o;
  Object call1961 = callmethod(self, "compilecall",
    1, params);
// compilenode returning call1961
    if1937 = call1961;
  }
// compilenode returning if1937
    if1900 = if1937;
  }
// compilenode returning if1900
    if1863 = if1900;
  }
// compilenode returning if1863
    if1858 = if1863;
  } else {
  }
// compilenode returning if1858
// Begin line 610
  setline(610);
// Begin line 612
  setline(612);
// Begin line 643
  setline(643);
// Begin line 609
  setline(609);
// compilenode returning *var_o
  Object call1963 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call1963
// compilenode returning call1963
  if (strlit1964 == NULL) {
    strlit1964 = alloc_String("op");
  }
// compilenode returning strlit1964
  params[0] = strlit1964;
  Object opresult1966 = callmethod(call1963, "==", 1, params);
// compilenode returning opresult1966
  Object if1962;
  if (istrue(opresult1966)) {
// Begin line 610
  setline(610);
// compilenode returning *var_o
// Begin line 611
  setline(611);
// compilenode returning self
  params[0] = *var_o;
  Object call1967 = callmethod(self, "compileop",
    1, params);
// compilenode returning call1967
    if1962 = call1967;
  } else {
  }
// compilenode returning if1962
// Begin line 612
  setline(612);
// Begin line 643
  setline(643);
// Begin line 612
  setline(612);
// compilenode returning *var_o
  Object call1968 = callmethod(*var_o, "register",
    0, params);
// compilenode returning call1968
// compilenode returning call1968
  return call1968;
}
Object meth_genjs_apply1992(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 627
  setline(627);
// compilenode returning *var_o
// Begin line 628
  setline(628);
// compilenode returning self
  params[0] = *var_o;
  Object call1993 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1993
  return call1993;
}
Object meth_genjs_apply2004(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_lineOut = closure[0];
  Object self = *closure[1];
// Begin line 640
  setline(640);
// Begin line 633
  setline(633);
  if (strlit2006 == NULL) {
    strlit2006 = alloc_String("  lineNumber =");
  }
// compilenode returning strlit2006
  Object num2007 = alloc_Float64(0.0);
// compilenode returning num2007
  Object num2008 = alloc_Float64(14.0);
// compilenode returning num2008
// compilenode returning *var_o
  params[0] = num2007;
  params[1] = num2008;
  Object call2009 = callmethod(*var_o, "substringFrom(1)to",
    2, params);
// compilenode returning call2009
  params[0] = call2009;
  Object opresult2011 = callmethod(strlit2006, "==", 1, params);
// compilenode returning opresult2011
  Object if2005;
  if (istrue(opresult2011)) {
// Begin line 635
  setline(635);
// Begin line 634
  setline(634);
// compilenode returning *var_o
  *var_lineOut = *var_o;
  if (*var_o == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2005 = nothing;
  } else {
// Begin line 639
  setline(639);
// Begin line 640
  setline(640);
// Begin line 636
  setline(636);
  Object bool2014 = alloc_Boolean(0);
// compilenode returning bool2014
// compilenode returning *var_lineOut
  params[0] = *var_lineOut;
  Object opresult2016 = callmethod(bool2014, "/=", 1, params);
// compilenode returning opresult2016
  Object if2013;
  if (istrue(opresult2016)) {
// Begin line 637
  setline(637);
// compilenode returning *var_lineOut
// Begin line 638
  setline(638);
// compilenode returning self
  params[0] = *var_lineOut;
  Object call2017 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2017
// Begin line 639
  setline(639);
// Begin line 638
  setline(638);
  Object bool2018 = alloc_Boolean(0);
// compilenode returning bool2018
  *var_lineOut = bool2018;
  if (bool2018 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2013 = nothing;
  } else {
  }
// compilenode returning if2013
// Begin line 640
  setline(640);
// compilenode returning *var_o
// Begin line 641
  setline(641);
// compilenode returning self
  params[0] = *var_o;
  Object call2020 = callmethod(self, "outprint",
    1, params);
// compilenode returning call2020
    if2005 = call2020;
  }
// compilenode returning if2005
  return if2005;
}
Object meth_genjs_compile1969(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[30];
  Object *var_vl = alloc_var();
  *var_vl = args[0];
  Object *var_of = alloc_var();
  *var_of = args[1];
  Object *var_mn = alloc_var();
  *var_mn = args[2];
  Object *var_rm = alloc_var();
  *var_rm = args[3];
  Object *var_bt = alloc_var();
  *var_bt = args[4];
  Object *var_glpath = alloc_var();
  *var_glpath = args[5];
  Object params[1];
  Object *var_values = closure[0];
  Object *var_outfile = closure[1];
  Object *var_modname = closure[2];
  Object *var_runmode = closure[3];
  Object *var_buildtype = closure[4];
  Object *var_gracelibPath = closure[5];
  Object *var_output = closure[6];
  Object *var_argv = alloc_var();
  *var_argv = undefined;
  Object *var_cmd = alloc_var();
  *var_cmd = undefined;
  Object *var_lineOut = alloc_var();
  *var_lineOut = undefined;
// Begin line 616
  setline(616);
// Begin line 643
  setline(643);
// Begin line 615
  setline(615);
// compilenode returning module_sys
  Object call1970 = callmethod(module_sys, "argv",
    0, params);
// compilenode returning call1970
// compilenode returning call1970
  var_argv = alloc_var();
  *var_argv = call1970;
  if (call1970 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 617
  setline(617);
  var_cmd = alloc_var();
  *var_cmd = undefined;
// compilenode returning nothing
// Begin line 618
  setline(618);
// Begin line 617
  setline(617);
// compilenode returning *var_vl
  *var_values = *var_vl;
  if (*var_vl == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 619
  setline(619);
// Begin line 618
  setline(618);
// compilenode returning *var_of
  *var_outfile = *var_of;
  if (*var_of == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 620
  setline(620);
// Begin line 619
  setline(619);
// compilenode returning *var_mn
  *var_modname = *var_mn;
  if (*var_mn == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 621
  setline(621);
// Begin line 620
  setline(620);
// compilenode returning *var_rm
  *var_runmode = *var_rm;
  if (*var_rm == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 622
  setline(622);
// Begin line 621
  setline(621);
// compilenode returning *var_bt
  *var_buildtype = *var_bt;
  if (*var_bt == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 623
  setline(623);
// Begin line 622
  setline(622);
// compilenode returning *var_glpath
  *var_gracelibPath = *var_glpath;
  if (*var_glpath == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 623
  setline(623);
  if (strlit1977 == NULL) {
    strlit1977 = alloc_String("generating ECMAScript code.");
  }
// compilenode returning strlit1977
// compilenode returning module_util
  params[0] = strlit1977;
  Object call1978 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call1978
// Begin line 624
  setline(624);
  Object num1979 = alloc_Float64(1.0);
// compilenode returning num1979
// compilenode returning module_util
  params[0] = num1979;
  Object call1980 = callmethod(module_util, "setline",
    1, params);
// compilenode returning call1980
// Begin line 625
  setline(625);
  if (strlit1981 == NULL) {
    strlit1981 = alloc_String("function gracecode_");
  }
// compilenode returning strlit1981
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult1983 = callmethod(strlit1981, "++", 1, params);
// compilenode returning opresult1983
  if (strlit1984 == NULL) {
    strlit1984 = alloc_String("() {");
  }
// compilenode returning strlit1984
  params[0] = strlit1984;
  Object opresult1986 = callmethod(opresult1983, "++", 1, params);
// compilenode returning opresult1986
// Begin line 626
  setline(626);
// compilenode returning self
  params[0] = opresult1986;
  Object call1987 = callmethod(self, "out",
    1, params);
// compilenode returning call1987
// Begin line 627
  setline(627);
// Begin line 626
  setline(626);
// compilenode returning *var_values
// Begin line 627
  setline(627);
// Begin line 643
  setline(643);
  Object obj1990 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1990, self, 0);
  addmethod2(obj1990, "outer", &reader_genjs_outer_1991);
  adddatum2(obj1990, self, 0);
  block_savedest(obj1990);
  Object **closure1992 = createclosure(1);
  Object *selfpp1994 = alloc_var();
  *selfpp1994 = self;
  addtoclosure(closure1992, selfpp1994);
  struct UserObject *uo1992 = (struct UserObject*)obj1990;
  uo1992->data[1] = (Object)closure1992;
  addmethod2(obj1990, "apply", &meth_genjs_apply1992);
  set_type(obj1990, 0);
// compilenode returning obj1990
  setclassname(obj1990, "Block<genjs:1989>");
// compilenode returning obj1990
  params[0] = *var_values;
  Object iter1988 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond1988 = callmethod(iter1988, "havemore", 0, NULL);
    if (!istrue(cond1988)) break;
    params[0] = callmethod(iter1988, "next", 0, NULL);
    callmethod(obj1990, "apply", 1, params);
  }
// compilenode returning *var_values
// Begin line 629
  setline(629);
  if (strlit1995 == NULL) {
    strlit1995 = alloc_String("  return this;");
  }
// compilenode returning strlit1995
// Begin line 630
  setline(630);
// compilenode returning self
  params[0] = strlit1995;
  Object call1996 = callmethod(self, "out",
    1, params);
// compilenode returning call1996
  if (strlit1997 == NULL) {
    strlit1997 = alloc_String("}");
  }
// compilenode returning strlit1997
// Begin line 631
  setline(631);
// compilenode returning self
  params[0] = strlit1997;
  Object call1998 = callmethod(self, "out",
    1, params);
// compilenode returning call1998
// Begin line 632
  setline(632);
// Begin line 631
  setline(631);
  Object bool1999 = alloc_Boolean(0);
// compilenode returning bool1999
  var_lineOut = alloc_var();
  *var_lineOut = bool1999;
  if (bool1999 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 640
  setline(640);
// Begin line 632
  setline(632);
// compilenode returning *var_output
// Begin line 640
  setline(640);
// Begin line 643
  setline(643);
  Object obj2002 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2002, self, 0);
  addmethod2(obj2002, "outer", &reader_genjs_outer_2003);
  adddatum2(obj2002, self, 0);
  block_savedest(obj2002);
  Object **closure2004 = createclosure(2);
  addtoclosure(closure2004, var_lineOut);
  Object *selfpp2021 = alloc_var();
  *selfpp2021 = self;
  addtoclosure(closure2004, selfpp2021);
  struct UserObject *uo2004 = (struct UserObject*)obj2002;
  uo2004->data[1] = (Object)closure2004;
  addmethod2(obj2002, "apply", &meth_genjs_apply2004);
  set_type(obj2002, 0);
// compilenode returning obj2002
  setclassname(obj2002, "Block<genjs:2001>");
// compilenode returning obj2002
  params[0] = *var_output;
  Object iter2000 = callmethod(*var_output, "iter", 1, params);
  while(1) {
    Object cond2000 = callmethod(iter2000, "havemore", 0, NULL);
    if (!istrue(cond2000)) break;
    params[0] = callmethod(iter2000, "next", 0, NULL);
    callmethod(obj2002, "apply", 1, params);
  }
// compilenode returning *var_output
// Begin line 643
  setline(643);
  if (strlit2022 == NULL) {
    strlit2022 = alloc_String("done.");
  }
// compilenode returning strlit2022
// Begin line 644
  setline(644);
// compilenode returning self
  params[0] = strlit2022;
  Object call2023 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call2023
  return call2023;
}
Object module_genjs_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<genjs>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_verbosity = alloc_var();
  *var_verbosity = undefined;
  Object *var_pad1 = alloc_var();
  *var_pad1 = undefined;
  Object *var_auto_count = alloc_var();
  *var_auto_count = undefined;
  Object *var_constants = alloc_var();
  *var_constants = undefined;
  Object *var_output = alloc_var();
  *var_output = undefined;
  Object *var_usedvars = alloc_var();
  *var_usedvars = undefined;
  Object *var_declaredvars = alloc_var();
  *var_declaredvars = undefined;
  Object *var_bblock = alloc_var();
  *var_bblock = undefined;
  Object *var_linenum = alloc_var();
  *var_linenum = undefined;
  Object *var_modules = alloc_var();
  *var_modules = undefined;
  Object *var_staticmodules = alloc_var();
  *var_staticmodules = undefined;
  Object *var_values = alloc_var();
  *var_values = undefined;
  Object *var_outfile = alloc_var();
  *var_outfile = undefined;
  Object *var_modname = alloc_var();
  *var_modname = undefined;
  Object *var_runmode = alloc_var();
  *var_runmode = undefined;
  Object *var_buildtype = alloc_var();
  *var_buildtype = undefined;
  Object *var_gracelibPath = alloc_var();
  *var_gracelibPath = undefined;
  Object *var_inBlock = alloc_var();
  *var_inBlock = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of sys
  if (module_sys == NULL)
    module_sys = module_sys_init();
  Object *var_sys = alloc_var();
  *var_sys = module_sys;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of ast
  if (module_ast == NULL)
    module_ast = module_ast_init();
  Object *var_ast = alloc_var();
  *var_ast = module_ast;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 7
  setline(7);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 8
  setline(8);
// Begin line 7
  setline(7);
  Object num4 = alloc_Float64(30.0);
// compilenode returning num4
  var_verbosity = alloc_var();
  *var_verbosity = num4;
  if (num4 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 9
  setline(9);
// Begin line 8
  setline(8);
  Object num5 = alloc_Float64(1.0);
// compilenode returning num5
  var_pad1 = alloc_var();
  *var_pad1 = num5;
  if (num5 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 10
  setline(10);
// Begin line 9
  setline(9);
  Object num6 = alloc_Float64(0.0);
// compilenode returning num6
  var_auto_count = alloc_var();
  *var_auto_count = num6;
  if (num6 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 11
  setline(11);
  Object array7 = alloc_List();
// compilenode returning array7
  var_constants = alloc_var();
  *var_constants = array7;
  if (array7 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 12
  setline(12);
  Object array8 = alloc_List();
// compilenode returning array8
  var_output = alloc_var();
  *var_output = array8;
  if (array8 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 13
  setline(13);
  Object array9 = alloc_List();
// compilenode returning array9
  var_usedvars = alloc_var();
  *var_usedvars = array9;
  if (array9 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 14
  setline(14);
  Object array10 = alloc_List();
// compilenode returning array10
  var_declaredvars = alloc_var();
  *var_declaredvars = array10;
  if (array10 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 15
  setline(15);
// Begin line 14
  setline(14);
  if (strlit11 == NULL) {
    strlit11 = alloc_String("entry");
  }
// compilenode returning strlit11
  var_bblock = alloc_var();
  *var_bblock = strlit11;
  if (strlit11 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 16
  setline(16);
// Begin line 15
  setline(15);
  Object num12 = alloc_Float64(0.0);
// compilenode returning num12
  var_linenum = alloc_var();
  *var_linenum = num12;
  if (num12 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 17
  setline(17);
  Object array13 = alloc_List();
// compilenode returning array13
  var_modules = alloc_var();
  *var_modules = array13;
  if (array13 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 18
  setline(18);
  Object array14 = alloc_List();
// compilenode returning array14
  var_staticmodules = alloc_var();
  *var_staticmodules = array14;
  if (array14 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 19
  setline(19);
  Object array15 = alloc_List();
// compilenode returning array15
  var_values = alloc_var();
  *var_values = array15;
  if (array15 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 20
  setline(20);
  var_outfile = alloc_var();
  *var_outfile = undefined;
// compilenode returning nothing
// Begin line 21
  setline(21);
// Begin line 20
  setline(20);
  if (strlit16 == NULL) {
    strlit16 = alloc_String("main");
  }
// compilenode returning strlit16
  var_modname = alloc_var();
  *var_modname = strlit16;
  if (strlit16 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 22
  setline(22);
// Begin line 21
  setline(21);
  if (strlit17 == NULL) {
    strlit17 = alloc_String("build");
  }
// compilenode returning strlit17
  var_runmode = alloc_var();
  *var_runmode = strlit17;
  if (strlit17 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 23
  setline(23);
// Begin line 22
  setline(22);
  if (strlit18 == NULL) {
    strlit18 = alloc_String("bc");
  }
// compilenode returning strlit18
  var_buildtype = alloc_var();
  *var_buildtype = strlit18;
  if (strlit18 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 24
  setline(24);
// Begin line 23
  setline(23);
  if (strlit19 == NULL) {
    strlit19 = alloc_String("gracelib.o");
  }
// compilenode returning strlit19
  var_gracelibPath = alloc_var();
  *var_gracelibPath = strlit19;
  if (strlit19 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 26
  setline(26);
// Begin line 24
  setline(24);
  Object bool20 = alloc_Boolean(0);
// compilenode returning bool20
  var_inBlock = alloc_var();
  *var_inBlock = bool20;
  if (bool20 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 27
  setline(27);
  block_savedest(self);
  Object **closure21 = createclosure(1);
  addtoclosure(closure21, var_output);
  struct UserObject *uo21 = (struct UserObject*)self;
  uo21->data[1] = (Object)closure21;
  addmethod2(self, "out", &meth_genjs_out21);
// compilenode returning 
// Begin line 30
  setline(30);
  addmethod2(self, "outprint", &meth_genjs_outprint23);
// compilenode returning 
// Begin line 33
  setline(33);
  addmethod2(self, "log_verbose", &meth_genjs_log_verbose25);
// compilenode returning 
// Begin line 46
  setline(46);
  addmethod2(self, "escapeident", &meth_genjs_escapeident27);
// compilenode returning 
// Begin line 49
  setline(49);
  addmethod2(self, "varf", &meth_genjs_varf77);
// compilenode returning 
// Begin line 53
  setline(53);
  block_savedest(self);
  Object **closure82 = createclosure(1);
  addtoclosure(closure82, var_bblock);
  struct UserObject *uo82 = (struct UserObject*)self;
  uo82->data[6] = (Object)closure82;
  addmethod2(self, "beginblock", &meth_genjs_beginblock82);
// compilenode returning 
// Begin line 70
  setline(70);
  block_savedest(self);
  Object **closure91 = createclosure(1);
  addtoclosure(closure91, var_auto_count);
  struct UserObject *uo91 = (struct UserObject*)self;
  uo91->data[7] = (Object)closure91;
  addmethod2(self, "compilearray", &meth_genjs_compilearray91);
// compilenode returning 
// Begin line 77
  setline(77);
  addmethod2(self, "compilemember", &meth_genjs_compilemember130);
// compilenode returning 
// Begin line 89
  setline(89);
  block_savedest(self);
  Object **closure135 = createclosure(2);
  addtoclosure(closure135, var_auto_count);
  addtoclosure(closure135, var_modname);
  struct UserObject *uo135 = (struct UserObject*)self;
  uo135->data[9] = (Object)closure135;
  addmethod2(self, "compileobjouter", &meth_genjs_compileobjouter135);
// compilenode returning 
// Begin line 105
  setline(105);
  block_savedest(self);
  Object **closure209 = createclosure(2);
  addtoclosure(closure209, var_auto_count);
  addtoclosure(closure209, var_modname);
  struct UserObject *uo209 = (struct UserObject*)self;
  uo209->data[10] = (Object)closure209;
  addmethod2(self, "compileobjdefdec", &meth_genjs_compileobjdefdec209);
// compilenode returning 
// Begin line 127
  setline(127);
  block_savedest(self);
  Object **closure290 = createclosure(2);
  addtoclosure(closure290, var_auto_count);
  addtoclosure(closure290, var_modname);
  struct UserObject *uo290 = (struct UserObject*)self;
  uo290->data[11] = (Object)closure290;
  addmethod2(self, "compileobjvardec", &meth_genjs_compileobjvardec290);
// compilenode returning 
// Begin line 137
  setline(137);
  addmethod2(self, "compileclass", &meth_genjs_compileclass435);
// compilenode returning 
// Begin line 167
  setline(167);
  block_savedest(self);
  Object **closure454 = createclosure(2);
  addtoclosure(closure454, var_inBlock);
  addtoclosure(closure454, var_auto_count);
  struct UserObject *uo454 = (struct UserObject*)self;
  uo454->data[13] = (Object)closure454;
  addmethod2(self, "compileobject", &meth_genjs_compileobject454);
// compilenode returning 
// Begin line 196
  setline(196);
  block_savedest(self);
  Object **closure516 = createclosure(2);
  addtoclosure(closure516, var_inBlock);
  addtoclosure(closure516, var_auto_count);
  struct UserObject *uo516 = (struct UserObject*)self;
  uo516->data[14] = (Object)closure516;
  addmethod2(self, "compileblock", &meth_genjs_compileblock516);
// compilenode returning 
// Begin line 212
  setline(212);
  block_savedest(self);
  Object **closure598 = createclosure(1);
  addtoclosure(closure598, var_auto_count);
  struct UserObject *uo598 = (struct UserObject*)self;
  uo598->data[15] = (Object)closure598;
  addmethod2(self, "compilefor", &meth_genjs_compilefor598);
// compilenode returning 
// Begin line 255
  setline(255);
  block_savedest(self);
  Object **closure679 = createclosure(3);
  addtoclosure(closure679, var_usedvars);
  addtoclosure(closure679, var_declaredvars);
  addtoclosure(closure679, var_auto_count);
  struct UserObject *uo679 = (struct UserObject*)self;
  uo679->data[16] = (Object)closure679;
  addmethod2(self, "compilemethod", &meth_genjs_compilemethod679);
// compilenode returning 
// Begin line 271
  setline(271);
  block_savedest(self);
  Object **closure797 = createclosure(1);
  addtoclosure(closure797, var_auto_count);
  struct UserObject *uo797 = (struct UserObject*)self;
  uo797->data[17] = (Object)closure797;
  addmethod2(self, "compilewhile", &meth_genjs_compilewhile797);
// compilenode returning 
// Begin line 291
  setline(291);
  block_savedest(self);
  Object **closure851 = createclosure(1);
  addtoclosure(closure851, var_auto_count);
  struct UserObject *uo851 = (struct UserObject*)self;
  uo851->data[18] = (Object)closure851;
  addmethod2(self, "compileif", &meth_genjs_compileif851);
// compilenode returning 
// Begin line 303
  setline(303);
  block_savedest(self);
  Object **closure923 = createclosure(3);
  addtoclosure(closure923, var_modules);
  addtoclosure(closure923, var_auto_count);
  addtoclosure(closure923, var_usedvars);
  struct UserObject *uo923 = (struct UserObject*)self;
  uo923->data[19] = (Object)closure923;
  addmethod2(self, "compileidentifier", &meth_genjs_compileidentifier923);
// compilenode returning 
// Begin line 329
  setline(329);
  block_savedest(self);
  Object **closure949 = createclosure(1);
  addtoclosure(closure949, var_usedvars);
  struct UserObject *uo949 = (struct UserObject*)self;
  uo949->data[20] = (Object)closure949;
  addmethod2(self, "compilebind", &meth_genjs_compilebind949);
// compilenode returning 
// Begin line 347
  setline(347);
  block_savedest(self);
  Object **closure1013 = createclosure(1);
  addtoclosure(closure1013, var_declaredvars);
  struct UserObject *uo1013 = (struct UserObject*)self;
  uo1013->data[21] = (Object)closure1013;
  addmethod2(self, "compiledefdec", &meth_genjs_compiledefdec1013);
// compilenode returning 
// Begin line 360
  setline(360);
  block_savedest(self);
  Object **closure1050 = createclosure(1);
  addtoclosure(closure1050, var_declaredvars);
  struct UserObject *uo1050 = (struct UserObject*)self;
  uo1050->data[22] = (Object)closure1050;
  addmethod2(self, "compilevardec", &meth_genjs_compilevardec1050);
// compilenode returning 
// Begin line 368
  setline(368);
  block_savedest(self);
  Object **closure1083 = createclosure(1);
  addtoclosure(closure1083, var_auto_count);
  struct UserObject *uo1083 = (struct UserObject*)self;
  uo1083->data[23] = (Object)closure1083;
  addmethod2(self, "compileindex", &meth_genjs_compileindex1083);
// compilenode returning 
// Begin line 391
  setline(391);
  block_savedest(self);
  Object **closure1121 = createclosure(1);
  addtoclosure(closure1121, var_auto_count);
  struct UserObject *uo1121 = (struct UserObject*)self;
  uo1121->data[24] = (Object)closure1121;
  addmethod2(self, "compileop", &meth_genjs_compileop1121);
// compilenode returning 
// Begin line 420
  setline(420);
  block_savedest(self);
  Object **closure1191 = createclosure(1);
  addtoclosure(closure1191, var_auto_count);
  struct UserObject *uo1191 = (struct UserObject*)self;
  uo1191->data[25] = (Object)closure1191;
  addmethod2(self, "compilecall", &meth_genjs_compilecall1191);
// compilenode returning 
// Begin line 464
  setline(464);
  block_savedest(self);
  Object **closure1287 = createclosure(2);
  addtoclosure(closure1287, var_auto_count);
  addtoclosure(closure1287, var_constants);
  struct UserObject *uo1287 = (struct UserObject*)self;
  uo1287->data[26] = (Object)closure1287;
  addmethod2(self, "compileoctets", &meth_genjs_compileoctets1287);
// compilenode returning 
// Begin line 471
  setline(471);
  addmethod2(self, "compileimport", &meth_genjs_compileimport1522);
// compilenode returning 
// Begin line 480
  setline(480);
  block_savedest(self);
  Object **closure1552 = createclosure(1);
  addtoclosure(closure1552, var_inBlock);
  struct UserObject *uo1552 = (struct UserObject*)self;
  uo1552->data[28] = (Object)closure1552;
  addmethod2(self, "compilereturn", &meth_genjs_compilereturn1552);
// compilenode returning 
// Begin line 612
  setline(612);
  block_savedest(self);
  Object **closure1569 = createclosure(3);
  addtoclosure(closure1569, var_linenum);
  addtoclosure(closure1569, var_auto_count);
  addtoclosure(closure1569, var_tmp);
  struct UserObject *uo1569 = (struct UserObject*)self;
  uo1569->data[29] = (Object)closure1569;
  addmethod2(self, "compilenode", &meth_genjs_compilenode1569);
// compilenode returning 
// Begin line 643
  setline(643);
  block_savedest(self);
  Object **closure1969 = createclosure(7);
  addtoclosure(closure1969, var_values);
  addtoclosure(closure1969, var_outfile);
  addtoclosure(closure1969, var_modname);
  addtoclosure(closure1969, var_runmode);
  addtoclosure(closure1969, var_buildtype);
  addtoclosure(closure1969, var_gracelibPath);
  addtoclosure(closure1969, var_output);
  struct UserObject *uo1969 = (struct UserObject*)self;
  uo1969->data[30] = (Object)closure1969;
  addmethod2(self, "compile", &meth_genjs_compile1969);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_genjs_init();
  gracelib_stats();
  return 0;
}
