#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_genllvm29_outer_56(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_639(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_705(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_732(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_754(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1060(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1102(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1119(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1125(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1139(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1240(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1313(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1332(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1348(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1398(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1407(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1418(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1509(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1743(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1785(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1895(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1937(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_1961(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_2003(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_2734(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_2790(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_2875(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_2947(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_3456(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_3908(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_3917(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4066(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4350(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4420(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4438(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4453(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4603(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4626(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4631(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4727(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4734(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4783(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_genllvm29_outer_4839(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_sys_init();
Object module_sys;
Object module_ast_init();
Object module_ast;
Object module_util_init();
Object module_util;
Object module_buildinfo_init();
Object module_buildinfo;
Object module_subtype_init();
Object module_subtype;
static Object strlit13;
static Object strlit18;
static Object strlit19;
static Object strlit20;
static Object strlit21;
static Object strlit32;
static Object strlit36;
static Object strlit45;
static Object strlit48;
static Object strlit60;
static Object strlit63;
static Object strlit67;
static Object strlit70;
static Object strlit73;
static Object strlit78;
static Object strlit92;
static Object strlit98;
static Object strlit101;
static Object strlit104;
static Object strlit109;
static Object strlit114;
static Object strlit118;
static Object strlit122;
static Object strlit125;
static Object strlit129;
static Object strlit132;
static Object strlit137;
static Object strlit142;
static Object strlit145;
static Object strlit149;
static Object strlit151;
static Object strlit153;
static Object strlit155;
static Object strlit157;
static Object strlit159;
static Object strlit161;
static Object strlit164;
static Object strlit169;
static Object strlit174;
static Object strlit177;
static Object strlit180;
static Object strlit183;
static Object strlit186;
static Object strlit191;
static Object strlit196;
static Object strlit201;
static Object strlit206;
static Object strlit223;
static Object strlit226;
static Object strlit229;
static Object strlit234;
static Object strlit239;
static Object strlit243;
static Object strlit247;
static Object strlit250;
static Object strlit255;
static Object strlit260;
static Object strlit264;
static Object strlit267;
static Object strlit272;
static Object strlit277;
static Object strlit280;
static Object strlit284;
static Object strlit286;
static Object strlit288;
static Object strlit291;
static Object strlit295;
static Object strlit297;
static Object strlit299;
static Object strlit301;
static Object strlit304;
static Object strlit309;
static Object strlit314;
static Object strlit317;
static Object strlit320;
static Object strlit323;
static Object strlit326;
static Object strlit331;
static Object strlit336;
static Object strlit341;
static Object strlit346;
static Object strlit363;
static Object strlit366;
static Object strlit369;
static Object strlit374;
static Object strlit379;
static Object strlit383;
static Object strlit387;
static Object strlit390;
static Object strlit395;
static Object strlit400;
static Object strlit404;
static Object strlit407;
static Object strlit412;
static Object strlit417;
static Object strlit420;
static Object strlit424;
static Object strlit426;
static Object strlit428;
static Object strlit431;
static Object strlit435;
static Object strlit437;
static Object strlit439;
static Object strlit441;
static Object strlit444;
static Object strlit449;
static Object strlit454;
static Object strlit457;
static Object strlit460;
static Object strlit463;
static Object strlit466;
static Object strlit471;
static Object strlit476;
static Object strlit481;
static Object strlit485;
static Object strlit495;
static Object strlit498;
static Object strlit501;
static Object strlit506;
static Object strlit511;
static Object strlit516;
static Object strlit519;
static Object strlit524;
static Object strlit529;
static Object strlit532;
static Object strlit536;
static Object strlit538;
static Object strlit540;
static Object strlit542;
static Object strlit544;
static Object strlit547;
static Object strlit551;
static Object strlit553;
static Object strlit555;
static Object strlit557;
static Object strlit559;
static Object strlit562;
static Object strlit567;
static Object strlit572;
static Object strlit575;
static Object strlit578;
static Object strlit581;
static Object strlit584;
static Object strlit589;
static Object strlit594;
static Object strlit599;
static Object strlit609;
static Object strlit629;
static Object strlit643;
static Object strlit673;
static Object strlit676;
static Object strlit679;
static Object strlit684;
static Object strlit687;
static Object strlit694;
static Object strlit697;
static Object strlit709;
static Object strlit715;
static Object strlit721;
static Object strlit734;
static Object strlit737;
static Object strlit740;
static Object strlit745;
static Object strlit767;
static Object strlit780;
static Object strlit783;
static Object strlit788;
static Object strlit791;
static Object strlit794;
static Object strlit797;
static Object strlit804;
static Object strlit809;
static Object strlit815;
static Object strlit818;
static Object strlit821;
static Object strlit828;
static Object strlit833;
static Object strlit838;
static Object strlit853;
static Object strlit856;
static Object strlit860;
static Object strlit863;
static Object strlit868;
static Object strlit871;
static Object strlit875;
static Object strlit879;
static Object strlit883;
static Object strlit886;
static Object strlit891;
static Object strlit894;
static Object strlit898;
static Object strlit901;
static Object strlit904;
static Object strlit909;
static Object strlit913;
static Object strlit916;
static Object strlit921;
static Object strlit925;
static Object strlit928;
static Object strlit933;
static Object strlit939;
static Object strlit943;
static Object strlit944;
static Object strlit945;
static Object strlit948;
static Object strlit953;
static Object strlit956;
static Object strlit960;
static Object strlit963;
static Object strlit967;
static Object strlit970;
static Object strlit973;
static Object strlit978;
static Object strlit982;
static Object strlit1006;
static Object strlit1016;
static Object strlit1019;
static Object strlit1022;
static Object strlit1025;
static Object strlit1031;
static Object strlit1034;
static Object strlit1038;
static Object strlit1041;
static Object strlit1046;
static Object strlit1051;
static Object strlit1053;
static Object strlit1055;
static Object strlit1064;
static Object strlit1068;
static Object strlit1074;
static Object strlit1083;
static Object strlit1086;
static Object strlit1090;
static Object strlit1093;
static Object strlit1107;
static Object strlit1111;
static Object strlit1153;
static Object strlit1155;
static Object strlit1158;
static Object strlit1164;
static Object strlit1167;
static Object strlit1178;
static Object strlit1181;
static Object strlit1184;
static Object strlit1188;
static Object strlit1190;
static Object strlit1192;
static Object strlit1195;
static Object strlit1198;
static Object strlit1202;
static Object strlit1204;
static Object strlit1206;
static Object strlit1208;
static Object strlit1211;
static Object strlit1215;
static Object strlit1217;
static Object strlit1219;
static Object strlit1221;
static Object strlit1224;
static Object strlit1227;
static Object strlit1231;
static Object strlit1246;
static Object strlit1249;
static Object strlit1253;
static Object strlit1256;
static Object strlit1261;
static Object strlit1265;
static Object strlit1268;
static Object strlit1273;
static Object strlit1277;
static Object strlit1280;
static Object strlit1285;
static Object strlit1290;
static Object strlit1293;
static Object strlit1296;
static Object strlit1319;
static Object strlit1334;
static Object strlit1337;
static Object strlit1351;
static Object strlit1354;
static Object strlit1357;
static Object strlit1363;
static Object strlit1367;
static Object strlit1369;
static Object strlit1372;
static Object strlit1378;
static Object strlit1381;
static Object strlit1386;
static Object strlit1402;
static Object strlit1421;
static Object strlit1433;
static Object strlit1436;
static Object strlit1439;
static Object strlit1444;
static Object strlit1449;
static Object strlit1458;
static Object strlit1461;
static Object strlit1466;
static Object strlit1471;
static Object strlit1474;
static Object strlit1477;
static Object strlit1482;
static Object strlit1486;
static Object strlit1489;
static Object strlit1493;
static Object strlit1496;
static Object strlit1502;
static Object strlit1512;
static Object strlit1515;
static Object strlit1518;
static Object strlit1521;
static Object strlit1525;
static Object strlit1529;
static Object strlit1532;
static Object strlit1535;
static Object strlit1540;
static Object strlit1548;
static Object strlit1551;
static Object strlit1554;
static Object strlit1559;
static Object strlit1564;
static Object strlit1567;
static Object strlit1570;
static Object strlit1573;
static Object strlit1578;
static Object strlit1582;
static Object strlit1585;
static Object strlit1590;
static Object strlit1594;
static Object strlit1597;
static Object strlit1602;
static Object strlit1607;
static Object strlit1611;
static Object strlit1614;
static Object strlit1619;
static Object strlit1623;
static Object strlit1626;
static Object strlit1631;
static Object strlit1635;
static Object strlit1638;
static Object strlit1643;
static Object strlit1647;
static Object strlit1650;
static Object strlit1655;
static Object strlit1660;
static Object strlit1663;
static Object strlit1666;
static Object strlit1671;
static Object strlit1682;
static Object strlit1686;
static Object strlit1692;
static Object strlit1695;
static Object strlit1698;
static Object strlit1703;
static Object strlit1707;
static Object strlit1710;
static Object strlit1715;
static Object strlit1719;
static Object strlit1722;
static Object strlit1727;
static Object strlit1733;
static Object strlit1737;
static Object strlit1738;
static Object strlit1747;
static Object strlit1751;
static Object strlit1757;
static Object strlit1766;
static Object strlit1769;
static Object strlit1773;
static Object strlit1776;
static Object strlit1791;
static Object strlit1795;
static Object strlit1805;
static Object strlit1809;
static Object strlit1815;
static Object strlit1818;
static Object strlit1821;
static Object strlit1826;
static Object strlit1830;
static Object strlit1833;
static Object strlit1838;
static Object strlit1848;
static Object strlit1851;
static Object strlit1856;
static Object strlit1862;
static Object strlit1865;
static Object strlit1869;
static Object strlit1872;
static Object strlit1877;
static Object strlit1883;
static Object strlit1887;
static Object strlit1888;
static Object strlit1889;
static Object strlit1890;
static Object strlit1899;
static Object strlit1903;
static Object strlit1909;
static Object strlit1918;
static Object strlit1921;
static Object strlit1925;
static Object strlit1928;
static Object strlit1943;
static Object strlit1953;
static Object strlit1965;
static Object strlit1969;
static Object strlit1975;
static Object strlit1984;
static Object strlit1987;
static Object strlit1991;
static Object strlit1994;
static Object strlit2008;
static Object strlit2013;
static Object strlit2023;
static Object strlit2026;
static Object strlit2031;
static Object strlit2036;
static Object strlit2041;
static Object strlit2046;
static Object strlit2050;
static Object strlit2053;
static Object strlit2058;
static Object strlit2063;
static Object strlit2068;
static Object strlit2073;
static Object strlit2077;
static Object strlit2084;
static Object strlit2087;
static Object strlit2090;
static Object strlit2093;
static Object strlit2096;
static Object strlit2100;
static Object strlit2103;
static Object strlit2108;
static Object strlit2112;
static Object strlit2115;
static Object strlit2123;
static Object strlit2128;
static Object strlit2135;
static Object strlit2140;
static Object strlit2143;
static Object strlit2148;
static Object strlit2152;
static Object strlit2157;
static Object strlit2167;
static Object strlit2168;
static Object strlit2169;
static Object strlit2172;
static Object strlit2182;
static Object strlit2185;
static Object strlit2190;
static Object strlit2194;
static Object strlit2197;
static Object strlit2202;
static Object strlit2206;
static Object strlit2209;
static Object strlit2214;
static Object strlit2217;
static Object strlit2220;
static Object strlit2226;
static Object strlit2229;
static Object strlit2233;
static Object strlit2234;
static Object strlit2237;
static Object strlit2240;
static Object strlit2246;
static Object strlit2249;
static Object strlit2253;
static Object strlit2256;
static Object strlit2267;
static Object strlit2270;
static Object strlit2273;
static Object strlit2286;
static Object strlit2289;
static Object strlit2300;
static Object strlit2306;
static Object strlit2323;
static Object strlit2325;
static Object strlit2328;
static Object strlit2333;
static Object strlit2337;
static Object strlit2340;
static Object strlit2345;
static Object strlit2349;
static Object strlit2352;
static Object strlit2357;
static Object strlit2360;
static Object strlit2363;
static Object strlit2369;
static Object strlit2372;
static Object strlit2376;
static Object strlit2377;
static Object strlit2380;
static Object strlit2383;
static Object strlit2389;
static Object strlit2392;
static Object strlit2396;
static Object strlit2399;
static Object strlit2407;
static Object strlit2421;
static Object strlit2423;
static Object strlit2426;
static Object strlit2431;
static Object strlit2436;
static Object strlit2439;
static Object strlit2444;
static Object strlit2448;
static Object strlit2451;
static Object strlit2456;
static Object strlit2459;
static Object strlit2462;
static Object strlit2468;
static Object strlit2471;
static Object strlit2475;
static Object strlit2476;
static Object strlit2479;
static Object strlit2482;
static Object strlit2488;
static Object strlit2491;
static Object strlit2495;
static Object strlit2498;
static Object strlit2506;
static Object strlit2513;
static Object strlit2516;
static Object strlit2520;
static Object strlit2523;
static Object strlit2528;
static Object strlit2531;
static Object strlit2535;
static Object strlit2554;
static Object strlit2558;
static Object strlit2564;
static Object strlit2570;
static Object strlit2576;
static Object strlit2581;
static Object strlit2582;
static Object strlit2585;
static Object strlit2588;
static Object strlit2590;
static Object strlit2594;
static Object strlit2597;
static Object strlit2599;
static Object strlit2603;
static Object strlit2606;
static Object strlit2608;
static Object strlit2612;
static Object strlit2615;
static Object strlit2617;
static Object strlit2619;
static Object strlit2622;
static Object strlit2626;
static Object strlit2631;
static Object strlit2636;
static Object strlit2641;
static Object strlit2645;
static Object strlit2662;
static Object strlit2666;
static Object strlit2669;
static Object strlit2674;
static Object strlit2679;
static Object strlit2682;
static Object strlit2685;
static Object strlit2689;
static Object strlit2692;
static Object strlit2695;
static Object strlit2700;
static Object strlit2705;
static Object strlit2711;
static Object strlit2716;
static Object strlit2726;
static Object strlit2728;
static Object strlit2752;
static Object strlit2766;
static Object strlit2770;
static Object strlit2773;
static Object strlit2778;
static Object strlit2783;
static Object strlit2792;
static Object strlit2795;
static Object strlit2800;
static Object strlit2809;
static Object strlit2812;
static Object strlit2815;
static Object strlit2820;
static Object strlit2825;
static Object strlit2831;
static Object strlit2837;
static Object strlit2842;
static Object strlit2851;
static Object strlit2855;
static Object strlit2858;
static Object strlit2863;
static Object strlit2868;
static Object strlit2877;
static Object strlit2880;
static Object strlit2885;
static Object strlit2894;
static Object strlit2897;
static Object strlit2900;
static Object strlit2905;
static Object strlit2910;
static Object strlit2916;
static Object strlit2922;
static Object strlit2927;
static Object strlit2936;
static Object strlit2956;
static Object strlit2968;
static Object strlit2971;
static Object strlit2977;
static Object strlit2980;
static Object strlit2985;
static Object strlit2989;
static Object strlit2992;
static Object strlit2997;
static Object strlit3002;
static Object strlit3006;
static Object strlit3009;
static Object strlit3013;
static Object strlit3016;
static Object strlit3022;
static Object strlit3025;
static Object strlit3029;
static Object strlit3032;
static Object strlit3036;
static Object strlit3039;
static Object strlit3044;
static Object strlit3050;
static Object strlit3054;
static Object strlit3057;
static Object strlit3060;
static Object strlit3063;
static Object strlit3068;
static Object strlit3073;
static Object strlit3077;
static Object strlit3080;
static Object strlit3083;
static Object strlit3089;
static Object strlit3092;
static Object strlit3096;
static Object strlit3099;
static Object strlit3103;
static Object strlit3106;
static Object strlit3111;
static Object strlit3116;
static Object strlit3119;
static Object strlit3124;
static Object strlit3129;
static Object strlit3133;
static Object strlit3137;
static Object strlit3140;
static Object strlit3145;
static Object strlit3150;
static Object strlit3154;
static Object strlit3157;
static Object strlit3162;
static Object strlit3171;
static Object strlit3180;
static Object strlit3183;
static Object strlit3186;
static Object strlit3189;
static Object strlit3195;
static Object strlit3198;
static Object strlit3203;
static Object strlit3207;
static Object strlit3210;
static Object strlit3215;
static Object strlit3220;
static Object strlit3224;
static Object strlit3227;
static Object strlit3231;
static Object strlit3234;
static Object strlit3240;
static Object strlit3243;
static Object strlit3247;
static Object strlit3250;
static Object strlit3256;
static Object strlit3259;
static Object strlit3264;
static Object strlit3268;
static Object strlit3271;
static Object strlit3274;
static Object strlit3280;
static Object strlit3285;
static Object strlit3288;
static Object strlit3294;
static Object strlit3299;
static Object strlit3302;
static Object strlit3305;
static Object strlit3310;
static Object strlit3315;
static Object strlit3319;
static Object strlit3322;
static Object strlit3327;
static Object strlit3331;
static Object strlit3334;
static Object strlit3339;
static Object strlit3343;
static Object strlit3346;
static Object strlit3350;
static Object strlit3353;
static Object strlit3357;
static Object strlit3360;
static Object strlit3365;
static Object strlit3370;
static Object strlit3373;
static Object strlit3378;
static Object strlit3383;
static Object strlit3387;
static Object strlit3390;
static Object strlit3394;
static Object strlit3397;
static Object strlit3402;
static Object strlit3406;
static Object strlit3409;
static Object strlit3415;
static Object strlit3418;
static Object strlit3427;
static Object strlit3433;
static Object strlit3436;
static Object strlit3440;
static Object strlit3444;
static Object strlit3448;
static Object strlit3459;
static Object strlit3467;
static Object strlit3471;
static Object strlit3474;
static Object strlit3479;
static Object strlit3483;
static Object strlit3498;
static Object strlit3502;
static Object strlit3505;
static Object strlit3511;
static Object strlit3515;
static Object strlit3518;
static Object strlit3531;
static Object strlit3534;
static Object strlit3540;
static Object strlit3543;
static Object strlit3548;
static Object strlit3552;
static Object strlit3555;
static Object strlit3560;
static Object strlit3565;
static Object strlit3569;
static Object strlit3572;
static Object strlit3576;
static Object strlit3579;
static Object strlit3585;
static Object strlit3588;
static Object strlit3592;
static Object strlit3595;
static Object strlit3599;
static Object strlit3602;
static Object strlit3607;
static Object strlit3613;
static Object strlit3617;
static Object strlit3620;
static Object strlit3623;
static Object strlit3626;
static Object strlit3631;
static Object strlit3635;
static Object strlit3638;
static Object strlit3641;
static Object strlit3647;
static Object strlit3650;
static Object strlit3654;
static Object strlit3657;
static Object strlit3661;
static Object strlit3664;
static Object strlit3669;
static Object strlit3674;
static Object strlit3677;
static Object strlit3682;
static Object strlit3687;
static Object strlit3691;
static Object strlit3695;
static Object strlit3698;
static Object strlit3703;
static Object strlit3709;
static Object strlit3713;
static Object strlit3716;
static Object strlit3721;
static Object strlit3731;
static Object strlit3737;
static Object strlit3743;
static Object strlit3749;
static Object strlit3755;
static Object strlit3763;
static Object strlit3767;
static Object strlit3771;
static Object strlit3781;
static Object strlit3786;
static Object strlit3789;
static Object strlit3792;
static Object strlit3797;
static Object strlit3801;
static Object strlit3811;
static Object strlit3817;
static Object strlit3823;
static Object strlit3829;
static Object strlit3835;
static Object strlit3838;
static Object strlit3846;
static Object strlit3852;
static Object strlit3858;
static Object strlit3864;
static Object strlit3870;
static Object strlit3876;
static Object strlit3882;
static Object strlit3888;
static Object strlit3894;
static Object strlit3900;
static Object strlit3919;
static Object strlit3922;
static Object strlit3927;
static Object strlit3936;
static Object strlit3939;
static Object strlit3945;
static Object strlit3949;
static Object strlit3960;
static Object strlit3965;
static Object strlit3976;
static Object strlit3981;
static Object strlit3987;
static Object strlit3990;
static Object strlit3993;
static Object strlit3998;
static Object strlit4002;
static Object strlit4013;
static Object strlit4018;
static Object strlit4026;
static Object strlit4037;
static Object strlit4041;
static Object strlit4058;
static Object strlit4061;
static Object strlit4070;
static Object strlit4077;
static Object strlit4080;
static Object strlit4091;
static Object strlit4096;
static Object strlit4099;
static Object strlit4105;
static Object strlit4113;
static Object strlit4117;
static Object strlit4120;
static Object strlit4124;
static Object strlit4131;
static Object strlit4135;
static Object strlit4148;
static Object strlit4154;
static Object strlit4162;
static Object strlit4165;
static Object strlit4172;
static Object strlit4175;
static Object strlit4181;
static Object strlit4189;
static Object strlit4192;
static Object strlit4202;
static Object strlit4205;
static Object strlit4210;
static Object strlit4212;
static Object strlit4214;
static Object strlit4216;
static Object strlit4218;
static Object strlit4220;
static Object strlit4222;
static Object strlit4224;
static Object strlit4226;
static Object strlit4228;
static Object strlit4230;
static Object strlit4232;
static Object strlit4234;
static Object strlit4236;
static Object strlit4238;
static Object strlit4239;
static Object strlit4245;
static Object strlit4249;
static Object strlit4251;
static Object strlit4253;
static Object strlit4255;
static Object strlit4257;
static Object strlit4259;
static Object strlit4261;
static Object strlit4263;
static Object strlit4266;
static Object strlit4270;
static Object strlit4272;
static Object strlit4274;
static Object strlit4277;
static Object strlit4280;
static Object strlit4283;
static Object strlit4286;
static Object strlit4293;
static Object strlit4298;
static Object strlit4304;
static Object strlit4305;
static Object strlit4312;
static Object strlit4317;
static Object strlit4320;
static Object strlit4325;
static Object strlit4329;
static Object strlit4331;
static Object strlit4333;
static Object strlit4335;
static Object strlit4337;
static Object strlit4339;
static Object strlit4341;
static Object strlit4343;
static Object strlit4354;
static Object strlit4358;
static Object strlit4367;
static Object strlit4370;
static Object strlit4374;
static Object strlit4377;
static Object strlit4383;
static Object strlit4389;
static Object strlit4402;
static Object strlit4405;
static Object strlit4409;
static Object strlit4412;
static Object strlit4425;
static Object strlit4440;
static Object strlit4443;
static Object strlit4459;
static Object strlit4461;
static Object strlit4463;
static Object strlit4465;
static Object strlit4467;
static Object strlit4470;
static Object strlit4473;
static Object strlit4476;
static Object strlit4477;
static Object strlit4484;
static Object strlit4489;
static Object strlit4496;
static Object strlit4497;
static Object strlit4504;
static Object strlit4509;
static Object strlit4512;
static Object strlit4516;
static Object strlit4518;
static Object strlit4520;
static Object strlit4522;
static Object strlit4524;
static Object strlit4526;
static Object strlit4528;
static Object strlit4530;
static Object strlit4532;
static Object strlit4534;
static Object strlit4536;
static Object strlit4538;
static Object strlit4540;
static Object strlit4542;
static Object strlit4544;
static Object strlit4546;
static Object strlit4548;
static Object strlit4550;
static Object strlit4552;
static Object strlit4554;
static Object strlit4556;
static Object strlit4558;
static Object strlit4559;
static Object strlit4562;
static Object strlit4565;
static Object strlit4569;
static Object strlit4571;
static Object strlit4573;
static Object strlit4575;
static Object strlit4577;
static Object strlit4579;
static Object strlit4581;
static Object strlit4583;
static Object strlit4585;
static Object strlit4588;
static Object strlit4592;
static Object strlit4594;
static Object strlit4596;
static Object strlit4598;
static Object strlit4608;
static Object strlit4609;
static Object strlit4616;
static Object strlit4636;
static Object strlit4639;
static Object strlit4641;
static Object strlit4645;
static Object strlit4647;
static Object strlit4651;
static Object strlit4655;
static Object strlit4657;
static Object strlit4659;
static Object strlit4661;
static Object strlit4668;
static Object strlit4672;
static Object strlit4674;
static Object strlit4676;
static Object strlit4683;
static Object strlit4687;
static Object strlit4689;
static Object strlit4691;
static Object strlit4693;
static Object strlit4695;
static Object strlit4697;
static Object strlit4699;
static Object strlit4701;
static Object strlit4703;
static Object strlit4705;
static Object strlit4707;
static Object strlit4709;
static Object strlit4711;
static Object strlit4713;
static Object strlit4715;
static Object strlit4717;
static Object strlit4719;
static Object strlit4721;
static Object strlit4723;
static Object strlit4729;
static Object strlit4738;
static Object strlit4740;
static Object strlit4742;
static Object strlit4744;
static Object strlit4746;
static Object strlit4748;
static Object strlit4750;
static Object strlit4752;
static Object strlit4754;
static Object strlit4756;
static Object strlit4758;
static Object strlit4760;
static Object strlit4762;
static Object strlit4764;
static Object strlit4766;
static Object strlit4768;
static Object strlit4770;
static Object strlit4772;
static Object strlit4774;
static Object strlit4776;
static Object strlit4778;
static Object strlit4788;
static Object strlit4792;
static Object strlit4795;
static Object strlit4800;
static Object strlit4807;
static Object strlit4810;
static Object strlit4812;
static Object strlit4814;
static Object strlit4817;
static Object strlit4821;
static Object strlit4822;
static Object strlit4826;
static Object strlit4832;
static Object strlit4841;
static Object strlit4851;
static Object strlit4854;
static Object strlit4857;
static Object strlit4864;
static Object strlit4866;
static Object strlit4869;
static Object strlit4874;
static Object strlit4881;
static Object strlit4884;
static Object strlit4886;
static Object strlit4890;
static Object strlit4893;
static Object strlit4898;
static Object strlit4902;
static Object strlit4905;
static Object strlit4910;
static Object strlit4917;
static Object strlit4920;
static Object strlit4922;
static Object strlit4925;
static Object strlit4928;
static Object strlit4931;
Object meth_genllvm29_out25(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_output = closure[0];
// compilenode returning *var_s
// compilenode returning *var_output
  params[0] = *var_s;
  Object call26 = callmethod(*var_output, "push",
    1, params);
// compilenode returning call26
  return call26;
}
Object meth_genllvm29_outprint27(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
// compilenode returning *var_s
// compilenode returning module_util
  params[0] = *var_s;
  Object call28 = callmethod(module_util, "outprint",
    1, params);
// compilenode returning call28
  return call28;
}
Object meth_genllvm29_log_verbose29(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
// compilenode returning *var_s
// compilenode returning module_util
  params[0] = *var_s;
  Object call30 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call30
  return call30;
}
Object meth_genllvm29_beginblock31(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_bblock = closure[0];
// Begin line 46
  setline(46);
  if (strlit32 == NULL) {
    strlit32 = alloc_String("%");
  }
// compilenode returning strlit32
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult34 = callmethod(strlit32, "++", 1, params);
// compilenode returning opresult34
  *var_bblock = opresult34;
  if (opresult34 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 47
  setline(47);
// compilenode returning *var_s
  if (strlit36 == NULL) {
    strlit36 = alloc_String(":");
  }
// compilenode returning strlit36
  params[0] = strlit36;
  Object opresult38 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult38
// Begin line 48
  setline(48);
// compilenode returning self
  params[0] = opresult38;
  Object call39 = callmethod(self, "out",
    1, params);
// compilenode returning call39
  return call39;
}
Object meth_genllvm29_apply57(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_a = alloc_var();
  *var_a = args[0];
  Object params[1];
  Object *var_r = closure[0];
  Object *var_myc = closure[1];
  Object self = *closure[2];
// Begin line 55
  setline(55);
// compilenode returning *var_a
// Begin line 56
  setline(56);
// compilenode returning self
  params[0] = *var_a;
  Object call58 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call58
  *var_r = call58;
  if (call58 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit60 == NULL) {
    strlit60 = alloc_String("  store %object ");
  }
// compilenode returning strlit60
// compilenode returning *var_r
  params[0] = *var_r;
  Object opresult62 = callmethod(strlit60, "++", 1, params);
// compilenode returning opresult62
  if (strlit63 == NULL) {
    strlit63 = alloc_String(", %object* %params_0");
  }
// compilenode returning strlit63
  params[0] = strlit63;
  Object opresult65 = callmethod(opresult62, "++", 1, params);
// compilenode returning opresult65
// Begin line 57
  setline(57);
// compilenode returning self
  params[0] = opresult65;
  Object call66 = callmethod(self, "out",
    1, params);
// compilenode returning call66
// Begin line 59
  setline(59);
// Begin line 57
  setline(57);
  if (strlit67 == NULL) {
    strlit67 = alloc_String("  call %object @callmethod(%object %array");
  }
// compilenode returning strlit67
// Begin line 58
  setline(58);
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult69 = callmethod(strlit67, "++", 1, params);
// compilenode returning opresult69
  if (strlit70 == NULL) {
    strlit70 = alloc_String(", i8* getelementptr([5 x i8]* @.str._push");
  }
// compilenode returning strlit70
  params[0] = strlit70;
  Object opresult72 = callmethod(opresult69, "++", 1, params);
// compilenode returning opresult72
// Begin line 59
  setline(59);
  if (strlit73 == NULL) {
    strlit73 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit73
  params[0] = strlit73;
  Object opresult75 = callmethod(opresult72, "++", 1, params);
// compilenode returning opresult75
// Begin line 60
  setline(60);
// compilenode returning self
  params[0] = opresult75;
  Object call76 = callmethod(self, "out",
    1, params);
// compilenode returning call76
  return call76;
}
Object meth_genllvm29_compilearray40(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 51
  setline(51);
// Begin line 50
  setline(50);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 52
  setline(52);
// Begin line 51
  setline(51);
// compilenode returning *var_auto_count
  Object num41 = alloc_Float64(1.0);
// compilenode returning num41
  params[0] = num41;
  Object sum43 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum43
  *var_auto_count = sum43;
  if (sum43 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 53
  setline(53);
  var_r = alloc_var();
  *var_r = undefined;
// compilenode returning nothing
  if (strlit45 == NULL) {
    strlit45 = alloc_String("  %array");
  }
// compilenode returning strlit45
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult47 = callmethod(strlit45, "++", 1, params);
// compilenode returning opresult47
  if (strlit48 == NULL) {
    strlit48 = alloc_String(" = call %object @alloc_List()");
  }
// compilenode returning strlit48
  params[0] = strlit48;
  Object opresult50 = callmethod(opresult47, "++", 1, params);
// compilenode returning opresult50
// Begin line 54
  setline(54);
// compilenode returning self
  params[0] = opresult50;
  Object call51 = callmethod(self, "out",
    1, params);
// compilenode returning call51
// Begin line 59
  setline(59);
// Begin line 61
  setline(61);
// Begin line 1429
  setline(1429);
// Begin line 54
  setline(54);
// compilenode returning *var_o
  Object call53 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call53
// compilenode returning call53
// Begin line 59
  setline(59);
// Begin line 1429
  setline(1429);
  Object obj55 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj55, self, 0);
  addmethod2(obj55, "outer", &reader_genllvm29_outer_56);
  adddatum2(obj55, self, 0);
  block_savedest(obj55);
  Object **closure57 = createclosure(3);
  addtoclosure(closure57, var_r);
  addtoclosure(closure57, var_myc);
  Object *selfpp77 = alloc_var();
  *selfpp77 = self;
  addtoclosure(closure57, selfpp77);
  struct UserObject *uo57 = (struct UserObject*)obj55;
  uo57->data[1] = (Object)closure57;
  addmethod2(obj55, "apply", &meth_genllvm29_apply57);
  set_type(obj55, 0);
// compilenode returning obj55
  setclassname(obj55, "Block<genllvm29:54>");
// compilenode returning obj55
  params[0] = call53;
  Object iter52 = callmethod(call53, "iter", 1, params);
  while(1) {
    Object cond52 = callmethod(iter52, "havemore", 0, NULL);
    if (!istrue(cond52)) break;
    params[0] = callmethod(iter52, "next", 0, NULL);
    callmethod(obj55, "apply", 1, params);
  }
// compilenode returning call53
// Begin line 62
  setline(62);
// Begin line 1429
  setline(1429);
// Begin line 62
  setline(62);
// Begin line 61
  setline(61);
  if (strlit78 == NULL) {
    strlit78 = alloc_String("%array");
  }
// compilenode returning strlit78
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult80 = callmethod(strlit78, "++", 1, params);
// compilenode returning opresult80
// compilenode returning *var_o
  params[0] = opresult80;
  Object call81 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call81
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilemember82(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_c = alloc_var();
  *var_c = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 66
  setline(66);
  Object array83 = alloc_List();
// compilenode returning array83
  var_l = alloc_var();
  *var_l = array83;
  if (array83 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_o
// compilenode returning *var_l
// compilenode returning module_ast
  params[0] = *var_o;
  params[1] = *var_l;
  Object call84 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call84
  var_c = alloc_var();
  *var_c = call84;
  if (call84 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 67
  setline(67);
// compilenode returning *var_c
// Begin line 68
  setline(68);
// compilenode returning self
  params[0] = *var_c;
  Object call85 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call85
  var_r = alloc_var();
  *var_r = call85;
  if (call85 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 69
  setline(69);
// Begin line 1429
  setline(1429);
// Begin line 68
  setline(68);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call86 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call86
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileobjouter87(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_selfr = alloc_var();
  *var_selfr = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_modname = closure[2];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_enm = alloc_var();
  *var_enm = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 72
  setline(72);
// Begin line 71
  setline(71);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 73
  setline(73);
// Begin line 72
  setline(72);
// compilenode returning *var_auto_count
  Object num88 = alloc_Float64(1.0);
// compilenode returning num88
  params[0] = num88;
  Object sum90 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum90
  *var_auto_count = sum90;
  if (sum90 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 74
  setline(74);
// Begin line 73
  setline(73);
  if (strlit92 == NULL) {
    strlit92 = alloc_String("outer");
  }
// compilenode returning strlit92
  var_nm = alloc_var();
  *var_nm = strlit92;
  if (strlit92 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 74
  setline(74);
// compilenode returning *var_nm
  Object call93 = gracelib_length(*var_nm);
// compilenode returning call93
  Object num94 = alloc_Float64(1.0);
// compilenode returning num94
  params[0] = num94;
  Object sum96 = callmethod(call93, "+", 1, params);
// compilenode returning sum96
  var_len = alloc_var();
  *var_len = sum96;
  if (sum96 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 75
  setline(75);
// Begin line 1429
  setline(1429);
// Begin line 75
  setline(75);
// compilenode returning *var_nm
  Object call97 = callmethod(*var_nm, "_escape",
    0, params);
// compilenode returning call97
// compilenode returning call97
  var_enm = alloc_var();
  *var_enm = call97;
  if (call97 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 78
  setline(78);
// Begin line 76
  setline(76);
  if (strlit98 == NULL) {
    strlit98 = alloc_String("@.str.methname");
  }
// compilenode returning strlit98
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult100 = callmethod(strlit98, "++", 1, params);
// compilenode returning opresult100
  if (strlit101 == NULL) {
    strlit101 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit101
  params[0] = strlit101;
  Object opresult103 = callmethod(opresult100, "++", 1, params);
// compilenode returning opresult103
// Begin line 77
  setline(77);
  if (strlit104 == NULL) {
    strlit104 = alloc_String("constant [");
  }
// compilenode returning strlit104
  params[0] = strlit104;
  Object opresult106 = callmethod(opresult103, "++", 1, params);
// compilenode returning opresult106
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult108 = callmethod(opresult106, "++", 1, params);
// compilenode returning opresult108
  if (strlit109 == NULL) {
    strlit109 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit109
  params[0] = strlit109;
  Object opresult111 = callmethod(opresult108, "++", 1, params);
// compilenode returning opresult111
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult113 = callmethod(opresult111, "++", 1, params);
// compilenode returning opresult113
  if (strlit114 == NULL) {
    strlit114 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit114
  params[0] = strlit114;
  Object opresult116 = callmethod(opresult113, "++", 1, params);
// compilenode returning opresult116
  var_con = alloc_var();
  *var_con = opresult116;
  if (opresult116 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 78
  setline(78);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call117 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call117
// Begin line 79
  setline(79);
  if (strlit118 == NULL) {
    strlit118 = alloc_String("; OBJECT OUTER DEC ");
  }
// compilenode returning strlit118
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult120 = callmethod(strlit118, "++", 1, params);
// compilenode returning opresult120
// Begin line 80
  setline(80);
// compilenode returning self
  params[0] = opresult120;
  Object call121 = callmethod(self, "out",
    1, params);
// compilenode returning call121
  if (strlit122 == NULL) {
    strlit122 = alloc_String("  call void @adddatum2(%object ");
  }
// compilenode returning strlit122
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult124 = callmethod(strlit122, "++", 1, params);
// compilenode returning opresult124
  if (strlit125 == NULL) {
    strlit125 = alloc_String(", %object %self, i32 0)");
  }
// compilenode returning strlit125
  params[0] = strlit125;
  Object opresult127 = callmethod(opresult124, "++", 1, params);
// compilenode returning opresult127
// Begin line 81
  setline(81);
// compilenode returning self
  params[0] = opresult127;
  Object call128 = callmethod(self, "out",
    1, params);
// compilenode returning call128
// Begin line 83
  setline(83);
// Begin line 81
  setline(81);
  if (strlit129 == NULL) {
    strlit129 = alloc_String("define private %object @""\x22""reader_");
  }
// compilenode returning strlit129
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult131 = callmethod(strlit129, "++", 1, params);
// compilenode returning opresult131
  if (strlit132 == NULL) {
    strlit132 = alloc_String("_");
  }
// compilenode returning strlit132
  params[0] = strlit132;
  Object opresult134 = callmethod(opresult131, "++", 1, params);
// compilenode returning opresult134
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult136 = callmethod(opresult134, "++", 1, params);
// compilenode returning opresult136
  if (strlit137 == NULL) {
    strlit137 = alloc_String("_");
  }
// compilenode returning strlit137
  params[0] = strlit137;
  Object opresult139 = callmethod(opresult136, "++", 1, params);
// compilenode returning opresult139
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult141 = callmethod(opresult139, "++", 1, params);
// compilenode returning opresult141
// Begin line 82
  setline(82);
  if (strlit142 == NULL) {
    strlit142 = alloc_String("""\x22""(%object %self, i32 %nparams, ");
  }
// compilenode returning strlit142
  params[0] = strlit142;
  Object opresult144 = callmethod(opresult141, "++", 1, params);
// compilenode returning opresult144
// Begin line 83
  setline(83);
  if (strlit145 == NULL) {
    strlit145 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit145
  params[0] = strlit145;
  Object opresult147 = callmethod(opresult144, "++", 1, params);
// compilenode returning opresult147
// Begin line 84
  setline(84);
// compilenode returning self
  params[0] = opresult147;
  Object call148 = callmethod(self, "outprint",
    1, params);
// compilenode returning call148
  if (strlit149 == NULL) {
    strlit149 = alloc_String("  %uo = bitcast %object %self to %UserObject*");
  }
// compilenode returning strlit149
// Begin line 85
  setline(85);
// compilenode returning self
  params[0] = strlit149;
  Object call150 = callmethod(self, "outprint",
    1, params);
// compilenode returning call150
  if (strlit151 == NULL) {
    strlit151 = alloc_String("  %fieldpp = getelementptr %UserObject* %uo, i32 0, i32 3");
  }
// compilenode returning strlit151
// Begin line 86
  setline(86);
// compilenode returning self
  params[0] = strlit151;
  Object call152 = callmethod(self, "outprint",
    1, params);
// compilenode returning call152
  if (strlit153 == NULL) {
    strlit153 = alloc_String("  %fieldpf = getelementptr [0 x %object]* %fieldpp, i32 0, i32 0");
  }
// compilenode returning strlit153
// Begin line 87
  setline(87);
// compilenode returning self
  params[0] = strlit153;
  Object call154 = callmethod(self, "outprint",
    1, params);
// compilenode returning call154
  if (strlit155 == NULL) {
    strlit155 = alloc_String("  %val = load %object* %fieldpf");
  }
// compilenode returning strlit155
// Begin line 88
  setline(88);
// compilenode returning self
  params[0] = strlit155;
  Object call156 = callmethod(self, "outprint",
    1, params);
// compilenode returning call156
  if (strlit157 == NULL) {
    strlit157 = alloc_String("  ret %object %val");
  }
// compilenode returning strlit157
// Begin line 89
  setline(89);
// compilenode returning self
  params[0] = strlit157;
  Object call158 = callmethod(self, "outprint",
    1, params);
// compilenode returning call158
  if (strlit159 == NULL) {
    strlit159 = alloc_String("}");
  }
// compilenode returning strlit159
// Begin line 90
  setline(90);
// compilenode returning self
  params[0] = strlit159;
  Object call160 = callmethod(self, "outprint",
    1, params);
// compilenode returning call160
// Begin line 98
  setline(98);
// Begin line 90
  setline(90);
  if (strlit161 == NULL) {
    strlit161 = alloc_String("  call void @addmethod2(%object ");
  }
// compilenode returning strlit161
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult163 = callmethod(strlit161, "++", 1, params);
// compilenode returning opresult163
// Begin line 91
  setline(91);
  if (strlit164 == NULL) {
    strlit164 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit164
  params[0] = strlit164;
  Object opresult166 = callmethod(opresult163, "++", 1, params);
// compilenode returning opresult166
// Begin line 92
  setline(92);
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult168 = callmethod(opresult166, "++", 1, params);
// compilenode returning opresult168
  if (strlit169 == NULL) {
    strlit169 = alloc_String(" x i8]* @.str.methname");
  }
// compilenode returning strlit169
  params[0] = strlit169;
  Object opresult171 = callmethod(opresult168, "++", 1, params);
// compilenode returning opresult171
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult173 = callmethod(opresult171, "++", 1, params);
// compilenode returning opresult173
  if (strlit174 == NULL) {
    strlit174 = alloc_String(", i32 0, i32 0), ");
  }
// compilenode returning strlit174
  params[0] = strlit174;
  Object opresult176 = callmethod(opresult173, "++", 1, params);
// compilenode returning opresult176
// Begin line 93
  setline(93);
  if (strlit177 == NULL) {
    strlit177 = alloc_String("%object(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit177
  params[0] = strlit177;
  Object opresult179 = callmethod(opresult176, "++", 1, params);
// compilenode returning opresult179
// Begin line 94
  setline(94);
  if (strlit180 == NULL) {
    strlit180 = alloc_String("getelementptr(%object ");
  }
// compilenode returning strlit180
  params[0] = strlit180;
  Object opresult182 = callmethod(opresult179, "++", 1, params);
// compilenode returning opresult182
// Begin line 95
  setline(95);
  if (strlit183 == NULL) {
    strlit183 = alloc_String("(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit183
  params[0] = strlit183;
  Object opresult185 = callmethod(opresult182, "++", 1, params);
// compilenode returning opresult185
// Begin line 96
  setline(96);
  if (strlit186 == NULL) {
    strlit186 = alloc_String("@""\x22""reader_");
  }
// compilenode returning strlit186
  params[0] = strlit186;
  Object opresult188 = callmethod(opresult185, "++", 1, params);
// compilenode returning opresult188
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult190 = callmethod(opresult188, "++", 1, params);
// compilenode returning opresult190
  if (strlit191 == NULL) {
    strlit191 = alloc_String("_");
  }
// compilenode returning strlit191
  params[0] = strlit191;
  Object opresult193 = callmethod(opresult190, "++", 1, params);
// compilenode returning opresult193
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult195 = callmethod(opresult193, "++", 1, params);
// compilenode returning opresult195
// Begin line 97
  setline(97);
  if (strlit196 == NULL) {
    strlit196 = alloc_String("_");
  }
// compilenode returning strlit196
  params[0] = strlit196;
  Object opresult198 = callmethod(opresult195, "++", 1, params);
// compilenode returning opresult198
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult200 = callmethod(opresult198, "++", 1, params);
// compilenode returning opresult200
// Begin line 98
  setline(98);
  if (strlit201 == NULL) {
    strlit201 = alloc_String("""\x22""))");
  }
// compilenode returning strlit201
  params[0] = strlit201;
  Object opresult203 = callmethod(opresult200, "++", 1, params);
// compilenode returning opresult203
// Begin line 99
  setline(99);
// compilenode returning self
  params[0] = opresult203;
  Object call204 = callmethod(self, "out",
    1, params);
// compilenode returning call204
  return call204;
}
Object meth_genllvm29_compileobjdefdec205(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfr = alloc_var();
  *var_selfr = args[1];
  Object *var_pos = alloc_var();
  *var_pos = args[2];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_modname = closure[2];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_enm = alloc_var();
  *var_enm = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 102
  setline(102);
// Begin line 101
  setline(101);
  if (strlit206 == NULL) {
    strlit206 = alloc_String("%undefined");
  }
// compilenode returning strlit206
  var_val = alloc_var();
  *var_val = strlit206;
  if (strlit206 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 103
  setline(103);
// Begin line 105
  setline(105);
// Begin line 1429
  setline(1429);
// Begin line 102
  setline(102);
// compilenode returning *var_o
  Object call208 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call208
// compilenode returning call208
  Object if207;
  if (istrue(call208)) {
// Begin line 103
  setline(103);
// Begin line 1429
  setline(1429);
// Begin line 103
  setline(103);
// compilenode returning *var_o
  Object call209 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call209
// compilenode returning call209
// Begin line 104
  setline(104);
// compilenode returning self
  params[0] = call209;
  Object call210 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call210
  *var_val = call210;
  if (call210 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if207 = nothing;
  } else {
  }
// compilenode returning if207
// Begin line 106
  setline(106);
// Begin line 105
  setline(105);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 107
  setline(107);
// Begin line 106
  setline(106);
// compilenode returning *var_auto_count
  Object num212 = alloc_Float64(1.0);
// compilenode returning num212
  params[0] = num212;
  Object sum214 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum214
  *var_auto_count = sum214;
  if (sum214 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 108
  setline(108);
// Begin line 1429
  setline(1429);
// Begin line 108
  setline(108);
// Begin line 1429
  setline(1429);
// Begin line 107
  setline(107);
// compilenode returning *var_o
  Object call216 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call216
// compilenode returning call216
  Object call217 = callmethod(call216, "value",
    0, params);
// compilenode returning call217
// compilenode returning call217
  var_nm = alloc_var();
  *var_nm = call217;
  if (call217 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 108
  setline(108);
// compilenode returning *var_nm
  Object call218 = gracelib_length(*var_nm);
// compilenode returning call218
  Object num219 = alloc_Float64(1.0);
// compilenode returning num219
  params[0] = num219;
  Object sum221 = callmethod(call218, "+", 1, params);
// compilenode returning sum221
  var_len = alloc_var();
  *var_len = sum221;
  if (sum221 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 109
  setline(109);
// Begin line 1429
  setline(1429);
// Begin line 109
  setline(109);
// compilenode returning *var_nm
  Object call222 = callmethod(*var_nm, "_escape",
    0, params);
// compilenode returning call222
// compilenode returning call222
  var_enm = alloc_var();
  *var_enm = call222;
  if (call222 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 112
  setline(112);
// Begin line 110
  setline(110);
  if (strlit223 == NULL) {
    strlit223 = alloc_String("@.str.methname");
  }
// compilenode returning strlit223
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult225 = callmethod(strlit223, "++", 1, params);
// compilenode returning opresult225
  if (strlit226 == NULL) {
    strlit226 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit226
  params[0] = strlit226;
  Object opresult228 = callmethod(opresult225, "++", 1, params);
// compilenode returning opresult228
// Begin line 111
  setline(111);
  if (strlit229 == NULL) {
    strlit229 = alloc_String("constant [");
  }
// compilenode returning strlit229
  params[0] = strlit229;
  Object opresult231 = callmethod(opresult228, "++", 1, params);
// compilenode returning opresult231
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult233 = callmethod(opresult231, "++", 1, params);
// compilenode returning opresult233
  if (strlit234 == NULL) {
    strlit234 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit234
  params[0] = strlit234;
  Object opresult236 = callmethod(opresult233, "++", 1, params);
// compilenode returning opresult236
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult238 = callmethod(opresult236, "++", 1, params);
// compilenode returning opresult238
  if (strlit239 == NULL) {
    strlit239 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit239
  params[0] = strlit239;
  Object opresult241 = callmethod(opresult238, "++", 1, params);
// compilenode returning opresult241
  var_con = alloc_var();
  *var_con = opresult241;
  if (opresult241 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 112
  setline(112);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call242 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call242
// Begin line 113
  setline(113);
  if (strlit243 == NULL) {
    strlit243 = alloc_String("; OBJECT CONST DEC ");
  }
// compilenode returning strlit243
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult245 = callmethod(strlit243, "++", 1, params);
// compilenode returning opresult245
// Begin line 114
  setline(114);
// compilenode returning self
  params[0] = opresult245;
  Object call246 = callmethod(self, "out",
    1, params);
// compilenode returning call246
  if (strlit247 == NULL) {
    strlit247 = alloc_String("  call void @adddatum2(%object ");
  }
// compilenode returning strlit247
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult249 = callmethod(strlit247, "++", 1, params);
// compilenode returning opresult249
  if (strlit250 == NULL) {
    strlit250 = alloc_String(", %object ");
  }
// compilenode returning strlit250
  params[0] = strlit250;
  Object opresult252 = callmethod(opresult249, "++", 1, params);
// compilenode returning opresult252
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult254 = callmethod(opresult252, "++", 1, params);
// compilenode returning opresult254
  if (strlit255 == NULL) {
    strlit255 = alloc_String(", i32 ");
  }
// compilenode returning strlit255
  params[0] = strlit255;
  Object opresult257 = callmethod(opresult254, "++", 1, params);
// compilenode returning opresult257
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult259 = callmethod(opresult257, "++", 1, params);
// compilenode returning opresult259
  if (strlit260 == NULL) {
    strlit260 = alloc_String(")");
  }
// compilenode returning strlit260
  params[0] = strlit260;
  Object opresult262 = callmethod(opresult259, "++", 1, params);
// compilenode returning opresult262
// Begin line 115
  setline(115);
// compilenode returning self
  params[0] = opresult262;
  Object call263 = callmethod(self, "out",
    1, params);
// compilenode returning call263
// Begin line 117
  setline(117);
// Begin line 115
  setline(115);
  if (strlit264 == NULL) {
    strlit264 = alloc_String("define private %object @""\x22""reader_");
  }
// compilenode returning strlit264
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult266 = callmethod(strlit264, "++", 1, params);
// compilenode returning opresult266
  if (strlit267 == NULL) {
    strlit267 = alloc_String("_");
  }
// compilenode returning strlit267
  params[0] = strlit267;
  Object opresult269 = callmethod(opresult266, "++", 1, params);
// compilenode returning opresult269
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult271 = callmethod(opresult269, "++", 1, params);
// compilenode returning opresult271
  if (strlit272 == NULL) {
    strlit272 = alloc_String("_");
  }
// compilenode returning strlit272
  params[0] = strlit272;
  Object opresult274 = callmethod(opresult271, "++", 1, params);
// compilenode returning opresult274
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult276 = callmethod(opresult274, "++", 1, params);
// compilenode returning opresult276
// Begin line 116
  setline(116);
  if (strlit277 == NULL) {
    strlit277 = alloc_String("""\x22""(%object %self, i32 %nparams, ");
  }
// compilenode returning strlit277
  params[0] = strlit277;
  Object opresult279 = callmethod(opresult276, "++", 1, params);
// compilenode returning opresult279
// Begin line 117
  setline(117);
  if (strlit280 == NULL) {
    strlit280 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit280
  params[0] = strlit280;
  Object opresult282 = callmethod(opresult279, "++", 1, params);
// compilenode returning opresult282
// Begin line 118
  setline(118);
// compilenode returning self
  params[0] = opresult282;
  Object call283 = callmethod(self, "outprint",
    1, params);
// compilenode returning call283
  if (strlit284 == NULL) {
    strlit284 = alloc_String("  %uo = bitcast %object %self to %UserObject*");
  }
// compilenode returning strlit284
// Begin line 119
  setline(119);
// compilenode returning self
  params[0] = strlit284;
  Object call285 = callmethod(self, "outprint",
    1, params);
// compilenode returning call285
  if (strlit286 == NULL) {
    strlit286 = alloc_String("  %fieldpp = getelementptr %UserObject* %uo, i32 0, i32 3");
  }
// compilenode returning strlit286
// Begin line 120
  setline(120);
// compilenode returning self
  params[0] = strlit286;
  Object call287 = callmethod(self, "outprint",
    1, params);
// compilenode returning call287
  if (strlit288 == NULL) {
    strlit288 = alloc_String("  %fieldpf = getelementptr [0 x %object]* %fieldpp, i32 0, i32 ");
  }
// compilenode returning strlit288
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult290 = callmethod(strlit288, "++", 1, params);
// compilenode returning opresult290
  if (strlit291 == NULL) {
    strlit291 = alloc_String("");
  }
// compilenode returning strlit291
  params[0] = strlit291;
  Object opresult293 = callmethod(opresult290, "++", 1, params);
// compilenode returning opresult293
// Begin line 121
  setline(121);
// compilenode returning self
  params[0] = opresult293;
  Object call294 = callmethod(self, "outprint",
    1, params);
// compilenode returning call294
  if (strlit295 == NULL) {
    strlit295 = alloc_String("  %val = load %object* %fieldpf");
  }
// compilenode returning strlit295
// Begin line 122
  setline(122);
// compilenode returning self
  params[0] = strlit295;
  Object call296 = callmethod(self, "outprint",
    1, params);
// compilenode returning call296
  if (strlit297 == NULL) {
    strlit297 = alloc_String("  ret %object %val");
  }
// compilenode returning strlit297
// Begin line 123
  setline(123);
// compilenode returning self
  params[0] = strlit297;
  Object call298 = callmethod(self, "outprint",
    1, params);
// compilenode returning call298
  if (strlit299 == NULL) {
    strlit299 = alloc_String("}");
  }
// compilenode returning strlit299
// Begin line 124
  setline(124);
// compilenode returning self
  params[0] = strlit299;
  Object call300 = callmethod(self, "outprint",
    1, params);
// compilenode returning call300
// Begin line 132
  setline(132);
// Begin line 124
  setline(124);
  if (strlit301 == NULL) {
    strlit301 = alloc_String("  call void @addmethod2(%object ");
  }
// compilenode returning strlit301
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult303 = callmethod(strlit301, "++", 1, params);
// compilenode returning opresult303
// Begin line 125
  setline(125);
  if (strlit304 == NULL) {
    strlit304 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit304
  params[0] = strlit304;
  Object opresult306 = callmethod(opresult303, "++", 1, params);
// compilenode returning opresult306
// Begin line 126
  setline(126);
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult308 = callmethod(opresult306, "++", 1, params);
// compilenode returning opresult308
  if (strlit309 == NULL) {
    strlit309 = alloc_String(" x i8]* @.str.methname");
  }
// compilenode returning strlit309
  params[0] = strlit309;
  Object opresult311 = callmethod(opresult308, "++", 1, params);
// compilenode returning opresult311
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult313 = callmethod(opresult311, "++", 1, params);
// compilenode returning opresult313
  if (strlit314 == NULL) {
    strlit314 = alloc_String(", i32 0, i32 0), ");
  }
// compilenode returning strlit314
  params[0] = strlit314;
  Object opresult316 = callmethod(opresult313, "++", 1, params);
// compilenode returning opresult316
// Begin line 127
  setline(127);
  if (strlit317 == NULL) {
    strlit317 = alloc_String("%object(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit317
  params[0] = strlit317;
  Object opresult319 = callmethod(opresult316, "++", 1, params);
// compilenode returning opresult319
// Begin line 128
  setline(128);
  if (strlit320 == NULL) {
    strlit320 = alloc_String("getelementptr(%object ");
  }
// compilenode returning strlit320
  params[0] = strlit320;
  Object opresult322 = callmethod(opresult319, "++", 1, params);
// compilenode returning opresult322
// Begin line 129
  setline(129);
  if (strlit323 == NULL) {
    strlit323 = alloc_String("(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit323
  params[0] = strlit323;
  Object opresult325 = callmethod(opresult322, "++", 1, params);
// compilenode returning opresult325
// Begin line 130
  setline(130);
  if (strlit326 == NULL) {
    strlit326 = alloc_String("@""\x22""reader_");
  }
// compilenode returning strlit326
  params[0] = strlit326;
  Object opresult328 = callmethod(opresult325, "++", 1, params);
// compilenode returning opresult328
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult330 = callmethod(opresult328, "++", 1, params);
// compilenode returning opresult330
  if (strlit331 == NULL) {
    strlit331 = alloc_String("_");
  }
// compilenode returning strlit331
  params[0] = strlit331;
  Object opresult333 = callmethod(opresult330, "++", 1, params);
// compilenode returning opresult333
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult335 = callmethod(opresult333, "++", 1, params);
// compilenode returning opresult335
// Begin line 131
  setline(131);
  if (strlit336 == NULL) {
    strlit336 = alloc_String("_");
  }
// compilenode returning strlit336
  params[0] = strlit336;
  Object opresult338 = callmethod(opresult335, "++", 1, params);
// compilenode returning opresult338
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult340 = callmethod(opresult338, "++", 1, params);
// compilenode returning opresult340
// Begin line 132
  setline(132);
  if (strlit341 == NULL) {
    strlit341 = alloc_String("""\x22""))");
  }
// compilenode returning strlit341
  params[0] = strlit341;
  Object opresult343 = callmethod(opresult340, "++", 1, params);
// compilenode returning opresult343
// Begin line 133
  setline(133);
// compilenode returning self
  params[0] = opresult343;
  Object call344 = callmethod(self, "out",
    1, params);
// compilenode returning call344
  return call344;
}
Object meth_genllvm29_compileobjvardec345(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfr = alloc_var();
  *var_selfr = args[1];
  Object *var_pos = alloc_var();
  *var_pos = args[2];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_modname = closure[2];
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_enm = alloc_var();
  *var_enm = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
  Object *var_nmw = alloc_var();
  *var_nmw = undefined;
// Begin line 136
  setline(136);
// Begin line 135
  setline(135);
  if (strlit346 == NULL) {
    strlit346 = alloc_String("%undefined");
  }
// compilenode returning strlit346
  var_val = alloc_var();
  *var_val = strlit346;
  if (strlit346 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 137
  setline(137);
// Begin line 139
  setline(139);
// Begin line 1429
  setline(1429);
// Begin line 136
  setline(136);
// compilenode returning *var_o
  Object call348 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call348
// compilenode returning call348
  Object if347;
  if (istrue(call348)) {
// Begin line 137
  setline(137);
// Begin line 1429
  setline(1429);
// Begin line 137
  setline(137);
// compilenode returning *var_o
  Object call349 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call349
// compilenode returning call349
// Begin line 138
  setline(138);
// compilenode returning self
  params[0] = call349;
  Object call350 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call350
  *var_val = call350;
  if (call350 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if347 = nothing;
  } else {
  }
// compilenode returning if347
// Begin line 140
  setline(140);
// Begin line 139
  setline(139);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 141
  setline(141);
// Begin line 140
  setline(140);
// compilenode returning *var_auto_count
  Object num352 = alloc_Float64(1.0);
// compilenode returning num352
  params[0] = num352;
  Object sum354 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum354
  *var_auto_count = sum354;
  if (sum354 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 142
  setline(142);
// Begin line 1429
  setline(1429);
// Begin line 142
  setline(142);
// Begin line 1429
  setline(1429);
// Begin line 141
  setline(141);
// compilenode returning *var_o
  Object call356 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call356
// compilenode returning call356
  Object call357 = callmethod(call356, "value",
    0, params);
// compilenode returning call357
// compilenode returning call357
  var_nm = alloc_var();
  *var_nm = call357;
  if (call357 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 142
  setline(142);
// compilenode returning *var_nm
  Object call358 = gracelib_length(*var_nm);
// compilenode returning call358
  Object num359 = alloc_Float64(1.0);
// compilenode returning num359
  params[0] = num359;
  Object sum361 = callmethod(call358, "+", 1, params);
// compilenode returning sum361
  var_len = alloc_var();
  *var_len = sum361;
  if (sum361 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 143
  setline(143);
// Begin line 1429
  setline(1429);
// Begin line 143
  setline(143);
// compilenode returning *var_nm
  Object call362 = callmethod(*var_nm, "_escape",
    0, params);
// compilenode returning call362
// compilenode returning call362
  var_enm = alloc_var();
  *var_enm = call362;
  if (call362 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 146
  setline(146);
// Begin line 144
  setline(144);
  if (strlit363 == NULL) {
    strlit363 = alloc_String("@.str.methname");
  }
// compilenode returning strlit363
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult365 = callmethod(strlit363, "++", 1, params);
// compilenode returning opresult365
  if (strlit366 == NULL) {
    strlit366 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit366
  params[0] = strlit366;
  Object opresult368 = callmethod(opresult365, "++", 1, params);
// compilenode returning opresult368
// Begin line 145
  setline(145);
  if (strlit369 == NULL) {
    strlit369 = alloc_String("constant [");
  }
// compilenode returning strlit369
  params[0] = strlit369;
  Object opresult371 = callmethod(opresult368, "++", 1, params);
// compilenode returning opresult371
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult373 = callmethod(opresult371, "++", 1, params);
// compilenode returning opresult373
  if (strlit374 == NULL) {
    strlit374 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit374
  params[0] = strlit374;
  Object opresult376 = callmethod(opresult373, "++", 1, params);
// compilenode returning opresult376
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult378 = callmethod(opresult376, "++", 1, params);
// compilenode returning opresult378
  if (strlit379 == NULL) {
    strlit379 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit379
  params[0] = strlit379;
  Object opresult381 = callmethod(opresult378, "++", 1, params);
// compilenode returning opresult381
  var_con = alloc_var();
  *var_con = opresult381;
  if (opresult381 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 146
  setline(146);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call382 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call382
// Begin line 147
  setline(147);
  if (strlit383 == NULL) {
    strlit383 = alloc_String("; OBJECT VAR DEC ");
  }
// compilenode returning strlit383
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult385 = callmethod(strlit383, "++", 1, params);
// compilenode returning opresult385
// Begin line 148
  setline(148);
// compilenode returning self
  params[0] = opresult385;
  Object call386 = callmethod(self, "out",
    1, params);
// compilenode returning call386
  if (strlit387 == NULL) {
    strlit387 = alloc_String("  call void @adddatum2(%object ");
  }
// compilenode returning strlit387
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult389 = callmethod(strlit387, "++", 1, params);
// compilenode returning opresult389
  if (strlit390 == NULL) {
    strlit390 = alloc_String(", %object ");
  }
// compilenode returning strlit390
  params[0] = strlit390;
  Object opresult392 = callmethod(opresult389, "++", 1, params);
// compilenode returning opresult392
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult394 = callmethod(opresult392, "++", 1, params);
// compilenode returning opresult394
  if (strlit395 == NULL) {
    strlit395 = alloc_String(", i32 ");
  }
// compilenode returning strlit395
  params[0] = strlit395;
  Object opresult397 = callmethod(opresult394, "++", 1, params);
// compilenode returning opresult397
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult399 = callmethod(opresult397, "++", 1, params);
// compilenode returning opresult399
  if (strlit400 == NULL) {
    strlit400 = alloc_String(")");
  }
// compilenode returning strlit400
  params[0] = strlit400;
  Object opresult402 = callmethod(opresult399, "++", 1, params);
// compilenode returning opresult402
// Begin line 149
  setline(149);
// compilenode returning self
  params[0] = opresult402;
  Object call403 = callmethod(self, "out",
    1, params);
// compilenode returning call403
// Begin line 151
  setline(151);
// Begin line 149
  setline(149);
  if (strlit404 == NULL) {
    strlit404 = alloc_String("define private %object @""\x22""reader_");
  }
// compilenode returning strlit404
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult406 = callmethod(strlit404, "++", 1, params);
// compilenode returning opresult406
  if (strlit407 == NULL) {
    strlit407 = alloc_String("_");
  }
// compilenode returning strlit407
  params[0] = strlit407;
  Object opresult409 = callmethod(opresult406, "++", 1, params);
// compilenode returning opresult409
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult411 = callmethod(opresult409, "++", 1, params);
// compilenode returning opresult411
  if (strlit412 == NULL) {
    strlit412 = alloc_String("_");
  }
// compilenode returning strlit412
  params[0] = strlit412;
  Object opresult414 = callmethod(opresult411, "++", 1, params);
// compilenode returning opresult414
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult416 = callmethod(opresult414, "++", 1, params);
// compilenode returning opresult416
// Begin line 150
  setline(150);
  if (strlit417 == NULL) {
    strlit417 = alloc_String("""\x22""(%object %self, i32 %nparams, ");
  }
// compilenode returning strlit417
  params[0] = strlit417;
  Object opresult419 = callmethod(opresult416, "++", 1, params);
// compilenode returning opresult419
// Begin line 151
  setline(151);
  if (strlit420 == NULL) {
    strlit420 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit420
  params[0] = strlit420;
  Object opresult422 = callmethod(opresult419, "++", 1, params);
// compilenode returning opresult422
// Begin line 152
  setline(152);
// compilenode returning self
  params[0] = opresult422;
  Object call423 = callmethod(self, "outprint",
    1, params);
// compilenode returning call423
  if (strlit424 == NULL) {
    strlit424 = alloc_String("  %uo = bitcast %object %self to %UserObject*");
  }
// compilenode returning strlit424
// Begin line 153
  setline(153);
// compilenode returning self
  params[0] = strlit424;
  Object call425 = callmethod(self, "outprint",
    1, params);
// compilenode returning call425
  if (strlit426 == NULL) {
    strlit426 = alloc_String("  %fieldpp = getelementptr %UserObject* %uo, i32 0, i32 3");
  }
// compilenode returning strlit426
// Begin line 154
  setline(154);
// compilenode returning self
  params[0] = strlit426;
  Object call427 = callmethod(self, "outprint",
    1, params);
// compilenode returning call427
  if (strlit428 == NULL) {
    strlit428 = alloc_String("  %fieldpf = getelementptr [0 x %object]* %fieldpp, i32 0, i32 ");
  }
// compilenode returning strlit428
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult430 = callmethod(strlit428, "++", 1, params);
// compilenode returning opresult430
  if (strlit431 == NULL) {
    strlit431 = alloc_String("");
  }
// compilenode returning strlit431
  params[0] = strlit431;
  Object opresult433 = callmethod(opresult430, "++", 1, params);
// compilenode returning opresult433
// Begin line 155
  setline(155);
// compilenode returning self
  params[0] = opresult433;
  Object call434 = callmethod(self, "outprint",
    1, params);
// compilenode returning call434
  if (strlit435 == NULL) {
    strlit435 = alloc_String("  %val = load %object* %fieldpf");
  }
// compilenode returning strlit435
// Begin line 156
  setline(156);
// compilenode returning self
  params[0] = strlit435;
  Object call436 = callmethod(self, "outprint",
    1, params);
// compilenode returning call436
  if (strlit437 == NULL) {
    strlit437 = alloc_String("  ret %object %val");
  }
// compilenode returning strlit437
// Begin line 157
  setline(157);
// compilenode returning self
  params[0] = strlit437;
  Object call438 = callmethod(self, "outprint",
    1, params);
// compilenode returning call438
  if (strlit439 == NULL) {
    strlit439 = alloc_String("}");
  }
// compilenode returning strlit439
// Begin line 158
  setline(158);
// compilenode returning self
  params[0] = strlit439;
  Object call440 = callmethod(self, "outprint",
    1, params);
// compilenode returning call440
// Begin line 166
  setline(166);
// Begin line 158
  setline(158);
  if (strlit441 == NULL) {
    strlit441 = alloc_String("  call void @addmethod2(%object ");
  }
// compilenode returning strlit441
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult443 = callmethod(strlit441, "++", 1, params);
// compilenode returning opresult443
// Begin line 159
  setline(159);
  if (strlit444 == NULL) {
    strlit444 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit444
  params[0] = strlit444;
  Object opresult446 = callmethod(opresult443, "++", 1, params);
// compilenode returning opresult446
// Begin line 160
  setline(160);
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult448 = callmethod(opresult446, "++", 1, params);
// compilenode returning opresult448
  if (strlit449 == NULL) {
    strlit449 = alloc_String(" x i8]* @.str.methname");
  }
// compilenode returning strlit449
  params[0] = strlit449;
  Object opresult451 = callmethod(opresult448, "++", 1, params);
// compilenode returning opresult451
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult453 = callmethod(opresult451, "++", 1, params);
// compilenode returning opresult453
  if (strlit454 == NULL) {
    strlit454 = alloc_String(", i32 0, i32 0), ");
  }
// compilenode returning strlit454
  params[0] = strlit454;
  Object opresult456 = callmethod(opresult453, "++", 1, params);
// compilenode returning opresult456
// Begin line 161
  setline(161);
  if (strlit457 == NULL) {
    strlit457 = alloc_String("%object(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit457
  params[0] = strlit457;
  Object opresult459 = callmethod(opresult456, "++", 1, params);
// compilenode returning opresult459
// Begin line 162
  setline(162);
  if (strlit460 == NULL) {
    strlit460 = alloc_String("getelementptr(%object ");
  }
// compilenode returning strlit460
  params[0] = strlit460;
  Object opresult462 = callmethod(opresult459, "++", 1, params);
// compilenode returning opresult462
// Begin line 163
  setline(163);
  if (strlit463 == NULL) {
    strlit463 = alloc_String("(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit463
  params[0] = strlit463;
  Object opresult465 = callmethod(opresult462, "++", 1, params);
// compilenode returning opresult465
// Begin line 164
  setline(164);
  if (strlit466 == NULL) {
    strlit466 = alloc_String("@""\x22""reader_");
  }
// compilenode returning strlit466
  params[0] = strlit466;
  Object opresult468 = callmethod(opresult465, "++", 1, params);
// compilenode returning opresult468
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult470 = callmethod(opresult468, "++", 1, params);
// compilenode returning opresult470
  if (strlit471 == NULL) {
    strlit471 = alloc_String("_");
  }
// compilenode returning strlit471
  params[0] = strlit471;
  Object opresult473 = callmethod(opresult470, "++", 1, params);
// compilenode returning opresult473
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult475 = callmethod(opresult473, "++", 1, params);
// compilenode returning opresult475
// Begin line 165
  setline(165);
  if (strlit476 == NULL) {
    strlit476 = alloc_String("_");
  }
// compilenode returning strlit476
  params[0] = strlit476;
  Object opresult478 = callmethod(opresult475, "++", 1, params);
// compilenode returning opresult478
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult480 = callmethod(opresult478, "++", 1, params);
// compilenode returning opresult480
// Begin line 166
  setline(166);
  if (strlit481 == NULL) {
    strlit481 = alloc_String("""\x22""))");
  }
// compilenode returning strlit481
  params[0] = strlit481;
  Object opresult483 = callmethod(opresult480, "++", 1, params);
// compilenode returning opresult483
// Begin line 167
  setline(167);
// compilenode returning self
  params[0] = opresult483;
  Object call484 = callmethod(self, "out",
    1, params);
// compilenode returning call484
// Begin line 168
  setline(168);
// Begin line 167
  setline(167);
// compilenode returning *var_nm
  if (strlit485 == NULL) {
    strlit485 = alloc_String(":=");
  }
// compilenode returning strlit485
  params[0] = strlit485;
  Object opresult487 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult487
  var_nmw = alloc_var();
  *var_nmw = opresult487;
  if (opresult487 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 168
  setline(168);
// compilenode returning *var_nmw
  Object call488 = gracelib_length(*var_nmw);
// compilenode returning call488
  Object num489 = alloc_Float64(1.0);
// compilenode returning num489
  params[0] = num489;
  Object sum491 = callmethod(call488, "+", 1, params);
// compilenode returning sum491
  *var_len = sum491;
  if (sum491 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 169
  setline(169);
// Begin line 1429
  setline(1429);
// Begin line 169
  setline(169);
// compilenode returning *var_nmw
  Object call493 = callmethod(*var_nmw, "_escape",
    0, params);
// compilenode returning call493
// compilenode returning call493
  *var_nmw = call493;
  if (call493 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 172
  setline(172);
// Begin line 170
  setline(170);
  if (strlit495 == NULL) {
    strlit495 = alloc_String("@.str.methnamew");
  }
// compilenode returning strlit495
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult497 = callmethod(strlit495, "++", 1, params);
// compilenode returning opresult497
  if (strlit498 == NULL) {
    strlit498 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit498
  params[0] = strlit498;
  Object opresult500 = callmethod(opresult497, "++", 1, params);
// compilenode returning opresult500
// Begin line 171
  setline(171);
  if (strlit501 == NULL) {
    strlit501 = alloc_String("constant [");
  }
// compilenode returning strlit501
  params[0] = strlit501;
  Object opresult503 = callmethod(opresult500, "++", 1, params);
// compilenode returning opresult503
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult505 = callmethod(opresult503, "++", 1, params);
// compilenode returning opresult505
  if (strlit506 == NULL) {
    strlit506 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit506
  params[0] = strlit506;
  Object opresult508 = callmethod(opresult505, "++", 1, params);
// compilenode returning opresult508
// compilenode returning *var_nmw
  params[0] = *var_nmw;
  Object opresult510 = callmethod(opresult508, "++", 1, params);
// compilenode returning opresult510
  if (strlit511 == NULL) {
    strlit511 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit511
  params[0] = strlit511;
  Object opresult513 = callmethod(opresult510, "++", 1, params);
// compilenode returning opresult513
  *var_con = opresult513;
  if (opresult513 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 172
  setline(172);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call515 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call515
// Begin line 175
  setline(175);
// Begin line 173
  setline(173);
  if (strlit516 == NULL) {
    strlit516 = alloc_String("define private %object @""\x22""writer_");
  }
// compilenode returning strlit516
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult518 = callmethod(strlit516, "++", 1, params);
// compilenode returning opresult518
  if (strlit519 == NULL) {
    strlit519 = alloc_String("_");
  }
// compilenode returning strlit519
  params[0] = strlit519;
  Object opresult521 = callmethod(opresult518, "++", 1, params);
// compilenode returning opresult521
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult523 = callmethod(opresult521, "++", 1, params);
// compilenode returning opresult523
  if (strlit524 == NULL) {
    strlit524 = alloc_String("_");
  }
// compilenode returning strlit524
  params[0] = strlit524;
  Object opresult526 = callmethod(opresult523, "++", 1, params);
// compilenode returning opresult526
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult528 = callmethod(opresult526, "++", 1, params);
// compilenode returning opresult528
// Begin line 174
  setline(174);
  if (strlit529 == NULL) {
    strlit529 = alloc_String("""\x22""(%object %self, i32 %nparams, ");
  }
// compilenode returning strlit529
  params[0] = strlit529;
  Object opresult531 = callmethod(opresult528, "++", 1, params);
// compilenode returning opresult531
// Begin line 175
  setline(175);
  if (strlit532 == NULL) {
    strlit532 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit532
  params[0] = strlit532;
  Object opresult534 = callmethod(opresult531, "++", 1, params);
// compilenode returning opresult534
// Begin line 176
  setline(176);
// compilenode returning self
  params[0] = opresult534;
  Object call535 = callmethod(self, "outprint",
    1, params);
// compilenode returning call535
  if (strlit536 == NULL) {
    strlit536 = alloc_String("  %params = getelementptr %object* %args, i32 0");
  }
// compilenode returning strlit536
// Begin line 177
  setline(177);
// compilenode returning self
  params[0] = strlit536;
  Object call537 = callmethod(self, "outprint",
    1, params);
// compilenode returning call537
  if (strlit538 == NULL) {
    strlit538 = alloc_String("  %par0 = load %object* %params");
  }
// compilenode returning strlit538
// Begin line 178
  setline(178);
// compilenode returning self
  params[0] = strlit538;
  Object call539 = callmethod(self, "outprint",
    1, params);
// compilenode returning call539
  if (strlit540 == NULL) {
    strlit540 = alloc_String("  %uo = bitcast %object %self to %UserObject*");
  }
// compilenode returning strlit540
// Begin line 179
  setline(179);
// compilenode returning self
  params[0] = strlit540;
  Object call541 = callmethod(self, "outprint",
    1, params);
// compilenode returning call541
  if (strlit542 == NULL) {
    strlit542 = alloc_String("  %fieldpp = getelementptr %UserObject* %uo, i32 0, i32 3");
  }
// compilenode returning strlit542
// Begin line 180
  setline(180);
// compilenode returning self
  params[0] = strlit542;
  Object call543 = callmethod(self, "outprint",
    1, params);
// compilenode returning call543
  if (strlit544 == NULL) {
    strlit544 = alloc_String("  %fieldpf = getelementptr [0 x %object]* %fieldpp, i32 0, i32 ");
  }
// compilenode returning strlit544
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult546 = callmethod(strlit544, "++", 1, params);
// compilenode returning opresult546
  if (strlit547 == NULL) {
    strlit547 = alloc_String("");
  }
// compilenode returning strlit547
  params[0] = strlit547;
  Object opresult549 = callmethod(opresult546, "++", 1, params);
// compilenode returning opresult549
// Begin line 181
  setline(181);
// compilenode returning self
  params[0] = opresult549;
  Object call550 = callmethod(self, "outprint",
    1, params);
// compilenode returning call550
  if (strlit551 == NULL) {
    strlit551 = alloc_String("  store %object %par0, %object* %fieldpf");
  }
// compilenode returning strlit551
// Begin line 182
  setline(182);
// compilenode returning self
  params[0] = strlit551;
  Object call552 = callmethod(self, "outprint",
    1, params);
// compilenode returning call552
  if (strlit553 == NULL) {
    strlit553 = alloc_String("  %nothing = load %object* @nothing");
  }
// compilenode returning strlit553
// Begin line 183
  setline(183);
// compilenode returning self
  params[0] = strlit553;
  Object call554 = callmethod(self, "outprint",
    1, params);
// compilenode returning call554
  if (strlit555 == NULL) {
    strlit555 = alloc_String("  ret %object %nothing");
  }
// compilenode returning strlit555
// Begin line 184
  setline(184);
// compilenode returning self
  params[0] = strlit555;
  Object call556 = callmethod(self, "outprint",
    1, params);
// compilenode returning call556
  if (strlit557 == NULL) {
    strlit557 = alloc_String("}");
  }
// compilenode returning strlit557
// Begin line 185
  setline(185);
// compilenode returning self
  params[0] = strlit557;
  Object call558 = callmethod(self, "outprint",
    1, params);
// compilenode returning call558
// Begin line 193
  setline(193);
// Begin line 185
  setline(185);
  if (strlit559 == NULL) {
    strlit559 = alloc_String("  call void @addmethod2(%object ");
  }
// compilenode returning strlit559
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult561 = callmethod(strlit559, "++", 1, params);
// compilenode returning opresult561
// Begin line 186
  setline(186);
  if (strlit562 == NULL) {
    strlit562 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit562
  params[0] = strlit562;
  Object opresult564 = callmethod(opresult561, "++", 1, params);
// compilenode returning opresult564
// Begin line 187
  setline(187);
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult566 = callmethod(opresult564, "++", 1, params);
// compilenode returning opresult566
  if (strlit567 == NULL) {
    strlit567 = alloc_String(" x i8]* @.str.methnamew");
  }
// compilenode returning strlit567
  params[0] = strlit567;
  Object opresult569 = callmethod(opresult566, "++", 1, params);
// compilenode returning opresult569
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult571 = callmethod(opresult569, "++", 1, params);
// compilenode returning opresult571
  if (strlit572 == NULL) {
    strlit572 = alloc_String(", i32 0, i32 0), ");
  }
// compilenode returning strlit572
  params[0] = strlit572;
  Object opresult574 = callmethod(opresult571, "++", 1, params);
// compilenode returning opresult574
// Begin line 188
  setline(188);
  if (strlit575 == NULL) {
    strlit575 = alloc_String("%object(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit575
  params[0] = strlit575;
  Object opresult577 = callmethod(opresult574, "++", 1, params);
// compilenode returning opresult577
// Begin line 189
  setline(189);
  if (strlit578 == NULL) {
    strlit578 = alloc_String("getelementptr(%object ");
  }
// compilenode returning strlit578
  params[0] = strlit578;
  Object opresult580 = callmethod(opresult577, "++", 1, params);
// compilenode returning opresult580
// Begin line 190
  setline(190);
  if (strlit581 == NULL) {
    strlit581 = alloc_String("(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit581
  params[0] = strlit581;
  Object opresult583 = callmethod(opresult580, "++", 1, params);
// compilenode returning opresult583
// Begin line 191
  setline(191);
  if (strlit584 == NULL) {
    strlit584 = alloc_String("@""\x22""writer_");
  }
// compilenode returning strlit584
  params[0] = strlit584;
  Object opresult586 = callmethod(opresult583, "++", 1, params);
// compilenode returning opresult586
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult588 = callmethod(opresult586, "++", 1, params);
// compilenode returning opresult588
  if (strlit589 == NULL) {
    strlit589 = alloc_String("_");
  }
// compilenode returning strlit589
  params[0] = strlit589;
  Object opresult591 = callmethod(opresult588, "++", 1, params);
// compilenode returning opresult591
// compilenode returning *var_enm
  params[0] = *var_enm;
  Object opresult593 = callmethod(opresult591, "++", 1, params);
// compilenode returning opresult593
// Begin line 192
  setline(192);
  if (strlit594 == NULL) {
    strlit594 = alloc_String("_");
  }
// compilenode returning strlit594
  params[0] = strlit594;
  Object opresult596 = callmethod(opresult593, "++", 1, params);
// compilenode returning opresult596
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult598 = callmethod(opresult596, "++", 1, params);
// compilenode returning opresult598
// Begin line 193
  setline(193);
  if (strlit599 == NULL) {
    strlit599 = alloc_String("""\x22""))");
  }
// compilenode returning strlit599
  params[0] = strlit599;
  Object opresult601 = callmethod(opresult598, "++", 1, params);
// compilenode returning opresult601
// Begin line 194
  setline(194);
// compilenode returning self
  params[0] = opresult601;
  Object call602 = callmethod(self, "out",
    1, params);
// compilenode returning call602
  return call602;
}
Object meth_genllvm29_compileclass603(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[4];
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_mbody = alloc_var();
  *var_mbody = undefined;
  Object *var_newmeth = alloc_var();
  *var_newmeth = undefined;
  Object *var_obody = alloc_var();
  *var_obody = undefined;
  Object *var_cobj = alloc_var();
  *var_cobj = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 197
  setline(197);
// Begin line 1429
  setline(1429);
// Begin line 196
  setline(196);
// compilenode returning *var_o
  Object call604 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call604
// compilenode returning call604
  var_params = alloc_var();
  *var_params = call604;
  if (call604 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 197
  setline(197);
  Object array605 = alloc_List();
// Begin line 1429
  setline(1429);
// Begin line 197
  setline(197);
// compilenode returning *var_o
  Object call606 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call606
// compilenode returning call606
// Begin line 1429
  setline(1429);
// Begin line 197
  setline(197);
// compilenode returning *var_o
  Object call607 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call607
// compilenode returning call607
// compilenode returning module_ast
  params[0] = call606;
  params[1] = call607;
  Object call608 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call608
  params[0] = call608;
  callmethod(array605, "push", 1, params);
// compilenode returning array605
  var_mbody = alloc_var();
  *var_mbody = array605;
  if (array605 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 199
  setline(199);
// Begin line 198
  setline(198);
  if (strlit609 == NULL) {
    strlit609 = alloc_String("new");
  }
// compilenode returning strlit609
  Object bool610 = alloc_Boolean(0);
// compilenode returning bool610
// compilenode returning module_ast
  params[0] = strlit609;
  params[1] = bool610;
  Object call611 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call611
// compilenode returning *var_params
// compilenode returning *var_mbody
// Begin line 199
  setline(199);
  Object bool612 = alloc_Boolean(0);
// compilenode returning bool612
// Begin line 198
  setline(198);
// compilenode returning module_ast
  params[0] = call611;
  params[1] = *var_params;
  params[2] = *var_mbody;
  params[3] = bool612;
  Object call613 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call613
  var_newmeth = alloc_var();
  *var_newmeth = call613;
  if (call613 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 200
  setline(200);
  Object array614 = alloc_List();
// compilenode returning *var_newmeth
  params[0] = *var_newmeth;
  callmethod(array614, "push", 1, params);
// compilenode returning array614
  var_obody = alloc_var();
  *var_obody = array614;
  if (array614 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 201
  setline(201);
// compilenode returning *var_obody
  Object bool615 = alloc_Boolean(0);
// compilenode returning bool615
// compilenode returning module_ast
  params[0] = *var_obody;
  params[1] = bool615;
  Object call616 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call616
  var_cobj = alloc_var();
  *var_cobj = call616;
  if (call616 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 202
  setline(202);
// Begin line 1429
  setline(1429);
// Begin line 202
  setline(202);
// compilenode returning *var_o
  Object call617 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call617
// compilenode returning call617
// compilenode returning *var_cobj
  Object bool618 = alloc_Boolean(0);
// compilenode returning bool618
// compilenode returning module_ast
  params[0] = call617;
  params[1] = *var_cobj;
  params[2] = bool618;
  Object call619 = callmethod(module_ast, "astdefdec",
    3, params);
// compilenode returning call619
  var_con = alloc_var();
  *var_con = call619;
  if (call619 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 203
  setline(203);
// Begin line 1429
  setline(1429);
// Begin line 203
  setline(203);
// compilenode returning *var_con
// Begin line 204
  setline(204);
// compilenode returning self
  params[0] = *var_con;
  Object call620 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call620
// Begin line 203
  setline(203);
// compilenode returning *var_o
  params[0] = call620;
  Object call621 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call621
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply640(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object *var_numMethods = closure[0];
  Object *var_numFields = closure[1];
  Object self = *closure[2];
// Begin line 217
  setline(217);
// Begin line 218
  setline(218);
// Begin line 1429
  setline(1429);
// Begin line 215
  setline(215);
// compilenode returning *var_e
  Object call642 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call642
// compilenode returning call642
  if (strlit643 == NULL) {
    strlit643 = alloc_String("vardec");
  }
// compilenode returning strlit643
  params[0] = strlit643;
  Object opresult645 = callmethod(call642, "==", 1, params);
// compilenode returning opresult645
  Object if641;
  if (istrue(opresult645)) {
// Begin line 217
  setline(217);
// Begin line 216
  setline(216);
// compilenode returning *var_numMethods
  Object num646 = alloc_Float64(1.0);
// compilenode returning num646
  params[0] = num646;
  Object sum648 = callmethod(*var_numMethods, "+", 1, params);
// compilenode returning sum648
  *var_numMethods = sum648;
  if (sum648 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if641 = nothing;
  } else {
  }
// compilenode returning if641
// Begin line 219
  setline(219);
// Begin line 218
  setline(218);
// compilenode returning *var_numMethods
  Object num650 = alloc_Float64(1.0);
// compilenode returning num650
  params[0] = num650;
  Object sum652 = callmethod(*var_numMethods, "+", 1, params);
// compilenode returning sum652
  *var_numMethods = sum652;
  if (sum652 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 220
  setline(220);
// Begin line 219
  setline(219);
// compilenode returning *var_numFields
  Object num654 = alloc_Float64(1.0);
// compilenode returning num654
  params[0] = num654;
  Object sum656 = callmethod(*var_numFields, "+", 1, params);
// compilenode returning sum656
  *var_numFields = sum656;
  if (sum656 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply706(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[3];
  Object *var_selfr = closure[0];
  Object *var_pos = closure[1];
  Object self = *closure[2];
// Begin line 234
  setline(234);
// Begin line 236
  setline(236);
// Begin line 1429
  setline(1429);
// Begin line 233
  setline(233);
// compilenode returning *var_e
  Object call708 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call708
// compilenode returning call708
  if (strlit709 == NULL) {
    strlit709 = alloc_String("method");
  }
// compilenode returning strlit709
  params[0] = strlit709;
  Object opresult711 = callmethod(call708, "==", 1, params);
// compilenode returning opresult711
  Object if707;
  if (istrue(opresult711)) {
// Begin line 234
  setline(234);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 235
  setline(235);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call712 = callmethod(self, "compilemethod",
    3, params);
// compilenode returning call712
    if707 = call712;
  } else {
  }
// compilenode returning if707
// Begin line 237
  setline(237);
// Begin line 239
  setline(239);
// Begin line 1429
  setline(1429);
// Begin line 236
  setline(236);
// compilenode returning *var_e
  Object call714 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call714
// compilenode returning call714
  if (strlit715 == NULL) {
    strlit715 = alloc_String("vardec");
  }
// compilenode returning strlit715
  params[0] = strlit715;
  Object opresult717 = callmethod(call714, "==", 1, params);
// compilenode returning opresult717
  Object if713;
  if (istrue(opresult717)) {
// Begin line 237
  setline(237);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 238
  setline(238);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call718 = callmethod(self, "compileobjvardec",
    3, params);
// compilenode returning call718
    if713 = call718;
  } else {
  }
// compilenode returning if713
// Begin line 240
  setline(240);
// Begin line 242
  setline(242);
// Begin line 1429
  setline(1429);
// Begin line 239
  setline(239);
// compilenode returning *var_e
  Object call720 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call720
// compilenode returning call720
  if (strlit721 == NULL) {
    strlit721 = alloc_String("defdec");
  }
// compilenode returning strlit721
  params[0] = strlit721;
  Object opresult723 = callmethod(call720, "==", 1, params);
// compilenode returning opresult723
  Object if719;
  if (istrue(opresult723)) {
// Begin line 240
  setline(240);
// compilenode returning *var_e
// compilenode returning *var_selfr
// compilenode returning *var_pos
// Begin line 241
  setline(241);
// compilenode returning self
  params[0] = *var_e;
  params[1] = *var_selfr;
  params[2] = *var_pos;
  Object call724 = callmethod(self, "compileobjdefdec",
    3, params);
// compilenode returning call724
    if719 = call724;
  } else {
  }
// compilenode returning if719
// Begin line 243
  setline(243);
// Begin line 242
  setline(242);
// compilenode returning *var_pos
  Object num725 = alloc_Float64(1.0);
// compilenode returning num725
  params[0] = num725;
  Object sum727 = callmethod(*var_pos, "+", 1, params);
// compilenode returning sum727
  *var_pos = sum727;
  if (sum727 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply733(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_selfr = closure[0];
  Object *var_o = closure[1];
  Object self = *closure[2];
// Begin line 246
  setline(246);
// Begin line 245
  setline(245);
  if (strlit734 == NULL) {
    strlit734 = alloc_String("  call void @set_type(%object ");
  }
// compilenode returning strlit734
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult736 = callmethod(strlit734, "++", 1, params);
// compilenode returning opresult736
  if (strlit737 == NULL) {
    strlit737 = alloc_String(", ");
  }
// compilenode returning strlit737
  params[0] = strlit737;
  Object opresult739 = callmethod(opresult736, "++", 1, params);
// compilenode returning opresult739
// Begin line 246
  setline(246);
  if (strlit740 == NULL) {
    strlit740 = alloc_String("i16 ");
  }
// compilenode returning strlit740
// Begin line 1429
  setline(1429);
// Begin line 246
  setline(246);
// compilenode returning *var_o
  Object call741 = callmethod(*var_o, "otype",
    0, params);
// compilenode returning call741
// compilenode returning call741
// compilenode returning module_subtype
  params[0] = call741;
  Object call742 = callmethod(module_subtype, "typeId",
    1, params);
// compilenode returning call742
  params[0] = call742;
  Object opresult744 = callmethod(strlit740, "++", 1, params);
// compilenode returning opresult744
  if (strlit745 == NULL) {
    strlit745 = alloc_String(")");
  }
// compilenode returning strlit745
  params[0] = strlit745;
  Object opresult747 = callmethod(opresult744, "++", 1, params);
// compilenode returning opresult747
  params[0] = opresult747;
  Object opresult749 = callmethod(opresult739, "++", 1, params);
// compilenode returning opresult749
// Begin line 247
  setline(247);
// compilenode returning self
  params[0] = opresult749;
  Object call750 = callmethod(self, "out",
    1, params);
// compilenode returning call750
  return call750;
}
Object meth_genllvm29_apply755(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
  return nothing;
}
Object meth_genllvm29_compileobject622(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_selfr = alloc_var();
  *var_selfr = undefined;
  Object *var_numFields = alloc_var();
  *var_numFields = undefined;
  Object *var_numMethods = alloc_var();
  *var_numMethods = undefined;
  Object *var_pos = alloc_var();
  *var_pos = undefined;
// Begin line 207
  setline(207);
// Begin line 206
  setline(206);
// compilenode returning *var_inBlock
  var_origInBlock = alloc_var();
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 208
  setline(208);
// Begin line 207
  setline(207);
  Object bool623 = alloc_Boolean(0);
// compilenode returning bool623
  *var_inBlock = bool623;
  if (bool623 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 209
  setline(209);
// Begin line 208
  setline(208);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 210
  setline(210);
// Begin line 209
  setline(209);
// compilenode returning *var_auto_count
  Object num625 = alloc_Float64(1.0);
// compilenode returning num625
  params[0] = num625;
  Object sum627 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum627
  *var_auto_count = sum627;
  if (sum627 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 211
  setline(211);
// Begin line 210
  setline(210);
  if (strlit629 == NULL) {
    strlit629 = alloc_String("%obj");
  }
// compilenode returning strlit629
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult631 = callmethod(strlit629, "++", 1, params);
// compilenode returning opresult631
  var_selfr = alloc_var();
  *var_selfr = opresult631;
  if (opresult631 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 212
  setline(212);
// Begin line 211
  setline(211);
  Object num632 = alloc_Float64(1.0);
// compilenode returning num632
  var_numFields = alloc_var();
  *var_numFields = num632;
  if (num632 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 213
  setline(213);
// Begin line 212
  setline(212);
  Object num633 = alloc_Float64(0.0);
// compilenode returning num633
  var_numMethods = alloc_var();
  *var_numMethods = num633;
  if (num633 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 214
  setline(214);
// Begin line 213
  setline(213);
  Object num634 = alloc_Float64(1.0);
// compilenode returning num634
  var_pos = alloc_var();
  *var_pos = num634;
  if (num634 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 220
  setline(220);
// Begin line 221
  setline(221);
// Begin line 1429
  setline(1429);
// Begin line 214
  setline(214);
// compilenode returning *var_o
  Object call636 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call636
// compilenode returning call636
// Begin line 220
  setline(220);
// Begin line 1429
  setline(1429);
  Object obj638 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj638, self, 0);
  addmethod2(obj638, "outer", &reader_genllvm29_outer_639);
  adddatum2(obj638, self, 0);
  block_savedest(obj638);
  Object **closure640 = createclosure(3);
  addtoclosure(closure640, var_numMethods);
  addtoclosure(closure640, var_numFields);
  Object *selfpp658 = alloc_var();
  *selfpp658 = self;
  addtoclosure(closure640, selfpp658);
  struct UserObject *uo640 = (struct UserObject*)obj638;
  uo640->data[1] = (Object)closure640;
  addmethod2(obj638, "apply", &meth_genllvm29_apply640);
  set_type(obj638, 0);
// compilenode returning obj638
  setclassname(obj638, "Block<genllvm29:637>");
// compilenode returning obj638
  params[0] = call636;
  Object iter635 = callmethod(call636, "iter", 1, params);
  while(1) {
    Object cond635 = callmethod(iter635, "havemore", 0, NULL);
    if (!istrue(cond635)) break;
    params[0] = callmethod(iter635, "next", 0, NULL);
    callmethod(obj638, "apply", 1, params);
  }
// compilenode returning call636
// Begin line 223
  setline(223);
// Begin line 224
  setline(224);
// Begin line 221
  setline(221);
// compilenode returning *var_numFields
  Object num660 = alloc_Float64(3.0);
// compilenode returning num660
  params[0] = num660;
  Object opresult662 = callmethod(*var_numFields, "==", 1, params);
// compilenode returning opresult662
  Object if659;
  if (istrue(opresult662)) {
// Begin line 223
  setline(223);
// Begin line 222
  setline(222);
  Object num663 = alloc_Float64(4.0);
// compilenode returning num663
  *var_numFields = num663;
  if (num663 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if659 = nothing;
  } else {
  }
// compilenode returning if659
// Begin line 228
  setline(228);
// Begin line 230
  setline(230);
// Begin line 1429
  setline(1429);
// Begin line 224
  setline(224);
// compilenode returning *var_o
  Object call666 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call666
// compilenode returning call666
  Object bool667 = alloc_Boolean(0);
// compilenode returning bool667
  params[0] = bool667;
  Object opresult669 = callmethod(call666, "/=", 1, params);
// compilenode returning opresult669
  Object if665;
  if (istrue(opresult669)) {
// Begin line 225
  setline(225);
// Begin line 1429
  setline(1429);
// Begin line 225
  setline(225);
// compilenode returning *var_o
  Object call670 = callmethod(*var_o, "superclass",
    0, params);
// compilenode returning call670
// compilenode returning call670
// Begin line 226
  setline(226);
// compilenode returning self
  params[0] = call670;
  Object call671 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call671
  *var_selfr = call671;
  if (call671 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if665 = nothing;
  } else {
// Begin line 228
  setline(228);
// Begin line 227
  setline(227);
  if (strlit673 == NULL) {
    strlit673 = alloc_String("  ");
  }
// compilenode returning strlit673
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult675 = callmethod(strlit673, "++", 1, params);
// compilenode returning opresult675
// Begin line 228
  setline(228);
// Begin line 227
  setline(227);
  if (strlit676 == NULL) {
    strlit676 = alloc_String(" = call %object @alloc_obj2(i32 ");
  }
// compilenode returning strlit676
// compilenode returning *var_numMethods
  params[0] = *var_numMethods;
  Object opresult678 = callmethod(strlit676, "++", 1, params);
// compilenode returning opresult678
  if (strlit679 == NULL) {
    strlit679 = alloc_String(",");
  }
// compilenode returning strlit679
  params[0] = strlit679;
  Object opresult681 = callmethod(opresult678, "++", 1, params);
// compilenode returning opresult681
  params[0] = opresult681;
  Object opresult683 = callmethod(opresult675, "++", 1, params);
// compilenode returning opresult683
// Begin line 228
  setline(228);
  if (strlit684 == NULL) {
    strlit684 = alloc_String("i32 ");
  }
// compilenode returning strlit684
// compilenode returning *var_numFields
  params[0] = *var_numFields;
  Object opresult686 = callmethod(strlit684, "++", 1, params);
// compilenode returning opresult686
  if (strlit687 == NULL) {
    strlit687 = alloc_String(")");
  }
// compilenode returning strlit687
  params[0] = strlit687;
  Object opresult689 = callmethod(opresult686, "++", 1, params);
// compilenode returning opresult689
  params[0] = opresult689;
  Object opresult691 = callmethod(opresult683, "++", 1, params);
// compilenode returning opresult691
// Begin line 229
  setline(229);
// compilenode returning self
  params[0] = opresult691;
  Object call692 = callmethod(self, "out",
    1, params);
// compilenode returning call692
    if665 = call692;
  }
// compilenode returning if665
// Begin line 230
  setline(230);
// compilenode returning *var_selfr
// Begin line 231
  setline(231);
// compilenode returning self
  params[0] = *var_selfr;
  Object call693 = callmethod(self, "compileobjouter",
    1, params);
// compilenode returning call693
  if (strlit694 == NULL) {
    strlit694 = alloc_String("  call void @adddatum2(%object ");
  }
// compilenode returning strlit694
// compilenode returning *var_selfr
  params[0] = *var_selfr;
  Object opresult696 = callmethod(strlit694, "++", 1, params);
// compilenode returning opresult696
  if (strlit697 == NULL) {
    strlit697 = alloc_String(", %object %self, i32 0)");
  }
// compilenode returning strlit697
  params[0] = strlit697;
  Object opresult699 = callmethod(opresult696, "++", 1, params);
// compilenode returning opresult699
// Begin line 232
  setline(232);
// compilenode returning self
  params[0] = opresult699;
  Object call700 = callmethod(self, "out",
    1, params);
// compilenode returning call700
// Begin line 243
  setline(243);
// Begin line 244
  setline(244);
// Begin line 1429
  setline(1429);
// Begin line 232
  setline(232);
// compilenode returning *var_o
  Object call702 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call702
// compilenode returning call702
// Begin line 243
  setline(243);
// Begin line 1429
  setline(1429);
  Object obj704 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj704, self, 0);
  addmethod2(obj704, "outer", &reader_genllvm29_outer_705);
  adddatum2(obj704, self, 0);
  block_savedest(obj704);
  Object **closure706 = createclosure(3);
  addtoclosure(closure706, var_selfr);
  addtoclosure(closure706, var_pos);
  Object *selfpp729 = alloc_var();
  *selfpp729 = self;
  addtoclosure(closure706, selfpp729);
  struct UserObject *uo706 = (struct UserObject*)obj704;
  uo706->data[1] = (Object)closure706;
  addmethod2(obj704, "apply", &meth_genllvm29_apply706);
  set_type(obj704, 0);
// compilenode returning obj704
  setclassname(obj704, "Block<genllvm29:703>");
// compilenode returning obj704
  params[0] = call702;
  Object iter701 = callmethod(call702, "iter", 1, params);
  while(1) {
    Object cond701 = callmethod(iter701, "havemore", 0, NULL);
    if (!istrue(cond701)) break;
    params[0] = callmethod(iter701, "next", 0, NULL);
    callmethod(obj704, "apply", 1, params);
  }
// compilenode returning call702
// Begin line 248
  setline(248);
// Begin line 246
  setline(246);
// Begin line 1429
  setline(1429);
  Object obj731 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj731, self, 0);
  addmethod2(obj731, "outer", &reader_genllvm29_outer_732);
  adddatum2(obj731, self, 0);
  block_savedest(obj731);
  Object **closure733 = createclosure(3);
  addtoclosure(closure733, var_selfr);
  addtoclosure(closure733, var_o);
  Object *selfpp751 = alloc_var();
  *selfpp751 = self;
  addtoclosure(closure733, selfpp751);
  struct UserObject *uo733 = (struct UserObject*)obj731;
  uo733->data[1] = (Object)closure733;
  addmethod2(obj731, "apply", &meth_genllvm29_apply733);
  set_type(obj731, 0);
// compilenode returning obj731
  setclassname(obj731, "Block<genllvm29:730>");
// compilenode returning obj731
// Begin line 248
  setline(248);
// Begin line 1429
  setline(1429);
  Object obj753 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj753, self, 0);
  addmethod2(obj753, "outer", &reader_genllvm29_outer_754);
  adddatum2(obj753, self, 0);
  block_savedest(obj753);
  Object **closure755 = createclosure(1);
  Object *selfpp756 = alloc_var();
  *selfpp756 = self;
  addtoclosure(closure755, selfpp756);
  struct UserObject *uo755 = (struct UserObject*)obj753;
  uo755->data[1] = (Object)closure755;
  addmethod2(obj753, "apply", &meth_genllvm29_apply755);
  set_type(obj753, 0);
// compilenode returning obj753
  setclassname(obj753, "Block<genllvm29:752>");
// compilenode returning obj753
// Begin line 244
  setline(244);
// compilenode returning module_util
  params[0] = obj731;
  params[1] = obj753;
  Object call757 = callmethod(module_util, "runOnNew(1)else",
    2, params);
// compilenode returning call757
// Begin line 249
  setline(249);
// Begin line 1429
  setline(1429);
// Begin line 248
  setline(248);
// compilenode returning *var_selfr
// compilenode returning *var_o
  params[0] = *var_selfr;
  Object call758 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call758
// compilenode returning nothing
// Begin line 250
  setline(250);
// Begin line 249
  setline(249);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileblock760(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[4];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_modname = closure[2];
  Object *var_constants = closure[3];
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_applymeth = alloc_var();
  *var_applymeth = undefined;
  Object *var_objbody = alloc_var();
  *var_objbody = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
  Object *var_modn = alloc_var();
  *var_modn = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 253
  setline(253);
// Begin line 252
  setline(252);
// compilenode returning *var_inBlock
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 254
  setline(254);
// Begin line 253
  setline(253);
  Object bool761 = alloc_Boolean(1);
// compilenode returning bool761
  *var_inBlock = bool761;
  if (bool761 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 255
  setline(255);
// Begin line 254
  setline(254);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 256
  setline(256);
// Begin line 255
  setline(255);
// compilenode returning *var_auto_count
  Object num763 = alloc_Float64(1.0);
// compilenode returning num763
  params[0] = num763;
  Object sum765 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum765
  *var_auto_count = sum765;
  if (sum765 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 257
  setline(257);
// Begin line 256
  setline(256);
  if (strlit767 == NULL) {
    strlit767 = alloc_String("apply");
  }
// compilenode returning strlit767
  Object bool768 = alloc_Boolean(0);
// compilenode returning bool768
// compilenode returning module_ast
  params[0] = strlit767;
  params[1] = bool768;
  Object call769 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call769
// Begin line 257
  setline(257);
// Begin line 1429
  setline(1429);
// Begin line 257
  setline(257);
// compilenode returning *var_o
  Object call770 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call770
// compilenode returning call770
// Begin line 1429
  setline(1429);
// Begin line 257
  setline(257);
// compilenode returning *var_o
  Object call771 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call771
// compilenode returning call771
  Object bool772 = alloc_Boolean(0);
// compilenode returning bool772
// Begin line 256
  setline(256);
// compilenode returning module_ast
  params[0] = call769;
  params[1] = call770;
  params[2] = call771;
  params[3] = bool772;
  Object call773 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call773
  var_applymeth = alloc_var();
  *var_applymeth = call773;
  if (call773 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 259
  setline(259);
// Begin line 1429
  setline(1429);
// Begin line 258
  setline(258);
  Object bool774 = alloc_Boolean(1);
// compilenode returning bool774
// compilenode returning *var_applymeth
  params[0] = bool774;
  Object call775 = callmethod(*var_applymeth, "selfclosure:=",
    1, params);
// compilenode returning call775
// compilenode returning nothing
// Begin line 259
  setline(259);
  Object array776 = alloc_List();
// compilenode returning *var_applymeth
  params[0] = *var_applymeth;
  callmethod(array776, "push", 1, params);
// compilenode returning array776
  Object bool777 = alloc_Boolean(0);
// compilenode returning bool777
// compilenode returning module_ast
  params[0] = array776;
  params[1] = bool777;
  Object call778 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call778
  var_objbody = alloc_var();
  *var_objbody = call778;
  if (call778 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 260
  setline(260);
// compilenode returning *var_objbody
// Begin line 261
  setline(261);
// compilenode returning self
  params[0] = *var_objbody;
  Object call779 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call779
  var_obj = alloc_var();
  *var_obj = call779;
  if (call779 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 262
  setline(262);
// Begin line 261
  setline(261);
  if (strlit780 == NULL) {
    strlit780 = alloc_String("Block<");
  }
// compilenode returning strlit780
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult782 = callmethod(strlit780, "++", 1, params);
// compilenode returning opresult782
  if (strlit783 == NULL) {
    strlit783 = alloc_String(":");
  }
// compilenode returning strlit783
  params[0] = strlit783;
  Object opresult785 = callmethod(opresult782, "++", 1, params);
// compilenode returning opresult785
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult787 = callmethod(opresult785, "++", 1, params);
// compilenode returning opresult787
  if (strlit788 == NULL) {
    strlit788 = alloc_String(">");
  }
// compilenode returning strlit788
  params[0] = strlit788;
  Object opresult790 = callmethod(opresult787, "++", 1, params);
// compilenode returning opresult790
  var_modn = alloc_var();
  *var_modn = opresult790;
  if (opresult790 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// Begin line 262
  setline(262);
  if (strlit791 == NULL) {
    strlit791 = alloc_String("@.str.block");
  }
// compilenode returning strlit791
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult793 = callmethod(strlit791, "++", 1, params);
// compilenode returning opresult793
  if (strlit794 == NULL) {
    strlit794 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit794
  params[0] = strlit794;
  Object opresult796 = callmethod(opresult793, "++", 1, params);
// compilenode returning opresult796
// Begin line 264
  setline(264);
// Begin line 263
  setline(263);
  if (strlit797 == NULL) {
    strlit797 = alloc_String("constant [");
  }
// compilenode returning strlit797
// Begin line 264
  setline(264);
// Begin line 1429
  setline(1429);
// Begin line 263
  setline(263);
// compilenode returning *var_modn
  Object call798 = callmethod(*var_modn, "size",
    0, params);
// compilenode returning call798
// compilenode returning call798
  Object num799 = alloc_Float64(1.0);
// compilenode returning num799
  params[0] = num799;
  Object sum801 = callmethod(call798, "+", 1, params);
// compilenode returning sum801
  params[0] = sum801;
  Object opresult803 = callmethod(strlit797, "++", 1, params);
// compilenode returning opresult803
  if (strlit804 == NULL) {
    strlit804 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit804
  params[0] = strlit804;
  Object opresult806 = callmethod(opresult803, "++", 1, params);
// compilenode returning opresult806
// compilenode returning *var_modn
  params[0] = *var_modn;
  Object opresult808 = callmethod(opresult806, "++", 1, params);
// compilenode returning opresult808
  if (strlit809 == NULL) {
    strlit809 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit809
  params[0] = strlit809;
  Object opresult811 = callmethod(opresult808, "++", 1, params);
// compilenode returning opresult811
  params[0] = opresult811;
  Object opresult813 = callmethod(opresult796, "++", 1, params);
// compilenode returning opresult813
  var_con = alloc_var();
  *var_con = opresult813;
  if (opresult813 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call814 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call814
// Begin line 267
  setline(267);
// Begin line 265
  setline(265);
  if (strlit815 == NULL) {
    strlit815 = alloc_String("  call void @setclassname(%object ");
  }
// compilenode returning strlit815
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult817 = callmethod(strlit815, "++", 1, params);
// compilenode returning opresult817
  if (strlit818 == NULL) {
    strlit818 = alloc_String(", ");
  }
// compilenode returning strlit818
  params[0] = strlit818;
  Object opresult820 = callmethod(opresult817, "++", 1, params);
// compilenode returning opresult820
// Begin line 267
  setline(267);
// Begin line 266
  setline(266);
  if (strlit821 == NULL) {
    strlit821 = alloc_String("i8* getelementptr([");
  }
// compilenode returning strlit821
// Begin line 267
  setline(267);
// Begin line 1429
  setline(1429);
// Begin line 266
  setline(266);
// compilenode returning *var_modn
  Object call822 = callmethod(*var_modn, "size",
    0, params);
// compilenode returning call822
// compilenode returning call822
  Object num823 = alloc_Float64(1.0);
// compilenode returning num823
  params[0] = num823;
  Object sum825 = callmethod(call822, "+", 1, params);
// compilenode returning sum825
  params[0] = sum825;
  Object opresult827 = callmethod(strlit821, "++", 1, params);
// compilenode returning opresult827
  if (strlit828 == NULL) {
    strlit828 = alloc_String(" x i8]* @.str.block");
  }
// compilenode returning strlit828
  params[0] = strlit828;
  Object opresult830 = callmethod(opresult827, "++", 1, params);
// compilenode returning opresult830
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult832 = callmethod(opresult830, "++", 1, params);
// compilenode returning opresult832
  if (strlit833 == NULL) {
    strlit833 = alloc_String(",");
  }
// compilenode returning strlit833
  params[0] = strlit833;
  Object opresult835 = callmethod(opresult832, "++", 1, params);
// compilenode returning opresult835
  params[0] = opresult835;
  Object opresult837 = callmethod(opresult820, "++", 1, params);
// compilenode returning opresult837
// Begin line 267
  setline(267);
  if (strlit838 == NULL) {
    strlit838 = alloc_String("i32 0,i32 0))");
  }
// compilenode returning strlit838
  params[0] = strlit838;
  Object opresult840 = callmethod(opresult837, "++", 1, params);
// compilenode returning opresult840
// Begin line 268
  setline(268);
// compilenode returning self
  params[0] = opresult840;
  Object call841 = callmethod(self, "out",
    1, params);
// compilenode returning call841
// Begin line 269
  setline(269);
// Begin line 1429
  setline(1429);
// Begin line 268
  setline(268);
// compilenode returning *var_obj
// compilenode returning *var_o
  params[0] = *var_obj;
  Object call842 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call842
// compilenode returning nothing
// Begin line 270
  setline(270);
// Begin line 269
  setline(269);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilefor844(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_bblock = closure[1];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_over = alloc_var();
  *var_over = undefined;
  Object *var_blk = alloc_var();
  *var_blk = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
  Object *var_creg = alloc_var();
  *var_creg = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
  Object *var_tblock = alloc_var();
  *var_tblock = undefined;
// Begin line 273
  setline(273);
// Begin line 272
  setline(272);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 274
  setline(274);
// Begin line 273
  setline(273);
// compilenode returning *var_auto_count
  Object num845 = alloc_Float64(1.0);
// compilenode returning num845
  params[0] = num845;
  Object sum847 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum847
  *var_auto_count = sum847;
  if (sum847 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 274
  setline(274);
// Begin line 1429
  setline(1429);
// Begin line 274
  setline(274);
// compilenode returning *var_o
  Object call849 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call849
// compilenode returning call849
// Begin line 275
  setline(275);
// compilenode returning self
  params[0] = call849;
  Object call850 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call850
  var_over = alloc_var();
  *var_over = call850;
  if (call850 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 276
  setline(276);
// Begin line 1429
  setline(1429);
// Begin line 275
  setline(275);
// compilenode returning *var_o
  Object call851 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call851
// compilenode returning call851
  var_blk = alloc_var();
  *var_blk = call851;
  if (call851 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 276
  setline(276);
// compilenode returning *var_blk
// Begin line 277
  setline(277);
// compilenode returning self
  params[0] = *var_blk;
  Object call852 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call852
  var_obj = alloc_var();
  *var_obj = call852;
  if (call852 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit853 == NULL) {
    strlit853 = alloc_String("  store %object ");
  }
// compilenode returning strlit853
// compilenode returning *var_over
  params[0] = *var_over;
  Object opresult855 = callmethod(strlit853, "++", 1, params);
// compilenode returning opresult855
  if (strlit856 == NULL) {
    strlit856 = alloc_String(", %object* %params_0");
  }
// compilenode returning strlit856
  params[0] = strlit856;
  Object opresult858 = callmethod(opresult855, "++", 1, params);
// compilenode returning opresult858
// Begin line 278
  setline(278);
// compilenode returning self
  params[0] = opresult858;
  Object call859 = callmethod(self, "out",
    1, params);
// compilenode returning call859
// Begin line 280
  setline(280);
// Begin line 278
  setline(278);
  if (strlit860 == NULL) {
    strlit860 = alloc_String("  %iter");
  }
// compilenode returning strlit860
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult862 = callmethod(strlit860, "++", 1, params);
// compilenode returning opresult862
  if (strlit863 == NULL) {
    strlit863 = alloc_String(" = call %object @callmethod(%object ");
  }
// compilenode returning strlit863
  params[0] = strlit863;
  Object opresult865 = callmethod(opresult862, "++", 1, params);
// compilenode returning opresult865
// compilenode returning *var_over
  params[0] = *var_over;
  Object opresult867 = callmethod(opresult865, "++", 1, params);
// compilenode returning opresult867
// Begin line 279
  setline(279);
  if (strlit868 == NULL) {
    strlit868 = alloc_String(", i8* getelementptr([5 x i8]* @.str._iter");
  }
// compilenode returning strlit868
  params[0] = strlit868;
  Object opresult870 = callmethod(opresult867, "++", 1, params);
// compilenode returning opresult870
// Begin line 280
  setline(280);
  if (strlit871 == NULL) {
    strlit871 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit871
  params[0] = strlit871;
  Object opresult873 = callmethod(opresult870, "++", 1, params);
// compilenode returning opresult873
// Begin line 282
  setline(282);
// compilenode returning self
  params[0] = opresult873;
  Object call874 = callmethod(self, "out",
    1, params);
// compilenode returning call874
  if (strlit875 == NULL) {
    strlit875 = alloc_String("  br label %BeginFor");
  }
// compilenode returning strlit875
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult877 = callmethod(strlit875, "++", 1, params);
// compilenode returning opresult877
// Begin line 283
  setline(283);
// compilenode returning self
  params[0] = opresult877;
  Object call878 = callmethod(self, "out",
    1, params);
// compilenode returning call878
  if (strlit879 == NULL) {
    strlit879 = alloc_String("BeginFor");
  }
// compilenode returning strlit879
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult881 = callmethod(strlit879, "++", 1, params);
// compilenode returning opresult881
// Begin line 284
  setline(284);
// compilenode returning self
  params[0] = opresult881;
  Object call882 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call882
// Begin line 287
  setline(287);
// Begin line 284
  setline(284);
  if (strlit883 == NULL) {
    strlit883 = alloc_String("  %condobj");
  }
// compilenode returning strlit883
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult885 = callmethod(strlit883, "++", 1, params);
// compilenode returning opresult885
  if (strlit886 == NULL) {
    strlit886 = alloc_String(" = call %object @callmethod(%object %iter");
  }
// compilenode returning strlit886
  params[0] = strlit886;
  Object opresult888 = callmethod(opresult885, "++", 1, params);
// compilenode returning opresult888
// Begin line 285
  setline(285);
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult890 = callmethod(opresult888, "++", 1, params);
// compilenode returning opresult890
// Begin line 286
  setline(286);
  if (strlit891 == NULL) {
    strlit891 = alloc_String(", i8* getelementptr([9 x i8]* @.str._havemore");
  }
// compilenode returning strlit891
  params[0] = strlit891;
  Object opresult893 = callmethod(opresult890, "++", 1, params);
// compilenode returning opresult893
// Begin line 287
  setline(287);
  if (strlit894 == NULL) {
    strlit894 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit894
  params[0] = strlit894;
  Object opresult896 = callmethod(opresult893, "++", 1, params);
// compilenode returning opresult896
// Begin line 288
  setline(288);
// compilenode returning self
  params[0] = opresult896;
  Object call897 = callmethod(self, "out",
    1, params);
// compilenode returning call897
// Begin line 289
  setline(289);
// Begin line 288
  setline(288);
  if (strlit898 == NULL) {
    strlit898 = alloc_String("%cond");
  }
// compilenode returning strlit898
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult900 = callmethod(strlit898, "++", 1, params);
// compilenode returning opresult900
  var_creg = alloc_var();
  *var_creg = opresult900;
  if (opresult900 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 290
  setline(290);
// Begin line 289
  setline(289);
  if (strlit901 == NULL) {
    strlit901 = alloc_String("  ");
  }
// compilenode returning strlit901
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult903 = callmethod(strlit901, "++", 1, params);
// compilenode returning opresult903
  if (strlit904 == NULL) {
    strlit904 = alloc_String("_valp = call i1 @istrue(%object %condobj");
  }
// compilenode returning strlit904
  params[0] = strlit904;
  Object opresult906 = callmethod(opresult903, "++", 1, params);
// compilenode returning opresult906
// Begin line 290
  setline(290);
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult908 = callmethod(opresult906, "++", 1, params);
// compilenode returning opresult908
  if (strlit909 == NULL) {
    strlit909 = alloc_String(")");
  }
// compilenode returning strlit909
  params[0] = strlit909;
  Object opresult911 = callmethod(opresult908, "++", 1, params);
// compilenode returning opresult911
// Begin line 291
  setline(291);
// compilenode returning self
  params[0] = opresult911;
  Object call912 = callmethod(self, "out",
    1, params);
// compilenode returning call912
  if (strlit913 == NULL) {
    strlit913 = alloc_String("  ");
  }
// compilenode returning strlit913
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult915 = callmethod(strlit913, "++", 1, params);
// compilenode returning opresult915
  if (strlit916 == NULL) {
    strlit916 = alloc_String(" = icmp eq i1 0, ");
  }
// compilenode returning strlit916
  params[0] = strlit916;
  Object opresult918 = callmethod(opresult915, "++", 1, params);
// compilenode returning opresult918
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult920 = callmethod(opresult918, "++", 1, params);
// compilenode returning opresult920
  if (strlit921 == NULL) {
    strlit921 = alloc_String("_valp");
  }
// compilenode returning strlit921
  params[0] = strlit921;
  Object opresult923 = callmethod(opresult920, "++", 1, params);
// compilenode returning opresult923
// Begin line 292
  setline(292);
// compilenode returning self
  params[0] = opresult923;
  Object call924 = callmethod(self, "out",
    1, params);
// compilenode returning call924
// Begin line 293
  setline(293);
// Begin line 292
  setline(292);
  if (strlit925 == NULL) {
    strlit925 = alloc_String("br i1 ");
  }
// compilenode returning strlit925
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult927 = callmethod(strlit925, "++", 1, params);
// compilenode returning opresult927
  if (strlit928 == NULL) {
    strlit928 = alloc_String(", label %EndFor");
  }
// compilenode returning strlit928
  params[0] = strlit928;
  Object opresult930 = callmethod(opresult927, "++", 1, params);
// compilenode returning opresult930
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult932 = callmethod(opresult930, "++", 1, params);
// compilenode returning opresult932
// Begin line 293
  setline(293);
  if (strlit933 == NULL) {
    strlit933 = alloc_String(", label %ForBody");
  }
// compilenode returning strlit933
  params[0] = strlit933;
  Object opresult935 = callmethod(opresult932, "++", 1, params);
// compilenode returning opresult935
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult937 = callmethod(opresult935, "++", 1, params);
// compilenode returning opresult937
// Begin line 294
  setline(294);
// compilenode returning self
  params[0] = opresult937;
  Object call938 = callmethod(self, "out",
    1, params);
// compilenode returning call938
  if (strlit939 == NULL) {
    strlit939 = alloc_String("ForBody");
  }
// compilenode returning strlit939
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult941 = callmethod(strlit939, "++", 1, params);
// compilenode returning opresult941
// Begin line 295
  setline(295);
// compilenode returning self
  params[0] = opresult941;
  Object call942 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call942
// Begin line 296
  setline(296);
// Begin line 295
  setline(295);
  if (strlit943 == NULL) {
    strlit943 = alloc_String("null");
  }
// compilenode returning strlit943
  var_tret = alloc_var();
  *var_tret = strlit943;
  if (strlit943 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 297
  setline(297);
// Begin line 296
  setline(296);
  if (strlit944 == NULL) {
    strlit944 = alloc_String("ERROR");
  }
// compilenode returning strlit944
  var_tblock = alloc_var();
  *var_tblock = strlit944;
  if (strlit944 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 300
  setline(300);
// Begin line 297
  setline(297);
  if (strlit945 == NULL) {
    strlit945 = alloc_String(" %forval");
  }
// compilenode returning strlit945
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult947 = callmethod(strlit945, "++", 1, params);
// compilenode returning opresult947
  if (strlit948 == NULL) {
    strlit948 = alloc_String(" = call %object @callmethod(%object %iter");
  }
// compilenode returning strlit948
  params[0] = strlit948;
  Object opresult950 = callmethod(opresult947, "++", 1, params);
// compilenode returning opresult950
// Begin line 298
  setline(298);
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult952 = callmethod(opresult950, "++", 1, params);
// compilenode returning opresult952
// Begin line 299
  setline(299);
  if (strlit953 == NULL) {
    strlit953 = alloc_String(", i8* getelementptr([5 x i8]* @.str._next");
  }
// compilenode returning strlit953
  params[0] = strlit953;
  Object opresult955 = callmethod(opresult952, "++", 1, params);
// compilenode returning opresult955
// Begin line 300
  setline(300);
  if (strlit956 == NULL) {
    strlit956 = alloc_String(",i32 0,i32 0), i32 0, %object* %params)");
  }
// compilenode returning strlit956
  params[0] = strlit956;
  Object opresult958 = callmethod(opresult955, "++", 1, params);
// compilenode returning opresult958
// Begin line 301
  setline(301);
// compilenode returning self
  params[0] = opresult958;
  Object call959 = callmethod(self, "out",
    1, params);
// compilenode returning call959
  if (strlit960 == NULL) {
    strlit960 = alloc_String("  store %object %forval");
  }
// compilenode returning strlit960
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult962 = callmethod(strlit960, "++", 1, params);
// compilenode returning opresult962
  if (strlit963 == NULL) {
    strlit963 = alloc_String(", %object* %params_0");
  }
// compilenode returning strlit963
  params[0] = strlit963;
  Object opresult965 = callmethod(opresult962, "++", 1, params);
// compilenode returning opresult965
// Begin line 302
  setline(302);
// compilenode returning self
  params[0] = opresult965;
  Object call966 = callmethod(self, "out",
    1, params);
// compilenode returning call966
// Begin line 304
  setline(304);
// Begin line 302
  setline(302);
  if (strlit967 == NULL) {
    strlit967 = alloc_String("  call %object @callmethod(%object ");
  }
// compilenode returning strlit967
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult969 = callmethod(strlit967, "++", 1, params);
// compilenode returning opresult969
// Begin line 303
  setline(303);
  if (strlit970 == NULL) {
    strlit970 = alloc_String(", i8* getelementptr([6 x i8]* @.str._apply");
  }
// compilenode returning strlit970
  params[0] = strlit970;
  Object opresult972 = callmethod(opresult969, "++", 1, params);
// compilenode returning opresult972
// Begin line 304
  setline(304);
  if (strlit973 == NULL) {
    strlit973 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit973
  params[0] = strlit973;
  Object opresult975 = callmethod(opresult972, "++", 1, params);
// compilenode returning opresult975
// Begin line 305
  setline(305);
// compilenode returning self
  params[0] = opresult975;
  Object call976 = callmethod(self, "out",
    1, params);
// compilenode returning call976
// Begin line 306
  setline(306);
// Begin line 305
  setline(305);
// compilenode returning *var_bblock
  *var_tblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 306
  setline(306);
  if (strlit978 == NULL) {
    strlit978 = alloc_String("  br label %BeginFor");
  }
// compilenode returning strlit978
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult980 = callmethod(strlit978, "++", 1, params);
// compilenode returning opresult980
// Begin line 307
  setline(307);
// compilenode returning self
  params[0] = opresult980;
  Object call981 = callmethod(self, "out",
    1, params);
// compilenode returning call981
  if (strlit982 == NULL) {
    strlit982 = alloc_String("EndFor");
  }
// compilenode returning strlit982
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult984 = callmethod(strlit982, "++", 1, params);
// compilenode returning opresult984
// Begin line 308
  setline(308);
// compilenode returning self
  params[0] = opresult984;
  Object call985 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call985
// Begin line 309
  setline(309);
// Begin line 1429
  setline(1429);
// Begin line 308
  setline(308);
// compilenode returning *var_over
// compilenode returning *var_o
  params[0] = *var_over;
  Object call986 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call986
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1061(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 350
  setline(350);
// Begin line 352
  setline(352);
// Begin line 1429
  setline(1429);
// Begin line 345
  setline(345);
// compilenode returning *var_l
  Object call1063 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1063
// compilenode returning call1063
  if (strlit1064 == NULL) {
    strlit1064 = alloc_String("vardec");
  }
// compilenode returning strlit1064
  params[0] = strlit1064;
  Object opresult1066 = callmethod(call1063, "==", 1, params);
// compilenode returning opresult1066
// Begin line 352
  setline(352);
// Begin line 1429
  setline(1429);
// Begin line 345
  setline(345);
// compilenode returning *var_l
  Object call1067 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1067
// compilenode returning call1067
  if (strlit1068 == NULL) {
    strlit1068 = alloc_String("defdec");
  }
// compilenode returning strlit1068
  params[0] = strlit1068;
  Object opresult1070 = callmethod(call1067, "==", 1, params);
// compilenode returning opresult1070
  params[0] = opresult1070;
  Object opresult1072 = callmethod(opresult1066, "|", 1, params);
// compilenode returning opresult1072
// Begin line 352
  setline(352);
// Begin line 1429
  setline(1429);
// Begin line 346
  setline(346);
// compilenode returning *var_l
  Object call1073 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1073
// compilenode returning call1073
  if (strlit1074 == NULL) {
    strlit1074 = alloc_String("class");
  }
// compilenode returning strlit1074
  params[0] = strlit1074;
  Object opresult1076 = callmethod(call1073, "==", 1, params);
// compilenode returning opresult1076
  params[0] = opresult1076;
  Object opresult1078 = callmethod(opresult1072, "|", 1, params);
// compilenode returning opresult1078
  Object if1062;
  if (istrue(opresult1078)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 347
  setline(347);
// Begin line 1429
  setline(1429);
// Begin line 347
  setline(347);
// Begin line 1429
  setline(1429);
// Begin line 347
  setline(347);
// Begin line 1429
  setline(1429);
// Begin line 347
  setline(347);
// compilenode returning *var_l
  Object call1079 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1079
// compilenode returning call1079
  Object call1080 = callmethod(call1079, "value",
    0, params);
// compilenode returning call1080
// compilenode returning call1080
  Object call1081 = callmethod(call1080, "_escape",
    0, params);
// compilenode returning call1081
// compilenode returning call1081
  var_tnm = alloc_var();
  *var_tnm = call1081;
  if (call1081 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 348
  setline(348);
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1082 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1082
// Begin line 349
  setline(349);
  if (strlit1083 == NULL) {
    strlit1083 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1083
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1085 = callmethod(strlit1083, "++", 1, params);
// compilenode returning opresult1085
  if (strlit1086 == NULL) {
    strlit1086 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit1086
  params[0] = strlit1086;
  Object opresult1088 = callmethod(opresult1085, "++", 1, params);
// compilenode returning opresult1088
// Begin line 350
  setline(350);
// compilenode returning self
  params[0] = opresult1088;
  Object call1089 = callmethod(self, "out",
    1, params);
// compilenode returning call1089
  if (strlit1090 == NULL) {
    strlit1090 = alloc_String("  store %object %undefined, %object* %""\x22""var_");
  }
// compilenode returning strlit1090
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1092 = callmethod(strlit1090, "++", 1, params);
// compilenode returning opresult1092
  if (strlit1093 == NULL) {
    strlit1093 = alloc_String("""\x22""");
  }
// compilenode returning strlit1093
  params[0] = strlit1093;
  Object opresult1095 = callmethod(opresult1092, "++", 1, params);
// compilenode returning opresult1095
// Begin line 351
  setline(351);
// compilenode returning self
  params[0] = opresult1095;
  Object call1096 = callmethod(self, "out",
    1, params);
// compilenode returning call1096
    if1062 = call1096;
  } else {
  }
// compilenode returning if1062
  return if1062;
}
Object meth_genllvm29_apply1103(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_ret = closure[0];
  Object self = *closure[1];
// Begin line 354
  setline(354);
// compilenode returning *var_l
// Begin line 355
  setline(355);
// compilenode returning self
  params[0] = *var_l;
  Object call1104 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1104
  *var_ret = call1104;
  if (call1104 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1126(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_d = alloc_var();
  *var_d = args[0];
  Object params[1];
  Object *var_u = closure[0];
  Object *var_decl = closure[1];
  Object self = *closure[2];
// Begin line 366
  setline(366);
// Begin line 367
  setline(367);
// Begin line 364
  setline(364);
// compilenode returning *var_d
// compilenode returning *var_u
  params[0] = *var_u;
  Object opresult1129 = callmethod(*var_d, "==", 1, params);
// compilenode returning opresult1129
  Object if1127;
  if (istrue(opresult1129)) {
// Begin line 366
  setline(366);
// Begin line 365
  setline(365);
  Object bool1130 = alloc_Boolean(1);
// compilenode returning bool1130
  *var_decl = bool1130;
  if (bool1130 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1127 = nothing;
  } else {
  }
// compilenode returning if1127
  return if1127;
}
Object meth_genllvm29_apply1140(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_u = closure[0];
  Object *var_found = closure[1];
  Object self = *closure[2];
// Begin line 375
  setline(375);
// Begin line 376
  setline(376);
// Begin line 373
  setline(373);
// compilenode returning *var_v
// compilenode returning *var_u
  params[0] = *var_u;
  Object opresult1143 = callmethod(*var_v, "==", 1, params);
// compilenode returning opresult1143
  Object if1141;
  if (istrue(opresult1143)) {
// Begin line 375
  setline(375);
// Begin line 374
  setline(374);
  Object bool1144 = alloc_Boolean(1);
// compilenode returning bool1144
  *var_found = bool1144;
  if (bool1144 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1141 = nothing;
  } else {
  }
// compilenode returning if1141
  return if1141;
}
Object meth_genllvm29_apply1120(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_u = alloc_var();
  *var_u = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_closurevars = closure[1];
  Object self = *closure[2];
  Object *var_decl = alloc_var();
  *var_decl = undefined;
// Begin line 363
  setline(363);
// Begin line 362
  setline(362);
  Object bool1121 = alloc_Boolean(0);
// compilenode returning bool1121
  var_decl = alloc_var();
  *var_decl = bool1121;
  if (bool1121 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 366
  setline(366);
// Begin line 363
  setline(363);
// compilenode returning *var_declaredvars
// Begin line 366
  setline(366);
// Begin line 1429
  setline(1429);
  Object obj1124 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1124, self, 0);
  addmethod2(obj1124, "outer", &reader_genllvm29_outer_1125);
  adddatum2(obj1124, self, 0);
  block_savedest(obj1124);
  Object **closure1126 = createclosure(3);
  addtoclosure(closure1126, var_u);
  addtoclosure(closure1126, var_decl);
  Object *selfpp1132 = alloc_var();
  *selfpp1132 = self;
  addtoclosure(closure1126, selfpp1132);
  struct UserObject *uo1126 = (struct UserObject*)obj1124;
  uo1126->data[1] = (Object)closure1126;
  addmethod2(obj1124, "apply", &meth_genllvm29_apply1126);
  set_type(obj1124, 0);
// compilenode returning obj1124
  setclassname(obj1124, "Block<genllvm29:1123>");
// compilenode returning obj1124
  params[0] = *var_declaredvars;
  Object iter1122 = callmethod(*var_declaredvars, "iter", 1, params);
  while(1) {
    Object cond1122 = callmethod(iter1122, "havemore", 0, NULL);
    if (!istrue(cond1122)) break;
    params[0] = callmethod(iter1122, "next", 0, NULL);
    callmethod(obj1124, "apply", 1, params);
  }
// compilenode returning *var_declaredvars
// Begin line 380
  setline(380);
// Begin line 368
  setline(368);
// compilenode returning *var_decl
  Object if1133;
  if (istrue(*var_decl)) {
// Begin line 370
  setline(370);
// Begin line 369
  setline(369);
// compilenode returning *var_decl
  *var_decl = *var_decl;
  if (*var_decl == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1133 = nothing;
  } else {
  Object *var_found = alloc_var();
  *var_found = undefined;
// Begin line 372
  setline(372);
// Begin line 371
  setline(371);
  Object bool1135 = alloc_Boolean(0);
// compilenode returning bool1135
  var_found = alloc_var();
  *var_found = bool1135;
  if (bool1135 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 375
  setline(375);
// Begin line 372
  setline(372);
// compilenode returning *var_closurevars
// Begin line 375
  setline(375);
// Begin line 1429
  setline(1429);
  Object obj1138 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1138, self, 0);
  addmethod2(obj1138, "outer", &reader_genllvm29_outer_1139);
  adddatum2(obj1138, self, 0);
  block_savedest(obj1138);
  Object **closure1140 = createclosure(3);
  addtoclosure(closure1140, var_u);
  addtoclosure(closure1140, var_found);
  Object *selfpp1146 = alloc_var();
  *selfpp1146 = self;
  addtoclosure(closure1140, selfpp1146);
  struct UserObject *uo1140 = (struct UserObject*)obj1138;
  uo1140->data[1] = (Object)closure1140;
  addmethod2(obj1138, "apply", &meth_genllvm29_apply1140);
  set_type(obj1138, 0);
// compilenode returning obj1138
  setclassname(obj1138, "Block<genllvm29:1137>");
// compilenode returning obj1138
  params[0] = *var_closurevars;
  Object iter1136 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1136 = callmethod(iter1136, "havemore", 0, NULL);
    if (!istrue(cond1136)) break;
    params[0] = callmethod(iter1136, "next", 0, NULL);
    callmethod(obj1138, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 380
  setline(380);
// Begin line 377
  setline(377);
// compilenode returning *var_found
  Object if1147;
  if (istrue(*var_found)) {
// Begin line 379
  setline(379);
// Begin line 378
  setline(378);
// compilenode returning *var_found
  *var_found = *var_found;
  if (*var_found == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1147 = nothing;
  } else {
// Begin line 380
  setline(380);
// compilenode returning *var_u
// compilenode returning *var_closurevars
  params[0] = *var_u;
  Object call1149 = callmethod(*var_closurevars, "push",
    1, params);
// compilenode returning call1149
    if1147 = call1149;
  }
// compilenode returning if1147
    if1133 = if1147;
  }
// compilenode returning if1133
  return if1133;
}
Object meth_genllvm29_apply1241(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_closurevars = closure[0];
  Object *var_i = closure[1];
  Object *var_toremove = closure[2];
  Object *var_declaredvars = closure[3];
  Object self = *closure[4];
  Object *var_pn = alloc_var();
  *var_pn = undefined;
// Begin line 418
  setline(418);
// Begin line 1429
  setline(1429);
// Begin line 418
  setline(418);
// Begin line 1429
  setline(1429);
// Begin line 418
  setline(418);
// compilenode returning *var_p
  Object call1242 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call1242
// compilenode returning call1242
  Object call1243 = callmethod(call1242, "_escape",
    0, params);
// compilenode returning call1243
// compilenode returning call1243
  var_pn = alloc_var();
  *var_pn = call1243;
  if (call1243 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 427
  setline(427);
// Begin line 419
  setline(419);
// compilenode returning *var_pn
// compilenode returning *var_closurevars
  params[0] = *var_pn;
  Object call1245 = callmethod(*var_closurevars, "contains",
    1, params);
// compilenode returning call1245
  Object if1244;
  if (istrue(call1245)) {
// Begin line 420
  setline(420);
  if (strlit1246 == NULL) {
    strlit1246 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1246
// compilenode returning *var_pn
  params[0] = *var_pn;
  Object opresult1248 = callmethod(strlit1246, "++", 1, params);
// compilenode returning opresult1248
  if (strlit1249 == NULL) {
    strlit1249 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit1249
  params[0] = strlit1249;
  Object opresult1251 = callmethod(opresult1248, "++", 1, params);
// compilenode returning opresult1251
// Begin line 421
  setline(421);
// compilenode returning self
  params[0] = opresult1251;
  Object call1252 = callmethod(self, "out",
    1, params);
// compilenode returning call1252
  if (strlit1253 == NULL) {
    strlit1253 = alloc_String("  %argp_");
  }
// compilenode returning strlit1253
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1255 = callmethod(strlit1253, "++", 1, params);
// compilenode returning opresult1255
  if (strlit1256 == NULL) {
    strlit1256 = alloc_String(" = getelementptr %object* %args, i32 ");
  }
// compilenode returning strlit1256
  params[0] = strlit1256;
  Object opresult1258 = callmethod(opresult1255, "++", 1, params);
// compilenode returning opresult1258
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1260 = callmethod(opresult1258, "++", 1, params);
// compilenode returning opresult1260
  if (strlit1261 == NULL) {
    strlit1261 = alloc_String("");
  }
// compilenode returning strlit1261
  params[0] = strlit1261;
  Object opresult1263 = callmethod(opresult1260, "++", 1, params);
// compilenode returning opresult1263
// Begin line 422
  setline(422);
// compilenode returning self
  params[0] = opresult1263;
  Object call1264 = callmethod(self, "out",
    1, params);
// compilenode returning call1264
  if (strlit1265 == NULL) {
    strlit1265 = alloc_String("  %argval_");
  }
// compilenode returning strlit1265
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1267 = callmethod(strlit1265, "++", 1, params);
// compilenode returning opresult1267
  if (strlit1268 == NULL) {
    strlit1268 = alloc_String(" = load %object* %argp_");
  }
// compilenode returning strlit1268
  params[0] = strlit1268;
  Object opresult1270 = callmethod(opresult1267, "++", 1, params);
// compilenode returning opresult1270
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1272 = callmethod(opresult1270, "++", 1, params);
// compilenode returning opresult1272
  if (strlit1273 == NULL) {
    strlit1273 = alloc_String("");
  }
// compilenode returning strlit1273
  params[0] = strlit1273;
  Object opresult1275 = callmethod(opresult1272, "++", 1, params);
// compilenode returning opresult1275
// Begin line 423
  setline(423);
// compilenode returning self
  params[0] = opresult1275;
  Object call1276 = callmethod(self, "out",
    1, params);
// compilenode returning call1276
  if (strlit1277 == NULL) {
    strlit1277 = alloc_String("  store %object %""\x22""argval_");
  }
// compilenode returning strlit1277
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1279 = callmethod(strlit1277, "++", 1, params);
// compilenode returning opresult1279
  if (strlit1280 == NULL) {
    strlit1280 = alloc_String("""\x22"", %object* %""\x22""var_");
  }
// compilenode returning strlit1280
  params[0] = strlit1280;
  Object opresult1282 = callmethod(opresult1279, "++", 1, params);
// compilenode returning opresult1282
// compilenode returning *var_pn
  params[0] = *var_pn;
  Object opresult1284 = callmethod(opresult1282, "++", 1, params);
// compilenode returning opresult1284
  if (strlit1285 == NULL) {
    strlit1285 = alloc_String("""\x22""");
  }
// compilenode returning strlit1285
  params[0] = strlit1285;
  Object opresult1287 = callmethod(opresult1284, "++", 1, params);
// compilenode returning opresult1287
// Begin line 424
  setline(424);
// compilenode returning self
  params[0] = opresult1287;
  Object call1288 = callmethod(self, "out",
    1, params);
// compilenode returning call1288
// compilenode returning *var_pn
// compilenode returning *var_toremove
  params[0] = *var_pn;
  Object call1289 = callmethod(*var_toremove, "push",
    1, params);
// compilenode returning call1289
    if1244 = call1289;
  } else {
// Begin line 427
  setline(427);
// Begin line 426
  setline(426);
  if (strlit1290 == NULL) {
    strlit1290 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1290
// compilenode returning *var_pn
  params[0] = *var_pn;
  Object opresult1292 = callmethod(strlit1290, "++", 1, params);
// compilenode returning opresult1292
  if (strlit1293 == NULL) {
    strlit1293 = alloc_String("""\x22"" = getelementptr %object* %args, ");
  }
// compilenode returning strlit1293
  params[0] = strlit1293;
  Object opresult1295 = callmethod(opresult1292, "++", 1, params);
// compilenode returning opresult1295
// Begin line 427
  setline(427);
  if (strlit1296 == NULL) {
    strlit1296 = alloc_String("i32 ");
  }
// compilenode returning strlit1296
  params[0] = strlit1296;
  Object opresult1298 = callmethod(opresult1295, "++", 1, params);
// compilenode returning opresult1298
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1300 = callmethod(opresult1298, "++", 1, params);
// compilenode returning opresult1300
// Begin line 428
  setline(428);
// compilenode returning self
  params[0] = opresult1300;
  Object call1301 = callmethod(self, "out",
    1, params);
// compilenode returning call1301
    if1244 = call1301;
  }
// compilenode returning if1244
// Begin line 429
  setline(429);
// compilenode returning *var_pn
// compilenode returning *var_declaredvars
  params[0] = *var_pn;
  Object call1302 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1302
// Begin line 431
  setline(431);
// Begin line 430
  setline(430);
// compilenode returning *var_i
  Object num1303 = alloc_Float64(1.0);
// compilenode returning num1303
  params[0] = num1303;
  Object sum1305 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum1305
  *var_i = sum1305;
  if (sum1305 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1314(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_pn = alloc_var();
  *var_pn = args[0];
  Object params[1];
  Object *var_toremove = closure[0];
  Object *var_closurevars = closure[1];
  Object self = *closure[2];
// Begin line 438
  setline(438);
// Begin line 435
  setline(435);
// compilenode returning *var_pn
// compilenode returning *var_toremove
  params[0] = *var_pn;
  Object call1316 = callmethod(*var_toremove, "contains",
    1, params);
// compilenode returning call1316
  Object if1315;
  if (istrue(call1316)) {
    if1315 = undefined;
  } else {
// Begin line 438
  setline(438);
// compilenode returning *var_pn
// compilenode returning *var_closurevars
  params[0] = *var_pn;
  Object call1317 = callmethod(*var_closurevars, "push",
    1, params);
// compilenode returning call1317
    if1315 = call1317;
  }
// compilenode returning if1315
  return if1315;
}
Object meth_genllvm29_apply1333(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ii = alloc_var();
  *var_ii = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 444
  setline(444);
// Begin line 443
  setline(443);
  if (strlit1334 == NULL) {
    strlit1334 = alloc_String("  %params_");
  }
// compilenode returning strlit1334
// compilenode returning *var_ii
  params[0] = *var_ii;
  Object opresult1336 = callmethod(strlit1334, "++", 1, params);
// compilenode returning opresult1336
  if (strlit1337 == NULL) {
    strlit1337 = alloc_String(" = getelementptr %object* %params, i32 ");
  }
// compilenode returning strlit1337
  params[0] = strlit1337;
  Object opresult1339 = callmethod(opresult1336, "++", 1, params);
// compilenode returning opresult1339
// Begin line 444
  setline(444);
// compilenode returning *var_ii
  params[0] = *var_ii;
  Object opresult1341 = callmethod(opresult1339, "++", 1, params);
// compilenode returning opresult1341
// Begin line 445
  setline(445);
// compilenode returning self
  params[0] = opresult1341;
  Object call1342 = callmethod(self, "out",
    1, params);
// compilenode returning call1342
  return call1342;
}
Object meth_genllvm29_apply1349(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_cv = alloc_var();
  *var_cv = args[0];
  Object params[1];
  Object *var_j = closure[0];
  Object self = *closure[1];
// Begin line 455
  setline(455);
// Begin line 457
  setline(457);
// Begin line 448
  setline(448);
// compilenode returning *var_cv
  if (strlit1351 == NULL) {
    strlit1351 = alloc_String("self");
  }
// compilenode returning strlit1351
  params[0] = strlit1351;
  Object opresult1353 = callmethod(*var_cv, "==", 1, params);
// compilenode returning opresult1353
  Object if1350;
  if (istrue(opresult1353)) {
// Begin line 449
  setline(449);
  if (strlit1354 == NULL) {
    strlit1354 = alloc_String("  %varc_");
  }
// compilenode returning strlit1354
// compilenode returning *var_cv
  params[0] = *var_cv;
  Object opresult1356 = callmethod(strlit1354, "++", 1, params);
// compilenode returning opresult1356
  if (strlit1357 == NULL) {
    strlit1357 = alloc_String(" = getelementptr %object** %closure, i32 ");
  }
// compilenode returning strlit1357
  params[0] = strlit1357;
  Object opresult1359 = callmethod(opresult1356, "++", 1, params);
// compilenode returning opresult1359
// compilenode returning *var_j
  params[0] = *var_j;
  Object opresult1361 = callmethod(opresult1359, "++", 1, params);
// compilenode returning opresult1361
// Begin line 450
  setline(450);
// compilenode returning self
  params[0] = opresult1361;
  Object call1362 = callmethod(self, "out",
    1, params);
// compilenode returning call1362
  if (strlit1363 == NULL) {
    strlit1363 = alloc_String("  %self2 = load %object** %varc_");
  }
// compilenode returning strlit1363
// compilenode returning *var_cv
  params[0] = *var_cv;
  Object opresult1365 = callmethod(strlit1363, "++", 1, params);
// compilenode returning opresult1365
// Begin line 451
  setline(451);
// compilenode returning self
  params[0] = opresult1365;
  Object call1366 = callmethod(self, "out",
    1, params);
// compilenode returning call1366
  if (strlit1367 == NULL) {
    strlit1367 = alloc_String("  %self = load %object* %self2");
  }
// compilenode returning strlit1367
// Begin line 452
  setline(452);
// compilenode returning self
  params[0] = strlit1367;
  Object call1368 = callmethod(self, "out",
    1, params);
// compilenode returning call1368
    if1350 = call1368;
  } else {
// Begin line 453
  setline(453);
  if (strlit1369 == NULL) {
    strlit1369 = alloc_String("  %""\x22""varc_");
  }
// compilenode returning strlit1369
// compilenode returning *var_cv
  params[0] = *var_cv;
  Object opresult1371 = callmethod(strlit1369, "++", 1, params);
// compilenode returning opresult1371
  if (strlit1372 == NULL) {
    strlit1372 = alloc_String("""\x22"" = getelementptr %object** %closure, i32 ");
  }
// compilenode returning strlit1372
  params[0] = strlit1372;
  Object opresult1374 = callmethod(opresult1371, "++", 1, params);
// compilenode returning opresult1374
// compilenode returning *var_j
  params[0] = *var_j;
  Object opresult1376 = callmethod(opresult1374, "++", 1, params);
// compilenode returning opresult1376
// Begin line 454
  setline(454);
// compilenode returning self
  params[0] = opresult1376;
  Object call1377 = callmethod(self, "out",
    1, params);
// compilenode returning call1377
// Begin line 455
  setline(455);
// Begin line 454
  setline(454);
  if (strlit1378 == NULL) {
    strlit1378 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1378
// compilenode returning *var_cv
  params[0] = *var_cv;
  Object opresult1380 = callmethod(strlit1378, "++", 1, params);
// compilenode returning opresult1380
  if (strlit1381 == NULL) {
    strlit1381 = alloc_String("""\x22"" = load %object** %""\x22""varc_");
  }
// compilenode returning strlit1381
  params[0] = strlit1381;
  Object opresult1383 = callmethod(opresult1380, "++", 1, params);
// compilenode returning opresult1383
// compilenode returning *var_cv
  params[0] = *var_cv;
  Object opresult1385 = callmethod(opresult1383, "++", 1, params);
// compilenode returning opresult1385
// Begin line 455
  setline(455);
  if (strlit1386 == NULL) {
    strlit1386 = alloc_String("""\x22""");
  }
// compilenode returning strlit1386
  params[0] = strlit1386;
  Object opresult1388 = callmethod(opresult1385, "++", 1, params);
// compilenode returning opresult1388
// Begin line 456
  setline(456);
// compilenode returning self
  params[0] = opresult1388;
  Object call1389 = callmethod(self, "out",
    1, params);
// compilenode returning call1389
    if1350 = call1389;
  }
// compilenode returning if1350
// Begin line 458
  setline(458);
// Begin line 457
  setline(457);
// compilenode returning *var_j
  Object num1390 = alloc_Float64(1.0);
// compilenode returning num1390
  params[0] = num1390;
  Object sum1392 = callmethod(*var_j, "+", 1, params);
// compilenode returning sum1392
  *var_j = sum1392;
  if (sum1392 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1399(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 460
  setline(460);
// compilenode returning *var_l
// Begin line 461
  setline(461);
// compilenode returning self
  params[0] = *var_l;
  Object call1400 = callmethod(self, "out",
    1, params);
// compilenode returning call1400
  return call1400;
}
Object meth_genllvm29_apply1408(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 464
  setline(464);
// compilenode returning *var_l
// Begin line 465
  setline(465);
// compilenode returning self
  params[0] = *var_l;
  Object call1409 = callmethod(self, "outprint",
    1, params);
// compilenode returning call1409
  return call1409;
}
Object meth_genllvm29_apply1419(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_cv = alloc_var();
  *var_cv = args[0];
  Object params[1];
  Object *var_usedvars = closure[0];
  Object self = *closure[1];
// Begin line 473
  setline(473);
// Begin line 476
  setline(476);
// Begin line 471
  setline(471);
// compilenode returning *var_cv
  if (strlit1421 == NULL) {
    strlit1421 = alloc_String("self");
  }
// compilenode returning strlit1421
  params[0] = strlit1421;
  Object opresult1423 = callmethod(*var_cv, "/=", 1, params);
// compilenode returning opresult1423
  Object if1420;
  if (istrue(opresult1423)) {
// Begin line 473
  setline(473);
// Begin line 472
  setline(472);
// Begin line 1429
  setline(1429);
// Begin line 472
  setline(472);
// compilenode returning *var_cv
// compilenode returning *var_usedvars
  params[0] = *var_cv;
  Object call1425 = callmethod(*var_usedvars, "contains",
    1, params);
// compilenode returning call1425
  Object call1426 = callmethod(call1425, "not",
    0, params);
// compilenode returning call1426
// compilenode returning call1426
  Object if1424;
  if (istrue(call1426)) {
// Begin line 473
  setline(473);
// compilenode returning *var_cv
// compilenode returning *var_usedvars
  params[0] = *var_cv;
  Object call1427 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call1427
    if1424 = call1427;
  } else {
  }
// compilenode returning if1424
    if1420 = if1424;
  } else {
  }
// compilenode returning if1420
  return if1420;
}
Object meth_genllvm29_apply1510(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_myc = closure[1];
  Object self = *closure[2];
// Begin line 501
  setline(501);
// Begin line 503
  setline(503);
// Begin line 492
  setline(492);
// compilenode returning *var_v
  if (strlit1512 == NULL) {
    strlit1512 = alloc_String("self");
  }
// compilenode returning strlit1512
  params[0] = strlit1512;
  Object opresult1514 = callmethod(*var_v, "==", 1, params);
// compilenode returning opresult1514
  Object if1511;
  if (istrue(opresult1514)) {
// Begin line 494
  setline(494);
// Begin line 493
  setline(493);
  if (strlit1515 == NULL) {
    strlit1515 = alloc_String("  %selfpp");
  }
// compilenode returning strlit1515
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1517 = callmethod(strlit1515, "++", 1, params);
// compilenode returning opresult1517
  if (strlit1518 == NULL) {
    strlit1518 = alloc_String(" = ");
  }
// compilenode returning strlit1518
  params[0] = strlit1518;
  Object opresult1520 = callmethod(opresult1517, "++", 1, params);
// compilenode returning opresult1520
// Begin line 494
  setline(494);
  if (strlit1521 == NULL) {
    strlit1521 = alloc_String("call %object* @alloc_var()");
  }
// compilenode returning strlit1521
  params[0] = strlit1521;
  Object opresult1523 = callmethod(opresult1520, "++", 1, params);
// compilenode returning opresult1523
// Begin line 495
  setline(495);
// compilenode returning self
  params[0] = opresult1523;
  Object call1524 = callmethod(self, "out",
    1, params);
// compilenode returning call1524
  if (strlit1525 == NULL) {
    strlit1525 = alloc_String("  store %object %self, %object* %selfpp");
  }
// compilenode returning strlit1525
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1527 = callmethod(strlit1525, "++", 1, params);
// compilenode returning opresult1527
// Begin line 496
  setline(496);
// compilenode returning self
  params[0] = opresult1527;
  Object call1528 = callmethod(self, "out",
    1, params);
// compilenode returning call1528
// Begin line 497
  setline(497);
// Begin line 496
  setline(496);
  if (strlit1529 == NULL) {
    strlit1529 = alloc_String("  call void @addtoclosure(%object** %closure");
  }
// compilenode returning strlit1529
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1531 = callmethod(strlit1529, "++", 1, params);
// compilenode returning opresult1531
  if (strlit1532 == NULL) {
    strlit1532 = alloc_String(", ");
  }
// compilenode returning strlit1532
  params[0] = strlit1532;
  Object opresult1534 = callmethod(opresult1531, "++", 1, params);
// compilenode returning opresult1534
// Begin line 497
  setline(497);
  if (strlit1535 == NULL) {
    strlit1535 = alloc_String("%object* %selfpp");
  }
// compilenode returning strlit1535
  params[0] = strlit1535;
  Object opresult1537 = callmethod(opresult1534, "++", 1, params);
// compilenode returning opresult1537
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult1539 = callmethod(opresult1537, "++", 1, params);
// compilenode returning opresult1539
  if (strlit1540 == NULL) {
    strlit1540 = alloc_String(")");
  }
// compilenode returning strlit1540
  params[0] = strlit1540;
  Object opresult1542 = callmethod(opresult1539, "++", 1, params);
// compilenode returning opresult1542
// Begin line 498
  setline(498);
// compilenode returning self
  params[0] = opresult1542;
  Object call1543 = callmethod(self, "out",
    1, params);
// compilenode returning call1543
// Begin line 499
  setline(499);
// Begin line 498
  setline(498);
// compilenode returning *var_auto_count
  Object num1544 = alloc_Float64(1.0);
// compilenode returning num1544
  params[0] = num1544;
  Object sum1546 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1546
  *var_auto_count = sum1546;
  if (sum1546 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1511 = nothing;
  } else {
// Begin line 501
  setline(501);
// Begin line 500
  setline(500);
  if (strlit1548 == NULL) {
    strlit1548 = alloc_String("  call void @addtoclosure(%object** %closure");
  }
// compilenode returning strlit1548
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1550 = callmethod(strlit1548, "++", 1, params);
// compilenode returning opresult1550
  if (strlit1551 == NULL) {
    strlit1551 = alloc_String(", ");
  }
// compilenode returning strlit1551
  params[0] = strlit1551;
  Object opresult1553 = callmethod(opresult1550, "++", 1, params);
// compilenode returning opresult1553
// Begin line 501
  setline(501);
  if (strlit1554 == NULL) {
    strlit1554 = alloc_String("%object* %""\x22""var_");
  }
// compilenode returning strlit1554
  params[0] = strlit1554;
  Object opresult1556 = callmethod(opresult1553, "++", 1, params);
// compilenode returning opresult1556
// compilenode returning *var_v
  params[0] = *var_v;
  Object opresult1558 = callmethod(opresult1556, "++", 1, params);
// compilenode returning opresult1558
  if (strlit1559 == NULL) {
    strlit1559 = alloc_String("""\x22"")");
  }
// compilenode returning strlit1559
  params[0] = strlit1559;
  Object opresult1561 = callmethod(opresult1558, "++", 1, params);
// compilenode returning opresult1561
// Begin line 502
  setline(502);
// compilenode returning self
  params[0] = opresult1561;
  Object call1562 = callmethod(self, "out",
    1, params);
// compilenode returning call1562
    if1511 = call1562;
  }
// compilenode returning if1511
  return if1511;
}
Object meth_genllvm29_compilemethod987(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object *var_selfobj = alloc_var();
  *var_selfobj = args[1];
  Object *var_pos = alloc_var();
  *var_pos = args[2];
  Object params[1];
  Object *var_paramsUsed = closure[0];
  Object *var_inBlock = closure[1];
  Object *var_output = closure[2];
  Object *var_bblock = closure[3];
  Object *var_usedvars = closure[4];
  Object *var_declaredvars = closure[5];
  Object *var_auto_count = closure[6];
  Object *var_modname = closure[7];
  Object *var_constants = closure[8];
  Object *var_origParamsUsed = alloc_var();
  *var_origParamsUsed = undefined;
  Object *var_origInBlock = alloc_var();
  *var_origInBlock = undefined;
  Object *var_oldout = alloc_var();
  *var_oldout = undefined;
  Object *var_oldbblock = alloc_var();
  *var_oldbblock = undefined;
  Object *var_oldusedvars = alloc_var();
  *var_oldusedvars = undefined;
  Object *var_olddeclaredvars = alloc_var();
  *var_olddeclaredvars = undefined;
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_name = alloc_var();
  *var_name = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
  Object *var_ret = alloc_var();
  *var_ret = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_closurevars = alloc_var();
  *var_closurevars = undefined;
  Object *var_litname = alloc_var();
  *var_litname = undefined;
  Object *var_toremove = alloc_var();
  *var_toremove = undefined;
  Object *var_origclosurevars = alloc_var();
  *var_origclosurevars = undefined;
  Object *var_j = alloc_var();
  *var_j = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 316
  setline(316);
// Begin line 315
  setline(315);
// compilenode returning *var_paramsUsed
  var_origParamsUsed = alloc_var();
  *var_origParamsUsed = *var_paramsUsed;
  if (*var_paramsUsed == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 317
  setline(317);
// Begin line 316
  setline(316);
  Object num988 = alloc_Float64(1.0);
// compilenode returning num988
  *var_paramsUsed = num988;
  if (num988 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 318
  setline(318);
// Begin line 317
  setline(317);
// compilenode returning *var_inBlock
  var_origInBlock = alloc_var();
  *var_origInBlock = *var_inBlock;
  if (*var_inBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 319
  setline(319);
// Begin line 1429
  setline(1429);
// Begin line 318
  setline(318);
// compilenode returning *var_o
  Object call990 = callmethod(*var_o, "selfclosure",
    0, params);
// compilenode returning call990
// compilenode returning call990
  *var_inBlock = call990;
  if (call990 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 320
  setline(320);
// Begin line 319
  setline(319);
// compilenode returning *var_output
  var_oldout = alloc_var();
  *var_oldout = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 321
  setline(321);
// Begin line 320
  setline(320);
// compilenode returning *var_bblock
  var_oldbblock = alloc_var();
  *var_oldbblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 322
  setline(322);
// Begin line 321
  setline(321);
// compilenode returning *var_usedvars
  var_oldusedvars = alloc_var();
  *var_oldusedvars = *var_usedvars;
  if (*var_usedvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 323
  setline(323);
// Begin line 322
  setline(322);
// compilenode returning *var_declaredvars
  var_olddeclaredvars = alloc_var();
  *var_olddeclaredvars = *var_declaredvars;
  if (*var_declaredvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 324
  setline(324);
  Object array992 = alloc_List();
// compilenode returning array992
  *var_output = array992;
  if (array992 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 325
  setline(325);
  Object array994 = alloc_List();
// compilenode returning array994
  *var_usedvars = array994;
  if (array994 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 326
  setline(326);
  Object array996 = alloc_List();
// compilenode returning array996
  *var_declaredvars = array996;
  if (array996 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 327
  setline(327);
// Begin line 326
  setline(326);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 328
  setline(328);
// Begin line 327
  setline(327);
// compilenode returning *var_auto_count
  Object num998 = alloc_Float64(1.0);
// compilenode returning num998
  params[0] = num998;
  Object sum1000 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1000
  *var_auto_count = sum1000;
  if (sum1000 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 329
  setline(329);
// Begin line 1429
  setline(1429);
// Begin line 329
  setline(329);
// Begin line 1429
  setline(1429);
// Begin line 328
  setline(328);
// compilenode returning *var_o
  Object call1002 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1002
// compilenode returning call1002
  Object call1003 = callmethod(call1002, "value",
    0, params);
// compilenode returning call1003
// compilenode returning call1003
  var_name = alloc_var();
  *var_name = call1003;
  if (call1003 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 330
  setline(330);
// Begin line 329
  setline(329);
// compilenode returning *var_name
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1005 = callmethod(*var_name, "++", 1, params);
// compilenode returning opresult1005
  var_nm = alloc_var();
  *var_nm = opresult1005;
  if (opresult1005 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 330
  setline(330);
  if (strlit1006 == NULL) {
    strlit1006 = alloc_String("entry");
  }
// compilenode returning strlit1006
// Begin line 331
  setline(331);
// compilenode returning self
  params[0] = strlit1006;
  Object call1007 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1007
// Begin line 1429
  setline(1429);
// Begin line 331
  setline(331);
// compilenode returning *var_output
  Object call1008 = callmethod(*var_output, "pop",
    0, params);
// compilenode returning call1008
// compilenode returning call1008
// Begin line 333
  setline(333);
// Begin line 1429
  setline(1429);
// Begin line 333
  setline(333);
// Begin line 1429
  setline(1429);
// Begin line 332
  setline(332);
// compilenode returning *var_o
  Object call1009 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call1009
// compilenode returning call1009
  Object call1010 = callmethod(call1009, "size",
    0, params);
// compilenode returning call1010
// compilenode returning call1010
  var_i = alloc_var();
  *var_i = call1010;
  if (call1010 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 339
  setline(339);
// Begin line 341
  setline(341);
// Begin line 1429
  setline(1429);
// Begin line 333
  setline(333);
// compilenode returning *var_o
  Object call1012 = callmethod(*var_o, "varargs",
    0, params);
// compilenode returning call1012
// compilenode returning call1012
  Object if1011;
  if (istrue(call1012)) {
  Object *var_van = alloc_var();
  *var_van = undefined;
// Begin line 334
  setline(334);
// Begin line 1429
  setline(1429);
// Begin line 334
  setline(334);
// Begin line 1429
  setline(1429);
// Begin line 334
  setline(334);
// Begin line 1429
  setline(1429);
// Begin line 334
  setline(334);
// compilenode returning *var_o
  Object call1013 = callmethod(*var_o, "vararg",
    0, params);
// compilenode returning call1013
// compilenode returning call1013
  Object call1014 = callmethod(call1013, "value",
    0, params);
// compilenode returning call1014
// compilenode returning call1014
  Object call1015 = callmethod(call1014, "_escape",
    0, params);
// compilenode returning call1015
// compilenode returning call1015
  var_van = alloc_var();
  *var_van = call1015;
  if (call1015 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 336
  setline(336);
// Begin line 335
  setline(335);
  if (strlit1016 == NULL) {
    strlit1016 = alloc_String("  %""\x22""var_init_");
  }
// compilenode returning strlit1016
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult1018 = callmethod(strlit1016, "++", 1, params);
// compilenode returning opresult1018
  if (strlit1019 == NULL) {
    strlit1019 = alloc_String("""\x22"" = call %object @process_varargs(");
  }
// compilenode returning strlit1019
  params[0] = strlit1019;
  Object opresult1021 = callmethod(opresult1018, "++", 1, params);
// compilenode returning opresult1021
// Begin line 336
  setline(336);
  if (strlit1022 == NULL) {
    strlit1022 = alloc_String("%object* %args, i32 ");
  }
// compilenode returning strlit1022
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult1024 = callmethod(strlit1022, "++", 1, params);
// compilenode returning opresult1024
  if (strlit1025 == NULL) {
    strlit1025 = alloc_String(", i32 %nparams)");
  }
// compilenode returning strlit1025
  params[0] = strlit1025;
  Object opresult1027 = callmethod(opresult1024, "++", 1, params);
// compilenode returning opresult1027
  params[0] = opresult1027;
  Object opresult1029 = callmethod(opresult1021, "++", 1, params);
// compilenode returning opresult1029
// Begin line 337
  setline(337);
// compilenode returning self
  params[0] = opresult1029;
  Object call1030 = callmethod(self, "out",
    1, params);
// compilenode returning call1030
  if (strlit1031 == NULL) {
    strlit1031 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1031
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult1033 = callmethod(strlit1031, "++", 1, params);
// compilenode returning opresult1033
  if (strlit1034 == NULL) {
    strlit1034 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit1034
  params[0] = strlit1034;
  Object opresult1036 = callmethod(opresult1033, "++", 1, params);
// compilenode returning opresult1036
// Begin line 338
  setline(338);
// compilenode returning self
  params[0] = opresult1036;
  Object call1037 = callmethod(self, "out",
    1, params);
// compilenode returning call1037
  if (strlit1038 == NULL) {
    strlit1038 = alloc_String("  store %object %""\x22""var_init_");
  }
// compilenode returning strlit1038
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult1040 = callmethod(strlit1038, "++", 1, params);
// compilenode returning opresult1040
  if (strlit1041 == NULL) {
    strlit1041 = alloc_String("""\x22"", %object* %""\x22""var_");
  }
// compilenode returning strlit1041
  params[0] = strlit1041;
  Object opresult1043 = callmethod(opresult1040, "++", 1, params);
// compilenode returning opresult1043
// compilenode returning *var_van
  params[0] = *var_van;
  Object opresult1045 = callmethod(opresult1043, "++", 1, params);
// compilenode returning opresult1045
  if (strlit1046 == NULL) {
    strlit1046 = alloc_String("""\x22""");
  }
// compilenode returning strlit1046
  params[0] = strlit1046;
  Object opresult1048 = callmethod(opresult1045, "++", 1, params);
// compilenode returning opresult1048
// Begin line 339
  setline(339);
// compilenode returning self
  params[0] = opresult1048;
  Object call1049 = callmethod(self, "out",
    1, params);
// compilenode returning call1049
// compilenode returning *var_van
// compilenode returning *var_declaredvars
  params[0] = *var_van;
  Object call1050 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1050
    if1011 = call1050;
  } else {
  }
// compilenode returning if1011
// Begin line 341
  setline(341);
  if (strlit1051 == NULL) {
    strlit1051 = alloc_String("  %undefined = load %object* @undefined");
  }
// compilenode returning strlit1051
// Begin line 342
  setline(342);
// compilenode returning self
  params[0] = strlit1051;
  Object call1052 = callmethod(self, "out",
    1, params);
// compilenode returning call1052
  if (strlit1053 == NULL) {
    strlit1053 = alloc_String("  %nothing = load %object* @nothing");
  }
// compilenode returning strlit1053
// Begin line 343
  setline(343);
// compilenode returning self
  params[0] = strlit1053;
  Object call1054 = callmethod(self, "out",
    1, params);
// compilenode returning call1054
// Begin line 344
  setline(344);
// Begin line 343
  setline(343);
  if (strlit1055 == NULL) {
    strlit1055 = alloc_String("%nothing");
  }
// compilenode returning strlit1055
  var_ret = alloc_var();
  *var_ret = strlit1055;
  if (strlit1055 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 350
  setline(350);
// Begin line 353
  setline(353);
// Begin line 1429
  setline(1429);
// Begin line 344
  setline(344);
// compilenode returning *var_o
  Object call1057 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call1057
// compilenode returning call1057
// Begin line 350
  setline(350);
// Begin line 1429
  setline(1429);
  Object obj1059 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1059, self, 0);
  addmethod2(obj1059, "outer", &reader_genllvm29_outer_1060);
  adddatum2(obj1059, self, 0);
  block_savedest(obj1059);
  Object **closure1061 = createclosure(2);
  addtoclosure(closure1061, var_declaredvars);
  Object *selfpp1097 = alloc_var();
  *selfpp1097 = self;
  addtoclosure(closure1061, selfpp1097);
  struct UserObject *uo1061 = (struct UserObject*)obj1059;
  uo1061->data[1] = (Object)closure1061;
  addmethod2(obj1059, "apply", &meth_genllvm29_apply1061);
  set_type(obj1059, 0);
// compilenode returning obj1059
  setclassname(obj1059, "Block<genllvm29:1058>");
// compilenode returning obj1059
  params[0] = call1057;
  Object iter1056 = callmethod(call1057, "iter", 1, params);
  while(1) {
    Object cond1056 = callmethod(iter1056, "havemore", 0, NULL);
    if (!istrue(cond1056)) break;
    params[0] = callmethod(iter1056, "next", 0, NULL);
    callmethod(obj1059, "apply", 1, params);
  }
// compilenode returning call1057
// Begin line 354
  setline(354);
// Begin line 356
  setline(356);
// Begin line 1429
  setline(1429);
// Begin line 353
  setline(353);
// compilenode returning *var_o
  Object call1099 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call1099
// compilenode returning call1099
// Begin line 354
  setline(354);
// Begin line 1429
  setline(1429);
  Object obj1101 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1101, self, 0);
  addmethod2(obj1101, "outer", &reader_genllvm29_outer_1102);
  adddatum2(obj1101, self, 0);
  block_savedest(obj1101);
  Object **closure1103 = createclosure(2);
  addtoclosure(closure1103, var_ret);
  Object *selfpp1106 = alloc_var();
  *selfpp1106 = self;
  addtoclosure(closure1103, selfpp1106);
  struct UserObject *uo1103 = (struct UserObject*)obj1101;
  uo1103->data[1] = (Object)closure1103;
  addmethod2(obj1101, "apply", &meth_genllvm29_apply1103);
  set_type(obj1101, 0);
// compilenode returning obj1101
  setclassname(obj1101, "Block<genllvm29:1100>");
// compilenode returning obj1101
  params[0] = call1099;
  Object iter1098 = callmethod(call1099, "iter", 1, params);
  while(1) {
    Object cond1098 = callmethod(iter1098, "havemore", 0, NULL);
    if (!istrue(cond1098)) break;
    params[0] = callmethod(iter1098, "next", 0, NULL);
    callmethod(obj1101, "apply", 1, params);
  }
// compilenode returning call1099
// Begin line 356
  setline(356);
  if (strlit1107 == NULL) {
    strlit1107 = alloc_String("  ret %object ");
  }
// compilenode returning strlit1107
// compilenode returning *var_ret
  params[0] = *var_ret;
  Object opresult1109 = callmethod(strlit1107, "++", 1, params);
// compilenode returning opresult1109
// Begin line 357
  setline(357);
// compilenode returning self
  params[0] = opresult1109;
  Object call1110 = callmethod(self, "out",
    1, params);
// compilenode returning call1110
  if (strlit1111 == NULL) {
    strlit1111 = alloc_String("}");
  }
// compilenode returning strlit1111
// Begin line 358
  setline(358);
// compilenode returning self
  params[0] = strlit1111;
  Object call1112 = callmethod(self, "out",
    1, params);
// compilenode returning call1112
// Begin line 359
  setline(359);
// Begin line 358
  setline(358);
// compilenode returning *var_output
  var_body = alloc_var();
  *var_body = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 360
  setline(360);
  Object array1113 = alloc_List();
// compilenode returning array1113
  *var_output = array1113;
  if (array1113 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 361
  setline(361);
  Object array1115 = alloc_List();
// compilenode returning array1115
  var_closurevars = alloc_var();
  *var_closurevars = array1115;
  if (array1115 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 380
  setline(380);
// Begin line 361
  setline(361);
// compilenode returning *var_usedvars
// Begin line 380
  setline(380);
// Begin line 1429
  setline(1429);
  Object obj1118 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1118, self, 0);
  addmethod2(obj1118, "outer", &reader_genllvm29_outer_1119);
  adddatum2(obj1118, self, 0);
  block_savedest(obj1118);
  Object **closure1120 = createclosure(3);
  addtoclosure(closure1120, var_declaredvars);
  addtoclosure(closure1120, var_closurevars);
  Object *selfpp1150 = alloc_var();
  *selfpp1150 = self;
  addtoclosure(closure1120, selfpp1150);
  struct UserObject *uo1120 = (struct UserObject*)obj1118;
  uo1120->data[1] = (Object)closure1120;
  addmethod2(obj1118, "apply", &meth_genllvm29_apply1120);
  set_type(obj1118, 0);
// compilenode returning obj1118
  setclassname(obj1118, "Block<genllvm29:1117>");
// compilenode returning obj1118
  params[0] = *var_usedvars;
  Object iter1116 = callmethod(*var_usedvars, "iter", 1, params);
  while(1) {
    Object cond1116 = callmethod(iter1116, "havemore", 0, NULL);
    if (!istrue(cond1116)) break;
    params[0] = callmethod(iter1116, "next", 0, NULL);
    callmethod(obj1118, "apply", 1, params);
  }
// compilenode returning *var_usedvars
// Begin line 385
  setline(385);
// Begin line 387
  setline(387);
// Begin line 1429
  setline(1429);
// Begin line 384
  setline(384);
// compilenode returning *var_o
  Object call1152 = callmethod(*var_o, "selfclosure",
    0, params);
// compilenode returning call1152
// compilenode returning call1152
  Object if1151;
  if (istrue(call1152)) {
// Begin line 385
  setline(385);
  if (strlit1153 == NULL) {
    strlit1153 = alloc_String("self");
  }
// compilenode returning strlit1153
// compilenode returning *var_closurevars
  params[0] = strlit1153;
  Object call1154 = callmethod(*var_closurevars, "push",
    1, params);
// compilenode returning call1154
    if1151 = call1154;
  } else {
  }
// compilenode returning if1151
// Begin line 387
  setline(387);
// Begin line 388
  setline(388);
// Begin line 387
  setline(387);
  if (strlit1155 == NULL) {
    strlit1155 = alloc_String("@""\x22""meth_");
  }
// compilenode returning strlit1155
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult1157 = callmethod(strlit1155, "++", 1, params);
// compilenode returning opresult1157
  if (strlit1158 == NULL) {
    strlit1158 = alloc_String("_");
  }
// compilenode returning strlit1158
  params[0] = strlit1158;
  Object opresult1160 = callmethod(opresult1157, "++", 1, params);
// compilenode returning opresult1160
// Begin line 1429
  setline(1429);
// Begin line 387
  setline(387);
// compilenode returning *var_nm
  Object call1161 = callmethod(*var_nm, "_escape",
    0, params);
// compilenode returning call1161
// compilenode returning call1161
  params[0] = call1161;
  Object opresult1163 = callmethod(opresult1160, "++", 1, params);
// compilenode returning opresult1163
  if (strlit1164 == NULL) {
    strlit1164 = alloc_String("""\x22""");
  }
// compilenode returning strlit1164
  params[0] = strlit1164;
  Object opresult1166 = callmethod(opresult1163, "++", 1, params);
// compilenode returning opresult1166
  var_litname = alloc_var();
  *var_litname = opresult1166;
  if (opresult1166 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 388
  setline(388);
  if (strlit1167 == NULL) {
    strlit1167 = alloc_String(";;;; METHOD DEFINITION: ");
  }
// compilenode returning strlit1167
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult1169 = callmethod(strlit1167, "++", 1, params);
// compilenode returning opresult1169
// Begin line 389
  setline(389);
// compilenode returning self
  params[0] = opresult1169;
  Object call1170 = callmethod(self, "outprint",
    1, params);
// compilenode returning call1170
// Begin line 408
  setline(408);
// Begin line 410
  setline(410);
// Begin line 1429
  setline(1429);
// Begin line 389
  setline(389);
// compilenode returning *var_closurevars
  Object call1172 = callmethod(*var_closurevars, "size",
    0, params);
// compilenode returning call1172
// compilenode returning call1172
  Object num1173 = alloc_Float64(0.0);
// compilenode returning num1173
  params[0] = num1173;
  Object opresult1175 = callmethod(call1172, ">", 1, params);
// compilenode returning opresult1175
  Object if1171;
  if (istrue(opresult1175)) {
// Begin line 399
  setline(399);
// Begin line 401
  setline(401);
// Begin line 1429
  setline(1429);
// Begin line 390
  setline(390);
// compilenode returning *var_o
  Object call1177 = callmethod(*var_o, "selfclosure",
    0, params);
// compilenode returning call1177
// compilenode returning call1177
  Object if1176;
  if (istrue(call1177)) {
// Begin line 392
  setline(392);
// Begin line 391
  setline(391);
  if (strlit1178 == NULL) {
    strlit1178 = alloc_String("define private %object ");
  }
// compilenode returning strlit1178
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1180 = callmethod(strlit1178, "++", 1, params);
// compilenode returning opresult1180
  if (strlit1181 == NULL) {
    strlit1181 = alloc_String("(%object %realself, i32 %nparams, ");
  }
// compilenode returning strlit1181
  params[0] = strlit1181;
  Object opresult1183 = callmethod(opresult1180, "++", 1, params);
// compilenode returning opresult1183
// Begin line 392
  setline(392);
  if (strlit1184 == NULL) {
    strlit1184 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit1184
  params[0] = strlit1184;
  Object opresult1186 = callmethod(opresult1183, "++", 1, params);
// compilenode returning opresult1186
// Begin line 393
  setline(393);
// compilenode returning self
  params[0] = opresult1186;
  Object call1187 = callmethod(self, "out",
    1, params);
// compilenode returning call1187
  if (strlit1188 == NULL) {
    strlit1188 = alloc_String("closureinit");
  }
// compilenode returning strlit1188
// Begin line 394
  setline(394);
// compilenode returning self
  params[0] = strlit1188;
  Object call1189 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1189
  if (strlit1190 == NULL) {
    strlit1190 = alloc_String("  %uo = bitcast %object %realself to %UserObject*");
  }
// compilenode returning strlit1190
// Begin line 395
  setline(395);
// compilenode returning self
  params[0] = strlit1190;
  Object call1191 = callmethod(self, "out",
    1, params);
// compilenode returning call1191
    if1176 = call1191;
  } else {
// Begin line 397
  setline(397);
// Begin line 396
  setline(396);
  if (strlit1192 == NULL) {
    strlit1192 = alloc_String("define private %object ");
  }
// compilenode returning strlit1192
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1194 = callmethod(strlit1192, "++", 1, params);
// compilenode returning opresult1194
  if (strlit1195 == NULL) {
    strlit1195 = alloc_String("(%object %self, i32 %nparams, ");
  }
// compilenode returning strlit1195
  params[0] = strlit1195;
  Object opresult1197 = callmethod(opresult1194, "++", 1, params);
// compilenode returning opresult1197
// Begin line 397
  setline(397);
  if (strlit1198 == NULL) {
    strlit1198 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit1198
  params[0] = strlit1198;
  Object opresult1200 = callmethod(opresult1197, "++", 1, params);
// compilenode returning opresult1200
// Begin line 398
  setline(398);
// compilenode returning self
  params[0] = opresult1200;
  Object call1201 = callmethod(self, "out",
    1, params);
// compilenode returning call1201
  if (strlit1202 == NULL) {
    strlit1202 = alloc_String("closureinit");
  }
// compilenode returning strlit1202
// Begin line 399
  setline(399);
// compilenode returning self
  params[0] = strlit1202;
  Object call1203 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1203
  if (strlit1204 == NULL) {
    strlit1204 = alloc_String("  %uo = bitcast %object %self to %UserObject*");
  }
// compilenode returning strlit1204
// Begin line 400
  setline(400);
// compilenode returning self
  params[0] = strlit1204;
  Object call1205 = callmethod(self, "out",
    1, params);
// compilenode returning call1205
    if1176 = call1205;
  }
// compilenode returning if1176
// Begin line 401
  setline(401);
  if (strlit1206 == NULL) {
    strlit1206 = alloc_String("  %closurepp = getelementptr %UserObject* %uo, i32 0, i32 3");
  }
// compilenode returning strlit1206
// Begin line 402
  setline(402);
// compilenode returning self
  params[0] = strlit1206;
  Object call1207 = callmethod(self, "out",
    1, params);
// compilenode returning call1207
  if (strlit1208 == NULL) {
    strlit1208 = alloc_String("  %closurepf = getelementptr [0 x %object]* %closurepp, i32 0, i32 ");
  }
// compilenode returning strlit1208
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult1210 = callmethod(strlit1208, "++", 1, params);
// compilenode returning opresult1210
  if (strlit1211 == NULL) {
    strlit1211 = alloc_String("");
  }
// compilenode returning strlit1211
  params[0] = strlit1211;
  Object opresult1213 = callmethod(opresult1210, "++", 1, params);
// compilenode returning opresult1213
// Begin line 403
  setline(403);
// compilenode returning self
  params[0] = opresult1213;
  Object call1214 = callmethod(self, "out",
    1, params);
// compilenode returning call1214
  if (strlit1215 == NULL) {
    strlit1215 = alloc_String("  %closurepc = bitcast %object* %closurepf to %object***");
  }
// compilenode returning strlit1215
// Begin line 404
  setline(404);
// compilenode returning self
  params[0] = strlit1215;
  Object call1216 = callmethod(self, "out",
    1, params);
// compilenode returning call1216
  if (strlit1217 == NULL) {
    strlit1217 = alloc_String("  %closure = load %object*** %closurepc");
  }
// compilenode returning strlit1217
// Begin line 405
  setline(405);
// compilenode returning self
  params[0] = strlit1217;
  Object call1218 = callmethod(self, "out",
    1, params);
// compilenode returning call1218
  if (strlit1219 == NULL) {
    strlit1219 = alloc_String("  br label %entry");
  }
// compilenode returning strlit1219
// Begin line 406
  setline(406);
// compilenode returning self
  params[0] = strlit1219;
  Object call1220 = callmethod(self, "out",
    1, params);
// compilenode returning call1220
    if1171 = call1220;
  } else {
// Begin line 408
  setline(408);
// Begin line 407
  setline(407);
  if (strlit1221 == NULL) {
    strlit1221 = alloc_String("define private %object ");
  }
// compilenode returning strlit1221
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1223 = callmethod(strlit1221, "++", 1, params);
// compilenode returning opresult1223
  if (strlit1224 == NULL) {
    strlit1224 = alloc_String("(%object %self, i32 %nparams, ");
  }
// compilenode returning strlit1224
  params[0] = strlit1224;
  Object opresult1226 = callmethod(opresult1223, "++", 1, params);
// compilenode returning opresult1226
// Begin line 408
  setline(408);
  if (strlit1227 == NULL) {
    strlit1227 = alloc_String("%object* %args, i32 %flags) {");
  }
// compilenode returning strlit1227
  params[0] = strlit1227;
  Object opresult1229 = callmethod(opresult1226, "++", 1, params);
// compilenode returning opresult1229
// Begin line 409
  setline(409);
// compilenode returning self
  params[0] = opresult1229;
  Object call1230 = callmethod(self, "out",
    1, params);
// compilenode returning call1230
    if1171 = call1230;
  }
// compilenode returning if1171
// Begin line 410
  setline(410);
  if (strlit1231 == NULL) {
    strlit1231 = alloc_String("entry");
  }
// compilenode returning strlit1231
// Begin line 415
  setline(415);
// compilenode returning self
  params[0] = strlit1231;
  Object call1232 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1232
// Begin line 416
  setline(416);
// Begin line 415
  setline(415);
  Object num1233 = alloc_Float64(0.0);
// compilenode returning num1233
  *var_i = num1233;
  if (num1233 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 417
  setline(417);
  Object array1235 = alloc_List();
// compilenode returning array1235
  *var_toremove = array1235;
  if (array1235 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 431
  setline(431);
// Begin line 432
  setline(432);
// Begin line 1429
  setline(1429);
// Begin line 417
  setline(417);
// compilenode returning *var_o
  Object call1237 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call1237
// compilenode returning call1237
// Begin line 431
  setline(431);
// Begin line 1429
  setline(1429);
  Object obj1239 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1239, self, 0);
  addmethod2(obj1239, "outer", &reader_genllvm29_outer_1240);
  adddatum2(obj1239, self, 0);
  block_savedest(obj1239);
  Object **closure1241 = createclosure(5);
  addtoclosure(closure1241, var_closurevars);
  addtoclosure(closure1241, var_i);
  addtoclosure(closure1241, var_toremove);
  addtoclosure(closure1241, var_declaredvars);
  Object *selfpp1307 = alloc_var();
  *selfpp1307 = self;
  addtoclosure(closure1241, selfpp1307);
  struct UserObject *uo1241 = (struct UserObject*)obj1239;
  uo1241->data[1] = (Object)closure1241;
  addmethod2(obj1239, "apply", &meth_genllvm29_apply1241);
  set_type(obj1239, 0);
// compilenode returning obj1239
  setclassname(obj1239, "Block<genllvm29:1238>");
// compilenode returning obj1239
  params[0] = call1237;
  Object iter1236 = callmethod(call1237, "iter", 1, params);
  while(1) {
    Object cond1236 = callmethod(iter1236, "havemore", 0, NULL);
    if (!istrue(cond1236)) break;
    params[0] = callmethod(iter1236, "next", 0, NULL);
    callmethod(obj1239, "apply", 1, params);
  }
// compilenode returning call1237
// Begin line 433
  setline(433);
// Begin line 432
  setline(432);
// compilenode returning *var_closurevars
  *var_origclosurevars = *var_closurevars;
  if (*var_closurevars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 434
  setline(434);
  Object array1308 = alloc_List();
// compilenode returning array1308
  *var_closurevars = array1308;
  if (array1308 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 438
  setline(438);
// Begin line 434
  setline(434);
// compilenode returning *var_origclosurevars
// Begin line 438
  setline(438);
// Begin line 1429
  setline(1429);
  Object obj1312 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1312, self, 0);
  addmethod2(obj1312, "outer", &reader_genllvm29_outer_1313);
  adddatum2(obj1312, self, 0);
  block_savedest(obj1312);
  Object **closure1314 = createclosure(3);
  addtoclosure(closure1314, var_toremove);
  addtoclosure(closure1314, var_closurevars);
  Object *selfpp1318 = alloc_var();
  *selfpp1318 = self;
  addtoclosure(closure1314, selfpp1318);
  struct UserObject *uo1314 = (struct UserObject*)obj1312;
  uo1314->data[1] = (Object)closure1314;
  addmethod2(obj1312, "apply", &meth_genllvm29_apply1314);
  set_type(obj1312, 0);
// compilenode returning obj1312
  setclassname(obj1312, "Block<genllvm29:1311>");
// compilenode returning obj1312
  params[0] = *var_origclosurevars;
  Object iter1310 = callmethod(*var_origclosurevars, "iter", 1, params);
  while(1) {
    Object cond1310 = callmethod(iter1310, "havemore", 0, NULL);
    if (!istrue(cond1310)) break;
    params[0] = callmethod(iter1310, "next", 0, NULL);
    callmethod(obj1312, "apply", 1, params);
  }
// compilenode returning *var_origclosurevars
// Begin line 441
  setline(441);
  if (strlit1319 == NULL) {
    strlit1319 = alloc_String("  %params = alloca %object, i32 ");
  }
// compilenode returning strlit1319
// compilenode returning *var_paramsUsed
  params[0] = *var_paramsUsed;
  Object opresult1321 = callmethod(strlit1319, "++", 1, params);
// compilenode returning opresult1321
// Begin line 442
  setline(442);
// compilenode returning self
  params[0] = opresult1321;
  Object call1322 = callmethod(self, "out",
    1, params);
// compilenode returning call1322
// Begin line 444
  setline(444);
// Begin line 446
  setline(446);
// Begin line 442
  setline(442);
  Object num1324 = alloc_Float64(0.0);
// compilenode returning num1324
// Begin line 446
  setline(446);
// Begin line 442
  setline(442);
// compilenode returning *var_paramsUsed
  Object num1325 = alloc_Float64(1.0);
// compilenode returning num1325
  params[0] = num1325;
  Object diff1327 = callmethod(*var_paramsUsed, "-", 1, params);
// compilenode returning diff1327
  params[0] = diff1327;
  Object opresult1329 = callmethod(num1324, "..", 1, params);
// compilenode returning opresult1329
// Begin line 444
  setline(444);
// Begin line 1429
  setline(1429);
  Object obj1331 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1331, self, 0);
  addmethod2(obj1331, "outer", &reader_genllvm29_outer_1332);
  adddatum2(obj1331, self, 0);
  block_savedest(obj1331);
  Object **closure1333 = createclosure(1);
  Object *selfpp1343 = alloc_var();
  *selfpp1343 = self;
  addtoclosure(closure1333, selfpp1343);
  struct UserObject *uo1333 = (struct UserObject*)obj1331;
  uo1333->data[1] = (Object)closure1333;
  addmethod2(obj1331, "apply", &meth_genllvm29_apply1333);
  set_type(obj1331, 0);
// compilenode returning obj1331
  setclassname(obj1331, "Block<genllvm29:1330>");
// compilenode returning obj1331
  params[0] = opresult1329;
  Object iter1323 = callmethod(opresult1329, "iter", 1, params);
  while(1) {
    Object cond1323 = callmethod(iter1323, "havemore", 0, NULL);
    if (!istrue(cond1323)) break;
    params[0] = callmethod(iter1323, "next", 0, NULL);
    callmethod(obj1331, "apply", 1, params);
  }
// compilenode returning opresult1329
// Begin line 447
  setline(447);
// Begin line 446
  setline(446);
  Object num1344 = alloc_Float64(0.0);
// compilenode returning num1344
  var_j = alloc_var();
  *var_j = num1344;
  if (num1344 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 458
  setline(458);
// Begin line 447
  setline(447);
// compilenode returning *var_closurevars
// Begin line 458
  setline(458);
// Begin line 1429
  setline(1429);
  Object obj1347 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1347, self, 0);
  addmethod2(obj1347, "outer", &reader_genllvm29_outer_1348);
  adddatum2(obj1347, self, 0);
  block_savedest(obj1347);
  Object **closure1349 = createclosure(2);
  addtoclosure(closure1349, var_j);
  Object *selfpp1394 = alloc_var();
  *selfpp1394 = self;
  addtoclosure(closure1349, selfpp1394);
  struct UserObject *uo1349 = (struct UserObject*)obj1347;
  uo1349->data[1] = (Object)closure1349;
  addmethod2(obj1347, "apply", &meth_genllvm29_apply1349);
  set_type(obj1347, 0);
// compilenode returning obj1347
  setclassname(obj1347, "Block<genllvm29:1346>");
// compilenode returning obj1347
  params[0] = *var_closurevars;
  Object iter1345 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1345 = callmethod(iter1345, "havemore", 0, NULL);
    if (!istrue(cond1345)) break;
    params[0] = callmethod(iter1345, "next", 0, NULL);
    callmethod(obj1347, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 460
  setline(460);
// Begin line 459
  setline(459);
// compilenode returning *var_body
// Begin line 460
  setline(460);
// Begin line 1429
  setline(1429);
  Object obj1397 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1397, self, 0);
  addmethod2(obj1397, "outer", &reader_genllvm29_outer_1398);
  adddatum2(obj1397, self, 0);
  block_savedest(obj1397);
  Object **closure1399 = createclosure(1);
  Object *selfpp1401 = alloc_var();
  *selfpp1401 = self;
  addtoclosure(closure1399, selfpp1401);
  struct UserObject *uo1399 = (struct UserObject*)obj1397;
  uo1399->data[1] = (Object)closure1399;
  addmethod2(obj1397, "apply", &meth_genllvm29_apply1399);
  set_type(obj1397, 0);
// compilenode returning obj1397
  setclassname(obj1397, "Block<genllvm29:1396>");
// compilenode returning obj1397
  params[0] = *var_body;
  Object iter1395 = callmethod(*var_body, "iter", 1, params);
  while(1) {
    Object cond1395 = callmethod(iter1395, "havemore", 0, NULL);
    if (!istrue(cond1395)) break;
    params[0] = callmethod(iter1395, "next", 0, NULL);
    callmethod(obj1397, "apply", 1, params);
  }
// compilenode returning *var_body
// Begin line 462
  setline(462);
  if (strlit1402 == NULL) {
    strlit1402 = alloc_String(";;;; ENDS");
  }
// compilenode returning strlit1402
// Begin line 463
  setline(463);
// compilenode returning self
  params[0] = strlit1402;
  Object call1403 = callmethod(self, "out",
    1, params);
// compilenode returning call1403
// Begin line 464
  setline(464);
// Begin line 463
  setline(463);
// compilenode returning *var_output
// Begin line 464
  setline(464);
// Begin line 1429
  setline(1429);
  Object obj1406 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1406, self, 0);
  addmethod2(obj1406, "outer", &reader_genllvm29_outer_1407);
  adddatum2(obj1406, self, 0);
  block_savedest(obj1406);
  Object **closure1408 = createclosure(1);
  Object *selfpp1410 = alloc_var();
  *selfpp1410 = self;
  addtoclosure(closure1408, selfpp1410);
  struct UserObject *uo1408 = (struct UserObject*)obj1406;
  uo1408->data[1] = (Object)closure1408;
  addmethod2(obj1406, "apply", &meth_genllvm29_apply1408);
  set_type(obj1406, 0);
// compilenode returning obj1406
  setclassname(obj1406, "Block<genllvm29:1405>");
// compilenode returning obj1406
  params[0] = *var_output;
  Object iter1404 = callmethod(*var_output, "iter", 1, params);
  while(1) {
    Object cond1404 = callmethod(iter1404, "havemore", 0, NULL);
    if (!istrue(cond1404)) break;
    params[0] = callmethod(iter1404, "next", 0, NULL);
    callmethod(obj1406, "apply", 1, params);
  }
// compilenode returning *var_output
// Begin line 467
  setline(467);
// Begin line 466
  setline(466);
// compilenode returning *var_oldout
  *var_output = *var_oldout;
  if (*var_oldout == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 468
  setline(468);
// Begin line 467
  setline(467);
// compilenode returning *var_oldbblock
  *var_bblock = *var_oldbblock;
  if (*var_oldbblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 469
  setline(469);
// Begin line 468
  setline(468);
// compilenode returning *var_oldusedvars
  *var_usedvars = *var_oldusedvars;
  if (*var_oldusedvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 470
  setline(470);
// Begin line 469
  setline(469);
// compilenode returning *var_olddeclaredvars
  *var_declaredvars = *var_olddeclaredvars;
  if (*var_olddeclaredvars == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 473
  setline(473);
// Begin line 470
  setline(470);
// compilenode returning *var_closurevars
// Begin line 473
  setline(473);
// Begin line 1429
  setline(1429);
  Object obj1417 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1417, self, 0);
  addmethod2(obj1417, "outer", &reader_genllvm29_outer_1418);
  adddatum2(obj1417, self, 0);
  block_savedest(obj1417);
  Object **closure1419 = createclosure(2);
  addtoclosure(closure1419, var_usedvars);
  Object *selfpp1428 = alloc_var();
  *selfpp1428 = self;
  addtoclosure(closure1419, selfpp1428);
  struct UserObject *uo1419 = (struct UserObject*)obj1417;
  uo1419->data[1] = (Object)closure1419;
  addmethod2(obj1417, "apply", &meth_genllvm29_apply1419);
  set_type(obj1417, 0);
// compilenode returning obj1417
  setclassname(obj1417, "Block<genllvm29:1416>");
// compilenode returning obj1417
  params[0] = *var_closurevars;
  Object iter1415 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1415 = callmethod(iter1415, "havemore", 0, NULL);
    if (!istrue(cond1415)) break;
    params[0] = callmethod(iter1415, "next", 0, NULL);
    callmethod(obj1417, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 477
  setline(477);
// compilenode returning *var_name
  Object call1429 = gracelib_length(*var_name);
// compilenode returning call1429
  Object num1430 = alloc_Float64(1.0);
// compilenode returning num1430
  params[0] = num1430;
  Object sum1432 = callmethod(call1429, "+", 1, params);
// compilenode returning sum1432
  var_len = alloc_var();
  *var_len = sum1432;
  if (sum1432 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 480
  setline(480);
// Begin line 478
  setline(478);
  if (strlit1433 == NULL) {
    strlit1433 = alloc_String("@.str.methname");
  }
// compilenode returning strlit1433
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1435 = callmethod(strlit1433, "++", 1, params);
// compilenode returning opresult1435
  if (strlit1436 == NULL) {
    strlit1436 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit1436
  params[0] = strlit1436;
  Object opresult1438 = callmethod(opresult1435, "++", 1, params);
// compilenode returning opresult1438
// Begin line 479
  setline(479);
  if (strlit1439 == NULL) {
    strlit1439 = alloc_String("constant [");
  }
// compilenode returning strlit1439
  params[0] = strlit1439;
  Object opresult1441 = callmethod(opresult1438, "++", 1, params);
// compilenode returning opresult1441
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult1443 = callmethod(opresult1441, "++", 1, params);
// compilenode returning opresult1443
  if (strlit1444 == NULL) {
    strlit1444 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit1444
  params[0] = strlit1444;
  Object opresult1446 = callmethod(opresult1443, "++", 1, params);
// compilenode returning opresult1446
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult1448 = callmethod(opresult1446, "++", 1, params);
// compilenode returning opresult1448
  if (strlit1449 == NULL) {
    strlit1449 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit1449
  params[0] = strlit1449;
  Object opresult1451 = callmethod(opresult1448, "++", 1, params);
// compilenode returning opresult1451
  var_con = alloc_var();
  *var_con = opresult1451;
  if (opresult1451 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 480
  setline(480);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call1452 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call1452
// Begin line 515
  setline(515);
// Begin line 517
  setline(517);
// Begin line 1429
  setline(1429);
// Begin line 481
  setline(481);
// compilenode returning *var_closurevars
  Object call1454 = callmethod(*var_closurevars, "size",
    0, params);
// compilenode returning call1454
// compilenode returning call1454
  Object num1455 = alloc_Float64(0.0);
// compilenode returning num1455
  params[0] = num1455;
  Object opresult1457 = callmethod(call1454, "==", 1, params);
// compilenode returning opresult1457
  Object if1453;
  if (istrue(opresult1457)) {
// Begin line 486
  setline(486);
// Begin line 482
  setline(482);
  if (strlit1458 == NULL) {
    strlit1458 = alloc_String("  call void @addmethod2(%object ");
  }
// compilenode returning strlit1458
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1460 = callmethod(strlit1458, "++", 1, params);
// compilenode returning opresult1460
// Begin line 483
  setline(483);
  if (strlit1461 == NULL) {
    strlit1461 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit1461
  params[0] = strlit1461;
  Object opresult1463 = callmethod(opresult1460, "++", 1, params);
// compilenode returning opresult1463
// Begin line 484
  setline(484);
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult1465 = callmethod(opresult1463, "++", 1, params);
// compilenode returning opresult1465
  if (strlit1466 == NULL) {
    strlit1466 = alloc_String(" x i8]* @.str.methname");
  }
// compilenode returning strlit1466
  params[0] = strlit1466;
  Object opresult1468 = callmethod(opresult1465, "++", 1, params);
// compilenode returning opresult1468
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1470 = callmethod(opresult1468, "++", 1, params);
// compilenode returning opresult1470
  if (strlit1471 == NULL) {
    strlit1471 = alloc_String(", i32 0, i32 0), ");
  }
// compilenode returning strlit1471
  params[0] = strlit1471;
  Object opresult1473 = callmethod(opresult1470, "++", 1, params);
// compilenode returning opresult1473
// Begin line 485
  setline(485);
  if (strlit1474 == NULL) {
    strlit1474 = alloc_String("%object(%object, i32, %object*, i32)* getelementptr(%object ");
  }
// compilenode returning strlit1474
  params[0] = strlit1474;
  Object opresult1476 = callmethod(opresult1473, "++", 1, params);
// compilenode returning opresult1476
// Begin line 486
  setline(486);
  if (strlit1477 == NULL) {
    strlit1477 = alloc_String("(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit1477
  params[0] = strlit1477;
  Object opresult1479 = callmethod(opresult1476, "++", 1, params);
// compilenode returning opresult1479
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1481 = callmethod(opresult1479, "++", 1, params);
// compilenode returning opresult1481
  if (strlit1482 == NULL) {
    strlit1482 = alloc_String("))");
  }
// compilenode returning strlit1482
  params[0] = strlit1482;
  Object opresult1484 = callmethod(opresult1481, "++", 1, params);
// compilenode returning opresult1484
// Begin line 487
  setline(487);
// compilenode returning self
  params[0] = opresult1484;
  Object call1485 = callmethod(self, "out",
    1, params);
// compilenode returning call1485
    if1453 = call1485;
  } else {
  Object *var_uo = alloc_var();
  *var_uo = undefined;
// Begin line 488
  setline(488);
  if (strlit1486 == NULL) {
    strlit1486 = alloc_String("  call void @block_savedest(%object ");
  }
// compilenode returning strlit1486
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1488 = callmethod(strlit1486, "++", 1, params);
// compilenode returning opresult1488
  if (strlit1489 == NULL) {
    strlit1489 = alloc_String(")");
  }
// compilenode returning strlit1489
  params[0] = strlit1489;
  Object opresult1491 = callmethod(opresult1488, "++", 1, params);
// compilenode returning opresult1491
// Begin line 489
  setline(489);
// compilenode returning self
  params[0] = opresult1491;
  Object call1492 = callmethod(self, "out",
    1, params);
// compilenode returning call1492
// Begin line 490
  setline(490);
// Begin line 489
  setline(489);
  if (strlit1493 == NULL) {
    strlit1493 = alloc_String("  %closure");
  }
// compilenode returning strlit1493
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1495 = callmethod(strlit1493, "++", 1, params);
// compilenode returning opresult1495
  if (strlit1496 == NULL) {
    strlit1496 = alloc_String(" = call %object** @createclosure(i32 ");
  }
// compilenode returning strlit1496
  params[0] = strlit1496;
  Object opresult1498 = callmethod(opresult1495, "++", 1, params);
// compilenode returning opresult1498
// Begin line 490
  setline(490);
// Begin line 1429
  setline(1429);
// Begin line 490
  setline(490);
// compilenode returning *var_closurevars
  Object call1499 = callmethod(*var_closurevars, "size",
    0, params);
// compilenode returning call1499
// compilenode returning call1499
  params[0] = call1499;
  Object opresult1501 = callmethod(opresult1498, "++", 1, params);
// compilenode returning opresult1501
  if (strlit1502 == NULL) {
    strlit1502 = alloc_String(")");
  }
// compilenode returning strlit1502
  params[0] = strlit1502;
  Object opresult1504 = callmethod(opresult1501, "++", 1, params);
// compilenode returning opresult1504
// Begin line 491
  setline(491);
// compilenode returning self
  params[0] = opresult1504;
  Object call1505 = callmethod(self, "out",
    1, params);
// compilenode returning call1505
// Begin line 501
  setline(501);
// Begin line 491
  setline(491);
// compilenode returning *var_closurevars
// Begin line 501
  setline(501);
// Begin line 1429
  setline(1429);
  Object obj1508 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1508, self, 0);
  addmethod2(obj1508, "outer", &reader_genllvm29_outer_1509);
  adddatum2(obj1508, self, 0);
  block_savedest(obj1508);
  Object **closure1510 = createclosure(3);
  addtoclosure(closure1510, var_auto_count);
  addtoclosure(closure1510, var_myc);
  Object *selfpp1563 = alloc_var();
  *selfpp1563 = self;
  addtoclosure(closure1510, selfpp1563);
  struct UserObject *uo1510 = (struct UserObject*)obj1508;
  uo1510->data[1] = (Object)closure1510;
  addmethod2(obj1508, "apply", &meth_genllvm29_apply1510);
  set_type(obj1508, 0);
// compilenode returning obj1508
  setclassname(obj1508, "Block<genllvm29:1507>");
// compilenode returning obj1508
  params[0] = *var_closurevars;
  Object iter1506 = callmethod(*var_closurevars, "iter", 1, params);
  while(1) {
    Object cond1506 = callmethod(iter1506, "havemore", 0, NULL);
    if (!istrue(cond1506)) break;
    params[0] = callmethod(iter1506, "next", 0, NULL);
    callmethod(obj1508, "apply", 1, params);
  }
// compilenode returning *var_closurevars
// Begin line 505
  setline(505);
// Begin line 504
  setline(504);
  if (strlit1564 == NULL) {
    strlit1564 = alloc_String("uo");
  }
// compilenode returning strlit1564
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1566 = callmethod(strlit1564, "++", 1, params);
// compilenode returning opresult1566
  if (strlit1567 == NULL) {
    strlit1567 = alloc_String("");
  }
// compilenode returning strlit1567
  params[0] = strlit1567;
  Object opresult1569 = callmethod(opresult1566, "++", 1, params);
// compilenode returning opresult1569
  var_uo = alloc_var();
  *var_uo = opresult1569;
  if (opresult1569 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 505
  setline(505);
  if (strlit1570 == NULL) {
    strlit1570 = alloc_String("  %");
  }
// compilenode returning strlit1570
// compilenode returning *var_uo
  params[0] = *var_uo;
  Object opresult1572 = callmethod(strlit1570, "++", 1, params);
// compilenode returning opresult1572
  if (strlit1573 == NULL) {
    strlit1573 = alloc_String(" = bitcast %object ");
  }
// compilenode returning strlit1573
  params[0] = strlit1573;
  Object opresult1575 = callmethod(opresult1572, "++", 1, params);
// compilenode returning opresult1575
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1577 = callmethod(opresult1575, "++", 1, params);
// compilenode returning opresult1577
  if (strlit1578 == NULL) {
    strlit1578 = alloc_String(" to %UserObject*");
  }
// compilenode returning strlit1578
  params[0] = strlit1578;
  Object opresult1580 = callmethod(opresult1577, "++", 1, params);
// compilenode returning opresult1580
// Begin line 506
  setline(506);
// compilenode returning self
  params[0] = opresult1580;
  Object call1581 = callmethod(self, "out",
    1, params);
// compilenode returning call1581
  if (strlit1582 == NULL) {
    strlit1582 = alloc_String("  %closurepp");
  }
// compilenode returning strlit1582
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1584 = callmethod(strlit1582, "++", 1, params);
// compilenode returning opresult1584
  if (strlit1585 == NULL) {
    strlit1585 = alloc_String(" = getelementptr %UserObject* %");
  }
// compilenode returning strlit1585
  params[0] = strlit1585;
  Object opresult1587 = callmethod(opresult1584, "++", 1, params);
// compilenode returning opresult1587
// compilenode returning *var_uo
  params[0] = *var_uo;
  Object opresult1589 = callmethod(opresult1587, "++", 1, params);
// compilenode returning opresult1589
  if (strlit1590 == NULL) {
    strlit1590 = alloc_String(", i32 0, i32 3");
  }
// compilenode returning strlit1590
  params[0] = strlit1590;
  Object opresult1592 = callmethod(opresult1589, "++", 1, params);
// compilenode returning opresult1592
// Begin line 507
  setline(507);
// compilenode returning self
  params[0] = opresult1592;
  Object call1593 = callmethod(self, "out",
    1, params);
// compilenode returning call1593
  if (strlit1594 == NULL) {
    strlit1594 = alloc_String("  %closurepf");
  }
// compilenode returning strlit1594
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1596 = callmethod(strlit1594, "++", 1, params);
// compilenode returning opresult1596
  if (strlit1597 == NULL) {
    strlit1597 = alloc_String(" = getelementptr [0 x %object]* %closurepp");
  }
// compilenode returning strlit1597
  params[0] = strlit1597;
  Object opresult1599 = callmethod(opresult1596, "++", 1, params);
// compilenode returning opresult1599
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1601 = callmethod(opresult1599, "++", 1, params);
// compilenode returning opresult1601
  if (strlit1602 == NULL) {
    strlit1602 = alloc_String(", i32 0, i32 ");
  }
// compilenode returning strlit1602
  params[0] = strlit1602;
  Object opresult1604 = callmethod(opresult1601, "++", 1, params);
// compilenode returning opresult1604
// compilenode returning *var_pos
  params[0] = *var_pos;
  Object opresult1606 = callmethod(opresult1604, "++", 1, params);
// compilenode returning opresult1606
  if (strlit1607 == NULL) {
    strlit1607 = alloc_String("");
  }
// compilenode returning strlit1607
  params[0] = strlit1607;
  Object opresult1609 = callmethod(opresult1606, "++", 1, params);
// compilenode returning opresult1609
// Begin line 508
  setline(508);
// compilenode returning self
  params[0] = opresult1609;
  Object call1610 = callmethod(self, "out",
    1, params);
// compilenode returning call1610
  if (strlit1611 == NULL) {
    strlit1611 = alloc_String("  %closurepc");
  }
// compilenode returning strlit1611
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1613 = callmethod(strlit1611, "++", 1, params);
// compilenode returning opresult1613
  if (strlit1614 == NULL) {
    strlit1614 = alloc_String(" = bitcast %object* %closurepf");
  }
// compilenode returning strlit1614
  params[0] = strlit1614;
  Object opresult1616 = callmethod(opresult1613, "++", 1, params);
// compilenode returning opresult1616
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1618 = callmethod(opresult1616, "++", 1, params);
// compilenode returning opresult1618
  if (strlit1619 == NULL) {
    strlit1619 = alloc_String(" to %object***");
  }
// compilenode returning strlit1619
  params[0] = strlit1619;
  Object opresult1621 = callmethod(opresult1618, "++", 1, params);
// compilenode returning opresult1621
// Begin line 509
  setline(509);
// compilenode returning self
  params[0] = opresult1621;
  Object call1622 = callmethod(self, "out",
    1, params);
// compilenode returning call1622
  if (strlit1623 == NULL) {
    strlit1623 = alloc_String("  %closurec");
  }
// compilenode returning strlit1623
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1625 = callmethod(strlit1623, "++", 1, params);
// compilenode returning opresult1625
  if (strlit1626 == NULL) {
    strlit1626 = alloc_String(" = bitcast %object** %closure");
  }
// compilenode returning strlit1626
  params[0] = strlit1626;
  Object opresult1628 = callmethod(opresult1625, "++", 1, params);
// compilenode returning opresult1628
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1630 = callmethod(opresult1628, "++", 1, params);
// compilenode returning opresult1630
  if (strlit1631 == NULL) {
    strlit1631 = alloc_String(" to %object");
  }
// compilenode returning strlit1631
  params[0] = strlit1631;
  Object opresult1633 = callmethod(opresult1630, "++", 1, params);
// compilenode returning opresult1633
// Begin line 510
  setline(510);
// compilenode returning self
  params[0] = opresult1633;
  Object call1634 = callmethod(self, "out",
    1, params);
// compilenode returning call1634
  if (strlit1635 == NULL) {
    strlit1635 = alloc_String("  store %object %closurec");
  }
// compilenode returning strlit1635
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1637 = callmethod(strlit1635, "++", 1, params);
// compilenode returning opresult1637
  if (strlit1638 == NULL) {
    strlit1638 = alloc_String(", %object* %closurepf");
  }
// compilenode returning strlit1638
  params[0] = strlit1638;
  Object opresult1640 = callmethod(opresult1637, "++", 1, params);
// compilenode returning opresult1640
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1642 = callmethod(opresult1640, "++", 1, params);
// compilenode returning opresult1642
  if (strlit1643 == NULL) {
    strlit1643 = alloc_String("");
  }
// compilenode returning strlit1643
  params[0] = strlit1643;
  Object opresult1645 = callmethod(opresult1642, "++", 1, params);
// compilenode returning opresult1645
// Begin line 511
  setline(511);
// compilenode returning self
  params[0] = opresult1645;
  Object call1646 = callmethod(self, "out",
    1, params);
// compilenode returning call1646
// Begin line 515
  setline(515);
// Begin line 511
  setline(511);
  if (strlit1647 == NULL) {
    strlit1647 = alloc_String("  call void @addmethod2(%object ");
  }
// compilenode returning strlit1647
// compilenode returning *var_selfobj
  params[0] = *var_selfobj;
  Object opresult1649 = callmethod(strlit1647, "++", 1, params);
// compilenode returning opresult1649
// Begin line 512
  setline(512);
  if (strlit1650 == NULL) {
    strlit1650 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit1650
  params[0] = strlit1650;
  Object opresult1652 = callmethod(opresult1649, "++", 1, params);
// compilenode returning opresult1652
// Begin line 513
  setline(513);
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult1654 = callmethod(opresult1652, "++", 1, params);
// compilenode returning opresult1654
  if (strlit1655 == NULL) {
    strlit1655 = alloc_String(" x i8]* @.str.methname");
  }
// compilenode returning strlit1655
  params[0] = strlit1655;
  Object opresult1657 = callmethod(opresult1654, "++", 1, params);
// compilenode returning opresult1657
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1659 = callmethod(opresult1657, "++", 1, params);
// compilenode returning opresult1659
  if (strlit1660 == NULL) {
    strlit1660 = alloc_String(", i32 0, i32 0), ");
  }
// compilenode returning strlit1660
  params[0] = strlit1660;
  Object opresult1662 = callmethod(opresult1659, "++", 1, params);
// compilenode returning opresult1662
// Begin line 514
  setline(514);
  if (strlit1663 == NULL) {
    strlit1663 = alloc_String("%object(%object, i32, %object*, i32)* getelementptr(%object ");
  }
// compilenode returning strlit1663
  params[0] = strlit1663;
  Object opresult1665 = callmethod(opresult1662, "++", 1, params);
// compilenode returning opresult1665
// Begin line 515
  setline(515);
  if (strlit1666 == NULL) {
    strlit1666 = alloc_String("(%object, i32, %object*, i32)* ");
  }
// compilenode returning strlit1666
  params[0] = strlit1666;
  Object opresult1668 = callmethod(opresult1665, "++", 1, params);
// compilenode returning opresult1668
// compilenode returning *var_litname
  params[0] = *var_litname;
  Object opresult1670 = callmethod(opresult1668, "++", 1, params);
// compilenode returning opresult1670
  if (strlit1671 == NULL) {
    strlit1671 = alloc_String("))");
  }
// compilenode returning strlit1671
  params[0] = strlit1671;
  Object opresult1673 = callmethod(opresult1670, "++", 1, params);
// compilenode returning opresult1673
// Begin line 516
  setline(516);
// compilenode returning self
  params[0] = opresult1673;
  Object call1674 = callmethod(self, "out",
    1, params);
// compilenode returning call1674
    if1453 = call1674;
  }
// compilenode returning if1453
// Begin line 518
  setline(518);
// Begin line 517
  setline(517);
// compilenode returning *var_origInBlock
  *var_inBlock = *var_origInBlock;
  if (*var_origInBlock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 519
  setline(519);
// Begin line 518
  setline(518);
// compilenode returning *var_origParamsUsed
  *var_paramsUsed = *var_origParamsUsed;
  if (*var_origParamsUsed == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1744(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 541
  setline(541);
// Begin line 543
  setline(543);
// Begin line 1429
  setline(1429);
// Begin line 536
  setline(536);
// compilenode returning *var_l
  Object call1746 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1746
// compilenode returning call1746
  if (strlit1747 == NULL) {
    strlit1747 = alloc_String("vardec");
  }
// compilenode returning strlit1747
  params[0] = strlit1747;
  Object opresult1749 = callmethod(call1746, "==", 1, params);
// compilenode returning opresult1749
// Begin line 543
  setline(543);
// Begin line 1429
  setline(1429);
// Begin line 536
  setline(536);
// compilenode returning *var_l
  Object call1750 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1750
// compilenode returning call1750
  if (strlit1751 == NULL) {
    strlit1751 = alloc_String("defdec");
  }
// compilenode returning strlit1751
  params[0] = strlit1751;
  Object opresult1753 = callmethod(call1750, "==", 1, params);
// compilenode returning opresult1753
  params[0] = opresult1753;
  Object opresult1755 = callmethod(opresult1749, "|", 1, params);
// compilenode returning opresult1755
// Begin line 543
  setline(543);
// Begin line 1429
  setline(1429);
// Begin line 537
  setline(537);
// compilenode returning *var_l
  Object call1756 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1756
// compilenode returning call1756
  if (strlit1757 == NULL) {
    strlit1757 = alloc_String("class");
  }
// compilenode returning strlit1757
  params[0] = strlit1757;
  Object opresult1759 = callmethod(call1756, "==", 1, params);
// compilenode returning opresult1759
  params[0] = opresult1759;
  Object opresult1761 = callmethod(opresult1755, "|", 1, params);
// compilenode returning opresult1761
  Object if1745;
  if (istrue(opresult1761)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 538
  setline(538);
// Begin line 1429
  setline(1429);
// Begin line 538
  setline(538);
// Begin line 1429
  setline(1429);
// Begin line 538
  setline(538);
// Begin line 1429
  setline(1429);
// Begin line 538
  setline(538);
// compilenode returning *var_l
  Object call1762 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1762
// compilenode returning call1762
  Object call1763 = callmethod(call1762, "value",
    0, params);
// compilenode returning call1763
// compilenode returning call1763
  Object call1764 = callmethod(call1763, "_escape",
    0, params);
// compilenode returning call1764
// compilenode returning call1764
  var_tnm = alloc_var();
  *var_tnm = call1764;
  if (call1764 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 539
  setline(539);
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1765 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1765
// Begin line 540
  setline(540);
  if (strlit1766 == NULL) {
    strlit1766 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1766
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1768 = callmethod(strlit1766, "++", 1, params);
// compilenode returning opresult1768
  if (strlit1769 == NULL) {
    strlit1769 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit1769
  params[0] = strlit1769;
  Object opresult1771 = callmethod(opresult1768, "++", 1, params);
// compilenode returning opresult1771
// Begin line 541
  setline(541);
// compilenode returning self
  params[0] = opresult1771;
  Object call1772 = callmethod(self, "out",
    1, params);
// compilenode returning call1772
  if (strlit1773 == NULL) {
    strlit1773 = alloc_String("  store %object %undefined, %object* %""\x22""var_");
  }
// compilenode returning strlit1773
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1775 = callmethod(strlit1773, "++", 1, params);
// compilenode returning opresult1775
  if (strlit1776 == NULL) {
    strlit1776 = alloc_String("""\x22""");
  }
// compilenode returning strlit1776
  params[0] = strlit1776;
  Object opresult1778 = callmethod(opresult1775, "++", 1, params);
// compilenode returning opresult1778
// Begin line 542
  setline(542);
// compilenode returning self
  params[0] = opresult1778;
  Object call1779 = callmethod(self, "out",
    1, params);
// compilenode returning call1779
    if1745 = call1779;
  } else {
  }
// compilenode returning if1745
  return if1745;
}
Object meth_genllvm29_apply1786(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_tret = closure[0];
  Object self = *closure[1];
// Begin line 545
  setline(545);
// compilenode returning *var_l
// Begin line 546
  setline(546);
// compilenode returning self
  params[0] = *var_l;
  Object call1787 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1787
  *var_tret = call1787;
  if (call1787 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilewhile1677(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_declaredvars = closure[1];
  Object *var_bblock = closure[2];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_creg = alloc_var();
  *var_creg = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
  Object *var_tblock = alloc_var();
  *var_tblock = undefined;
// Begin line 522
  setline(522);
// Begin line 521
  setline(521);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 523
  setline(523);
// Begin line 522
  setline(522);
// compilenode returning *var_auto_count
  Object num1678 = alloc_Float64(1.0);
// compilenode returning num1678
  params[0] = num1678;
  Object sum1680 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1680
  *var_auto_count = sum1680;
  if (sum1680 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 523
  setline(523);
  if (strlit1682 == NULL) {
    strlit1682 = alloc_String("  br label %BeginWhile");
  }
// compilenode returning strlit1682
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1684 = callmethod(strlit1682, "++", 1, params);
// compilenode returning opresult1684
// Begin line 524
  setline(524);
// compilenode returning self
  params[0] = opresult1684;
  Object call1685 = callmethod(self, "out",
    1, params);
// compilenode returning call1685
  if (strlit1686 == NULL) {
    strlit1686 = alloc_String("BeginWhile");
  }
// compilenode returning strlit1686
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1688 = callmethod(strlit1686, "++", 1, params);
// compilenode returning opresult1688
// Begin line 525
  setline(525);
// compilenode returning self
  params[0] = opresult1688;
  Object call1689 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1689
// Begin line 1429
  setline(1429);
// Begin line 525
  setline(525);
// compilenode returning *var_o
  Object call1690 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1690
// compilenode returning call1690
// Begin line 526
  setline(526);
// compilenode returning self
  params[0] = call1690;
  Object call1691 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1691
  var_cond = alloc_var();
  *var_cond = call1691;
  if (call1691 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 527
  setline(527);
// Begin line 526
  setline(526);
  if (strlit1692 == NULL) {
    strlit1692 = alloc_String("%cond");
  }
// compilenode returning strlit1692
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1694 = callmethod(strlit1692, "++", 1, params);
// compilenode returning opresult1694
  var_creg = alloc_var();
  *var_creg = opresult1694;
  if (opresult1694 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 528
  setline(528);
// Begin line 527
  setline(527);
  if (strlit1695 == NULL) {
    strlit1695 = alloc_String("  ");
  }
// compilenode returning strlit1695
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1697 = callmethod(strlit1695, "++", 1, params);
// compilenode returning opresult1697
  if (strlit1698 == NULL) {
    strlit1698 = alloc_String("_valp = call i1 @istrue(%object ");
  }
// compilenode returning strlit1698
  params[0] = strlit1698;
  Object opresult1700 = callmethod(opresult1697, "++", 1, params);
// compilenode returning opresult1700
// Begin line 528
  setline(528);
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult1702 = callmethod(opresult1700, "++", 1, params);
// compilenode returning opresult1702
  if (strlit1703 == NULL) {
    strlit1703 = alloc_String(")");
  }
// compilenode returning strlit1703
  params[0] = strlit1703;
  Object opresult1705 = callmethod(opresult1702, "++", 1, params);
// compilenode returning opresult1705
// Begin line 529
  setline(529);
// compilenode returning self
  params[0] = opresult1705;
  Object call1706 = callmethod(self, "out",
    1, params);
// compilenode returning call1706
  if (strlit1707 == NULL) {
    strlit1707 = alloc_String("  ");
  }
// compilenode returning strlit1707
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1709 = callmethod(strlit1707, "++", 1, params);
// compilenode returning opresult1709
  if (strlit1710 == NULL) {
    strlit1710 = alloc_String(" = icmp eq i1 0, ");
  }
// compilenode returning strlit1710
  params[0] = strlit1710;
  Object opresult1712 = callmethod(opresult1709, "++", 1, params);
// compilenode returning opresult1712
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1714 = callmethod(opresult1712, "++", 1, params);
// compilenode returning opresult1714
  if (strlit1715 == NULL) {
    strlit1715 = alloc_String("_valp");
  }
// compilenode returning strlit1715
  params[0] = strlit1715;
  Object opresult1717 = callmethod(opresult1714, "++", 1, params);
// compilenode returning opresult1717
// Begin line 530
  setline(530);
// compilenode returning self
  params[0] = opresult1717;
  Object call1718 = callmethod(self, "out",
    1, params);
// compilenode returning call1718
// Begin line 531
  setline(531);
// Begin line 530
  setline(530);
  if (strlit1719 == NULL) {
    strlit1719 = alloc_String("br i1 ");
  }
// compilenode returning strlit1719
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1721 = callmethod(strlit1719, "++", 1, params);
// compilenode returning opresult1721
  if (strlit1722 == NULL) {
    strlit1722 = alloc_String(", label %EndWhile");
  }
// compilenode returning strlit1722
  params[0] = strlit1722;
  Object opresult1724 = callmethod(opresult1721, "++", 1, params);
// compilenode returning opresult1724
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1726 = callmethod(opresult1724, "++", 1, params);
// compilenode returning opresult1726
// Begin line 531
  setline(531);
  if (strlit1727 == NULL) {
    strlit1727 = alloc_String(", label %WhileBody");
  }
// compilenode returning strlit1727
  params[0] = strlit1727;
  Object opresult1729 = callmethod(opresult1726, "++", 1, params);
// compilenode returning opresult1729
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1731 = callmethod(opresult1729, "++", 1, params);
// compilenode returning opresult1731
// Begin line 532
  setline(532);
// compilenode returning self
  params[0] = opresult1731;
  Object call1732 = callmethod(self, "out",
    1, params);
// compilenode returning call1732
  if (strlit1733 == NULL) {
    strlit1733 = alloc_String("WhileBody");
  }
// compilenode returning strlit1733
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1735 = callmethod(strlit1733, "++", 1, params);
// compilenode returning opresult1735
// Begin line 533
  setline(533);
// compilenode returning self
  params[0] = opresult1735;
  Object call1736 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1736
// Begin line 534
  setline(534);
// Begin line 533
  setline(533);
  if (strlit1737 == NULL) {
    strlit1737 = alloc_String("null");
  }
// compilenode returning strlit1737
  var_tret = alloc_var();
  *var_tret = strlit1737;
  if (strlit1737 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 535
  setline(535);
// Begin line 534
  setline(534);
  if (strlit1738 == NULL) {
    strlit1738 = alloc_String("ERROR");
  }
// compilenode returning strlit1738
  var_tblock = alloc_var();
  *var_tblock = strlit1738;
  if (strlit1738 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 541
  setline(541);
// Begin line 544
  setline(544);
// Begin line 1429
  setline(1429);
// Begin line 535
  setline(535);
// compilenode returning *var_o
  Object call1740 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call1740
// compilenode returning call1740
// Begin line 541
  setline(541);
// Begin line 1429
  setline(1429);
  Object obj1742 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1742, self, 0);
  addmethod2(obj1742, "outer", &reader_genllvm29_outer_1743);
  adddatum2(obj1742, self, 0);
  block_savedest(obj1742);
  Object **closure1744 = createclosure(2);
  addtoclosure(closure1744, var_declaredvars);
  Object *selfpp1780 = alloc_var();
  *selfpp1780 = self;
  addtoclosure(closure1744, selfpp1780);
  struct UserObject *uo1744 = (struct UserObject*)obj1742;
  uo1744->data[1] = (Object)closure1744;
  addmethod2(obj1742, "apply", &meth_genllvm29_apply1744);
  set_type(obj1742, 0);
// compilenode returning obj1742
  setclassname(obj1742, "Block<genllvm29:1741>");
// compilenode returning obj1742
  params[0] = call1740;
  Object iter1739 = callmethod(call1740, "iter", 1, params);
  while(1) {
    Object cond1739 = callmethod(iter1739, "havemore", 0, NULL);
    if (!istrue(cond1739)) break;
    params[0] = callmethod(iter1739, "next", 0, NULL);
    callmethod(obj1742, "apply", 1, params);
  }
// compilenode returning call1740
// Begin line 545
  setline(545);
// Begin line 547
  setline(547);
// Begin line 1429
  setline(1429);
// Begin line 544
  setline(544);
// compilenode returning *var_o
  Object call1782 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call1782
// compilenode returning call1782
// Begin line 545
  setline(545);
// Begin line 1429
  setline(1429);
  Object obj1784 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1784, self, 0);
  addmethod2(obj1784, "outer", &reader_genllvm29_outer_1785);
  adddatum2(obj1784, self, 0);
  block_savedest(obj1784);
  Object **closure1786 = createclosure(2);
  addtoclosure(closure1786, var_tret);
  Object *selfpp1789 = alloc_var();
  *selfpp1789 = self;
  addtoclosure(closure1786, selfpp1789);
  struct UserObject *uo1786 = (struct UserObject*)obj1784;
  uo1786->data[1] = (Object)closure1786;
  addmethod2(obj1784, "apply", &meth_genllvm29_apply1786);
  set_type(obj1784, 0);
// compilenode returning obj1784
  setclassname(obj1784, "Block<genllvm29:1783>");
// compilenode returning obj1784
  params[0] = call1782;
  Object iter1781 = callmethod(call1782, "iter", 1, params);
  while(1) {
    Object cond1781 = callmethod(iter1781, "havemore", 0, NULL);
    if (!istrue(cond1781)) break;
    params[0] = callmethod(iter1781, "next", 0, NULL);
    callmethod(obj1784, "apply", 1, params);
  }
// compilenode returning call1782
// Begin line 548
  setline(548);
// Begin line 547
  setline(547);
// compilenode returning *var_bblock
  *var_tblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 548
  setline(548);
  if (strlit1791 == NULL) {
    strlit1791 = alloc_String("  br label %BeginWhile");
  }
// compilenode returning strlit1791
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1793 = callmethod(strlit1791, "++", 1, params);
// compilenode returning opresult1793
// Begin line 549
  setline(549);
// compilenode returning self
  params[0] = opresult1793;
  Object call1794 = callmethod(self, "out",
    1, params);
// compilenode returning call1794
  if (strlit1795 == NULL) {
    strlit1795 = alloc_String("EndWhile");
  }
// compilenode returning strlit1795
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1797 = callmethod(strlit1795, "++", 1, params);
// compilenode returning opresult1797
// Begin line 552
  setline(552);
// compilenode returning self
  params[0] = opresult1797;
  Object call1798 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1798
// Begin line 553
  setline(553);
// Begin line 1429
  setline(1429);
// Begin line 552
  setline(552);
// compilenode returning *var_cond
// compilenode returning *var_o
  params[0] = *var_cond;
  Object call1799 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call1799
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1896(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 584
  setline(584);
// Begin line 586
  setline(586);
// Begin line 1429
  setline(1429);
// Begin line 579
  setline(579);
// compilenode returning *var_l
  Object call1898 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1898
// compilenode returning call1898
  if (strlit1899 == NULL) {
    strlit1899 = alloc_String("vardec");
  }
// compilenode returning strlit1899
  params[0] = strlit1899;
  Object opresult1901 = callmethod(call1898, "==", 1, params);
// compilenode returning opresult1901
// Begin line 586
  setline(586);
// Begin line 1429
  setline(1429);
// Begin line 579
  setline(579);
// compilenode returning *var_l
  Object call1902 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1902
// compilenode returning call1902
  if (strlit1903 == NULL) {
    strlit1903 = alloc_String("defdec");
  }
// compilenode returning strlit1903
  params[0] = strlit1903;
  Object opresult1905 = callmethod(call1902, "==", 1, params);
// compilenode returning opresult1905
  params[0] = opresult1905;
  Object opresult1907 = callmethod(opresult1901, "|", 1, params);
// compilenode returning opresult1907
// Begin line 586
  setline(586);
// Begin line 1429
  setline(1429);
// Begin line 580
  setline(580);
// compilenode returning *var_l
  Object call1908 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1908
// compilenode returning call1908
  if (strlit1909 == NULL) {
    strlit1909 = alloc_String("class");
  }
// compilenode returning strlit1909
  params[0] = strlit1909;
  Object opresult1911 = callmethod(call1908, "==", 1, params);
// compilenode returning opresult1911
  params[0] = opresult1911;
  Object opresult1913 = callmethod(opresult1907, "|", 1, params);
// compilenode returning opresult1913
  Object if1897;
  if (istrue(opresult1913)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 581
  setline(581);
// Begin line 1429
  setline(1429);
// Begin line 581
  setline(581);
// Begin line 1429
  setline(1429);
// Begin line 581
  setline(581);
// Begin line 1429
  setline(1429);
// Begin line 581
  setline(581);
// compilenode returning *var_l
  Object call1914 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1914
// compilenode returning call1914
  Object call1915 = callmethod(call1914, "value",
    0, params);
// compilenode returning call1915
// compilenode returning call1915
  Object call1916 = callmethod(call1915, "_escape",
    0, params);
// compilenode returning call1916
// compilenode returning call1916
  var_tnm = alloc_var();
  *var_tnm = call1916;
  if (call1916 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 582
  setline(582);
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1917 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1917
// Begin line 583
  setline(583);
  if (strlit1918 == NULL) {
    strlit1918 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1918
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1920 = callmethod(strlit1918, "++", 1, params);
// compilenode returning opresult1920
  if (strlit1921 == NULL) {
    strlit1921 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit1921
  params[0] = strlit1921;
  Object opresult1923 = callmethod(opresult1920, "++", 1, params);
// compilenode returning opresult1923
// Begin line 584
  setline(584);
// compilenode returning self
  params[0] = opresult1923;
  Object call1924 = callmethod(self, "out",
    1, params);
// compilenode returning call1924
  if (strlit1925 == NULL) {
    strlit1925 = alloc_String("  store %object %undefined, %object* %""\x22""var_");
  }
// compilenode returning strlit1925
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1927 = callmethod(strlit1925, "++", 1, params);
// compilenode returning opresult1927
  if (strlit1928 == NULL) {
    strlit1928 = alloc_String("""\x22""");
  }
// compilenode returning strlit1928
  params[0] = strlit1928;
  Object opresult1930 = callmethod(opresult1927, "++", 1, params);
// compilenode returning opresult1930
// Begin line 585
  setline(585);
// compilenode returning self
  params[0] = opresult1930;
  Object call1931 = callmethod(self, "out",
    1, params);
// compilenode returning call1931
    if1897 = call1931;
  } else {
  }
// compilenode returning if1897
  return if1897;
}
Object meth_genllvm29_apply1938(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_tret = closure[0];
  Object self = *closure[1];
// Begin line 588
  setline(588);
// compilenode returning *var_l
// Begin line 589
  setline(589);
// compilenode returning self
  params[0] = *var_l;
  Object call1939 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1939
  *var_tret = call1939;
  if (call1939 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply1962(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 600
  setline(600);
// Begin line 602
  setline(602);
// Begin line 1429
  setline(1429);
// Begin line 595
  setline(595);
// compilenode returning *var_l
  Object call1964 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1964
// compilenode returning call1964
  if (strlit1965 == NULL) {
    strlit1965 = alloc_String("vardec");
  }
// compilenode returning strlit1965
  params[0] = strlit1965;
  Object opresult1967 = callmethod(call1964, "==", 1, params);
// compilenode returning opresult1967
// Begin line 602
  setline(602);
// Begin line 1429
  setline(1429);
// Begin line 595
  setline(595);
// compilenode returning *var_l
  Object call1968 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1968
// compilenode returning call1968
  if (strlit1969 == NULL) {
    strlit1969 = alloc_String("defdec");
  }
// compilenode returning strlit1969
  params[0] = strlit1969;
  Object opresult1971 = callmethod(call1968, "==", 1, params);
// compilenode returning opresult1971
  params[0] = opresult1971;
  Object opresult1973 = callmethod(opresult1967, "|", 1, params);
// compilenode returning opresult1973
// Begin line 602
  setline(602);
// Begin line 1429
  setline(1429);
// Begin line 596
  setline(596);
// compilenode returning *var_l
  Object call1974 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call1974
// compilenode returning call1974
  if (strlit1975 == NULL) {
    strlit1975 = alloc_String("class");
  }
// compilenode returning strlit1975
  params[0] = strlit1975;
  Object opresult1977 = callmethod(call1974, "==", 1, params);
// compilenode returning opresult1977
  params[0] = opresult1977;
  Object opresult1979 = callmethod(opresult1973, "|", 1, params);
// compilenode returning opresult1979
  Object if1963;
  if (istrue(opresult1979)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 597
  setline(597);
// Begin line 1429
  setline(1429);
// Begin line 597
  setline(597);
// Begin line 1429
  setline(1429);
// Begin line 597
  setline(597);
// Begin line 1429
  setline(1429);
// Begin line 597
  setline(597);
// compilenode returning *var_l
  Object call1980 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call1980
// compilenode returning call1980
  Object call1981 = callmethod(call1980, "value",
    0, params);
// compilenode returning call1981
// compilenode returning call1981
  Object call1982 = callmethod(call1981, "_escape",
    0, params);
// compilenode returning call1982
// compilenode returning call1982
  var_tnm = alloc_var();
  *var_tnm = call1982;
  if (call1982 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 598
  setline(598);
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call1983 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call1983
// Begin line 599
  setline(599);
  if (strlit1984 == NULL) {
    strlit1984 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit1984
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1986 = callmethod(strlit1984, "++", 1, params);
// compilenode returning opresult1986
  if (strlit1987 == NULL) {
    strlit1987 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit1987
  params[0] = strlit1987;
  Object opresult1989 = callmethod(opresult1986, "++", 1, params);
// compilenode returning opresult1989
// Begin line 600
  setline(600);
// compilenode returning self
  params[0] = opresult1989;
  Object call1990 = callmethod(self, "out",
    1, params);
// compilenode returning call1990
  if (strlit1991 == NULL) {
    strlit1991 = alloc_String("  store %object %undefined, %object* %""\x22""var_");
  }
// compilenode returning strlit1991
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult1993 = callmethod(strlit1991, "++", 1, params);
// compilenode returning opresult1993
  if (strlit1994 == NULL) {
    strlit1994 = alloc_String("""\x22""");
  }
// compilenode returning strlit1994
  params[0] = strlit1994;
  Object opresult1996 = callmethod(opresult1993, "++", 1, params);
// compilenode returning opresult1996
// Begin line 601
  setline(601);
// compilenode returning self
  params[0] = opresult1996;
  Object call1997 = callmethod(self, "out",
    1, params);
// compilenode returning call1997
    if1963 = call1997;
  } else {
  }
// compilenode returning if1963
  return if1963;
}
Object meth_genllvm29_apply2004(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_fret = closure[0];
  Object self = *closure[1];
// Begin line 604
  setline(604);
// compilenode returning *var_l
// Begin line 605
  setline(605);
// compilenode returning self
  params[0] = *var_l;
  Object call2005 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2005
  *var_fret = call2005;
  if (call2005 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileif1800(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_bblock = closure[1];
  Object *var_declaredvars = closure[2];
  Object *var_myc = alloc_var();
  *var_myc = undefined;
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_creg = alloc_var();
  *var_creg = undefined;
  Object *var_startblock = alloc_var();
  *var_startblock = undefined;
  Object *var_tret = alloc_var();
  *var_tret = undefined;
  Object *var_fret = alloc_var();
  *var_fret = undefined;
  Object *var_tblock = alloc_var();
  *var_tblock = undefined;
  Object *var_fblock = alloc_var();
  *var_fblock = undefined;
// Begin line 556
  setline(556);
// Begin line 555
  setline(555);
// compilenode returning *var_auto_count
  var_myc = alloc_var();
  *var_myc = *var_auto_count;
  if (*var_auto_count == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 557
  setline(557);
// Begin line 556
  setline(556);
// compilenode returning *var_auto_count
  Object num1801 = alloc_Float64(1.0);
// compilenode returning num1801
  params[0] = num1801;
  Object sum1803 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum1803
  *var_auto_count = sum1803;
  if (sum1803 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 557
  setline(557);
  if (strlit1805 == NULL) {
    strlit1805 = alloc_String("  br label %BeginIf");
  }
// compilenode returning strlit1805
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1807 = callmethod(strlit1805, "++", 1, params);
// compilenode returning opresult1807
// Begin line 558
  setline(558);
// compilenode returning self
  params[0] = opresult1807;
  Object call1808 = callmethod(self, "out",
    1, params);
// compilenode returning call1808
  if (strlit1809 == NULL) {
    strlit1809 = alloc_String("BeginIf");
  }
// compilenode returning strlit1809
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1811 = callmethod(strlit1809, "++", 1, params);
// compilenode returning opresult1811
// Begin line 559
  setline(559);
// compilenode returning self
  params[0] = opresult1811;
  Object call1812 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1812
// Begin line 1429
  setline(1429);
// Begin line 559
  setline(559);
// compilenode returning *var_o
  Object call1813 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call1813
// compilenode returning call1813
// Begin line 560
  setline(560);
// compilenode returning self
  params[0] = call1813;
  Object call1814 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call1814
  var_cond = alloc_var();
  *var_cond = call1814;
  if (call1814 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 561
  setline(561);
// Begin line 560
  setline(560);
  if (strlit1815 == NULL) {
    strlit1815 = alloc_String("%cond");
  }
// compilenode returning strlit1815
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1817 = callmethod(strlit1815, "++", 1, params);
// compilenode returning opresult1817
  var_creg = alloc_var();
  *var_creg = opresult1817;
  if (opresult1817 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 562
  setline(562);
// Begin line 561
  setline(561);
  if (strlit1818 == NULL) {
    strlit1818 = alloc_String("  ");
  }
// compilenode returning strlit1818
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1820 = callmethod(strlit1818, "++", 1, params);
// compilenode returning opresult1820
  if (strlit1821 == NULL) {
    strlit1821 = alloc_String("_valp = call i1 @istrue(%object ");
  }
// compilenode returning strlit1821
  params[0] = strlit1821;
  Object opresult1823 = callmethod(opresult1820, "++", 1, params);
// compilenode returning opresult1823
// Begin line 562
  setline(562);
// compilenode returning *var_cond
  params[0] = *var_cond;
  Object opresult1825 = callmethod(opresult1823, "++", 1, params);
// compilenode returning opresult1825
  if (strlit1826 == NULL) {
    strlit1826 = alloc_String(")");
  }
// compilenode returning strlit1826
  params[0] = strlit1826;
  Object opresult1828 = callmethod(opresult1825, "++", 1, params);
// compilenode returning opresult1828
// Begin line 563
  setline(563);
// compilenode returning self
  params[0] = opresult1828;
  Object call1829 = callmethod(self, "out",
    1, params);
// compilenode returning call1829
  if (strlit1830 == NULL) {
    strlit1830 = alloc_String("  ");
  }
// compilenode returning strlit1830
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1832 = callmethod(strlit1830, "++", 1, params);
// compilenode returning opresult1832
  if (strlit1833 == NULL) {
    strlit1833 = alloc_String(" = icmp eq i1 0, ");
  }
// compilenode returning strlit1833
  params[0] = strlit1833;
  Object opresult1835 = callmethod(opresult1832, "++", 1, params);
// compilenode returning opresult1835
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1837 = callmethod(opresult1835, "++", 1, params);
// compilenode returning opresult1837
  if (strlit1838 == NULL) {
    strlit1838 = alloc_String("_valp");
  }
// compilenode returning strlit1838
  params[0] = strlit1838;
  Object opresult1840 = callmethod(opresult1837, "++", 1, params);
// compilenode returning opresult1840
// Begin line 564
  setline(564);
// compilenode returning self
  params[0] = opresult1840;
  Object call1841 = callmethod(self, "out",
    1, params);
// compilenode returning call1841
// Begin line 565
  setline(565);
// Begin line 564
  setline(564);
// compilenode returning *var_bblock
  var_startblock = alloc_var();
  *var_startblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 571
  setline(571);
// Begin line 573
  setline(573);
// Begin line 1429
  setline(1429);
// Begin line 573
  setline(573);
// Begin line 1429
  setline(1429);
// Begin line 565
  setline(565);
// compilenode returning *var_o
  Object call1843 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call1843
// compilenode returning call1843
  Object call1844 = callmethod(call1843, "size",
    0, params);
// compilenode returning call1844
// compilenode returning call1844
  Object num1845 = alloc_Float64(0.0);
// compilenode returning num1845
  params[0] = num1845;
  Object opresult1847 = callmethod(call1844, ">", 1, params);
// compilenode returning opresult1847
  Object if1842;
  if (istrue(opresult1847)) {
// Begin line 567
  setline(567);
// Begin line 566
  setline(566);
  if (strlit1848 == NULL) {
    strlit1848 = alloc_String("br i1 ");
  }
// compilenode returning strlit1848
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1850 = callmethod(strlit1848, "++", 1, params);
// compilenode returning opresult1850
  if (strlit1851 == NULL) {
    strlit1851 = alloc_String(", label %FalseBranch");
  }
// compilenode returning strlit1851
  params[0] = strlit1851;
  Object opresult1853 = callmethod(opresult1850, "++", 1, params);
// compilenode returning opresult1853
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1855 = callmethod(opresult1853, "++", 1, params);
// compilenode returning opresult1855
// Begin line 567
  setline(567);
  if (strlit1856 == NULL) {
    strlit1856 = alloc_String(", label %TrueBranch");
  }
// compilenode returning strlit1856
  params[0] = strlit1856;
  Object opresult1858 = callmethod(opresult1855, "++", 1, params);
// compilenode returning opresult1858
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1860 = callmethod(opresult1858, "++", 1, params);
// compilenode returning opresult1860
// Begin line 568
  setline(568);
// compilenode returning self
  params[0] = opresult1860;
  Object call1861 = callmethod(self, "out",
    1, params);
// compilenode returning call1861
    if1842 = call1861;
  } else {
// Begin line 569
  setline(569);
  if (strlit1862 == NULL) {
    strlit1862 = alloc_String("  %undefined");
  }
// compilenode returning strlit1862
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1864 = callmethod(strlit1862, "++", 1, params);
// compilenode returning opresult1864
  if (strlit1865 == NULL) {
    strlit1865 = alloc_String(" = load %object* @undefined");
  }
// compilenode returning strlit1865
  params[0] = strlit1865;
  Object opresult1867 = callmethod(opresult1864, "++", 1, params);
// compilenode returning opresult1867
// Begin line 570
  setline(570);
// compilenode returning self
  params[0] = opresult1867;
  Object call1868 = callmethod(self, "out",
    1, params);
// compilenode returning call1868
// Begin line 571
  setline(571);
// Begin line 570
  setline(570);
  if (strlit1869 == NULL) {
    strlit1869 = alloc_String("br i1 ");
  }
// compilenode returning strlit1869
// compilenode returning *var_creg
  params[0] = *var_creg;
  Object opresult1871 = callmethod(strlit1869, "++", 1, params);
// compilenode returning opresult1871
  if (strlit1872 == NULL) {
    strlit1872 = alloc_String(", label %EndIf");
  }
// compilenode returning strlit1872
  params[0] = strlit1872;
  Object opresult1874 = callmethod(opresult1871, "++", 1, params);
// compilenode returning opresult1874
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1876 = callmethod(opresult1874, "++", 1, params);
// compilenode returning opresult1876
// Begin line 571
  setline(571);
  if (strlit1877 == NULL) {
    strlit1877 = alloc_String(", label %TrueBranch");
  }
// compilenode returning strlit1877
  params[0] = strlit1877;
  Object opresult1879 = callmethod(opresult1876, "++", 1, params);
// compilenode returning opresult1879
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1881 = callmethod(opresult1879, "++", 1, params);
// compilenode returning opresult1881
// Begin line 572
  setline(572);
// compilenode returning self
  params[0] = opresult1881;
  Object call1882 = callmethod(self, "out",
    1, params);
// compilenode returning call1882
    if1842 = call1882;
  }
// compilenode returning if1842
// Begin line 573
  setline(573);
  if (strlit1883 == NULL) {
    strlit1883 = alloc_String("TrueBranch");
  }
// compilenode returning strlit1883
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1885 = callmethod(strlit1883, "++", 1, params);
// compilenode returning opresult1885
// Begin line 574
  setline(574);
// compilenode returning self
  params[0] = opresult1885;
  Object call1886 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1886
// Begin line 575
  setline(575);
// Begin line 574
  setline(574);
  if (strlit1887 == NULL) {
    strlit1887 = alloc_String("%undefined");
  }
// compilenode returning strlit1887
  var_tret = alloc_var();
  *var_tret = strlit1887;
  if (strlit1887 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 576
  setline(576);
// Begin line 575
  setline(575);
  if (strlit1888 == NULL) {
    strlit1888 = alloc_String("%undefined");
  }
// compilenode returning strlit1888
  var_fret = alloc_var();
  *var_fret = strlit1888;
  if (strlit1888 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 577
  setline(577);
// Begin line 576
  setline(576);
  if (strlit1889 == NULL) {
    strlit1889 = alloc_String("ERROR");
  }
// compilenode returning strlit1889
  var_tblock = alloc_var();
  *var_tblock = strlit1889;
  if (strlit1889 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 578
  setline(578);
// Begin line 577
  setline(577);
  if (strlit1890 == NULL) {
    strlit1890 = alloc_String("ERROR");
  }
// compilenode returning strlit1890
  var_fblock = alloc_var();
  *var_fblock = strlit1890;
  if (strlit1890 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 584
  setline(584);
// Begin line 587
  setline(587);
// Begin line 1429
  setline(1429);
// Begin line 578
  setline(578);
// compilenode returning *var_o
  Object call1892 = callmethod(*var_o, "thenblock",
    0, params);
// compilenode returning call1892
// compilenode returning call1892
// Begin line 584
  setline(584);
// Begin line 1429
  setline(1429);
  Object obj1894 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1894, self, 0);
  addmethod2(obj1894, "outer", &reader_genllvm29_outer_1895);
  adddatum2(obj1894, self, 0);
  block_savedest(obj1894);
  Object **closure1896 = createclosure(2);
  addtoclosure(closure1896, var_declaredvars);
  Object *selfpp1932 = alloc_var();
  *selfpp1932 = self;
  addtoclosure(closure1896, selfpp1932);
  struct UserObject *uo1896 = (struct UserObject*)obj1894;
  uo1896->data[1] = (Object)closure1896;
  addmethod2(obj1894, "apply", &meth_genllvm29_apply1896);
  set_type(obj1894, 0);
// compilenode returning obj1894
  setclassname(obj1894, "Block<genllvm29:1893>");
// compilenode returning obj1894
  params[0] = call1892;
  Object iter1891 = callmethod(call1892, "iter", 1, params);
  while(1) {
    Object cond1891 = callmethod(iter1891, "havemore", 0, NULL);
    if (!istrue(cond1891)) break;
    params[0] = callmethod(iter1891, "next", 0, NULL);
    callmethod(obj1894, "apply", 1, params);
  }
// compilenode returning call1892
// Begin line 588
  setline(588);
// Begin line 590
  setline(590);
// Begin line 1429
  setline(1429);
// Begin line 587
  setline(587);
// compilenode returning *var_o
  Object call1934 = callmethod(*var_o, "thenblock",
    0, params);
// compilenode returning call1934
// compilenode returning call1934
// Begin line 588
  setline(588);
// Begin line 1429
  setline(1429);
  Object obj1936 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1936, self, 0);
  addmethod2(obj1936, "outer", &reader_genllvm29_outer_1937);
  adddatum2(obj1936, self, 0);
  block_savedest(obj1936);
  Object **closure1938 = createclosure(2);
  addtoclosure(closure1938, var_tret);
  Object *selfpp1941 = alloc_var();
  *selfpp1941 = self;
  addtoclosure(closure1938, selfpp1941);
  struct UserObject *uo1938 = (struct UserObject*)obj1936;
  uo1938->data[1] = (Object)closure1938;
  addmethod2(obj1936, "apply", &meth_genllvm29_apply1938);
  set_type(obj1936, 0);
// compilenode returning obj1936
  setclassname(obj1936, "Block<genllvm29:1935>");
// compilenode returning obj1936
  params[0] = call1934;
  Object iter1933 = callmethod(call1934, "iter", 1, params);
  while(1) {
    Object cond1933 = callmethod(iter1933, "havemore", 0, NULL);
    if (!istrue(cond1933)) break;
    params[0] = callmethod(iter1933, "next", 0, NULL);
    callmethod(obj1936, "apply", 1, params);
  }
// compilenode returning call1934
// Begin line 591
  setline(591);
// Begin line 590
  setline(590);
// compilenode returning *var_bblock
  *var_tblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 591
  setline(591);
  if (strlit1943 == NULL) {
    strlit1943 = alloc_String("  br label %EndIf");
  }
// compilenode returning strlit1943
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1945 = callmethod(strlit1943, "++", 1, params);
// compilenode returning opresult1945
// Begin line 592
  setline(592);
// compilenode returning self
  params[0] = opresult1945;
  Object call1946 = callmethod(self, "out",
    1, params);
// compilenode returning call1946
// Begin line 608
  setline(608);
// Begin line 609
  setline(609);
// Begin line 1429
  setline(1429);
// Begin line 609
  setline(609);
// Begin line 1429
  setline(1429);
// Begin line 592
  setline(592);
// compilenode returning *var_o
  Object call1948 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call1948
// compilenode returning call1948
  Object call1949 = callmethod(call1948, "size",
    0, params);
// compilenode returning call1949
// compilenode returning call1949
  Object num1950 = alloc_Float64(0.0);
// compilenode returning num1950
  params[0] = num1950;
  Object opresult1952 = callmethod(call1949, ">", 1, params);
// compilenode returning opresult1952
  Object if1947;
  if (istrue(opresult1952)) {
// Begin line 593
  setline(593);
  if (strlit1953 == NULL) {
    strlit1953 = alloc_String("FalseBranch");
  }
// compilenode returning strlit1953
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult1955 = callmethod(strlit1953, "++", 1, params);
// compilenode returning opresult1955
// Begin line 594
  setline(594);
// compilenode returning self
  params[0] = opresult1955;
  Object call1956 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call1956
// Begin line 600
  setline(600);
// Begin line 603
  setline(603);
// Begin line 1429
  setline(1429);
// Begin line 594
  setline(594);
// compilenode returning *var_o
  Object call1958 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call1958
// compilenode returning call1958
// Begin line 600
  setline(600);
// Begin line 1429
  setline(1429);
  Object obj1960 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1960, self, 0);
  addmethod2(obj1960, "outer", &reader_genllvm29_outer_1961);
  adddatum2(obj1960, self, 0);
  block_savedest(obj1960);
  Object **closure1962 = createclosure(2);
  addtoclosure(closure1962, var_declaredvars);
  Object *selfpp1998 = alloc_var();
  *selfpp1998 = self;
  addtoclosure(closure1962, selfpp1998);
  struct UserObject *uo1962 = (struct UserObject*)obj1960;
  uo1962->data[1] = (Object)closure1962;
  addmethod2(obj1960, "apply", &meth_genllvm29_apply1962);
  set_type(obj1960, 0);
// compilenode returning obj1960
  setclassname(obj1960, "Block<genllvm29:1959>");
// compilenode returning obj1960
  params[0] = call1958;
  Object iter1957 = callmethod(call1958, "iter", 1, params);
  while(1) {
    Object cond1957 = callmethod(iter1957, "havemore", 0, NULL);
    if (!istrue(cond1957)) break;
    params[0] = callmethod(iter1957, "next", 0, NULL);
    callmethod(obj1960, "apply", 1, params);
  }
// compilenode returning call1958
// Begin line 604
  setline(604);
// Begin line 606
  setline(606);
// Begin line 1429
  setline(1429);
// Begin line 603
  setline(603);
// compilenode returning *var_o
  Object call2000 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call2000
// compilenode returning call2000
// Begin line 604
  setline(604);
// Begin line 1429
  setline(1429);
  Object obj2002 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2002, self, 0);
  addmethod2(obj2002, "outer", &reader_genllvm29_outer_2003);
  adddatum2(obj2002, self, 0);
  block_savedest(obj2002);
  Object **closure2004 = createclosure(2);
  addtoclosure(closure2004, var_fret);
  Object *selfpp2007 = alloc_var();
  *selfpp2007 = self;
  addtoclosure(closure2004, selfpp2007);
  struct UserObject *uo2004 = (struct UserObject*)obj2002;
  uo2004->data[1] = (Object)closure2004;
  addmethod2(obj2002, "apply", &meth_genllvm29_apply2004);
  set_type(obj2002, 0);
// compilenode returning obj2002
  setclassname(obj2002, "Block<genllvm29:2001>");
// compilenode returning obj2002
  params[0] = call2000;
  Object iter1999 = callmethod(call2000, "iter", 1, params);
  while(1) {
    Object cond1999 = callmethod(iter1999, "havemore", 0, NULL);
    if (!istrue(cond1999)) break;
    params[0] = callmethod(iter1999, "next", 0, NULL);
    callmethod(obj2002, "apply", 1, params);
  }
// compilenode returning call2000
// Begin line 606
  setline(606);
  if (strlit2008 == NULL) {
    strlit2008 = alloc_String("  br label %EndIf");
  }
// compilenode returning strlit2008
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult2010 = callmethod(strlit2008, "++", 1, params);
// compilenode returning opresult2010
// Begin line 607
  setline(607);
// compilenode returning self
  params[0] = opresult2010;
  Object call2011 = callmethod(self, "out",
    1, params);
// compilenode returning call2011
// Begin line 608
  setline(608);
// Begin line 607
  setline(607);
// compilenode returning *var_bblock
  *var_fblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1947 = nothing;
  } else {
  }
// compilenode returning if1947
// Begin line 609
  setline(609);
  if (strlit2013 == NULL) {
    strlit2013 = alloc_String("EndIf");
  }
// compilenode returning strlit2013
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult2015 = callmethod(strlit2013, "++", 1, params);
// compilenode returning opresult2015
// Begin line 610
  setline(610);
// compilenode returning self
  params[0] = opresult2015;
  Object call2016 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2016
// Begin line 615
  setline(615);
// Begin line 617
  setline(617);
// Begin line 1429
  setline(1429);
// Begin line 617
  setline(617);
// Begin line 1429
  setline(1429);
// Begin line 610
  setline(610);
// compilenode returning *var_o
  Object call2018 = callmethod(*var_o, "elseblock",
    0, params);
// compilenode returning call2018
// compilenode returning call2018
  Object call2019 = callmethod(call2018, "size",
    0, params);
// compilenode returning call2019
// compilenode returning call2019
  Object num2020 = alloc_Float64(0.0);
// compilenode returning num2020
  params[0] = num2020;
  Object opresult2022 = callmethod(call2019, ">", 1, params);
// compilenode returning opresult2022
  Object if2017;
  if (istrue(opresult2022)) {
// Begin line 612
  setline(612);
// Begin line 611
  setline(611);
  if (strlit2023 == NULL) {
    strlit2023 = alloc_String("  %if");
  }
// compilenode returning strlit2023
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult2025 = callmethod(strlit2023, "++", 1, params);
// compilenode returning opresult2025
  if (strlit2026 == NULL) {
    strlit2026 = alloc_String(" = phi %object [ ");
  }
// compilenode returning strlit2026
  params[0] = strlit2026;
  Object opresult2028 = callmethod(opresult2025, "++", 1, params);
// compilenode returning opresult2028
// compilenode returning *var_tret
  params[0] = *var_tret;
  Object opresult2030 = callmethod(opresult2028, "++", 1, params);
// compilenode returning opresult2030
  if (strlit2031 == NULL) {
    strlit2031 = alloc_String(", ");
  }
// compilenode returning strlit2031
  params[0] = strlit2031;
  Object opresult2033 = callmethod(opresult2030, "++", 1, params);
// compilenode returning opresult2033
// Begin line 612
  setline(612);
// compilenode returning *var_tblock
  params[0] = *var_tblock;
  Object opresult2035 = callmethod(opresult2033, "++", 1, params);
// compilenode returning opresult2035
  if (strlit2036 == NULL) {
    strlit2036 = alloc_String("], [");
  }
// compilenode returning strlit2036
  params[0] = strlit2036;
  Object opresult2038 = callmethod(opresult2035, "++", 1, params);
// compilenode returning opresult2038
// compilenode returning *var_fret
  params[0] = *var_fret;
  Object opresult2040 = callmethod(opresult2038, "++", 1, params);
// compilenode returning opresult2040
  if (strlit2041 == NULL) {
    strlit2041 = alloc_String(", ");
  }
// compilenode returning strlit2041
  params[0] = strlit2041;
  Object opresult2043 = callmethod(opresult2040, "++", 1, params);
// compilenode returning opresult2043
// compilenode returning *var_fblock
  params[0] = *var_fblock;
  Object opresult2045 = callmethod(opresult2043, "++", 1, params);
// compilenode returning opresult2045
  if (strlit2046 == NULL) {
    strlit2046 = alloc_String("]");
  }
// compilenode returning strlit2046
  params[0] = strlit2046;
  Object opresult2048 = callmethod(opresult2045, "++", 1, params);
// compilenode returning opresult2048
// Begin line 613
  setline(613);
// compilenode returning self
  params[0] = opresult2048;
  Object call2049 = callmethod(self, "out",
    1, params);
// compilenode returning call2049
    if2017 = call2049;
  } else {
// Begin line 615
  setline(615);
// Begin line 614
  setline(614);
  if (strlit2050 == NULL) {
    strlit2050 = alloc_String("  %if");
  }
// compilenode returning strlit2050
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult2052 = callmethod(strlit2050, "++", 1, params);
// compilenode returning opresult2052
  if (strlit2053 == NULL) {
    strlit2053 = alloc_String(" = phi %object [ ");
  }
// compilenode returning strlit2053
  params[0] = strlit2053;
  Object opresult2055 = callmethod(opresult2052, "++", 1, params);
// compilenode returning opresult2055
// compilenode returning *var_tret
  params[0] = *var_tret;
  Object opresult2057 = callmethod(opresult2055, "++", 1, params);
// compilenode returning opresult2057
  if (strlit2058 == NULL) {
    strlit2058 = alloc_String(", ");
  }
// compilenode returning strlit2058
  params[0] = strlit2058;
  Object opresult2060 = callmethod(opresult2057, "++", 1, params);
// compilenode returning opresult2060
// Begin line 615
  setline(615);
// compilenode returning *var_tblock
  params[0] = *var_tblock;
  Object opresult2062 = callmethod(opresult2060, "++", 1, params);
// compilenode returning opresult2062
  if (strlit2063 == NULL) {
    strlit2063 = alloc_String("], [%undefined");
  }
// compilenode returning strlit2063
  params[0] = strlit2063;
  Object opresult2065 = callmethod(opresult2062, "++", 1, params);
// compilenode returning opresult2065
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult2067 = callmethod(opresult2065, "++", 1, params);
// compilenode returning opresult2067
  if (strlit2068 == NULL) {
    strlit2068 = alloc_String(", ");
  }
// compilenode returning strlit2068
  params[0] = strlit2068;
  Object opresult2070 = callmethod(opresult2067, "++", 1, params);
// compilenode returning opresult2070
// compilenode returning *var_startblock
  params[0] = *var_startblock;
  Object opresult2072 = callmethod(opresult2070, "++", 1, params);
// compilenode returning opresult2072
  if (strlit2073 == NULL) {
    strlit2073 = alloc_String("]");
  }
// compilenode returning strlit2073
  params[0] = strlit2073;
  Object opresult2075 = callmethod(opresult2072, "++", 1, params);
// compilenode returning opresult2075
// Begin line 616
  setline(616);
// compilenode returning self
  params[0] = opresult2075;
  Object call2076 = callmethod(self, "out",
    1, params);
// compilenode returning call2076
    if2017 = call2076;
  }
// compilenode returning if2017
// Begin line 618
  setline(618);
// Begin line 1429
  setline(1429);
// Begin line 618
  setline(618);
// Begin line 617
  setline(617);
  if (strlit2077 == NULL) {
    strlit2077 = alloc_String("%if");
  }
// compilenode returning strlit2077
// compilenode returning *var_myc
  params[0] = *var_myc;
  Object opresult2079 = callmethod(strlit2077, "++", 1, params);
// compilenode returning opresult2079
// compilenode returning *var_o
  params[0] = opresult2079;
  Object call2080 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2080
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileidentifier2081(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_modules = closure[1];
  Object *var_usedvars = closure[2];
  Object *var_name = alloc_var();
  *var_name = undefined;
// Begin line 621
  setline(621);
// Begin line 1429
  setline(1429);
// Begin line 620
  setline(620);
// compilenode returning *var_o
  Object call2082 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2082
// compilenode returning call2082
  var_name = alloc_var();
  *var_name = call2082;
  if (call2082 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 642
  setline(642);
// Begin line 643
  setline(643);
// Begin line 621
  setline(621);
// compilenode returning *var_name
  if (strlit2084 == NULL) {
    strlit2084 = alloc_String("self");
  }
// compilenode returning strlit2084
  params[0] = strlit2084;
  Object opresult2086 = callmethod(*var_name, "==", 1, params);
// compilenode returning opresult2086
  Object if2083;
  if (istrue(opresult2086)) {
// Begin line 623
  setline(623);
// Begin line 1429
  setline(1429);
// Begin line 622
  setline(622);
  if (strlit2087 == NULL) {
    strlit2087 = alloc_String("%self");
  }
// compilenode returning strlit2087
// compilenode returning *var_o
  params[0] = strlit2087;
  Object call2088 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2088
// compilenode returning nothing
    if2083 = nothing;
  } else {
// Begin line 642
  setline(642);
// Begin line 630
  setline(630);
// Begin line 623
  setline(623);
// compilenode returning *var_name
  if (strlit2090 == NULL) {
    strlit2090 = alloc_String("__compilerRevision");
  }
// compilenode returning strlit2090
  params[0] = strlit2090;
  Object opresult2092 = callmethod(*var_name, "==", 1, params);
// compilenode returning opresult2092
  Object if2089;
  if (istrue(opresult2092)) {
// Begin line 625
  setline(625);
// Begin line 624
  setline(624);
  if (strlit2093 == NULL) {
    strlit2093 = alloc_String("%str___compilerRevision");
  }
// compilenode returning strlit2093
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2095 = callmethod(strlit2093, "++", 1, params);
// compilenode returning opresult2095
// Begin line 625
  setline(625);
  if (strlit2096 == NULL) {
    strlit2096 = alloc_String(" = bitcast [41 x i8]* @.str._compilerRevision to i8*");
  }
// compilenode returning strlit2096
  params[0] = strlit2096;
  Object opresult2098 = callmethod(opresult2095, "++", 1, params);
// compilenode returning opresult2098
// Begin line 626
  setline(626);
// compilenode returning self
  params[0] = opresult2098;
  Object call2099 = callmethod(self, "out",
    1, params);
// compilenode returning call2099
// Begin line 628
  setline(628);
// Begin line 626
  setline(626);
  if (strlit2100 == NULL) {
    strlit2100 = alloc_String("%""\x22""var_val___compilerRevision");
  }
// compilenode returning strlit2100
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2102 = callmethod(strlit2100, "++", 1, params);
// compilenode returning opresult2102
// Begin line 627
  setline(627);
  if (strlit2103 == NULL) {
    strlit2103 = alloc_String("""\x22"" = call %object @alloc_String(i8* %str___compilerRevision");
  }
// compilenode returning strlit2103
  params[0] = strlit2103;
  Object opresult2105 = callmethod(opresult2102, "++", 1, params);
// compilenode returning opresult2105
// Begin line 628
  setline(628);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2107 = callmethod(opresult2105, "++", 1, params);
// compilenode returning opresult2107
  if (strlit2108 == NULL) {
    strlit2108 = alloc_String(")");
  }
// compilenode returning strlit2108
  params[0] = strlit2108;
  Object opresult2110 = callmethod(opresult2107, "++", 1, params);
// compilenode returning opresult2110
// Begin line 629
  setline(629);
// compilenode returning self
  params[0] = opresult2110;
  Object call2111 = callmethod(self, "out",
    1, params);
// compilenode returning call2111
// Begin line 630
  setline(630);
// Begin line 1429
  setline(1429);
// Begin line 630
  setline(630);
// Begin line 629
  setline(629);
  if (strlit2112 == NULL) {
    strlit2112 = alloc_String("%""\x22""var_val___compilerRevision");
  }
// compilenode returning strlit2112
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2114 = callmethod(strlit2112, "++", 1, params);
// compilenode returning opresult2114
  if (strlit2115 == NULL) {
    strlit2115 = alloc_String("""\x22""");
  }
// compilenode returning strlit2115
  params[0] = strlit2115;
  Object opresult2117 = callmethod(opresult2114, "++", 1, params);
// compilenode returning opresult2117
// compilenode returning *var_o
  params[0] = opresult2117;
  Object call2118 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2118
// compilenode returning nothing
    if2089 = nothing;
  } else {
// Begin line 631
  setline(631);
// Begin line 1429
  setline(1429);
// Begin line 631
  setline(631);
// compilenode returning *var_name
  Object call2119 = callmethod(*var_name, "_escape",
    0, params);
// compilenode returning call2119
// compilenode returning call2119
  *var_name = call2119;
  if (call2119 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 638
  setline(638);
// Begin line 632
  setline(632);
// compilenode returning *var_name
// compilenode returning *var_modules
  params[0] = *var_name;
  Object call2122 = callmethod(*var_modules, "contains",
    1, params);
// compilenode returning call2122
  Object if2121;
  if (istrue(call2122)) {
// Begin line 634
  setline(634);
// Begin line 633
  setline(633);
  if (strlit2123 == NULL) {
    strlit2123 = alloc_String("  %""\x22""var_val_");
  }
// compilenode returning strlit2123
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult2125 = callmethod(strlit2123, "++", 1, params);
// compilenode returning opresult2125
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2127 = callmethod(opresult2125, "++", 1, params);
// compilenode returning opresult2127
// Begin line 634
  setline(634);
  if (strlit2128 == NULL) {
    strlit2128 = alloc_String("""\x22"" = load %object* @.module.");
  }
// compilenode returning strlit2128
  params[0] = strlit2128;
  Object opresult2130 = callmethod(opresult2127, "++", 1, params);
// compilenode returning opresult2130
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult2132 = callmethod(opresult2130, "++", 1, params);
// compilenode returning opresult2132
// Begin line 635
  setline(635);
// compilenode returning self
  params[0] = opresult2132;
  Object call2133 = callmethod(self, "out",
    1, params);
// compilenode returning call2133
    if2121 = call2133;
  } else {
// Begin line 636
  setline(636);
// compilenode returning *var_name
// compilenode returning *var_usedvars
  params[0] = *var_name;
  Object call2134 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call2134
// Begin line 638
  setline(638);
// Begin line 637
  setline(637);
  if (strlit2135 == NULL) {
    strlit2135 = alloc_String("  %""\x22""var_val_");
  }
// compilenode returning strlit2135
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult2137 = callmethod(strlit2135, "++", 1, params);
// compilenode returning opresult2137
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2139 = callmethod(opresult2137, "++", 1, params);
// compilenode returning opresult2139
  if (strlit2140 == NULL) {
    strlit2140 = alloc_String("""\x22"" = load %object* ");
  }
// compilenode returning strlit2140
  params[0] = strlit2140;
  Object opresult2142 = callmethod(opresult2139, "++", 1, params);
// compilenode returning opresult2142
// Begin line 638
  setline(638);
  if (strlit2143 == NULL) {
    strlit2143 = alloc_String("%""\x22""var_");
  }
// compilenode returning strlit2143
  params[0] = strlit2143;
  Object opresult2145 = callmethod(opresult2142, "++", 1, params);
// compilenode returning opresult2145
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult2147 = callmethod(opresult2145, "++", 1, params);
// compilenode returning opresult2147
  if (strlit2148 == NULL) {
    strlit2148 = alloc_String("""\x22""");
  }
// compilenode returning strlit2148
  params[0] = strlit2148;
  Object opresult2150 = callmethod(opresult2147, "++", 1, params);
// compilenode returning opresult2150
// Begin line 639
  setline(639);
// compilenode returning self
  params[0] = opresult2150;
  Object call2151 = callmethod(self, "out",
    1, params);
// compilenode returning call2151
    if2121 = call2151;
  }
// compilenode returning if2121
// Begin line 641
  setline(641);
// Begin line 1429
  setline(1429);
// Begin line 641
  setline(641);
// Begin line 640
  setline(640);
  if (strlit2152 == NULL) {
    strlit2152 = alloc_String("%""\x22""var_val_");
  }
// compilenode returning strlit2152
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult2154 = callmethod(strlit2152, "++", 1, params);
// compilenode returning opresult2154
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2156 = callmethod(opresult2154, "++", 1, params);
// compilenode returning opresult2156
  if (strlit2157 == NULL) {
    strlit2157 = alloc_String("""\x22""");
  }
// compilenode returning strlit2157
  params[0] = strlit2157;
  Object opresult2159 = callmethod(opresult2156, "++", 1, params);
// compilenode returning opresult2159
// compilenode returning *var_o
  params[0] = opresult2159;
  Object call2160 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2160
// compilenode returning nothing
// Begin line 642
  setline(642);
// Begin line 641
  setline(641);
// compilenode returning *var_auto_count
  Object num2161 = alloc_Float64(1.0);
// compilenode returning num2161
  params[0] = num2161;
  Object sum2163 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2163
  *var_auto_count = sum2163;
  if (sum2163 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2089 = nothing;
  }
// compilenode returning if2089
    if2083 = if2089;
  }
// compilenode returning if2083
  return if2083;
}
Object meth_genllvm29_compilebind2165(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[18];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_usedvars = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_dest = alloc_var();
  *var_dest = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_c = alloc_var();
  *var_c = undefined;
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 646
  setline(646);
// Begin line 1429
  setline(1429);
// Begin line 645
  setline(645);
// compilenode returning *var_o
  Object call2166 = callmethod(*var_o, "dest",
    0, params);
// compilenode returning call2166
// compilenode returning call2166
  var_dest = alloc_var();
  *var_dest = call2166;
  if (call2166 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 647
  setline(647);
// Begin line 646
  setline(646);
  if (strlit2167 == NULL) {
    strlit2167 = alloc_String("");
  }
// compilenode returning strlit2167
  var_val = alloc_var();
  *var_val = strlit2167;
  if (strlit2167 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 648
  setline(648);
// Begin line 647
  setline(647);
  if (strlit2168 == NULL) {
    strlit2168 = alloc_String("");
  }
// compilenode returning strlit2168
  var_c = alloc_var();
  *var_c = strlit2168;
  if (strlit2168 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 649
  setline(649);
// Begin line 648
  setline(648);
  if (strlit2169 == NULL) {
    strlit2169 = alloc_String("");
  }
// compilenode returning strlit2169
  var_r = alloc_var();
  *var_r = strlit2169;
  if (strlit2169 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 677
  setline(677);
// Begin line 678
  setline(678);
// Begin line 1429
  setline(1429);
// Begin line 649
  setline(649);
// compilenode returning *var_dest
  Object call2171 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call2171
// compilenode returning call2171
  if (strlit2172 == NULL) {
    strlit2172 = alloc_String("identifier");
  }
// compilenode returning strlit2172
  params[0] = strlit2172;
  Object opresult2174 = callmethod(call2171, "==", 1, params);
// compilenode returning opresult2174
  Object if2170;
  if (istrue(opresult2174)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
// Begin line 651
  setline(651);
// Begin line 1429
  setline(1429);
// Begin line 650
  setline(650);
// compilenode returning *var_o
  Object call2175 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2175
// compilenode returning call2175
  *var_val = call2175;
  if (call2175 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 651
  setline(651);
// compilenode returning *var_val
// Begin line 652
  setline(652);
// compilenode returning self
  params[0] = *var_val;
  Object call2177 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2177
  *var_val = call2177;
  if (call2177 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1429
  setline(1429);
// Begin line 652
  setline(652);
// Begin line 1429
  setline(1429);
// Begin line 652
  setline(652);
// compilenode returning *var_dest
  Object call2179 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call2179
// compilenode returning call2179
  Object call2180 = callmethod(call2179, "_escape",
    0, params);
// compilenode returning call2180
// compilenode returning call2180
  var_nm = alloc_var();
  *var_nm = call2180;
  if (call2180 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 653
  setline(653);
// compilenode returning *var_nm
// compilenode returning *var_usedvars
  params[0] = *var_nm;
  Object call2181 = callmethod(*var_usedvars, "push",
    1, params);
// compilenode returning call2181
// Begin line 654
  setline(654);
  if (strlit2182 == NULL) {
    strlit2182 = alloc_String("  store %object ");
  }
// compilenode returning strlit2182
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2184 = callmethod(strlit2182, "++", 1, params);
// compilenode returning opresult2184
  if (strlit2185 == NULL) {
    strlit2185 = alloc_String(", %object* %""\x22""var_");
  }
// compilenode returning strlit2185
  params[0] = strlit2185;
  Object opresult2187 = callmethod(opresult2184, "++", 1, params);
// compilenode returning opresult2187
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2189 = callmethod(opresult2187, "++", 1, params);
// compilenode returning opresult2189
  if (strlit2190 == NULL) {
    strlit2190 = alloc_String("""\x22""");
  }
// compilenode returning strlit2190
  params[0] = strlit2190;
  Object opresult2192 = callmethod(opresult2189, "++", 1, params);
// compilenode returning opresult2192
// Begin line 655
  setline(655);
// compilenode returning self
  params[0] = opresult2192;
  Object call2193 = callmethod(self, "out",
    1, params);
// compilenode returning call2193
  if (strlit2194 == NULL) {
    strlit2194 = alloc_String("  %icmp");
  }
// compilenode returning strlit2194
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2196 = callmethod(strlit2194, "++", 1, params);
// compilenode returning opresult2196
  if (strlit2197 == NULL) {
    strlit2197 = alloc_String(" = icmp eq %object ");
  }
// compilenode returning strlit2197
  params[0] = strlit2197;
  Object opresult2199 = callmethod(opresult2196, "++", 1, params);
// compilenode returning opresult2199
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2201 = callmethod(opresult2199, "++", 1, params);
// compilenode returning opresult2201
  if (strlit2202 == NULL) {
    strlit2202 = alloc_String(", %undefined");
  }
// compilenode returning strlit2202
  params[0] = strlit2202;
  Object opresult2204 = callmethod(opresult2201, "++", 1, params);
// compilenode returning opresult2204
// Begin line 656
  setline(656);
// compilenode returning self
  params[0] = opresult2204;
  Object call2205 = callmethod(self, "out",
    1, params);
// compilenode returning call2205
// Begin line 657
  setline(657);
// Begin line 656
  setline(656);
  if (strlit2206 == NULL) {
    strlit2206 = alloc_String("  br i1 %icmp");
  }
// compilenode returning strlit2206
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2208 = callmethod(strlit2206, "++", 1, params);
// compilenode returning opresult2208
  if (strlit2209 == NULL) {
    strlit2209 = alloc_String(", label %isundef");
  }
// compilenode returning strlit2209
  params[0] = strlit2209;
  Object opresult2211 = callmethod(opresult2208, "++", 1, params);
// compilenode returning opresult2211
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2213 = callmethod(opresult2211, "++", 1, params);
// compilenode returning opresult2213
  if (strlit2214 == NULL) {
    strlit2214 = alloc_String(", ");
  }
// compilenode returning strlit2214
  params[0] = strlit2214;
  Object opresult2216 = callmethod(opresult2213, "++", 1, params);
// compilenode returning opresult2216
// Begin line 657
  setline(657);
  if (strlit2217 == NULL) {
    strlit2217 = alloc_String("label %isdef");
  }
// compilenode returning strlit2217
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2219 = callmethod(strlit2217, "++", 1, params);
// compilenode returning opresult2219
  if (strlit2220 == NULL) {
    strlit2220 = alloc_String("");
  }
// compilenode returning strlit2220
  params[0] = strlit2220;
  Object opresult2222 = callmethod(opresult2219, "++", 1, params);
// compilenode returning opresult2222
  params[0] = opresult2222;
  Object opresult2224 = callmethod(opresult2216, "++", 1, params);
// compilenode returning opresult2224
// Begin line 658
  setline(658);
// compilenode returning self
  params[0] = opresult2224;
  Object call2225 = callmethod(self, "out",
    1, params);
// compilenode returning call2225
  if (strlit2226 == NULL) {
    strlit2226 = alloc_String("isundef");
  }
// compilenode returning strlit2226
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2228 = callmethod(strlit2226, "++", 1, params);
// compilenode returning opresult2228
  if (strlit2229 == NULL) {
    strlit2229 = alloc_String("");
  }
// compilenode returning strlit2229
  params[0] = strlit2229;
  Object opresult2231 = callmethod(opresult2228, "++", 1, params);
// compilenode returning opresult2231
// Begin line 659
  setline(659);
// compilenode returning self
  params[0] = opresult2231;
  Object call2232 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2232
// Begin line 661
  setline(661);
// Begin line 659
  setline(659);
  if (strlit2233 == NULL) {
    strlit2233 = alloc_String("  call %object @callmethod(%object %nothing");
  }
// compilenode returning strlit2233
// Begin line 660
  setline(660);
  if (strlit2234 == NULL) {
    strlit2234 = alloc_String(", i8* getelementptr([11 x i8]* @.str._assignment");
  }
// compilenode returning strlit2234
  params[0] = strlit2234;
  Object opresult2236 = callmethod(strlit2233, "++", 1, params);
// compilenode returning opresult2236
// Begin line 661
  setline(661);
  if (strlit2237 == NULL) {
    strlit2237 = alloc_String(",i32 0,i32 0), i32 1, %object* %""\x22""var_");
  }
// compilenode returning strlit2237
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2239 = callmethod(strlit2237, "++", 1, params);
// compilenode returning opresult2239
  if (strlit2240 == NULL) {
    strlit2240 = alloc_String("""\x22"")");
  }
// compilenode returning strlit2240
  params[0] = strlit2240;
  Object opresult2242 = callmethod(opresult2239, "++", 1, params);
// compilenode returning opresult2242
  params[0] = opresult2242;
  Object opresult2244 = callmethod(opresult2236, "++", 1, params);
// compilenode returning opresult2244
// Begin line 662
  setline(662);
// compilenode returning self
  params[0] = opresult2244;
  Object call2245 = callmethod(self, "out",
    1, params);
// compilenode returning call2245
  if (strlit2246 == NULL) {
    strlit2246 = alloc_String("  br label %isdef");
  }
// compilenode returning strlit2246
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2248 = callmethod(strlit2246, "++", 1, params);
// compilenode returning opresult2248
  if (strlit2249 == NULL) {
    strlit2249 = alloc_String("");
  }
// compilenode returning strlit2249
  params[0] = strlit2249;
  Object opresult2251 = callmethod(opresult2248, "++", 1, params);
// compilenode returning opresult2251
// Begin line 663
  setline(663);
// compilenode returning self
  params[0] = opresult2251;
  Object call2252 = callmethod(self, "out",
    1, params);
// compilenode returning call2252
  if (strlit2253 == NULL) {
    strlit2253 = alloc_String("isdef");
  }
// compilenode returning strlit2253
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2255 = callmethod(strlit2253, "++", 1, params);
// compilenode returning opresult2255
  if (strlit2256 == NULL) {
    strlit2256 = alloc_String("");
  }
// compilenode returning strlit2256
  params[0] = strlit2256;
  Object opresult2258 = callmethod(opresult2255, "++", 1, params);
// compilenode returning opresult2258
// Begin line 664
  setline(664);
// compilenode returning self
  params[0] = opresult2258;
  Object call2259 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2259
// Begin line 665
  setline(665);
// Begin line 664
  setline(664);
// compilenode returning *var_auto_count
  Object num2260 = alloc_Float64(1.0);
// compilenode returning num2260
  params[0] = num2260;
  Object sum2262 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2262
  *var_auto_count = sum2262;
  if (sum2262 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 666
  setline(666);
// Begin line 1429
  setline(1429);
// Begin line 665
  setline(665);
// compilenode returning *var_val
// compilenode returning *var_o
  params[0] = *var_val;
  Object call2264 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2264
// compilenode returning nothing
    if2170 = nothing;
  } else {
// Begin line 677
  setline(677);
// Begin line 672
  setline(672);
// Begin line 1429
  setline(1429);
// Begin line 666
  setline(666);
// compilenode returning *var_dest
  Object call2266 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call2266
// compilenode returning call2266
  if (strlit2267 == NULL) {
    strlit2267 = alloc_String("member");
  }
// compilenode returning strlit2267
  params[0] = strlit2267;
  Object opresult2269 = callmethod(call2266, "==", 1, params);
// compilenode returning opresult2269
  Object if2265;
  if (istrue(opresult2269)) {
// Begin line 667
  setline(667);
  if (strlit2270 == NULL) {
    strlit2270 = alloc_String("; WARNING: non-local assigns not yet fully supported");
  }
// compilenode returning strlit2270
// Begin line 668
  setline(668);
// compilenode returning self
  params[0] = strlit2270;
  Object call2271 = callmethod(self, "out",
    1, params);
// compilenode returning call2271
// Begin line 669
  setline(669);
// Begin line 1429
  setline(1429);
// Begin line 669
  setline(669);
// Begin line 1429
  setline(1429);
// Begin line 668
  setline(668);
// compilenode returning *var_dest
  Object call2272 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call2272
// compilenode returning call2272
  if (strlit2273 == NULL) {
    strlit2273 = alloc_String(":=");
  }
// compilenode returning strlit2273
  params[0] = strlit2273;
  Object opresult2275 = callmethod(call2272, "++", 1, params);
// compilenode returning opresult2275
// compilenode returning *var_dest
  params[0] = opresult2275;
  Object call2276 = callmethod(*var_dest, "value:=",
    1, params);
// compilenode returning call2276
// compilenode returning nothing
// Begin line 669
  setline(669);
// compilenode returning *var_dest
  Object array2277 = alloc_List();
// Begin line 1429
  setline(1429);
// Begin line 669
  setline(669);
// compilenode returning *var_o
  Object call2278 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2278
// compilenode returning call2278
  params[0] = call2278;
  callmethod(array2277, "push", 1, params);
// compilenode returning array2277
// compilenode returning module_ast
  params[0] = *var_dest;
  params[1] = array2277;
  Object call2279 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call2279
  *var_c = call2279;
  if (call2279 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 670
  setline(670);
// compilenode returning *var_c
// Begin line 671
  setline(671);
// compilenode returning self
  params[0] = *var_c;
  Object call2281 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2281
  *var_r = call2281;
  if (call2281 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 672
  setline(672);
// Begin line 1429
  setline(1429);
// Begin line 671
  setline(671);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call2283 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2283
// compilenode returning nothing
    if2265 = nothing;
  } else {
// Begin line 677
  setline(677);
// Begin line 678
  setline(678);
// Begin line 1429
  setline(1429);
// Begin line 672
  setline(672);
// compilenode returning *var_dest
  Object call2285 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call2285
// compilenode returning call2285
  if (strlit2286 == NULL) {
    strlit2286 = alloc_String("index");
  }
// compilenode returning strlit2286
  params[0] = strlit2286;
  Object opresult2288 = callmethod(call2285, "==", 1, params);
// compilenode returning opresult2288
  Object if2284;
  if (istrue(opresult2288)) {
  Object *var_imem = alloc_var();
  *var_imem = undefined;
// Begin line 673
  setline(673);
  if (strlit2289 == NULL) {
    strlit2289 = alloc_String("[]:=");
  }
// compilenode returning strlit2289
// Begin line 1429
  setline(1429);
// Begin line 673
  setline(673);
// compilenode returning *var_dest
  Object call2290 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call2290
// compilenode returning call2290
// compilenode returning module_ast
  params[0] = strlit2289;
  params[1] = call2290;
  Object call2291 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call2291
  var_imem = alloc_var();
  *var_imem = call2291;
  if (call2291 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 674
  setline(674);
// compilenode returning *var_imem
  Object array2292 = alloc_List();
// Begin line 1429
  setline(1429);
// Begin line 674
  setline(674);
// compilenode returning *var_dest
  Object call2293 = callmethod(*var_dest, "index",
    0, params);
// compilenode returning call2293
// compilenode returning call2293
  params[0] = call2293;
  callmethod(array2292, "push", 1, params);
// Begin line 1429
  setline(1429);
// Begin line 674
  setline(674);
// compilenode returning *var_o
  Object call2294 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2294
// compilenode returning call2294
  params[0] = call2294;
  callmethod(array2292, "push", 1, params);
// compilenode returning array2292
// compilenode returning module_ast
  params[0] = *var_imem;
  params[1] = array2292;
  Object call2295 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call2295
  *var_c = call2295;
  if (call2295 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 675
  setline(675);
// compilenode returning *var_c
// Begin line 676
  setline(676);
// compilenode returning self
  params[0] = *var_c;
  Object call2297 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2297
  *var_r = call2297;
  if (call2297 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 677
  setline(677);
// Begin line 1429
  setline(1429);
// Begin line 676
  setline(676);
// compilenode returning *var_r
// compilenode returning *var_o
  params[0] = *var_r;
  Object call2299 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2299
// compilenode returning nothing
    if2284 = nothing;
  } else {
  }
// compilenode returning if2284
    if2265 = if2284;
  }
// compilenode returning if2265
    if2170 = if2265;
  }
// compilenode returning if2170
// Begin line 679
  setline(679);
// Begin line 1429
  setline(1429);
// Begin line 678
  setline(678);
  if (strlit2300 == NULL) {
    strlit2300 = alloc_String("%nothing");
  }
// compilenode returning strlit2300
// compilenode returning *var_o
  params[0] = strlit2300;
  Object call2301 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2301
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compiledefdec2302(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[19];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 682
  setline(682);
  var_nm = alloc_var();
  *var_nm = undefined;
// compilenode returning nothing
// Begin line 685
  setline(685);
// Begin line 687
  setline(687);
// Begin line 1429
  setline(1429);
// Begin line 687
  setline(687);
// Begin line 1429
  setline(1429);
// Begin line 682
  setline(682);
// compilenode returning *var_o
  Object call2304 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call2304
// compilenode returning call2304
  Object call2305 = callmethod(call2304, "kind",
    0, params);
// compilenode returning call2305
// compilenode returning call2305
  if (strlit2306 == NULL) {
    strlit2306 = alloc_String("generic");
  }
// compilenode returning strlit2306
  params[0] = strlit2306;
  Object opresult2308 = callmethod(call2305, "==", 1, params);
// compilenode returning opresult2308
  Object if2303;
  if (istrue(opresult2308)) {
// Begin line 683
  setline(683);
// Begin line 1429
  setline(1429);
// Begin line 683
  setline(683);
// Begin line 1429
  setline(1429);
// Begin line 683
  setline(683);
// Begin line 1429
  setline(1429);
// Begin line 683
  setline(683);
// Begin line 1429
  setline(1429);
// Begin line 683
  setline(683);
// compilenode returning *var_o
  Object call2309 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call2309
// compilenode returning call2309
  Object call2310 = callmethod(call2309, "value",
    0, params);
// compilenode returning call2310
// compilenode returning call2310
  Object call2311 = callmethod(call2310, "value",
    0, params);
// compilenode returning call2311
// compilenode returning call2311
  Object call2312 = callmethod(call2311, "_escape",
    0, params);
// compilenode returning call2312
// compilenode returning call2312
  *var_nm = call2312;
  if (call2312 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2303 = nothing;
  } else {
// Begin line 685
  setline(685);
// Begin line 1429
  setline(1429);
// Begin line 685
  setline(685);
// Begin line 1429
  setline(1429);
// Begin line 685
  setline(685);
// Begin line 1429
  setline(1429);
// Begin line 685
  setline(685);
// compilenode returning *var_o
  Object call2314 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call2314
// compilenode returning call2314
  Object call2315 = callmethod(call2314, "value",
    0, params);
// compilenode returning call2315
// compilenode returning call2315
  Object call2316 = callmethod(call2315, "_escape",
    0, params);
// compilenode returning call2316
// compilenode returning call2316
  *var_nm = call2316;
  if (call2316 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2303 = nothing;
  }
// compilenode returning if2303
// Begin line 687
  setline(687);
// compilenode returning *var_nm
// compilenode returning *var_declaredvars
  params[0] = *var_nm;
  Object call2318 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call2318
// Begin line 689
  setline(689);
// Begin line 1429
  setline(1429);
// Begin line 688
  setline(688);
// compilenode returning *var_o
  Object call2319 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2319
// compilenode returning call2319
  var_val = alloc_var();
  *var_val = call2319;
  if (call2319 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 692
  setline(692);
// Begin line 689
  setline(689);
// compilenode returning *var_val
  Object if2320;
  if (istrue(*var_val)) {
// Begin line 690
  setline(690);
// compilenode returning *var_val
// Begin line 691
  setline(691);
// compilenode returning self
  params[0] = *var_val;
  Object call2321 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2321
  *var_val = call2321;
  if (call2321 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2320 = nothing;
  } else {
// Begin line 692
  setline(692);
  if (strlit2323 == NULL) {
    strlit2323 = alloc_String("const must have value bound.");
  }
// compilenode returning strlit2323
// compilenode returning module_util
  params[0] = strlit2323;
  Object call2324 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2324
    if2320 = call2324;
  }
// compilenode returning if2320
// Begin line 695
  setline(695);
// Begin line 694
  setline(694);
  if (strlit2325 == NULL) {
    strlit2325 = alloc_String("  store %object ");
  }
// compilenode returning strlit2325
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2327 = callmethod(strlit2325, "++", 1, params);
// compilenode returning opresult2327
  if (strlit2328 == NULL) {
    strlit2328 = alloc_String(", %object* %""\x22""var_");
  }
// compilenode returning strlit2328
  params[0] = strlit2328;
  Object opresult2330 = callmethod(opresult2327, "++", 1, params);
// compilenode returning opresult2330
// Begin line 695
  setline(695);
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2332 = callmethod(opresult2330, "++", 1, params);
// compilenode returning opresult2332
  if (strlit2333 == NULL) {
    strlit2333 = alloc_String("""\x22""");
  }
// compilenode returning strlit2333
  params[0] = strlit2333;
  Object opresult2335 = callmethod(opresult2332, "++", 1, params);
// compilenode returning opresult2335
// Begin line 696
  setline(696);
// compilenode returning self
  params[0] = opresult2335;
  Object call2336 = callmethod(self, "out",
    1, params);
// compilenode returning call2336
  if (strlit2337 == NULL) {
    strlit2337 = alloc_String("  %icmp");
  }
// compilenode returning strlit2337
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2339 = callmethod(strlit2337, "++", 1, params);
// compilenode returning opresult2339
  if (strlit2340 == NULL) {
    strlit2340 = alloc_String(" = icmp eq %object ");
  }
// compilenode returning strlit2340
  params[0] = strlit2340;
  Object opresult2342 = callmethod(opresult2339, "++", 1, params);
// compilenode returning opresult2342
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2344 = callmethod(opresult2342, "++", 1, params);
// compilenode returning opresult2344
  if (strlit2345 == NULL) {
    strlit2345 = alloc_String(", %undefined");
  }
// compilenode returning strlit2345
  params[0] = strlit2345;
  Object opresult2347 = callmethod(opresult2344, "++", 1, params);
// compilenode returning opresult2347
// Begin line 697
  setline(697);
// compilenode returning self
  params[0] = opresult2347;
  Object call2348 = callmethod(self, "out",
    1, params);
// compilenode returning call2348
// Begin line 698
  setline(698);
// Begin line 697
  setline(697);
  if (strlit2349 == NULL) {
    strlit2349 = alloc_String("  br i1 %icmp");
  }
// compilenode returning strlit2349
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2351 = callmethod(strlit2349, "++", 1, params);
// compilenode returning opresult2351
  if (strlit2352 == NULL) {
    strlit2352 = alloc_String(", label %isundef");
  }
// compilenode returning strlit2352
  params[0] = strlit2352;
  Object opresult2354 = callmethod(opresult2351, "++", 1, params);
// compilenode returning opresult2354
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2356 = callmethod(opresult2354, "++", 1, params);
// compilenode returning opresult2356
  if (strlit2357 == NULL) {
    strlit2357 = alloc_String(", ");
  }
// compilenode returning strlit2357
  params[0] = strlit2357;
  Object opresult2359 = callmethod(opresult2356, "++", 1, params);
// compilenode returning opresult2359
// Begin line 698
  setline(698);
  if (strlit2360 == NULL) {
    strlit2360 = alloc_String("label %isdef");
  }
// compilenode returning strlit2360
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2362 = callmethod(strlit2360, "++", 1, params);
// compilenode returning opresult2362
  if (strlit2363 == NULL) {
    strlit2363 = alloc_String("");
  }
// compilenode returning strlit2363
  params[0] = strlit2363;
  Object opresult2365 = callmethod(opresult2362, "++", 1, params);
// compilenode returning opresult2365
  params[0] = opresult2365;
  Object opresult2367 = callmethod(opresult2359, "++", 1, params);
// compilenode returning opresult2367
// Begin line 699
  setline(699);
// compilenode returning self
  params[0] = opresult2367;
  Object call2368 = callmethod(self, "out",
    1, params);
// compilenode returning call2368
  if (strlit2369 == NULL) {
    strlit2369 = alloc_String("isundef");
  }
// compilenode returning strlit2369
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2371 = callmethod(strlit2369, "++", 1, params);
// compilenode returning opresult2371
  if (strlit2372 == NULL) {
    strlit2372 = alloc_String("");
  }
// compilenode returning strlit2372
  params[0] = strlit2372;
  Object opresult2374 = callmethod(opresult2371, "++", 1, params);
// compilenode returning opresult2374
// Begin line 700
  setline(700);
// compilenode returning self
  params[0] = opresult2374;
  Object call2375 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2375
// Begin line 702
  setline(702);
// Begin line 700
  setline(700);
  if (strlit2376 == NULL) {
    strlit2376 = alloc_String("  call %object @callmethod(%object %nothing");
  }
// compilenode returning strlit2376
// Begin line 701
  setline(701);
  if (strlit2377 == NULL) {
    strlit2377 = alloc_String(", i8* getelementptr([11 x i8]* @.str._assignment");
  }
// compilenode returning strlit2377
  params[0] = strlit2377;
  Object opresult2379 = callmethod(strlit2376, "++", 1, params);
// compilenode returning opresult2379
// Begin line 702
  setline(702);
  if (strlit2380 == NULL) {
    strlit2380 = alloc_String(",i32 0,i32 0), i32 1, %object* %""\x22""var_");
  }
// compilenode returning strlit2380
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2382 = callmethod(strlit2380, "++", 1, params);
// compilenode returning opresult2382
  if (strlit2383 == NULL) {
    strlit2383 = alloc_String("""\x22"")");
  }
// compilenode returning strlit2383
  params[0] = strlit2383;
  Object opresult2385 = callmethod(opresult2382, "++", 1, params);
// compilenode returning opresult2385
  params[0] = opresult2385;
  Object opresult2387 = callmethod(opresult2379, "++", 1, params);
// compilenode returning opresult2387
// Begin line 703
  setline(703);
// compilenode returning self
  params[0] = opresult2387;
  Object call2388 = callmethod(self, "out",
    1, params);
// compilenode returning call2388
  if (strlit2389 == NULL) {
    strlit2389 = alloc_String("  br label %isdef");
  }
// compilenode returning strlit2389
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2391 = callmethod(strlit2389, "++", 1, params);
// compilenode returning opresult2391
  if (strlit2392 == NULL) {
    strlit2392 = alloc_String("");
  }
// compilenode returning strlit2392
  params[0] = strlit2392;
  Object opresult2394 = callmethod(opresult2391, "++", 1, params);
// compilenode returning opresult2394
// Begin line 704
  setline(704);
// compilenode returning self
  params[0] = opresult2394;
  Object call2395 = callmethod(self, "out",
    1, params);
// compilenode returning call2395
  if (strlit2396 == NULL) {
    strlit2396 = alloc_String("isdef");
  }
// compilenode returning strlit2396
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2398 = callmethod(strlit2396, "++", 1, params);
// compilenode returning opresult2398
  if (strlit2399 == NULL) {
    strlit2399 = alloc_String("");
  }
// compilenode returning strlit2399
  params[0] = strlit2399;
  Object opresult2401 = callmethod(opresult2398, "++", 1, params);
// compilenode returning opresult2401
// Begin line 705
  setline(705);
// compilenode returning self
  params[0] = opresult2401;
  Object call2402 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2402
// Begin line 706
  setline(706);
// Begin line 705
  setline(705);
// compilenode returning *var_auto_count
  Object num2403 = alloc_Float64(1.0);
// compilenode returning num2403
  params[0] = num2403;
  Object sum2405 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2405
  *var_auto_count = sum2405;
  if (sum2405 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 707
  setline(707);
// Begin line 1429
  setline(1429);
// Begin line 706
  setline(706);
  if (strlit2407 == NULL) {
    strlit2407 = alloc_String("%nothing");
  }
// compilenode returning strlit2407
// compilenode returning *var_o
  params[0] = strlit2407;
  Object call2408 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2408
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilevardec2409(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[20];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_hadval = alloc_var();
  *var_hadval = undefined;
// Begin line 709
  setline(709);
// Begin line 1429
  setline(1429);
// Begin line 709
  setline(709);
// Begin line 1429
  setline(1429);
// Begin line 709
  setline(709);
// Begin line 1429
  setline(1429);
// Begin line 709
  setline(709);
// compilenode returning *var_o
  Object call2410 = callmethod(*var_o, "name",
    0, params);
// compilenode returning call2410
// compilenode returning call2410
  Object call2411 = callmethod(call2410, "value",
    0, params);
// compilenode returning call2411
// compilenode returning call2411
  Object call2412 = callmethod(call2411, "_escape",
    0, params);
// compilenode returning call2412
// compilenode returning call2412
  var_nm = alloc_var();
  *var_nm = call2412;
  if (call2412 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 710
  setline(710);
// compilenode returning *var_nm
// compilenode returning *var_declaredvars
  params[0] = *var_nm;
  Object call2413 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call2413
// Begin line 712
  setline(712);
// Begin line 1429
  setline(1429);
// Begin line 711
  setline(711);
// compilenode returning *var_o
  Object call2414 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2414
// compilenode returning call2414
  var_val = alloc_var();
  *var_val = call2414;
  if (call2414 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 713
  setline(713);
// Begin line 712
  setline(712);
  Object bool2415 = alloc_Boolean(0);
// compilenode returning bool2415
  var_hadval = alloc_var();
  *var_hadval = bool2415;
  if (bool2415 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 718
  setline(718);
// Begin line 713
  setline(713);
// compilenode returning *var_val
  Object if2416;
  if (istrue(*var_val)) {
// Begin line 714
  setline(714);
// compilenode returning *var_val
// Begin line 715
  setline(715);
// compilenode returning self
  params[0] = *var_val;
  Object call2417 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2417
  *var_val = call2417;
  if (call2417 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 716
  setline(716);
// Begin line 715
  setline(715);
  Object bool2419 = alloc_Boolean(1);
// compilenode returning bool2419
  *var_hadval = bool2419;
  if (bool2419 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2416 = nothing;
  } else {
// Begin line 718
  setline(718);
// Begin line 717
  setline(717);
  if (strlit2421 == NULL) {
    strlit2421 = alloc_String("%undefined");
  }
// compilenode returning strlit2421
  *var_val = strlit2421;
  if (strlit2421 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2416 = nothing;
  }
// compilenode returning if2416
// Begin line 720
  setline(720);
// Begin line 719
  setline(719);
  if (strlit2423 == NULL) {
    strlit2423 = alloc_String("  store %object ");
  }
// compilenode returning strlit2423
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2425 = callmethod(strlit2423, "++", 1, params);
// compilenode returning opresult2425
  if (strlit2426 == NULL) {
    strlit2426 = alloc_String(", %object* %""\x22""var_");
  }
// compilenode returning strlit2426
  params[0] = strlit2426;
  Object opresult2428 = callmethod(opresult2425, "++", 1, params);
// compilenode returning opresult2428
// Begin line 720
  setline(720);
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2430 = callmethod(opresult2428, "++", 1, params);
// compilenode returning opresult2430
  if (strlit2431 == NULL) {
    strlit2431 = alloc_String("""\x22""");
  }
// compilenode returning strlit2431
  params[0] = strlit2431;
  Object opresult2433 = callmethod(opresult2430, "++", 1, params);
// compilenode returning opresult2433
// Begin line 721
  setline(721);
// compilenode returning self
  params[0] = opresult2433;
  Object call2434 = callmethod(self, "out",
    1, params);
// compilenode returning call2434
// Begin line 732
  setline(732);
// Begin line 721
  setline(721);
// compilenode returning *var_hadval
  Object if2435;
  if (istrue(*var_hadval)) {
// Begin line 722
  setline(722);
  if (strlit2436 == NULL) {
    strlit2436 = alloc_String("  %icmp");
  }
// compilenode returning strlit2436
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2438 = callmethod(strlit2436, "++", 1, params);
// compilenode returning opresult2438
  if (strlit2439 == NULL) {
    strlit2439 = alloc_String(" = icmp eq %object ");
  }
// compilenode returning strlit2439
  params[0] = strlit2439;
  Object opresult2441 = callmethod(opresult2438, "++", 1, params);
// compilenode returning opresult2441
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult2443 = callmethod(opresult2441, "++", 1, params);
// compilenode returning opresult2443
  if (strlit2444 == NULL) {
    strlit2444 = alloc_String(", %undefined");
  }
// compilenode returning strlit2444
  params[0] = strlit2444;
  Object opresult2446 = callmethod(opresult2443, "++", 1, params);
// compilenode returning opresult2446
// Begin line 723
  setline(723);
// compilenode returning self
  params[0] = opresult2446;
  Object call2447 = callmethod(self, "out",
    1, params);
// compilenode returning call2447
// Begin line 724
  setline(724);
// Begin line 723
  setline(723);
  if (strlit2448 == NULL) {
    strlit2448 = alloc_String("  br i1 %icmp");
  }
// compilenode returning strlit2448
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2450 = callmethod(strlit2448, "++", 1, params);
// compilenode returning opresult2450
  if (strlit2451 == NULL) {
    strlit2451 = alloc_String(", label %isundef");
  }
// compilenode returning strlit2451
  params[0] = strlit2451;
  Object opresult2453 = callmethod(opresult2450, "++", 1, params);
// compilenode returning opresult2453
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2455 = callmethod(opresult2453, "++", 1, params);
// compilenode returning opresult2455
  if (strlit2456 == NULL) {
    strlit2456 = alloc_String(", ");
  }
// compilenode returning strlit2456
  params[0] = strlit2456;
  Object opresult2458 = callmethod(opresult2455, "++", 1, params);
// compilenode returning opresult2458
// Begin line 724
  setline(724);
  if (strlit2459 == NULL) {
    strlit2459 = alloc_String("label %isdef");
  }
// compilenode returning strlit2459
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2461 = callmethod(strlit2459, "++", 1, params);
// compilenode returning opresult2461
  if (strlit2462 == NULL) {
    strlit2462 = alloc_String("");
  }
// compilenode returning strlit2462
  params[0] = strlit2462;
  Object opresult2464 = callmethod(opresult2461, "++", 1, params);
// compilenode returning opresult2464
  params[0] = opresult2464;
  Object opresult2466 = callmethod(opresult2458, "++", 1, params);
// compilenode returning opresult2466
// Begin line 725
  setline(725);
// compilenode returning self
  params[0] = opresult2466;
  Object call2467 = callmethod(self, "out",
    1, params);
// compilenode returning call2467
  if (strlit2468 == NULL) {
    strlit2468 = alloc_String("isundef");
  }
// compilenode returning strlit2468
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2470 = callmethod(strlit2468, "++", 1, params);
// compilenode returning opresult2470
  if (strlit2471 == NULL) {
    strlit2471 = alloc_String("");
  }
// compilenode returning strlit2471
  params[0] = strlit2471;
  Object opresult2473 = callmethod(opresult2470, "++", 1, params);
// compilenode returning opresult2473
// Begin line 726
  setline(726);
// compilenode returning self
  params[0] = opresult2473;
  Object call2474 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2474
// Begin line 728
  setline(728);
// Begin line 726
  setline(726);
  if (strlit2475 == NULL) {
    strlit2475 = alloc_String("  call %object @callmethod(%object %nothing");
  }
// compilenode returning strlit2475
// Begin line 727
  setline(727);
  if (strlit2476 == NULL) {
    strlit2476 = alloc_String(", i8* getelementptr([11 x i8]* @.str._assignment");
  }
// compilenode returning strlit2476
  params[0] = strlit2476;
  Object opresult2478 = callmethod(strlit2475, "++", 1, params);
// compilenode returning opresult2478
// Begin line 728
  setline(728);
  if (strlit2479 == NULL) {
    strlit2479 = alloc_String(",i32 0,i32 0), i32 1, %object* %""\x22""var_");
  }
// compilenode returning strlit2479
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult2481 = callmethod(strlit2479, "++", 1, params);
// compilenode returning opresult2481
  if (strlit2482 == NULL) {
    strlit2482 = alloc_String("""\x22"")");
  }
// compilenode returning strlit2482
  params[0] = strlit2482;
  Object opresult2484 = callmethod(opresult2481, "++", 1, params);
// compilenode returning opresult2484
  params[0] = opresult2484;
  Object opresult2486 = callmethod(opresult2478, "++", 1, params);
// compilenode returning opresult2486
// Begin line 729
  setline(729);
// compilenode returning self
  params[0] = opresult2486;
  Object call2487 = callmethod(self, "out",
    1, params);
// compilenode returning call2487
  if (strlit2488 == NULL) {
    strlit2488 = alloc_String("  br label %isdef");
  }
// compilenode returning strlit2488
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2490 = callmethod(strlit2488, "++", 1, params);
// compilenode returning opresult2490
  if (strlit2491 == NULL) {
    strlit2491 = alloc_String("");
  }
// compilenode returning strlit2491
  params[0] = strlit2491;
  Object opresult2493 = callmethod(opresult2490, "++", 1, params);
// compilenode returning opresult2493
// Begin line 730
  setline(730);
// compilenode returning self
  params[0] = opresult2493;
  Object call2494 = callmethod(self, "out",
    1, params);
// compilenode returning call2494
  if (strlit2495 == NULL) {
    strlit2495 = alloc_String("isdef");
  }
// compilenode returning strlit2495
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2497 = callmethod(strlit2495, "++", 1, params);
// compilenode returning opresult2497
  if (strlit2498 == NULL) {
    strlit2498 = alloc_String("");
  }
// compilenode returning strlit2498
  params[0] = strlit2498;
  Object opresult2500 = callmethod(opresult2497, "++", 1, params);
// compilenode returning opresult2500
// Begin line 731
  setline(731);
// compilenode returning self
  params[0] = opresult2500;
  Object call2501 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call2501
// Begin line 732
  setline(732);
// Begin line 731
  setline(731);
// compilenode returning *var_auto_count
  Object num2502 = alloc_Float64(1.0);
// compilenode returning num2502
  params[0] = num2502;
  Object sum2504 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2504
  *var_auto_count = sum2504;
  if (sum2504 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2435 = nothing;
  } else {
  }
// compilenode returning if2435
// Begin line 734
  setline(734);
// Begin line 1429
  setline(1429);
// Begin line 733
  setline(733);
  if (strlit2506 == NULL) {
    strlit2506 = alloc_String("%nothing");
  }
// compilenode returning strlit2506
// compilenode returning *var_o
  params[0] = strlit2506;
  Object call2507 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2507
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileindex2508(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[21];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_of = alloc_var();
  *var_of = undefined;
  Object *var_index = alloc_var();
  *var_index = undefined;
// Begin line 736
  setline(736);
// Begin line 1429
  setline(1429);
// Begin line 736
  setline(736);
// compilenode returning *var_o
  Object call2509 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2509
// compilenode returning call2509
// Begin line 737
  setline(737);
// compilenode returning self
  params[0] = call2509;
  Object call2510 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2510
  var_of = alloc_var();
  *var_of = call2510;
  if (call2510 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1429
  setline(1429);
// Begin line 737
  setline(737);
// compilenode returning *var_o
  Object call2511 = callmethod(*var_o, "index",
    0, params);
// compilenode returning call2511
// compilenode returning call2511
// Begin line 738
  setline(738);
// compilenode returning self
  params[0] = call2511;
  Object call2512 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2512
  var_index = alloc_var();
  *var_index = call2512;
  if (call2512 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit2513 == NULL) {
    strlit2513 = alloc_String("  store %object ");
  }
// compilenode returning strlit2513
// compilenode returning *var_index
  params[0] = *var_index;
  Object opresult2515 = callmethod(strlit2513, "++", 1, params);
// compilenode returning opresult2515
  if (strlit2516 == NULL) {
    strlit2516 = alloc_String(", %object* %params_0");
  }
// compilenode returning strlit2516
  params[0] = strlit2516;
  Object opresult2518 = callmethod(opresult2515, "++", 1, params);
// compilenode returning opresult2518
// Begin line 739
  setline(739);
// compilenode returning self
  params[0] = opresult2518;
  Object call2519 = callmethod(self, "out",
    1, params);
// compilenode returning call2519
// Begin line 741
  setline(741);
// Begin line 739
  setline(739);
  if (strlit2520 == NULL) {
    strlit2520 = alloc_String("  %idxres");
  }
// compilenode returning strlit2520
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2522 = callmethod(strlit2520, "++", 1, params);
// compilenode returning opresult2522
  if (strlit2523 == NULL) {
    strlit2523 = alloc_String(" = call %object @callmethod(%object ");
  }
// compilenode returning strlit2523
  params[0] = strlit2523;
  Object opresult2525 = callmethod(opresult2522, "++", 1, params);
// compilenode returning opresult2525
// Begin line 740
  setline(740);
// compilenode returning *var_of
  params[0] = *var_of;
  Object opresult2527 = callmethod(opresult2525, "++", 1, params);
// compilenode returning opresult2527
  if (strlit2528 == NULL) {
    strlit2528 = alloc_String(", i8* getelementptr([3 x i8]* @.str._index");
  }
// compilenode returning strlit2528
  params[0] = strlit2528;
  Object opresult2530 = callmethod(opresult2527, "++", 1, params);
// compilenode returning opresult2530
// Begin line 741
  setline(741);
  if (strlit2531 == NULL) {
    strlit2531 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit2531
  params[0] = strlit2531;
  Object opresult2533 = callmethod(opresult2530, "++", 1, params);
// compilenode returning opresult2533
// Begin line 742
  setline(742);
// compilenode returning self
  params[0] = opresult2533;
  Object call2534 = callmethod(self, "out",
    1, params);
// compilenode returning call2534
// Begin line 743
  setline(743);
// Begin line 1429
  setline(1429);
// Begin line 743
  setline(743);
// Begin line 742
  setline(742);
  if (strlit2535 == NULL) {
    strlit2535 = alloc_String("%idxres");
  }
// compilenode returning strlit2535
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2537 = callmethod(strlit2535, "++", 1, params);
// compilenode returning opresult2537
// compilenode returning *var_o
  params[0] = opresult2537;
  Object call2538 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2538
// compilenode returning nothing
// Begin line 744
  setline(744);
// Begin line 743
  setline(743);
// compilenode returning *var_auto_count
  Object num2539 = alloc_Float64(1.0);
// compilenode returning num2539
  params[0] = num2539;
  Object sum2541 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2541
  *var_auto_count = sum2541;
  if (sum2541 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileop2543(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[22];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_left = alloc_var();
  *var_left = undefined;
  Object *var_right = alloc_var();
  *var_right = undefined;
// Begin line 746
  setline(746);
// Begin line 1429
  setline(1429);
// Begin line 746
  setline(746);
// compilenode returning *var_o
  Object call2544 = callmethod(*var_o, "left",
    0, params);
// compilenode returning call2544
// compilenode returning call2544
// Begin line 747
  setline(747);
// compilenode returning self
  params[0] = call2544;
  Object call2545 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2545
  var_left = alloc_var();
  *var_left = call2545;
  if (call2545 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1429
  setline(1429);
// Begin line 747
  setline(747);
// compilenode returning *var_o
  Object call2546 = callmethod(*var_o, "right",
    0, params);
// compilenode returning call2546
// compilenode returning call2546
// Begin line 748
  setline(748);
// compilenode returning self
  params[0] = call2546;
  Object call2547 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2547
  var_right = alloc_var();
  *var_right = call2547;
  if (call2547 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 749
  setline(749);
// Begin line 748
  setline(748);
// compilenode returning *var_auto_count
  Object num2548 = alloc_Float64(1.0);
// compilenode returning num2548
  params[0] = num2548;
  Object sum2550 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2550
  *var_auto_count = sum2550;
  if (sum2550 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 788
  setline(788);
// Begin line 789
  setline(789);
// Begin line 1429
  setline(1429);
// Begin line 749
  setline(749);
// compilenode returning *var_o
  Object call2553 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2553
// compilenode returning call2553
  if (strlit2554 == NULL) {
    strlit2554 = alloc_String("+");
  }
// compilenode returning strlit2554
  params[0] = strlit2554;
  Object opresult2556 = callmethod(call2553, "==", 1, params);
// compilenode returning opresult2556
// Begin line 789
  setline(789);
// Begin line 1429
  setline(1429);
// Begin line 749
  setline(749);
// compilenode returning *var_o
  Object call2557 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2557
// compilenode returning call2557
  if (strlit2558 == NULL) {
    strlit2558 = alloc_String("*");
  }
// compilenode returning strlit2558
  params[0] = strlit2558;
  Object opresult2560 = callmethod(call2557, "==", 1, params);
// compilenode returning opresult2560
  params[0] = opresult2560;
  Object opresult2562 = callmethod(opresult2556, "|", 1, params);
// compilenode returning opresult2562
// Begin line 789
  setline(789);
// Begin line 1429
  setline(1429);
// Begin line 749
  setline(749);
// compilenode returning *var_o
  Object call2563 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2563
// compilenode returning call2563
  if (strlit2564 == NULL) {
    strlit2564 = alloc_String("/");
  }
// compilenode returning strlit2564
  params[0] = strlit2564;
  Object opresult2566 = callmethod(call2563, "==", 1, params);
// compilenode returning opresult2566
  params[0] = opresult2566;
  Object opresult2568 = callmethod(opresult2562, "|", 1, params);
// compilenode returning opresult2568
// Begin line 789
  setline(789);
// Begin line 1429
  setline(1429);
// Begin line 750
  setline(750);
// compilenode returning *var_o
  Object call2569 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2569
// compilenode returning call2569
  if (strlit2570 == NULL) {
    strlit2570 = alloc_String("-");
  }
// compilenode returning strlit2570
  params[0] = strlit2570;
  Object opresult2572 = callmethod(call2569, "==", 1, params);
// compilenode returning opresult2572
  params[0] = opresult2572;
  Object opresult2574 = callmethod(opresult2568, "|", 1, params);
// compilenode returning opresult2574
// Begin line 789
  setline(789);
// Begin line 1429
  setline(1429);
// Begin line 750
  setline(750);
// compilenode returning *var_o
  Object call2575 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2575
// compilenode returning call2575
  if (strlit2576 == NULL) {
    strlit2576 = alloc_String("%");
  }
// compilenode returning strlit2576
  params[0] = strlit2576;
  Object opresult2578 = callmethod(call2575, "==", 1, params);
// compilenode returning opresult2578
  params[0] = opresult2578;
  Object opresult2580 = callmethod(opresult2574, "|", 1, params);
// compilenode returning opresult2580
  Object if2552;
  if (istrue(opresult2580)) {
  Object *var_rnm = alloc_var();
  *var_rnm = undefined;
  Object *var_opnm = alloc_var();
  *var_opnm = undefined;
// Begin line 752
  setline(752);
// Begin line 751
  setline(751);
  if (strlit2581 == NULL) {
    strlit2581 = alloc_String("sum");
  }
// compilenode returning strlit2581
  var_rnm = alloc_var();
  *var_rnm = strlit2581;
  if (strlit2581 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 753
  setline(753);
// Begin line 752
  setline(752);
  if (strlit2582 == NULL) {
    strlit2582 = alloc_String("plus");
  }
// compilenode returning strlit2582
  var_opnm = alloc_var();
  *var_opnm = strlit2582;
  if (strlit2582 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 756
  setline(756);
// Begin line 757
  setline(757);
// Begin line 1429
  setline(1429);
// Begin line 753
  setline(753);
// compilenode returning *var_o
  Object call2584 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2584
// compilenode returning call2584
  if (strlit2585 == NULL) {
    strlit2585 = alloc_String("*");
  }
// compilenode returning strlit2585
  params[0] = strlit2585;
  Object opresult2587 = callmethod(call2584, "==", 1, params);
// compilenode returning opresult2587
  Object if2583;
  if (istrue(opresult2587)) {
// Begin line 755
  setline(755);
// Begin line 754
  setline(754);
  if (strlit2588 == NULL) {
    strlit2588 = alloc_String("prod");
  }
// compilenode returning strlit2588
  *var_rnm = strlit2588;
  if (strlit2588 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 756
  setline(756);
// Begin line 755
  setline(755);
  if (strlit2590 == NULL) {
    strlit2590 = alloc_String("asterisk");
  }
// compilenode returning strlit2590
  *var_opnm = strlit2590;
  if (strlit2590 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2583 = nothing;
  } else {
  }
// compilenode returning if2583
// Begin line 760
  setline(760);
// Begin line 761
  setline(761);
// Begin line 1429
  setline(1429);
// Begin line 757
  setline(757);
// compilenode returning *var_o
  Object call2593 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2593
// compilenode returning call2593
  if (strlit2594 == NULL) {
    strlit2594 = alloc_String("/");
  }
// compilenode returning strlit2594
  params[0] = strlit2594;
  Object opresult2596 = callmethod(call2593, "==", 1, params);
// compilenode returning opresult2596
  Object if2592;
  if (istrue(opresult2596)) {
// Begin line 759
  setline(759);
// Begin line 758
  setline(758);
  if (strlit2597 == NULL) {
    strlit2597 = alloc_String("quotient");
  }
// compilenode returning strlit2597
  *var_rnm = strlit2597;
  if (strlit2597 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 760
  setline(760);
// Begin line 759
  setline(759);
  if (strlit2599 == NULL) {
    strlit2599 = alloc_String("slash");
  }
// compilenode returning strlit2599
  *var_opnm = strlit2599;
  if (strlit2599 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2592 = nothing;
  } else {
  }
// compilenode returning if2592
// Begin line 764
  setline(764);
// Begin line 765
  setline(765);
// Begin line 1429
  setline(1429);
// Begin line 761
  setline(761);
// compilenode returning *var_o
  Object call2602 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2602
// compilenode returning call2602
  if (strlit2603 == NULL) {
    strlit2603 = alloc_String("-");
  }
// compilenode returning strlit2603
  params[0] = strlit2603;
  Object opresult2605 = callmethod(call2602, "==", 1, params);
// compilenode returning opresult2605
  Object if2601;
  if (istrue(opresult2605)) {
// Begin line 763
  setline(763);
// Begin line 762
  setline(762);
  if (strlit2606 == NULL) {
    strlit2606 = alloc_String("diff");
  }
// compilenode returning strlit2606
  *var_rnm = strlit2606;
  if (strlit2606 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 764
  setline(764);
// Begin line 763
  setline(763);
  if (strlit2608 == NULL) {
    strlit2608 = alloc_String("minus");
  }
// compilenode returning strlit2608
  *var_opnm = strlit2608;
  if (strlit2608 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2601 = nothing;
  } else {
  }
// compilenode returning if2601
// Begin line 768
  setline(768);
// Begin line 769
  setline(769);
// Begin line 1429
  setline(1429);
// Begin line 765
  setline(765);
// compilenode returning *var_o
  Object call2611 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2611
// compilenode returning call2611
  if (strlit2612 == NULL) {
    strlit2612 = alloc_String("%");
  }
// compilenode returning strlit2612
  params[0] = strlit2612;
  Object opresult2614 = callmethod(call2611, "==", 1, params);
// compilenode returning opresult2614
  Object if2610;
  if (istrue(opresult2614)) {
// Begin line 767
  setline(767);
// Begin line 766
  setline(766);
  if (strlit2615 == NULL) {
    strlit2615 = alloc_String("modulus");
  }
// compilenode returning strlit2615
  *var_rnm = strlit2615;
  if (strlit2615 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 768
  setline(768);
// Begin line 767
  setline(767);
  if (strlit2617 == NULL) {
    strlit2617 = alloc_String("percent");
  }
// compilenode returning strlit2617
  *var_opnm = strlit2617;
  if (strlit2617 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2610 = nothing;
  } else {
  }
// compilenode returning if2610
// Begin line 769
  setline(769);
  if (strlit2619 == NULL) {
    strlit2619 = alloc_String("  store %object ");
  }
// compilenode returning strlit2619
// compilenode returning *var_right
  params[0] = *var_right;
  Object opresult2621 = callmethod(strlit2619, "++", 1, params);
// compilenode returning opresult2621
  if (strlit2622 == NULL) {
    strlit2622 = alloc_String(", %object* %params_0");
  }
// compilenode returning strlit2622
  params[0] = strlit2622;
  Object opresult2624 = callmethod(opresult2621, "++", 1, params);
// compilenode returning opresult2624
// Begin line 770
  setline(770);
// compilenode returning self
  params[0] = opresult2624;
  Object call2625 = callmethod(self, "out",
    1, params);
// compilenode returning call2625
// Begin line 772
  setline(772);
// Begin line 770
  setline(770);
  if (strlit2626 == NULL) {
    strlit2626 = alloc_String("  %");
  }
// compilenode returning strlit2626
// compilenode returning *var_rnm
  params[0] = *var_rnm;
  Object opresult2628 = callmethod(strlit2626, "++", 1, params);
// compilenode returning opresult2628
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2630 = callmethod(opresult2628, "++", 1, params);
// compilenode returning opresult2630
  if (strlit2631 == NULL) {
    strlit2631 = alloc_String(" = call %object @callmethod(%object ");
  }
// compilenode returning strlit2631
  params[0] = strlit2631;
  Object opresult2633 = callmethod(opresult2630, "++", 1, params);
// compilenode returning opresult2633
// Begin line 771
  setline(771);
// compilenode returning *var_left
  params[0] = *var_left;
  Object opresult2635 = callmethod(opresult2633, "++", 1, params);
// compilenode returning opresult2635
  if (strlit2636 == NULL) {
    strlit2636 = alloc_String(", i8* getelementptr([2 x i8]* @.str._");
  }
// compilenode returning strlit2636
  params[0] = strlit2636;
  Object opresult2638 = callmethod(opresult2635, "++", 1, params);
// compilenode returning opresult2638
// compilenode returning *var_opnm
  params[0] = *var_opnm;
  Object opresult2640 = callmethod(opresult2638, "++", 1, params);
// compilenode returning opresult2640
// Begin line 772
  setline(772);
  if (strlit2641 == NULL) {
    strlit2641 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit2641
  params[0] = strlit2641;
  Object opresult2643 = callmethod(opresult2640, "++", 1, params);
// compilenode returning opresult2643
// Begin line 773
  setline(773);
// compilenode returning self
  params[0] = opresult2643;
  Object call2644 = callmethod(self, "out",
    1, params);
// compilenode returning call2644
// Begin line 774
  setline(774);
// Begin line 1429
  setline(1429);
// Begin line 774
  setline(774);
// Begin line 773
  setline(773);
  if (strlit2645 == NULL) {
    strlit2645 = alloc_String("%");
  }
// compilenode returning strlit2645
// compilenode returning *var_rnm
  params[0] = *var_rnm;
  Object opresult2647 = callmethod(strlit2645, "++", 1, params);
// compilenode returning opresult2647
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2649 = callmethod(opresult2647, "++", 1, params);
// compilenode returning opresult2649
// compilenode returning *var_o
  params[0] = opresult2649;
  Object call2650 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2650
// compilenode returning nothing
// Begin line 775
  setline(775);
// Begin line 774
  setline(774);
// compilenode returning *var_auto_count
  Object num2651 = alloc_Float64(1.0);
// compilenode returning num2651
  params[0] = num2651;
  Object sum2653 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2653
  *var_auto_count = sum2653;
  if (sum2653 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2552 = nothing;
  } else {
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_evl = alloc_var();
  *var_evl = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 776
  setline(776);
// Begin line 1429
  setline(1429);
// Begin line 776
  setline(776);
// compilenode returning *var_o
  Object call2655 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2655
// compilenode returning call2655
  Object call2656 = gracelib_length(call2655);
// compilenode returning call2656
  Object num2657 = alloc_Float64(1.0);
// compilenode returning num2657
  params[0] = num2657;
  Object sum2659 = callmethod(call2656, "+", 1, params);
// compilenode returning sum2659
  var_len = alloc_var();
  *var_len = sum2659;
  if (sum2659 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 777
  setline(777);
// Begin line 1429
  setline(1429);
// Begin line 777
  setline(777);
// Begin line 1429
  setline(1429);
// Begin line 777
  setline(777);
// compilenode returning *var_o
  Object call2660 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2660
// compilenode returning call2660
  Object call2661 = callmethod(call2660, "_escape",
    0, params);
// compilenode returning call2661
// compilenode returning call2661
  var_evl = alloc_var();
  *var_evl = call2661;
  if (call2661 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 780
  setline(780);
// Begin line 778
  setline(778);
  if (strlit2662 == NULL) {
    strlit2662 = alloc_String("@.str");
  }
// compilenode returning strlit2662
// Begin line 780
  setline(780);
// Begin line 1429
  setline(1429);
// Begin line 778
  setline(778);
// compilenode returning *var_constants
  Object call2663 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call2663
// compilenode returning call2663
  params[0] = call2663;
  Object opresult2665 = callmethod(strlit2662, "++", 1, params);
// compilenode returning opresult2665
  if (strlit2666 == NULL) {
    strlit2666 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit2666
  params[0] = strlit2666;
  Object opresult2668 = callmethod(opresult2665, "++", 1, params);
// compilenode returning opresult2668
// Begin line 779
  setline(779);
  if (strlit2669 == NULL) {
    strlit2669 = alloc_String("constant [");
  }
// compilenode returning strlit2669
  params[0] = strlit2669;
  Object opresult2671 = callmethod(opresult2668, "++", 1, params);
// compilenode returning opresult2671
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult2673 = callmethod(opresult2671, "++", 1, params);
// compilenode returning opresult2673
  if (strlit2674 == NULL) {
    strlit2674 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit2674
  params[0] = strlit2674;
  Object opresult2676 = callmethod(opresult2673, "++", 1, params);
// compilenode returning opresult2676
// compilenode returning *var_evl
  params[0] = *var_evl;
  Object opresult2678 = callmethod(opresult2676, "++", 1, params);
// compilenode returning opresult2678
  if (strlit2679 == NULL) {
    strlit2679 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit2679
  params[0] = strlit2679;
  Object opresult2681 = callmethod(opresult2678, "++", 1, params);
// compilenode returning opresult2681
  var_con = alloc_var();
  *var_con = opresult2681;
  if (opresult2681 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 780
  setline(780);
  if (strlit2682 == NULL) {
    strlit2682 = alloc_String("  store %object ");
  }
// compilenode returning strlit2682
// compilenode returning *var_right
  params[0] = *var_right;
  Object opresult2684 = callmethod(strlit2682, "++", 1, params);
// compilenode returning opresult2684
  if (strlit2685 == NULL) {
    strlit2685 = alloc_String(", %object* %params_0");
  }
// compilenode returning strlit2685
  params[0] = strlit2685;
  Object opresult2687 = callmethod(opresult2684, "++", 1, params);
// compilenode returning opresult2687
// Begin line 781
  setline(781);
// compilenode returning self
  params[0] = opresult2687;
  Object call2688 = callmethod(self, "out",
    1, params);
// compilenode returning call2688
// Begin line 784
  setline(784);
// Begin line 781
  setline(781);
  if (strlit2689 == NULL) {
    strlit2689 = alloc_String("  %opresult");
  }
// compilenode returning strlit2689
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2691 = callmethod(strlit2689, "++", 1, params);
// compilenode returning opresult2691
  if (strlit2692 == NULL) {
    strlit2692 = alloc_String(" = call %object ");
  }
// compilenode returning strlit2692
  params[0] = strlit2692;
  Object opresult2694 = callmethod(opresult2691, "++", 1, params);
// compilenode returning opresult2694
// Begin line 782
  setline(782);
  if (strlit2695 == NULL) {
    strlit2695 = alloc_String("@callmethod(%object ");
  }
// compilenode returning strlit2695
  params[0] = strlit2695;
  Object opresult2697 = callmethod(opresult2694, "++", 1, params);
// compilenode returning opresult2697
// compilenode returning *var_left
  params[0] = *var_left;
  Object opresult2699 = callmethod(opresult2697, "++", 1, params);
// compilenode returning opresult2699
// Begin line 783
  setline(783);
  if (strlit2700 == NULL) {
    strlit2700 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit2700
  params[0] = strlit2700;
  Object opresult2702 = callmethod(opresult2699, "++", 1, params);
// compilenode returning opresult2702
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult2704 = callmethod(opresult2702, "++", 1, params);
// compilenode returning opresult2704
  if (strlit2705 == NULL) {
    strlit2705 = alloc_String(" x i8]* @.str");
  }
// compilenode returning strlit2705
  params[0] = strlit2705;
  Object opresult2707 = callmethod(opresult2704, "++", 1, params);
// compilenode returning opresult2707
// Begin line 784
  setline(784);
// Begin line 1429
  setline(1429);
// Begin line 784
  setline(784);
// compilenode returning *var_constants
  Object call2708 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call2708
// compilenode returning call2708
  params[0] = call2708;
  Object opresult2710 = callmethod(opresult2707, "++", 1, params);
// compilenode returning opresult2710
  if (strlit2711 == NULL) {
    strlit2711 = alloc_String(",i32 0,i32 0), i32 1, %object* %params)");
  }
// compilenode returning strlit2711
  params[0] = strlit2711;
  Object opresult2713 = callmethod(opresult2710, "++", 1, params);
// compilenode returning opresult2713
// Begin line 785
  setline(785);
// compilenode returning self
  params[0] = opresult2713;
  Object call2714 = callmethod(self, "out",
    1, params);
// compilenode returning call2714
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call2715 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call2715
// Begin line 787
  setline(787);
// Begin line 1429
  setline(1429);
// Begin line 787
  setline(787);
// Begin line 786
  setline(786);
  if (strlit2716 == NULL) {
    strlit2716 = alloc_String("%opresult");
  }
// compilenode returning strlit2716
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2718 = callmethod(strlit2716, "++", 1, params);
// compilenode returning opresult2718
// compilenode returning *var_o
  params[0] = opresult2718;
  Object call2719 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2719
// compilenode returning nothing
// Begin line 788
  setline(788);
// Begin line 787
  setline(787);
// compilenode returning *var_auto_count
  Object num2720 = alloc_Float64(1.0);
// compilenode returning num2720
  params[0] = num2720;
  Object sum2722 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2722
  *var_auto_count = sum2722;
  if (sum2722 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2552 = nothing;
  }
// compilenode returning if2552
  return if2552;
}
Object meth_genllvm29_apply2735(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[1];
  Object *var_args = closure[0];
  Object self = *closure[1];
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 798
  setline(798);
// compilenode returning *var_p
// Begin line 799
  setline(799);
// compilenode returning self
  params[0] = *var_p;
  Object call2736 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2736
  var_r = alloc_var();
  *var_r = call2736;
  if (call2736 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_args
  params[0] = *var_r;
  Object call2737 = callmethod(*var_args, "push",
    1, params);
// compilenode returning call2737
  return call2737;
}
Object meth_genllvm29_apply2791(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object self = *closure[1];
// Begin line 811
  setline(811);
  if (strlit2792 == NULL) {
    strlit2792 = alloc_String("  store %object ");
  }
// compilenode returning strlit2792
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult2794 = callmethod(strlit2792, "++", 1, params);
// compilenode returning opresult2794
  if (strlit2795 == NULL) {
    strlit2795 = alloc_String(", %object* %params_");
  }
// compilenode returning strlit2795
  params[0] = strlit2795;
  Object opresult2797 = callmethod(opresult2794, "++", 1, params);
// compilenode returning opresult2797
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult2799 = callmethod(opresult2797, "++", 1, params);
// compilenode returning opresult2799
  if (strlit2800 == NULL) {
    strlit2800 = alloc_String("");
  }
// compilenode returning strlit2800
  params[0] = strlit2800;
  Object opresult2802 = callmethod(opresult2799, "++", 1, params);
// compilenode returning opresult2802
// Begin line 812
  setline(812);
// compilenode returning self
  params[0] = opresult2802;
  Object call2803 = callmethod(self, "out",
    1, params);
// compilenode returning call2803
// Begin line 813
  setline(813);
// Begin line 812
  setline(812);
// compilenode returning *var_i
  Object num2804 = alloc_Float64(1.0);
// compilenode returning num2804
  params[0] = num2804;
  Object sum2806 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum2806
  *var_i = sum2806;
  if (sum2806 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply2876(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object self = *closure[1];
// Begin line 826
  setline(826);
  if (strlit2877 == NULL) {
    strlit2877 = alloc_String("  store %object ");
  }
// compilenode returning strlit2877
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult2879 = callmethod(strlit2877, "++", 1, params);
// compilenode returning opresult2879
  if (strlit2880 == NULL) {
    strlit2880 = alloc_String(", %object* %params_");
  }
// compilenode returning strlit2880
  params[0] = strlit2880;
  Object opresult2882 = callmethod(opresult2879, "++", 1, params);
// compilenode returning opresult2882
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult2884 = callmethod(opresult2882, "++", 1, params);
// compilenode returning opresult2884
  if (strlit2885 == NULL) {
    strlit2885 = alloc_String("");
  }
// compilenode returning strlit2885
  params[0] = strlit2885;
  Object opresult2887 = callmethod(opresult2884, "++", 1, params);
// compilenode returning opresult2887
// Begin line 827
  setline(827);
// compilenode returning self
  params[0] = opresult2887;
  Object call2888 = callmethod(self, "out",
    1, params);
// compilenode returning call2888
// Begin line 828
  setline(828);
// Begin line 827
  setline(827);
// compilenode returning *var_i
  Object num2889 = alloc_Float64(1.0);
// compilenode returning num2889
  params[0] = num2889;
  Object sum2891 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum2891
  *var_i = sum2891;
  if (sum2891 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilecall2724(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[23];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_paramsUsed = closure[0];
  Object *var_constants = closure[1];
  Object *var_auto_count = closure[2];
  Object *var_args = alloc_var();
  *var_args = undefined;
  Object *var_obj = alloc_var();
  *var_obj = undefined;
  Object *var_len = alloc_var();
  *var_len = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
  Object *var_evl = alloc_var();
  *var_evl = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
// Begin line 792
  setline(792);
  Object array2725 = alloc_List();
// compilenode returning array2725
  var_args = alloc_var();
  *var_args = array2725;
  if (array2725 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 793
  setline(793);
// Begin line 792
  setline(792);
  if (strlit2726 == NULL) {
    strlit2726 = alloc_String("");
  }
// compilenode returning strlit2726
  var_obj = alloc_var();
  *var_obj = strlit2726;
  if (strlit2726 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 794
  setline(794);
// Begin line 793
  setline(793);
  Object num2727 = alloc_Float64(0.0);
// compilenode returning num2727
  var_len = alloc_var();
  *var_len = num2727;
  if (num2727 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 795
  setline(795);
// Begin line 794
  setline(794);
  if (strlit2728 == NULL) {
    strlit2728 = alloc_String("");
  }
// compilenode returning strlit2728
  var_con = alloc_var();
  *var_con = strlit2728;
  if (strlit2728 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 796
  setline(796);
  var_evl = alloc_var();
  *var_evl = undefined;
// compilenode returning nothing
// Begin line 797
  setline(797);
// Begin line 796
  setline(796);
  Object num2729 = alloc_Float64(0.0);
// compilenode returning num2729
  var_i = alloc_var();
  *var_i = num2729;
  if (num2729 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 799
  setline(799);
// Begin line 801
  setline(801);
// Begin line 1429
  setline(1429);
// Begin line 797
  setline(797);
// compilenode returning *var_o
  Object call2731 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call2731
// compilenode returning call2731
// Begin line 799
  setline(799);
// Begin line 1429
  setline(1429);
  Object obj2733 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2733, self, 0);
  addmethod2(obj2733, "outer", &reader_genllvm29_outer_2734);
  adddatum2(obj2733, self, 0);
  block_savedest(obj2733);
  Object **closure2735 = createclosure(2);
  addtoclosure(closure2735, var_args);
  Object *selfpp2738 = alloc_var();
  *selfpp2738 = self;
  addtoclosure(closure2735, selfpp2738);
  struct UserObject *uo2735 = (struct UserObject*)obj2733;
  uo2735->data[1] = (Object)closure2735;
  addmethod2(obj2733, "apply", &meth_genllvm29_apply2735);
  set_type(obj2733, 0);
// compilenode returning obj2733
  setclassname(obj2733, "Block<genllvm29:2732>");
// compilenode returning obj2733
  params[0] = call2731;
  Object iter2730 = callmethod(call2731, "iter", 1, params);
  while(1) {
    Object cond2730 = callmethod(iter2730, "havemore", 0, NULL);
    if (!istrue(cond2730)) break;
    params[0] = callmethod(iter2730, "next", 0, NULL);
    callmethod(obj2733, "apply", 1, params);
  }
// compilenode returning call2731
// Begin line 803
  setline(803);
// Begin line 804
  setline(804);
// Begin line 1429
  setline(1429);
// Begin line 801
  setline(801);
// compilenode returning *var_args
  Object call2740 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2740
// compilenode returning call2740
// compilenode returning *var_paramsUsed
  params[0] = *var_paramsUsed;
  Object opresult2742 = callmethod(call2740, ">", 1, params);
// compilenode returning opresult2742
  Object if2739;
  if (istrue(opresult2742)) {
// Begin line 803
  setline(803);
// Begin line 1429
  setline(1429);
// Begin line 802
  setline(802);
// compilenode returning *var_args
  Object call2743 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2743
// compilenode returning call2743
  *var_paramsUsed = call2743;
  if (call2743 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2739 = nothing;
  } else {
  }
// compilenode returning if2739
// Begin line 804
  setline(804);
// Begin line 1429
  setline(1429);
// Begin line 804
  setline(804);
// Begin line 1429
  setline(1429);
// Begin line 804
  setline(804);
// Begin line 1429
  setline(1429);
// Begin line 804
  setline(804);
// compilenode returning *var_o
  Object call2745 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2745
// compilenode returning call2745
  Object call2746 = callmethod(call2745, "value",
    0, params);
// compilenode returning call2746
// compilenode returning call2746
  Object call2747 = callmethod(call2746, "_escape",
    0, params);
// compilenode returning call2747
// compilenode returning call2747
  *var_evl = call2747;
  if (call2747 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 834
  setline(834);
// Begin line 836
  setline(836);
// Begin line 1429
  setline(1429);
// Begin line 836
  setline(836);
// Begin line 1429
  setline(1429);
// Begin line 805
  setline(805);
// compilenode returning *var_o
  Object call2750 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2750
// compilenode returning call2750
  Object call2751 = callmethod(call2750, "kind",
    0, params);
// compilenode returning call2751
// compilenode returning call2751
  if (strlit2752 == NULL) {
    strlit2752 = alloc_String("member");
  }
// compilenode returning strlit2752
  params[0] = strlit2752;
  Object opresult2754 = callmethod(call2751, "==", 1, params);
// compilenode returning opresult2754
  Object if2749;
  if (istrue(opresult2754)) {
// Begin line 806
  setline(806);
// Begin line 1429
  setline(1429);
// Begin line 806
  setline(806);
// Begin line 1429
  setline(1429);
// Begin line 806
  setline(806);
// compilenode returning *var_o
  Object call2755 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2755
// compilenode returning call2755
  Object call2756 = callmethod(call2755, "in",
    0, params);
// compilenode returning call2756
// compilenode returning call2756
// Begin line 807
  setline(807);
// compilenode returning self
  params[0] = call2756;
  Object call2757 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call2757
  *var_obj = call2757;
  if (call2757 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1429
  setline(1429);
// Begin line 807
  setline(807);
// Begin line 1429
  setline(1429);
// Begin line 807
  setline(807);
// compilenode returning *var_o
  Object call2759 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2759
// compilenode returning call2759
  Object call2760 = callmethod(call2759, "value",
    0, params);
// compilenode returning call2760
// compilenode returning call2760
  Object call2761 = gracelib_length(call2760);
// compilenode returning call2761
  Object num2762 = alloc_Float64(1.0);
// compilenode returning num2762
  params[0] = num2762;
  Object sum2764 = callmethod(call2761, "+", 1, params);
// compilenode returning sum2764
  *var_len = sum2764;
  if (sum2764 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 810
  setline(810);
// Begin line 808
  setline(808);
  if (strlit2766 == NULL) {
    strlit2766 = alloc_String("@.str");
  }
// compilenode returning strlit2766
// Begin line 810
  setline(810);
// Begin line 1429
  setline(1429);
// Begin line 808
  setline(808);
// compilenode returning *var_constants
  Object call2767 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call2767
// compilenode returning call2767
  params[0] = call2767;
  Object opresult2769 = callmethod(strlit2766, "++", 1, params);
// compilenode returning opresult2769
  if (strlit2770 == NULL) {
    strlit2770 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit2770
  params[0] = strlit2770;
  Object opresult2772 = callmethod(opresult2769, "++", 1, params);
// compilenode returning opresult2772
// Begin line 809
  setline(809);
  if (strlit2773 == NULL) {
    strlit2773 = alloc_String("constant [");
  }
// compilenode returning strlit2773
  params[0] = strlit2773;
  Object opresult2775 = callmethod(opresult2772, "++", 1, params);
// compilenode returning opresult2775
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult2777 = callmethod(opresult2775, "++", 1, params);
// compilenode returning opresult2777
  if (strlit2778 == NULL) {
    strlit2778 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit2778
  params[0] = strlit2778;
  Object opresult2780 = callmethod(opresult2777, "++", 1, params);
// compilenode returning opresult2780
// compilenode returning *var_evl
  params[0] = *var_evl;
  Object opresult2782 = callmethod(opresult2780, "++", 1, params);
// compilenode returning opresult2782
  if (strlit2783 == NULL) {
    strlit2783 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit2783
  params[0] = strlit2783;
  Object opresult2785 = callmethod(opresult2782, "++", 1, params);
// compilenode returning opresult2785
  *var_con = opresult2785;
  if (opresult2785 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 813
  setline(813);
// Begin line 810
  setline(810);
// compilenode returning *var_args
// Begin line 813
  setline(813);
// Begin line 1429
  setline(1429);
  Object obj2789 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2789, self, 0);
  addmethod2(obj2789, "outer", &reader_genllvm29_outer_2790);
  adddatum2(obj2789, self, 0);
  block_savedest(obj2789);
  Object **closure2791 = createclosure(2);
  addtoclosure(closure2791, var_i);
  Object *selfpp2808 = alloc_var();
  *selfpp2808 = self;
  addtoclosure(closure2791, selfpp2808);
  struct UserObject *uo2791 = (struct UserObject*)obj2789;
  uo2791->data[1] = (Object)closure2791;
  addmethod2(obj2789, "apply", &meth_genllvm29_apply2791);
  set_type(obj2789, 0);
// compilenode returning obj2789
  setclassname(obj2789, "Block<genllvm29:2788>");
// compilenode returning obj2789
  params[0] = *var_args;
  Object iter2787 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond2787 = callmethod(iter2787, "havemore", 0, NULL);
    if (!istrue(cond2787)) break;
    params[0] = callmethod(iter2787, "next", 0, NULL);
    callmethod(obj2789, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 818
  setline(818);
// Begin line 814
  setline(814);
  if (strlit2809 == NULL) {
    strlit2809 = alloc_String("  %call");
  }
// compilenode returning strlit2809
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2811 = callmethod(strlit2809, "++", 1, params);
// compilenode returning opresult2811
  if (strlit2812 == NULL) {
    strlit2812 = alloc_String(" = call %object ");
  }
// compilenode returning strlit2812
  params[0] = strlit2812;
  Object opresult2814 = callmethod(opresult2811, "++", 1, params);
// compilenode returning opresult2814
// Begin line 815
  setline(815);
  if (strlit2815 == NULL) {
    strlit2815 = alloc_String("@callmethod(%object ");
  }
// compilenode returning strlit2815
  params[0] = strlit2815;
  Object opresult2817 = callmethod(opresult2814, "++", 1, params);
// compilenode returning opresult2817
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult2819 = callmethod(opresult2817, "++", 1, params);
// compilenode returning opresult2819
// Begin line 816
  setline(816);
  if (strlit2820 == NULL) {
    strlit2820 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit2820
  params[0] = strlit2820;
  Object opresult2822 = callmethod(opresult2819, "++", 1, params);
// compilenode returning opresult2822
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult2824 = callmethod(opresult2822, "++", 1, params);
// compilenode returning opresult2824
  if (strlit2825 == NULL) {
    strlit2825 = alloc_String(" x i8]* @.str");
  }
// compilenode returning strlit2825
  params[0] = strlit2825;
  Object opresult2827 = callmethod(opresult2824, "++", 1, params);
// compilenode returning opresult2827
// Begin line 818
  setline(818);
// Begin line 1429
  setline(1429);
// Begin line 817
  setline(817);
// compilenode returning *var_constants
  Object call2828 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call2828
// compilenode returning call2828
  params[0] = call2828;
  Object opresult2830 = callmethod(opresult2827, "++", 1, params);
// compilenode returning opresult2830
  if (strlit2831 == NULL) {
    strlit2831 = alloc_String(",i32 0,i32 0), i32 ");
  }
// compilenode returning strlit2831
  params[0] = strlit2831;
  Object opresult2833 = callmethod(opresult2830, "++", 1, params);
// compilenode returning opresult2833
// Begin line 818
  setline(818);
// Begin line 1429
  setline(1429);
// Begin line 818
  setline(818);
// compilenode returning *var_args
  Object call2834 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2834
// compilenode returning call2834
  params[0] = call2834;
  Object opresult2836 = callmethod(opresult2833, "++", 1, params);
// compilenode returning opresult2836
  if (strlit2837 == NULL) {
    strlit2837 = alloc_String(", %object* %params)");
  }
// compilenode returning strlit2837
  params[0] = strlit2837;
  Object opresult2839 = callmethod(opresult2836, "++", 1, params);
// compilenode returning opresult2839
// Begin line 819
  setline(819);
// compilenode returning self
  params[0] = opresult2839;
  Object call2840 = callmethod(self, "out",
    1, params);
// compilenode returning call2840
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call2841 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call2841
    if2749 = call2841;
  } else {
// Begin line 822
  setline(822);
// Begin line 821
  setline(821);
  if (strlit2842 == NULL) {
    strlit2842 = alloc_String("%self");
  }
// compilenode returning strlit2842
  *var_obj = strlit2842;
  if (strlit2842 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 822
  setline(822);
// Begin line 1429
  setline(1429);
// Begin line 822
  setline(822);
// Begin line 1429
  setline(1429);
// Begin line 822
  setline(822);
// compilenode returning *var_o
  Object call2844 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2844
// compilenode returning call2844
  Object call2845 = callmethod(call2844, "value",
    0, params);
// compilenode returning call2845
// compilenode returning call2845
  Object call2846 = gracelib_length(call2845);
// compilenode returning call2846
  Object num2847 = alloc_Float64(1.0);
// compilenode returning num2847
  params[0] = num2847;
  Object sum2849 = callmethod(call2846, "+", 1, params);
// compilenode returning sum2849
  *var_len = sum2849;
  if (sum2849 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 825
  setline(825);
// Begin line 823
  setline(823);
  if (strlit2851 == NULL) {
    strlit2851 = alloc_String("@.str");
  }
// compilenode returning strlit2851
// Begin line 825
  setline(825);
// Begin line 1429
  setline(1429);
// Begin line 823
  setline(823);
// compilenode returning *var_constants
  Object call2852 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call2852
// compilenode returning call2852
  params[0] = call2852;
  Object opresult2854 = callmethod(strlit2851, "++", 1, params);
// compilenode returning opresult2854
  if (strlit2855 == NULL) {
    strlit2855 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit2855
  params[0] = strlit2855;
  Object opresult2857 = callmethod(opresult2854, "++", 1, params);
// compilenode returning opresult2857
// Begin line 824
  setline(824);
  if (strlit2858 == NULL) {
    strlit2858 = alloc_String("constant [");
  }
// compilenode returning strlit2858
  params[0] = strlit2858;
  Object opresult2860 = callmethod(opresult2857, "++", 1, params);
// compilenode returning opresult2860
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult2862 = callmethod(opresult2860, "++", 1, params);
// compilenode returning opresult2862
  if (strlit2863 == NULL) {
    strlit2863 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit2863
  params[0] = strlit2863;
  Object opresult2865 = callmethod(opresult2862, "++", 1, params);
// compilenode returning opresult2865
// compilenode returning *var_evl
  params[0] = *var_evl;
  Object opresult2867 = callmethod(opresult2865, "++", 1, params);
// compilenode returning opresult2867
  if (strlit2868 == NULL) {
    strlit2868 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit2868
  params[0] = strlit2868;
  Object opresult2870 = callmethod(opresult2867, "++", 1, params);
// compilenode returning opresult2870
  *var_con = opresult2870;
  if (opresult2870 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 828
  setline(828);
// Begin line 825
  setline(825);
// compilenode returning *var_args
// Begin line 828
  setline(828);
// Begin line 1429
  setline(1429);
  Object obj2874 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2874, self, 0);
  addmethod2(obj2874, "outer", &reader_genllvm29_outer_2875);
  adddatum2(obj2874, self, 0);
  block_savedest(obj2874);
  Object **closure2876 = createclosure(2);
  addtoclosure(closure2876, var_i);
  Object *selfpp2893 = alloc_var();
  *selfpp2893 = self;
  addtoclosure(closure2876, selfpp2893);
  struct UserObject *uo2876 = (struct UserObject*)obj2874;
  uo2876->data[1] = (Object)closure2876;
  addmethod2(obj2874, "apply", &meth_genllvm29_apply2876);
  set_type(obj2874, 0);
// compilenode returning obj2874
  setclassname(obj2874, "Block<genllvm29:2873>");
// compilenode returning obj2874
  params[0] = *var_args;
  Object iter2872 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond2872 = callmethod(iter2872, "havemore", 0, NULL);
    if (!istrue(cond2872)) break;
    params[0] = callmethod(iter2872, "next", 0, NULL);
    callmethod(obj2874, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 833
  setline(833);
// Begin line 829
  setline(829);
  if (strlit2894 == NULL) {
    strlit2894 = alloc_String("  %call");
  }
// compilenode returning strlit2894
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2896 = callmethod(strlit2894, "++", 1, params);
// compilenode returning opresult2896
  if (strlit2897 == NULL) {
    strlit2897 = alloc_String(" = call %object ");
  }
// compilenode returning strlit2897
  params[0] = strlit2897;
  Object opresult2899 = callmethod(opresult2896, "++", 1, params);
// compilenode returning opresult2899
// Begin line 830
  setline(830);
  if (strlit2900 == NULL) {
    strlit2900 = alloc_String("@callmethod(%object ");
  }
// compilenode returning strlit2900
  params[0] = strlit2900;
  Object opresult2902 = callmethod(opresult2899, "++", 1, params);
// compilenode returning opresult2902
// compilenode returning *var_obj
  params[0] = *var_obj;
  Object opresult2904 = callmethod(opresult2902, "++", 1, params);
// compilenode returning opresult2904
// Begin line 831
  setline(831);
  if (strlit2905 == NULL) {
    strlit2905 = alloc_String(", i8* getelementptr([");
  }
// compilenode returning strlit2905
  params[0] = strlit2905;
  Object opresult2907 = callmethod(opresult2904, "++", 1, params);
// compilenode returning opresult2907
// compilenode returning *var_len
  params[0] = *var_len;
  Object opresult2909 = callmethod(opresult2907, "++", 1, params);
// compilenode returning opresult2909
  if (strlit2910 == NULL) {
    strlit2910 = alloc_String(" x i8]* @.str");
  }
// compilenode returning strlit2910
  params[0] = strlit2910;
  Object opresult2912 = callmethod(opresult2909, "++", 1, params);
// compilenode returning opresult2912
// Begin line 833
  setline(833);
// Begin line 1429
  setline(1429);
// Begin line 832
  setline(832);
// compilenode returning *var_constants
  Object call2913 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call2913
// compilenode returning call2913
  params[0] = call2913;
  Object opresult2915 = callmethod(opresult2912, "++", 1, params);
// compilenode returning opresult2915
  if (strlit2916 == NULL) {
    strlit2916 = alloc_String(",i32 0,i32 0), i32 ");
  }
// compilenode returning strlit2916
  params[0] = strlit2916;
  Object opresult2918 = callmethod(opresult2915, "++", 1, params);
// compilenode returning opresult2918
// Begin line 833
  setline(833);
// Begin line 1429
  setline(1429);
// Begin line 833
  setline(833);
// compilenode returning *var_args
  Object call2919 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call2919
// compilenode returning call2919
  params[0] = call2919;
  Object opresult2921 = callmethod(opresult2918, "++", 1, params);
// compilenode returning opresult2921
  if (strlit2922 == NULL) {
    strlit2922 = alloc_String(", %object* %params)");
  }
// compilenode returning strlit2922
  params[0] = strlit2922;
  Object opresult2924 = callmethod(opresult2921, "++", 1, params);
// compilenode returning opresult2924
// Begin line 834
  setline(834);
// compilenode returning self
  params[0] = opresult2924;
  Object call2925 = callmethod(self, "out",
    1, params);
// compilenode returning call2925
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call2926 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call2926
    if2749 = call2926;
  }
// compilenode returning if2749
// Begin line 837
  setline(837);
// Begin line 1429
  setline(1429);
// Begin line 837
  setline(837);
// Begin line 836
  setline(836);
  if (strlit2927 == NULL) {
    strlit2927 = alloc_String("%call");
  }
// compilenode returning strlit2927
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2929 = callmethod(strlit2927, "++", 1, params);
// compilenode returning opresult2929
// compilenode returning *var_o
  params[0] = opresult2929;
  Object call2930 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call2930
// compilenode returning nothing
// Begin line 838
  setline(838);
// Begin line 837
  setline(837);
// compilenode returning *var_auto_count
  Object num2931 = alloc_Float64(1.0);
// compilenode returning num2931
  params[0] = num2931;
  Object sum2933 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum2933
  *var_auto_count = sum2933;
  if (sum2933 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply2948(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_i = closure[0];
  Object *var_escval = closure[1];
  Object self = *closure[2];
// Begin line 846
  setline(846);
// Begin line 847
  setline(847);
// Begin line 844
  setline(844);
// compilenode returning *var_i
  Object num2950 = alloc_Float64(2.0);
// compilenode returning num2950
  params[0] = num2950;
  Object modulus2952 = callmethod(*var_i, "%", 1, params);
// compilenode returning modulus2952
  Object num2953 = alloc_Float64(0.0);
// compilenode returning num2953
  params[0] = num2953;
  Object opresult2955 = callmethod(modulus2952, "==", 1, params);
// compilenode returning opresult2955
  Object if2949;
  if (istrue(opresult2955)) {
// Begin line 846
  setline(846);
// Begin line 845
  setline(845);
// compilenode returning *var_escval
  if (strlit2956 == NULL) {
    strlit2956 = alloc_String("\\");
  }
// compilenode returning strlit2956
  params[0] = strlit2956;
  Object opresult2958 = callmethod(*var_escval, "++", 1, params);
// compilenode returning opresult2958
  *var_escval = opresult2958;
  if (opresult2958 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2949 = nothing;
  } else {
  }
// compilenode returning if2949
// Begin line 848
  setline(848);
// Begin line 847
  setline(847);
// compilenode returning *var_escval
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult2961 = callmethod(*var_escval, "++", 1, params);
// compilenode returning opresult2961
  *var_escval = opresult2961;
  if (opresult2961 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 849
  setline(849);
// Begin line 848
  setline(848);
// compilenode returning *var_i
  Object num2963 = alloc_Float64(1.0);
// compilenode returning num2963
  params[0] = num2963;
  Object sum2965 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum2965
  *var_i = sum2965;
  if (sum2965 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileoctets2935(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[24];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_constants = closure[1];
  Object *var_escval = alloc_var();
  *var_escval = undefined;
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 841
  setline(841);
// Begin line 840
  setline(840);
  if (strlit2936 == NULL) {
    strlit2936 = alloc_String("");
  }
// compilenode returning strlit2936
  var_escval = alloc_var();
  *var_escval = strlit2936;
  if (strlit2936 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 841
  setline(841);
// Begin line 1429
  setline(1429);
// Begin line 841
  setline(841);
// compilenode returning *var_o
  Object call2937 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2937
// compilenode returning call2937
  Object call2938 = gracelib_length(call2937);
// compilenode returning call2938
  Object num2939 = alloc_Float64(2.0);
// compilenode returning num2939
  params[0] = num2939;
  Object quotient2941 = callmethod(call2938, "/", 1, params);
// compilenode returning quotient2941
  var_l = alloc_var();
  *var_l = quotient2941;
  if (quotient2941 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 843
  setline(843);
// Begin line 842
  setline(842);
  Object num2942 = alloc_Float64(0.0);
// compilenode returning num2942
  var_i = alloc_var();
  *var_i = num2942;
  if (num2942 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 849
  setline(849);
// Begin line 850
  setline(850);
// Begin line 1429
  setline(1429);
// Begin line 843
  setline(843);
// compilenode returning *var_o
  Object call2944 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call2944
// compilenode returning call2944
// Begin line 849
  setline(849);
// Begin line 1429
  setline(1429);
  Object obj2946 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2946, self, 0);
  addmethod2(obj2946, "outer", &reader_genllvm29_outer_2947);
  adddatum2(obj2946, self, 0);
  block_savedest(obj2946);
  Object **closure2948 = createclosure(3);
  addtoclosure(closure2948, var_i);
  addtoclosure(closure2948, var_escval);
  Object *selfpp2967 = alloc_var();
  *selfpp2967 = self;
  addtoclosure(closure2948, selfpp2967);
  struct UserObject *uo2948 = (struct UserObject*)obj2946;
  uo2948->data[1] = (Object)closure2948;
  addmethod2(obj2946, "apply", &meth_genllvm29_apply2948);
  set_type(obj2946, 0);
// compilenode returning obj2946
  setclassname(obj2946, "Block<genllvm29:2945>");
// compilenode returning obj2946
  params[0] = call2944;
  Object iter2943 = callmethod(call2944, "iter", 1, params);
  while(1) {
    Object cond2943 = callmethod(iter2943, "havemore", 0, NULL);
    if (!istrue(cond2943)) break;
    params[0] = callmethod(iter2943, "next", 0, NULL);
    callmethod(obj2946, "apply", 1, params);
  }
// compilenode returning call2944
// Begin line 851
  setline(851);
// Begin line 850
  setline(850);
  if (strlit2968 == NULL) {
    strlit2968 = alloc_String("  %tmp");
  }
// compilenode returning strlit2968
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2970 = callmethod(strlit2968, "++", 1, params);
// compilenode returning opresult2970
  if (strlit2971 == NULL) {
    strlit2971 = alloc_String(" = load %object* @.octlit");
  }
// compilenode returning strlit2971
  params[0] = strlit2971;
  Object opresult2973 = callmethod(opresult2970, "++", 1, params);
// compilenode returning opresult2973
// Begin line 851
  setline(851);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2975 = callmethod(opresult2973, "++", 1, params);
// compilenode returning opresult2975
// Begin line 852
  setline(852);
// compilenode returning self
  params[0] = opresult2975;
  Object call2976 = callmethod(self, "out",
    1, params);
// compilenode returning call2976
// Begin line 853
  setline(853);
// Begin line 852
  setline(852);
  if (strlit2977 == NULL) {
    strlit2977 = alloc_String("  %cmp");
  }
// compilenode returning strlit2977
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2979 = callmethod(strlit2977, "++", 1, params);
// compilenode returning opresult2979
  if (strlit2980 == NULL) {
    strlit2980 = alloc_String(" = icmp ne %object %tmp");
  }
// compilenode returning strlit2980
  params[0] = strlit2980;
  Object opresult2982 = callmethod(opresult2979, "++", 1, params);
// compilenode returning opresult2982
// Begin line 853
  setline(853);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2984 = callmethod(opresult2982, "++", 1, params);
// compilenode returning opresult2984
  if (strlit2985 == NULL) {
    strlit2985 = alloc_String(", null");
  }
// compilenode returning strlit2985
  params[0] = strlit2985;
  Object opresult2987 = callmethod(opresult2984, "++", 1, params);
// compilenode returning opresult2987
// Begin line 854
  setline(854);
// compilenode returning self
  params[0] = opresult2987;
  Object call2988 = callmethod(self, "out",
    1, params);
// compilenode returning call2988
// Begin line 856
  setline(856);
// Begin line 854
  setline(854);
  if (strlit2989 == NULL) {
    strlit2989 = alloc_String("  br i1 %cmp");
  }
// compilenode returning strlit2989
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2991 = callmethod(strlit2989, "++", 1, params);
// compilenode returning opresult2991
  if (strlit2992 == NULL) {
    strlit2992 = alloc_String(", label %octlit");
  }
// compilenode returning strlit2992
  params[0] = strlit2992;
  Object opresult2994 = callmethod(opresult2991, "++", 1, params);
// compilenode returning opresult2994
// Begin line 855
  setline(855);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult2996 = callmethod(opresult2994, "++", 1, params);
// compilenode returning opresult2996
  if (strlit2997 == NULL) {
    strlit2997 = alloc_String(".already, label %octlit");
  }
// compilenode returning strlit2997
  params[0] = strlit2997;
  Object opresult2999 = callmethod(opresult2996, "++", 1, params);
// compilenode returning opresult2999
// Begin line 856
  setline(856);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3001 = callmethod(opresult2999, "++", 1, params);
// compilenode returning opresult3001
  if (strlit3002 == NULL) {
    strlit3002 = alloc_String(".define");
  }
// compilenode returning strlit3002
  params[0] = strlit3002;
  Object opresult3004 = callmethod(opresult3001, "++", 1, params);
// compilenode returning opresult3004
// Begin line 857
  setline(857);
// compilenode returning self
  params[0] = opresult3004;
  Object call3005 = callmethod(self, "out",
    1, params);
// compilenode returning call3005
  if (strlit3006 == NULL) {
    strlit3006 = alloc_String("octlit");
  }
// compilenode returning strlit3006
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3008 = callmethod(strlit3006, "++", 1, params);
// compilenode returning opresult3008
  if (strlit3009 == NULL) {
    strlit3009 = alloc_String(".already");
  }
// compilenode returning strlit3009
  params[0] = strlit3009;
  Object opresult3011 = callmethod(opresult3008, "++", 1, params);
// compilenode returning opresult3011
// Begin line 858
  setline(858);
// compilenode returning self
  params[0] = opresult3011;
  Object call3012 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3012
// Begin line 859
  setline(859);
// Begin line 858
  setline(858);
  if (strlit3013 == NULL) {
    strlit3013 = alloc_String("  %alreadyoctets");
  }
// compilenode returning strlit3013
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3015 = callmethod(strlit3013, "++", 1, params);
// compilenode returning opresult3015
  if (strlit3016 == NULL) {
    strlit3016 = alloc_String(" = load %object* @.octlit");
  }
// compilenode returning strlit3016
  params[0] = strlit3016;
  Object opresult3018 = callmethod(opresult3015, "++", 1, params);
// compilenode returning opresult3018
// Begin line 859
  setline(859);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3020 = callmethod(opresult3018, "++", 1, params);
// compilenode returning opresult3020
// Begin line 860
  setline(860);
// compilenode returning self
  params[0] = opresult3020;
  Object call3021 = callmethod(self, "out",
    1, params);
// compilenode returning call3021
  if (strlit3022 == NULL) {
    strlit3022 = alloc_String("  br label %octlit");
  }
// compilenode returning strlit3022
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3024 = callmethod(strlit3022, "++", 1, params);
// compilenode returning opresult3024
  if (strlit3025 == NULL) {
    strlit3025 = alloc_String(".end");
  }
// compilenode returning strlit3025
  params[0] = strlit3025;
  Object opresult3027 = callmethod(opresult3024, "++", 1, params);
// compilenode returning opresult3027
// Begin line 861
  setline(861);
// compilenode returning self
  params[0] = opresult3027;
  Object call3028 = callmethod(self, "out",
    1, params);
// compilenode returning call3028
  if (strlit3029 == NULL) {
    strlit3029 = alloc_String("octlit");
  }
// compilenode returning strlit3029
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3031 = callmethod(strlit3029, "++", 1, params);
// compilenode returning opresult3031
  if (strlit3032 == NULL) {
    strlit3032 = alloc_String(".define");
  }
// compilenode returning strlit3032
  params[0] = strlit3032;
  Object opresult3034 = callmethod(opresult3031, "++", 1, params);
// compilenode returning opresult3034
// Begin line 862
  setline(862);
// compilenode returning self
  params[0] = opresult3034;
  Object call3035 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3035
  if (strlit3036 == NULL) {
    strlit3036 = alloc_String("  %oct");
  }
// compilenode returning strlit3036
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3038 = callmethod(strlit3036, "++", 1, params);
// compilenode returning opresult3038
  if (strlit3039 == NULL) {
    strlit3039 = alloc_String(" = getelementptr [");
  }
// compilenode returning strlit3039
  params[0] = strlit3039;
  Object opresult3041 = callmethod(opresult3038, "++", 1, params);
// compilenode returning opresult3041
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3043 = callmethod(opresult3041, "++", 1, params);
// compilenode returning opresult3043
  if (strlit3044 == NULL) {
    strlit3044 = alloc_String(" x i8]* @.oct");
  }
// compilenode returning strlit3044
  params[0] = strlit3044;
  Object opresult3046 = callmethod(opresult3043, "++", 1, params);
// compilenode returning opresult3046
// Begin line 1429
  setline(1429);
// Begin line 862
  setline(862);
// compilenode returning *var_constants
  Object call3047 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call3047
// compilenode returning call3047
  params[0] = call3047;
  Object opresult3049 = callmethod(opresult3046, "++", 1, params);
// compilenode returning opresult3049
  if (strlit3050 == NULL) {
    strlit3050 = alloc_String(", i32 0, i32 0");
  }
// compilenode returning strlit3050
  params[0] = strlit3050;
  Object opresult3052 = callmethod(opresult3049, "++", 1, params);
// compilenode returning opresult3052
// Begin line 863
  setline(863);
// compilenode returning self
  params[0] = opresult3052;
  Object call3053 = callmethod(self, "out",
    1, params);
// compilenode returning call3053
// Begin line 865
  setline(865);
// Begin line 863
  setline(863);
  if (strlit3054 == NULL) {
    strlit3054 = alloc_String("  %defoctets");
  }
// compilenode returning strlit3054
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3056 = callmethod(strlit3054, "++", 1, params);
// compilenode returning opresult3056
  if (strlit3057 == NULL) {
    strlit3057 = alloc_String(" = call %object ");
  }
// compilenode returning strlit3057
  params[0] = strlit3057;
  Object opresult3059 = callmethod(opresult3056, "++", 1, params);
// compilenode returning opresult3059
// Begin line 864
  setline(864);
  if (strlit3060 == NULL) {
    strlit3060 = alloc_String("@alloc_Octets(i8* ");
  }
// compilenode returning strlit3060
  params[0] = strlit3060;
  Object opresult3062 = callmethod(opresult3059, "++", 1, params);
// compilenode returning opresult3062
// Begin line 865
  setline(865);
  if (strlit3063 == NULL) {
    strlit3063 = alloc_String("%oct");
  }
// compilenode returning strlit3063
  params[0] = strlit3063;
  Object opresult3065 = callmethod(opresult3062, "++", 1, params);
// compilenode returning opresult3065
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3067 = callmethod(opresult3065, "++", 1, params);
// compilenode returning opresult3067
  if (strlit3068 == NULL) {
    strlit3068 = alloc_String(", i32 ");
  }
// compilenode returning strlit3068
  params[0] = strlit3068;
  Object opresult3070 = callmethod(opresult3067, "++", 1, params);
// compilenode returning opresult3070
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3072 = callmethod(opresult3070, "++", 1, params);
// compilenode returning opresult3072
  if (strlit3073 == NULL) {
    strlit3073 = alloc_String(")");
  }
// compilenode returning strlit3073
  params[0] = strlit3073;
  Object opresult3075 = callmethod(opresult3072, "++", 1, params);
// compilenode returning opresult3075
// Begin line 866
  setline(866);
// compilenode returning self
  params[0] = opresult3075;
  Object call3076 = callmethod(self, "out",
    1, params);
// compilenode returning call3076
// Begin line 867
  setline(867);
// Begin line 866
  setline(866);
  if (strlit3077 == NULL) {
    strlit3077 = alloc_String("  store %object %defoctets");
  }
// compilenode returning strlit3077
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3079 = callmethod(strlit3077, "++", 1, params);
// compilenode returning opresult3079
  if (strlit3080 == NULL) {
    strlit3080 = alloc_String(", %object* ");
  }
// compilenode returning strlit3080
  params[0] = strlit3080;
  Object opresult3082 = callmethod(opresult3079, "++", 1, params);
// compilenode returning opresult3082
// Begin line 867
  setline(867);
  if (strlit3083 == NULL) {
    strlit3083 = alloc_String("@.octlit");
  }
// compilenode returning strlit3083
  params[0] = strlit3083;
  Object opresult3085 = callmethod(opresult3082, "++", 1, params);
// compilenode returning opresult3085
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3087 = callmethod(opresult3085, "++", 1, params);
// compilenode returning opresult3087
// Begin line 868
  setline(868);
// compilenode returning self
  params[0] = opresult3087;
  Object call3088 = callmethod(self, "out",
    1, params);
// compilenode returning call3088
  if (strlit3089 == NULL) {
    strlit3089 = alloc_String("br label %octlit");
  }
// compilenode returning strlit3089
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3091 = callmethod(strlit3089, "++", 1, params);
// compilenode returning opresult3091
  if (strlit3092 == NULL) {
    strlit3092 = alloc_String(".end");
  }
// compilenode returning strlit3092
  params[0] = strlit3092;
  Object opresult3094 = callmethod(opresult3091, "++", 1, params);
// compilenode returning opresult3094
// Begin line 869
  setline(869);
// compilenode returning self
  params[0] = opresult3094;
  Object call3095 = callmethod(self, "out",
    1, params);
// compilenode returning call3095
  if (strlit3096 == NULL) {
    strlit3096 = alloc_String("octlit");
  }
// compilenode returning strlit3096
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3098 = callmethod(strlit3096, "++", 1, params);
// compilenode returning opresult3098
  if (strlit3099 == NULL) {
    strlit3099 = alloc_String(".end");
  }
// compilenode returning strlit3099
  params[0] = strlit3099;
  Object opresult3101 = callmethod(opresult3098, "++", 1, params);
// compilenode returning opresult3101
// Begin line 870
  setline(870);
// compilenode returning self
  params[0] = opresult3101;
  Object call3102 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3102
// Begin line 873
  setline(873);
// Begin line 870
  setline(870);
  if (strlit3103 == NULL) {
    strlit3103 = alloc_String(" %octets");
  }
// compilenode returning strlit3103
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3105 = callmethod(strlit3103, "++", 1, params);
// compilenode returning opresult3105
  if (strlit3106 == NULL) {
    strlit3106 = alloc_String(" = phi %object [%alreadyoctets");
  }
// compilenode returning strlit3106
  params[0] = strlit3106;
  Object opresult3108 = callmethod(opresult3105, "++", 1, params);
// compilenode returning opresult3108
// Begin line 871
  setline(871);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3110 = callmethod(opresult3108, "++", 1, params);
// compilenode returning opresult3110
  if (strlit3111 == NULL) {
    strlit3111 = alloc_String(", %octlit");
  }
// compilenode returning strlit3111
  params[0] = strlit3111;
  Object opresult3113 = callmethod(opresult3110, "++", 1, params);
// compilenode returning opresult3113
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3115 = callmethod(opresult3113, "++", 1, params);
// compilenode returning opresult3115
  if (strlit3116 == NULL) {
    strlit3116 = alloc_String(".already], ");
  }
// compilenode returning strlit3116
  params[0] = strlit3116;
  Object opresult3118 = callmethod(opresult3115, "++", 1, params);
// compilenode returning opresult3118
// Begin line 872
  setline(872);
  if (strlit3119 == NULL) {
    strlit3119 = alloc_String("[%defoctets");
  }
// compilenode returning strlit3119
  params[0] = strlit3119;
  Object opresult3121 = callmethod(opresult3118, "++", 1, params);
// compilenode returning opresult3121
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3123 = callmethod(opresult3121, "++", 1, params);
// compilenode returning opresult3123
  if (strlit3124 == NULL) {
    strlit3124 = alloc_String(", %octlit");
  }
// compilenode returning strlit3124
  params[0] = strlit3124;
  Object opresult3126 = callmethod(opresult3123, "++", 1, params);
// compilenode returning opresult3126
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3128 = callmethod(opresult3126, "++", 1, params);
// compilenode returning opresult3128
// Begin line 873
  setline(873);
  if (strlit3129 == NULL) {
    strlit3129 = alloc_String(".define]");
  }
// compilenode returning strlit3129
  params[0] = strlit3129;
  Object opresult3131 = callmethod(opresult3128, "++", 1, params);
// compilenode returning opresult3131
// Begin line 874
  setline(874);
// compilenode returning self
  params[0] = opresult3131;
  Object call3132 = callmethod(self, "out",
    1, params);
// compilenode returning call3132
// Begin line 876
  setline(876);
// Begin line 874
  setline(874);
  if (strlit3133 == NULL) {
    strlit3133 = alloc_String("@.oct");
  }
// compilenode returning strlit3133
// Begin line 876
  setline(876);
// Begin line 1429
  setline(1429);
// Begin line 874
  setline(874);
// compilenode returning *var_constants
  Object call3134 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call3134
// compilenode returning call3134
  params[0] = call3134;
  Object opresult3136 = callmethod(strlit3133, "++", 1, params);
// compilenode returning opresult3136
  if (strlit3137 == NULL) {
    strlit3137 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit3137
  params[0] = strlit3137;
  Object opresult3139 = callmethod(opresult3136, "++", 1, params);
// compilenode returning opresult3139
// Begin line 875
  setline(875);
  if (strlit3140 == NULL) {
    strlit3140 = alloc_String("constant [");
  }
// compilenode returning strlit3140
  params[0] = strlit3140;
  Object opresult3142 = callmethod(opresult3139, "++", 1, params);
// compilenode returning opresult3142
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3144 = callmethod(opresult3142, "++", 1, params);
// compilenode returning opresult3144
  if (strlit3145 == NULL) {
    strlit3145 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit3145
  params[0] = strlit3145;
  Object opresult3147 = callmethod(opresult3144, "++", 1, params);
// compilenode returning opresult3147
// compilenode returning *var_escval
  params[0] = *var_escval;
  Object opresult3149 = callmethod(opresult3147, "++", 1, params);
// compilenode returning opresult3149
  if (strlit3150 == NULL) {
    strlit3150 = alloc_String("""\x22""");
  }
// compilenode returning strlit3150
  params[0] = strlit3150;
  Object opresult3152 = callmethod(opresult3149, "++", 1, params);
// compilenode returning opresult3152
  var_con = alloc_var();
  *var_con = opresult3152;
  if (opresult3152 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 876
  setline(876);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3153 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3153
// Begin line 879
  setline(879);
// Begin line 877
  setline(877);
  if (strlit3154 == NULL) {
    strlit3154 = alloc_String("@.octlit");
  }
// compilenode returning strlit3154
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3156 = callmethod(strlit3154, "++", 1, params);
// compilenode returning opresult3156
// Begin line 878
  setline(878);
  if (strlit3157 == NULL) {
    strlit3157 = alloc_String(" = private global %object null");
  }
// compilenode returning strlit3157
  params[0] = strlit3157;
  Object opresult3159 = callmethod(opresult3156, "++", 1, params);
// compilenode returning opresult3159
  *var_con = opresult3159;
  if (opresult3159 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 879
  setline(879);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3161 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3161
// Begin line 881
  setline(881);
// Begin line 1429
  setline(1429);
// Begin line 881
  setline(881);
// Begin line 880
  setline(880);
  if (strlit3162 == NULL) {
    strlit3162 = alloc_String("%octets");
  }
// compilenode returning strlit3162
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3164 = callmethod(strlit3162, "++", 1, params);
// compilenode returning opresult3164
// compilenode returning *var_o
  params[0] = opresult3164;
  Object call3165 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3165
// compilenode returning nothing
// Begin line 882
  setline(882);
// Begin line 881
  setline(881);
// compilenode returning *var_auto_count
  Object num3166 = alloc_Float64(1.0);
// compilenode returning num3166
  params[0] = num3166;
  Object sum3168 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum3168
  *var_auto_count = sum3168;
  if (sum3168 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compileimport3170(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[25];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_bblock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_staticmodules = closure[2];
  Object *var_constants = closure[3];
  Object *var_modules = closure[4];
  Object *var_con = alloc_var();
  *var_con = undefined;
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_modg = alloc_var();
  *var_modg = undefined;
  Object *var_sblock = alloc_var();
  *var_sblock = undefined;
// Begin line 884
  setline(884);
  if (strlit3171 == NULL) {
    strlit3171 = alloc_String("; Import of ");
  }
// compilenode returning strlit3171
// Begin line 1429
  setline(1429);
// Begin line 884
  setline(884);
// Begin line 1429
  setline(1429);
// Begin line 884
  setline(884);
// compilenode returning *var_o
  Object call3172 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3172
// compilenode returning call3172
  Object call3173 = callmethod(call3172, "value",
    0, params);
// compilenode returning call3173
// compilenode returning call3173
  params[0] = call3173;
  Object opresult3175 = callmethod(strlit3171, "++", 1, params);
// compilenode returning opresult3175
// Begin line 885
  setline(885);
// compilenode returning self
  params[0] = opresult3175;
  Object call3176 = callmethod(self, "out",
    1, params);
// compilenode returning call3176
// Begin line 886
  setline(886);
  var_con = alloc_var();
  *var_con = undefined;
// compilenode returning nothing
// Begin line 1429
  setline(1429);
// Begin line 886
  setline(886);
// Begin line 1429
  setline(1429);
// Begin line 886
  setline(886);
// Begin line 1429
  setline(1429);
// Begin line 886
  setline(886);
// compilenode returning *var_o
  Object call3177 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3177
// compilenode returning call3177
  Object call3178 = callmethod(call3177, "value",
    0, params);
// compilenode returning call3178
// compilenode returning call3178
  Object call3179 = callmethod(call3178, "_escape",
    0, params);
// compilenode returning call3179
// compilenode returning call3179
  var_nm = alloc_var();
  *var_nm = call3179;
  if (call3179 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 888
  setline(888);
// Begin line 887
  setline(887);
  if (strlit3180 == NULL) {
    strlit3180 = alloc_String("@""\x22"".module.");
  }
// compilenode returning strlit3180
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3182 = callmethod(strlit3180, "++", 1, params);
// compilenode returning opresult3182
  if (strlit3183 == NULL) {
    strlit3183 = alloc_String("""\x22""");
  }
// compilenode returning strlit3183
  params[0] = strlit3183;
  Object opresult3185 = callmethod(opresult3182, "++", 1, params);
// compilenode returning opresult3185
  var_modg = alloc_var();
  *var_modg = opresult3185;
  if (opresult3185 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 889
  setline(889);
// Begin line 888
  setline(888);
// compilenode returning *var_bblock
  var_sblock = alloc_var();
  *var_sblock = *var_bblock;
  if (*var_bblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 889
  setline(889);
  if (strlit3186 == NULL) {
    strlit3186 = alloc_String("  %tmp");
  }
// compilenode returning strlit3186
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3188 = callmethod(strlit3186, "++", 1, params);
// compilenode returning opresult3188
  if (strlit3189 == NULL) {
    strlit3189 = alloc_String(" = load %object* ");
  }
// compilenode returning strlit3189
  params[0] = strlit3189;
  Object opresult3191 = callmethod(opresult3188, "++", 1, params);
// compilenode returning opresult3191
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult3193 = callmethod(opresult3191, "++", 1, params);
// compilenode returning opresult3193
// Begin line 890
  setline(890);
// compilenode returning self
  params[0] = opresult3193;
  Object call3194 = callmethod(self, "out",
    1, params);
// compilenode returning call3194
// Begin line 891
  setline(891);
// Begin line 890
  setline(890);
  if (strlit3195 == NULL) {
    strlit3195 = alloc_String("  %cmp");
  }
// compilenode returning strlit3195
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3197 = callmethod(strlit3195, "++", 1, params);
// compilenode returning opresult3197
  if (strlit3198 == NULL) {
    strlit3198 = alloc_String(" = icmp ne %object %tmp");
  }
// compilenode returning strlit3198
  params[0] = strlit3198;
  Object opresult3200 = callmethod(opresult3197, "++", 1, params);
// compilenode returning opresult3200
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3202 = callmethod(opresult3200, "++", 1, params);
// compilenode returning opresult3202
// Begin line 891
  setline(891);
  if (strlit3203 == NULL) {
    strlit3203 = alloc_String(", null");
  }
// compilenode returning strlit3203
  params[0] = strlit3203;
  Object opresult3205 = callmethod(opresult3202, "++", 1, params);
// compilenode returning opresult3205
// Begin line 892
  setline(892);
// compilenode returning self
  params[0] = opresult3205;
  Object call3206 = callmethod(self, "out",
    1, params);
// compilenode returning call3206
// Begin line 893
  setline(893);
// Begin line 892
  setline(892);
  if (strlit3207 == NULL) {
    strlit3207 = alloc_String("  br i1 %cmp");
  }
// compilenode returning strlit3207
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3209 = callmethod(strlit3207, "++", 1, params);
// compilenode returning opresult3209
  if (strlit3210 == NULL) {
    strlit3210 = alloc_String(", label %""\x22""import.");
  }
// compilenode returning strlit3210
  params[0] = strlit3210;
  Object opresult3212 = callmethod(opresult3209, "++", 1, params);
// compilenode returning opresult3212
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3214 = callmethod(opresult3212, "++", 1, params);
// compilenode returning opresult3214
// Begin line 893
  setline(893);
  if (strlit3215 == NULL) {
    strlit3215 = alloc_String(".already""\x22"", label %""\x22""import.");
  }
// compilenode returning strlit3215
  params[0] = strlit3215;
  Object opresult3217 = callmethod(opresult3214, "++", 1, params);
// compilenode returning opresult3217
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3219 = callmethod(opresult3217, "++", 1, params);
// compilenode returning opresult3219
  if (strlit3220 == NULL) {
    strlit3220 = alloc_String(".define""\x22""");
  }
// compilenode returning strlit3220
  params[0] = strlit3220;
  Object opresult3222 = callmethod(opresult3219, "++", 1, params);
// compilenode returning opresult3222
// Begin line 894
  setline(894);
// compilenode returning self
  params[0] = opresult3222;
  Object call3223 = callmethod(self, "out",
    1, params);
// compilenode returning call3223
  if (strlit3224 == NULL) {
    strlit3224 = alloc_String("import.");
  }
// compilenode returning strlit3224
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3226 = callmethod(strlit3224, "++", 1, params);
// compilenode returning opresult3226
  if (strlit3227 == NULL) {
    strlit3227 = alloc_String(".already");
  }
// compilenode returning strlit3227
  params[0] = strlit3227;
  Object opresult3229 = callmethod(opresult3226, "++", 1, params);
// compilenode returning opresult3229
// Begin line 895
  setline(895);
// compilenode returning self
  params[0] = opresult3229;
  Object call3230 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3230
  if (strlit3231 == NULL) {
    strlit3231 = alloc_String("  %alreadymod");
  }
// compilenode returning strlit3231
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3233 = callmethod(strlit3231, "++", 1, params);
// compilenode returning opresult3233
  if (strlit3234 == NULL) {
    strlit3234 = alloc_String(" = load %object* ");
  }
// compilenode returning strlit3234
  params[0] = strlit3234;
  Object opresult3236 = callmethod(opresult3233, "++", 1, params);
// compilenode returning opresult3236
// compilenode returning *var_modg
  params[0] = *var_modg;
  Object opresult3238 = callmethod(opresult3236, "++", 1, params);
// compilenode returning opresult3238
// Begin line 896
  setline(896);
// compilenode returning self
  params[0] = opresult3238;
  Object call3239 = callmethod(self, "out",
    1, params);
// compilenode returning call3239
  if (strlit3240 == NULL) {
    strlit3240 = alloc_String("  br label %""\x22""import.");
  }
// compilenode returning strlit3240
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3242 = callmethod(strlit3240, "++", 1, params);
// compilenode returning opresult3242
  if (strlit3243 == NULL) {
    strlit3243 = alloc_String(".end""\x22""");
  }
// compilenode returning strlit3243
  params[0] = strlit3243;
  Object opresult3245 = callmethod(opresult3242, "++", 1, params);
// compilenode returning opresult3245
// Begin line 897
  setline(897);
// compilenode returning self
  params[0] = opresult3245;
  Object call3246 = callmethod(self, "out",
    1, params);
// compilenode returning call3246
  if (strlit3247 == NULL) {
    strlit3247 = alloc_String("import.");
  }
// compilenode returning strlit3247
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3249 = callmethod(strlit3247, "++", 1, params);
// compilenode returning opresult3249
  if (strlit3250 == NULL) {
    strlit3250 = alloc_String(".define");
  }
// compilenode returning strlit3250
  params[0] = strlit3250;
  Object opresult3252 = callmethod(opresult3249, "++", 1, params);
// compilenode returning opresult3252
// Begin line 898
  setline(898);
// compilenode returning self
  params[0] = opresult3252;
  Object call3253 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3253
// Begin line 908
  setline(908);
// Begin line 898
  setline(898);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call3255 = callmethod(*var_staticmodules, "contains",
    1, params);
// compilenode returning call3255
  Object if3254;
  if (istrue(call3255)) {
// Begin line 900
  setline(900);
// Begin line 899
  setline(899);
  if (strlit3256 == NULL) {
    strlit3256 = alloc_String("  %""\x22""tmp_mod_");
  }
// compilenode returning strlit3256
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3258 = callmethod(strlit3256, "++", 1, params);
// compilenode returning opresult3258
  if (strlit3259 == NULL) {
    strlit3259 = alloc_String("""\x22"" = call %object @module_");
  }
// compilenode returning strlit3259
  params[0] = strlit3259;
  Object opresult3261 = callmethod(opresult3258, "++", 1, params);
// compilenode returning opresult3261
// Begin line 900
  setline(900);
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3263 = callmethod(opresult3261, "++", 1, params);
// compilenode returning opresult3263
  if (strlit3264 == NULL) {
    strlit3264 = alloc_String("_init()");
  }
// compilenode returning strlit3264
  params[0] = strlit3264;
  Object opresult3266 = callmethod(opresult3263, "++", 1, params);
// compilenode returning opresult3266
// Begin line 901
  setline(901);
// compilenode returning self
  params[0] = opresult3266;
  Object call3267 = callmethod(self, "out",
    1, params);
// compilenode returning call3267
    if3254 = call3267;
  } else {
  Object *var_mn = alloc_var();
  *var_mn = undefined;
  Object *var_l = alloc_var();
  *var_l = undefined;
// Begin line 903
  setline(903);
// Begin line 902
  setline(902);
  if (strlit3268 == NULL) {
    strlit3268 = alloc_String("@""\x22"".str.module.");
  }
// compilenode returning strlit3268
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3270 = callmethod(strlit3268, "++", 1, params);
// compilenode returning opresult3270
  if (strlit3271 == NULL) {
    strlit3271 = alloc_String("""\x22""");
  }
// compilenode returning strlit3271
  params[0] = strlit3271;
  Object opresult3273 = callmethod(opresult3270, "++", 1, params);
// compilenode returning opresult3273
  var_mn = alloc_var();
  *var_mn = opresult3273;
  if (opresult3273 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 903
  setline(903);
// Begin line 1429
  setline(1429);
// Begin line 903
  setline(903);
  if (strlit3274 == NULL) {
    strlit3274 = alloc_String("utf-8");
  }
// compilenode returning strlit3274
// compilenode returning *var_nm
  params[0] = strlit3274;
  Object call3275 = callmethod(*var_nm, "encode",
    1, params);
// compilenode returning call3275
  Object call3276 = callmethod(call3275, "size",
    0, params);
// compilenode returning call3276
// compilenode returning call3276
  Object num3277 = alloc_Float64(1.0);
// compilenode returning num3277
  params[0] = num3277;
  Object sum3279 = callmethod(call3276, "+", 1, params);
// compilenode returning sum3279
  var_l = alloc_var();
  *var_l = sum3279;
  if (sum3279 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 905
  setline(905);
// Begin line 906
  setline(906);
// Begin line 904
  setline(904);
// compilenode returning *var_mn
  if (strlit3280 == NULL) {
    strlit3280 = alloc_String(" = private unnamed_addr constant [");
  }
// compilenode returning strlit3280
  params[0] = strlit3280;
  Object opresult3282 = callmethod(*var_mn, "++", 1, params);
// compilenode returning opresult3282
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3284 = callmethod(opresult3282, "++", 1, params);
// compilenode returning opresult3284
  if (strlit3285 == NULL) {
    strlit3285 = alloc_String(" x i8] ");
  }
// compilenode returning strlit3285
  params[0] = strlit3285;
  Object opresult3287 = callmethod(opresult3284, "++", 1, params);
// compilenode returning opresult3287
// Begin line 905
  setline(905);
  if (strlit3288 == NULL) {
    strlit3288 = alloc_String(" c""\x22""");
  }
// compilenode returning strlit3288
  params[0] = strlit3288;
  Object opresult3290 = callmethod(opresult3287, "++", 1, params);
// compilenode returning opresult3290
// Begin line 1429
  setline(1429);
// Begin line 905
  setline(905);
// compilenode returning *var_nm
  Object call3291 = callmethod(*var_nm, "_escape",
    0, params);
// compilenode returning call3291
// compilenode returning call3291
  params[0] = call3291;
  Object opresult3293 = callmethod(opresult3290, "++", 1, params);
// compilenode returning opresult3293
  if (strlit3294 == NULL) {
    strlit3294 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit3294
  params[0] = strlit3294;
  Object opresult3296 = callmethod(opresult3293, "++", 1, params);
// compilenode returning opresult3296
  *var_con = opresult3296;
  if (opresult3296 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 906
  setline(906);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3298 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3298
// Begin line 908
  setline(908);
// Begin line 907
  setline(907);
  if (strlit3299 == NULL) {
    strlit3299 = alloc_String("  %""\x22""tmp_mod_");
  }
// compilenode returning strlit3299
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3301 = callmethod(strlit3299, "++", 1, params);
// compilenode returning opresult3301
  if (strlit3302 == NULL) {
    strlit3302 = alloc_String("""\x22"" = call %object @dlmodule(i8 *");
  }
// compilenode returning strlit3302
  params[0] = strlit3302;
  Object opresult3304 = callmethod(opresult3301, "++", 1, params);
// compilenode returning opresult3304
// Begin line 908
  setline(908);
  if (strlit3305 == NULL) {
    strlit3305 = alloc_String(" getelementptr([");
  }
// compilenode returning strlit3305
  params[0] = strlit3305;
  Object opresult3307 = callmethod(opresult3304, "++", 1, params);
// compilenode returning opresult3307
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3309 = callmethod(opresult3307, "++", 1, params);
// compilenode returning opresult3309
  if (strlit3310 == NULL) {
    strlit3310 = alloc_String(" x i8]* ");
  }
// compilenode returning strlit3310
  params[0] = strlit3310;
  Object opresult3312 = callmethod(opresult3309, "++", 1, params);
// compilenode returning opresult3312
// compilenode returning *var_mn
  params[0] = *var_mn;
  Object opresult3314 = callmethod(opresult3312, "++", 1, params);
// compilenode returning opresult3314
  if (strlit3315 == NULL) {
    strlit3315 = alloc_String(",i32 0,i32 0))");
  }
// compilenode returning strlit3315
  params[0] = strlit3315;
  Object opresult3317 = callmethod(opresult3314, "++", 1, params);
// compilenode returning opresult3317
// Begin line 909
  setline(909);
// compilenode returning self
  params[0] = opresult3317;
  Object call3318 = callmethod(self, "out",
    1, params);
// compilenode returning call3318
    if3254 = call3318;
  }
// compilenode returning if3254
// Begin line 911
  setline(911);
// Begin line 910
  setline(910);
  if (strlit3319 == NULL) {
    strlit3319 = alloc_String("  store %object %""\x22""tmp_mod_");
  }
// compilenode returning strlit3319
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3321 = callmethod(strlit3319, "++", 1, params);
// compilenode returning opresult3321
// Begin line 911
  setline(911);
  if (strlit3322 == NULL) {
    strlit3322 = alloc_String("""\x22"", %object* @""\x22"".module.");
  }
// compilenode returning strlit3322
  params[0] = strlit3322;
  Object opresult3324 = callmethod(opresult3321, "++", 1, params);
// compilenode returning opresult3324
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3326 = callmethod(opresult3324, "++", 1, params);
// compilenode returning opresult3326
  if (strlit3327 == NULL) {
    strlit3327 = alloc_String("""\x22""");
  }
// compilenode returning strlit3327
  params[0] = strlit3327;
  Object opresult3329 = callmethod(opresult3326, "++", 1, params);
// compilenode returning opresult3329
// Begin line 912
  setline(912);
// compilenode returning self
  params[0] = opresult3329;
  Object call3330 = callmethod(self, "out",
    1, params);
// compilenode returning call3330
// Begin line 913
  setline(913);
// Begin line 912
  setline(912);
  if (strlit3331 == NULL) {
    strlit3331 = alloc_String("  store %object %""\x22""tmp_mod_");
  }
// compilenode returning strlit3331
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3333 = callmethod(strlit3331, "++", 1, params);
// compilenode returning opresult3333
  if (strlit3334 == NULL) {
    strlit3334 = alloc_String("""\x22"", %object* @""\x22"".module.");
  }
// compilenode returning strlit3334
  params[0] = strlit3334;
  Object opresult3336 = callmethod(opresult3333, "++", 1, params);
// compilenode returning opresult3336
// Begin line 913
  setline(913);
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3338 = callmethod(opresult3336, "++", 1, params);
// compilenode returning opresult3338
  if (strlit3339 == NULL) {
    strlit3339 = alloc_String("""\x22""");
  }
// compilenode returning strlit3339
  params[0] = strlit3339;
  Object opresult3341 = callmethod(opresult3338, "++", 1, params);
// compilenode returning opresult3341
// Begin line 914
  setline(914);
// compilenode returning self
  params[0] = opresult3341;
  Object call3342 = callmethod(self, "out",
    1, params);
// compilenode returning call3342
  if (strlit3343 == NULL) {
    strlit3343 = alloc_String("  br label %""\x22""import.");
  }
// compilenode returning strlit3343
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3345 = callmethod(strlit3343, "++", 1, params);
// compilenode returning opresult3345
  if (strlit3346 == NULL) {
    strlit3346 = alloc_String(".end""\x22""");
  }
// compilenode returning strlit3346
  params[0] = strlit3346;
  Object opresult3348 = callmethod(opresult3345, "++", 1, params);
// compilenode returning opresult3348
// Begin line 915
  setline(915);
// compilenode returning self
  params[0] = opresult3348;
  Object call3349 = callmethod(self, "out",
    1, params);
// compilenode returning call3349
  if (strlit3350 == NULL) {
    strlit3350 = alloc_String("import.");
  }
// compilenode returning strlit3350
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3352 = callmethod(strlit3350, "++", 1, params);
// compilenode returning opresult3352
  if (strlit3353 == NULL) {
    strlit3353 = alloc_String(".end");
  }
// compilenode returning strlit3353
  params[0] = strlit3353;
  Object opresult3355 = callmethod(opresult3352, "++", 1, params);
// compilenode returning opresult3355
// Begin line 916
  setline(916);
// compilenode returning self
  params[0] = opresult3355;
  Object call3356 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3356
// Begin line 918
  setline(918);
// Begin line 916
  setline(916);
  if (strlit3357 == NULL) {
    strlit3357 = alloc_String("  %""\x22""tmp_modv_");
  }
// compilenode returning strlit3357
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3359 = callmethod(strlit3357, "++", 1, params);
// compilenode returning opresult3359
  if (strlit3360 == NULL) {
    strlit3360 = alloc_String("""\x22"" = phi %object [%alreadymod");
  }
// compilenode returning strlit3360
  params[0] = strlit3360;
  Object opresult3362 = callmethod(opresult3359, "++", 1, params);
// compilenode returning opresult3362
// Begin line 917
  setline(917);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3364 = callmethod(opresult3362, "++", 1, params);
// compilenode returning opresult3364
  if (strlit3365 == NULL) {
    strlit3365 = alloc_String(", %""\x22""import.");
  }
// compilenode returning strlit3365
  params[0] = strlit3365;
  Object opresult3367 = callmethod(opresult3364, "++", 1, params);
// compilenode returning opresult3367
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3369 = callmethod(opresult3367, "++", 1, params);
// compilenode returning opresult3369
  if (strlit3370 == NULL) {
    strlit3370 = alloc_String(".already""\x22""], ");
  }
// compilenode returning strlit3370
  params[0] = strlit3370;
  Object opresult3372 = callmethod(opresult3369, "++", 1, params);
// compilenode returning opresult3372
// Begin line 918
  setline(918);
  if (strlit3373 == NULL) {
    strlit3373 = alloc_String("[%""\x22""tmp_mod_");
  }
// compilenode returning strlit3373
  params[0] = strlit3373;
  Object opresult3375 = callmethod(opresult3372, "++", 1, params);
// compilenode returning opresult3375
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3377 = callmethod(opresult3375, "++", 1, params);
// compilenode returning opresult3377
  if (strlit3378 == NULL) {
    strlit3378 = alloc_String("""\x22"", %""\x22""import.");
  }
// compilenode returning strlit3378
  params[0] = strlit3378;
  Object opresult3380 = callmethod(opresult3377, "++", 1, params);
// compilenode returning opresult3380
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3382 = callmethod(opresult3380, "++", 1, params);
// compilenode returning opresult3382
  if (strlit3383 == NULL) {
    strlit3383 = alloc_String(".define""\x22""]");
  }
// compilenode returning strlit3383
  params[0] = strlit3383;
  Object opresult3385 = callmethod(opresult3382, "++", 1, params);
// compilenode returning opresult3385
// Begin line 919
  setline(919);
// compilenode returning self
  params[0] = opresult3385;
  Object call3386 = callmethod(self, "out",
    1, params);
// compilenode returning call3386
  if (strlit3387 == NULL) {
    strlit3387 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit3387
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3389 = callmethod(strlit3387, "++", 1, params);
// compilenode returning opresult3389
  if (strlit3390 == NULL) {
    strlit3390 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit3390
  params[0] = strlit3390;
  Object opresult3392 = callmethod(opresult3389, "++", 1, params);
// compilenode returning opresult3392
// Begin line 920
  setline(920);
// compilenode returning self
  params[0] = opresult3392;
  Object call3393 = callmethod(self, "out",
    1, params);
// compilenode returning call3393
// Begin line 921
  setline(921);
// Begin line 920
  setline(920);
  if (strlit3394 == NULL) {
    strlit3394 = alloc_String("  store %object %""\x22""tmp_modv_");
  }
// compilenode returning strlit3394
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3396 = callmethod(strlit3394, "++", 1, params);
// compilenode returning opresult3396
// Begin line 921
  setline(921);
  if (strlit3397 == NULL) {
    strlit3397 = alloc_String("""\x22"", %object* %""\x22""var_");
  }
// compilenode returning strlit3397
  params[0] = strlit3397;
  Object opresult3399 = callmethod(opresult3396, "++", 1, params);
// compilenode returning opresult3399
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3401 = callmethod(opresult3399, "++", 1, params);
// compilenode returning opresult3401
  if (strlit3402 == NULL) {
    strlit3402 = alloc_String("""\x22""");
  }
// compilenode returning strlit3402
  params[0] = strlit3402;
  Object opresult3404 = callmethod(opresult3401, "++", 1, params);
// compilenode returning opresult3404
// Begin line 922
  setline(922);
// compilenode returning self
  params[0] = opresult3404;
  Object call3405 = callmethod(self, "out",
    1, params);
// compilenode returning call3405
// Begin line 923
  setline(923);
// Begin line 922
  setline(922);
  if (strlit3406 == NULL) {
    strlit3406 = alloc_String("@""\x22"".module.");
  }
// compilenode returning strlit3406
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3408 = callmethod(strlit3406, "++", 1, params);
// compilenode returning opresult3408
  if (strlit3409 == NULL) {
    strlit3409 = alloc_String("""\x22"" = weak global %object null");
  }
// compilenode returning strlit3409
  params[0] = strlit3409;
  Object opresult3411 = callmethod(opresult3408, "++", 1, params);
// compilenode returning opresult3411
  *var_con = opresult3411;
  if (opresult3411 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 923
  setline(923);
// compilenode returning *var_nm
// compilenode returning *var_modules
  params[0] = *var_nm;
  Object call3413 = callmethod(*var_modules, "push",
    1, params);
// compilenode returning call3413
// Begin line 924
  setline(924);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3414 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3414
// Begin line 926
  setline(926);
// Begin line 925
  setline(925);
  if (strlit3415 == NULL) {
    strlit3415 = alloc_String("declare %object @""\x22""module_");
  }
// compilenode returning strlit3415
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult3417 = callmethod(strlit3415, "++", 1, params);
// compilenode returning opresult3417
  if (strlit3418 == NULL) {
    strlit3418 = alloc_String("_init""\x22""()");
  }
// compilenode returning strlit3418
  params[0] = strlit3418;
  Object opresult3420 = callmethod(opresult3417, "++", 1, params);
// compilenode returning opresult3420
  *var_con = opresult3420;
  if (opresult3420 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 926
  setline(926);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3422 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3422
// Begin line 928
  setline(928);
// Begin line 927
  setline(927);
// compilenode returning *var_auto_count
  Object num3423 = alloc_Float64(1.0);
// compilenode returning num3423
  params[0] = num3423;
  Object sum3425 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum3425
  *var_auto_count = sum3425;
  if (sum3425 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 929
  setline(929);
// Begin line 1429
  setline(1429);
// Begin line 928
  setline(928);
  if (strlit3427 == NULL) {
    strlit3427 = alloc_String("%undefined");
  }
// compilenode returning strlit3427
// compilenode returning *var_o
  params[0] = strlit3427;
  Object call3428 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3428
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilereturn3429(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[26];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_inBlock = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_reg = alloc_var();
  *var_reg = undefined;
// Begin line 931
  setline(931);
// Begin line 1429
  setline(1429);
// Begin line 931
  setline(931);
// compilenode returning *var_o
  Object call3430 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3430
// compilenode returning call3430
// Begin line 932
  setline(932);
// compilenode returning self
  params[0] = call3430;
  Object call3431 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call3431
  var_reg = alloc_var();
  *var_reg = call3431;
  if (call3431 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 936
  setline(936);
// Begin line 932
  setline(932);
// compilenode returning *var_inBlock
  Object if3432;
  if (istrue(*var_inBlock)) {
// Begin line 933
  setline(933);
  if (strlit3433 == NULL) {
    strlit3433 = alloc_String("  call void @block_return(%object %realself, %object ");
  }
// compilenode returning strlit3433
// compilenode returning *var_reg
  params[0] = *var_reg;
  Object opresult3435 = callmethod(strlit3433, "++", 1, params);
// compilenode returning opresult3435
  if (strlit3436 == NULL) {
    strlit3436 = alloc_String(")");
  }
// compilenode returning strlit3436
  params[0] = strlit3436;
  Object opresult3438 = callmethod(opresult3435, "++", 1, params);
// compilenode returning opresult3438
// Begin line 934
  setline(934);
// compilenode returning self
  params[0] = opresult3438;
  Object call3439 = callmethod(self, "out",
    1, params);
// compilenode returning call3439
    if3432 = call3439;
  } else {
// Begin line 935
  setline(935);
  if (strlit3440 == NULL) {
    strlit3440 = alloc_String("  ret %object ");
  }
// compilenode returning strlit3440
// compilenode returning *var_reg
  params[0] = *var_reg;
  Object opresult3442 = callmethod(strlit3440, "++", 1, params);
// compilenode returning opresult3442
// Begin line 936
  setline(936);
// compilenode returning self
  params[0] = opresult3442;
  Object call3443 = callmethod(self, "out",
    1, params);
// compilenode returning call3443
  if (strlit3444 == NULL) {
    strlit3444 = alloc_String("postret");
  }
// compilenode returning strlit3444
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3446 = callmethod(strlit3444, "++", 1, params);
// compilenode returning opresult3446
// Begin line 937
  setline(937);
// compilenode returning self
  params[0] = opresult3446;
  Object call3447 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3447
    if3432 = call3447;
  }
// compilenode returning if3432
// Begin line 939
  setline(939);
// Begin line 1429
  setline(1429);
// Begin line 938
  setline(938);
  if (strlit3448 == NULL) {
    strlit3448 = alloc_String("%undefined");
  }
// compilenode returning strlit3448
// compilenode returning *var_o
  params[0] = strlit3448;
  Object call3449 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3449
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply3457(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_havedot = closure[0];
  Object self = *closure[1];
// Begin line 946
  setline(946);
// Begin line 947
  setline(947);
// Begin line 944
  setline(944);
// compilenode returning *var_c
  if (strlit3459 == NULL) {
    strlit3459 = alloc_String(".");
  }
// compilenode returning strlit3459
  params[0] = strlit3459;
  Object opresult3461 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult3461
  Object if3458;
  if (istrue(opresult3461)) {
// Begin line 946
  setline(946);
// Begin line 945
  setline(945);
  Object bool3462 = alloc_Boolean(1);
// compilenode returning bool3462
  *var_havedot = bool3462;
  if (bool3462 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3458 = nothing;
  } else {
  }
// compilenode returning if3458
  return if3458;
}
Object meth_genllvm29_compilenum3450(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[27];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object *var_auto_count = closure[0];
  Object *var_cnum = alloc_var();
  *var_cnum = undefined;
  Object *var_havedot = alloc_var();
  *var_havedot = undefined;
// Begin line 942
  setline(942);
// Begin line 1429
  setline(1429);
// Begin line 941
  setline(941);
// compilenode returning *var_o
  Object call3451 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3451
// compilenode returning call3451
  var_cnum = alloc_var();
  *var_cnum = call3451;
  if (call3451 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 943
  setline(943);
// Begin line 942
  setline(942);
  Object bool3452 = alloc_Boolean(0);
// compilenode returning bool3452
  var_havedot = alloc_var();
  *var_havedot = bool3452;
  if (bool3452 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 946
  setline(946);
// Begin line 943
  setline(943);
// compilenode returning *var_cnum
// Begin line 946
  setline(946);
// Begin line 1429
  setline(1429);
  Object obj3455 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3455, self, 0);
  addmethod2(obj3455, "outer", &reader_genllvm29_outer_3456);
  adddatum2(obj3455, self, 0);
  block_savedest(obj3455);
  Object **closure3457 = createclosure(2);
  addtoclosure(closure3457, var_havedot);
  Object *selfpp3464 = alloc_var();
  *selfpp3464 = self;
  addtoclosure(closure3457, selfpp3464);
  struct UserObject *uo3457 = (struct UserObject*)obj3455;
  uo3457->data[1] = (Object)closure3457;
  addmethod2(obj3455, "apply", &meth_genllvm29_apply3457);
  set_type(obj3455, 0);
// compilenode returning obj3455
  setclassname(obj3455, "Block<genllvm29:3454>");
// compilenode returning obj3455
  params[0] = *var_cnum;
  Object iter3453 = callmethod(*var_cnum, "iter", 1, params);
  while(1) {
    Object cond3453 = callmethod(iter3453, "havemore", 0, NULL);
    if (!istrue(cond3453)) break;
    params[0] = callmethod(iter3453, "next", 0, NULL);
    callmethod(obj3455, "apply", 1, params);
  }
// compilenode returning *var_cnum
// Begin line 950
  setline(950);
// Begin line 951
  setline(951);
// Begin line 1429
  setline(1429);
// Begin line 948
  setline(948);
// compilenode returning *var_havedot
  Object call3466 = callmethod(*var_havedot, "not",
    0, params);
// compilenode returning call3466
// compilenode returning call3466
  Object if3465;
  if (istrue(call3466)) {
// Begin line 950
  setline(950);
// Begin line 949
  setline(949);
// compilenode returning *var_cnum
  if (strlit3467 == NULL) {
    strlit3467 = alloc_String(".0");
  }
// compilenode returning strlit3467
  params[0] = strlit3467;
  Object opresult3469 = callmethod(*var_cnum, "++", 1, params);
// compilenode returning opresult3469
  *var_cnum = opresult3469;
  if (opresult3469 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3465 = nothing;
  } else {
  }
// compilenode returning if3465
// Begin line 952
  setline(952);
// Begin line 951
  setline(951);
  if (strlit3471 == NULL) {
    strlit3471 = alloc_String("  %num");
  }
// compilenode returning strlit3471
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3473 = callmethod(strlit3471, "++", 1, params);
// compilenode returning opresult3473
  if (strlit3474 == NULL) {
    strlit3474 = alloc_String(" = call %object @alloc_Float64(double ");
  }
// compilenode returning strlit3474
  params[0] = strlit3474;
  Object opresult3476 = callmethod(opresult3473, "++", 1, params);
// compilenode returning opresult3476
// Begin line 952
  setline(952);
// compilenode returning *var_cnum
  params[0] = *var_cnum;
  Object opresult3478 = callmethod(opresult3476, "++", 1, params);
// compilenode returning opresult3478
  if (strlit3479 == NULL) {
    strlit3479 = alloc_String(")");
  }
// compilenode returning strlit3479
  params[0] = strlit3479;
  Object opresult3481 = callmethod(opresult3478, "++", 1, params);
// compilenode returning opresult3481
// Begin line 953
  setline(953);
// compilenode returning self
  params[0] = opresult3481;
  Object call3482 = callmethod(self, "out",
    1, params);
// compilenode returning call3482
// Begin line 954
  setline(954);
// Begin line 1429
  setline(1429);
// Begin line 954
  setline(954);
// Begin line 953
  setline(953);
  if (strlit3483 == NULL) {
    strlit3483 = alloc_String("%num");
  }
// compilenode returning strlit3483
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3485 = callmethod(strlit3483, "++", 1, params);
// compilenode returning opresult3485
// compilenode returning *var_o
  params[0] = opresult3485;
  Object call3486 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3486
// compilenode returning nothing
// Begin line 955
  setline(955);
// Begin line 954
  setline(954);
// compilenode returning *var_auto_count
  Object num3487 = alloc_Float64(1.0);
// compilenode returning num3487
  params[0] = num3487;
  Object sum3489 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum3489
  *var_auto_count = sum3489;
  if (sum3489 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_apply3909(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_prm = alloc_var();
  *var_prm = args[0];
  Object params[1];
  Object *var_args = closure[0];
  Object self = *closure[1];
  Object *var_r = alloc_var();
  *var_r = undefined;
// Begin line 1072
  setline(1072);
// compilenode returning *var_prm
// Begin line 1073
  setline(1073);
// compilenode returning self
  params[0] = *var_prm;
  Object call3910 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call3910
  var_r = alloc_var();
  *var_r = call3910;
  if (call3910 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_r
// compilenode returning *var_args
  params[0] = *var_r;
  Object call3911 = callmethod(*var_args, "push",
    1, params);
// compilenode returning call3911
  return call3911;
}
Object meth_genllvm29_apply3918(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_arg = alloc_var();
  *var_arg = args[0];
  Object params[1];
  Object *var_parami = closure[0];
  Object self = *closure[1];
// Begin line 1077
  setline(1077);
  if (strlit3919 == NULL) {
    strlit3919 = alloc_String("  store %object ");
  }
// compilenode returning strlit3919
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult3921 = callmethod(strlit3919, "++", 1, params);
// compilenode returning opresult3921
  if (strlit3922 == NULL) {
    strlit3922 = alloc_String(", %object* %params_");
  }
// compilenode returning strlit3922
  params[0] = strlit3922;
  Object opresult3924 = callmethod(opresult3921, "++", 1, params);
// compilenode returning opresult3924
// compilenode returning *var_parami
  params[0] = *var_parami;
  Object opresult3926 = callmethod(opresult3924, "++", 1, params);
// compilenode returning opresult3926
  if (strlit3927 == NULL) {
    strlit3927 = alloc_String("");
  }
// compilenode returning strlit3927
  params[0] = strlit3927;
  Object opresult3929 = callmethod(opresult3926, "++", 1, params);
// compilenode returning opresult3929
// Begin line 1078
  setline(1078);
// compilenode returning self
  params[0] = opresult3929;
  Object call3930 = callmethod(self, "out",
    1, params);
// compilenode returning call3930
// Begin line 1079
  setline(1079);
// Begin line 1078
  setline(1078);
// compilenode returning *var_parami
  Object num3931 = alloc_Float64(1.0);
// compilenode returning num3931
  params[0] = num3931;
  Object sum3933 = callmethod(*var_parami, "+", 1, params);
// compilenode returning sum3933
  *var_parami = sum3933;
  if (sum3933 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compilenode3491(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[28];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[3];
  Object *var_linenum = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_constants = closure[2];
  Object *var_topLevelMethodPos = closure[3];
  Object *var_tmp = closure[4];
  Object *var_l = alloc_var();
  *var_l = undefined;
// Begin line 960
  setline(960);
// Begin line 962
  setline(962);
// Begin line 957
  setline(957);
// compilenode returning *var_linenum
// Begin line 962
  setline(962);
// Begin line 1429
  setline(1429);
// Begin line 957
  setline(957);
// compilenode returning *var_o
  Object call3493 = callmethod(*var_o, "line",
    0, params);
// compilenode returning call3493
// compilenode returning call3493
  params[0] = call3493;
  Object opresult3495 = callmethod(*var_linenum, "/=", 1, params);
// compilenode returning opresult3495
  Object if3492;
  if (istrue(opresult3495)) {
// Begin line 959
  setline(959);
// Begin line 1429
  setline(1429);
// Begin line 958
  setline(958);
// compilenode returning *var_o
  Object call3496 = callmethod(*var_o, "line",
    0, params);
// compilenode returning call3496
// compilenode returning call3496
  *var_linenum = call3496;
  if (call3496 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 959
  setline(959);
  if (strlit3498 == NULL) {
    strlit3498 = alloc_String("; Begin line ");
  }
// compilenode returning strlit3498
// compilenode returning *var_linenum
  params[0] = *var_linenum;
  Object opresult3500 = callmethod(strlit3498, "++", 1, params);
// compilenode returning opresult3500
// Begin line 960
  setline(960);
// compilenode returning self
  params[0] = opresult3500;
  Object call3501 = callmethod(self, "out",
    1, params);
// compilenode returning call3501
  if (strlit3502 == NULL) {
    strlit3502 = alloc_String("  call void @setline(i32 ");
  }
// compilenode returning strlit3502
// compilenode returning *var_linenum
  params[0] = *var_linenum;
  Object opresult3504 = callmethod(strlit3502, "++", 1, params);
// compilenode returning opresult3504
  if (strlit3505 == NULL) {
    strlit3505 = alloc_String(")");
  }
// compilenode returning strlit3505
  params[0] = strlit3505;
  Object opresult3507 = callmethod(opresult3504, "++", 1, params);
// compilenode returning opresult3507
// Begin line 961
  setline(961);
// compilenode returning self
  params[0] = opresult3507;
  Object call3508 = callmethod(self, "out",
    1, params);
// compilenode returning call3508
    if3492 = call3508;
  } else {
  }
// compilenode returning if3492
// Begin line 963
  setline(963);
// Begin line 965
  setline(965);
// Begin line 1429
  setline(1429);
// Begin line 962
  setline(962);
// compilenode returning *var_o
  Object call3510 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3510
// compilenode returning call3510
  if (strlit3511 == NULL) {
    strlit3511 = alloc_String("num");
  }
// compilenode returning strlit3511
  params[0] = strlit3511;
  Object opresult3513 = callmethod(call3510, "==", 1, params);
// compilenode returning opresult3513
  Object if3509;
  if (istrue(opresult3513)) {
// Begin line 963
  setline(963);
// compilenode returning *var_o
// Begin line 964
  setline(964);
// compilenode returning self
  params[0] = *var_o;
  Object call3514 = callmethod(self, "compilenum",
    1, params);
// compilenode returning call3514
    if3509 = call3514;
  } else {
  }
// compilenode returning if3509
// Begin line 966
  setline(966);
// Begin line 965
  setline(965);
  if (strlit3515 == NULL) {
    strlit3515 = alloc_String("");
  }
// compilenode returning strlit3515
  var_l = alloc_var();
  *var_l = strlit3515;
  if (strlit3515 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1002
  setline(1002);
// Begin line 1003
  setline(1003);
// Begin line 1429
  setline(1429);
// Begin line 966
  setline(966);
// compilenode returning *var_o
  Object call3517 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3517
// compilenode returning call3517
  if (strlit3518 == NULL) {
    strlit3518 = alloc_String("string");
  }
// compilenode returning strlit3518
  params[0] = strlit3518;
  Object opresult3520 = callmethod(call3517, "==", 1, params);
// compilenode returning opresult3520
  Object if3516;
  if (istrue(opresult3520)) {
  Object *var_con = alloc_var();
  *var_con = undefined;
// Begin line 967
  setline(967);
// Begin line 1429
  setline(1429);
// Begin line 967
  setline(967);
// compilenode returning *var_o
  Object call3521 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3521
// compilenode returning call3521
  Object call3522 = gracelib_length(call3521);
// compilenode returning call3522
  *var_l = call3522;
  if (call3522 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 969
  setline(969);
// Begin line 968
  setline(968);
// compilenode returning *var_l
  Object num3524 = alloc_Float64(1.0);
// compilenode returning num3524
  params[0] = num3524;
  Object sum3526 = callmethod(*var_l, "+", 1, params);
// compilenode returning sum3526
  *var_l = sum3526;
  if (sum3526 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 969
  setline(969);
// Begin line 1429
  setline(1429);
// Begin line 969
  setline(969);
// Begin line 1429
  setline(1429);
// Begin line 969
  setline(969);
// Begin line 1429
  setline(1429);
// Begin line 969
  setline(969);
// compilenode returning *var_o
  Object call3528 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3528
// compilenode returning call3528
  Object call3529 = callmethod(call3528, "_escape",
    0, params);
// compilenode returning call3529
// compilenode returning call3529
// compilenode returning *var_o
  params[0] = call3529;
  Object call3530 = callmethod(*var_o, "value:=",
    1, params);
// compilenode returning call3530
// compilenode returning nothing
// Begin line 971
  setline(971);
// Begin line 970
  setline(970);
  if (strlit3531 == NULL) {
    strlit3531 = alloc_String("  %tmp");
  }
// compilenode returning strlit3531
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3533 = callmethod(strlit3531, "++", 1, params);
// compilenode returning opresult3533
  if (strlit3534 == NULL) {
    strlit3534 = alloc_String(" = load %object* @.strlit");
  }
// compilenode returning strlit3534
  params[0] = strlit3534;
  Object opresult3536 = callmethod(opresult3533, "++", 1, params);
// compilenode returning opresult3536
// Begin line 971
  setline(971);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3538 = callmethod(opresult3536, "++", 1, params);
// compilenode returning opresult3538
// Begin line 972
  setline(972);
// compilenode returning self
  params[0] = opresult3538;
  Object call3539 = callmethod(self, "out",
    1, params);
// compilenode returning call3539
// Begin line 973
  setline(973);
// Begin line 972
  setline(972);
  if (strlit3540 == NULL) {
    strlit3540 = alloc_String("  %cmp");
  }
// compilenode returning strlit3540
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3542 = callmethod(strlit3540, "++", 1, params);
// compilenode returning opresult3542
  if (strlit3543 == NULL) {
    strlit3543 = alloc_String(" = icmp ne %object %tmp");
  }
// compilenode returning strlit3543
  params[0] = strlit3543;
  Object opresult3545 = callmethod(opresult3542, "++", 1, params);
// compilenode returning opresult3545
// Begin line 973
  setline(973);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3547 = callmethod(opresult3545, "++", 1, params);
// compilenode returning opresult3547
  if (strlit3548 == NULL) {
    strlit3548 = alloc_String(", null");
  }
// compilenode returning strlit3548
  params[0] = strlit3548;
  Object opresult3550 = callmethod(opresult3547, "++", 1, params);
// compilenode returning opresult3550
// Begin line 974
  setline(974);
// compilenode returning self
  params[0] = opresult3550;
  Object call3551 = callmethod(self, "out",
    1, params);
// compilenode returning call3551
// Begin line 976
  setline(976);
// Begin line 974
  setline(974);
  if (strlit3552 == NULL) {
    strlit3552 = alloc_String("  br i1 %cmp");
  }
// compilenode returning strlit3552
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3554 = callmethod(strlit3552, "++", 1, params);
// compilenode returning opresult3554
  if (strlit3555 == NULL) {
    strlit3555 = alloc_String(", label %strlit");
  }
// compilenode returning strlit3555
  params[0] = strlit3555;
  Object opresult3557 = callmethod(opresult3554, "++", 1, params);
// compilenode returning opresult3557
// Begin line 975
  setline(975);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3559 = callmethod(opresult3557, "++", 1, params);
// compilenode returning opresult3559
  if (strlit3560 == NULL) {
    strlit3560 = alloc_String(".already, label %strlit");
  }
// compilenode returning strlit3560
  params[0] = strlit3560;
  Object opresult3562 = callmethod(opresult3559, "++", 1, params);
// compilenode returning opresult3562
// Begin line 976
  setline(976);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3564 = callmethod(opresult3562, "++", 1, params);
// compilenode returning opresult3564
  if (strlit3565 == NULL) {
    strlit3565 = alloc_String(".define");
  }
// compilenode returning strlit3565
  params[0] = strlit3565;
  Object opresult3567 = callmethod(opresult3564, "++", 1, params);
// compilenode returning opresult3567
// Begin line 977
  setline(977);
// compilenode returning self
  params[0] = opresult3567;
  Object call3568 = callmethod(self, "out",
    1, params);
// compilenode returning call3568
  if (strlit3569 == NULL) {
    strlit3569 = alloc_String("strlit");
  }
// compilenode returning strlit3569
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3571 = callmethod(strlit3569, "++", 1, params);
// compilenode returning opresult3571
  if (strlit3572 == NULL) {
    strlit3572 = alloc_String(".already");
  }
// compilenode returning strlit3572
  params[0] = strlit3572;
  Object opresult3574 = callmethod(opresult3571, "++", 1, params);
// compilenode returning opresult3574
// Begin line 978
  setline(978);
// compilenode returning self
  params[0] = opresult3574;
  Object call3575 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3575
// Begin line 979
  setline(979);
// Begin line 978
  setline(978);
  if (strlit3576 == NULL) {
    strlit3576 = alloc_String("  %alreadystring");
  }
// compilenode returning strlit3576
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3578 = callmethod(strlit3576, "++", 1, params);
// compilenode returning opresult3578
  if (strlit3579 == NULL) {
    strlit3579 = alloc_String(" = load %object* @.strlit");
  }
// compilenode returning strlit3579
  params[0] = strlit3579;
  Object opresult3581 = callmethod(opresult3578, "++", 1, params);
// compilenode returning opresult3581
// Begin line 979
  setline(979);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3583 = callmethod(opresult3581, "++", 1, params);
// compilenode returning opresult3583
// Begin line 980
  setline(980);
// compilenode returning self
  params[0] = opresult3583;
  Object call3584 = callmethod(self, "out",
    1, params);
// compilenode returning call3584
  if (strlit3585 == NULL) {
    strlit3585 = alloc_String("  br label %strlit");
  }
// compilenode returning strlit3585
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3587 = callmethod(strlit3585, "++", 1, params);
// compilenode returning opresult3587
  if (strlit3588 == NULL) {
    strlit3588 = alloc_String(".end");
  }
// compilenode returning strlit3588
  params[0] = strlit3588;
  Object opresult3590 = callmethod(opresult3587, "++", 1, params);
// compilenode returning opresult3590
// Begin line 981
  setline(981);
// compilenode returning self
  params[0] = opresult3590;
  Object call3591 = callmethod(self, "out",
    1, params);
// compilenode returning call3591
  if (strlit3592 == NULL) {
    strlit3592 = alloc_String("strlit");
  }
// compilenode returning strlit3592
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3594 = callmethod(strlit3592, "++", 1, params);
// compilenode returning opresult3594
  if (strlit3595 == NULL) {
    strlit3595 = alloc_String(".define");
  }
// compilenode returning strlit3595
  params[0] = strlit3595;
  Object opresult3597 = callmethod(opresult3594, "++", 1, params);
// compilenode returning opresult3597
// Begin line 982
  setline(982);
// compilenode returning self
  params[0] = opresult3597;
  Object call3598 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3598
  if (strlit3599 == NULL) {
    strlit3599 = alloc_String("  %str");
  }
// compilenode returning strlit3599
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3601 = callmethod(strlit3599, "++", 1, params);
// compilenode returning opresult3601
  if (strlit3602 == NULL) {
    strlit3602 = alloc_String(" = getelementptr [");
  }
// compilenode returning strlit3602
  params[0] = strlit3602;
  Object opresult3604 = callmethod(opresult3601, "++", 1, params);
// compilenode returning opresult3604
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3606 = callmethod(opresult3604, "++", 1, params);
// compilenode returning opresult3606
  if (strlit3607 == NULL) {
    strlit3607 = alloc_String(" x i8]* @.str");
  }
// compilenode returning strlit3607
  params[0] = strlit3607;
  Object opresult3609 = callmethod(opresult3606, "++", 1, params);
// compilenode returning opresult3609
// Begin line 1429
  setline(1429);
// Begin line 982
  setline(982);
// compilenode returning *var_constants
  Object call3610 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call3610
// compilenode returning call3610
  params[0] = call3610;
  Object opresult3612 = callmethod(opresult3609, "++", 1, params);
// compilenode returning opresult3612
  if (strlit3613 == NULL) {
    strlit3613 = alloc_String(", i32 0, i32 0");
  }
// compilenode returning strlit3613
  params[0] = strlit3613;
  Object opresult3615 = callmethod(opresult3612, "++", 1, params);
// compilenode returning opresult3615
// Begin line 983
  setline(983);
// compilenode returning self
  params[0] = opresult3615;
  Object call3616 = callmethod(self, "out",
    1, params);
// compilenode returning call3616
// Begin line 985
  setline(985);
// Begin line 983
  setline(983);
  if (strlit3617 == NULL) {
    strlit3617 = alloc_String("  %defstring");
  }
// compilenode returning strlit3617
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3619 = callmethod(strlit3617, "++", 1, params);
// compilenode returning opresult3619
  if (strlit3620 == NULL) {
    strlit3620 = alloc_String(" = call %object ");
  }
// compilenode returning strlit3620
  params[0] = strlit3620;
  Object opresult3622 = callmethod(opresult3619, "++", 1, params);
// compilenode returning opresult3622
// Begin line 984
  setline(984);
  if (strlit3623 == NULL) {
    strlit3623 = alloc_String("@alloc_String(i8* ");
  }
// compilenode returning strlit3623
  params[0] = strlit3623;
  Object opresult3625 = callmethod(opresult3622, "++", 1, params);
// compilenode returning opresult3625
// Begin line 985
  setline(985);
  if (strlit3626 == NULL) {
    strlit3626 = alloc_String("%str");
  }
// compilenode returning strlit3626
  params[0] = strlit3626;
  Object opresult3628 = callmethod(opresult3625, "++", 1, params);
// compilenode returning opresult3628
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3630 = callmethod(opresult3628, "++", 1, params);
// compilenode returning opresult3630
  if (strlit3631 == NULL) {
    strlit3631 = alloc_String(")");
  }
// compilenode returning strlit3631
  params[0] = strlit3631;
  Object opresult3633 = callmethod(opresult3630, "++", 1, params);
// compilenode returning opresult3633
// Begin line 986
  setline(986);
// compilenode returning self
  params[0] = opresult3633;
  Object call3634 = callmethod(self, "out",
    1, params);
// compilenode returning call3634
// Begin line 987
  setline(987);
// Begin line 986
  setline(986);
  if (strlit3635 == NULL) {
    strlit3635 = alloc_String("  store %object %defstring");
  }
// compilenode returning strlit3635
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3637 = callmethod(strlit3635, "++", 1, params);
// compilenode returning opresult3637
  if (strlit3638 == NULL) {
    strlit3638 = alloc_String(", %object* ");
  }
// compilenode returning strlit3638
  params[0] = strlit3638;
  Object opresult3640 = callmethod(opresult3637, "++", 1, params);
// compilenode returning opresult3640
// Begin line 987
  setline(987);
  if (strlit3641 == NULL) {
    strlit3641 = alloc_String("@.strlit");
  }
// compilenode returning strlit3641
  params[0] = strlit3641;
  Object opresult3643 = callmethod(opresult3640, "++", 1, params);
// compilenode returning opresult3643
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3645 = callmethod(opresult3643, "++", 1, params);
// compilenode returning opresult3645
// Begin line 988
  setline(988);
// compilenode returning self
  params[0] = opresult3645;
  Object call3646 = callmethod(self, "out",
    1, params);
// compilenode returning call3646
  if (strlit3647 == NULL) {
    strlit3647 = alloc_String("br label %strlit");
  }
// compilenode returning strlit3647
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3649 = callmethod(strlit3647, "++", 1, params);
// compilenode returning opresult3649
  if (strlit3650 == NULL) {
    strlit3650 = alloc_String(".end");
  }
// compilenode returning strlit3650
  params[0] = strlit3650;
  Object opresult3652 = callmethod(opresult3649, "++", 1, params);
// compilenode returning opresult3652
// Begin line 989
  setline(989);
// compilenode returning self
  params[0] = opresult3652;
  Object call3653 = callmethod(self, "out",
    1, params);
// compilenode returning call3653
  if (strlit3654 == NULL) {
    strlit3654 = alloc_String("strlit");
  }
// compilenode returning strlit3654
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3656 = callmethod(strlit3654, "++", 1, params);
// compilenode returning opresult3656
  if (strlit3657 == NULL) {
    strlit3657 = alloc_String(".end");
  }
// compilenode returning strlit3657
  params[0] = strlit3657;
  Object opresult3659 = callmethod(opresult3656, "++", 1, params);
// compilenode returning opresult3659
// Begin line 990
  setline(990);
// compilenode returning self
  params[0] = opresult3659;
  Object call3660 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call3660
// Begin line 993
  setline(993);
// Begin line 990
  setline(990);
  if (strlit3661 == NULL) {
    strlit3661 = alloc_String(" %string");
  }
// compilenode returning strlit3661
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3663 = callmethod(strlit3661, "++", 1, params);
// compilenode returning opresult3663
  if (strlit3664 == NULL) {
    strlit3664 = alloc_String(" = phi %object [%alreadystring");
  }
// compilenode returning strlit3664
  params[0] = strlit3664;
  Object opresult3666 = callmethod(opresult3663, "++", 1, params);
// compilenode returning opresult3666
// Begin line 991
  setline(991);
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3668 = callmethod(opresult3666, "++", 1, params);
// compilenode returning opresult3668
  if (strlit3669 == NULL) {
    strlit3669 = alloc_String(", %strlit");
  }
// compilenode returning strlit3669
  params[0] = strlit3669;
  Object opresult3671 = callmethod(opresult3668, "++", 1, params);
// compilenode returning opresult3671
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3673 = callmethod(opresult3671, "++", 1, params);
// compilenode returning opresult3673
  if (strlit3674 == NULL) {
    strlit3674 = alloc_String(".already], ");
  }
// compilenode returning strlit3674
  params[0] = strlit3674;
  Object opresult3676 = callmethod(opresult3673, "++", 1, params);
// compilenode returning opresult3676
// Begin line 992
  setline(992);
  if (strlit3677 == NULL) {
    strlit3677 = alloc_String("[%defstring");
  }
// compilenode returning strlit3677
  params[0] = strlit3677;
  Object opresult3679 = callmethod(opresult3676, "++", 1, params);
// compilenode returning opresult3679
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3681 = callmethod(opresult3679, "++", 1, params);
// compilenode returning opresult3681
  if (strlit3682 == NULL) {
    strlit3682 = alloc_String(", %strlit");
  }
// compilenode returning strlit3682
  params[0] = strlit3682;
  Object opresult3684 = callmethod(opresult3681, "++", 1, params);
// compilenode returning opresult3684
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3686 = callmethod(opresult3684, "++", 1, params);
// compilenode returning opresult3686
// Begin line 993
  setline(993);
  if (strlit3687 == NULL) {
    strlit3687 = alloc_String(".define]");
  }
// compilenode returning strlit3687
  params[0] = strlit3687;
  Object opresult3689 = callmethod(opresult3686, "++", 1, params);
// compilenode returning opresult3689
// Begin line 994
  setline(994);
// compilenode returning self
  params[0] = opresult3689;
  Object call3690 = callmethod(self, "out",
    1, params);
// compilenode returning call3690
// Begin line 996
  setline(996);
// Begin line 994
  setline(994);
  if (strlit3691 == NULL) {
    strlit3691 = alloc_String("@.str");
  }
// compilenode returning strlit3691
// Begin line 996
  setline(996);
// Begin line 1429
  setline(1429);
// Begin line 994
  setline(994);
// compilenode returning *var_constants
  Object call3692 = callmethod(*var_constants, "size",
    0, params);
// compilenode returning call3692
// compilenode returning call3692
  params[0] = call3692;
  Object opresult3694 = callmethod(strlit3691, "++", 1, params);
// compilenode returning opresult3694
  if (strlit3695 == NULL) {
    strlit3695 = alloc_String(" = private unnamed_addr ");
  }
// compilenode returning strlit3695
  params[0] = strlit3695;
  Object opresult3697 = callmethod(opresult3694, "++", 1, params);
// compilenode returning opresult3697
// Begin line 995
  setline(995);
  if (strlit3698 == NULL) {
    strlit3698 = alloc_String("constant [");
  }
// compilenode returning strlit3698
  params[0] = strlit3698;
  Object opresult3700 = callmethod(opresult3697, "++", 1, params);
// compilenode returning opresult3700
// compilenode returning *var_l
  params[0] = *var_l;
  Object opresult3702 = callmethod(opresult3700, "++", 1, params);
// compilenode returning opresult3702
  if (strlit3703 == NULL) {
    strlit3703 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit3703
  params[0] = strlit3703;
  Object opresult3705 = callmethod(opresult3702, "++", 1, params);
// compilenode returning opresult3705
// Begin line 996
  setline(996);
// Begin line 1429
  setline(1429);
// Begin line 995
  setline(995);
// compilenode returning *var_o
  Object call3706 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3706
// compilenode returning call3706
  params[0] = call3706;
  Object opresult3708 = callmethod(opresult3705, "++", 1, params);
// compilenode returning opresult3708
  if (strlit3709 == NULL) {
    strlit3709 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit3709
  params[0] = strlit3709;
  Object opresult3711 = callmethod(opresult3708, "++", 1, params);
// compilenode returning opresult3711
  var_con = alloc_var();
  *var_con = opresult3711;
  if (opresult3711 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 996
  setline(996);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3712 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3712
// Begin line 999
  setline(999);
// Begin line 997
  setline(997);
  if (strlit3713 == NULL) {
    strlit3713 = alloc_String("@.strlit");
  }
// compilenode returning strlit3713
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3715 = callmethod(strlit3713, "++", 1, params);
// compilenode returning opresult3715
// Begin line 998
  setline(998);
  if (strlit3716 == NULL) {
    strlit3716 = alloc_String(" = private global %object null");
  }
// compilenode returning strlit3716
  params[0] = strlit3716;
  Object opresult3718 = callmethod(opresult3715, "++", 1, params);
// compilenode returning opresult3718
  *var_con = opresult3718;
  if (opresult3718 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 999
  setline(999);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call3720 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call3720
// Begin line 1001
  setline(1001);
// Begin line 1429
  setline(1429);
// Begin line 1001
  setline(1001);
// Begin line 1000
  setline(1000);
  if (strlit3721 == NULL) {
    strlit3721 = alloc_String("%string");
  }
// compilenode returning strlit3721
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3723 = callmethod(strlit3721, "++", 1, params);
// compilenode returning opresult3723
// compilenode returning *var_o
  params[0] = opresult3723;
  Object call3724 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3724
// compilenode returning nothing
// Begin line 1002
  setline(1002);
// Begin line 1001
  setline(1001);
// compilenode returning *var_auto_count
  Object num3725 = alloc_Float64(1.0);
// compilenode returning num3725
  params[0] = num3725;
  Object sum3727 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum3727
  *var_auto_count = sum3727;
  if (sum3727 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3516 = nothing;
  } else {
  }
// compilenode returning if3516
// Begin line 1004
  setline(1004);
// Begin line 1006
  setline(1006);
// Begin line 1429
  setline(1429);
// Begin line 1003
  setline(1003);
// compilenode returning *var_o
  Object call3730 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3730
// compilenode returning call3730
  if (strlit3731 == NULL) {
    strlit3731 = alloc_String("index");
  }
// compilenode returning strlit3731
  params[0] = strlit3731;
  Object opresult3733 = callmethod(call3730, "==", 1, params);
// compilenode returning opresult3733
  Object if3729;
  if (istrue(opresult3733)) {
// Begin line 1004
  setline(1004);
// compilenode returning *var_o
// Begin line 1005
  setline(1005);
// compilenode returning self
  params[0] = *var_o;
  Object call3734 = callmethod(self, "compileindex",
    1, params);
// compilenode returning call3734
    if3729 = call3734;
  } else {
  }
// compilenode returning if3729
// Begin line 1007
  setline(1007);
// Begin line 1009
  setline(1009);
// Begin line 1429
  setline(1429);
// Begin line 1006
  setline(1006);
// compilenode returning *var_o
  Object call3736 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3736
// compilenode returning call3736
  if (strlit3737 == NULL) {
    strlit3737 = alloc_String("octets");
  }
// compilenode returning strlit3737
  params[0] = strlit3737;
  Object opresult3739 = callmethod(call3736, "==", 1, params);
// compilenode returning opresult3739
  Object if3735;
  if (istrue(opresult3739)) {
// Begin line 1007
  setline(1007);
// compilenode returning *var_o
// Begin line 1008
  setline(1008);
// compilenode returning self
  params[0] = *var_o;
  Object call3740 = callmethod(self, "compileoctets",
    1, params);
// compilenode returning call3740
    if3735 = call3740;
  } else {
  }
// compilenode returning if3735
// Begin line 1010
  setline(1010);
// Begin line 1012
  setline(1012);
// Begin line 1429
  setline(1429);
// Begin line 1009
  setline(1009);
// compilenode returning *var_o
  Object call3742 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3742
// compilenode returning call3742
  if (strlit3743 == NULL) {
    strlit3743 = alloc_String("import");
  }
// compilenode returning strlit3743
  params[0] = strlit3743;
  Object opresult3745 = callmethod(call3742, "==", 1, params);
// compilenode returning opresult3745
  Object if3741;
  if (istrue(opresult3745)) {
// Begin line 1010
  setline(1010);
// compilenode returning *var_o
// Begin line 1011
  setline(1011);
// compilenode returning self
  params[0] = *var_o;
  Object call3746 = callmethod(self, "compileimport",
    1, params);
// compilenode returning call3746
    if3741 = call3746;
  } else {
  }
// compilenode returning if3741
// Begin line 1013
  setline(1013);
// Begin line 1015
  setline(1015);
// Begin line 1429
  setline(1429);
// Begin line 1012
  setline(1012);
// compilenode returning *var_o
  Object call3748 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3748
// compilenode returning call3748
  if (strlit3749 == NULL) {
    strlit3749 = alloc_String("return");
  }
// compilenode returning strlit3749
  params[0] = strlit3749;
  Object opresult3751 = callmethod(call3748, "==", 1, params);
// compilenode returning opresult3751
  Object if3747;
  if (istrue(opresult3751)) {
// Begin line 1013
  setline(1013);
// compilenode returning *var_o
// Begin line 1014
  setline(1014);
// compilenode returning self
  params[0] = *var_o;
  Object call3752 = callmethod(self, "compilereturn",
    1, params);
// compilenode returning call3752
    if3747 = call3752;
  } else {
  }
// compilenode returning if3747
// Begin line 1016
  setline(1016);
// Begin line 1018
  setline(1018);
// Begin line 1429
  setline(1429);
// Begin line 1015
  setline(1015);
// compilenode returning *var_o
  Object call3754 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3754
// compilenode returning call3754
  if (strlit3755 == NULL) {
    strlit3755 = alloc_String("generic");
  }
// compilenode returning strlit3755
  params[0] = strlit3755;
  Object opresult3757 = callmethod(call3754, "==", 1, params);
// compilenode returning opresult3757
  Object if3753;
  if (istrue(opresult3757)) {
// Begin line 1016
  setline(1016);
// Begin line 1429
  setline(1429);
// Begin line 1016
  setline(1016);
// Begin line 1429
  setline(1429);
// Begin line 1016
  setline(1016);
// compilenode returning *var_o
  Object call3758 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3758
// compilenode returning call3758
// Begin line 1017
  setline(1017);
// compilenode returning self
  params[0] = call3758;
  Object call3759 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call3759
// Begin line 1016
  setline(1016);
// compilenode returning *var_o
  params[0] = call3759;
  Object call3760 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3760
// compilenode returning nothing
    if3753 = nothing;
  } else {
  }
// compilenode returning if3753
// Begin line 1029
  setline(1029);
// Begin line 1031
  setline(1031);
// Begin line 1429
  setline(1429);
// Begin line 1018
  setline(1018);
// compilenode returning *var_o
  Object call3762 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3762
// compilenode returning call3762
  if (strlit3763 == NULL) {
    strlit3763 = alloc_String("identifier");
  }
// compilenode returning strlit3763
  params[0] = strlit3763;
  Object opresult3765 = callmethod(call3762, "==", 1, params);
// compilenode returning opresult3765
// Begin line 1031
  setline(1031);
// Begin line 1429
  setline(1429);
// Begin line 1019
  setline(1019);
// compilenode returning *var_o
  Object call3766 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3766
// compilenode returning call3766
  if (strlit3767 == NULL) {
    strlit3767 = alloc_String("true");
  }
// compilenode returning strlit3767
  params[0] = strlit3767;
  Object opresult3769 = callmethod(call3766, "==", 1, params);
// compilenode returning opresult3769
// Begin line 1031
  setline(1031);
// Begin line 1429
  setline(1429);
// Begin line 1019
  setline(1019);
// compilenode returning *var_o
  Object call3770 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3770
// compilenode returning call3770
  if (strlit3771 == NULL) {
    strlit3771 = alloc_String("false");
  }
// compilenode returning strlit3771
  params[0] = strlit3771;
  Object opresult3773 = callmethod(call3770, "==", 1, params);
// compilenode returning opresult3773
  params[0] = opresult3773;
  Object opresult3775 = callmethod(opresult3769, "|", 1, params);
// compilenode returning opresult3775
  params[0] = opresult3775;
  Object opresult3777 = callmethod(opresult3765, "&", 1, params);
// compilenode returning opresult3777
  Object if3761;
  if (istrue(opresult3777)) {
  Object *var_val = alloc_var();
  *var_val = undefined;
// Begin line 1021
  setline(1021);
// Begin line 1020
  setline(1020);
  Object num3778 = alloc_Float64(0.0);
// compilenode returning num3778
  var_val = alloc_var();
  *var_val = num3778;
  if (num3778 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1023
  setline(1023);
// Begin line 1024
  setline(1024);
// Begin line 1429
  setline(1429);
// Begin line 1021
  setline(1021);
// compilenode returning *var_o
  Object call3780 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3780
// compilenode returning call3780
  if (strlit3781 == NULL) {
    strlit3781 = alloc_String("true");
  }
// compilenode returning strlit3781
  params[0] = strlit3781;
  Object opresult3783 = callmethod(call3780, "==", 1, params);
// compilenode returning opresult3783
  Object if3779;
  if (istrue(opresult3783)) {
// Begin line 1023
  setline(1023);
// Begin line 1022
  setline(1022);
  Object num3784 = alloc_Float64(1.0);
// compilenode returning num3784
  *var_val = num3784;
  if (num3784 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3779 = nothing;
  } else {
  }
// compilenode returning if3779
// Begin line 1025
  setline(1025);
// Begin line 1024
  setline(1024);
  if (strlit3786 == NULL) {
    strlit3786 = alloc_String("  %bool");
  }
// compilenode returning strlit3786
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3788 = callmethod(strlit3786, "++", 1, params);
// compilenode returning opresult3788
  if (strlit3789 == NULL) {
    strlit3789 = alloc_String(" = call %object ");
  }
// compilenode returning strlit3789
  params[0] = strlit3789;
  Object opresult3791 = callmethod(opresult3788, "++", 1, params);
// compilenode returning opresult3791
// Begin line 1025
  setline(1025);
  if (strlit3792 == NULL) {
    strlit3792 = alloc_String("@alloc_Boolean(i32 ");
  }
// compilenode returning strlit3792
  params[0] = strlit3792;
  Object opresult3794 = callmethod(opresult3791, "++", 1, params);
// compilenode returning opresult3794
// compilenode returning *var_val
  params[0] = *var_val;
  Object opresult3796 = callmethod(opresult3794, "++", 1, params);
// compilenode returning opresult3796
  if (strlit3797 == NULL) {
    strlit3797 = alloc_String(")");
  }
// compilenode returning strlit3797
  params[0] = strlit3797;
  Object opresult3799 = callmethod(opresult3796, "++", 1, params);
// compilenode returning opresult3799
// Begin line 1026
  setline(1026);
// compilenode returning self
  params[0] = opresult3799;
  Object call3800 = callmethod(self, "out",
    1, params);
// compilenode returning call3800
// Begin line 1027
  setline(1027);
// Begin line 1429
  setline(1429);
// Begin line 1027
  setline(1027);
// Begin line 1026
  setline(1026);
  if (strlit3801 == NULL) {
    strlit3801 = alloc_String("%bool");
  }
// compilenode returning strlit3801
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3803 = callmethod(strlit3801, "++", 1, params);
// compilenode returning opresult3803
// compilenode returning *var_o
  params[0] = opresult3803;
  Object call3804 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3804
// compilenode returning nothing
// Begin line 1028
  setline(1028);
// Begin line 1027
  setline(1027);
// compilenode returning *var_auto_count
  Object num3805 = alloc_Float64(1.0);
// compilenode returning num3805
  params[0] = num3805;
  Object sum3807 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum3807
  *var_auto_count = sum3807;
  if (sum3807 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3761 = nothing;
  } else {
// Begin line 1029
  setline(1029);
// Begin line 1031
  setline(1031);
// Begin line 1429
  setline(1429);
// Begin line 1028
  setline(1028);
// compilenode returning *var_o
  Object call3810 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3810
// compilenode returning call3810
  if (strlit3811 == NULL) {
    strlit3811 = alloc_String("identifier");
  }
// compilenode returning strlit3811
  params[0] = strlit3811;
  Object opresult3813 = callmethod(call3810, "==", 1, params);
// compilenode returning opresult3813
  Object if3809;
  if (istrue(opresult3813)) {
// Begin line 1029
  setline(1029);
// compilenode returning *var_o
// Begin line 1030
  setline(1030);
// compilenode returning self
  params[0] = *var_o;
  Object call3814 = callmethod(self, "compileidentifier",
    1, params);
// compilenode returning call3814
    if3809 = call3814;
  } else {
  }
// compilenode returning if3809
    if3761 = if3809;
  }
// compilenode returning if3761
// Begin line 1032
  setline(1032);
// Begin line 1034
  setline(1034);
// Begin line 1429
  setline(1429);
// Begin line 1031
  setline(1031);
// compilenode returning *var_o
  Object call3816 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3816
// compilenode returning call3816
  if (strlit3817 == NULL) {
    strlit3817 = alloc_String("defdec");
  }
// compilenode returning strlit3817
  params[0] = strlit3817;
  Object opresult3819 = callmethod(call3816, "==", 1, params);
// compilenode returning opresult3819
  Object if3815;
  if (istrue(opresult3819)) {
// Begin line 1032
  setline(1032);
// compilenode returning *var_o
// Begin line 1033
  setline(1033);
// compilenode returning self
  params[0] = *var_o;
  Object call3820 = callmethod(self, "compiledefdec",
    1, params);
// compilenode returning call3820
    if3815 = call3820;
  } else {
  }
// compilenode returning if3815
// Begin line 1035
  setline(1035);
// Begin line 1037
  setline(1037);
// Begin line 1429
  setline(1429);
// Begin line 1034
  setline(1034);
// compilenode returning *var_o
  Object call3822 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3822
// compilenode returning call3822
  if (strlit3823 == NULL) {
    strlit3823 = alloc_String("vardec");
  }
// compilenode returning strlit3823
  params[0] = strlit3823;
  Object opresult3825 = callmethod(call3822, "==", 1, params);
// compilenode returning opresult3825
  Object if3821;
  if (istrue(opresult3825)) {
// Begin line 1035
  setline(1035);
// compilenode returning *var_o
// Begin line 1036
  setline(1036);
// compilenode returning self
  params[0] = *var_o;
  Object call3826 = callmethod(self, "compilevardec",
    1, params);
// compilenode returning call3826
    if3821 = call3826;
  } else {
  }
// compilenode returning if3821
// Begin line 1038
  setline(1038);
// Begin line 1040
  setline(1040);
// Begin line 1429
  setline(1429);
// Begin line 1037
  setline(1037);
// compilenode returning *var_o
  Object call3828 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3828
// compilenode returning call3828
  if (strlit3829 == NULL) {
    strlit3829 = alloc_String("block");
  }
// compilenode returning strlit3829
  params[0] = strlit3829;
  Object opresult3831 = callmethod(call3828, "==", 1, params);
// compilenode returning opresult3831
  Object if3827;
  if (istrue(opresult3831)) {
// Begin line 1038
  setline(1038);
// compilenode returning *var_o
// Begin line 1039
  setline(1039);
// compilenode returning self
  params[0] = *var_o;
  Object call3832 = callmethod(self, "compileblock",
    1, params);
// compilenode returning call3832
    if3827 = call3832;
  } else {
  }
// compilenode returning if3827
// Begin line 1043
  setline(1043);
// Begin line 1044
  setline(1044);
// Begin line 1429
  setline(1429);
// Begin line 1040
  setline(1040);
// compilenode returning *var_o
  Object call3834 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3834
// compilenode returning call3834
  if (strlit3835 == NULL) {
    strlit3835 = alloc_String("method");
  }
// compilenode returning strlit3835
  params[0] = strlit3835;
  Object opresult3837 = callmethod(call3834, "==", 1, params);
// compilenode returning opresult3837
  Object if3833;
  if (istrue(opresult3837)) {
// Begin line 1041
  setline(1041);
// compilenode returning *var_o
  if (strlit3838 == NULL) {
    strlit3838 = alloc_String("%self");
  }
// compilenode returning strlit3838
// compilenode returning *var_topLevelMethodPos
// Begin line 1042
  setline(1042);
// compilenode returning self
  params[0] = *var_o;
  params[1] = strlit3838;
  params[2] = *var_topLevelMethodPos;
  Object call3839 = callmethod(self, "compilemethod",
    3, params);
// compilenode returning call3839
// Begin line 1043
  setline(1043);
// Begin line 1042
  setline(1042);
// compilenode returning *var_topLevelMethodPos
  Object num3840 = alloc_Float64(1.0);
// compilenode returning num3840
  params[0] = num3840;
  Object sum3842 = callmethod(*var_topLevelMethodPos, "+", 1, params);
// compilenode returning sum3842
  *var_topLevelMethodPos = sum3842;
  if (sum3842 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3833 = nothing;
  } else {
  }
// compilenode returning if3833
// Begin line 1045
  setline(1045);
// Begin line 1047
  setline(1047);
// Begin line 1429
  setline(1429);
// Begin line 1044
  setline(1044);
// compilenode returning *var_o
  Object call3845 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3845
// compilenode returning call3845
  if (strlit3846 == NULL) {
    strlit3846 = alloc_String("array");
  }
// compilenode returning strlit3846
  params[0] = strlit3846;
  Object opresult3848 = callmethod(call3845, "==", 1, params);
// compilenode returning opresult3848
  Object if3844;
  if (istrue(opresult3848)) {
// Begin line 1045
  setline(1045);
// compilenode returning *var_o
// Begin line 1046
  setline(1046);
// compilenode returning self
  params[0] = *var_o;
  Object call3849 = callmethod(self, "compilearray",
    1, params);
// compilenode returning call3849
    if3844 = call3849;
  } else {
  }
// compilenode returning if3844
// Begin line 1048
  setline(1048);
// Begin line 1050
  setline(1050);
// Begin line 1429
  setline(1429);
// Begin line 1047
  setline(1047);
// compilenode returning *var_o
  Object call3851 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3851
// compilenode returning call3851
  if (strlit3852 == NULL) {
    strlit3852 = alloc_String("bind");
  }
// compilenode returning strlit3852
  params[0] = strlit3852;
  Object opresult3854 = callmethod(call3851, "==", 1, params);
// compilenode returning opresult3854
  Object if3850;
  if (istrue(opresult3854)) {
// Begin line 1048
  setline(1048);
// compilenode returning *var_o
// Begin line 1049
  setline(1049);
// compilenode returning self
  params[0] = *var_o;
  Object call3855 = callmethod(self, "compilebind",
    1, params);
// compilenode returning call3855
    if3850 = call3855;
  } else {
  }
// compilenode returning if3850
// Begin line 1051
  setline(1051);
// Begin line 1053
  setline(1053);
// Begin line 1429
  setline(1429);
// Begin line 1050
  setline(1050);
// compilenode returning *var_o
  Object call3857 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3857
// compilenode returning call3857
  if (strlit3858 == NULL) {
    strlit3858 = alloc_String("while");
  }
// compilenode returning strlit3858
  params[0] = strlit3858;
  Object opresult3860 = callmethod(call3857, "==", 1, params);
// compilenode returning opresult3860
  Object if3856;
  if (istrue(opresult3860)) {
// Begin line 1051
  setline(1051);
// compilenode returning *var_o
// Begin line 1052
  setline(1052);
// compilenode returning self
  params[0] = *var_o;
  Object call3861 = callmethod(self, "compilewhile",
    1, params);
// compilenode returning call3861
    if3856 = call3861;
  } else {
  }
// compilenode returning if3856
// Begin line 1054
  setline(1054);
// Begin line 1056
  setline(1056);
// Begin line 1429
  setline(1429);
// Begin line 1053
  setline(1053);
// compilenode returning *var_o
  Object call3863 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3863
// compilenode returning call3863
  if (strlit3864 == NULL) {
    strlit3864 = alloc_String("if");
  }
// compilenode returning strlit3864
  params[0] = strlit3864;
  Object opresult3866 = callmethod(call3863, "==", 1, params);
// compilenode returning opresult3866
  Object if3862;
  if (istrue(opresult3866)) {
// Begin line 1054
  setline(1054);
// compilenode returning *var_o
// Begin line 1055
  setline(1055);
// compilenode returning self
  params[0] = *var_o;
  Object call3867 = callmethod(self, "compileif",
    1, params);
// compilenode returning call3867
    if3862 = call3867;
  } else {
  }
// compilenode returning if3862
// Begin line 1057
  setline(1057);
// Begin line 1059
  setline(1059);
// Begin line 1429
  setline(1429);
// Begin line 1056
  setline(1056);
// compilenode returning *var_o
  Object call3869 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3869
// compilenode returning call3869
  if (strlit3870 == NULL) {
    strlit3870 = alloc_String("class");
  }
// compilenode returning strlit3870
  params[0] = strlit3870;
  Object opresult3872 = callmethod(call3869, "==", 1, params);
// compilenode returning opresult3872
  Object if3868;
  if (istrue(opresult3872)) {
// Begin line 1057
  setline(1057);
// compilenode returning *var_o
// Begin line 1058
  setline(1058);
// compilenode returning self
  params[0] = *var_o;
  Object call3873 = callmethod(self, "compileclass",
    1, params);
// compilenode returning call3873
    if3868 = call3873;
  } else {
  }
// compilenode returning if3868
// Begin line 1060
  setline(1060);
// Begin line 1062
  setline(1062);
// Begin line 1429
  setline(1429);
// Begin line 1059
  setline(1059);
// compilenode returning *var_o
  Object call3875 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3875
// compilenode returning call3875
  if (strlit3876 == NULL) {
    strlit3876 = alloc_String("object");
  }
// compilenode returning strlit3876
  params[0] = strlit3876;
  Object opresult3878 = callmethod(call3875, "==", 1, params);
// compilenode returning opresult3878
  Object if3874;
  if (istrue(opresult3878)) {
// Begin line 1060
  setline(1060);
// compilenode returning *var_o
// Begin line 1061
  setline(1061);
// compilenode returning self
  params[0] = *var_o;
  Object call3879 = callmethod(self, "compileobject",
    1, params);
// compilenode returning call3879
    if3874 = call3879;
  } else {
  }
// compilenode returning if3874
// Begin line 1063
  setline(1063);
// Begin line 1065
  setline(1065);
// Begin line 1429
  setline(1429);
// Begin line 1062
  setline(1062);
// compilenode returning *var_o
  Object call3881 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3881
// compilenode returning call3881
  if (strlit3882 == NULL) {
    strlit3882 = alloc_String("member");
  }
// compilenode returning strlit3882
  params[0] = strlit3882;
  Object opresult3884 = callmethod(call3881, "==", 1, params);
// compilenode returning opresult3884
  Object if3880;
  if (istrue(opresult3884)) {
// Begin line 1063
  setline(1063);
// compilenode returning *var_o
// Begin line 1064
  setline(1064);
// compilenode returning self
  params[0] = *var_o;
  Object call3885 = callmethod(self, "compilemember",
    1, params);
// compilenode returning call3885
    if3880 = call3885;
  } else {
  }
// compilenode returning if3880
// Begin line 1066
  setline(1066);
// Begin line 1068
  setline(1068);
// Begin line 1429
  setline(1429);
// Begin line 1065
  setline(1065);
// compilenode returning *var_o
  Object call3887 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3887
// compilenode returning call3887
  if (strlit3888 == NULL) {
    strlit3888 = alloc_String("for");
  }
// compilenode returning strlit3888
  params[0] = strlit3888;
  Object opresult3890 = callmethod(call3887, "==", 1, params);
// compilenode returning opresult3890
  Object if3886;
  if (istrue(opresult3890)) {
// Begin line 1066
  setline(1066);
// compilenode returning *var_o
// Begin line 1067
  setline(1067);
// compilenode returning self
  params[0] = *var_o;
  Object call3891 = callmethod(self, "compilefor",
    1, params);
// compilenode returning call3891
    if3886 = call3891;
  } else {
  }
// compilenode returning if3886
// Begin line 1104
  setline(1104);
// Begin line 1107
  setline(1107);
// Begin line 1429
  setline(1429);
// Begin line 1068
  setline(1068);
// compilenode returning *var_o
  Object call3893 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call3893
// compilenode returning call3893
  if (strlit3894 == NULL) {
    strlit3894 = alloc_String("call");
  }
// compilenode returning strlit3894
  params[0] = strlit3894;
  Object opresult3896 = callmethod(call3893, "==", 1, params);
// compilenode returning opresult3896
  Object if3892;
  if (istrue(opresult3896)) {
// Begin line 1104
  setline(1104);
// Begin line 1106
  setline(1106);
// Begin line 1429
  setline(1429);
// Begin line 1106
  setline(1106);
// Begin line 1429
  setline(1429);
// Begin line 1069
  setline(1069);
// compilenode returning *var_o
  Object call3898 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3898
// compilenode returning call3898
  Object call3899 = callmethod(call3898, "value",
    0, params);
// compilenode returning call3899
// compilenode returning call3899
  if (strlit3900 == NULL) {
    strlit3900 = alloc_String("print");
  }
// compilenode returning strlit3900
  params[0] = strlit3900;
  Object opresult3902 = callmethod(call3899, "==", 1, params);
// compilenode returning opresult3902
  Object if3897;
  if (istrue(opresult3902)) {
  Object *var_args = alloc_var();
  *var_args = undefined;
  Object *var_parami = alloc_var();
  *var_parami = undefined;
// Begin line 1071
  setline(1071);
  Object array3903 = alloc_List();
// compilenode returning array3903
  var_args = alloc_var();
  *var_args = array3903;
  if (array3903 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1073
  setline(1073);
// Begin line 1075
  setline(1075);
// Begin line 1429
  setline(1429);
// Begin line 1071
  setline(1071);
// compilenode returning *var_o
  Object call3905 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call3905
// compilenode returning call3905
// Begin line 1073
  setline(1073);
// Begin line 1429
  setline(1429);
  Object obj3907 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3907, self, 0);
  addmethod2(obj3907, "outer", &reader_genllvm29_outer_3908);
  adddatum2(obj3907, self, 0);
  block_savedest(obj3907);
  Object **closure3909 = createclosure(2);
  addtoclosure(closure3909, var_args);
  Object *selfpp3912 = alloc_var();
  *selfpp3912 = self;
  addtoclosure(closure3909, selfpp3912);
  struct UserObject *uo3909 = (struct UserObject*)obj3907;
  uo3909->data[1] = (Object)closure3909;
  addmethod2(obj3907, "apply", &meth_genllvm29_apply3909);
  set_type(obj3907, 0);
// compilenode returning obj3907
  setclassname(obj3907, "Block<genllvm29:3906>");
// compilenode returning obj3907
  params[0] = call3905;
  Object iter3904 = callmethod(call3905, "iter", 1, params);
  while(1) {
    Object cond3904 = callmethod(iter3904, "havemore", 0, NULL);
    if (!istrue(cond3904)) break;
    params[0] = callmethod(iter3904, "next", 0, NULL);
    callmethod(obj3907, "apply", 1, params);
  }
// compilenode returning call3905
// Begin line 1076
  setline(1076);
// Begin line 1075
  setline(1075);
  Object num3913 = alloc_Float64(0.0);
// compilenode returning num3913
  var_parami = alloc_var();
  *var_parami = num3913;
  if (num3913 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1079
  setline(1079);
// Begin line 1076
  setline(1076);
// compilenode returning *var_args
// Begin line 1079
  setline(1079);
// Begin line 1429
  setline(1429);
  Object obj3916 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj3916, self, 0);
  addmethod2(obj3916, "outer", &reader_genllvm29_outer_3917);
  adddatum2(obj3916, self, 0);
  block_savedest(obj3916);
  Object **closure3918 = createclosure(2);
  addtoclosure(closure3918, var_parami);
  Object *selfpp3935 = alloc_var();
  *selfpp3935 = self;
  addtoclosure(closure3918, selfpp3935);
  struct UserObject *uo3918 = (struct UserObject*)obj3916;
  uo3918->data[1] = (Object)closure3918;
  addmethod2(obj3916, "apply", &meth_genllvm29_apply3918);
  set_type(obj3916, 0);
// compilenode returning obj3916
  setclassname(obj3916, "Block<genllvm29:3915>");
// compilenode returning obj3916
  params[0] = *var_args;
  Object iter3914 = callmethod(*var_args, "iter", 1, params);
  while(1) {
    Object cond3914 = callmethod(iter3914, "havemore", 0, NULL);
    if (!istrue(cond3914)) break;
    params[0] = callmethod(iter3914, "next", 0, NULL);
    callmethod(obj3916, "apply", 1, params);
  }
// compilenode returning *var_args
// Begin line 1081
  setline(1081);
// Begin line 1080
  setline(1080);
  if (strlit3936 == NULL) {
    strlit3936 = alloc_String("  %call");
  }
// compilenode returning strlit3936
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3938 = callmethod(strlit3936, "++", 1, params);
// compilenode returning opresult3938
  if (strlit3939 == NULL) {
    strlit3939 = alloc_String(" = call %object @gracelib_print(%object null, i32 ");
  }
// compilenode returning strlit3939
  params[0] = strlit3939;
  Object opresult3941 = callmethod(opresult3938, "++", 1, params);
// compilenode returning opresult3941
// Begin line 1081
  setline(1081);
// Begin line 1429
  setline(1429);
// Begin line 1081
  setline(1081);
// compilenode returning *var_args
  Object call3942 = callmethod(*var_args, "size",
    0, params);
// compilenode returning call3942
// compilenode returning call3942
  params[0] = call3942;
  Object opresult3944 = callmethod(opresult3941, "++", 1, params);
// compilenode returning opresult3944
  if (strlit3945 == NULL) {
    strlit3945 = alloc_String(", %object* %params)");
  }
// compilenode returning strlit3945
  params[0] = strlit3945;
  Object opresult3947 = callmethod(opresult3944, "++", 1, params);
// compilenode returning opresult3947
// Begin line 1082
  setline(1082);
// compilenode returning self
  params[0] = opresult3947;
  Object call3948 = callmethod(self, "out",
    1, params);
// compilenode returning call3948
// Begin line 1083
  setline(1083);
// Begin line 1429
  setline(1429);
// Begin line 1083
  setline(1083);
// Begin line 1082
  setline(1082);
  if (strlit3949 == NULL) {
    strlit3949 = alloc_String("%call");
  }
// compilenode returning strlit3949
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3951 = callmethod(strlit3949, "++", 1, params);
// compilenode returning opresult3951
// compilenode returning *var_o
  params[0] = opresult3951;
  Object call3952 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call3952
// compilenode returning nothing
// Begin line 1084
  setline(1084);
// Begin line 1083
  setline(1083);
// compilenode returning *var_auto_count
  Object num3953 = alloc_Float64(1.0);
// compilenode returning num3953
  params[0] = num3953;
  Object sum3955 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum3955
  *var_auto_count = sum3955;
  if (sum3955 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3897 = nothing;
  } else {
// Begin line 1104
  setline(1104);
// Begin line 1097
  setline(1097);
// Begin line 1429
  setline(1429);
// Begin line 1097
  setline(1097);
// Begin line 1429
  setline(1429);
// Begin line 1084
  setline(1084);
// compilenode returning *var_o
  Object call3958 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3958
// compilenode returning call3958
  Object call3959 = callmethod(call3958, "kind",
    0, params);
// compilenode returning call3959
// compilenode returning call3959
  if (strlit3960 == NULL) {
    strlit3960 = alloc_String("identifier");
  }
// compilenode returning strlit3960
  params[0] = strlit3960;
  Object opresult3962 = callmethod(call3959, "==", 1, params);
// compilenode returning opresult3962
// Begin line 1097
  setline(1097);
// Begin line 1429
  setline(1429);
// Begin line 1097
  setline(1097);
// Begin line 1429
  setline(1429);
// Begin line 1085
  setline(1085);
// compilenode returning *var_o
  Object call3963 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call3963
// compilenode returning call3963
  Object call3964 = callmethod(call3963, "value",
    0, params);
// compilenode returning call3964
// compilenode returning call3964
  if (strlit3965 == NULL) {
    strlit3965 = alloc_String("length");
  }
// compilenode returning strlit3965
  params[0] = strlit3965;
  Object opresult3967 = callmethod(call3964, "==", 1, params);
// compilenode returning opresult3967
  params[0] = opresult3967;
  Object opresult3969 = callmethod(opresult3962, "&", 1, params);
// compilenode returning opresult3969
  Object if3957;
  if (istrue(opresult3969)) {
// Begin line 1091
  setline(1091);
// Begin line 1093
  setline(1093);
// Begin line 1429
  setline(1429);
// Begin line 1093
  setline(1093);
// Begin line 1429
  setline(1429);
// Begin line 1086
  setline(1086);
// compilenode returning *var_o
  Object call3971 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call3971
// compilenode returning call3971
  Object call3972 = callmethod(call3971, "size",
    0, params);
// compilenode returning call3972
// compilenode returning call3972
  Object num3973 = alloc_Float64(0.0);
// compilenode returning num3973
  params[0] = num3973;
  Object opresult3975 = callmethod(call3972, "==", 1, params);
// compilenode returning opresult3975
  Object if3970;
  if (istrue(opresult3975)) {
// Begin line 1087
  setline(1087);
  if (strlit3976 == NULL) {
    strlit3976 = alloc_String("; PP FOLLOWS");
  }
// compilenode returning strlit3976
// Begin line 1088
  setline(1088);
// compilenode returning self
  params[0] = strlit3976;
  Object call3977 = callmethod(self, "out",
    1, params);
// compilenode returning call3977
  Object num3978 = alloc_Float64(0.0);
// compilenode returning num3978
// compilenode returning *var_o
  params[0] = num3978;
  Object call3979 = callmethod(*var_o, "pretty",
    1, params);
// compilenode returning call3979
// Begin line 1089
  setline(1089);
// compilenode returning self
  params[0] = call3979;
  Object call3980 = callmethod(self, "out",
    1, params);
// compilenode returning call3980
// Begin line 1090
  setline(1090);
// Begin line 1089
  setline(1089);
  if (strlit3981 == NULL) {
    strlit3981 = alloc_String("null");
  }
// compilenode returning strlit3981
  *var_tmp = strlit3981;
  if (strlit3981 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3970 = nothing;
  } else {
// Begin line 1091
  setline(1091);
// Begin line 1429
  setline(1429);
// Begin line 1091
  setline(1091);
// Begin line 1429
  setline(1429);
// Begin line 1091
  setline(1091);
// compilenode returning *var_o
  Object call3983 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call3983
// compilenode returning call3983
  Object call3984 = callmethod(call3983, "first",
    0, params);
// compilenode returning call3984
// compilenode returning call3984
// Begin line 1092
  setline(1092);
// compilenode returning self
  params[0] = call3984;
  Object call3985 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call3985
  *var_tmp = call3985;
  if (call3985 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3970 = nothing;
  }
// compilenode returning if3970
// Begin line 1094
  setline(1094);
// Begin line 1093
  setline(1093);
  if (strlit3987 == NULL) {
    strlit3987 = alloc_String("  %call");
  }
// compilenode returning strlit3987
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult3989 = callmethod(strlit3987, "++", 1, params);
// compilenode returning opresult3989
  if (strlit3990 == NULL) {
    strlit3990 = alloc_String(" = call %object ");
  }
// compilenode returning strlit3990
  params[0] = strlit3990;
  Object opresult3992 = callmethod(opresult3989, "++", 1, params);
// compilenode returning opresult3992
// Begin line 1094
  setline(1094);
  if (strlit3993 == NULL) {
    strlit3993 = alloc_String("@gracelib_length(%object ");
  }
// compilenode returning strlit3993
  params[0] = strlit3993;
  Object opresult3995 = callmethod(opresult3992, "++", 1, params);
// compilenode returning opresult3995
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult3997 = callmethod(opresult3995, "++", 1, params);
// compilenode returning opresult3997
  if (strlit3998 == NULL) {
    strlit3998 = alloc_String(")");
  }
// compilenode returning strlit3998
  params[0] = strlit3998;
  Object opresult4000 = callmethod(opresult3997, "++", 1, params);
// compilenode returning opresult4000
// Begin line 1095
  setline(1095);
// compilenode returning self
  params[0] = opresult4000;
  Object call4001 = callmethod(self, "out",
    1, params);
// compilenode returning call4001
// Begin line 1096
  setline(1096);
// Begin line 1429
  setline(1429);
// Begin line 1096
  setline(1096);
// Begin line 1095
  setline(1095);
  if (strlit4002 == NULL) {
    strlit4002 = alloc_String("%call");
  }
// compilenode returning strlit4002
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult4004 = callmethod(strlit4002, "++", 1, params);
// compilenode returning opresult4004
// compilenode returning *var_o
  params[0] = opresult4004;
  Object call4005 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call4005
// compilenode returning nothing
// Begin line 1097
  setline(1097);
// Begin line 1096
  setline(1096);
// compilenode returning *var_auto_count
  Object num4006 = alloc_Float64(1.0);
// compilenode returning num4006
  params[0] = num4006;
  Object sum4008 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum4008
  *var_auto_count = sum4008;
  if (sum4008 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if3957 = nothing;
  } else {
// Begin line 1104
  setline(1104);
// Begin line 1103
  setline(1103);
// Begin line 1429
  setline(1429);
// Begin line 1103
  setline(1103);
// Begin line 1429
  setline(1429);
// Begin line 1097
  setline(1097);
// compilenode returning *var_o
  Object call4011 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call4011
// compilenode returning call4011
  Object call4012 = callmethod(call4011, "kind",
    0, params);
// compilenode returning call4012
// compilenode returning call4012
  if (strlit4013 == NULL) {
    strlit4013 = alloc_String("identifier");
  }
// compilenode returning strlit4013
  params[0] = strlit4013;
  Object opresult4015 = callmethod(call4012, "==", 1, params);
// compilenode returning opresult4015
// Begin line 1103
  setline(1103);
// Begin line 1429
  setline(1429);
// Begin line 1103
  setline(1103);
// Begin line 1429
  setline(1429);
// Begin line 1098
  setline(1098);
// compilenode returning *var_o
  Object call4016 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call4016
// compilenode returning call4016
  Object call4017 = callmethod(call4016, "value",
    0, params);
// compilenode returning call4017
// compilenode returning call4017
  if (strlit4018 == NULL) {
    strlit4018 = alloc_String("escapestring");
  }
// compilenode returning strlit4018
  params[0] = strlit4018;
  Object opresult4020 = callmethod(call4017, "==", 1, params);
// compilenode returning opresult4020
  params[0] = opresult4020;
  Object opresult4022 = callmethod(opresult4015, "&", 1, params);
// compilenode returning opresult4022
  Object if4010;
  if (istrue(opresult4022)) {
// Begin line 1100
  setline(1100);
// Begin line 1429
  setline(1429);
// Begin line 1100
  setline(1100);
// Begin line 1429
  setline(1429);
// Begin line 1099
  setline(1099);
// compilenode returning *var_o
  Object call4023 = callmethod(*var_o, "with",
    0, params);
// compilenode returning call4023
// compilenode returning call4023
  Object call4024 = callmethod(call4023, "first",
    0, params);
// compilenode returning call4024
// compilenode returning call4024
  *var_tmp = call4024;
  if (call4024 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1100
  setline(1100);
  if (strlit4026 == NULL) {
    strlit4026 = alloc_String("_escape");
  }
// compilenode returning strlit4026
// compilenode returning *var_tmp
// compilenode returning module_ast
  params[0] = strlit4026;
  params[1] = *var_tmp;
  Object call4027 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call4027
  *var_tmp = call4027;
  if (call4027 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1101
  setline(1101);
// compilenode returning *var_tmp
  Object array4029 = alloc_List();
// compilenode returning array4029
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = array4029;
  Object call4030 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call4030
  *var_tmp = call4030;
  if (call4030 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1102
  setline(1102);
// Begin line 1429
  setline(1429);
// Begin line 1102
  setline(1102);
// compilenode returning *var_tmp
// Begin line 1103
  setline(1103);
// compilenode returning self
  params[0] = *var_tmp;
  Object call4032 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call4032
// Begin line 1102
  setline(1102);
// compilenode returning *var_o
  params[0] = call4032;
  Object call4033 = callmethod(*var_o, "register:=",
    1, params);
// compilenode returning call4033
// compilenode returning nothing
    if4010 = nothing;
  } else {
// Begin line 1104
  setline(1104);
// compilenode returning *var_o
// Begin line 1105
  setline(1105);
// compilenode returning self
  params[0] = *var_o;
  Object call4034 = callmethod(self, "compilecall",
    1, params);
// compilenode returning call4034
    if4010 = call4034;
  }
// compilenode returning if4010
    if3957 = if4010;
  }
// compilenode returning if3957
    if3897 = if3957;
  }
// compilenode returning if3897
    if3892 = if3897;
  } else {
  }
// compilenode returning if3892
// Begin line 1108
  setline(1108);
// Begin line 1110
  setline(1110);
// Begin line 1429
  setline(1429);
// Begin line 1107
  setline(1107);
// compilenode returning *var_o
  Object call4036 = callmethod(*var_o, "kind",
    0, params);
// compilenode returning call4036
// compilenode returning call4036
  if (strlit4037 == NULL) {
    strlit4037 = alloc_String("op");
  }
// compilenode returning strlit4037
  params[0] = strlit4037;
  Object opresult4039 = callmethod(call4036, "==", 1, params);
// compilenode returning opresult4039
  Object if4035;
  if (istrue(opresult4039)) {
// Begin line 1108
  setline(1108);
// compilenode returning *var_o
// Begin line 1109
  setline(1109);
// compilenode returning self
  params[0] = *var_o;
  Object call4040 = callmethod(self, "compileop",
    1, params);
// compilenode returning call4040
    if4035 = call4040;
  } else {
  }
// compilenode returning if4035
// Begin line 1110
  setline(1110);
  if (strlit4041 == NULL) {
    strlit4041 = alloc_String("; compilenode returning ");
  }
// compilenode returning strlit4041
// Begin line 1429
  setline(1429);
// Begin line 1110
  setline(1110);
// compilenode returning *var_o
  Object call4042 = callmethod(*var_o, "register",
    0, params);
// compilenode returning call4042
// compilenode returning call4042
  params[0] = call4042;
  Object opresult4044 = callmethod(strlit4041, "++", 1, params);
// compilenode returning opresult4044
// Begin line 1111
  setline(1111);
// compilenode returning self
  params[0] = opresult4044;
  Object call4045 = callmethod(self, "out",
    1, params);
// compilenode returning call4045
// Begin line 1429
  setline(1429);
// Begin line 1111
  setline(1111);
// compilenode returning *var_o
  Object call4046 = callmethod(*var_o, "register",
    0, params);
// compilenode returning call4046
// compilenode returning call4046
  return call4046;
}
Object meth_genllvm29_apply4067(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[2];
  Object *var_buildtype = closure[0];
  Object *var_linkfiles = closure[1];
  Object *var_staticmodules = closure[2];
  Object *var_ext = closure[3];
  Object *var_argv = closure[4];
  Object *var_cmd = closure[5];
  Object self = *closure[6];
// Begin line 1176
  setline(1176);
// Begin line 1179
  setline(1179);
// Begin line 1429
  setline(1429);
// Begin line 1127
  setline(1127);
// compilenode returning *var_v
  Object call4069 = callmethod(*var_v, "kind",
    0, params);
// compilenode returning call4069
// compilenode returning call4069
  if (strlit4070 == NULL) {
    strlit4070 = alloc_String("import");
  }
// compilenode returning strlit4070
  params[0] = strlit4070;
  Object opresult4072 = callmethod(call4069, "==", 1, params);
// compilenode returning opresult4072
  Object if4068;
  if (istrue(opresult4072)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_exists = alloc_var();
  *var_exists = undefined;
// Begin line 1129
  setline(1129);
// Begin line 1429
  setline(1429);
// Begin line 1129
  setline(1129);
// Begin line 1429
  setline(1429);
// Begin line 1128
  setline(1128);
// compilenode returning *var_v
  Object call4073 = callmethod(*var_v, "value",
    0, params);
// compilenode returning call4073
// compilenode returning call4073
  Object call4074 = callmethod(call4073, "value",
    0, params);
// compilenode returning call4074
// compilenode returning call4074
  var_nm = alloc_var();
  *var_nm = call4074;
  if (call4074 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1130
  setline(1130);
// Begin line 1129
  setline(1129);
  Object bool4075 = alloc_Boolean(0);
// compilenode returning bool4075
  var_exists = alloc_var();
  *var_exists = bool4075;
  if (bool4075 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1133
  setline(1133);
// Begin line 1131
  setline(1131);
// Begin line 1134
  setline(1134);
// Begin line 1130
  setline(1130);
// compilenode returning *var_buildtype
  if (strlit4077 == NULL) {
    strlit4077 = alloc_String("native");
  }
// compilenode returning strlit4077
  params[0] = strlit4077;
  Object opresult4079 = callmethod(*var_buildtype, "==", 1, params);
// compilenode returning opresult4079
// Begin line 1131
  setline(1131);
// compilenode returning *var_nm
  if (strlit4080 == NULL) {
    strlit4080 = alloc_String(".gso");
  }
// compilenode returning strlit4080
  params[0] = strlit4080;
  Object opresult4082 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4082
// compilenode returning module_io
  params[0] = opresult4082;
  Object call4083 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call4083
  params[0] = call4083;
  Object opresult4085 = callmethod(opresult4079, "&", 1, params);
// compilenode returning opresult4085
  Object if4076;
  if (istrue(opresult4085)) {
// Begin line 1133
  setline(1133);
// Begin line 1132
  setline(1132);
  Object bool4086 = alloc_Boolean(1);
// compilenode returning bool4086
  *var_exists = bool4086;
  if (bool4086 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4076 = nothing;
  } else {
  }
// compilenode returning if4076
// Begin line 1139
  setline(1139);
// Begin line 1143
  setline(1143);
// Begin line 1429
  setline(1429);
// Begin line 1134
  setline(1134);
// compilenode returning *var_exists
  Object call4089 = callmethod(*var_exists, "not",
    0, params);
// compilenode returning call4089
// compilenode returning call4089
  Object if4088;
  if (istrue(call4089)) {
// Begin line 1139
  setline(1139);
// Begin line 1135
  setline(1135);
// compilenode returning *var_nm
  if (strlit4091 == NULL) {
    strlit4091 = alloc_String(".gco");
  }
// compilenode returning strlit4091
  params[0] = strlit4091;
  Object opresult4093 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4093
// compilenode returning module_io
  params[0] = opresult4093;
  Object call4094 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call4094
  Object if4090;
  if (istrue(call4094)) {
// Begin line 1139
  setline(1139);
// Begin line 1136
  setline(1136);
// compilenode returning *var_nm
  if (strlit4096 == NULL) {
    strlit4096 = alloc_String(".gco");
  }
// compilenode returning strlit4096
  params[0] = strlit4096;
  Object opresult4098 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4098
// compilenode returning *var_nm
  if (strlit4099 == NULL) {
    strlit4099 = alloc_String(".grace");
  }
// compilenode returning strlit4099
  params[0] = strlit4099;
  Object opresult4101 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4101
// compilenode returning module_io
  params[0] = opresult4098;
  params[1] = opresult4101;
  Object call4102 = callmethod(module_io, "newer",
    2, params);
// compilenode returning call4102
  Object if4095;
  if (istrue(call4102)) {
// Begin line 1138
  setline(1138);
// Begin line 1137
  setline(1137);
  Object bool4103 = alloc_Boolean(1);
// compilenode returning bool4103
  *var_exists = bool4103;
  if (bool4103 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1138
  setline(1138);
// compilenode returning *var_nm
  if (strlit4105 == NULL) {
    strlit4105 = alloc_String(".gco");
  }
// compilenode returning strlit4105
  params[0] = strlit4105;
  Object opresult4107 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4107
// compilenode returning *var_linkfiles
  params[0] = opresult4107;
  Object call4108 = callmethod(*var_linkfiles, "push",
    1, params);
// compilenode returning call4108
// Begin line 1139
  setline(1139);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call4109 = callmethod(*var_staticmodules, "push",
    1, params);
// compilenode returning call4109
    if4095 = call4109;
  } else {
  }
// compilenode returning if4095
    if4090 = if4095;
  } else {
  }
// compilenode returning if4090
    if4088 = if4090;
  } else {
  }
// compilenode returning if4088
// Begin line 1169
  setline(1169);
// Begin line 1171
  setline(1171);
// Begin line 1429
  setline(1429);
// Begin line 1143
  setline(1143);
// compilenode returning *var_exists
  Object call4111 = callmethod(*var_exists, "not",
    0, params);
// compilenode returning call4111
// compilenode returning call4111
  Object if4110;
  if (istrue(call4111)) {
// Begin line 1146
  setline(1146);
// Begin line 1144
  setline(1144);
// compilenode returning *var_nm
  if (strlit4113 == NULL) {
    strlit4113 = alloc_String(".gc");
  }
// compilenode returning strlit4113
  params[0] = strlit4113;
  Object opresult4115 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4115
// compilenode returning module_io
  params[0] = opresult4115;
  Object call4116 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call4116
  Object if4112;
  if (istrue(call4116)) {
// Begin line 1146
  setline(1146);
// Begin line 1145
  setline(1145);
  if (strlit4117 == NULL) {
    strlit4117 = alloc_String(".gc");
  }
// compilenode returning strlit4117
  *var_ext = strlit4117;
  if (strlit4117 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4112 = nothing;
  } else {
  }
// compilenode returning if4112
// Begin line 1149
  setline(1149);
// Begin line 1147
  setline(1147);
// compilenode returning *var_nm
  if (strlit4120 == NULL) {
    strlit4120 = alloc_String(".grace");
  }
// compilenode returning strlit4120
  params[0] = strlit4120;
  Object opresult4122 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4122
// compilenode returning module_io
  params[0] = opresult4122;
  Object call4123 = callmethod(module_io, "exists",
    1, params);
// compilenode returning call4123
  Object if4119;
  if (istrue(call4123)) {
// Begin line 1149
  setline(1149);
// Begin line 1148
  setline(1148);
  if (strlit4124 == NULL) {
    strlit4124 = alloc_String(".grace");
  }
// compilenode returning strlit4124
  *var_ext = strlit4124;
  if (strlit4124 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4119 = nothing;
  } else {
  }
// compilenode returning if4119
// Begin line 1169
  setline(1169);
// Begin line 1170
  setline(1170);
// Begin line 1150
  setline(1150);
// compilenode returning *var_ext
  Object bool4127 = alloc_Boolean(0);
// compilenode returning bool4127
  params[0] = bool4127;
  Object opresult4129 = callmethod(*var_ext, "/=", 1, params);
// compilenode returning opresult4129
  Object if4126;
  if (istrue(opresult4129)) {
// Begin line 1152
  setline(1152);
// Begin line 1429
  setline(1429);
// Begin line 1151
  setline(1151);
// compilenode returning *var_argv
  Object call4130 = callmethod(*var_argv, "first",
    0, params);
// compilenode returning call4130
// compilenode returning call4130
  if (strlit4131 == NULL) {
    strlit4131 = alloc_String(" --target llvm29");
  }
// compilenode returning strlit4131
  params[0] = strlit4131;
  Object opresult4133 = callmethod(call4130, "++", 1, params);
// compilenode returning opresult4133
  *var_cmd = opresult4133;
  if (opresult4133 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1153
  setline(1153);
// Begin line 1152
  setline(1152);
// compilenode returning *var_cmd
  if (strlit4135 == NULL) {
    strlit4135 = alloc_String(" --make ");
  }
// compilenode returning strlit4135
  params[0] = strlit4135;
  Object opresult4137 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4137
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult4139 = callmethod(opresult4137, "++", 1, params);
// compilenode returning opresult4139
// compilenode returning *var_ext
  params[0] = *var_ext;
  Object opresult4141 = callmethod(opresult4139, "++", 1, params);
// compilenode returning opresult4141
  *var_cmd = opresult4141;
  if (opresult4141 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1155
  setline(1155);
// Begin line 1156
  setline(1156);
// Begin line 1429
  setline(1429);
// Begin line 1153
  setline(1153);
// compilenode returning module_util
  Object call4144 = callmethod(module_util, "verbosity",
    0, params);
// compilenode returning call4144
// compilenode returning call4144
  Object num4145 = alloc_Float64(30.0);
// compilenode returning num4145
  params[0] = num4145;
  Object opresult4147 = callmethod(call4144, ">", 1, params);
// compilenode returning opresult4147
  Object if4143;
  if (istrue(opresult4147)) {
// Begin line 1155
  setline(1155);
// Begin line 1154
  setline(1154);
// compilenode returning *var_cmd
  if (strlit4148 == NULL) {
    strlit4148 = alloc_String(" --verbose");
  }
// compilenode returning strlit4148
  params[0] = strlit4148;
  Object opresult4150 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4150
  *var_cmd = opresult4150;
  if (opresult4150 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4143 = nothing;
  } else {
  }
// compilenode returning if4143
// Begin line 1158
  setline(1158);
// Begin line 1159
  setline(1159);
// Begin line 1429
  setline(1429);
// Begin line 1156
  setline(1156);
// compilenode returning module_util
  Object call4153 = callmethod(module_util, "vtag",
    0, params);
// compilenode returning call4153
// compilenode returning call4153
  Object if4152;
  if (istrue(call4153)) {
// Begin line 1158
  setline(1158);
// Begin line 1157
  setline(1157);
// compilenode returning *var_cmd
  if (strlit4154 == NULL) {
    strlit4154 = alloc_String(" --vtag ");
  }
// compilenode returning strlit4154
  params[0] = strlit4154;
  Object opresult4156 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4156
// Begin line 1158
  setline(1158);
// Begin line 1429
  setline(1429);
// Begin line 1157
  setline(1157);
// compilenode returning module_util
  Object call4157 = callmethod(module_util, "vtag",
    0, params);
// compilenode returning call4157
// compilenode returning call4157
  params[0] = call4157;
  Object opresult4159 = callmethod(opresult4156, "++", 1, params);
// compilenode returning opresult4159
  *var_cmd = opresult4159;
  if (opresult4159 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4152 = nothing;
  } else {
  }
// compilenode returning if4152
// Begin line 1161
  setline(1161);
// Begin line 1162
  setline(1162);
// Begin line 1159
  setline(1159);
// compilenode returning *var_buildtype
  if (strlit4162 == NULL) {
    strlit4162 = alloc_String("native");
  }
// compilenode returning strlit4162
  params[0] = strlit4162;
  Object opresult4164 = callmethod(*var_buildtype, "==", 1, params);
// compilenode returning opresult4164
  Object if4161;
  if (istrue(opresult4164)) {
// Begin line 1161
  setline(1161);
// Begin line 1160
  setline(1160);
// compilenode returning *var_cmd
  if (strlit4165 == NULL) {
    strlit4165 = alloc_String(" --native --noexec");
  }
// compilenode returning strlit4165
  params[0] = strlit4165;
  Object opresult4167 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4167
  *var_cmd = opresult4167;
  if (opresult4167 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4161 = nothing;
  } else {
  }
// compilenode returning if4161
// Begin line 1163
  setline(1163);
// Begin line 1162
  setline(1162);
// Begin line 1429
  setline(1429);
// Begin line 1162
  setline(1162);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4170 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4170
  Object call4171 = callmethod(call4170, "not",
    0, params);
// compilenode returning call4171
// compilenode returning call4171
  Object if4169;
  if (istrue(call4171)) {
// Begin line 1163
  setline(1163);
  if (strlit4172 == NULL) {
    strlit4172 = alloc_String("failed processing import of ");
  }
// compilenode returning strlit4172
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult4174 = callmethod(strlit4172, "++", 1, params);
// compilenode returning opresult4174
  if (strlit4175 == NULL) {
    strlit4175 = alloc_String(".");
  }
// compilenode returning strlit4175
  params[0] = strlit4175;
  Object opresult4177 = callmethod(opresult4174, "++", 1, params);
// compilenode returning opresult4177
// compilenode returning module_util
  params[0] = opresult4177;
  Object call4178 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call4178
    if4169 = call4178;
  } else {
  }
// compilenode returning if4169
// Begin line 1166
  setline(1166);
// Begin line 1165
  setline(1165);
  Object bool4179 = alloc_Boolean(1);
// compilenode returning bool4179
  *var_exists = bool4179;
  if (bool4179 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1166
  setline(1166);
// compilenode returning *var_nm
  if (strlit4181 == NULL) {
    strlit4181 = alloc_String(".gco");
  }
// compilenode returning strlit4181
  params[0] = strlit4181;
  Object opresult4183 = callmethod(*var_nm, "++", 1, params);
// compilenode returning opresult4183
// compilenode returning *var_linkfiles
  params[0] = opresult4183;
  Object call4184 = callmethod(*var_linkfiles, "push",
    1, params);
// compilenode returning call4184
// Begin line 1167
  setline(1167);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call4185 = callmethod(*var_staticmodules, "push",
    1, params);
// compilenode returning call4185
// Begin line 1169
  setline(1169);
// Begin line 1168
  setline(1168);
  Object bool4186 = alloc_Boolean(0);
// compilenode returning bool4186
  *var_ext = bool4186;
  if (bool4186 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4126 = nothing;
  } else {
  }
// compilenode returning if4126
    if4110 = if4126;
  } else {
  }
// compilenode returning if4110
// Begin line 1173
  setline(1173);
// Begin line 1175
  setline(1175);
// Begin line 1171
  setline(1171);
// compilenode returning *var_nm
  if (strlit4189 == NULL) {
    strlit4189 = alloc_String("sys");
  }
// compilenode returning strlit4189
  params[0] = strlit4189;
  Object opresult4191 = callmethod(*var_nm, "==", 1, params);
// compilenode returning opresult4191
// Begin line 1175
  setline(1175);
// Begin line 1171
  setline(1171);
// compilenode returning *var_nm
  if (strlit4192 == NULL) {
    strlit4192 = alloc_String("io");
  }
// compilenode returning strlit4192
  params[0] = strlit4192;
  Object opresult4194 = callmethod(*var_nm, "==", 1, params);
// compilenode returning opresult4194
  params[0] = opresult4194;
  Object opresult4196 = callmethod(opresult4191, "|", 1, params);
// compilenode returning opresult4196
  Object if4188;
  if (istrue(opresult4196)) {
// Begin line 1173
  setline(1173);
// Begin line 1172
  setline(1172);
  Object bool4197 = alloc_Boolean(1);
// compilenode returning bool4197
  *var_exists = bool4197;
  if (bool4197 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1173
  setline(1173);
// compilenode returning *var_nm
// compilenode returning *var_staticmodules
  params[0] = *var_nm;
  Object call4199 = callmethod(*var_staticmodules, "push",
    1, params);
// compilenode returning call4199
    if4188 = call4199;
  } else {
  }
// compilenode returning if4188
// Begin line 1176
  setline(1176);
// Begin line 1178
  setline(1178);
// Begin line 1429
  setline(1429);
// Begin line 1175
  setline(1175);
// compilenode returning *var_exists
  Object call4201 = callmethod(*var_exists, "not",
    0, params);
// compilenode returning call4201
// compilenode returning call4201
  Object if4200;
  if (istrue(call4201)) {
// Begin line 1176
  setline(1176);
  if (strlit4202 == NULL) {
    strlit4202 = alloc_String("failed finding import of ");
  }
// compilenode returning strlit4202
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult4204 = callmethod(strlit4202, "++", 1, params);
// compilenode returning opresult4204
  if (strlit4205 == NULL) {
    strlit4205 = alloc_String(".");
  }
// compilenode returning strlit4205
  params[0] = strlit4205;
  Object opresult4207 = callmethod(opresult4204, "++", 1, params);
// compilenode returning opresult4207
// compilenode returning module_util
  params[0] = opresult4207;
  Object call4208 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call4208
    if4200 = call4208;
  } else {
  }
// compilenode returning if4200
    if4068 = if4200;
  } else {
  }
// compilenode returning if4068
  return if4068;
}
Object meth_genllvm29_apply4351(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_declaredvars = closure[0];
  Object self = *closure[1];
// Begin line 1240
  setline(1240);
// Begin line 1242
  setline(1242);
// Begin line 1429
  setline(1429);
// Begin line 1226
  setline(1226);
// compilenode returning *var_l
  Object call4353 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call4353
// compilenode returning call4353
  if (strlit4354 == NULL) {
    strlit4354 = alloc_String("vardec");
  }
// compilenode returning strlit4354
  params[0] = strlit4354;
  Object opresult4356 = callmethod(call4353, "==", 1, params);
// compilenode returning opresult4356
// Begin line 1242
  setline(1242);
// Begin line 1429
  setline(1429);
// Begin line 1226
  setline(1226);
// compilenode returning *var_l
  Object call4357 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call4357
// compilenode returning call4357
  if (strlit4358 == NULL) {
    strlit4358 = alloc_String("defdec");
  }
// compilenode returning strlit4358
  params[0] = strlit4358;
  Object opresult4360 = callmethod(call4357, "==", 1, params);
// compilenode returning opresult4360
  params[0] = opresult4360;
  Object opresult4362 = callmethod(opresult4356, "|", 1, params);
// compilenode returning opresult4362
  Object if4352;
  if (istrue(opresult4362)) {
  Object *var_tnm = alloc_var();
  *var_tnm = undefined;
// Begin line 1227
  setline(1227);
// Begin line 1429
  setline(1429);
// Begin line 1227
  setline(1227);
// Begin line 1429
  setline(1429);
// Begin line 1227
  setline(1227);
// Begin line 1429
  setline(1429);
// Begin line 1227
  setline(1227);
// compilenode returning *var_l
  Object call4363 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call4363
// compilenode returning call4363
  Object call4364 = callmethod(call4363, "value",
    0, params);
// compilenode returning call4364
// compilenode returning call4364
  Object call4365 = callmethod(call4364, "_escape",
    0, params);
// compilenode returning call4365
// compilenode returning call4365
  var_tnm = alloc_var();
  *var_tnm = call4365;
  if (call4365 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1228
  setline(1228);
// compilenode returning *var_tnm
// compilenode returning *var_declaredvars
  params[0] = *var_tnm;
  Object call4366 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call4366
// Begin line 1229
  setline(1229);
  if (strlit4367 == NULL) {
    strlit4367 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit4367
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult4369 = callmethod(strlit4367, "++", 1, params);
// compilenode returning opresult4369
  if (strlit4370 == NULL) {
    strlit4370 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit4370
  params[0] = strlit4370;
  Object opresult4372 = callmethod(opresult4369, "++", 1, params);
// compilenode returning opresult4372
// Begin line 1230
  setline(1230);
// compilenode returning self
  params[0] = opresult4372;
  Object call4373 = callmethod(self, "out",
    1, params);
// compilenode returning call4373
  if (strlit4374 == NULL) {
    strlit4374 = alloc_String("  store %object %undefined, %object* %""\x22""var_");
  }
// compilenode returning strlit4374
// compilenode returning *var_tnm
  params[0] = *var_tnm;
  Object opresult4376 = callmethod(strlit4374, "++", 1, params);
// compilenode returning opresult4376
  if (strlit4377 == NULL) {
    strlit4377 = alloc_String("""\x22""");
  }
// compilenode returning strlit4377
  params[0] = strlit4377;
  Object opresult4379 = callmethod(opresult4376, "++", 1, params);
// compilenode returning opresult4379
// Begin line 1231
  setline(1231);
// compilenode returning self
  params[0] = opresult4379;
  Object call4380 = callmethod(self, "out",
    1, params);
// compilenode returning call4380
    if4352 = call4380;
  } else {
// Begin line 1240
  setline(1240);
// Begin line 1242
  setline(1242);
// Begin line 1429
  setline(1429);
// Begin line 1231
  setline(1231);
// compilenode returning *var_l
  Object call4382 = callmethod(*var_l, "kind",
    0, params);
// compilenode returning call4382
// compilenode returning call4382
  if (strlit4383 == NULL) {
    strlit4383 = alloc_String("class");
  }
// compilenode returning strlit4383
  params[0] = strlit4383;
  Object opresult4385 = callmethod(call4382, "==", 1, params);
// compilenode returning opresult4385
  Object if4381;
  if (istrue(opresult4385)) {
  Object *var_tnmc = alloc_var();
  *var_tnmc = undefined;
// Begin line 1233
  setline(1233);
  var_tnmc = alloc_var();
  *var_tnmc = undefined;
// compilenode returning nothing
// Begin line 1236
  setline(1236);
// Begin line 1238
  setline(1238);
// Begin line 1429
  setline(1429);
// Begin line 1238
  setline(1238);
// Begin line 1429
  setline(1429);
// Begin line 1233
  setline(1233);
// compilenode returning *var_l
  Object call4387 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call4387
// compilenode returning call4387
  Object call4388 = callmethod(call4387, "kind",
    0, params);
// compilenode returning call4388
// compilenode returning call4388
  if (strlit4389 == NULL) {
    strlit4389 = alloc_String("generic");
  }
// compilenode returning strlit4389
  params[0] = strlit4389;
  Object opresult4391 = callmethod(call4388, "==", 1, params);
// compilenode returning opresult4391
  Object if4386;
  if (istrue(opresult4391)) {
// Begin line 1234
  setline(1234);
// Begin line 1429
  setline(1429);
// Begin line 1234
  setline(1234);
// Begin line 1429
  setline(1429);
// Begin line 1234
  setline(1234);
// Begin line 1429
  setline(1429);
// Begin line 1234
  setline(1234);
// Begin line 1429
  setline(1429);
// Begin line 1234
  setline(1234);
// compilenode returning *var_l
  Object call4392 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call4392
// compilenode returning call4392
  Object call4393 = callmethod(call4392, "value",
    0, params);
// compilenode returning call4393
// compilenode returning call4393
  Object call4394 = callmethod(call4393, "value",
    0, params);
// compilenode returning call4394
// compilenode returning call4394
  Object call4395 = callmethod(call4394, "_escape",
    0, params);
// compilenode returning call4395
// compilenode returning call4395
  *var_tnmc = call4395;
  if (call4395 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4386 = nothing;
  } else {
// Begin line 1236
  setline(1236);
// Begin line 1429
  setline(1429);
// Begin line 1236
  setline(1236);
// Begin line 1429
  setline(1429);
// Begin line 1236
  setline(1236);
// Begin line 1429
  setline(1429);
// Begin line 1236
  setline(1236);
// compilenode returning *var_l
  Object call4397 = callmethod(*var_l, "name",
    0, params);
// compilenode returning call4397
// compilenode returning call4397
  Object call4398 = callmethod(call4397, "value",
    0, params);
// compilenode returning call4398
// compilenode returning call4398
  Object call4399 = callmethod(call4398, "_escape",
    0, params);
// compilenode returning call4399
// compilenode returning call4399
  *var_tnmc = call4399;
  if (call4399 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4386 = nothing;
  }
// compilenode returning if4386
// Begin line 1238
  setline(1238);
// compilenode returning *var_tnmc
// compilenode returning *var_declaredvars
  params[0] = *var_tnmc;
  Object call4401 = callmethod(*var_declaredvars, "push",
    1, params);
// compilenode returning call4401
// Begin line 1239
  setline(1239);
  if (strlit4402 == NULL) {
    strlit4402 = alloc_String("  %""\x22""var_");
  }
// compilenode returning strlit4402
// compilenode returning *var_tnmc
  params[0] = *var_tnmc;
  Object opresult4404 = callmethod(strlit4402, "++", 1, params);
// compilenode returning opresult4404
  if (strlit4405 == NULL) {
    strlit4405 = alloc_String("""\x22"" = call %object* @alloc_var()");
  }
// compilenode returning strlit4405
  params[0] = strlit4405;
  Object opresult4407 = callmethod(opresult4404, "++", 1, params);
// compilenode returning opresult4407
// Begin line 1240
  setline(1240);
// compilenode returning self
  params[0] = opresult4407;
  Object call4408 = callmethod(self, "out",
    1, params);
// compilenode returning call4408
  if (strlit4409 == NULL) {
    strlit4409 = alloc_String("  store %object %undefined, %object* %""\x22""var_");
  }
// compilenode returning strlit4409
// compilenode returning *var_tnmc
  params[0] = *var_tnmc;
  Object opresult4411 = callmethod(strlit4409, "++", 1, params);
// compilenode returning opresult4411
  if (strlit4412 == NULL) {
    strlit4412 = alloc_String("""\x22""");
  }
// compilenode returning strlit4412
  params[0] = strlit4412;
  Object opresult4414 = callmethod(opresult4411, "++", 1, params);
// compilenode returning opresult4414
// Begin line 1241
  setline(1241);
// compilenode returning self
  params[0] = opresult4414;
  Object call4415 = callmethod(self, "out",
    1, params);
// compilenode returning call4415
    if4381 = call4415;
  } else {
  }
// compilenode returning if4381
    if4352 = if4381;
  }
// compilenode returning if4352
  return if4352;
}
Object meth_genllvm29_apply4421(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 1244
  setline(1244);
// compilenode returning *var_o
// Begin line 1245
  setline(1245);
// compilenode returning self
  params[0] = *var_o;
  Object call4422 = callmethod(self, "compilenode",
    1, params);
// compilenode returning call4422
  return call4422;
}
Object meth_genllvm29_apply4439(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 1250
  setline(1250);
  if (strlit4440 == NULL) {
    strlit4440 = alloc_String("  %params_");
  }
// compilenode returning strlit4440
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult4442 = callmethod(strlit4440, "++", 1, params);
// compilenode returning opresult4442
  if (strlit4443 == NULL) {
    strlit4443 = alloc_String(" = getelementptr %object* %params, i32 ");
  }
// compilenode returning strlit4443
  params[0] = strlit4443;
  Object opresult4445 = callmethod(opresult4442, "++", 1, params);
// compilenode returning opresult4445
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult4447 = callmethod(opresult4445, "++", 1, params);
// compilenode returning opresult4447
// Begin line 1251
  setline(1251);
// compilenode returning self
  params[0] = opresult4447;
  Object call4448 = callmethod(self, "out",
    1, params);
// compilenode returning call4448
  return call4448;
}
Object meth_genllvm29_apply4454(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 1253
  setline(1253);
// compilenode returning *var_l
// Begin line 1254
  setline(1254);
// compilenode returning self
  params[0] = *var_l;
  Object call4455 = callmethod(self, "out",
    1, params);
// compilenode returning call4455
  return call4455;
}
Object meth_genllvm29_apply4604(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 1310
  setline(1310);
// compilenode returning *var_c
// Begin line 1311
  setline(1311);
// compilenode returning self
  params[0] = *var_c;
  Object call4605 = callmethod(self, "out",
    1, params);
// compilenode returning call4605
  return call4605;
}
Object meth_genllvm29_apply4632(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m2 = alloc_var();
  *var_m2 = args[0];
  Object params[1];
  Object *var_smfirst = closure[0];
  Object self = *closure[1];
// Begin line 1321
  setline(1321);
// Begin line 1318
  setline(1318);
// compilenode returning *var_smfirst
  Object if4633;
  if (istrue(*var_smfirst)) {
// Begin line 1320
  setline(1320);
// Begin line 1319
  setline(1319);
  Object bool4634 = alloc_Boolean(0);
// compilenode returning bool4634
  *var_smfirst = bool4634;
  if (bool4634 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4633 = nothing;
  } else {
// Begin line 1321
  setline(1321);
  if (strlit4636 == NULL) {
    strlit4636 = alloc_String(",");
  }
// compilenode returning strlit4636
// Begin line 1322
  setline(1322);
// compilenode returning self
  params[0] = strlit4636;
  Object call4637 = callmethod(self, "out",
    1, params);
// compilenode returning call4637
    if4633 = call4637;
  }
// compilenode returning if4633
// Begin line 1326
  setline(1326);
// Begin line 1323
  setline(1323);
// compilenode returning *var_m2
  Object if4638;
  if (istrue(*var_m2)) {
// Begin line 1324
  setline(1324);
  if (strlit4639 == NULL) {
    strlit4639 = alloc_String("i1 1");
  }
// compilenode returning strlit4639
// Begin line 1325
  setline(1325);
// compilenode returning self
  params[0] = strlit4639;
  Object call4640 = callmethod(self, "out",
    1, params);
// compilenode returning call4640
    if4638 = call4640;
  } else {
// Begin line 1326
  setline(1326);
  if (strlit4641 == NULL) {
    strlit4641 = alloc_String("i1 0");
  }
// compilenode returning strlit4641
// Begin line 1327
  setline(1327);
// compilenode returning self
  params[0] = strlit4641;
  Object call4642 = callmethod(self, "out",
    1, params);
// compilenode returning call4642
    if4638 = call4642;
  }
// compilenode returning if4638
  return if4638;
}
Object meth_genllvm29_apply4627(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m1 = alloc_var();
  *var_m1 = args[0];
  Object params[1];
  Object *var_smfirst = closure[0];
  Object self = *closure[1];
// Begin line 1326
  setline(1326);
// Begin line 1317
  setline(1317);
// compilenode returning *var_m1
// Begin line 1326
  setline(1326);
// Begin line 1429
  setline(1429);
  Object obj4630 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4630, self, 0);
  addmethod2(obj4630, "outer", &reader_genllvm29_outer_4631);
  adddatum2(obj4630, self, 0);
  block_savedest(obj4630);
  Object **closure4632 = createclosure(2);
  addtoclosure(closure4632, var_smfirst);
  Object *selfpp4643 = alloc_var();
  *selfpp4643 = self;
  addtoclosure(closure4632, selfpp4643);
  struct UserObject *uo4632 = (struct UserObject*)obj4630;
  uo4632->data[1] = (Object)closure4632;
  addmethod2(obj4630, "apply", &meth_genllvm29_apply4632);
  set_type(obj4630, 0);
// compilenode returning obj4630
  setclassname(obj4630, "Block<genllvm29:4629>");
// compilenode returning obj4630
  params[0] = *var_m1;
  Object iter4628 = callmethod(*var_m1, "iter", 1, params);
  while(1) {
    Object cond4628 = callmethod(iter4628, "havemore", 0, NULL);
    if (!istrue(cond4628)) break;
    params[0] = callmethod(iter4628, "next", 0, NULL);
    callmethod(obj4630, "apply", 1, params);
  }
// compilenode returning *var_m1
  return *var_m1;
}
Object meth_genllvm29_apply4728(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 1359
  setline(1359);
  if (strlit4729 == NULL) {
    strlit4729 = alloc_String("declare void @set_type(%object, i16)");
  }
// compilenode returning strlit4729
// Begin line 1360
  setline(1360);
// compilenode returning self
  params[0] = strlit4729;
  Object call4730 = callmethod(self, "out",
    1, params);
// compilenode returning call4730
  return call4730;
}
Object meth_genllvm29_apply4735(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
  return nothing;
}
Object meth_genllvm29_apply4784(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = alloc_var();
  *var_x = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 1383
  setline(1383);
// compilenode returning *var_x
// Begin line 1384
  setline(1384);
// compilenode returning self
  params[0] = *var_x;
  Object call4785 = callmethod(self, "outprint",
    1, params);
// compilenode returning call4785
  return call4785;
}
Object meth_genllvm29_apply4840(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_fn = alloc_var();
  *var_fn = args[0];
  Object params[1];
  Object *var_cmd = closure[0];
  Object self = *closure[1];
// Begin line 1399
  setline(1399);
// Begin line 1398
  setline(1398);
// compilenode returning *var_cmd
  if (strlit4841 == NULL) {
    strlit4841 = alloc_String(" ");
  }
// compilenode returning strlit4841
  params[0] = strlit4841;
  Object opresult4843 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4843
// compilenode returning *var_fn
  params[0] = *var_fn;
  Object opresult4845 = callmethod(opresult4843, "++", 1, params);
// compilenode returning opresult4845
  *var_cmd = opresult4845;
  if (opresult4845 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_genllvm29_compile4047(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[29];
  Object *var_vl = alloc_var();
  *var_vl = args[0];
  Object *var_of = alloc_var();
  *var_of = args[1];
  Object *var_mn = alloc_var();
  *var_mn = args[2];
  Object *var_rm = alloc_var();
  *var_rm = args[3];
  Object *var_bt = alloc_var();
  *var_bt = args[4];
  Object *var_glpath = alloc_var();
  *var_glpath = args[5];
  Object params[2];
  Object *var_values = closure[0];
  Object *var_outfile = closure[1];
  Object *var_modname = closure[2];
  Object *var_runmode = closure[3];
  Object *var_buildtype = closure[4];
  Object *var_gracelibPath = closure[5];
  Object *var_staticmodules = closure[6];
  Object *var_constants = closure[7];
  Object *var_output = closure[8];
  Object *var_declaredvars = closure[9];
  Object *var_paramsUsed = closure[10];
  Object *var_argv = alloc_var();
  *var_argv = undefined;
  Object *var_cmd = alloc_var();
  *var_cmd = undefined;
  Object *var_linkfiles = alloc_var();
  *var_linkfiles = undefined;
  Object *var_ext = alloc_var();
  *var_ext = undefined;
  Object *var_modn = alloc_var();
  *var_modn = undefined;
  Object *var_con = alloc_var();
  *var_con = undefined;
  Object *var_tmpo = alloc_var();
  *var_tmpo = undefined;
  Object *var_tmpo2 = alloc_var();
  *var_tmpo2 = undefined;
  Object *var_mtx = alloc_var();
  *var_mtx = undefined;
  Object *var_smfirst = alloc_var();
  *var_smfirst = undefined;
// Begin line 1115
  setline(1115);
// Begin line 1429
  setline(1429);
// Begin line 1114
  setline(1114);
// compilenode returning module_sys
  Object call4048 = callmethod(module_sys, "argv",
    0, params);
// compilenode returning call4048
// compilenode returning call4048
  var_argv = alloc_var();
  *var_argv = call4048;
  if (call4048 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1116
  setline(1116);
  var_cmd = alloc_var();
  *var_cmd = undefined;
// compilenode returning nothing
// Begin line 1117
  setline(1117);
// Begin line 1116
  setline(1116);
// compilenode returning *var_vl
  *var_values = *var_vl;
  if (*var_vl == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1118
  setline(1118);
// Begin line 1117
  setline(1117);
// compilenode returning *var_of
  *var_outfile = *var_of;
  if (*var_of == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1119
  setline(1119);
// Begin line 1118
  setline(1118);
// compilenode returning *var_mn
  *var_modname = *var_mn;
  if (*var_mn == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1120
  setline(1120);
// Begin line 1119
  setline(1119);
// compilenode returning *var_rm
  *var_runmode = *var_rm;
  if (*var_rm == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1121
  setline(1121);
// Begin line 1120
  setline(1120);
// compilenode returning *var_bt
  *var_buildtype = *var_bt;
  if (*var_bt == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1122
  setline(1122);
// Begin line 1121
  setline(1121);
// compilenode returning *var_glpath
  *var_gracelibPath = *var_glpath;
  if (*var_glpath == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1123
  setline(1123);
  Object array4055 = alloc_List();
// compilenode returning array4055
  var_linkfiles = alloc_var();
  *var_linkfiles = array4055;
  if (array4055 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1124
  setline(1124);
// Begin line 1123
  setline(1123);
  Object bool4056 = alloc_Boolean(0);
// compilenode returning bool4056
  var_ext = alloc_var();
  *var_ext = bool4056;
  if (bool4056 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1176
  setline(1176);
// Begin line 1181
  setline(1181);
// Begin line 1124
  setline(1124);
// compilenode returning *var_runmode
  if (strlit4058 == NULL) {
    strlit4058 = alloc_String("make");
  }
// compilenode returning strlit4058
  params[0] = strlit4058;
  Object opresult4060 = callmethod(*var_runmode, "==", 1, params);
// compilenode returning opresult4060
  Object if4057;
  if (istrue(opresult4060)) {
// Begin line 1125
  setline(1125);
  if (strlit4061 == NULL) {
    strlit4061 = alloc_String("checking imports.");
  }
// compilenode returning strlit4061
// Begin line 1126
  setline(1126);
// compilenode returning self
  params[0] = strlit4061;
  Object call4062 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call4062
// Begin line 1176
  setline(1176);
// Begin line 1126
  setline(1126);
// compilenode returning *var_values
// Begin line 1176
  setline(1176);
// Begin line 1429
  setline(1429);
  Object obj4065 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4065, self, 0);
  addmethod2(obj4065, "outer", &reader_genllvm29_outer_4066);
  adddatum2(obj4065, self, 0);
  block_savedest(obj4065);
  Object **closure4067 = createclosure(7);
  addtoclosure(closure4067, var_buildtype);
  addtoclosure(closure4067, var_linkfiles);
  addtoclosure(closure4067, var_staticmodules);
  addtoclosure(closure4067, var_ext);
  addtoclosure(closure4067, var_argv);
  addtoclosure(closure4067, var_cmd);
  Object *selfpp4209 = alloc_var();
  *selfpp4209 = self;
  addtoclosure(closure4067, selfpp4209);
  struct UserObject *uo4067 = (struct UserObject*)obj4065;
  uo4067->data[1] = (Object)closure4067;
  addmethod2(obj4065, "apply", &meth_genllvm29_apply4067);
  set_type(obj4065, 0);
// compilenode returning obj4065
  setclassname(obj4065, "Block<genllvm29:4064>");
// compilenode returning obj4065
  params[0] = *var_values;
  Object iter4063 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond4063 = callmethod(iter4063, "havemore", 0, NULL);
    if (!istrue(cond4063)) break;
    params[0] = callmethod(iter4063, "next", 0, NULL);
    callmethod(obj4065, "apply", 1, params);
  }
// compilenode returning *var_values
    if4057 = *var_values;
  } else {
  }
// compilenode returning if4057
// Begin line 1181
  setline(1181);
  if (strlit4210 == NULL) {
    strlit4210 = alloc_String("@.str = private unnamed_addr constant [6 x i8] c""\x22""Hello\\00""\x22""");
  }
// compilenode returning strlit4210
// Begin line 1182
  setline(1182);
// compilenode returning self
  params[0] = strlit4210;
  Object call4211 = callmethod(self, "out",
    1, params);
// compilenode returning call4211
  if (strlit4212 == NULL) {
    strlit4212 = alloc_String("@.str._plus = private unnamed_addr constant [2 x i8] c""\x22""+\\00""\x22""");
  }
// compilenode returning strlit4212
// Begin line 1183
  setline(1183);
// compilenode returning self
  params[0] = strlit4212;
  Object call4213 = callmethod(self, "out",
    1, params);
// compilenode returning call4213
  if (strlit4214 == NULL) {
    strlit4214 = alloc_String("@.str._minus = private unnamed_addr constant [2 x i8] c""\x22""-\\00""\x22""");
  }
// compilenode returning strlit4214
// Begin line 1184
  setline(1184);
// compilenode returning self
  params[0] = strlit4214;
  Object call4215 = callmethod(self, "out",
    1, params);
// compilenode returning call4215
  if (strlit4216 == NULL) {
    strlit4216 = alloc_String("@.str._asterisk = private unnamed_addr constant [2 x i8] c""\x22""*\\00""\x22""");
  }
// compilenode returning strlit4216
// Begin line 1185
  setline(1185);
// compilenode returning self
  params[0] = strlit4216;
  Object call4217 = callmethod(self, "out",
    1, params);
// compilenode returning call4217
  if (strlit4218 == NULL) {
    strlit4218 = alloc_String("@.str._slash = private unnamed_addr constant [2 x i8] c""\x22""/\\00""\x22""");
  }
// compilenode returning strlit4218
// Begin line 1186
  setline(1186);
// compilenode returning self
  params[0] = strlit4218;
  Object call4219 = callmethod(self, "out",
    1, params);
// compilenode returning call4219
  if (strlit4220 == NULL) {
    strlit4220 = alloc_String("@.str._percent = private unnamed_addr constant [2 x i8] c""\x22""%\\00""\x22""");
  }
// compilenode returning strlit4220
// Begin line 1187
  setline(1187);
// compilenode returning self
  params[0] = strlit4220;
  Object call4221 = callmethod(self, "out",
    1, params);
// compilenode returning call4221
  if (strlit4222 == NULL) {
    strlit4222 = alloc_String("@.str._index = private unnamed_addr constant [3 x i8] c""\x22""[]\\00""\x22""");
  }
// compilenode returning strlit4222
// Begin line 1188
  setline(1188);
// compilenode returning self
  params[0] = strlit4222;
  Object call4223 = callmethod(self, "out",
    1, params);
// compilenode returning call4223
  if (strlit4224 == NULL) {
    strlit4224 = alloc_String("@.str._push = private unnamed_addr constant [5 x i8] c""\x22""push\\00""\x22""");
  }
// compilenode returning strlit4224
// Begin line 1189
  setline(1189);
// compilenode returning self
  params[0] = strlit4224;
  Object call4225 = callmethod(self, "out",
    1, params);
// compilenode returning call4225
  if (strlit4226 == NULL) {
    strlit4226 = alloc_String("@.str._iter = private unnamed_addr constant [5 x i8] c""\x22""iter\\00""\x22""");
  }
// compilenode returning strlit4226
// Begin line 1190
  setline(1190);
// compilenode returning self
  params[0] = strlit4226;
  Object call4227 = callmethod(self, "out",
    1, params);
// compilenode returning call4227
  if (strlit4228 == NULL) {
    strlit4228 = alloc_String("@.str._apply = private unnamed_addr constant [6 x i8] c""\x22""apply\\00""\x22""");
  }
// compilenode returning strlit4228
// Begin line 1191
  setline(1191);
// compilenode returning self
  params[0] = strlit4228;
  Object call4229 = callmethod(self, "out",
    1, params);
// compilenode returning call4229
  if (strlit4230 == NULL) {
    strlit4230 = alloc_String("@.str._havemore = private unnamed_addr constant [9 x i8] c""\x22""havemore\\00""\x22""");
  }
// compilenode returning strlit4230
// Begin line 1192
  setline(1192);
// compilenode returning self
  params[0] = strlit4230;
  Object call4231 = callmethod(self, "out",
    1, params);
// compilenode returning call4231
  if (strlit4232 == NULL) {
    strlit4232 = alloc_String("@.str._next = private unnamed_addr constant [5 x i8] c""\x22""next\\00""\x22""");
  }
// compilenode returning strlit4232
// Begin line 1193
  setline(1193);
// compilenode returning self
  params[0] = strlit4232;
  Object call4233 = callmethod(self, "out",
    1, params);
// compilenode returning call4233
  if (strlit4234 == NULL) {
    strlit4234 = alloc_String("@.str._assignment = private unnamed_addr constant [11 x i8] c""\x22""assignment\\00""\x22""");
  }
// compilenode returning strlit4234
// Begin line 1194
  setline(1194);
// compilenode returning self
  params[0] = strlit4234;
  Object call4235 = callmethod(self, "out",
    1, params);
// compilenode returning call4235
  if (strlit4236 == NULL) {
    strlit4236 = alloc_String("@.str.asString = private unnamed_addr constant [9 x i8] c""\x22""asString\\00""\x22""");
  }
// compilenode returning strlit4236
// Begin line 1195
  setline(1195);
// compilenode returning self
  params[0] = strlit4236;
  Object call4237 = callmethod(self, "out",
    1, params);
// compilenode returning call4237
// Begin line 1196
  setline(1196);
// Begin line 1195
  setline(1195);
  if (strlit4238 == NULL) {
    strlit4238 = alloc_String("@.str._compilerRevision = private unnamed_addr constant [41 x i8]");
  }
// compilenode returning strlit4238
// Begin line 1196
  setline(1196);
  if (strlit4239 == NULL) {
    strlit4239 = alloc_String("c""\x22""");
  }
// compilenode returning strlit4239
  params[0] = strlit4239;
  Object opresult4241 = callmethod(strlit4238, "++", 1, params);
// compilenode returning opresult4241
// Begin line 1429
  setline(1429);
// Begin line 1196
  setline(1196);
// compilenode returning module_buildinfo
  Object call4242 = callmethod(module_buildinfo, "gitrevision",
    0, params);
// compilenode returning call4242
// compilenode returning call4242
  params[0] = call4242;
  Object opresult4244 = callmethod(opresult4241, "++", 1, params);
// compilenode returning opresult4244
  if (strlit4245 == NULL) {
    strlit4245 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit4245
  params[0] = strlit4245;
  Object opresult4247 = callmethod(opresult4244, "++", 1, params);
// compilenode returning opresult4247
// Begin line 1197
  setline(1197);
// compilenode returning self
  params[0] = opresult4247;
  Object call4248 = callmethod(self, "out",
    1, params);
// compilenode returning call4248
  if (strlit4249 == NULL) {
    strlit4249 = alloc_String("@undefined = private global %object null");
  }
// compilenode returning strlit4249
// Begin line 1198
  setline(1198);
// compilenode returning self
  params[0] = strlit4249;
  Object call4250 = callmethod(self, "out",
    1, params);
// compilenode returning call4250
  if (strlit4251 == NULL) {
    strlit4251 = alloc_String("@nothing = private global %object null");
  }
// compilenode returning strlit4251
// Begin line 1199
  setline(1199);
// compilenode returning self
  params[0] = strlit4251;
  Object call4252 = callmethod(self, "out",
    1, params);
// compilenode returning call4252
  if (strlit4253 == NULL) {
    strlit4253 = alloc_String("@argv = private global %object null");
  }
// compilenode returning strlit4253
// Begin line 1200
  setline(1200);
// compilenode returning self
  params[0] = strlit4253;
  Object call4254 = callmethod(self, "out",
    1, params);
// compilenode returning call4254
  if (strlit4255 == NULL) {
    strlit4255 = alloc_String("%Method = type {i8*,i32,%object(%object,i32,%object*,i32)*}");
  }
// compilenode returning strlit4255
// Begin line 1201
  setline(1201);
// compilenode returning self
  params[0] = strlit4255;
  Object call4256 = callmethod(self, "outprint",
    1, params);
// compilenode returning call4256
  if (strlit4257 == NULL) {
    strlit4257 = alloc_String("%ClassData = type { i8*, %Method*, i32 }*");
  }
// compilenode returning strlit4257
// Begin line 1202
  setline(1202);
// compilenode returning self
  params[0] = strlit4257;
  Object call4258 = callmethod(self, "outprint",
    1, params);
// compilenode returning call4258
  if (strlit4259 == NULL) {
    strlit4259 = alloc_String("%object = type { i32, %ClassData, [0 x i8] }*");
  }
// compilenode returning strlit4259
// Begin line 1203
  setline(1203);
// compilenode returning self
  params[0] = strlit4259;
  Object call4260 = callmethod(self, "outprint",
    1, params);
// compilenode returning call4260
  if (strlit4261 == NULL) {
    strlit4261 = alloc_String("%UserObject = type { i32, i8*, i8*, [0 x %object] }");
  }
// compilenode returning strlit4261
// Begin line 1204
  setline(1204);
// compilenode returning self
  params[0] = strlit4261;
  Object call4262 = callmethod(self, "outprint",
    1, params);
// compilenode returning call4262
  if (strlit4263 == NULL) {
    strlit4263 = alloc_String("define %object @module_");
  }
// compilenode returning strlit4263
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4265 = callmethod(strlit4263, "++", 1, params);
// compilenode returning opresult4265
  if (strlit4266 == NULL) {
    strlit4266 = alloc_String("_init() {");
  }
// compilenode returning strlit4266
  params[0] = strlit4266;
  Object opresult4268 = callmethod(opresult4265, "++", 1, params);
// compilenode returning opresult4268
// Begin line 1205
  setline(1205);
// compilenode returning self
  params[0] = opresult4268;
  Object call4269 = callmethod(self, "out",
    1, params);
// compilenode returning call4269
  if (strlit4270 == NULL) {
    strlit4270 = alloc_String("entry:");
  }
// compilenode returning strlit4270
// Begin line 1206
  setline(1206);
// compilenode returning self
  params[0] = strlit4270;
  Object call4271 = callmethod(self, "out",
    1, params);
// compilenode returning call4271
  if (strlit4272 == NULL) {
    strlit4272 = alloc_String("  %self = call %object @alloc_obj2(i32 100, i32 100)");
  }
// compilenode returning strlit4272
// Begin line 1207
  setline(1207);
// compilenode returning self
  params[0] = strlit4272;
  Object call4273 = callmethod(self, "out",
    1, params);
// compilenode returning call4273
// Begin line 1208
  setline(1208);
// Begin line 1207
  setline(1207);
  if (strlit4274 == NULL) {
    strlit4274 = alloc_String("Module<");
  }
// compilenode returning strlit4274
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4276 = callmethod(strlit4274, "++", 1, params);
// compilenode returning opresult4276
  if (strlit4277 == NULL) {
    strlit4277 = alloc_String(">");
  }
// compilenode returning strlit4277
  params[0] = strlit4277;
  Object opresult4279 = callmethod(opresult4276, "++", 1, params);
// compilenode returning opresult4279
  var_modn = alloc_var();
  *var_modn = opresult4279;
  if (opresult4279 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1210
  setline(1210);
// Begin line 1208
  setline(1208);
  if (strlit4280 == NULL) {
    strlit4280 = alloc_String("@""\x22"".str._modcname_");
  }
// compilenode returning strlit4280
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4282 = callmethod(strlit4280, "++", 1, params);
// compilenode returning opresult4282
  if (strlit4283 == NULL) {
    strlit4283 = alloc_String("""\x22"" = private unnamed_addr ");
  }
// compilenode returning strlit4283
  params[0] = strlit4283;
  Object opresult4285 = callmethod(opresult4282, "++", 1, params);
// compilenode returning opresult4285
// Begin line 1210
  setline(1210);
// Begin line 1209
  setline(1209);
  if (strlit4286 == NULL) {
    strlit4286 = alloc_String("constant [");
  }
// compilenode returning strlit4286
// Begin line 1210
  setline(1210);
// Begin line 1429
  setline(1429);
// Begin line 1209
  setline(1209);
// compilenode returning *var_modn
  Object call4287 = callmethod(*var_modn, "size",
    0, params);
// compilenode returning call4287
// compilenode returning call4287
  Object num4288 = alloc_Float64(1.0);
// compilenode returning num4288
  params[0] = num4288;
  Object sum4290 = callmethod(call4287, "+", 1, params);
// compilenode returning sum4290
  params[0] = sum4290;
  Object opresult4292 = callmethod(strlit4286, "++", 1, params);
// compilenode returning opresult4292
  if (strlit4293 == NULL) {
    strlit4293 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit4293
  params[0] = strlit4293;
  Object opresult4295 = callmethod(opresult4292, "++", 1, params);
// compilenode returning opresult4295
// compilenode returning *var_modn
  params[0] = *var_modn;
  Object opresult4297 = callmethod(opresult4295, "++", 1, params);
// compilenode returning opresult4297
  if (strlit4298 == NULL) {
    strlit4298 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit4298
  params[0] = strlit4298;
  Object opresult4300 = callmethod(opresult4297, "++", 1, params);
// compilenode returning opresult4300
  params[0] = opresult4300;
  Object opresult4302 = callmethod(opresult4285, "++", 1, params);
// compilenode returning opresult4302
  var_con = alloc_var();
  *var_con = opresult4302;
  if (opresult4302 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1210
  setline(1210);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call4303 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call4303
// Begin line 1214
  setline(1214);
// Begin line 1211
  setline(1211);
  if (strlit4304 == NULL) {
    strlit4304 = alloc_String("  call void @setclassname(%object %self, ");
  }
// compilenode returning strlit4304
// Begin line 1214
  setline(1214);
// Begin line 1212
  setline(1212);
  if (strlit4305 == NULL) {
    strlit4305 = alloc_String("i8* getelementptr([");
  }
// compilenode returning strlit4305
// Begin line 1214
  setline(1214);
// Begin line 1429
  setline(1429);
// Begin line 1212
  setline(1212);
// compilenode returning *var_modn
  Object call4306 = callmethod(*var_modn, "size",
    0, params);
// compilenode returning call4306
// compilenode returning call4306
  Object num4307 = alloc_Float64(1.0);
// compilenode returning num4307
  params[0] = num4307;
  Object sum4309 = callmethod(call4306, "+", 1, params);
// compilenode returning sum4309
  params[0] = sum4309;
  Object opresult4311 = callmethod(strlit4305, "++", 1, params);
// compilenode returning opresult4311
  if (strlit4312 == NULL) {
    strlit4312 = alloc_String(" x i8]* ");
  }
// compilenode returning strlit4312
  params[0] = strlit4312;
  Object opresult4314 = callmethod(opresult4311, "++", 1, params);
// compilenode returning opresult4314
  params[0] = opresult4314;
  Object opresult4316 = callmethod(strlit4304, "++", 1, params);
// compilenode returning opresult4316
// Begin line 1214
  setline(1214);
// Begin line 1213
  setline(1213);
  if (strlit4317 == NULL) {
    strlit4317 = alloc_String("@""\x22"".str._modcname_");
  }
// compilenode returning strlit4317
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4319 = callmethod(strlit4317, "++", 1, params);
// compilenode returning opresult4319
  if (strlit4320 == NULL) {
    strlit4320 = alloc_String("""\x22"",");
  }
// compilenode returning strlit4320
  params[0] = strlit4320;
  Object opresult4322 = callmethod(opresult4319, "++", 1, params);
// compilenode returning opresult4322
  params[0] = opresult4322;
  Object opresult4324 = callmethod(opresult4316, "++", 1, params);
// compilenode returning opresult4324
// Begin line 1214
  setline(1214);
  if (strlit4325 == NULL) {
    strlit4325 = alloc_String("i32 0,i32 0))");
  }
// compilenode returning strlit4325
  params[0] = strlit4325;
  Object opresult4327 = callmethod(opresult4324, "++", 1, params);
// compilenode returning opresult4327
// Begin line 1215
  setline(1215);
// compilenode returning self
  params[0] = opresult4327;
  Object call4328 = callmethod(self, "out",
    1, params);
// compilenode returning call4328
  if (strlit4329 == NULL) {
    strlit4329 = alloc_String("  %undefined = load %object* @undefined");
  }
// compilenode returning strlit4329
// Begin line 1216
  setline(1216);
// compilenode returning self
  params[0] = strlit4329;
  Object call4330 = callmethod(self, "out",
    1, params);
// compilenode returning call4330
  if (strlit4331 == NULL) {
    strlit4331 = alloc_String("  %nothing = load %object* @nothing");
  }
// compilenode returning strlit4331
// Begin line 1217
  setline(1217);
// compilenode returning self
  params[0] = strlit4331;
  Object call4332 = callmethod(self, "out",
    1, params);
// compilenode returning call4332
  if (strlit4333 == NULL) {
    strlit4333 = alloc_String("  %var_argv = call %object* @alloc_var()");
  }
// compilenode returning strlit4333
// Begin line 1218
  setline(1218);
// compilenode returning self
  params[0] = strlit4333;
  Object call4334 = callmethod(self, "out",
    1, params);
// compilenode returning call4334
  if (strlit4335 == NULL) {
    strlit4335 = alloc_String("  %tmp_argv = load %object* @argv");
  }
// compilenode returning strlit4335
// Begin line 1219
  setline(1219);
// compilenode returning self
  params[0] = strlit4335;
  Object call4336 = callmethod(self, "out",
    1, params);
// compilenode returning call4336
  if (strlit4337 == NULL) {
    strlit4337 = alloc_String("  store %object %tmp_argv, %object* %var_argv");
  }
// compilenode returning strlit4337
// Begin line 1220
  setline(1220);
// compilenode returning self
  params[0] = strlit4337;
  Object call4338 = callmethod(self, "out",
    1, params);
// compilenode returning call4338
  if (strlit4339 == NULL) {
    strlit4339 = alloc_String("  %var_HashMap = call %object* @alloc_var()");
  }
// compilenode returning strlit4339
// Begin line 1221
  setline(1221);
// compilenode returning self
  params[0] = strlit4339;
  Object call4340 = callmethod(self, "out",
    1, params);
// compilenode returning call4340
  if (strlit4341 == NULL) {
    strlit4341 = alloc_String("  %tmp_hmco = call %object @alloc_HashMapClassObject()");
  }
// compilenode returning strlit4341
// Begin line 1222
  setline(1222);
// compilenode returning self
  params[0] = strlit4341;
  Object call4342 = callmethod(self, "out",
    1, params);
// compilenode returning call4342
  if (strlit4343 == NULL) {
    strlit4343 = alloc_String("  store %object %tmp_hmco, %object* %var_HashMap");
  }
// compilenode returning strlit4343
// Begin line 1223
  setline(1223);
// compilenode returning self
  params[0] = strlit4343;
  Object call4344 = callmethod(self, "out",
    1, params);
// compilenode returning call4344
// Begin line 1224
  setline(1224);
// Begin line 1223
  setline(1223);
// compilenode returning *var_output
  var_tmpo = alloc_var();
  *var_tmpo = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1225
  setline(1225);
  Object array4345 = alloc_List();
// compilenode returning array4345
  *var_output = array4345;
  if (array4345 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1240
  setline(1240);
// Begin line 1225
  setline(1225);
// compilenode returning *var_values
// Begin line 1240
  setline(1240);
// Begin line 1429
  setline(1429);
  Object obj4349 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4349, self, 0);
  addmethod2(obj4349, "outer", &reader_genllvm29_outer_4350);
  adddatum2(obj4349, self, 0);
  block_savedest(obj4349);
  Object **closure4351 = createclosure(2);
  addtoclosure(closure4351, var_declaredvars);
  Object *selfpp4416 = alloc_var();
  *selfpp4416 = self;
  addtoclosure(closure4351, selfpp4416);
  struct UserObject *uo4351 = (struct UserObject*)obj4349;
  uo4351->data[1] = (Object)closure4351;
  addmethod2(obj4349, "apply", &meth_genllvm29_apply4351);
  set_type(obj4349, 0);
// compilenode returning obj4349
  setclassname(obj4349, "Block<genllvm29:4348>");
// compilenode returning obj4349
  params[0] = *var_values;
  Object iter4347 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond4347 = callmethod(iter4347, "havemore", 0, NULL);
    if (!istrue(cond4347)) break;
    params[0] = callmethod(iter4347, "next", 0, NULL);
    callmethod(obj4349, "apply", 1, params);
  }
// compilenode returning *var_values
// Begin line 1244
  setline(1244);
// Begin line 1243
  setline(1243);
// compilenode returning *var_values
// Begin line 1244
  setline(1244);
// Begin line 1429
  setline(1429);
  Object obj4419 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4419, self, 0);
  addmethod2(obj4419, "outer", &reader_genllvm29_outer_4420);
  adddatum2(obj4419, self, 0);
  block_savedest(obj4419);
  Object **closure4421 = createclosure(1);
  Object *selfpp4423 = alloc_var();
  *selfpp4423 = self;
  addtoclosure(closure4421, selfpp4423);
  struct UserObject *uo4421 = (struct UserObject*)obj4419;
  uo4421->data[1] = (Object)closure4421;
  addmethod2(obj4419, "apply", &meth_genllvm29_apply4421);
  set_type(obj4419, 0);
// compilenode returning obj4419
  setclassname(obj4419, "Block<genllvm29:4418>");
// compilenode returning obj4419
  params[0] = *var_values;
  Object iter4417 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond4417 = callmethod(iter4417, "havemore", 0, NULL);
    if (!istrue(cond4417)) break;
    params[0] = callmethod(iter4417, "next", 0, NULL);
    callmethod(obj4419, "apply", 1, params);
  }
// compilenode returning *var_values
// Begin line 1247
  setline(1247);
// Begin line 1246
  setline(1246);
// compilenode returning *var_output
  var_tmpo2 = alloc_var();
  *var_tmpo2 = *var_output;
  if (*var_output == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1248
  setline(1248);
// Begin line 1247
  setline(1247);
// compilenode returning *var_tmpo
  *var_output = *var_tmpo;
  if (*var_tmpo == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1248
  setline(1248);
  if (strlit4425 == NULL) {
    strlit4425 = alloc_String("  %params = alloca %object, i32 ");
  }
// compilenode returning strlit4425
// compilenode returning *var_paramsUsed
  params[0] = *var_paramsUsed;
  Object opresult4427 = callmethod(strlit4425, "++", 1, params);
// compilenode returning opresult4427
// Begin line 1249
  setline(1249);
// compilenode returning self
  params[0] = opresult4427;
  Object call4428 = callmethod(self, "out",
    1, params);
// compilenode returning call4428
// Begin line 1250
  setline(1250);
// Begin line 1252
  setline(1252);
// Begin line 1249
  setline(1249);
  Object num4430 = alloc_Float64(0.0);
// compilenode returning num4430
// Begin line 1252
  setline(1252);
// Begin line 1249
  setline(1249);
// compilenode returning *var_paramsUsed
  Object num4431 = alloc_Float64(1.0);
// compilenode returning num4431
  params[0] = num4431;
  Object diff4433 = callmethod(*var_paramsUsed, "-", 1, params);
// compilenode returning diff4433
  params[0] = diff4433;
  Object opresult4435 = callmethod(num4430, "..", 1, params);
// compilenode returning opresult4435
// Begin line 1250
  setline(1250);
// Begin line 1429
  setline(1429);
  Object obj4437 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4437, self, 0);
  addmethod2(obj4437, "outer", &reader_genllvm29_outer_4438);
  adddatum2(obj4437, self, 0);
  block_savedest(obj4437);
  Object **closure4439 = createclosure(1);
  Object *selfpp4449 = alloc_var();
  *selfpp4449 = self;
  addtoclosure(closure4439, selfpp4449);
  struct UserObject *uo4439 = (struct UserObject*)obj4437;
  uo4439->data[1] = (Object)closure4439;
  addmethod2(obj4437, "apply", &meth_genllvm29_apply4439);
  set_type(obj4437, 0);
// compilenode returning obj4437
  setclassname(obj4437, "Block<genllvm29:4436>");
// compilenode returning obj4437
  params[0] = opresult4435;
  Object iter4429 = callmethod(opresult4435, "iter", 1, params);
  while(1) {
    Object cond4429 = callmethod(iter4429, "havemore", 0, NULL);
    if (!istrue(cond4429)) break;
    params[0] = callmethod(iter4429, "next", 0, NULL);
    callmethod(obj4437, "apply", 1, params);
  }
// compilenode returning opresult4435
// Begin line 1253
  setline(1253);
// Begin line 1252
  setline(1252);
// compilenode returning *var_tmpo2
// Begin line 1253
  setline(1253);
// Begin line 1429
  setline(1429);
  Object obj4452 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4452, self, 0);
  addmethod2(obj4452, "outer", &reader_genllvm29_outer_4453);
  adddatum2(obj4452, self, 0);
  block_savedest(obj4452);
  Object **closure4454 = createclosure(1);
  Object *selfpp4456 = alloc_var();
  *selfpp4456 = self;
  addtoclosure(closure4454, selfpp4456);
  struct UserObject *uo4454 = (struct UserObject*)obj4452;
  uo4454->data[1] = (Object)closure4454;
  addmethod2(obj4452, "apply", &meth_genllvm29_apply4454);
  set_type(obj4452, 0);
// compilenode returning obj4452
  setclassname(obj4452, "Block<genllvm29:4451>");
// compilenode returning obj4452
  params[0] = *var_tmpo2;
  Object iter4450 = callmethod(*var_tmpo2, "iter", 1, params);
  while(1) {
    Object cond4450 = callmethod(iter4450, "havemore", 0, NULL);
    if (!istrue(cond4450)) break;
    params[0] = callmethod(iter4450, "next", 0, NULL);
    callmethod(obj4452, "apply", 1, params);
  }
// compilenode returning *var_tmpo2
// Begin line 1256
  setline(1256);
// Begin line 1255
  setline(1255);
  Object num4457 = alloc_Float64(1.0);
// compilenode returning num4457
  *var_paramsUsed = num4457;
  if (num4457 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1256
  setline(1256);
  if (strlit4459 == NULL) {
    strlit4459 = alloc_String("  ret %object %self");
  }
// compilenode returning strlit4459
// Begin line 1257
  setline(1257);
// compilenode returning self
  params[0] = strlit4459;
  Object call4460 = callmethod(self, "out",
    1, params);
// compilenode returning call4460
  if (strlit4461 == NULL) {
    strlit4461 = alloc_String("}");
  }
// compilenode returning strlit4461
// Begin line 1258
  setline(1258);
// compilenode returning self
  params[0] = strlit4461;
  Object call4462 = callmethod(self, "out",
    1, params);
// compilenode returning call4462
  if (strlit4463 == NULL) {
    strlit4463 = alloc_String("define weak i32 @main(i32 %argc, i8** %argv) {");
  }
// compilenode returning strlit4463
// Begin line 1259
  setline(1259);
// compilenode returning self
  params[0] = strlit4463;
  Object call4464 = callmethod(self, "out",
    1, params);
// compilenode returning call4464
  if (strlit4465 == NULL) {
    strlit4465 = alloc_String("entry:");
  }
// compilenode returning strlit4465
// Begin line 1260
  setline(1260);
// compilenode returning self
  params[0] = strlit4465;
  Object call4466 = callmethod(self, "out",
    1, params);
// compilenode returning call4466
  if (strlit4467 == NULL) {
    strlit4467 = alloc_String("  call void @initprofiling()");
  }
// compilenode returning strlit4467
// Begin line 1261
  setline(1261);
// compilenode returning self
  params[0] = strlit4467;
  Object call4468 = callmethod(self, "out",
    1, params);
// compilenode returning call4468
// Begin line 1269
  setline(1269);
// Begin line 1261
  setline(1261);
  if (strlit4470 == NULL) {
    strlit4470 = alloc_String("LogCallGraph");
  }
// compilenode returning strlit4470
// Begin line 1271
  setline(1271);
// Begin line 1429
  setline(1429);
// Begin line 1261
  setline(1261);
// compilenode returning module_util
  Object call4471 = callmethod(module_util, "extensions",
    0, params);
// compilenode returning call4471
// compilenode returning call4471
  params[0] = strlit4470;
  Object call4472 = callmethod(call4471, "contains",
    1, params);
// compilenode returning call4472
  Object if4469;
  if (istrue(call4472)) {
  Object *var_lcgfile = alloc_var();
  *var_lcgfile = undefined;
// Begin line 1262
  setline(1262);
  if (strlit4473 == NULL) {
    strlit4473 = alloc_String("LogCallGraph");
  }
// compilenode returning strlit4473
// Begin line 1263
  setline(1263);
// Begin line 1429
  setline(1429);
// Begin line 1262
  setline(1262);
// compilenode returning module_util
  Object call4474 = callmethod(module_util, "extensions",
    0, params);
// compilenode returning call4474
// compilenode returning call4474
  params[0] = strlit4473;
  Object call4475 = callmethod(call4474, "get",
    1, params);
// compilenode returning call4475
  var_lcgfile = alloc_var();
  *var_lcgfile = call4475;
  if (call4475 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1265
  setline(1265);
// Begin line 1263
  setline(1263);
  if (strlit4476 == NULL) {
    strlit4476 = alloc_String("@.str.logdest = private unnamed_addr ");
  }
// compilenode returning strlit4476
// Begin line 1265
  setline(1265);
// Begin line 1264
  setline(1264);
  if (strlit4477 == NULL) {
    strlit4477 = alloc_String("constant [");
  }
// compilenode returning strlit4477
// Begin line 1265
  setline(1265);
// Begin line 1429
  setline(1429);
// Begin line 1264
  setline(1264);
// compilenode returning *var_lcgfile
  Object call4478 = callmethod(*var_lcgfile, "size",
    0, params);
// compilenode returning call4478
// compilenode returning call4478
  Object num4479 = alloc_Float64(1.0);
// compilenode returning num4479
  params[0] = num4479;
  Object sum4481 = callmethod(call4478, "+", 1, params);
// compilenode returning sum4481
  params[0] = sum4481;
  Object opresult4483 = callmethod(strlit4477, "++", 1, params);
// compilenode returning opresult4483
  if (strlit4484 == NULL) {
    strlit4484 = alloc_String(" x i8] c""\x22""");
  }
// compilenode returning strlit4484
  params[0] = strlit4484;
  Object opresult4486 = callmethod(opresult4483, "++", 1, params);
// compilenode returning opresult4486
// compilenode returning *var_lcgfile
  params[0] = *var_lcgfile;
  Object opresult4488 = callmethod(opresult4486, "++", 1, params);
// compilenode returning opresult4488
  if (strlit4489 == NULL) {
    strlit4489 = alloc_String("\\00""\x22""");
  }
// compilenode returning strlit4489
  params[0] = strlit4489;
  Object opresult4491 = callmethod(opresult4488, "++", 1, params);
// compilenode returning opresult4491
  params[0] = opresult4491;
  Object opresult4493 = callmethod(strlit4476, "++", 1, params);
// compilenode returning opresult4493
  *var_con = opresult4493;
  if (opresult4493 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1265
  setline(1265);
// compilenode returning *var_con
// compilenode returning *var_constants
  params[0] = *var_con;
  Object call4495 = callmethod(*var_constants, "push",
    1, params);
// compilenode returning call4495
// Begin line 1269
  setline(1269);
// Begin line 1266
  setline(1266);
  if (strlit4496 == NULL) {
    strlit4496 = alloc_String("  call void @enable_callgraph(");
  }
// compilenode returning strlit4496
// Begin line 1269
  setline(1269);
// Begin line 1267
  setline(1267);
  if (strlit4497 == NULL) {
    strlit4497 = alloc_String("i8* getelementptr([");
  }
// compilenode returning strlit4497
// Begin line 1269
  setline(1269);
// Begin line 1429
  setline(1429);
// Begin line 1267
  setline(1267);
// compilenode returning *var_lcgfile
  Object call4498 = callmethod(*var_lcgfile, "size",
    0, params);
// compilenode returning call4498
// compilenode returning call4498
  Object num4499 = alloc_Float64(1.0);
// compilenode returning num4499
  params[0] = num4499;
  Object sum4501 = callmethod(call4498, "+", 1, params);
// compilenode returning sum4501
  params[0] = sum4501;
  Object opresult4503 = callmethod(strlit4497, "++", 1, params);
// compilenode returning opresult4503
  if (strlit4504 == NULL) {
    strlit4504 = alloc_String(" x i8]* ");
  }
// compilenode returning strlit4504
  params[0] = strlit4504;
  Object opresult4506 = callmethod(opresult4503, "++", 1, params);
// compilenode returning opresult4506
  params[0] = opresult4506;
  Object opresult4508 = callmethod(strlit4496, "++", 1, params);
// compilenode returning opresult4508
// Begin line 1268
  setline(1268);
  if (strlit4509 == NULL) {
    strlit4509 = alloc_String("@.str.logdest,");
  }
// compilenode returning strlit4509
  params[0] = strlit4509;
  Object opresult4511 = callmethod(opresult4508, "++", 1, params);
// compilenode returning opresult4511
// Begin line 1269
  setline(1269);
  if (strlit4512 == NULL) {
    strlit4512 = alloc_String("i32 0,i32 0))");
  }
// compilenode returning strlit4512
  params[0] = strlit4512;
  Object opresult4514 = callmethod(opresult4511, "++", 1, params);
// compilenode returning opresult4514
// Begin line 1270
  setline(1270);
// compilenode returning self
  params[0] = opresult4514;
  Object call4515 = callmethod(self, "out",
    1, params);
// compilenode returning call4515
    if4469 = call4515;
  } else {
  }
// compilenode returning if4469
// Begin line 1271
  setline(1271);
  if (strlit4516 == NULL) {
    strlit4516 = alloc_String("  call void @gracelib_argv(i8** %argv)");
  }
// compilenode returning strlit4516
// Begin line 1272
  setline(1272);
// compilenode returning self
  params[0] = strlit4516;
  Object call4517 = callmethod(self, "out",
    1, params);
// compilenode returning call4517
  if (strlit4518 == NULL) {
    strlit4518 = alloc_String("  %params = alloca %object, i32 1");
  }
// compilenode returning strlit4518
// Begin line 1273
  setline(1273);
// compilenode returning self
  params[0] = strlit4518;
  Object call4519 = callmethod(self, "out",
    1, params);
// compilenode returning call4519
  if (strlit4520 == NULL) {
    strlit4520 = alloc_String("  %params_0 = getelementptr %object* %params, i32 0");
  }
// compilenode returning strlit4520
// Begin line 1274
  setline(1274);
// compilenode returning self
  params[0] = strlit4520;
  Object call4521 = callmethod(self, "out",
    1, params);
// compilenode returning call4521
  if (strlit4522 == NULL) {
    strlit4522 = alloc_String("  %undefined = call %object @alloc_Undefined()");
  }
// compilenode returning strlit4522
// Begin line 1275
  setline(1275);
// compilenode returning self
  params[0] = strlit4522;
  Object call4523 = callmethod(self, "out",
    1, params);
// compilenode returning call4523
  if (strlit4524 == NULL) {
    strlit4524 = alloc_String("  store %object %undefined, %object* @undefined");
  }
// compilenode returning strlit4524
// Begin line 1276
  setline(1276);
// compilenode returning self
  params[0] = strlit4524;
  Object call4525 = callmethod(self, "out",
    1, params);
// compilenode returning call4525
  if (strlit4526 == NULL) {
    strlit4526 = alloc_String("  %nothing = call %object @alloc_Nothing()");
  }
// compilenode returning strlit4526
// Begin line 1277
  setline(1277);
// compilenode returning self
  params[0] = strlit4526;
  Object call4527 = callmethod(self, "out",
    1, params);
// compilenode returning call4527
  if (strlit4528 == NULL) {
    strlit4528 = alloc_String("  store %object %nothing, %object* @nothing");
  }
// compilenode returning strlit4528
// Begin line 1278
  setline(1278);
// compilenode returning self
  params[0] = strlit4528;
  Object call4529 = callmethod(self, "out",
    1, params);
// compilenode returning call4529
  if (strlit4530 == NULL) {
    strlit4530 = alloc_String("  %tmp_argv = call %object @alloc_List()");
  }
// compilenode returning strlit4530
// Begin line 1279
  setline(1279);
// compilenode returning self
  params[0] = strlit4530;
  Object call4531 = callmethod(self, "out",
    1, params);
// compilenode returning call4531
  if (strlit4532 == NULL) {
    strlit4532 = alloc_String("  %argv_i = alloca i32");
  }
// compilenode returning strlit4532
// Begin line 1280
  setline(1280);
// compilenode returning self
  params[0] = strlit4532;
  Object call4533 = callmethod(self, "out",
    1, params);
// compilenode returning call4533
  if (strlit4534 == NULL) {
    strlit4534 = alloc_String("  store i32 0, i32* %argv_i");
  }
// compilenode returning strlit4534
// Begin line 1281
  setline(1281);
// compilenode returning self
  params[0] = strlit4534;
  Object call4535 = callmethod(self, "out",
    1, params);
// compilenode returning call4535
  if (strlit4536 == NULL) {
    strlit4536 = alloc_String("  br label %argv.cond");
  }
// compilenode returning strlit4536
// Begin line 1282
  setline(1282);
// compilenode returning self
  params[0] = strlit4536;
  Object call4537 = callmethod(self, "out",
    1, params);
// compilenode returning call4537
  if (strlit4538 == NULL) {
    strlit4538 = alloc_String("argv.cond");
  }
// compilenode returning strlit4538
// Begin line 1283
  setline(1283);
// compilenode returning self
  params[0] = strlit4538;
  Object call4539 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call4539
  if (strlit4540 == NULL) {
    strlit4540 = alloc_String("  %argv_tmp1 = load i32* %argv_i, align 4");
  }
// compilenode returning strlit4540
// Begin line 1284
  setline(1284);
// compilenode returning self
  params[0] = strlit4540;
  Object call4541 = callmethod(self, "out",
    1, params);
// compilenode returning call4541
  if (strlit4542 == NULL) {
    strlit4542 = alloc_String("  %argv_cmp = icmp slt i32 %argv_tmp1, %argc");
  }
// compilenode returning strlit4542
// Begin line 1285
  setline(1285);
// compilenode returning self
  params[0] = strlit4542;
  Object call4543 = callmethod(self, "out",
    1, params);
// compilenode returning call4543
  if (strlit4544 == NULL) {
    strlit4544 = alloc_String("  br i1 %argv_cmp, label %argv.body, label %argv.end");
  }
// compilenode returning strlit4544
// Begin line 1286
  setline(1286);
// compilenode returning self
  params[0] = strlit4544;
  Object call4545 = callmethod(self, "out",
    1, params);
// compilenode returning call4545
  if (strlit4546 == NULL) {
    strlit4546 = alloc_String("argv.body");
  }
// compilenode returning strlit4546
// Begin line 1287
  setline(1287);
// compilenode returning self
  params[0] = strlit4546;
  Object call4547 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call4547
  if (strlit4548 == NULL) {
    strlit4548 = alloc_String("  %argv_iv = load i32* %argv_i");
  }
// compilenode returning strlit4548
// Begin line 1288
  setline(1288);
// compilenode returning self
  params[0] = strlit4548;
  Object call4549 = callmethod(self, "out",
    1, params);
// compilenode returning call4549
  if (strlit4550 == NULL) {
    strlit4550 = alloc_String("  %argv_idx = getelementptr i8** %argv, i32 %argv_iv");
  }
// compilenode returning strlit4550
// Begin line 1289
  setline(1289);
// compilenode returning self
  params[0] = strlit4550;
  Object call4551 = callmethod(self, "out",
    1, params);
// compilenode returning call4551
  if (strlit4552 == NULL) {
    strlit4552 = alloc_String("  %argv_val = load i8** %argv_idx");
  }
// compilenode returning strlit4552
// Begin line 1290
  setline(1290);
// compilenode returning self
  params[0] = strlit4552;
  Object call4553 = callmethod(self, "out",
    1, params);
// compilenode returning call4553
  if (strlit4554 == NULL) {
    strlit4554 = alloc_String("  %argv_tmp3 = call %object @alloc_String(i8* %argv_val)");
  }
// compilenode returning strlit4554
// Begin line 1291
  setline(1291);
// compilenode returning self
  params[0] = strlit4554;
  Object call4555 = callmethod(self, "out",
    1, params);
// compilenode returning call4555
  if (strlit4556 == NULL) {
    strlit4556 = alloc_String("  store %object %argv_tmp3, %object* %params_0");
  }
// compilenode returning strlit4556
// Begin line 1292
  setline(1292);
// compilenode returning self
  params[0] = strlit4556;
  Object call4557 = callmethod(self, "out",
    1, params);
// compilenode returning call4557
// Begin line 1295
  setline(1295);
// Begin line 1292
  setline(1292);
  if (strlit4558 == NULL) {
    strlit4558 = alloc_String("  call %object @callmethod(%object %tmp_argv, ");
  }
// compilenode returning strlit4558
// Begin line 1293
  setline(1293);
  if (strlit4559 == NULL) {
    strlit4559 = alloc_String("i8* getelementptr([5 x i8]* @.str._push");
  }
// compilenode returning strlit4559
  params[0] = strlit4559;
  Object opresult4561 = callmethod(strlit4558, "++", 1, params);
// compilenode returning opresult4561
// Begin line 1294
  setline(1294);
  if (strlit4562 == NULL) {
    strlit4562 = alloc_String(",i32 0,i32 0), ");
  }
// compilenode returning strlit4562
  params[0] = strlit4562;
  Object opresult4564 = callmethod(opresult4561, "++", 1, params);
// compilenode returning opresult4564
// Begin line 1295
  setline(1295);
  if (strlit4565 == NULL) {
    strlit4565 = alloc_String("i32 0, %object* %params)");
  }
// compilenode returning strlit4565
  params[0] = strlit4565;
  Object opresult4567 = callmethod(opresult4564, "++", 1, params);
// compilenode returning opresult4567
// Begin line 1296
  setline(1296);
// compilenode returning self
  params[0] = opresult4567;
  Object call4568 = callmethod(self, "out",
    1, params);
// compilenode returning call4568
  if (strlit4569 == NULL) {
    strlit4569 = alloc_String("  %argv_inc = add i32 %argv_iv, 1");
  }
// compilenode returning strlit4569
// Begin line 1297
  setline(1297);
// compilenode returning self
  params[0] = strlit4569;
  Object call4570 = callmethod(self, "out",
    1, params);
// compilenode returning call4570
  if (strlit4571 == NULL) {
    strlit4571 = alloc_String("  store i32 %argv_inc, i32* %argv_i");
  }
// compilenode returning strlit4571
// Begin line 1298
  setline(1298);
// compilenode returning self
  params[0] = strlit4571;
  Object call4572 = callmethod(self, "out",
    1, params);
// compilenode returning call4572
  if (strlit4573 == NULL) {
    strlit4573 = alloc_String("  br label %argv.cond");
  }
// compilenode returning strlit4573
// Begin line 1299
  setline(1299);
// compilenode returning self
  params[0] = strlit4573;
  Object call4574 = callmethod(self, "out",
    1, params);
// compilenode returning call4574
  if (strlit4575 == NULL) {
    strlit4575 = alloc_String("argv.end");
  }
// compilenode returning strlit4575
// Begin line 1300
  setline(1300);
// compilenode returning self
  params[0] = strlit4575;
  Object call4576 = callmethod(self, "beginblock",
    1, params);
// compilenode returning call4576
  if (strlit4577 == NULL) {
    strlit4577 = alloc_String("  call void @module_sys_init_argv(%object %tmp_argv)");
  }
// compilenode returning strlit4577
// Begin line 1301
  setline(1301);
// compilenode returning self
  params[0] = strlit4577;
  Object call4578 = callmethod(self, "out",
    1, params);
// compilenode returning call4578
  if (strlit4579 == NULL) {
    strlit4579 = alloc_String("  %var_argv = call %object* @alloc_var()");
  }
// compilenode returning strlit4579
// Begin line 1302
  setline(1302);
// compilenode returning self
  params[0] = strlit4579;
  Object call4580 = callmethod(self, "out",
    1, params);
// compilenode returning call4580
  if (strlit4581 == NULL) {
    strlit4581 = alloc_String("  store %object %tmp_argv, %object* %var_argv");
  }
// compilenode returning strlit4581
// Begin line 1303
  setline(1303);
// compilenode returning self
  params[0] = strlit4581;
  Object call4582 = callmethod(self, "out",
    1, params);
// compilenode returning call4582
  if (strlit4583 == NULL) {
    strlit4583 = alloc_String("  store %object %tmp_argv, %object* @argv");
  }
// compilenode returning strlit4583
// Begin line 1304
  setline(1304);
// compilenode returning self
  params[0] = strlit4583;
  Object call4584 = callmethod(self, "out",
    1, params);
// compilenode returning call4584
  if (strlit4585 == NULL) {
    strlit4585 = alloc_String("  call %object @module_");
  }
// compilenode returning strlit4585
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4587 = callmethod(strlit4585, "++", 1, params);
// compilenode returning opresult4587
  if (strlit4588 == NULL) {
    strlit4588 = alloc_String("_init()");
  }
// compilenode returning strlit4588
  params[0] = strlit4588;
  Object opresult4590 = callmethod(opresult4587, "++", 1, params);
// compilenode returning opresult4590
// Begin line 1305
  setline(1305);
// compilenode returning self
  params[0] = opresult4590;
  Object call4591 = callmethod(self, "out",
    1, params);
// compilenode returning call4591
  if (strlit4592 == NULL) {
    strlit4592 = alloc_String("  call void @gracelib_stats()");
  }
// compilenode returning strlit4592
// Begin line 1306
  setline(1306);
// compilenode returning self
  params[0] = strlit4592;
  Object call4593 = callmethod(self, "out",
    1, params);
// compilenode returning call4593
  if (strlit4594 == NULL) {
    strlit4594 = alloc_String("  ret i32 0");
  }
// compilenode returning strlit4594
// Begin line 1307
  setline(1307);
// compilenode returning self
  params[0] = strlit4594;
  Object call4595 = callmethod(self, "out",
    1, params);
// compilenode returning call4595
  if (strlit4596 == NULL) {
    strlit4596 = alloc_String("}");
  }
// compilenode returning strlit4596
// Begin line 1308
  setline(1308);
// compilenode returning self
  params[0] = strlit4596;
  Object call4597 = callmethod(self, "out",
    1, params);
// compilenode returning call4597
  if (strlit4598 == NULL) {
    strlit4598 = alloc_String("; constant definitions");
  }
// compilenode returning strlit4598
// Begin line 1309
  setline(1309);
// compilenode returning self
  params[0] = strlit4598;
  Object call4599 = callmethod(self, "out",
    1, params);
// compilenode returning call4599
// Begin line 1310
  setline(1310);
// Begin line 1309
  setline(1309);
// compilenode returning *var_constants
// Begin line 1310
  setline(1310);
// Begin line 1429
  setline(1429);
  Object obj4602 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4602, self, 0);
  addmethod2(obj4602, "outer", &reader_genllvm29_outer_4603);
  adddatum2(obj4602, self, 0);
  block_savedest(obj4602);
  Object **closure4604 = createclosure(1);
  Object *selfpp4606 = alloc_var();
  *selfpp4606 = self;
  addtoclosure(closure4604, selfpp4606);
  struct UserObject *uo4604 = (struct UserObject*)obj4602;
  uo4604->data[1] = (Object)closure4604;
  addmethod2(obj4602, "apply", &meth_genllvm29_apply4604);
  set_type(obj4602, 0);
// compilenode returning obj4602
  setclassname(obj4602, "Block<genllvm29:4601>");
// compilenode returning obj4602
  params[0] = *var_constants;
  Object iter4600 = callmethod(*var_constants, "iter", 1, params);
  while(1) {
    Object cond4600 = callmethod(iter4600, "havemore", 0, NULL);
    if (!istrue(cond4600)) break;
    params[0] = callmethod(iter4600, "next", 0, NULL);
    callmethod(obj4602, "apply", 1, params);
  }
// compilenode returning *var_constants
// Begin line 1313
  setline(1313);
// Begin line 1429
  setline(1429);
// Begin line 1312
  setline(1312);
// compilenode returning module_subtype
  Object call4607 = callmethod(module_subtype, "boolMatrix",
    0, params);
// compilenode returning call4607
// compilenode returning call4607
  *var_mtx = call4607;
  if (call4607 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1314
  setline(1314);
// Begin line 1313
  setline(1313);
  if (strlit4608 == NULL) {
    strlit4608 = alloc_String("@.subtypes = private unnamed_addr ");
  }
// compilenode returning strlit4608
// Begin line 1314
  setline(1314);
  if (strlit4609 == NULL) {
    strlit4609 = alloc_String("constant [");
  }
// compilenode returning strlit4609
// Begin line 1429
  setline(1429);
// Begin line 1314
  setline(1314);
// compilenode returning *var_mtx
  Object call4610 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4610
// compilenode returning call4610
// Begin line 1429
  setline(1429);
// Begin line 1314
  setline(1314);
// compilenode returning *var_mtx
  Object call4611 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4611
// compilenode returning call4611
  params[0] = call4611;
  Object prod4613 = callmethod(call4610, "*", 1, params);
// compilenode returning prod4613
  params[0] = prod4613;
  Object opresult4615 = callmethod(strlit4609, "++", 1, params);
// compilenode returning opresult4615
  if (strlit4616 == NULL) {
    strlit4616 = alloc_String(" x i1] [");
  }
// compilenode returning strlit4616
  params[0] = strlit4616;
  Object opresult4618 = callmethod(opresult4615, "++", 1, params);
// compilenode returning opresult4618
  params[0] = opresult4618;
  Object opresult4620 = callmethod(strlit4608, "++", 1, params);
// compilenode returning opresult4620
// Begin line 1315
  setline(1315);
// compilenode returning self
  params[0] = opresult4620;
  Object call4621 = callmethod(self, "out",
    1, params);
// compilenode returning call4621
// Begin line 1316
  setline(1316);
// Begin line 1315
  setline(1315);
  Object bool4622 = alloc_Boolean(1);
// compilenode returning bool4622
  var_smfirst = alloc_var();
  *var_smfirst = bool4622;
  if (bool4622 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1326
  setline(1326);
// Begin line 1316
  setline(1316);
// compilenode returning *var_mtx
// Begin line 1326
  setline(1326);
// Begin line 1429
  setline(1429);
  Object obj4625 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4625, self, 0);
  addmethod2(obj4625, "outer", &reader_genllvm29_outer_4626);
  adddatum2(obj4625, self, 0);
  block_savedest(obj4625);
  Object **closure4627 = createclosure(2);
  addtoclosure(closure4627, var_smfirst);
  Object *selfpp4644 = alloc_var();
  *selfpp4644 = self;
  addtoclosure(closure4627, selfpp4644);
  struct UserObject *uo4627 = (struct UserObject*)obj4625;
  uo4627->data[1] = (Object)closure4627;
  addmethod2(obj4625, "apply", &meth_genllvm29_apply4627);
  set_type(obj4625, 0);
// compilenode returning obj4625
  setclassname(obj4625, "Block<genllvm29:4624>");
// compilenode returning obj4625
  params[0] = *var_mtx;
  Object iter4623 = callmethod(*var_mtx, "iter", 1, params);
  while(1) {
    Object cond4623 = callmethod(iter4623, "havemore", 0, NULL);
    if (!istrue(cond4623)) break;
    params[0] = callmethod(iter4623, "next", 0, NULL);
    callmethod(obj4625, "apply", 1, params);
  }
// compilenode returning *var_mtx
// Begin line 1330
  setline(1330);
  if (strlit4645 == NULL) {
    strlit4645 = alloc_String("]");
  }
// compilenode returning strlit4645
// Begin line 1331
  setline(1331);
// compilenode returning self
  params[0] = strlit4645;
  Object call4646 = callmethod(self, "out",
    1, params);
// compilenode returning call4646
  if (strlit4647 == NULL) {
    strlit4647 = alloc_String("@.typecount = private unnamed_addr constant i16 ");
  }
// compilenode returning strlit4647
// Begin line 1429
  setline(1429);
// Begin line 1331
  setline(1331);
// compilenode returning *var_mtx
  Object call4648 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4648
// compilenode returning call4648
  params[0] = call4648;
  Object opresult4650 = callmethod(strlit4647, "++", 1, params);
// compilenode returning opresult4650
  if (strlit4651 == NULL) {
    strlit4651 = alloc_String("");
  }
// compilenode returning strlit4651
  params[0] = strlit4651;
  Object opresult4653 = callmethod(opresult4650, "++", 1, params);
// compilenode returning opresult4653
// Begin line 1332
  setline(1332);
// compilenode returning self
  params[0] = opresult4653;
  Object call4654 = callmethod(self, "out",
    1, params);
// compilenode returning call4654
  if (strlit4655 == NULL) {
    strlit4655 = alloc_String("define private i1 @checksub(i16 %sub, i16 %sup) {");
  }
// compilenode returning strlit4655
// Begin line 1333
  setline(1333);
// compilenode returning self
  params[0] = strlit4655;
  Object call4656 = callmethod(self, "out",
    1, params);
// compilenode returning call4656
  if (strlit4657 == NULL) {
    strlit4657 = alloc_String("entry:");
  }
// compilenode returning strlit4657
// Begin line 1334
  setline(1334);
// compilenode returning self
  params[0] = strlit4657;
  Object call4658 = callmethod(self, "out",
    1, params);
// compilenode returning call4658
  if (strlit4659 == NULL) {
    strlit4659 = alloc_String("  %tc = load i16* @.typecount");
  }
// compilenode returning strlit4659
// Begin line 1335
  setline(1335);
// compilenode returning self
  params[0] = strlit4659;
  Object call4660 = callmethod(self, "out",
    1, params);
// compilenode returning call4660
  if (strlit4661 == NULL) {
    strlit4661 = alloc_String("  %st = load [");
  }
// compilenode returning strlit4661
// Begin line 1429
  setline(1429);
// Begin line 1335
  setline(1335);
// compilenode returning *var_mtx
  Object call4662 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4662
// compilenode returning call4662
// Begin line 1429
  setline(1429);
// Begin line 1335
  setline(1335);
// compilenode returning *var_mtx
  Object call4663 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4663
// compilenode returning call4663
  params[0] = call4663;
  Object prod4665 = callmethod(call4662, "*", 1, params);
// compilenode returning prod4665
  params[0] = prod4665;
  Object opresult4667 = callmethod(strlit4661, "++", 1, params);
// compilenode returning opresult4667
  if (strlit4668 == NULL) {
    strlit4668 = alloc_String(" x i1]* @.subtypes");
  }
// compilenode returning strlit4668
  params[0] = strlit4668;
  Object opresult4670 = callmethod(opresult4667, "++", 1, params);
// compilenode returning opresult4670
// Begin line 1336
  setline(1336);
// compilenode returning self
  params[0] = opresult4670;
  Object call4671 = callmethod(self, "out",
    1, params);
// compilenode returning call4671
  if (strlit4672 == NULL) {
    strlit4672 = alloc_String("  %ridx = mul i16 %sub, %tc");
  }
// compilenode returning strlit4672
// Begin line 1337
  setline(1337);
// compilenode returning self
  params[0] = strlit4672;
  Object call4673 = callmethod(self, "out",
    1, params);
// compilenode returning call4673
  if (strlit4674 == NULL) {
    strlit4674 = alloc_String("  %idx = add i16 %ridx, %sup");
  }
// compilenode returning strlit4674
// Begin line 1338
  setline(1338);
// compilenode returning self
  params[0] = strlit4674;
  Object call4675 = callmethod(self, "out",
    1, params);
// compilenode returning call4675
  if (strlit4676 == NULL) {
    strlit4676 = alloc_String("  %ptr = getelementptr [");
  }
// compilenode returning strlit4676
// Begin line 1429
  setline(1429);
// Begin line 1338
  setline(1338);
// compilenode returning *var_mtx
  Object call4677 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4677
// compilenode returning call4677
// Begin line 1429
  setline(1429);
// Begin line 1338
  setline(1338);
// compilenode returning *var_mtx
  Object call4678 = callmethod(*var_mtx, "size",
    0, params);
// compilenode returning call4678
// compilenode returning call4678
  params[0] = call4678;
  Object prod4680 = callmethod(call4677, "*", 1, params);
// compilenode returning prod4680
  params[0] = prod4680;
  Object opresult4682 = callmethod(strlit4676, "++", 1, params);
// compilenode returning opresult4682
  if (strlit4683 == NULL) {
    strlit4683 = alloc_String(" x i1]* @.subtypes, i32 0, i16 %idx");
  }
// compilenode returning strlit4683
  params[0] = strlit4683;
  Object opresult4685 = callmethod(opresult4682, "++", 1, params);
// compilenode returning opresult4685
// Begin line 1339
  setline(1339);
// compilenode returning self
  params[0] = opresult4685;
  Object call4686 = callmethod(self, "out",
    1, params);
// compilenode returning call4686
  if (strlit4687 == NULL) {
    strlit4687 = alloc_String("  %rv = load i1* %ptr");
  }
// compilenode returning strlit4687
// Begin line 1340
  setline(1340);
// compilenode returning self
  params[0] = strlit4687;
  Object call4688 = callmethod(self, "out",
    1, params);
// compilenode returning call4688
  if (strlit4689 == NULL) {
    strlit4689 = alloc_String("  ret i1 %rv");
  }
// compilenode returning strlit4689
// Begin line 1341
  setline(1341);
// compilenode returning self
  params[0] = strlit4689;
  Object call4690 = callmethod(self, "out",
    1, params);
// compilenode returning call4690
  if (strlit4691 == NULL) {
    strlit4691 = alloc_String("}");
  }
// compilenode returning strlit4691
// Begin line 1342
  setline(1342);
// compilenode returning self
  params[0] = strlit4691;
  Object call4692 = callmethod(self, "out",
    1, params);
// compilenode returning call4692
  if (strlit4693 == NULL) {
    strlit4693 = alloc_String("; gracelib");
  }
// compilenode returning strlit4693
// Begin line 1343
  setline(1343);
// compilenode returning self
  params[0] = strlit4693;
  Object call4694 = callmethod(self, "out",
    1, params);
// compilenode returning call4694
  if (strlit4695 == NULL) {
    strlit4695 = alloc_String("declare %object @alloc_obj2(i32, i32)");
  }
// compilenode returning strlit4695
// Begin line 1344
  setline(1344);
// compilenode returning self
  params[0] = strlit4695;
  Object call4696 = callmethod(self, "out",
    1, params);
// compilenode returning call4696
  if (strlit4697 == NULL) {
    strlit4697 = alloc_String("declare void @addmethod2(%object, i8*, %object(%object, i32, %object*, i32)*)");
  }
// compilenode returning strlit4697
// Begin line 1345
  setline(1345);
// compilenode returning self
  params[0] = strlit4697;
  Object call4698 = callmethod(self, "out",
    1, params);
// compilenode returning call4698
  if (strlit4699 == NULL) {
    strlit4699 = alloc_String("declare void @adddatum2(%object, %object, i32)");
  }
// compilenode returning strlit4699
// Begin line 1346
  setline(1346);
// compilenode returning self
  params[0] = strlit4699;
  Object call4700 = callmethod(self, "out",
    1, params);
// compilenode returning call4700
  if (strlit4701 == NULL) {
    strlit4701 = alloc_String("declare %object @alloc_List()");
  }
// compilenode returning strlit4701
// Begin line 1347
  setline(1347);
// compilenode returning self
  params[0] = strlit4701;
  Object call4702 = callmethod(self, "out",
    1, params);
// compilenode returning call4702
  if (strlit4703 == NULL) {
    strlit4703 = alloc_String("declare %object @alloc_Float64(double)");
  }
// compilenode returning strlit4703
// Begin line 1348
  setline(1348);
// compilenode returning self
  params[0] = strlit4703;
  Object call4704 = callmethod(self, "out",
    1, params);
// compilenode returning call4704
  if (strlit4705 == NULL) {
    strlit4705 = alloc_String("declare %object @alloc_String(i8*)");
  }
// compilenode returning strlit4705
// Begin line 1349
  setline(1349);
// compilenode returning self
  params[0] = strlit4705;
  Object call4706 = callmethod(self, "out",
    1, params);
// compilenode returning call4706
  if (strlit4707 == NULL) {
    strlit4707 = alloc_String("declare %object @alloc_Octets(i8*, i32)");
  }
// compilenode returning strlit4707
// Begin line 1350
  setline(1350);
// compilenode returning self
  params[0] = strlit4707;
  Object call4708 = callmethod(self, "out",
    1, params);
// compilenode returning call4708
  if (strlit4709 == NULL) {
    strlit4709 = alloc_String("declare %object @alloc_Boolean(i32)");
  }
// compilenode returning strlit4709
// Begin line 1351
  setline(1351);
// compilenode returning self
  params[0] = strlit4709;
  Object call4710 = callmethod(self, "out",
    1, params);
// compilenode returning call4710
  if (strlit4711 == NULL) {
    strlit4711 = alloc_String("declare %object @alloc_Undefined()");
  }
// compilenode returning strlit4711
// Begin line 1352
  setline(1352);
// compilenode returning self
  params[0] = strlit4711;
  Object call4712 = callmethod(self, "out",
    1, params);
// compilenode returning call4712
  if (strlit4713 == NULL) {
    strlit4713 = alloc_String("declare %object @alloc_Nothing()");
  }
// compilenode returning strlit4713
// Begin line 1353
  setline(1353);
// compilenode returning self
  params[0] = strlit4713;
  Object call4714 = callmethod(self, "out",
    1, params);
// compilenode returning call4714
  if (strlit4715 == NULL) {
    strlit4715 = alloc_String("declare %object @alloc_HashMapClassObject()");
  }
// compilenode returning strlit4715
// Begin line 1354
  setline(1354);
// compilenode returning self
  params[0] = strlit4715;
  Object call4716 = callmethod(self, "out",
    1, params);
// compilenode returning call4716
  if (strlit4717 == NULL) {
    strlit4717 = alloc_String("declare %object @callmethod(%object, i8*, i32, %object*)");
  }
// compilenode returning strlit4717
// Begin line 1355
  setline(1355);
// compilenode returning self
  params[0] = strlit4717;
  Object call4718 = callmethod(self, "out",
    1, params);
// compilenode returning call4718
  if (strlit4719 == NULL) {
    strlit4719 = alloc_String("declare %object @gracelib_print(%object, i32, %object*)");
  }
// compilenode returning strlit4719
// Begin line 1356
  setline(1356);
// compilenode returning self
  params[0] = strlit4719;
  Object call4720 = callmethod(self, "out",
    1, params);
// compilenode returning call4720
  if (strlit4721 == NULL) {
    strlit4721 = alloc_String("declare %object @gracelib_readall(%object, i32, %object*)");
  }
// compilenode returning strlit4721
// Begin line 1357
  setline(1357);
// compilenode returning self
  params[0] = strlit4721;
  Object call4722 = callmethod(self, "out",
    1, params);
// compilenode returning call4722
  if (strlit4723 == NULL) {
    strlit4723 = alloc_String("declare %object @gracelib_length(%object)");
  }
// compilenode returning strlit4723
// Begin line 1358
  setline(1358);
// compilenode returning self
  params[0] = strlit4723;
  Object call4724 = callmethod(self, "out",
    1, params);
// compilenode returning call4724
// Begin line 1361
  setline(1361);
// Begin line 1359
  setline(1359);
// Begin line 1429
  setline(1429);
  Object obj4726 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4726, self, 0);
  addmethod2(obj4726, "outer", &reader_genllvm29_outer_4727);
  adddatum2(obj4726, self, 0);
  block_savedest(obj4726);
  Object **closure4728 = createclosure(1);
  Object *selfpp4731 = alloc_var();
  *selfpp4731 = self;
  addtoclosure(closure4728, selfpp4731);
  struct UserObject *uo4728 = (struct UserObject*)obj4726;
  uo4728->data[1] = (Object)closure4728;
  addmethod2(obj4726, "apply", &meth_genllvm29_apply4728);
  set_type(obj4726, 0);
// compilenode returning obj4726
  setclassname(obj4726, "Block<genllvm29:4725>");
// compilenode returning obj4726
// Begin line 1361
  setline(1361);
// Begin line 1429
  setline(1429);
  Object obj4733 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4733, self, 0);
  addmethod2(obj4733, "outer", &reader_genllvm29_outer_4734);
  adddatum2(obj4733, self, 0);
  block_savedest(obj4733);
  Object **closure4735 = createclosure(1);
  Object *selfpp4736 = alloc_var();
  *selfpp4736 = self;
  addtoclosure(closure4735, selfpp4736);
  struct UserObject *uo4735 = (struct UserObject*)obj4733;
  uo4735->data[1] = (Object)closure4735;
  addmethod2(obj4733, "apply", &meth_genllvm29_apply4735);
  set_type(obj4733, 0);
// compilenode returning obj4733
  setclassname(obj4733, "Block<genllvm29:4732>");
// compilenode returning obj4733
// Begin line 1358
  setline(1358);
// compilenode returning module_util
  params[0] = obj4726;
  params[1] = obj4733;
  Object call4737 = callmethod(module_util, "runOnNew(1)else",
    2, params);
// compilenode returning call4737
// Begin line 1361
  setline(1361);
  if (strlit4738 == NULL) {
    strlit4738 = alloc_String("declare void @setclassname(%object, i8*)");
  }
// compilenode returning strlit4738
// Begin line 1362
  setline(1362);
// compilenode returning self
  params[0] = strlit4738;
  Object call4739 = callmethod(self, "out",
    1, params);
// compilenode returning call4739
  if (strlit4740 == NULL) {
    strlit4740 = alloc_String("declare void @enable_callgraph(i8*)");
  }
// compilenode returning strlit4740
// Begin line 1363
  setline(1363);
// compilenode returning self
  params[0] = strlit4740;
  Object call4741 = callmethod(self, "out",
    1, params);
// compilenode returning call4741
  if (strlit4742 == NULL) {
    strlit4742 = alloc_String("declare %object @dlmodule(i8*)");
  }
// compilenode returning strlit4742
// Begin line 1364
  setline(1364);
// compilenode returning self
  params[0] = strlit4742;
  Object call4743 = callmethod(self, "out",
    1, params);
// compilenode returning call4743
  if (strlit4744 == NULL) {
    strlit4744 = alloc_String("declare %object* @alloc_var()");
  }
// compilenode returning strlit4744
// Begin line 1365
  setline(1365);
// compilenode returning self
  params[0] = strlit4744;
  Object call4745 = callmethod(self, "out",
    1, params);
// compilenode returning call4745
  if (strlit4746 == NULL) {
    strlit4746 = alloc_String("declare void @gracelib_argv(i8**)");
  }
// compilenode returning strlit4746
// Begin line 1366
  setline(1366);
// compilenode returning self
  params[0] = strlit4746;
  Object call4747 = callmethod(self, "out",
    1, params);
// compilenode returning call4747
  if (strlit4748 == NULL) {
    strlit4748 = alloc_String("declare void @module_sys_init_argv(%object)");
  }
// compilenode returning strlit4748
// Begin line 1367
  setline(1367);
// compilenode returning self
  params[0] = strlit4748;
  Object call4749 = callmethod(self, "out",
    1, params);
// compilenode returning call4749
  if (strlit4750 == NULL) {
    strlit4750 = alloc_String("declare i1 @istrue(%object)");
  }
// compilenode returning strlit4750
// Begin line 1368
  setline(1368);
// compilenode returning self
  params[0] = strlit4750;
  Object call4751 = callmethod(self, "out",
    1, params);
// compilenode returning call4751
  if (strlit4752 == NULL) {
    strlit4752 = alloc_String("declare void @gracelib_stats()");
  }
// compilenode returning strlit4752
// Begin line 1369
  setline(1369);
// compilenode returning self
  params[0] = strlit4752;
  Object call4753 = callmethod(self, "out",
    1, params);
// compilenode returning call4753
  if (strlit4754 == NULL) {
    strlit4754 = alloc_String("declare void @initprofiling()");
  }
// compilenode returning strlit4754
// Begin line 1370
  setline(1370);
// compilenode returning self
  params[0] = strlit4754;
  Object call4755 = callmethod(self, "out",
    1, params);
// compilenode returning call4755
  if (strlit4756 == NULL) {
    strlit4756 = alloc_String("declare %object** @createclosure(i32)");
  }
// compilenode returning strlit4756
// Begin line 1371
  setline(1371);
// compilenode returning self
  params[0] = strlit4756;
  Object call4757 = callmethod(self, "out",
    1, params);
// compilenode returning call4757
  if (strlit4758 == NULL) {
    strlit4758 = alloc_String("declare void @addtoclosure(%object**, %object*)");
  }
// compilenode returning strlit4758
// Begin line 1372
  setline(1372);
// compilenode returning self
  params[0] = strlit4758;
  Object call4759 = callmethod(self, "out",
    1, params);
// compilenode returning call4759
  if (strlit4760 == NULL) {
    strlit4760 = alloc_String("declare void @addclosuremethod(%object, i8*, %object(%object,");
  }
// compilenode returning strlit4760
// Begin line 1373
  setline(1373);
// compilenode returning self
  params[0] = strlit4760;
  Object call4761 = callmethod(self, "out",
    1, params);
// compilenode returning call4761
  if (strlit4762 == NULL) {
    strlit4762 = alloc_String("    i32, %object*, %object**)*, %object**)");
  }
// compilenode returning strlit4762
// Begin line 1374
  setline(1374);
// compilenode returning self
  params[0] = strlit4762;
  Object call4763 = callmethod(self, "out",
    1, params);
// compilenode returning call4763
  if (strlit4764 == NULL) {
    strlit4764 = alloc_String("declare void @setline(i32)");
  }
// compilenode returning strlit4764
// Begin line 1375
  setline(1375);
// compilenode returning self
  params[0] = strlit4764;
  Object call4765 = callmethod(self, "out",
    1, params);
// compilenode returning call4765
  if (strlit4766 == NULL) {
    strlit4766 = alloc_String("declare void @block_return(%object, %object)");
  }
// compilenode returning strlit4766
// Begin line 1376
  setline(1376);
// compilenode returning self
  params[0] = strlit4766;
  Object call4767 = callmethod(self, "out",
    1, params);
// compilenode returning call4767
  if (strlit4768 == NULL) {
    strlit4768 = alloc_String("declare void @block_savedest(%object)");
  }
// compilenode returning strlit4768
// Begin line 1377
  setline(1377);
// compilenode returning self
  params[0] = strlit4768;
  Object call4769 = callmethod(self, "out",
    1, params);
// compilenode returning call4769
  if (strlit4770 == NULL) {
    strlit4770 = alloc_String("declare %object @process_varargs(%object*, i32, i32)");
  }
// compilenode returning strlit4770
// Begin line 1378
  setline(1378);
// compilenode returning self
  params[0] = strlit4770;
  Object call4771 = callmethod(self, "out",
    1, params);
// compilenode returning call4771
  if (strlit4772 == NULL) {
    strlit4772 = alloc_String("; libc functions");
  }
// compilenode returning strlit4772
// Begin line 1379
  setline(1379);
// compilenode returning self
  params[0] = strlit4772;
  Object call4773 = callmethod(self, "out",
    1, params);
// compilenode returning call4773
  if (strlit4774 == NULL) {
    strlit4774 = alloc_String("declare i32 @puts(i8*)");
  }
// compilenode returning strlit4774
// Begin line 1380
  setline(1380);
// compilenode returning self
  params[0] = strlit4774;
  Object call4775 = callmethod(self, "out",
    1, params);
// compilenode returning call4775
  if (strlit4776 == NULL) {
    strlit4776 = alloc_String("declare i8* @malloc(i32)");
  }
// compilenode returning strlit4776
// Begin line 1381
  setline(1381);
// compilenode returning self
  params[0] = strlit4776;
  Object call4777 = callmethod(self, "out",
    1, params);
// compilenode returning call4777
  if (strlit4778 == NULL) {
    strlit4778 = alloc_String("writing file.");
  }
// compilenode returning strlit4778
// Begin line 1382
  setline(1382);
// compilenode returning self
  params[0] = strlit4778;
  Object call4779 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call4779
// Begin line 1383
  setline(1383);
// Begin line 1382
  setline(1382);
// compilenode returning *var_output
// Begin line 1383
  setline(1383);
// Begin line 1429
  setline(1429);
  Object obj4782 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4782, self, 0);
  addmethod2(obj4782, "outer", &reader_genllvm29_outer_4783);
  adddatum2(obj4782, self, 0);
  block_savedest(obj4782);
  Object **closure4784 = createclosure(1);
  Object *selfpp4786 = alloc_var();
  *selfpp4786 = self;
  addtoclosure(closure4784, selfpp4786);
  struct UserObject *uo4784 = (struct UserObject*)obj4782;
  uo4784->data[1] = (Object)closure4784;
  addmethod2(obj4782, "apply", &meth_genllvm29_apply4784);
  set_type(obj4782, 0);
// compilenode returning obj4782
  setclassname(obj4782, "Block<genllvm29:4781>");
// compilenode returning obj4782
  params[0] = *var_output;
  Object iter4780 = callmethod(*var_output, "iter", 1, params);
  while(1) {
    Object cond4780 = callmethod(iter4780, "havemore", 0, NULL);
    if (!istrue(cond4780)) break;
    params[0] = callmethod(iter4780, "next", 0, NULL);
    callmethod(obj4782, "apply", 1, params);
  }
// compilenode returning *var_output
// Begin line 1429
  setline(1429);
// Begin line 1432
  setline(1432);
// Begin line 1386
  setline(1386);
// compilenode returning *var_runmode
  if (strlit4788 == NULL) {
    strlit4788 = alloc_String("make");
  }
// compilenode returning strlit4788
  params[0] = strlit4788;
  Object opresult4790 = callmethod(*var_runmode, "==", 1, params);
// compilenode returning opresult4790
  Object if4787;
  if (istrue(opresult4790)) {
// Begin line 1387
  setline(1387);
// Begin line 1429
  setline(1429);
// Begin line 1387
  setline(1387);
// compilenode returning *var_outfile
  Object call4791 = callmethod(*var_outfile, "close",
    0, params);
// compilenode returning call4791
// compilenode returning call4791
// Begin line 1389
  setline(1389);
// Begin line 1388
  setline(1388);
  if (strlit4792 == NULL) {
    strlit4792 = alloc_String("llvm-as -o ");
  }
// compilenode returning strlit4792
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4794 = callmethod(strlit4792, "++", 1, params);
// compilenode returning opresult4794
  if (strlit4795 == NULL) {
    strlit4795 = alloc_String(".gco ");
  }
// compilenode returning strlit4795
  params[0] = strlit4795;
  Object opresult4797 = callmethod(opresult4794, "++", 1, params);
// compilenode returning opresult4797
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4799 = callmethod(opresult4797, "++", 1, params);
// compilenode returning opresult4799
  if (strlit4800 == NULL) {
    strlit4800 = alloc_String(".ll");
  }
// compilenode returning strlit4800
  params[0] = strlit4800;
  Object opresult4802 = callmethod(opresult4799, "++", 1, params);
// compilenode returning opresult4802
  *var_cmd = opresult4802;
  if (opresult4802 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1391
  setline(1391);
// Begin line 1389
  setline(1389);
// Begin line 1429
  setline(1429);
// Begin line 1389
  setline(1389);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4805 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4805
  Object call4806 = callmethod(call4805, "not",
    0, params);
// compilenode returning call4806
// compilenode returning call4806
  Object if4804;
  if (istrue(call4806)) {
// Begin line 1390
  setline(1390);
  if (strlit4807 == NULL) {
    strlit4807 = alloc_String("Failed LLVM assembling");
  }
// compilenode returning strlit4807
// Begin line 1391
  setline(1391);
// Begin line 1429
  setline(1429);
// Begin line 1390
  setline(1390);
// compilenode returning module_io
  Object call4808 = callmethod(module_io, "error",
    0, params);
// compilenode returning call4808
// compilenode returning call4808
  params[0] = strlit4807;
  Object call4809 = callmethod(call4808, "write",
    1, params);
// compilenode returning call4809
// Begin line 1391
  setline(1391);
  if (strlit4810 == NULL) {
    strlit4810 = alloc_String("Fatal.");
  }
// compilenode returning strlit4810
  params[0] = strlit4810;
  Object call4811 = callmethod(self, "raise",
    1, params);
// compilenode returning call4811
    if4804 = call4811;
  } else {
  }
// compilenode returning if4804
// Begin line 1393
  setline(1393);
  if (strlit4812 == NULL) {
    strlit4812 = alloc_String("linking.");
  }
// compilenode returning strlit4812
// Begin line 1394
  setline(1394);
// compilenode returning self
  params[0] = strlit4812;
  Object call4813 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call4813
// Begin line 1395
  setline(1395);
// Begin line 1394
  setline(1394);
  if (strlit4814 == NULL) {
    strlit4814 = alloc_String("llvm-link -o ");
  }
// compilenode returning strlit4814
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4816 = callmethod(strlit4814, "++", 1, params);
// compilenode returning opresult4816
  if (strlit4817 == NULL) {
    strlit4817 = alloc_String(".bc ");
  }
// compilenode returning strlit4817
  params[0] = strlit4817;
  Object opresult4819 = callmethod(opresult4816, "++", 1, params);
// compilenode returning opresult4819
  *var_cmd = opresult4819;
  if (opresult4819 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1395
  setline(1395);
// compilenode returning *var_cmd
  if (strlit4821 == NULL) {
    strlit4821 = alloc_String(".o");
  }
// compilenode returning strlit4821
  if (strlit4822 == NULL) {
    strlit4822 = alloc_String(".bc");
  }
// compilenode returning strlit4822
// compilenode returning *var_gracelibPath
  params[0] = strlit4821;
  params[1] = strlit4822;
  Object call4823 = callmethod(*var_gracelibPath, "replace(1)with",
    2, params);
// compilenode returning call4823
  params[0] = call4823;
  Object opresult4825 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4825
  if (strlit4826 == NULL) {
    strlit4826 = alloc_String(" ");
  }
// compilenode returning strlit4826
  params[0] = strlit4826;
  Object opresult4828 = callmethod(opresult4825, "++", 1, params);
// compilenode returning opresult4828
  *var_cmd = opresult4828;
  if (opresult4828 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1397
  setline(1397);
// Begin line 1396
  setline(1396);
// compilenode returning *var_cmd
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4831 = callmethod(*var_cmd, "++", 1, params);
// compilenode returning opresult4831
  if (strlit4832 == NULL) {
    strlit4832 = alloc_String(".gco");
  }
// compilenode returning strlit4832
  params[0] = strlit4832;
  Object opresult4834 = callmethod(opresult4831, "++", 1, params);
// compilenode returning opresult4834
  *var_cmd = opresult4834;
  if (opresult4834 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1399
  setline(1399);
// Begin line 1397
  setline(1397);
// compilenode returning *var_linkfiles
// Begin line 1399
  setline(1399);
// Begin line 1429
  setline(1429);
  Object obj4838 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj4838, self, 0);
  addmethod2(obj4838, "outer", &reader_genllvm29_outer_4839);
  adddatum2(obj4838, self, 0);
  block_savedest(obj4838);
  Object **closure4840 = createclosure(2);
  addtoclosure(closure4840, var_cmd);
  Object *selfpp4847 = alloc_var();
  *selfpp4847 = self;
  addtoclosure(closure4840, selfpp4847);
  struct UserObject *uo4840 = (struct UserObject*)obj4838;
  uo4840->data[1] = (Object)closure4840;
  addmethod2(obj4838, "apply", &meth_genllvm29_apply4840);
  set_type(obj4838, 0);
// compilenode returning obj4838
  setclassname(obj4838, "Block<genllvm29:4837>");
// compilenode returning obj4838
  params[0] = *var_linkfiles;
  Object iter4836 = callmethod(*var_linkfiles, "iter", 1, params);
  while(1) {
    Object cond4836 = callmethod(iter4836, "havemore", 0, NULL);
    if (!istrue(cond4836)) break;
    params[0] = callmethod(iter4836, "next", 0, NULL);
    callmethod(obj4838, "apply", 1, params);
  }
// compilenode returning *var_linkfiles
// Begin line 1402
  setline(1402);
// Begin line 1400
  setline(1400);
// Begin line 1429
  setline(1429);
// Begin line 1400
  setline(1400);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4849 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4849
  Object call4850 = callmethod(call4849, "not",
    0, params);
// compilenode returning call4850
// compilenode returning call4850
  Object if4848;
  if (istrue(call4850)) {
// Begin line 1401
  setline(1401);
  if (strlit4851 == NULL) {
    strlit4851 = alloc_String("Failed LLVM linking");
  }
// compilenode returning strlit4851
// Begin line 1402
  setline(1402);
// Begin line 1429
  setline(1429);
// Begin line 1401
  setline(1401);
// compilenode returning module_io
  Object call4852 = callmethod(module_io, "error",
    0, params);
// compilenode returning call4852
// compilenode returning call4852
  params[0] = strlit4851;
  Object call4853 = callmethod(call4852, "write",
    1, params);
// compilenode returning call4853
// Begin line 1402
  setline(1402);
  if (strlit4854 == NULL) {
    strlit4854 = alloc_String("Fatal.");
  }
// compilenode returning strlit4854
  params[0] = strlit4854;
  Object call4855 = callmethod(self, "raise",
    1, params);
// compilenode returning call4855
    if4848 = call4855;
  } else {
  }
// compilenode returning if4848
// Begin line 1423
  setline(1423);
// Begin line 1426
  setline(1426);
// Begin line 1404
  setline(1404);
// compilenode returning *var_buildtype
  if (strlit4857 == NULL) {
    strlit4857 = alloc_String("native");
  }
// compilenode returning strlit4857
  params[0] = strlit4857;
  Object opresult4859 = callmethod(*var_buildtype, "==", 1, params);
// compilenode returning opresult4859
// Begin line 1426
  setline(1426);
// Begin line 1429
  setline(1429);
// Begin line 1426
  setline(1426);
// Begin line 1429
  setline(1429);
// Begin line 1404
  setline(1404);
// compilenode returning module_util
  Object call4860 = callmethod(module_util, "noexec",
    0, params);
// compilenode returning call4860
// compilenode returning call4860
  Object call4861 = callmethod(call4860, "not",
    0, params);
// compilenode returning call4861
// compilenode returning call4861
  params[0] = call4861;
  Object opresult4863 = callmethod(opresult4859, "&", 1, params);
// compilenode returning opresult4863
  Object if4856;
  if (istrue(opresult4863)) {
// Begin line 1405
  setline(1405);
  if (strlit4864 == NULL) {
    strlit4864 = alloc_String("compiling to native.");
  }
// compilenode returning strlit4864
// Begin line 1406
  setline(1406);
// compilenode returning self
  params[0] = strlit4864;
  Object call4865 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call4865
// Begin line 1408
  setline(1408);
// Begin line 1406
  setline(1406);
  if (strlit4866 == NULL) {
    strlit4866 = alloc_String("llc -o ");
  }
// compilenode returning strlit4866
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4868 = callmethod(strlit4866, "++", 1, params);
// compilenode returning opresult4868
  if (strlit4869 == NULL) {
    strlit4869 = alloc_String(".s -relocation-model=pic ");
  }
// compilenode returning strlit4869
  params[0] = strlit4869;
  Object opresult4871 = callmethod(opresult4868, "++", 1, params);
// compilenode returning opresult4871
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4873 = callmethod(opresult4871, "++", 1, params);
// compilenode returning opresult4873
// Begin line 1407
  setline(1407);
  if (strlit4874 == NULL) {
    strlit4874 = alloc_String(".bc");
  }
// compilenode returning strlit4874
  params[0] = strlit4874;
  Object opresult4876 = callmethod(opresult4873, "++", 1, params);
// compilenode returning opresult4876
  *var_cmd = opresult4876;
  if (opresult4876 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1410
  setline(1410);
// Begin line 1408
  setline(1408);
// Begin line 1429
  setline(1429);
// Begin line 1408
  setline(1408);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4879 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4879
  Object call4880 = callmethod(call4879, "not",
    0, params);
// compilenode returning call4880
// compilenode returning call4880
  Object if4878;
  if (istrue(call4880)) {
// Begin line 1409
  setline(1409);
  if (strlit4881 == NULL) {
    strlit4881 = alloc_String("failed native assembly compilation");
  }
// compilenode returning strlit4881
// Begin line 1410
  setline(1410);
// Begin line 1429
  setline(1429);
// Begin line 1409
  setline(1409);
// compilenode returning module_io
  Object call4882 = callmethod(module_io, "error",
    0, params);
// compilenode returning call4882
// compilenode returning call4882
  params[0] = strlit4881;
  Object call4883 = callmethod(call4882, "write",
    1, params);
// compilenode returning call4883
// Begin line 1410
  setline(1410);
  if (strlit4884 == NULL) {
    strlit4884 = alloc_String("fatal.");
  }
// compilenode returning strlit4884
  params[0] = strlit4884;
  Object call4885 = callmethod(self, "raise",
    1, params);
// compilenode returning call4885
    if4878 = call4885;
  } else {
  }
// compilenode returning if4878
// Begin line 1414
  setline(1414);
// Begin line 1413
  setline(1413);
  if (strlit4886 == NULL) {
    strlit4886 = alloc_String("ld -ldl -o /dev/null 2>/dev/null");
  }
// compilenode returning strlit4886
  *var_cmd = strlit4886;
  if (strlit4886 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1420
  setline(1420);
// Begin line 1414
  setline(1414);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4889 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4889
  Object if4888;
  if (istrue(call4889)) {
// Begin line 1417
  setline(1417);
// Begin line 1415
  setline(1415);
  if (strlit4890 == NULL) {
    strlit4890 = alloc_String("gcc -fPIC -Wl,--export-dynamic -o ");
  }
// compilenode returning strlit4890
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4892 = callmethod(strlit4890, "++", 1, params);
// compilenode returning opresult4892
  if (strlit4893 == NULL) {
    strlit4893 = alloc_String(" -ldl ");
  }
// compilenode returning strlit4893
  params[0] = strlit4893;
  Object opresult4895 = callmethod(opresult4892, "++", 1, params);
// compilenode returning opresult4895
// Begin line 1416
  setline(1416);
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4897 = callmethod(opresult4895, "++", 1, params);
// compilenode returning opresult4897
  if (strlit4898 == NULL) {
    strlit4898 = alloc_String(".s");
  }
// compilenode returning strlit4898
  params[0] = strlit4898;
  Object opresult4900 = callmethod(opresult4897, "++", 1, params);
// compilenode returning opresult4900
  *var_cmd = opresult4900;
  if (opresult4900 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4888 = nothing;
  } else {
// Begin line 1420
  setline(1420);
// Begin line 1418
  setline(1418);
  if (strlit4902 == NULL) {
    strlit4902 = alloc_String("gcc -fPIC -Wl,--export-dynamic -o ");
  }
// compilenode returning strlit4902
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4904 = callmethod(strlit4902, "++", 1, params);
// compilenode returning opresult4904
  if (strlit4905 == NULL) {
    strlit4905 = alloc_String(" ");
  }
// compilenode returning strlit4905
  params[0] = strlit4905;
  Object opresult4907 = callmethod(opresult4904, "++", 1, params);
// compilenode returning opresult4907
// Begin line 1419
  setline(1419);
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4909 = callmethod(opresult4907, "++", 1, params);
// compilenode returning opresult4909
  if (strlit4910 == NULL) {
    strlit4910 = alloc_String(".s");
  }
// compilenode returning strlit4910
  params[0] = strlit4910;
  Object opresult4912 = callmethod(opresult4909, "++", 1, params);
// compilenode returning opresult4912
  *var_cmd = opresult4912;
  if (opresult4912 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if4888 = nothing;
  }
// compilenode returning if4888
// Begin line 1423
  setline(1423);
// Begin line 1421
  setline(1421);
// Begin line 1429
  setline(1429);
// Begin line 1421
  setline(1421);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4915 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4915
  Object call4916 = callmethod(call4915, "not",
    0, params);
// compilenode returning call4916
// compilenode returning call4916
  Object if4914;
  if (istrue(call4916)) {
// Begin line 1422
  setline(1422);
  if (strlit4917 == NULL) {
    strlit4917 = alloc_String("failed native assembly compilation");
  }
// compilenode returning strlit4917
// Begin line 1423
  setline(1423);
// Begin line 1429
  setline(1429);
// Begin line 1422
  setline(1422);
// compilenode returning module_io
  Object call4918 = callmethod(module_io, "error",
    0, params);
// compilenode returning call4918
// compilenode returning call4918
  params[0] = strlit4917;
  Object call4919 = callmethod(call4918, "write",
    1, params);
// compilenode returning call4919
// Begin line 1423
  setline(1423);
  if (strlit4920 == NULL) {
    strlit4920 = alloc_String("fatal.");
  }
// compilenode returning strlit4920
  params[0] = strlit4920;
  Object call4921 = callmethod(self, "raise",
    1, params);
// compilenode returning call4921
    if4914 = call4921;
  } else {
  }
// compilenode returning if4914
    if4856 = if4914;
  } else {
  }
// compilenode returning if4856
// Begin line 1426
  setline(1426);
  if (strlit4922 == NULL) {
    strlit4922 = alloc_String("done.");
  }
// compilenode returning strlit4922
// Begin line 1427
  setline(1427);
// compilenode returning self
  params[0] = strlit4922;
  Object call4923 = callmethod(self, "log_verbose",
    1, params);
// compilenode returning call4923
// Begin line 1429
  setline(1429);
// Begin line 1431
  setline(1431);
// Begin line 1427
  setline(1427);
// compilenode returning *var_buildtype
  if (strlit4925 == NULL) {
    strlit4925 = alloc_String("run");
  }
// compilenode returning strlit4925
  params[0] = strlit4925;
  Object opresult4927 = callmethod(*var_buildtype, "==", 1, params);
// compilenode returning opresult4927
  Object if4924;
  if (istrue(opresult4927)) {
// Begin line 1429
  setline(1429);
// Begin line 1428
  setline(1428);
  if (strlit4928 == NULL) {
    strlit4928 = alloc_String("lli ./");
  }
// compilenode returning strlit4928
// compilenode returning *var_modname
  params[0] = *var_modname;
  Object opresult4930 = callmethod(strlit4928, "++", 1, params);
// compilenode returning opresult4930
  if (strlit4931 == NULL) {
    strlit4931 = alloc_String(".bc");
  }
// compilenode returning strlit4931
  params[0] = strlit4931;
  Object opresult4933 = callmethod(opresult4930, "++", 1, params);
// compilenode returning opresult4933
  *var_cmd = opresult4933;
  if (opresult4933 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1429
  setline(1429);
// compilenode returning *var_cmd
// compilenode returning module_io
  params[0] = *var_cmd;
  Object call4935 = callmethod(module_io, "system",
    1, params);
// compilenode returning call4935
    if4924 = call4935;
  } else {
  }
// compilenode returning if4924
    if4787 = if4924;
  } else {
  }
// compilenode returning if4787
  return if4787;
}
Object module_genllvm29_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<genllvm29>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_verbosity = alloc_var();
  *var_verbosity = undefined;
  Object *var_pad1 = alloc_var();
  *var_pad1 = undefined;
  Object *var_auto_count = alloc_var();
  *var_auto_count = undefined;
  Object *var_constants = alloc_var();
  *var_constants = undefined;
  Object *var_output = alloc_var();
  *var_output = undefined;
  Object *var_usedvars = alloc_var();
  *var_usedvars = undefined;
  Object *var_declaredvars = alloc_var();
  *var_declaredvars = undefined;
  Object *var_bblock = alloc_var();
  *var_bblock = undefined;
  Object *var_linenum = alloc_var();
  *var_linenum = undefined;
  Object *var_modules = alloc_var();
  *var_modules = undefined;
  Object *var_staticmodules = alloc_var();
  *var_staticmodules = undefined;
  Object *var_values = alloc_var();
  *var_values = undefined;
  Object *var_outfile = alloc_var();
  *var_outfile = undefined;
  Object *var_modname = alloc_var();
  *var_modname = undefined;
  Object *var_runmode = alloc_var();
  *var_runmode = undefined;
  Object *var_buildtype = alloc_var();
  *var_buildtype = undefined;
  Object *var_gracelibPath = alloc_var();
  *var_gracelibPath = undefined;
  Object *var_inBlock = alloc_var();
  *var_inBlock = undefined;
  Object *var_paramsUsed = alloc_var();
  *var_paramsUsed = undefined;
  Object *var_topLevelMethodPos = alloc_var();
  *var_topLevelMethodPos = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of sys
  if (module_sys == NULL)
    module_sys = module_sys_init();
  Object *var_sys = alloc_var();
  *var_sys = module_sys;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of ast
  if (module_ast == NULL)
    module_ast = module_ast_init();
  Object *var_ast = alloc_var();
  *var_ast = module_ast;
// compilenode returning undefined
// Begin line 5
  setline(5);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Import of buildinfo
  if (module_buildinfo == NULL)
    module_buildinfo = module_buildinfo_init();
  Object *var_buildinfo = alloc_var();
  *var_buildinfo = module_buildinfo;
// compilenode returning undefined
// Begin line 14
  setline(14);
// Import of subtype
  if (module_subtype == NULL)
    module_subtype = module_subtype_init();
  Object *var_subtype = alloc_var();
  *var_subtype = module_subtype;
// compilenode returning undefined
// Begin line 15
  setline(15);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 16
  setline(16);
// Begin line 15
  setline(15);
  Object num6 = alloc_Float64(30.0);
// compilenode returning num6
  var_verbosity = alloc_var();
  *var_verbosity = num6;
  if (num6 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 17
  setline(17);
// Begin line 16
  setline(16);
  Object num7 = alloc_Float64(1.0);
// compilenode returning num7
  var_pad1 = alloc_var();
  *var_pad1 = num7;
  if (num7 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 18
  setline(18);
// Begin line 17
  setline(17);
  Object num8 = alloc_Float64(0.0);
// compilenode returning num8
  var_auto_count = alloc_var();
  *var_auto_count = num8;
  if (num8 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 19
  setline(19);
  Object array9 = alloc_List();
// compilenode returning array9
  var_constants = alloc_var();
  *var_constants = array9;
  if (array9 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 20
  setline(20);
  Object array10 = alloc_List();
// compilenode returning array10
  var_output = alloc_var();
  *var_output = array10;
  if (array10 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 21
  setline(21);
  Object array11 = alloc_List();
// compilenode returning array11
  var_usedvars = alloc_var();
  *var_usedvars = array11;
  if (array11 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 22
  setline(22);
  Object array12 = alloc_List();
// compilenode returning array12
  var_declaredvars = alloc_var();
  *var_declaredvars = array12;
  if (array12 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 23
  setline(23);
// Begin line 22
  setline(22);
  if (strlit13 == NULL) {
    strlit13 = alloc_String("entry");
  }
// compilenode returning strlit13
  var_bblock = alloc_var();
  *var_bblock = strlit13;
  if (strlit13 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 24
  setline(24);
// Begin line 23
  setline(23);
  Object num14 = alloc_Float64(1.0);
// compilenode returning num14
  var_linenum = alloc_var();
  *var_linenum = num14;
  if (num14 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 25
  setline(25);
  Object array15 = alloc_List();
// compilenode returning array15
  var_modules = alloc_var();
  *var_modules = array15;
  if (array15 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 26
  setline(26);
  Object array16 = alloc_List();
// compilenode returning array16
  var_staticmodules = alloc_var();
  *var_staticmodules = array16;
  if (array16 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 27
  setline(27);
  Object array17 = alloc_List();
// compilenode returning array17
  var_values = alloc_var();
  *var_values = array17;
  if (array17 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 28
  setline(28);
  var_outfile = alloc_var();
  *var_outfile = undefined;
// compilenode returning nothing
// Begin line 29
  setline(29);
// Begin line 28
  setline(28);
  if (strlit18 == NULL) {
    strlit18 = alloc_String("main");
  }
// compilenode returning strlit18
  var_modname = alloc_var();
  *var_modname = strlit18;
  if (strlit18 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 30
  setline(30);
// Begin line 29
  setline(29);
  if (strlit19 == NULL) {
    strlit19 = alloc_String("build");
  }
// compilenode returning strlit19
  var_runmode = alloc_var();
  *var_runmode = strlit19;
  if (strlit19 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 31
  setline(31);
// Begin line 30
  setline(30);
  if (strlit20 == NULL) {
    strlit20 = alloc_String("bc");
  }
// compilenode returning strlit20
  var_buildtype = alloc_var();
  *var_buildtype = strlit20;
  if (strlit20 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 32
  setline(32);
// Begin line 31
  setline(31);
  if (strlit21 == NULL) {
    strlit21 = alloc_String("gracelib.bc");
  }
// compilenode returning strlit21
  var_gracelibPath = alloc_var();
  *var_gracelibPath = strlit21;
  if (strlit21 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 33
  setline(33);
// Begin line 32
  setline(32);
  Object bool22 = alloc_Boolean(0);
// compilenode returning bool22
  var_inBlock = alloc_var();
  *var_inBlock = bool22;
  if (bool22 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 34
  setline(34);
// Begin line 33
  setline(33);
  Object num23 = alloc_Float64(1.0);
// compilenode returning num23
  var_paramsUsed = alloc_var();
  *var_paramsUsed = num23;
  if (num23 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 36
  setline(36);
// Begin line 34
  setline(34);
  Object num24 = alloc_Float64(1.0);
// compilenode returning num24
  var_topLevelMethodPos = alloc_var();
  *var_topLevelMethodPos = num24;
  if (num24 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 37
  setline(37);
  block_savedest(self);
  Object **closure25 = createclosure(1);
  addtoclosure(closure25, var_output);
  struct UserObject *uo25 = (struct UserObject*)self;
  uo25->data[1] = (Object)closure25;
  addmethod2(self, "out", &meth_genllvm29_out25);
// compilenode returning 
// Begin line 40
  setline(40);
  addmethod2(self, "outprint", &meth_genllvm29_outprint27);
// compilenode returning 
// Begin line 43
  setline(43);
  addmethod2(self, "log_verbose", &meth_genllvm29_log_verbose29);
// compilenode returning 
// Begin line 47
  setline(47);
  block_savedest(self);
  Object **closure31 = createclosure(1);
  addtoclosure(closure31, var_bblock);
  struct UserObject *uo31 = (struct UserObject*)self;
  uo31->data[4] = (Object)closure31;
  addmethod2(self, "beginblock", &meth_genllvm29_beginblock31);
// compilenode returning 
// Begin line 62
  setline(62);
  block_savedest(self);
  Object **closure40 = createclosure(1);
  addtoclosure(closure40, var_auto_count);
  struct UserObject *uo40 = (struct UserObject*)self;
  uo40->data[5] = (Object)closure40;
  addmethod2(self, "compilearray", &meth_genllvm29_compilearray40);
// compilenode returning 
// Begin line 69
  setline(69);
  addmethod2(self, "compilemember", &meth_genllvm29_compilemember82);
// compilenode returning 
// Begin line 98
  setline(98);
  block_savedest(self);
  Object **closure87 = createclosure(3);
  addtoclosure(closure87, var_auto_count);
  addtoclosure(closure87, var_constants);
  addtoclosure(closure87, var_modname);
  struct UserObject *uo87 = (struct UserObject*)self;
  uo87->data[7] = (Object)closure87;
  addmethod2(self, "compileobjouter", &meth_genllvm29_compileobjouter87);
// compilenode returning 
// Begin line 132
  setline(132);
  block_savedest(self);
  Object **closure205 = createclosure(3);
  addtoclosure(closure205, var_auto_count);
  addtoclosure(closure205, var_constants);
  addtoclosure(closure205, var_modname);
  struct UserObject *uo205 = (struct UserObject*)self;
  uo205->data[8] = (Object)closure205;
  addmethod2(self, "compileobjdefdec", &meth_genllvm29_compileobjdefdec205);
// compilenode returning 
// Begin line 193
  setline(193);
  block_savedest(self);
  Object **closure345 = createclosure(3);
  addtoclosure(closure345, var_auto_count);
  addtoclosure(closure345, var_constants);
  addtoclosure(closure345, var_modname);
  struct UserObject *uo345 = (struct UserObject*)self;
  uo345->data[9] = (Object)closure345;
  addmethod2(self, "compileobjvardec", &meth_genllvm29_compileobjvardec345);
// compilenode returning 
// Begin line 203
  setline(203);
  addmethod2(self, "compileclass", &meth_genllvm29_compileclass603);
// compilenode returning 
// Begin line 250
  setline(250);
  block_savedest(self);
  Object **closure622 = createclosure(2);
  addtoclosure(closure622, var_inBlock);
  addtoclosure(closure622, var_auto_count);
  struct UserObject *uo622 = (struct UserObject*)self;
  uo622->data[11] = (Object)closure622;
  addmethod2(self, "compileobject", &meth_genllvm29_compileobject622);
// compilenode returning 
// Begin line 270
  setline(270);
  block_savedest(self);
  Object **closure760 = createclosure(4);
  addtoclosure(closure760, var_inBlock);
  addtoclosure(closure760, var_auto_count);
  addtoclosure(closure760, var_modname);
  addtoclosure(closure760, var_constants);
  struct UserObject *uo760 = (struct UserObject*)self;
  uo760->data[12] = (Object)closure760;
  addmethod2(self, "compileblock", &meth_genllvm29_compileblock760);
// compilenode returning 
// Begin line 309
  setline(309);
  block_savedest(self);
  Object **closure844 = createclosure(2);
  addtoclosure(closure844, var_auto_count);
  addtoclosure(closure844, var_bblock);
  struct UserObject *uo844 = (struct UserObject*)self;
  uo844->data[13] = (Object)closure844;
  addmethod2(self, "compilefor", &meth_genllvm29_compilefor844);
// compilenode returning 
// Begin line 519
  setline(519);
  block_savedest(self);
  Object **closure987 = createclosure(9);
  addtoclosure(closure987, var_paramsUsed);
  addtoclosure(closure987, var_inBlock);
  addtoclosure(closure987, var_output);
  addtoclosure(closure987, var_bblock);
  addtoclosure(closure987, var_usedvars);
  addtoclosure(closure987, var_declaredvars);
  addtoclosure(closure987, var_auto_count);
  addtoclosure(closure987, var_modname);
  addtoclosure(closure987, var_constants);
  struct UserObject *uo987 = (struct UserObject*)self;
  uo987->data[14] = (Object)closure987;
  addmethod2(self, "compilemethod", &meth_genllvm29_compilemethod987);
// compilenode returning 
// Begin line 553
  setline(553);
  block_savedest(self);
  Object **closure1677 = createclosure(3);
  addtoclosure(closure1677, var_auto_count);
  addtoclosure(closure1677, var_declaredvars);
  addtoclosure(closure1677, var_bblock);
  struct UserObject *uo1677 = (struct UserObject*)self;
  uo1677->data[15] = (Object)closure1677;
  addmethod2(self, "compilewhile", &meth_genllvm29_compilewhile1677);
// compilenode returning 
// Begin line 618
  setline(618);
  block_savedest(self);
  Object **closure1800 = createclosure(3);
  addtoclosure(closure1800, var_auto_count);
  addtoclosure(closure1800, var_bblock);
  addtoclosure(closure1800, var_declaredvars);
  struct UserObject *uo1800 = (struct UserObject*)self;
  uo1800->data[16] = (Object)closure1800;
  addmethod2(self, "compileif", &meth_genllvm29_compileif1800);
// compilenode returning 
// Begin line 642
  setline(642);
  block_savedest(self);
  Object **closure2081 = createclosure(3);
  addtoclosure(closure2081, var_auto_count);
  addtoclosure(closure2081, var_modules);
  addtoclosure(closure2081, var_usedvars);
  struct UserObject *uo2081 = (struct UserObject*)self;
  uo2081->data[17] = (Object)closure2081;
  addmethod2(self, "compileidentifier", &meth_genllvm29_compileidentifier2081);
// compilenode returning 
// Begin line 679
  setline(679);
  block_savedest(self);
  Object **closure2165 = createclosure(2);
  addtoclosure(closure2165, var_usedvars);
  addtoclosure(closure2165, var_auto_count);
  struct UserObject *uo2165 = (struct UserObject*)self;
  uo2165->data[18] = (Object)closure2165;
  addmethod2(self, "compilebind", &meth_genllvm29_compilebind2165);
// compilenode returning 
// Begin line 707
  setline(707);
  block_savedest(self);
  Object **closure2302 = createclosure(2);
  addtoclosure(closure2302, var_declaredvars);
  addtoclosure(closure2302, var_auto_count);
  struct UserObject *uo2302 = (struct UserObject*)self;
  uo2302->data[19] = (Object)closure2302;
  addmethod2(self, "compiledefdec", &meth_genllvm29_compiledefdec2302);
// compilenode returning 
// Begin line 734
  setline(734);
  block_savedest(self);
  Object **closure2409 = createclosure(2);
  addtoclosure(closure2409, var_declaredvars);
  addtoclosure(closure2409, var_auto_count);
  struct UserObject *uo2409 = (struct UserObject*)self;
  uo2409->data[20] = (Object)closure2409;
  addmethod2(self, "compilevardec", &meth_genllvm29_compilevardec2409);
// compilenode returning 
// Begin line 744
  setline(744);
  block_savedest(self);
  Object **closure2508 = createclosure(1);
  addtoclosure(closure2508, var_auto_count);
  struct UserObject *uo2508 = (struct UserObject*)self;
  uo2508->data[21] = (Object)closure2508;
  addmethod2(self, "compileindex", &meth_genllvm29_compileindex2508);
// compilenode returning 
// Begin line 788
  setline(788);
  block_savedest(self);
  Object **closure2543 = createclosure(2);
  addtoclosure(closure2543, var_auto_count);
  addtoclosure(closure2543, var_constants);
  struct UserObject *uo2543 = (struct UserObject*)self;
  uo2543->data[22] = (Object)closure2543;
  addmethod2(self, "compileop", &meth_genllvm29_compileop2543);
// compilenode returning 
// Begin line 838
  setline(838);
  block_savedest(self);
  Object **closure2724 = createclosure(3);
  addtoclosure(closure2724, var_paramsUsed);
  addtoclosure(closure2724, var_constants);
  addtoclosure(closure2724, var_auto_count);
  struct UserObject *uo2724 = (struct UserObject*)self;
  uo2724->data[23] = (Object)closure2724;
  addmethod2(self, "compilecall", &meth_genllvm29_compilecall2724);
// compilenode returning 
// Begin line 882
  setline(882);
  block_savedest(self);
  Object **closure2935 = createclosure(2);
  addtoclosure(closure2935, var_auto_count);
  addtoclosure(closure2935, var_constants);
  struct UserObject *uo2935 = (struct UserObject*)self;
  uo2935->data[24] = (Object)closure2935;
  addmethod2(self, "compileoctets", &meth_genllvm29_compileoctets2935);
// compilenode returning 
// Begin line 929
  setline(929);
  block_savedest(self);
  Object **closure3170 = createclosure(5);
  addtoclosure(closure3170, var_bblock);
  addtoclosure(closure3170, var_auto_count);
  addtoclosure(closure3170, var_staticmodules);
  addtoclosure(closure3170, var_constants);
  addtoclosure(closure3170, var_modules);
  struct UserObject *uo3170 = (struct UserObject*)self;
  uo3170->data[25] = (Object)closure3170;
  addmethod2(self, "compileimport", &meth_genllvm29_compileimport3170);
// compilenode returning 
// Begin line 939
  setline(939);
  block_savedest(self);
  Object **closure3429 = createclosure(2);
  addtoclosure(closure3429, var_inBlock);
  addtoclosure(closure3429, var_auto_count);
  struct UserObject *uo3429 = (struct UserObject*)self;
  uo3429->data[26] = (Object)closure3429;
  addmethod2(self, "compilereturn", &meth_genllvm29_compilereturn3429);
// compilenode returning 
// Begin line 955
  setline(955);
  block_savedest(self);
  Object **closure3450 = createclosure(1);
  addtoclosure(closure3450, var_auto_count);
  struct UserObject *uo3450 = (struct UserObject*)self;
  uo3450->data[27] = (Object)closure3450;
  addmethod2(self, "compilenum", &meth_genllvm29_compilenum3450);
// compilenode returning 
// Begin line 1111
  setline(1111);
  block_savedest(self);
  Object **closure3491 = createclosure(5);
  addtoclosure(closure3491, var_linenum);
  addtoclosure(closure3491, var_auto_count);
  addtoclosure(closure3491, var_constants);
  addtoclosure(closure3491, var_topLevelMethodPos);
  addtoclosure(closure3491, var_tmp);
  struct UserObject *uo3491 = (struct UserObject*)self;
  uo3491->data[28] = (Object)closure3491;
  addmethod2(self, "compilenode", &meth_genllvm29_compilenode3491);
// compilenode returning 
// Begin line 1429
  setline(1429);
  block_savedest(self);
  Object **closure4047 = createclosure(11);
  addtoclosure(closure4047, var_values);
  addtoclosure(closure4047, var_outfile);
  addtoclosure(closure4047, var_modname);
  addtoclosure(closure4047, var_runmode);
  addtoclosure(closure4047, var_buildtype);
  addtoclosure(closure4047, var_gracelibPath);
  addtoclosure(closure4047, var_staticmodules);
  addtoclosure(closure4047, var_constants);
  addtoclosure(closure4047, var_output);
  addtoclosure(closure4047, var_declaredvars);
  addtoclosure(closure4047, var_paramsUsed);
  struct UserObject *uo4047 = (struct UserObject*)self;
  uo4047->data[29] = (Object)closure4047;
  addmethod2(self, "compile", &meth_genllvm29_compile4047);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_genllvm29_init();
  gracelib_stats();
  return 0;
}
