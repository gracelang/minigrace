#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_lexer_outer_27(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_39(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_46(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_49(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_51(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_52(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_53(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_54(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_55(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_57(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_60(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_62(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_63(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_64(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_65(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_66(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_68(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_71(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_73(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_74(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_75(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_76(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_77(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_79(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_82(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_84(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_86(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_87(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_88(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_89(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_91(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_94(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_96(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_98(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_99(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_100(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_101(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_103(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_106(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_108(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_110(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_111(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_112(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_113(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_115(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_118(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_120(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_122(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_123(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_124(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_125(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_127(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_130(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_132(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_134(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_135(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_136(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_137(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_139(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_142(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_144(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_146(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_147(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_148(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_149(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_151(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_154(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_156(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_158(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_159(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_160(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_161(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_163(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_166(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_168(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_170(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_171(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_172(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_173(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_175(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_178(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_180(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_182(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_183(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_184(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_185(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_187(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_190(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_192(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_193(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_194(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_195(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_196(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_198(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_201(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_203(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_204(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_205(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_206(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_207(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_209(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_212(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_214(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_215(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_216(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_217(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_218(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_220(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_223(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_225(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_227(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_228(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_229(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_230(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_232(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_235(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_237(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_239(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_240(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_241(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_242(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_244(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_247(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_249(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_251(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_252(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_253(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_254(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_256(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_259(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_261(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_263(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_264(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_265(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_266(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_268(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_271(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_kind_273(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object reader_lexer_value_275(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object reader_lexer_line_276(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object reader_lexer_indent_277(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object reader_lexer_linePos_278(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object reader_lexer_outer_280(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_lexer_outer_669(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_sys_init();
Object module_sys;
Object module_util_init();
Object module_util;
Object module_unicode_init();
Object module_unicode;
static Object strlit6;
static Object strlit7;
static Object strlit8;
static Object strlit9;
static Object strlit10;
static Object strlit11;
static Object strlit12;
static Object strlit13;
static Object strlit14;
static Object strlit15;
static Object strlit16;
static Object strlit17;
static Object strlit18;
static Object strlit19;
static Object strlit20;
static Object strlit21;
static Object strlit50;
static Object strlit61;
static Object strlit72;
static Object strlit83;
static Object strlit85;
static Object strlit95;
static Object strlit97;
static Object strlit107;
static Object strlit109;
static Object strlit119;
static Object strlit121;
static Object strlit131;
static Object strlit133;
static Object strlit143;
static Object strlit145;
static Object strlit155;
static Object strlit157;
static Object strlit167;
static Object strlit169;
static Object strlit179;
static Object strlit181;
static Object strlit191;
static Object strlit202;
static Object strlit213;
static Object strlit224;
static Object strlit226;
static Object strlit236;
static Object strlit238;
static Object strlit248;
static Object strlit250;
static Object strlit260;
static Object strlit262;
static Object strlit272;
static Object strlit274;
static Object strlit285;
static Object strlit295;
static Object strlit301;
static Object strlit304;
static Object strlit309;
static Object strlit314;
static Object strlit319;
static Object strlit324;
static Object strlit329;
static Object strlit334;
static Object strlit345;
static Object strlit354;
static Object strlit363;
static Object strlit372;
static Object strlit381;
static Object strlit390;
static Object strlit399;
static Object strlit408;
static Object strlit417;
static Object strlit426;
static Object strlit435;
static Object strlit444;
static Object strlit453;
static Object strlit462;
static Object strlit471;
static Object strlit484;
static Object strlit491;
static Object strlit497;
static Object strlit504;
static Object strlit507;
static Object strlit515;
static Object strlit521;
static Object strlit527;
static Object strlit533;
static Object strlit542;
static Object strlit550;
static Object strlit556;
static Object strlit562;
static Object strlit565;
static Object strlit593;
static Object strlit596;
static Object strlit601;
static Object strlit606;
static Object strlit611;
static Object strlit616;
static Object strlit621;
static Object strlit626;
static Object strlit631;
static Object strlit646;
static Object strlit650;
static Object strlit654;
static Object strlit656;
static Object strlit664;
static Object strlit676;
static Object strlit695;
static Object strlit696;
static Object strlit699;
static Object strlit705;
static Object strlit723;
static Object strlit724;
static Object strlit727;
static Object strlit732;
static Object strlit737;
static Object strlit740;
static Object strlit753;
static Object strlit756;
static Object strlit765;
static Object strlit769;
static Object strlit772;
static Object strlit777;
static Object strlit780;
static Object strlit783;
static Object strlit788;
static Object strlit791;
static Object strlit793;
static Object strlit796;
static Object strlit799;
static Object strlit806;
static Object strlit818;
static Object strlit823;
static Object strlit826;
static Object strlit829;
static Object strlit834;
static Object strlit837;
static Object strlit840;
static Object strlit845;
static Object strlit851;
static Object strlit855;
static Object strlit859;
static Object strlit862;
static Object strlit865;
static Object strlit870;
static Object strlit875;
static Object strlit880;
static Object strlit885;
static Object strlit890;
static Object strlit895;
static Object strlit900;
static Object strlit907;
static Object strlit910;
static Object strlit915;
static Object strlit919;
static Object strlit922;
static Object strlit927;
static Object strlit933;
static Object strlit964;
static Object strlit965;
static Object strlit968;
static Object strlit973;
static Object strlit976;
static Object strlit982;
static Object strlit989;
static Object strlit992;
static Object strlit1000;
static Object strlit1005;
static Object strlit1008;
static Object strlit1016;
static Object strlit1022;
static Object strlit1023;
static Object strlit1029;
static Object strlit1034;
static Object strlit1039;
static Object strlit1050;
static Object strlit1058;
static Object strlit1059;
static Object strlit1061;
static Object strlit1062;
static Object strlit1064;
static Object strlit1076;
static Object strlit1080;
static Object strlit1083;
static Object strlit1088;
static Object strlit1093;
static Object strlit1098;
static Object strlit1103;
static Object strlit1109;
static Object strlit1111;
static Object strlit1113;
static Object strlit1119;
static Object strlit1126;
static Object strlit1127;
static Object strlit1131;
static Object strlit1132;
static Object strlit1138;
static Object strlit1141;
static Object strlit1146;
static Object strlit1154;
static Object strlit1162;
static Object strlit1165;
static Object strlit1170;
static Object strlit1173;
static Object strlit1178;
static Object strlit1181;
static Object strlit1186;
static Object strlit1189;
static Object strlit1194;
static Object strlit1197;
static Object strlit1202;
static Object strlit1205;
static Object strlit1215;
static Object strlit1247;
static Object strlit1252;
static Object strlit1253;
static Object strlit1258;
static Object strlit1259;
static Object strlit1261;
static Object strlit1262;
static Object strlit1264;
static Object strlit1266;
static Object strlit1268;
static Object strlit1281;
static Object strlit1284;
static Object strlit1285;
static Object strlit1293;
static Object strlit1297;
static Object strlit1299;
static Object strlit1301;
static Object strlit1307;
Object meth_lexer_apply28(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_cr = alloc_var();
  *var_cr = args[0];
  Object params[1];
  Object *var_c = closure[0];
  Object *var_i = closure[1];
  Object *var_ret = closure[2];
  Object self = *closure[3];
// Begin line 15
  setline(15);
// Begin line 16
  setline(16);
// Begin line 13
  setline(13);
// compilenode returning *var_cr
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult31 = callmethod(*var_cr, "==", 1, params);
// compilenode returning opresult31
  Object if29;
  if (istrue(opresult31)) {
// Begin line 15
  setline(15);
// Begin line 14
  setline(14);
// compilenode returning *var_i
  *var_ret = *var_i;
  if (*var_i == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if29 = nothing;
  } else {
  }
// compilenode returning if29
// Begin line 17
  setline(17);
// Begin line 16
  setline(16);
// compilenode returning *var_i
  Object num33 = alloc_Float64(1.0);
// compilenode returning num33
  params[0] = num33;
  Object sum35 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum35
  *var_i = sum35;
  if (sum35 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_lexer_hexdecchar4(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_chars = alloc_var();
  *var_chars = undefined;
  Object *var_ret = alloc_var();
  *var_ret = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
// Begin line 9
  setline(9);
  Object array5 = alloc_List();
// Begin line 8
  setline(8);
  if (strlit6 == NULL) {
    strlit6 = alloc_String("0");
  }
// compilenode returning strlit6
  params[0] = strlit6;
  callmethod(array5, "push", 1, params);
  if (strlit7 == NULL) {
    strlit7 = alloc_String("1");
  }
// compilenode returning strlit7
  params[0] = strlit7;
  callmethod(array5, "push", 1, params);
  if (strlit8 == NULL) {
    strlit8 = alloc_String("2");
  }
// compilenode returning strlit8
  params[0] = strlit8;
  callmethod(array5, "push", 1, params);
  if (strlit9 == NULL) {
    strlit9 = alloc_String("3");
  }
// compilenode returning strlit9
  params[0] = strlit9;
  callmethod(array5, "push", 1, params);
  if (strlit10 == NULL) {
    strlit10 = alloc_String("4");
  }
// compilenode returning strlit10
  params[0] = strlit10;
  callmethod(array5, "push", 1, params);
  if (strlit11 == NULL) {
    strlit11 = alloc_String("5");
  }
// compilenode returning strlit11
  params[0] = strlit11;
  callmethod(array5, "push", 1, params);
  if (strlit12 == NULL) {
    strlit12 = alloc_String("6");
  }
// compilenode returning strlit12
  params[0] = strlit12;
  callmethod(array5, "push", 1, params);
  if (strlit13 == NULL) {
    strlit13 = alloc_String("7");
  }
// compilenode returning strlit13
  params[0] = strlit13;
  callmethod(array5, "push", 1, params);
  if (strlit14 == NULL) {
    strlit14 = alloc_String("8");
  }
// compilenode returning strlit14
  params[0] = strlit14;
  callmethod(array5, "push", 1, params);
// Begin line 9
  setline(9);
  if (strlit15 == NULL) {
    strlit15 = alloc_String("9");
  }
// compilenode returning strlit15
  params[0] = strlit15;
  callmethod(array5, "push", 1, params);
  if (strlit16 == NULL) {
    strlit16 = alloc_String("a");
  }
// compilenode returning strlit16
  params[0] = strlit16;
  callmethod(array5, "push", 1, params);
  if (strlit17 == NULL) {
    strlit17 = alloc_String("b");
  }
// compilenode returning strlit17
  params[0] = strlit17;
  callmethod(array5, "push", 1, params);
  if (strlit18 == NULL) {
    strlit18 = alloc_String("c");
  }
// compilenode returning strlit18
  params[0] = strlit18;
  callmethod(array5, "push", 1, params);
  if (strlit19 == NULL) {
    strlit19 = alloc_String("d");
  }
// compilenode returning strlit19
  params[0] = strlit19;
  callmethod(array5, "push", 1, params);
  if (strlit20 == NULL) {
    strlit20 = alloc_String("e");
  }
// compilenode returning strlit20
  params[0] = strlit20;
  callmethod(array5, "push", 1, params);
  if (strlit21 == NULL) {
    strlit21 = alloc_String("f");
  }
// compilenode returning strlit21
  params[0] = strlit21;
  callmethod(array5, "push", 1, params);
// compilenode returning array5
  var_chars = alloc_var();
  *var_chars = array5;
  if (array5 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 11
  setline(11);
// Begin line 10
  setline(10);
  Object num22 = alloc_Float64(0.0);
// compilenode returning num22
  var_ret = alloc_var();
  *var_ret = num22;
  if (num22 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 12
  setline(12);
// Begin line 11
  setline(11);
  Object num23 = alloc_Float64(0.0);
// compilenode returning num23
  var_i = alloc_var();
  *var_i = num23;
  if (num23 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 17
  setline(17);
// Begin line 12
  setline(12);
// compilenode returning *var_chars
// Begin line 17
  setline(17);
// Begin line 633
  setline(633);
  Object obj26 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj26, self, 0);
  addmethod2(obj26, "outer", &reader_lexer_outer_27);
  adddatum2(obj26, self, 0);
  block_savedest(obj26);
  Object **closure28 = createclosure(4);
  addtoclosure(closure28, var_c);
  addtoclosure(closure28, var_i);
  addtoclosure(closure28, var_ret);
  Object *selfpp37 = alloc_var();
  *selfpp37 = self;
  addtoclosure(closure28, selfpp37);
  struct UserObject *uo28 = (struct UserObject*)obj26;
  uo28->data[1] = (Object)closure28;
  addmethod2(obj26, "apply", &meth_lexer_apply28);
  set_type(obj26, 0);
// compilenode returning obj26
  setclassname(obj26, "Block<lexer:25>");
// compilenode returning obj26
  params[0] = *var_chars;
  Object iter24 = callmethod(*var_chars, "iter", 1, params);
  while(1) {
    Object cond24 = callmethod(iter24, "havemore", 0, NULL);
    if (!istrue(cond24)) break;
    params[0] = callmethod(iter24, "next", 0, NULL);
    callmethod(obj26, "apply", 1, params);
  }
// compilenode returning *var_chars
// Begin line 18
  setline(18);
// compilenode returning *var_ret
  return *var_ret;
}
Object meth_lexer_new47(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj48 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj48, self, 0);
  addmethod2(obj48, "outer", &reader_lexer_outer_49);
  adddatum2(obj48, self, 0);
// Begin line 29
  setline(29);
  if (strlit50 == NULL) {
    strlit50 = alloc_String("identifier");
  }
// compilenode returning strlit50
// OBJECT CONST DEC kind
  adddatum2(obj48, strlit50, 1);
  addmethod2(obj48, "kind", &reader_lexer_kind_51);
// Begin line 30
  setline(30);
// compilenode returning *var_s
// OBJECT CONST DEC value
  adddatum2(obj48, *var_s, 2);
  addmethod2(obj48, "value", &reader_lexer_value_52);
// Begin line 31
  setline(31);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj48, *var_lineNumber, 3);
  addmethod2(obj48, "line", &reader_lexer_line_53);
// Begin line 32
  setline(32);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj48, *var_indentLevel, 4);
  addmethod2(obj48, "indent", &reader_lexer_indent_54);
// Begin line 33
  setline(33);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj48, *var_startPosition, 5);
  addmethod2(obj48, "linePos", &reader_lexer_linePos_55);
  set_type(obj48, 0);
// compilenode returning obj48
  return obj48;
}
Object meth_lexer_new58(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj59 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj59, self, 0);
  addmethod2(obj59, "outer", &reader_lexer_outer_60);
  adddatum2(obj59, self, 0);
// Begin line 36
  setline(36);
  if (strlit61 == NULL) {
    strlit61 = alloc_String("string");
  }
// compilenode returning strlit61
// OBJECT CONST DEC kind
  adddatum2(obj59, strlit61, 1);
  addmethod2(obj59, "kind", &reader_lexer_kind_62);
// Begin line 37
  setline(37);
// compilenode returning *var_s
// OBJECT CONST DEC value
  adddatum2(obj59, *var_s, 2);
  addmethod2(obj59, "value", &reader_lexer_value_63);
// Begin line 38
  setline(38);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj59, *var_lineNumber, 3);
  addmethod2(obj59, "line", &reader_lexer_line_64);
// Begin line 39
  setline(39);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj59, *var_indentLevel, 4);
  addmethod2(obj59, "indent", &reader_lexer_indent_65);
// Begin line 40
  setline(40);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj59, *var_startPosition, 5);
  addmethod2(obj59, "linePos", &reader_lexer_linePos_66);
  set_type(obj59, 0);
// compilenode returning obj59
  return obj59;
}
Object meth_lexer_new69(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj70 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj70, self, 0);
  addmethod2(obj70, "outer", &reader_lexer_outer_71);
  adddatum2(obj70, self, 0);
// Begin line 43
  setline(43);
  if (strlit72 == NULL) {
    strlit72 = alloc_String("octets");
  }
// compilenode returning strlit72
// OBJECT CONST DEC kind
  adddatum2(obj70, strlit72, 1);
  addmethod2(obj70, "kind", &reader_lexer_kind_73);
// Begin line 44
  setline(44);
// compilenode returning *var_s
// OBJECT CONST DEC value
  adddatum2(obj70, *var_s, 2);
  addmethod2(obj70, "value", &reader_lexer_value_74);
// Begin line 45
  setline(45);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj70, *var_lineNumber, 3);
  addmethod2(obj70, "line", &reader_lexer_line_75);
// Begin line 46
  setline(46);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj70, *var_indentLevel, 4);
  addmethod2(obj70, "indent", &reader_lexer_indent_76);
// Begin line 47
  setline(47);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj70, *var_startPosition, 5);
  addmethod2(obj70, "linePos", &reader_lexer_linePos_77);
  set_type(obj70, 0);
// compilenode returning obj70
  return obj70;
}
Object meth_lexer_new80(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj81 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj81, self, 0);
  addmethod2(obj81, "outer", &reader_lexer_outer_82);
  adddatum2(obj81, self, 0);
// Begin line 50
  setline(50);
  if (strlit83 == NULL) {
    strlit83 = alloc_String("lbrace");
  }
// compilenode returning strlit83
// OBJECT CONST DEC kind
  adddatum2(obj81, strlit83, 1);
  addmethod2(obj81, "kind", &reader_lexer_kind_84);
// Begin line 51
  setline(51);
  if (strlit85 == NULL) {
    strlit85 = alloc_String("{");
  }
// compilenode returning strlit85
// OBJECT CONST DEC value
  adddatum2(obj81, strlit85, 2);
  addmethod2(obj81, "value", &reader_lexer_value_86);
// Begin line 52
  setline(52);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj81, *var_lineNumber, 3);
  addmethod2(obj81, "line", &reader_lexer_line_87);
// Begin line 53
  setline(53);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj81, *var_indentLevel, 4);
  addmethod2(obj81, "indent", &reader_lexer_indent_88);
// Begin line 54
  setline(54);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj81, *var_startPosition, 5);
  addmethod2(obj81, "linePos", &reader_lexer_linePos_89);
  set_type(obj81, 0);
// compilenode returning obj81
  return obj81;
}
Object meth_lexer_new92(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj93 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj93, self, 0);
  addmethod2(obj93, "outer", &reader_lexer_outer_94);
  adddatum2(obj93, self, 0);
// Begin line 57
  setline(57);
  if (strlit95 == NULL) {
    strlit95 = alloc_String("rbrace");
  }
// compilenode returning strlit95
// OBJECT CONST DEC kind
  adddatum2(obj93, strlit95, 1);
  addmethod2(obj93, "kind", &reader_lexer_kind_96);
// Begin line 58
  setline(58);
  if (strlit97 == NULL) {
    strlit97 = alloc_String("}");
  }
// compilenode returning strlit97
// OBJECT CONST DEC value
  adddatum2(obj93, strlit97, 2);
  addmethod2(obj93, "value", &reader_lexer_value_98);
// Begin line 59
  setline(59);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj93, *var_lineNumber, 3);
  addmethod2(obj93, "line", &reader_lexer_line_99);
// Begin line 60
  setline(60);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj93, *var_indentLevel, 4);
  addmethod2(obj93, "indent", &reader_lexer_indent_100);
// Begin line 61
  setline(61);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj93, *var_startPosition, 5);
  addmethod2(obj93, "linePos", &reader_lexer_linePos_101);
  set_type(obj93, 0);
// compilenode returning obj93
  return obj93;
}
Object meth_lexer_new104(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj105 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj105, self, 0);
  addmethod2(obj105, "outer", &reader_lexer_outer_106);
  adddatum2(obj105, self, 0);
// Begin line 64
  setline(64);
  if (strlit107 == NULL) {
    strlit107 = alloc_String("lparen");
  }
// compilenode returning strlit107
// OBJECT CONST DEC kind
  adddatum2(obj105, strlit107, 1);
  addmethod2(obj105, "kind", &reader_lexer_kind_108);
// Begin line 65
  setline(65);
  if (strlit109 == NULL) {
    strlit109 = alloc_String("(");
  }
// compilenode returning strlit109
// OBJECT CONST DEC value
  adddatum2(obj105, strlit109, 2);
  addmethod2(obj105, "value", &reader_lexer_value_110);
// Begin line 66
  setline(66);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj105, *var_lineNumber, 3);
  addmethod2(obj105, "line", &reader_lexer_line_111);
// Begin line 67
  setline(67);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj105, *var_indentLevel, 4);
  addmethod2(obj105, "indent", &reader_lexer_indent_112);
// Begin line 68
  setline(68);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj105, *var_startPosition, 5);
  addmethod2(obj105, "linePos", &reader_lexer_linePos_113);
  set_type(obj105, 0);
// compilenode returning obj105
  return obj105;
}
Object meth_lexer_new116(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj117 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj117, self, 0);
  addmethod2(obj117, "outer", &reader_lexer_outer_118);
  adddatum2(obj117, self, 0);
// Begin line 71
  setline(71);
  if (strlit119 == NULL) {
    strlit119 = alloc_String("rparen");
  }
// compilenode returning strlit119
// OBJECT CONST DEC kind
  adddatum2(obj117, strlit119, 1);
  addmethod2(obj117, "kind", &reader_lexer_kind_120);
// Begin line 72
  setline(72);
  if (strlit121 == NULL) {
    strlit121 = alloc_String(")");
  }
// compilenode returning strlit121
// OBJECT CONST DEC value
  adddatum2(obj117, strlit121, 2);
  addmethod2(obj117, "value", &reader_lexer_value_122);
// Begin line 73
  setline(73);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj117, *var_lineNumber, 3);
  addmethod2(obj117, "line", &reader_lexer_line_123);
// Begin line 74
  setline(74);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj117, *var_indentLevel, 4);
  addmethod2(obj117, "indent", &reader_lexer_indent_124);
// Begin line 75
  setline(75);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj117, *var_startPosition, 5);
  addmethod2(obj117, "linePos", &reader_lexer_linePos_125);
  set_type(obj117, 0);
// compilenode returning obj117
  return obj117;
}
Object meth_lexer_new128(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj129 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj129, self, 0);
  addmethod2(obj129, "outer", &reader_lexer_outer_130);
  adddatum2(obj129, self, 0);
// Begin line 78
  setline(78);
  if (strlit131 == NULL) {
    strlit131 = alloc_String("lsquare");
  }
// compilenode returning strlit131
// OBJECT CONST DEC kind
  adddatum2(obj129, strlit131, 1);
  addmethod2(obj129, "kind", &reader_lexer_kind_132);
// Begin line 79
  setline(79);
  if (strlit133 == NULL) {
    strlit133 = alloc_String("[");
  }
// compilenode returning strlit133
// OBJECT CONST DEC value
  adddatum2(obj129, strlit133, 2);
  addmethod2(obj129, "value", &reader_lexer_value_134);
// Begin line 80
  setline(80);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj129, *var_lineNumber, 3);
  addmethod2(obj129, "line", &reader_lexer_line_135);
// Begin line 81
  setline(81);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj129, *var_indentLevel, 4);
  addmethod2(obj129, "indent", &reader_lexer_indent_136);
// Begin line 82
  setline(82);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj129, *var_startPosition, 5);
  addmethod2(obj129, "linePos", &reader_lexer_linePos_137);
  set_type(obj129, 0);
// compilenode returning obj129
  return obj129;
}
Object meth_lexer_new140(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj141 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj141, self, 0);
  addmethod2(obj141, "outer", &reader_lexer_outer_142);
  adddatum2(obj141, self, 0);
// Begin line 85
  setline(85);
  if (strlit143 == NULL) {
    strlit143 = alloc_String("rsquare");
  }
// compilenode returning strlit143
// OBJECT CONST DEC kind
  adddatum2(obj141, strlit143, 1);
  addmethod2(obj141, "kind", &reader_lexer_kind_144);
// Begin line 86
  setline(86);
  if (strlit145 == NULL) {
    strlit145 = alloc_String("]");
  }
// compilenode returning strlit145
// OBJECT CONST DEC value
  adddatum2(obj141, strlit145, 2);
  addmethod2(obj141, "value", &reader_lexer_value_146);
// Begin line 87
  setline(87);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj141, *var_lineNumber, 3);
  addmethod2(obj141, "line", &reader_lexer_line_147);
// Begin line 88
  setline(88);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj141, *var_indentLevel, 4);
  addmethod2(obj141, "indent", &reader_lexer_indent_148);
// Begin line 89
  setline(89);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj141, *var_startPosition, 5);
  addmethod2(obj141, "linePos", &reader_lexer_linePos_149);
  set_type(obj141, 0);
// compilenode returning obj141
  return obj141;
}
Object meth_lexer_new152(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj153 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj153, self, 0);
  addmethod2(obj153, "outer", &reader_lexer_outer_154);
  adddatum2(obj153, self, 0);
// Begin line 92
  setline(92);
  if (strlit155 == NULL) {
    strlit155 = alloc_String("comma");
  }
// compilenode returning strlit155
// OBJECT CONST DEC kind
  adddatum2(obj153, strlit155, 1);
  addmethod2(obj153, "kind", &reader_lexer_kind_156);
// Begin line 93
  setline(93);
  if (strlit157 == NULL) {
    strlit157 = alloc_String(",");
  }
// compilenode returning strlit157
// OBJECT CONST DEC value
  adddatum2(obj153, strlit157, 2);
  addmethod2(obj153, "value", &reader_lexer_value_158);
// Begin line 94
  setline(94);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj153, *var_lineNumber, 3);
  addmethod2(obj153, "line", &reader_lexer_line_159);
// Begin line 95
  setline(95);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj153, *var_indentLevel, 4);
  addmethod2(obj153, "indent", &reader_lexer_indent_160);
// Begin line 96
  setline(96);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj153, *var_startPosition, 5);
  addmethod2(obj153, "linePos", &reader_lexer_linePos_161);
  set_type(obj153, 0);
// compilenode returning obj153
  return obj153;
}
Object meth_lexer_new164(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj165 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj165, self, 0);
  addmethod2(obj165, "outer", &reader_lexer_outer_166);
  adddatum2(obj165, self, 0);
// Begin line 99
  setline(99);
  if (strlit167 == NULL) {
    strlit167 = alloc_String("colon");
  }
// compilenode returning strlit167
// OBJECT CONST DEC kind
  adddatum2(obj165, strlit167, 1);
  addmethod2(obj165, "kind", &reader_lexer_kind_168);
// Begin line 100
  setline(100);
  if (strlit169 == NULL) {
    strlit169 = alloc_String(":");
  }
// compilenode returning strlit169
// OBJECT CONST DEC value
  adddatum2(obj165, strlit169, 2);
  addmethod2(obj165, "value", &reader_lexer_value_170);
// Begin line 101
  setline(101);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj165, *var_lineNumber, 3);
  addmethod2(obj165, "line", &reader_lexer_line_171);
// Begin line 102
  setline(102);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj165, *var_indentLevel, 4);
  addmethod2(obj165, "indent", &reader_lexer_indent_172);
// Begin line 103
  setline(103);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj165, *var_startPosition, 5);
  addmethod2(obj165, "linePos", &reader_lexer_linePos_173);
  set_type(obj165, 0);
// compilenode returning obj165
  return obj165;
}
Object meth_lexer_new176(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj177 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj177, self, 0);
  addmethod2(obj177, "outer", &reader_lexer_outer_178);
  adddatum2(obj177, self, 0);
// Begin line 106
  setline(106);
  if (strlit179 == NULL) {
    strlit179 = alloc_String("dot");
  }
// compilenode returning strlit179
// OBJECT CONST DEC kind
  adddatum2(obj177, strlit179, 1);
  addmethod2(obj177, "kind", &reader_lexer_kind_180);
// Begin line 107
  setline(107);
  if (strlit181 == NULL) {
    strlit181 = alloc_String(".");
  }
// compilenode returning strlit181
// OBJECT CONST DEC value
  adddatum2(obj177, strlit181, 2);
  addmethod2(obj177, "value", &reader_lexer_value_182);
// Begin line 108
  setline(108);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj177, *var_lineNumber, 3);
  addmethod2(obj177, "line", &reader_lexer_line_183);
// Begin line 109
  setline(109);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj177, *var_indentLevel, 4);
  addmethod2(obj177, "indent", &reader_lexer_indent_184);
// Begin line 110
  setline(110);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj177, *var_startPosition, 5);
  addmethod2(obj177, "linePos", &reader_lexer_linePos_185);
  set_type(obj177, 0);
// compilenode returning obj177
  return obj177;
}
Object meth_lexer_new188(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj189 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj189, self, 0);
  addmethod2(obj189, "outer", &reader_lexer_outer_190);
  adddatum2(obj189, self, 0);
// Begin line 113
  setline(113);
  if (strlit191 == NULL) {
    strlit191 = alloc_String("num");
  }
// compilenode returning strlit191
// OBJECT CONST DEC kind
  adddatum2(obj189, strlit191, 1);
  addmethod2(obj189, "kind", &reader_lexer_kind_192);
// Begin line 114
  setline(114);
// compilenode returning *var_v
// OBJECT CONST DEC value
  adddatum2(obj189, *var_v, 2);
  addmethod2(obj189, "value", &reader_lexer_value_193);
// Begin line 115
  setline(115);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj189, *var_lineNumber, 3);
  addmethod2(obj189, "line", &reader_lexer_line_194);
// Begin line 116
  setline(116);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj189, *var_indentLevel, 4);
  addmethod2(obj189, "indent", &reader_lexer_indent_195);
// Begin line 117
  setline(117);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj189, *var_startPosition, 5);
  addmethod2(obj189, "linePos", &reader_lexer_linePos_196);
  set_type(obj189, 0);
// compilenode returning obj189
  return obj189;
}
Object meth_lexer_new199(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj200 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj200, self, 0);
  addmethod2(obj200, "outer", &reader_lexer_outer_201);
  adddatum2(obj200, self, 0);
// Begin line 120
  setline(120);
  if (strlit202 == NULL) {
    strlit202 = alloc_String("keyword");
  }
// compilenode returning strlit202
// OBJECT CONST DEC kind
  adddatum2(obj200, strlit202, 1);
  addmethod2(obj200, "kind", &reader_lexer_kind_203);
// Begin line 121
  setline(121);
// compilenode returning *var_v
// OBJECT CONST DEC value
  adddatum2(obj200, *var_v, 2);
  addmethod2(obj200, "value", &reader_lexer_value_204);
// Begin line 122
  setline(122);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj200, *var_lineNumber, 3);
  addmethod2(obj200, "line", &reader_lexer_line_205);
// Begin line 123
  setline(123);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj200, *var_indentLevel, 4);
  addmethod2(obj200, "indent", &reader_lexer_indent_206);
// Begin line 124
  setline(124);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj200, *var_startPosition, 5);
  addmethod2(obj200, "linePos", &reader_lexer_linePos_207);
  set_type(obj200, 0);
// compilenode returning obj200
  return obj200;
}
Object meth_lexer_new210(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj211 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj211, self, 0);
  addmethod2(obj211, "outer", &reader_lexer_outer_212);
  adddatum2(obj211, self, 0);
// Begin line 127
  setline(127);
  if (strlit213 == NULL) {
    strlit213 = alloc_String("op");
  }
// compilenode returning strlit213
// OBJECT CONST DEC kind
  adddatum2(obj211, strlit213, 1);
  addmethod2(obj211, "kind", &reader_lexer_kind_214);
// Begin line 128
  setline(128);
// compilenode returning *var_v
// OBJECT CONST DEC value
  adddatum2(obj211, *var_v, 2);
  addmethod2(obj211, "value", &reader_lexer_value_215);
// Begin line 129
  setline(129);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj211, *var_lineNumber, 3);
  addmethod2(obj211, "line", &reader_lexer_line_216);
// Begin line 130
  setline(130);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj211, *var_indentLevel, 4);
  addmethod2(obj211, "indent", &reader_lexer_indent_217);
// Begin line 131
  setline(131);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj211, *var_startPosition, 5);
  addmethod2(obj211, "linePos", &reader_lexer_linePos_218);
  set_type(obj211, 0);
// compilenode returning obj211
  return obj211;
}
Object meth_lexer_new221(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj222 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj222, self, 0);
  addmethod2(obj222, "outer", &reader_lexer_outer_223);
  adddatum2(obj222, self, 0);
// Begin line 134
  setline(134);
  if (strlit224 == NULL) {
    strlit224 = alloc_String("arrow");
  }
// compilenode returning strlit224
// OBJECT CONST DEC kind
  adddatum2(obj222, strlit224, 1);
  addmethod2(obj222, "kind", &reader_lexer_kind_225);
// Begin line 135
  setline(135);
  if (strlit226 == NULL) {
    strlit226 = alloc_String("->");
  }
// compilenode returning strlit226
// OBJECT CONST DEC value
  adddatum2(obj222, strlit226, 2);
  addmethod2(obj222, "value", &reader_lexer_value_227);
// Begin line 136
  setline(136);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj222, *var_lineNumber, 3);
  addmethod2(obj222, "line", &reader_lexer_line_228);
// Begin line 137
  setline(137);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj222, *var_indentLevel, 4);
  addmethod2(obj222, "indent", &reader_lexer_indent_229);
// Begin line 138
  setline(138);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj222, *var_startPosition, 5);
  addmethod2(obj222, "linePos", &reader_lexer_linePos_230);
  set_type(obj222, 0);
// compilenode returning obj222
  return obj222;
}
Object meth_lexer_new233(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj234 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj234, self, 0);
  addmethod2(obj234, "outer", &reader_lexer_outer_235);
  adddatum2(obj234, self, 0);
// Begin line 141
  setline(141);
  if (strlit236 == NULL) {
    strlit236 = alloc_String("bind");
  }
// compilenode returning strlit236
// OBJECT CONST DEC kind
  adddatum2(obj234, strlit236, 1);
  addmethod2(obj234, "kind", &reader_lexer_kind_237);
// Begin line 142
  setline(142);
  if (strlit238 == NULL) {
    strlit238 = alloc_String(":=");
  }
// compilenode returning strlit238
// OBJECT CONST DEC value
  adddatum2(obj234, strlit238, 2);
  addmethod2(obj234, "value", &reader_lexer_value_239);
// Begin line 143
  setline(143);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj234, *var_lineNumber, 3);
  addmethod2(obj234, "line", &reader_lexer_line_240);
// Begin line 144
  setline(144);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj234, *var_indentLevel, 4);
  addmethod2(obj234, "indent", &reader_lexer_indent_241);
// Begin line 145
  setline(145);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj234, *var_startPosition, 5);
  addmethod2(obj234, "linePos", &reader_lexer_linePos_242);
  set_type(obj234, 0);
// compilenode returning obj234
  return obj234;
}
Object meth_lexer_new245(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj246 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj246, self, 0);
  addmethod2(obj246, "outer", &reader_lexer_outer_247);
  adddatum2(obj246, self, 0);
// Begin line 148
  setline(148);
  if (strlit248 == NULL) {
    strlit248 = alloc_String("semicolon");
  }
// compilenode returning strlit248
// OBJECT CONST DEC kind
  adddatum2(obj246, strlit248, 1);
  addmethod2(obj246, "kind", &reader_lexer_kind_249);
// Begin line 149
  setline(149);
  if (strlit250 == NULL) {
    strlit250 = alloc_String(";");
  }
// compilenode returning strlit250
// OBJECT CONST DEC value
  adddatum2(obj246, strlit250, 2);
  addmethod2(obj246, "value", &reader_lexer_value_251);
// Begin line 150
  setline(150);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj246, *var_lineNumber, 3);
  addmethod2(obj246, "line", &reader_lexer_line_252);
// Begin line 151
  setline(151);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj246, *var_indentLevel, 4);
  addmethod2(obj246, "indent", &reader_lexer_indent_253);
// Begin line 152
  setline(152);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj246, *var_startPosition, 5);
  addmethod2(obj246, "linePos", &reader_lexer_linePos_254);
  set_type(obj246, 0);
// compilenode returning obj246
  return obj246;
}
Object meth_lexer_new257(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj258 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj258, self, 0);
  addmethod2(obj258, "outer", &reader_lexer_outer_259);
  adddatum2(obj258, self, 0);
// Begin line 155
  setline(155);
  if (strlit260 == NULL) {
    strlit260 = alloc_String("lgeneric");
  }
// compilenode returning strlit260
// OBJECT CONST DEC kind
  adddatum2(obj258, strlit260, 1);
  addmethod2(obj258, "kind", &reader_lexer_kind_261);
// Begin line 156
  setline(156);
  if (strlit262 == NULL) {
    strlit262 = alloc_String("<");
  }
// compilenode returning strlit262
// OBJECT CONST DEC value
  adddatum2(obj258, strlit262, 2);
  addmethod2(obj258, "value", &reader_lexer_value_263);
// Begin line 157
  setline(157);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj258, *var_lineNumber, 3);
  addmethod2(obj258, "line", &reader_lexer_line_264);
// Begin line 158
  setline(158);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj258, *var_indentLevel, 4);
  addmethod2(obj258, "indent", &reader_lexer_indent_265);
// Begin line 159
  setline(159);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj258, *var_startPosition, 5);
  addmethod2(obj258, "linePos", &reader_lexer_linePos_266);
  set_type(obj258, 0);
// compilenode returning obj258
  return obj258;
}
Object meth_lexer_new269(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_lineNumber = closure[0];
  Object *var_indentLevel = closure[1];
  Object *var_startPosition = closure[2];
  Object obj270 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj270, self, 0);
  addmethod2(obj270, "outer", &reader_lexer_outer_271);
  adddatum2(obj270, self, 0);
// Begin line 162
  setline(162);
  if (strlit272 == NULL) {
    strlit272 = alloc_String("rgeneric");
  }
// compilenode returning strlit272
// OBJECT CONST DEC kind
  adddatum2(obj270, strlit272, 1);
  addmethod2(obj270, "kind", &reader_lexer_kind_273);
// Begin line 163
  setline(163);
  if (strlit274 == NULL) {
    strlit274 = alloc_String(">");
  }
// compilenode returning strlit274
// OBJECT CONST DEC value
  adddatum2(obj270, strlit274, 2);
  addmethod2(obj270, "value", &reader_lexer_value_275);
// Begin line 164
  setline(164);
// compilenode returning *var_lineNumber
// OBJECT CONST DEC line
  adddatum2(obj270, *var_lineNumber, 3);
  addmethod2(obj270, "line", &reader_lexer_line_276);
// Begin line 165
  setline(165);
// compilenode returning *var_indentLevel
// OBJECT CONST DEC indent
  adddatum2(obj270, *var_indentLevel, 4);
  addmethod2(obj270, "indent", &reader_lexer_indent_277);
// Begin line 166
  setline(166);
// compilenode returning *var_startPosition
// OBJECT CONST DEC linePos
  adddatum2(obj270, *var_startPosition, 5);
  addmethod2(obj270, "linePos", &reader_lexer_linePos_278);
  set_type(obj270, 0);
// compilenode returning obj270
  return obj270;
}
Object meth_lexer_modechange281(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_tokens = alloc_var();
  *var_tokens = args[0];
  Object *var_mode = alloc_var();
  *var_mode = args[1];
  Object *var_accum = alloc_var();
  *var_accum = args[2];
  Object params[1];
  Object *var_IdentifierToken = closure[0];
  Object *var_KeywordToken = closure[1];
  Object *var_StringToken = closure[2];
  Object *var_OctetsToken = closure[3];
  Object *var_CommaToken = closure[4];
  Object *var_DotToken = closure[5];
  Object *var_LBraceToken = closure[6];
  Object *var_RBraceToken = closure[7];
  Object *var_LParenToken = closure[8];
  Object *var_RParenToken = closure[9];
  Object *var_LSquareToken = closure[10];
  Object *var_RSquareToken = closure[11];
  Object *var_LGenericToken = closure[12];
  Object *var_RGenericToken = closure[13];
  Object *var_SemicolonToken = closure[14];
  Object *var_NumToken = closure[15];
  Object *var_OpToken = closure[16];
  Object *var_ArrowToken = closure[17];
  Object *var_BindToken = closure[18];
  Object *var_ColonToken = closure[19];
  Object *var_indentLevel = closure[20];
  Object *var_linePosition = closure[21];
  Object *var_startPosition = closure[22];
  Object *var_done = alloc_var();
  *var_done = undefined;
  Object *var_tok = alloc_var();
  *var_tok = undefined;
// Begin line 186
  setline(186);
// Begin line 185
  setline(185);
  Object bool282 = alloc_Boolean(0);
// compilenode returning bool282
  var_done = alloc_var();
  *var_done = bool282;
  if (bool282 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 187
  setline(187);
// Begin line 186
  setline(186);
  Object num283 = alloc_Float64(0.0);
// compilenode returning num283
  var_tok = alloc_var();
  *var_tok = num283;
  if (num283 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 314
  setline(314);
// Begin line 317
  setline(317);
// Begin line 187
  setline(187);
// compilenode returning *var_mode
  if (strlit285 == NULL) {
    strlit285 = alloc_String("n");
  }
// compilenode returning strlit285
  params[0] = strlit285;
  Object opresult287 = callmethod(*var_mode, "/=", 1, params);
// compilenode returning opresult287
// Begin line 317
  setline(317);
// Begin line 633
  setline(633);
// Begin line 187
  setline(187);
// compilenode returning *var_accum
  Object call288 = callmethod(*var_accum, "size",
    0, params);
// compilenode returning call288
// compilenode returning call288
  Object num289 = alloc_Float64(0.0);
// compilenode returning num289
  params[0] = num289;
  Object opresult291 = callmethod(call288, ">", 1, params);
// compilenode returning opresult291
  params[0] = opresult291;
  Object opresult293 = callmethod(opresult287, "|", 1, params);
// compilenode returning opresult293
  Object if284;
  if (istrue(opresult293)) {
// Begin line 198
  setline(198);
// Begin line 199
  setline(199);
// Begin line 188
  setline(188);
// compilenode returning *var_mode
  if (strlit295 == NULL) {
    strlit295 = alloc_String("i");
  }
// compilenode returning strlit295
  params[0] = strlit295;
  Object opresult297 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult297
  Object if294;
  if (istrue(opresult297)) {
// Begin line 189
  setline(189);
// compilenode returning *var_accum
// compilenode returning *var_IdentifierToken
  params[0] = *var_accum;
  Object call298 = callmethod(*var_IdentifierToken, "new",
    1, params);
// compilenode returning call298
  *var_tok = call298;
  if (call298 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 194
  setline(194);
// Begin line 196
  setline(196);
// Begin line 190
  setline(190);
// compilenode returning *var_accum
  if (strlit301 == NULL) {
    strlit301 = alloc_String("object");
  }
// compilenode returning strlit301
  params[0] = strlit301;
  Object opresult303 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult303
// Begin line 196
  setline(196);
// Begin line 190
  setline(190);
// compilenode returning *var_accum
  if (strlit304 == NULL) {
    strlit304 = alloc_String("method");
  }
// compilenode returning strlit304
  params[0] = strlit304;
  Object opresult306 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult306
  params[0] = opresult306;
  Object opresult308 = callmethod(opresult303, "|", 1, params);
// compilenode returning opresult308
// Begin line 196
  setline(196);
// Begin line 191
  setline(191);
// compilenode returning *var_accum
  if (strlit309 == NULL) {
    strlit309 = alloc_String("var");
  }
// compilenode returning strlit309
  params[0] = strlit309;
  Object opresult311 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult311
  params[0] = opresult311;
  Object opresult313 = callmethod(opresult308, "|", 1, params);
// compilenode returning opresult313
// Begin line 196
  setline(196);
// Begin line 191
  setline(191);
// compilenode returning *var_accum
  if (strlit314 == NULL) {
    strlit314 = alloc_String("type");
  }
// compilenode returning strlit314
  params[0] = strlit314;
  Object opresult316 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult316
  params[0] = opresult316;
  Object opresult318 = callmethod(opresult313, "|", 1, params);
// compilenode returning opresult318
// Begin line 196
  setline(196);
// Begin line 192
  setline(192);
// compilenode returning *var_accum
  if (strlit319 == NULL) {
    strlit319 = alloc_String("import");
  }
// compilenode returning strlit319
  params[0] = strlit319;
  Object opresult321 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult321
  params[0] = opresult321;
  Object opresult323 = callmethod(opresult318, "|", 1, params);
// compilenode returning opresult323
// Begin line 196
  setline(196);
// Begin line 192
  setline(192);
// compilenode returning *var_accum
  if (strlit324 == NULL) {
    strlit324 = alloc_String("class");
  }
// compilenode returning strlit324
  params[0] = strlit324;
  Object opresult326 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult326
  params[0] = opresult326;
  Object opresult328 = callmethod(opresult323, "|", 1, params);
// compilenode returning opresult328
// Begin line 196
  setline(196);
// Begin line 193
  setline(193);
// compilenode returning *var_accum
  if (strlit329 == NULL) {
    strlit329 = alloc_String("return");
  }
// compilenode returning strlit329
  params[0] = strlit329;
  Object opresult331 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult331
  params[0] = opresult331;
  Object opresult333 = callmethod(opresult328, "|", 1, params);
// compilenode returning opresult333
// Begin line 196
  setline(196);
// Begin line 193
  setline(193);
// compilenode returning *var_accum
  if (strlit334 == NULL) {
    strlit334 = alloc_String("def");
  }
// compilenode returning strlit334
  params[0] = strlit334;
  Object opresult336 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult336
  params[0] = opresult336;
  Object opresult338 = callmethod(opresult333, "|", 1, params);
// compilenode returning opresult338
  Object if300;
  if (istrue(opresult338)) {
// Begin line 194
  setline(194);
// compilenode returning *var_accum
// compilenode returning *var_KeywordToken
  params[0] = *var_accum;
  Object call339 = callmethod(*var_KeywordToken, "new",
    1, params);
// compilenode returning call339
  *var_tok = call339;
  if (call339 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if300 = nothing;
  } else {
  }
// compilenode returning if300
// Begin line 196
  setline(196);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call341 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call341
// Begin line 198
  setline(198);
// Begin line 197
  setline(197);
  Object bool342 = alloc_Boolean(1);
// compilenode returning bool342
  *var_done = bool342;
  if (bool342 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if294 = nothing;
  } else {
  }
// compilenode returning if294
// Begin line 203
  setline(203);
// Begin line 204
  setline(204);
// Begin line 199
  setline(199);
// compilenode returning *var_mode
  if (strlit345 == NULL) {
    strlit345 = alloc_String("I");
  }
// compilenode returning strlit345
  params[0] = strlit345;
  Object opresult347 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult347
  Object if344;
  if (istrue(opresult347)) {
// Begin line 200
  setline(200);
// compilenode returning *var_accum
// compilenode returning *var_IdentifierToken
  params[0] = *var_accum;
  Object call348 = callmethod(*var_IdentifierToken, "new",
    1, params);
// compilenode returning call348
  *var_tok = call348;
  if (call348 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 201
  setline(201);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call350 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call350
// Begin line 203
  setline(203);
// Begin line 202
  setline(202);
  Object bool351 = alloc_Boolean(1);
// compilenode returning bool351
  *var_done = bool351;
  if (bool351 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if344 = nothing;
  } else {
  }
// compilenode returning if344
// Begin line 208
  setline(208);
// Begin line 209
  setline(209);
// Begin line 204
  setline(204);
// compilenode returning *var_mode
  if (strlit354 == NULL) {
    strlit354 = alloc_String("""\x22""");
  }
// compilenode returning strlit354
  params[0] = strlit354;
  Object opresult356 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult356
  Object if353;
  if (istrue(opresult356)) {
// Begin line 205
  setline(205);
// compilenode returning *var_accum
// compilenode returning *var_StringToken
  params[0] = *var_accum;
  Object call357 = callmethod(*var_StringToken, "new",
    1, params);
// compilenode returning call357
  *var_tok = call357;
  if (call357 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 206
  setline(206);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call359 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call359
// Begin line 208
  setline(208);
// Begin line 207
  setline(207);
  Object bool360 = alloc_Boolean(1);
// compilenode returning bool360
  *var_done = bool360;
  if (bool360 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if353 = nothing;
  } else {
  }
// compilenode returning if353
// Begin line 213
  setline(213);
// Begin line 214
  setline(214);
// Begin line 209
  setline(209);
// compilenode returning *var_mode
  if (strlit363 == NULL) {
    strlit363 = alloc_String("x");
  }
// compilenode returning strlit363
  params[0] = strlit363;
  Object opresult365 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult365
  Object if362;
  if (istrue(opresult365)) {
// Begin line 210
  setline(210);
// compilenode returning *var_accum
// compilenode returning *var_OctetsToken
  params[0] = *var_accum;
  Object call366 = callmethod(*var_OctetsToken, "new",
    1, params);
// compilenode returning call366
  *var_tok = call366;
  if (call366 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 211
  setline(211);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call368 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call368
// Begin line 213
  setline(213);
// Begin line 212
  setline(212);
  Object bool369 = alloc_Boolean(1);
// compilenode returning bool369
  *var_done = bool369;
  if (bool369 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if362 = nothing;
  } else {
  }
// compilenode returning if362
// Begin line 218
  setline(218);
// Begin line 219
  setline(219);
// Begin line 214
  setline(214);
// compilenode returning *var_mode
  if (strlit372 == NULL) {
    strlit372 = alloc_String(",");
  }
// compilenode returning strlit372
  params[0] = strlit372;
  Object opresult374 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult374
  Object if371;
  if (istrue(opresult374)) {
// Begin line 216
  setline(216);
// Begin line 633
  setline(633);
// Begin line 215
  setline(215);
// compilenode returning *var_CommaToken
  Object call375 = callmethod(*var_CommaToken, "new",
    0, params);
// compilenode returning call375
// compilenode returning call375
  *var_tok = call375;
  if (call375 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 216
  setline(216);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call377 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call377
// Begin line 218
  setline(218);
// Begin line 217
  setline(217);
  Object bool378 = alloc_Boolean(1);
// compilenode returning bool378
  *var_done = bool378;
  if (bool378 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if371 = nothing;
  } else {
  }
// compilenode returning if371
// Begin line 223
  setline(223);
// Begin line 224
  setline(224);
// Begin line 219
  setline(219);
// compilenode returning *var_mode
  if (strlit381 == NULL) {
    strlit381 = alloc_String(".");
  }
// compilenode returning strlit381
  params[0] = strlit381;
  Object opresult383 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult383
  Object if380;
  if (istrue(opresult383)) {
// Begin line 221
  setline(221);
// Begin line 633
  setline(633);
// Begin line 220
  setline(220);
// compilenode returning *var_DotToken
  Object call384 = callmethod(*var_DotToken, "new",
    0, params);
// compilenode returning call384
// compilenode returning call384
  *var_tok = call384;
  if (call384 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 221
  setline(221);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call386 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call386
// Begin line 223
  setline(223);
// Begin line 222
  setline(222);
  Object bool387 = alloc_Boolean(1);
// compilenode returning bool387
  *var_done = bool387;
  if (bool387 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if380 = nothing;
  } else {
  }
// compilenode returning if380
// Begin line 228
  setline(228);
// Begin line 229
  setline(229);
// Begin line 224
  setline(224);
// compilenode returning *var_mode
  if (strlit390 == NULL) {
    strlit390 = alloc_String("{");
  }
// compilenode returning strlit390
  params[0] = strlit390;
  Object opresult392 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult392
  Object if389;
  if (istrue(opresult392)) {
// Begin line 226
  setline(226);
// Begin line 633
  setline(633);
// Begin line 225
  setline(225);
// compilenode returning *var_LBraceToken
  Object call393 = callmethod(*var_LBraceToken, "new",
    0, params);
// compilenode returning call393
// compilenode returning call393
  *var_tok = call393;
  if (call393 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 226
  setline(226);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call395 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call395
// Begin line 228
  setline(228);
// Begin line 227
  setline(227);
  Object bool396 = alloc_Boolean(1);
// compilenode returning bool396
  *var_done = bool396;
  if (bool396 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if389 = nothing;
  } else {
  }
// compilenode returning if389
// Begin line 233
  setline(233);
// Begin line 234
  setline(234);
// Begin line 229
  setline(229);
// compilenode returning *var_mode
  if (strlit399 == NULL) {
    strlit399 = alloc_String("}");
  }
// compilenode returning strlit399
  params[0] = strlit399;
  Object opresult401 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult401
  Object if398;
  if (istrue(opresult401)) {
// Begin line 231
  setline(231);
// Begin line 633
  setline(633);
// Begin line 230
  setline(230);
// compilenode returning *var_RBraceToken
  Object call402 = callmethod(*var_RBraceToken, "new",
    0, params);
// compilenode returning call402
// compilenode returning call402
  *var_tok = call402;
  if (call402 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 231
  setline(231);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call404 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call404
// Begin line 233
  setline(233);
// Begin line 232
  setline(232);
  Object bool405 = alloc_Boolean(1);
// compilenode returning bool405
  *var_done = bool405;
  if (bool405 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if398 = nothing;
  } else {
  }
// compilenode returning if398
// Begin line 238
  setline(238);
// Begin line 239
  setline(239);
// Begin line 234
  setline(234);
// compilenode returning *var_mode
  if (strlit408 == NULL) {
    strlit408 = alloc_String("(");
  }
// compilenode returning strlit408
  params[0] = strlit408;
  Object opresult410 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult410
  Object if407;
  if (istrue(opresult410)) {
// Begin line 236
  setline(236);
// Begin line 633
  setline(633);
// Begin line 235
  setline(235);
// compilenode returning *var_LParenToken
  Object call411 = callmethod(*var_LParenToken, "new",
    0, params);
// compilenode returning call411
// compilenode returning call411
  *var_tok = call411;
  if (call411 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 236
  setline(236);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call413 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call413
// Begin line 238
  setline(238);
// Begin line 237
  setline(237);
  Object bool414 = alloc_Boolean(1);
// compilenode returning bool414
  *var_done = bool414;
  if (bool414 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if407 = nothing;
  } else {
  }
// compilenode returning if407
// Begin line 243
  setline(243);
// Begin line 244
  setline(244);
// Begin line 239
  setline(239);
// compilenode returning *var_mode
  if (strlit417 == NULL) {
    strlit417 = alloc_String(")");
  }
// compilenode returning strlit417
  params[0] = strlit417;
  Object opresult419 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult419
  Object if416;
  if (istrue(opresult419)) {
// Begin line 241
  setline(241);
// Begin line 633
  setline(633);
// Begin line 240
  setline(240);
// compilenode returning *var_RParenToken
  Object call420 = callmethod(*var_RParenToken, "new",
    0, params);
// compilenode returning call420
// compilenode returning call420
  *var_tok = call420;
  if (call420 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 241
  setline(241);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call422 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call422
// Begin line 243
  setline(243);
// Begin line 242
  setline(242);
  Object bool423 = alloc_Boolean(1);
// compilenode returning bool423
  *var_done = bool423;
  if (bool423 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if416 = nothing;
  } else {
  }
// compilenode returning if416
// Begin line 248
  setline(248);
// Begin line 249
  setline(249);
// Begin line 244
  setline(244);
// compilenode returning *var_mode
  if (strlit426 == NULL) {
    strlit426 = alloc_String("[");
  }
// compilenode returning strlit426
  params[0] = strlit426;
  Object opresult428 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult428
  Object if425;
  if (istrue(opresult428)) {
// Begin line 246
  setline(246);
// Begin line 633
  setline(633);
// Begin line 245
  setline(245);
// compilenode returning *var_LSquareToken
  Object call429 = callmethod(*var_LSquareToken, "new",
    0, params);
// compilenode returning call429
// compilenode returning call429
  *var_tok = call429;
  if (call429 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 246
  setline(246);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call431 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call431
// Begin line 248
  setline(248);
// Begin line 247
  setline(247);
  Object bool432 = alloc_Boolean(1);
// compilenode returning bool432
  *var_done = bool432;
  if (bool432 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if425 = nothing;
  } else {
  }
// compilenode returning if425
// Begin line 253
  setline(253);
// Begin line 254
  setline(254);
// Begin line 249
  setline(249);
// compilenode returning *var_mode
  if (strlit435 == NULL) {
    strlit435 = alloc_String("]");
  }
// compilenode returning strlit435
  params[0] = strlit435;
  Object opresult437 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult437
  Object if434;
  if (istrue(opresult437)) {
// Begin line 251
  setline(251);
// Begin line 633
  setline(633);
// Begin line 250
  setline(250);
// compilenode returning *var_RSquareToken
  Object call438 = callmethod(*var_RSquareToken, "new",
    0, params);
// compilenode returning call438
// compilenode returning call438
  *var_tok = call438;
  if (call438 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 251
  setline(251);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call440 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call440
// Begin line 253
  setline(253);
// Begin line 252
  setline(252);
  Object bool441 = alloc_Boolean(1);
// compilenode returning bool441
  *var_done = bool441;
  if (bool441 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if434 = nothing;
  } else {
  }
// compilenode returning if434
// Begin line 258
  setline(258);
// Begin line 259
  setline(259);
// Begin line 254
  setline(254);
// compilenode returning *var_mode
  if (strlit444 == NULL) {
    strlit444 = alloc_String("<");
  }
// compilenode returning strlit444
  params[0] = strlit444;
  Object opresult446 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult446
  Object if443;
  if (istrue(opresult446)) {
// Begin line 256
  setline(256);
// Begin line 633
  setline(633);
// Begin line 255
  setline(255);
// compilenode returning *var_LGenericToken
  Object call447 = callmethod(*var_LGenericToken, "new",
    0, params);
// compilenode returning call447
// compilenode returning call447
  *var_tok = call447;
  if (call447 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 256
  setline(256);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call449 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call449
// Begin line 258
  setline(258);
// Begin line 257
  setline(257);
  Object bool450 = alloc_Boolean(1);
// compilenode returning bool450
  *var_done = bool450;
  if (bool450 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if443 = nothing;
  } else {
  }
// compilenode returning if443
// Begin line 263
  setline(263);
// Begin line 264
  setline(264);
// Begin line 259
  setline(259);
// compilenode returning *var_mode
  if (strlit453 == NULL) {
    strlit453 = alloc_String(">");
  }
// compilenode returning strlit453
  params[0] = strlit453;
  Object opresult455 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult455
  Object if452;
  if (istrue(opresult455)) {
// Begin line 261
  setline(261);
// Begin line 633
  setline(633);
// Begin line 260
  setline(260);
// compilenode returning *var_RGenericToken
  Object call456 = callmethod(*var_RGenericToken, "new",
    0, params);
// compilenode returning call456
// compilenode returning call456
  *var_tok = call456;
  if (call456 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 261
  setline(261);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call458 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call458
// Begin line 263
  setline(263);
// Begin line 262
  setline(262);
  Object bool459 = alloc_Boolean(1);
// compilenode returning bool459
  *var_done = bool459;
  if (bool459 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if452 = nothing;
  } else {
  }
// compilenode returning if452
// Begin line 268
  setline(268);
// Begin line 269
  setline(269);
// Begin line 264
  setline(264);
// compilenode returning *var_mode
  if (strlit462 == NULL) {
    strlit462 = alloc_String(";");
  }
// compilenode returning strlit462
  params[0] = strlit462;
  Object opresult464 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult464
  Object if461;
  if (istrue(opresult464)) {
// Begin line 266
  setline(266);
// Begin line 633
  setline(633);
// Begin line 265
  setline(265);
// compilenode returning *var_SemicolonToken
  Object call465 = callmethod(*var_SemicolonToken, "new",
    0, params);
// compilenode returning call465
// compilenode returning call465
  *var_tok = call465;
  if (call465 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 266
  setline(266);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call467 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call467
// Begin line 268
  setline(268);
// Begin line 267
  setline(267);
  Object bool468 = alloc_Boolean(1);
// compilenode returning bool468
  *var_done = bool468;
  if (bool468 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if461 = nothing;
  } else {
  }
// compilenode returning if461
// Begin line 285
  setline(285);
// Begin line 286
  setline(286);
// Begin line 269
  setline(269);
// compilenode returning *var_mode
  if (strlit471 == NULL) {
    strlit471 = alloc_String("m");
  }
// compilenode returning strlit471
  params[0] = strlit471;
  Object opresult473 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult473
  Object if470;
  if (istrue(opresult473)) {
// Begin line 270
  setline(270);
// compilenode returning *var_accum
// compilenode returning *var_NumToken
  params[0] = *var_accum;
  Object call474 = callmethod(*var_NumToken, "new",
    1, params);
// compilenode returning call474
  *var_tok = call474;
  if (call474 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 279
  setline(279);
// Begin line 283
  setline(283);
// Begin line 633
  setline(633);
// Begin line 271
  setline(271);
// compilenode returning *var_tokens
  Object call477 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call477
// compilenode returning call477
  Object num478 = alloc_Float64(1.0);
// compilenode returning num478
  params[0] = num478;
  Object opresult480 = callmethod(call477, ">", 1, params);
// compilenode returning opresult480
  Object if476;
  if (istrue(opresult480)) {
// Begin line 279
  setline(279);
// Begin line 282
  setline(282);
// Begin line 633
  setline(633);
// Begin line 282
  setline(282);
// Begin line 633
  setline(633);
// Begin line 272
  setline(272);
// compilenode returning *var_tokens
  Object call482 = callmethod(*var_tokens, "last",
    0, params);
// compilenode returning call482
// compilenode returning call482
  Object call483 = callmethod(call482, "kind",
    0, params);
// compilenode returning call483
// compilenode returning call483
  if (strlit484 == NULL) {
    strlit484 = alloc_String("dot");
  }
// compilenode returning strlit484
  params[0] = strlit484;
  Object opresult486 = callmethod(call483, "==", 1, params);
// compilenode returning opresult486
  Object if481;
  if (istrue(opresult486)) {
// Begin line 273
  setline(273);
// Begin line 633
  setline(633);
// Begin line 273
  setline(273);
// compilenode returning *var_tokens
  Object call487 = callmethod(*var_tokens, "pop",
    0, params);
// compilenode returning call487
// compilenode returning call487
// Begin line 279
  setline(279);
// Begin line 281
  setline(281);
// Begin line 633
  setline(633);
// Begin line 281
  setline(281);
// Begin line 633
  setline(633);
// Begin line 274
  setline(274);
// compilenode returning *var_tokens
  Object call489 = callmethod(*var_tokens, "last",
    0, params);
// compilenode returning call489
// compilenode returning call489
  Object call490 = callmethod(call489, "kind",
    0, params);
// compilenode returning call490
// compilenode returning call490
  if (strlit491 == NULL) {
    strlit491 = alloc_String("num");
  }
// compilenode returning strlit491
  params[0] = strlit491;
  Object opresult493 = callmethod(call490, "==", 1, params);
// compilenode returning opresult493
  Object if488;
  if (istrue(opresult493)) {
// Begin line 276
  setline(276);
// Begin line 633
  setline(633);
// Begin line 275
  setline(275);
// compilenode returning *var_tokens
  Object call494 = callmethod(*var_tokens, "pop",
    0, params);
// compilenode returning call494
// compilenode returning call494
  *var_tok = call494;
  if (call494 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 276
  setline(276);
// Begin line 633
  setline(633);
// Begin line 276
  setline(276);
// compilenode returning *var_tok
  Object call496 = callmethod(*var_tok, "value",
    0, params);
// compilenode returning call496
// compilenode returning call496
  if (strlit497 == NULL) {
    strlit497 = alloc_String(".");
  }
// compilenode returning strlit497
  params[0] = strlit497;
  Object opresult499 = callmethod(call496, "++", 1, params);
// compilenode returning opresult499
// compilenode returning *var_accum
  params[0] = *var_accum;
  Object opresult501 = callmethod(opresult499, "++", 1, params);
// compilenode returning opresult501
// compilenode returning *var_NumToken
  params[0] = opresult501;
  Object call502 = callmethod(*var_NumToken, "new",
    1, params);
// compilenode returning call502
  *var_tok = call502;
  if (call502 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if488 = nothing;
  } else {
// Begin line 279
  setline(279);
// Begin line 278
  setline(278);
  if (strlit504 == NULL) {
    strlit504 = alloc_String("found .");
  }
// compilenode returning strlit504
// compilenode returning *var_accum
  params[0] = *var_accum;
  Object opresult506 = callmethod(strlit504, "++", 1, params);
// compilenode returning opresult506
// Begin line 279
  setline(279);
  if (strlit507 == NULL) {
    strlit507 = alloc_String(", expected term");
  }
// compilenode returning strlit507
  params[0] = strlit507;
  Object opresult509 = callmethod(opresult506, "++", 1, params);
// compilenode returning opresult509
// Begin line 278
  setline(278);
// compilenode returning module_util
  params[0] = opresult509;
  Object call510 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call510
    if488 = call510;
  }
// compilenode returning if488
    if481 = if488;
  } else {
  }
// compilenode returning if481
    if476 = if481;
  } else {
  }
// compilenode returning if476
// Begin line 283
  setline(283);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call511 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call511
// Begin line 285
  setline(285);
// Begin line 284
  setline(284);
  Object bool512 = alloc_Boolean(1);
// compilenode returning bool512
  *var_done = bool512;
  if (bool512 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if470 = nothing;
  } else {
  }
// compilenode returning if470
// Begin line 299
  setline(299);
// Begin line 300
  setline(300);
// Begin line 286
  setline(286);
// compilenode returning *var_mode
  if (strlit515 == NULL) {
    strlit515 = alloc_String("o");
  }
// compilenode returning strlit515
  params[0] = strlit515;
  Object opresult517 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult517
  Object if514;
  if (istrue(opresult517)) {
// Begin line 287
  setline(287);
// compilenode returning *var_accum
// compilenode returning *var_OpToken
  params[0] = *var_accum;
  Object call518 = callmethod(*var_OpToken, "new",
    1, params);
// compilenode returning call518
  *var_tok = call518;
  if (call518 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 290
  setline(290);
// Begin line 291
  setline(291);
// Begin line 288
  setline(288);
// compilenode returning *var_accum
  if (strlit521 == NULL) {
    strlit521 = alloc_String("->");
  }
// compilenode returning strlit521
  params[0] = strlit521;
  Object opresult523 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult523
  Object if520;
  if (istrue(opresult523)) {
// Begin line 290
  setline(290);
// Begin line 633
  setline(633);
// Begin line 289
  setline(289);
// compilenode returning *var_ArrowToken
  Object call524 = callmethod(*var_ArrowToken, "new",
    0, params);
// compilenode returning call524
// compilenode returning call524
  *var_tok = call524;
  if (call524 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if520 = nothing;
  } else {
  }
// compilenode returning if520
// Begin line 293
  setline(293);
// Begin line 294
  setline(294);
// Begin line 291
  setline(291);
// compilenode returning *var_accum
  if (strlit527 == NULL) {
    strlit527 = alloc_String(":=");
  }
// compilenode returning strlit527
  params[0] = strlit527;
  Object opresult529 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult529
  Object if526;
  if (istrue(opresult529)) {
// Begin line 293
  setline(293);
// Begin line 633
  setline(633);
// Begin line 292
  setline(292);
// compilenode returning *var_BindToken
  Object call530 = callmethod(*var_BindToken, "new",
    0, params);
// compilenode returning call530
// compilenode returning call530
  *var_tok = call530;
  if (call530 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if526 = nothing;
  } else {
  }
// compilenode returning if526
// Begin line 296
  setline(296);
// Begin line 297
  setline(297);
// Begin line 294
  setline(294);
// compilenode returning *var_accum
  if (strlit533 == NULL) {
    strlit533 = alloc_String(":");
  }
// compilenode returning strlit533
  params[0] = strlit533;
  Object opresult535 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult535
  Object if532;
  if (istrue(opresult535)) {
// Begin line 296
  setline(296);
// Begin line 633
  setline(633);
// Begin line 295
  setline(295);
// compilenode returning *var_ColonToken
  Object call536 = callmethod(*var_ColonToken, "new",
    0, params);
// compilenode returning call536
// compilenode returning call536
  *var_tok = call536;
  if (call536 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if532 = nothing;
  } else {
  }
// compilenode returning if532
// Begin line 297
  setline(297);
// compilenode returning *var_tok
// compilenode returning *var_tokens
  params[0] = *var_tok;
  Object call538 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call538
// Begin line 299
  setline(299);
// Begin line 298
  setline(298);
  Object bool539 = alloc_Boolean(1);
// compilenode returning bool539
  *var_done = bool539;
  if (bool539 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if514 = nothing;
  } else {
  }
// compilenode returning if514
// Begin line 303
  setline(303);
// Begin line 304
  setline(304);
// Begin line 300
  setline(300);
// compilenode returning *var_mode
  if (strlit542 == NULL) {
    strlit542 = alloc_String("d");
  }
// compilenode returning strlit542
  params[0] = strlit542;
  Object opresult544 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult544
  Object if541;
  if (istrue(opresult544)) {
// Begin line 302
  setline(302);
// Begin line 633
  setline(633);
// Begin line 301
  setline(301);
// compilenode returning *var_accum
  Object call545 = callmethod(*var_accum, "size",
    0, params);
// compilenode returning call545
// compilenode returning call545
  *var_indentLevel = call545;
  if (call545 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 303
  setline(303);
// Begin line 302
  setline(302);
  Object bool547 = alloc_Boolean(1);
// compilenode returning bool547
  *var_done = bool547;
  if (bool547 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if541 = nothing;
  } else {
  }
// compilenode returning if541
// Begin line 306
  setline(306);
// Begin line 307
  setline(307);
// Begin line 304
  setline(304);
// compilenode returning *var_mode
  if (strlit550 == NULL) {
    strlit550 = alloc_String("n");
  }
// compilenode returning strlit550
  params[0] = strlit550;
  Object opresult552 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult552
  Object if549;
  if (istrue(opresult552)) {
// Begin line 306
  setline(306);
// Begin line 305
  setline(305);
  Object bool553 = alloc_Boolean(1);
// compilenode returning bool553
  *var_done = bool553;
  if (bool553 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if549 = nothing;
  } else {
  }
// compilenode returning if549
// Begin line 309
  setline(309);
// Begin line 310
  setline(310);
// Begin line 307
  setline(307);
// compilenode returning *var_mode
  if (strlit556 == NULL) {
    strlit556 = alloc_String("c");
  }
// compilenode returning strlit556
  params[0] = strlit556;
  Object opresult558 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult558
  Object if555;
  if (istrue(opresult558)) {
// Begin line 309
  setline(309);
// Begin line 308
  setline(308);
  Object bool559 = alloc_Boolean(1);
// compilenode returning bool559
  *var_done = bool559;
  if (bool559 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if555 = nothing;
  } else {
  }
// compilenode returning if555
// Begin line 314
  setline(314);
// Begin line 310
  setline(310);
// compilenode returning *var_done
  Object if561;
  if (istrue(*var_done)) {
    if561 = undefined;
  } else {
// Begin line 314
  setline(314);
// Begin line 313
  setline(313);
  if (strlit562 == NULL) {
    strlit562 = alloc_String("Lexing error: no handler for mode ");
  }
// compilenode returning strlit562
// compilenode returning *var_mode
  params[0] = *var_mode;
  Object opresult564 = callmethod(strlit562, "++", 1, params);
// compilenode returning opresult564
// Begin line 314
  setline(314);
  if (strlit565 == NULL) {
    strlit565 = alloc_String(" with accum ");
  }
// compilenode returning strlit565
  params[0] = strlit565;
  Object opresult567 = callmethod(opresult564, "++", 1, params);
// compilenode returning opresult567
// compilenode returning *var_accum
  params[0] = *var_accum;
  Object opresult569 = callmethod(opresult567, "++", 1, params);
// compilenode returning opresult569
// Begin line 313
  setline(313);
// compilenode returning module_util
  params[0] = opresult569;
  Object call570 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call570
    if561 = call570;
  }
// compilenode returning if561
    if284 = if561;
  } else {
  }
// compilenode returning if284
// Begin line 318
  setline(318);
// Begin line 317
  setline(317);
// compilenode returning *var_linePosition
  *var_startPosition = *var_linePosition;
  if (*var_linePosition == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_lexer_isidentifierchar572(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_ov = alloc_var();
  *var_ov = args[0];
  Object params[1];
// Begin line 329
  setline(329);
// Begin line 324
  setline(324);
// compilenode returning *var_ov
// compilenode returning module_unicode
  params[0] = *var_ov;
  Object call574 = callmethod(module_unicode, "isLetter",
    1, params);
// compilenode returning call574
// compilenode returning *var_ov
// compilenode returning module_unicode
  params[0] = *var_ov;
  Object call575 = callmethod(module_unicode, "isNumber",
    1, params);
// compilenode returning call575
  params[0] = call575;
  Object opresult577 = callmethod(call574, "|", 1, params);
// compilenode returning opresult577
// Begin line 325
  setline(325);
// compilenode returning *var_ov
  Object num578 = alloc_Float64(95.0);
// compilenode returning num578
  params[0] = num578;
  Object opresult580 = callmethod(*var_ov, "==", 1, params);
// compilenode returning opresult580
  params[0] = opresult580;
  Object opresult582 = callmethod(opresult577, "|", 1, params);
// compilenode returning opresult582
// Begin line 324
  setline(324);
// Begin line 325
  setline(325);
// compilenode returning *var_ov
  Object num583 = alloc_Float64(39.0);
// compilenode returning num583
  params[0] = num583;
  Object opresult585 = callmethod(*var_ov, "==", 1, params);
// compilenode returning opresult585
  params[0] = opresult585;
  Object opresult587 = callmethod(opresult582, "|", 1, params);
// compilenode returning opresult587
  Object if573;
  if (istrue(opresult587)) {
// Begin line 327
  setline(327);
  Object bool588 = alloc_Boolean(1);
// compilenode returning bool588
    if573 = bool588;
  } else {
// Begin line 329
  setline(329);
  Object bool589 = alloc_Boolean(0);
// compilenode returning bool589
    if573 = bool589;
  }
// compilenode returning if573
  return if573;
}
Object meth_lexer_isoperatorchar590(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object *var_ordval = alloc_var();
  *var_ordval = args[1];
  Object params[1];
  Object *var_ret = alloc_var();
  *var_ret = undefined;
// Begin line 336
  setline(336);
// Begin line 335
  setline(335);
  Object bool591 = alloc_Boolean(0);
// compilenode returning bool591
  var_ret = alloc_var();
  *var_ret = bool591;
  if (bool591 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 342
  setline(342);
// Begin line 343
  setline(343);
// Begin line 336
  setline(336);
// compilenode returning *var_c
  if (strlit593 == NULL) {
    strlit593 = alloc_String("-");
  }
// compilenode returning strlit593
  params[0] = strlit593;
  Object opresult595 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult595
// Begin line 343
  setline(343);
// Begin line 336
  setline(336);
// compilenode returning *var_c
  if (strlit596 == NULL) {
    strlit596 = alloc_String("&");
  }
// compilenode returning strlit596
  params[0] = strlit596;
  Object opresult598 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult598
  params[0] = opresult598;
  Object opresult600 = callmethod(opresult595, "|", 1, params);
// compilenode returning opresult600
// Begin line 343
  setline(343);
// Begin line 336
  setline(336);
// compilenode returning *var_c
  if (strlit601 == NULL) {
    strlit601 = alloc_String("|");
  }
// compilenode returning strlit601
  params[0] = strlit601;
  Object opresult603 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult603
  params[0] = opresult603;
  Object opresult605 = callmethod(opresult600, "|", 1, params);
// compilenode returning opresult605
// Begin line 343
  setline(343);
// Begin line 336
  setline(336);
// compilenode returning *var_c
  if (strlit606 == NULL) {
    strlit606 = alloc_String(":");
  }
// compilenode returning strlit606
  params[0] = strlit606;
  Object opresult608 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult608
  params[0] = opresult608;
  Object opresult610 = callmethod(opresult605, "|", 1, params);
// compilenode returning opresult610
// Begin line 343
  setline(343);
// Begin line 337
  setline(337);
// compilenode returning *var_c
  if (strlit611 == NULL) {
    strlit611 = alloc_String("%");
  }
// compilenode returning strlit611
  params[0] = strlit611;
  Object opresult613 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult613
  params[0] = opresult613;
  Object opresult615 = callmethod(opresult610, "|", 1, params);
// compilenode returning opresult615
// Begin line 343
  setline(343);
// Begin line 338
  setline(338);
// compilenode returning *var_c
  if (strlit616 == NULL) {
    strlit616 = alloc_String("*");
  }
// compilenode returning strlit616
  params[0] = strlit616;
  Object opresult618 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult618
  params[0] = opresult618;
  Object opresult620 = callmethod(opresult615, "|", 1, params);
// compilenode returning opresult620
// Begin line 343
  setline(343);
// Begin line 338
  setline(338);
// compilenode returning *var_c
  if (strlit621 == NULL) {
    strlit621 = alloc_String("/");
  }
// compilenode returning strlit621
  params[0] = strlit621;
  Object opresult623 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult623
  params[0] = opresult623;
  Object opresult625 = callmethod(opresult620, "|", 1, params);
// compilenode returning opresult625
// Begin line 343
  setline(343);
// Begin line 338
  setline(338);
// compilenode returning *var_c
  if (strlit626 == NULL) {
    strlit626 = alloc_String("+");
  }
// compilenode returning strlit626
  params[0] = strlit626;
  Object opresult628 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult628
  params[0] = opresult628;
  Object opresult630 = callmethod(opresult625, "|", 1, params);
// compilenode returning opresult630
// Begin line 343
  setline(343);
// Begin line 338
  setline(338);
// compilenode returning *var_c
  if (strlit631 == NULL) {
    strlit631 = alloc_String("!");
  }
// compilenode returning strlit631
  params[0] = strlit631;
  Object opresult633 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult633
  params[0] = opresult633;
  Object opresult635 = callmethod(opresult630, "|", 1, params);
// compilenode returning opresult635
  Object if592;
  if (istrue(opresult635)) {
// Begin line 340
  setline(340);
// Begin line 339
  setline(339);
  Object bool636 = alloc_Boolean(1);
// compilenode returning bool636
  *var_ret = bool636;
  if (bool636 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if592 = nothing;
  } else {
// Begin line 342
  setline(342);
// Begin line 340
  setline(340);
// compilenode returning *var_ordval
// compilenode returning module_unicode
  params[0] = *var_ordval;
  Object call639 = callmethod(module_unicode, "isSymbolMathematical",
    1, params);
// compilenode returning call639
  Object if638;
  if (istrue(call639)) {
// Begin line 342
  setline(342);
// Begin line 341
  setline(341);
  Object bool640 = alloc_Boolean(1);
// compilenode returning bool640
  *var_ret = bool640;
  if (bool640 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if638 = nothing;
  } else {
  }
// compilenode returning if638
    if592 = if638;
  }
// compilenode returning if592
// Begin line 343
  setline(343);
// compilenode returning *var_ret
  return *var_ret;
}
Object meth_lexer_lexinput642(Object self, int nparams, Object *args, int32_t flags) {
  Object params[1];
// Begin line 349
  setline(349);
// Begin line 633
  setline(633);
// Begin line 349
  setline(349);
// compilenode returning module_util
  Object call643 = callmethod(module_util, "infile",
    0, params);
// compilenode returning call643
// compilenode returning call643
// Begin line 350
  setline(350);
// compilenode returning self
  params[0] = call643;
  Object call644 = callmethod(self, "lexfile",
    1, params);
// compilenode returning call644
  return call644;
}
Object meth_lexer_apply670(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[3];
  Object *var_linePosition = closure[0];
  Object *var_lineNumber = closure[1];
  Object *var_atStart = closure[2];
  Object *var_mode = closure[3];
  Object *var_newmode = closure[4];
  Object *var_instr = closure[5];
  Object *var_inBackticks = closure[6];
  Object *var_prev = closure[7];
  Object *var_tokens = closure[8];
  Object *var_accum = closure[9];
  Object *var_escaped = closure[10];
  Object *var_interpString = closure[11];
  Object *var_backtickIdent = closure[12];
  Object *var_interpdepth = closure[13];
  Object *var_unichars = closure[14];
  Object *var_codepoint = closure[15];
  Object *var_startPosition = closure[16];
  Object self = *closure[17];
  Object *var_ct = alloc_var();
  *var_ct = undefined;
  Object *var_ordval = alloc_var();
  *var_ordval = undefined;
// Begin line 374
  setline(374);
// Begin line 373
  setline(373);
// compilenode returning *var_linePosition
  Object num671 = alloc_Float64(1.0);
// compilenode returning num671
  params[0] = num671;
  Object sum673 = callmethod(*var_linePosition, "+", 1, params);
// compilenode returning sum673
  *var_linePosition = sum673;
  if (sum673 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 374
  setline(374);
// compilenode returning *var_lineNumber
// compilenode returning *var_linePosition
// compilenode returning module_util
  params[0] = *var_lineNumber;
  params[1] = *var_linePosition;
  Object call675 = callmethod(module_util, "setPosition",
    2, params);
// compilenode returning call675
// Begin line 376
  setline(376);
// Begin line 375
  setline(375);
  if (strlit676 == NULL) {
    strlit676 = alloc_String("");
  }
// compilenode returning strlit676
  var_ct = alloc_var();
  *var_ct = strlit676;
  if (strlit676 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 377
  setline(377);
// Begin line 633
  setline(633);
// Begin line 376
  setline(376);
// compilenode returning *var_c
  Object call677 = callmethod(*var_c, "ord",
    0, params);
// compilenode returning call677
// compilenode returning call677
  var_ordval = alloc_var();
  *var_ordval = call677;
  if (call677 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 382
  setline(382);
// Begin line 377
  setline(377);
// compilenode returning *var_ordval
// compilenode returning module_unicode
  params[0] = *var_ordval;
  Object call679 = callmethod(module_unicode, "isSeparator",
    1, params);
// compilenode returning call679
// compilenode returning *var_ordval
  Object num680 = alloc_Float64(32.0);
// compilenode returning num680
  params[0] = num680;
  Object opresult682 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult682
  params[0] = opresult682;
  Object opresult684 = callmethod(call679, "&", 1, params);
// compilenode returning opresult684
// Begin line 378
  setline(378);
// compilenode returning *var_ordval
  Object num685 = alloc_Float64(8232.0);
// compilenode returning num685
  params[0] = num685;
  Object opresult687 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult687
  params[0] = opresult687;
  Object opresult689 = callmethod(opresult684, "&", 1, params);
// compilenode returning opresult689
// Begin line 377
  setline(377);
// Begin line 378
  setline(378);
// compilenode returning *var_ordval
  Object num690 = alloc_Float64(9.0);
// compilenode returning num690
  params[0] = num690;
  Object opresult692 = callmethod(*var_ordval, "==", 1, params);
// compilenode returning opresult692
  params[0] = opresult692;
  Object opresult694 = callmethod(opresult689, "|", 1, params);
// compilenode returning opresult694
  Object if678;
  if (istrue(opresult694)) {
// Begin line 382
  setline(382);
// Begin line 381
  setline(381);
  if (strlit695 == NULL) {
    strlit695 = alloc_String("illegal whitespace in input: ");
  }
// compilenode returning strlit695
// Begin line 382
  setline(382);
  if (strlit696 == NULL) {
    strlit696 = alloc_String("");
  }
// compilenode returning strlit696
// compilenode returning *var_ordval
  params[0] = *var_ordval;
  Object opresult698 = callmethod(strlit696, "++", 1, params);
// compilenode returning opresult698
  if (strlit699 == NULL) {
    strlit699 = alloc_String(", ");
  }
// compilenode returning strlit699
  params[0] = strlit699;
  Object opresult701 = callmethod(opresult698, "++", 1, params);
// compilenode returning opresult701
// compilenode returning *var_c
// compilenode returning module_unicode
  params[0] = *var_c;
  Object call702 = callmethod(module_unicode, "name",
    1, params);
// compilenode returning call702
  params[0] = call702;
  Object opresult704 = callmethod(opresult701, "++", 1, params);
// compilenode returning opresult704
  if (strlit705 == NULL) {
    strlit705 = alloc_String("");
  }
// compilenode returning strlit705
  params[0] = strlit705;
  Object opresult707 = callmethod(opresult704, "++", 1, params);
// compilenode returning opresult707
  params[0] = opresult707;
  Object opresult709 = callmethod(strlit695, "++", 1, params);
// compilenode returning opresult709
// Begin line 381
  setline(381);
// compilenode returning module_util
  params[0] = opresult709;
  Object call710 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call710
    if678 = call710;
  } else {
  }
// compilenode returning if678
// Begin line 390
  setline(390);
// Begin line 384
  setline(384);
// compilenode returning *var_ordval
// compilenode returning module_unicode
  params[0] = *var_ordval;
  Object call712 = callmethod(module_unicode, "isControl",
    1, params);
// compilenode returning call712
// compilenode returning *var_ordval
  Object num713 = alloc_Float64(10.0);
// compilenode returning num713
  params[0] = num713;
  Object opresult715 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult715
  params[0] = opresult715;
  Object opresult717 = callmethod(call712, "&", 1, params);
// compilenode returning opresult717
// Begin line 385
  setline(385);
// compilenode returning *var_ordval
  Object num718 = alloc_Float64(13.0);
// compilenode returning num718
  params[0] = num718;
  Object opresult720 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult720
  params[0] = opresult720;
  Object opresult722 = callmethod(opresult717, "&", 1, params);
// compilenode returning opresult722
  Object if711;
  if (istrue(opresult722)) {
// Begin line 390
  setline(390);
// Begin line 388
  setline(388);
  if (strlit723 == NULL) {
    strlit723 = alloc_String("illegal control character in ");
  }
// compilenode returning strlit723
// Begin line 390
  setline(390);
// Begin line 389
  setline(389);
  if (strlit724 == NULL) {
    strlit724 = alloc_String("input: #");
  }
// compilenode returning strlit724
// compilenode returning *var_ordval
  params[0] = *var_ordval;
  Object opresult726 = callmethod(strlit724, "++", 1, params);
// compilenode returning opresult726
  if (strlit727 == NULL) {
    strlit727 = alloc_String(" on line ");
  }
// compilenode returning strlit727
  params[0] = strlit727;
  Object opresult729 = callmethod(opresult726, "++", 1, params);
// compilenode returning opresult729
// compilenode returning *var_lineNumber
  params[0] = *var_lineNumber;
  Object opresult731 = callmethod(opresult729, "++", 1, params);
// compilenode returning opresult731
  if (strlit732 == NULL) {
    strlit732 = alloc_String("");
  }
// compilenode returning strlit732
  params[0] = strlit732;
  Object opresult734 = callmethod(opresult731, "++", 1, params);
// compilenode returning opresult734
  params[0] = opresult734;
  Object opresult736 = callmethod(strlit723, "++", 1, params);
// compilenode returning opresult736
// Begin line 390
  setline(390);
  if (strlit737 == NULL) {
    strlit737 = alloc_String(" character ");
  }
// compilenode returning strlit737
// compilenode returning *var_linePosition
  params[0] = *var_linePosition;
  Object opresult739 = callmethod(strlit737, "++", 1, params);
// compilenode returning opresult739
  if (strlit740 == NULL) {
    strlit740 = alloc_String(".");
  }
// compilenode returning strlit740
  params[0] = strlit740;
  Object opresult742 = callmethod(opresult739, "++", 1, params);
// compilenode returning opresult742
  params[0] = opresult742;
  Object opresult744 = callmethod(opresult736, "++", 1, params);
// compilenode returning opresult744
// Begin line 388
  setline(388);
// compilenode returning module_util
  params[0] = opresult744;
  Object call745 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call745
    if711 = call745;
  } else {
  }
// compilenode returning if711
// Begin line 398
  setline(398);
// Begin line 400
  setline(400);
// Begin line 392
  setline(392);
// compilenode returning *var_atStart
// Begin line 400
  setline(400);
// Begin line 392
  setline(392);
// compilenode returning *var_linePosition
  Object num747 = alloc_Float64(1.0);
// compilenode returning num747
  params[0] = num747;
  Object opresult749 = callmethod(*var_linePosition, "==", 1, params);
// compilenode returning opresult749
  params[0] = opresult749;
  Object opresult751 = callmethod(*var_atStart, "&", 1, params);
// compilenode returning opresult751
  Object if746;
  if (istrue(opresult751)) {
// Begin line 398
  setline(398);
// Begin line 399
  setline(399);
// Begin line 393
  setline(393);
// compilenode returning *var_c
  if (strlit753 == NULL) {
    strlit753 = alloc_String("#");
  }
// compilenode returning strlit753
  params[0] = strlit753;
  Object opresult755 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult755
  Object if752;
  if (istrue(opresult755)) {
// Begin line 395
  setline(395);
// Begin line 394
  setline(394);
  if (strlit756 == NULL) {
    strlit756 = alloc_String("c");
  }
// compilenode returning strlit756
  *var_mode = strlit756;
  if (strlit756 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 396
  setline(396);
// Begin line 395
  setline(395);
// compilenode returning *var_mode
  *var_newmode = *var_mode;
  if (*var_mode == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if752 = nothing;
  } else {
// Begin line 398
  setline(398);
// Begin line 397
  setline(397);
  Object bool759 = alloc_Boolean(0);
// compilenode returning bool759
  *var_atStart = bool759;
  if (bool759 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if752 = nothing;
  }
// compilenode returning if752
    if746 = if752;
  } else {
  }
// compilenode returning if746
// Begin line 463
  setline(463);
// Begin line 467
  setline(467);
// Begin line 400
  setline(400);
// compilenode returning *var_instr
// compilenode returning *var_inBackticks
  params[0] = *var_inBackticks;
  Object opresult763 = callmethod(*var_instr, "|", 1, params);
// compilenode returning opresult763
  Object if761;
  if (istrue(opresult763)) {
    if761 = undefined;
  } else {
// Begin line 463
  setline(463);
// Begin line 467
  setline(467);
// Begin line 402
  setline(402);
// compilenode returning *var_mode
  if (strlit765 == NULL) {
    strlit765 = alloc_String("c");
  }
// compilenode returning strlit765
  params[0] = strlit765;
  Object opresult767 = callmethod(*var_mode, "/=", 1, params);
// compilenode returning opresult767
  Object if764;
  if (istrue(opresult767)) {
// Begin line 406
  setline(406);
// Begin line 407
  setline(407);
// Begin line 404
  setline(404);
// compilenode returning *var_c
  if (strlit769 == NULL) {
    strlit769 = alloc_String(" ");
  }
// compilenode returning strlit769
  params[0] = strlit769;
  Object opresult771 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult771
// Begin line 407
  setline(407);
// Begin line 404
  setline(404);
// compilenode returning *var_mode
  if (strlit772 == NULL) {
    strlit772 = alloc_String("d");
  }
// compilenode returning strlit772
  params[0] = strlit772;
  Object opresult774 = callmethod(*var_mode, "/=", 1, params);
// compilenode returning opresult774
  params[0] = opresult774;
  Object opresult776 = callmethod(opresult771, "&", 1, params);
// compilenode returning opresult776
  Object if768;
  if (istrue(opresult776)) {
// Begin line 406
  setline(406);
// Begin line 405
  setline(405);
  if (strlit777 == NULL) {
    strlit777 = alloc_String("n");
  }
// compilenode returning strlit777
  *var_newmode = strlit777;
  if (strlit777 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if768 = nothing;
  } else {
  }
// compilenode returning if768
// Begin line 415
  setline(415);
// Begin line 417
  setline(417);
// Begin line 407
  setline(407);
// compilenode returning *var_c
  if (strlit780 == NULL) {
    strlit780 = alloc_String("""\x22""");
  }
// compilenode returning strlit780
  params[0] = strlit780;
  Object opresult782 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult782
  Object if779;
  if (istrue(opresult782)) {
// Begin line 410
  setline(410);
// Begin line 409
  setline(409);
  if (strlit783 == NULL) {
    strlit783 = alloc_String("""\x22""");
  }
// compilenode returning strlit783
  *var_newmode = strlit783;
  if (strlit783 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 411
  setline(411);
// Begin line 410
  setline(410);
  Object bool785 = alloc_Boolean(1);
// compilenode returning bool785
  *var_instr = bool785;
  if (bool785 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 415
  setline(415);
// Begin line 416
  setline(416);
// Begin line 411
  setline(411);
// compilenode returning *var_prev
  if (strlit788 == NULL) {
    strlit788 = alloc_String("x");
  }
// compilenode returning strlit788
  params[0] = strlit788;
  Object opresult790 = callmethod(*var_prev, "==", 1, params);
// compilenode returning opresult790
  Object if787;
  if (istrue(opresult790)) {
// Begin line 414
  setline(414);
// Begin line 413
  setline(413);
  if (strlit791 == NULL) {
    strlit791 = alloc_String("x");
  }
// compilenode returning strlit791
  *var_newmode = strlit791;
  if (strlit791 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 415
  setline(415);
// Begin line 414
  setline(414);
  if (strlit793 == NULL) {
    strlit793 = alloc_String("n");
  }
// compilenode returning strlit793
  *var_mode = strlit793;
  if (strlit793 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if787 = nothing;
  } else {
  }
// compilenode returning if787
    if779 = if787;
  } else {
  }
// compilenode returning if779
// Begin line 420
  setline(420);
// Begin line 421
  setline(421);
// Begin line 417
  setline(417);
// compilenode returning *var_c
  if (strlit796 == NULL) {
    strlit796 = alloc_String("`");
  }
// compilenode returning strlit796
  params[0] = strlit796;
  Object opresult798 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult798
  Object if795;
  if (istrue(opresult798)) {
// Begin line 419
  setline(419);
// Begin line 418
  setline(418);
  if (strlit799 == NULL) {
    strlit799 = alloc_String("I");
  }
// compilenode returning strlit799
  *var_newmode = strlit799;
  if (strlit799 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 420
  setline(420);
// Begin line 419
  setline(419);
  Object bool801 = alloc_Boolean(1);
// compilenode returning bool801
  *var_inBackticks = bool801;
  if (bool801 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if795 = nothing;
  } else {
  }
// compilenode returning if795
// Begin line 421
  setline(421);
// compilenode returning *var_ordval
// Begin line 422
  setline(422);
// compilenode returning self
  params[0] = *var_ordval;
  Object call803 = callmethod(self, "isidentifierchar",
    1, params);
// compilenode returning call803
  *var_ct = call803;
  if (call803 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 424
  setline(424);
// Begin line 422
  setline(422);
// compilenode returning *var_ct
  Object if805;
  if (istrue(*var_ct)) {
// Begin line 424
  setline(424);
// Begin line 423
  setline(423);
  if (strlit806 == NULL) {
    strlit806 = alloc_String("i");
  }
// compilenode returning strlit806
  *var_newmode = strlit806;
  if (strlit806 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if805 = nothing;
  } else {
  }
// compilenode returning if805
// Begin line 426
  setline(426);
// Begin line 425
  setline(425);
// compilenode returning *var_ordval
  Object num808 = alloc_Float64(48.0);
// compilenode returning num808
  params[0] = num808;
  Object opresult810 = callmethod(*var_ordval, ">=", 1, params);
// compilenode returning opresult810
// Begin line 426
  setline(426);
// Begin line 425
  setline(425);
// compilenode returning *var_ordval
  Object num811 = alloc_Float64(57.0);
// compilenode returning num811
  params[0] = num811;
  Object opresult813 = callmethod(*var_ordval, "<=", 1, params);
// compilenode returning opresult813
  params[0] = opresult813;
  Object opresult815 = callmethod(opresult810, "&", 1, params);
// compilenode returning opresult815
  *var_ct = opresult815;
  if (opresult815 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 428
  setline(428);
// Begin line 429
  setline(429);
// Begin line 426
  setline(426);
// compilenode returning *var_ct
// Begin line 429
  setline(429);
// Begin line 426
  setline(426);
// compilenode returning *var_mode
  if (strlit818 == NULL) {
    strlit818 = alloc_String("i");
  }
// compilenode returning strlit818
  params[0] = strlit818;
  Object opresult820 = callmethod(*var_mode, "/=", 1, params);
// compilenode returning opresult820
  params[0] = opresult820;
  Object opresult822 = callmethod(*var_ct, "&", 1, params);
// compilenode returning opresult822
  Object if817;
  if (istrue(opresult822)) {
// Begin line 428
  setline(428);
// Begin line 427
  setline(427);
  if (strlit823 == NULL) {
    strlit823 = alloc_String("m");
  }
// compilenode returning strlit823
  *var_newmode = strlit823;
  if (strlit823 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if817 = nothing;
  } else {
  }
// compilenode returning if817
// Begin line 439
  setline(439);
// Begin line 440
  setline(440);
// Begin line 429
  setline(429);
// compilenode returning *var_mode
  if (strlit826 == NULL) {
    strlit826 = alloc_String("i");
  }
// compilenode returning strlit826
  params[0] = strlit826;
  Object opresult828 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult828
// Begin line 440
  setline(440);
// Begin line 429
  setline(429);
// compilenode returning *var_c
  if (strlit829 == NULL) {
    strlit829 = alloc_String("<");
  }
// compilenode returning strlit829
  params[0] = strlit829;
  Object opresult831 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult831
  params[0] = opresult831;
  Object opresult833 = callmethod(opresult828, "&", 1, params);
// compilenode returning opresult833
  Object if825;
  if (istrue(opresult833)) {
// Begin line 431
  setline(431);
// Begin line 430
  setline(430);
  if (strlit834 == NULL) {
    strlit834 = alloc_String("<");
  }
// compilenode returning strlit834
  *var_newmode = strlit834;
  if (strlit834 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if825 = nothing;
  } else {
// Begin line 439
  setline(439);
// Begin line 437
  setline(437);
// Begin line 431
  setline(431);
// compilenode returning *var_mode
  if (strlit837 == NULL) {
    strlit837 = alloc_String("i");
  }
// compilenode returning strlit837
  params[0] = strlit837;
  Object opresult839 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult839
// Begin line 437
  setline(437);
// Begin line 431
  setline(431);
// compilenode returning *var_mode
  if (strlit840 == NULL) {
    strlit840 = alloc_String(">");
  }
// compilenode returning strlit840
  params[0] = strlit840;
  Object opresult842 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult842
  params[0] = opresult842;
  Object opresult844 = callmethod(opresult839, "|", 1, params);
// compilenode returning opresult844
// Begin line 437
  setline(437);
// Begin line 432
  setline(432);
// compilenode returning *var_c
  if (strlit845 == NULL) {
    strlit845 = alloc_String(">");
  }
// compilenode returning strlit845
  params[0] = strlit845;
  Object opresult847 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult847
  params[0] = opresult847;
  Object opresult849 = callmethod(opresult844, "&", 1, params);
// compilenode returning opresult849
  Object if836;
  if (istrue(opresult849)) {
// Begin line 434
  setline(434);
// Begin line 436
  setline(436);
// Begin line 433
  setline(433);
// compilenode returning *var_mode
  if (strlit851 == NULL) {
    strlit851 = alloc_String(">");
  }
// compilenode returning strlit851
  params[0] = strlit851;
  Object opresult853 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult853
  Object if850;
  if (istrue(opresult853)) {
// Begin line 434
  setline(434);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 435
  setline(435);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call854 = callmethod(self, "modechange",
    3, params);
// compilenode returning call854
    if850 = call854;
  } else {
  }
// compilenode returning if850
// Begin line 437
  setline(437);
// Begin line 436
  setline(436);
  if (strlit855 == NULL) {
    strlit855 = alloc_String(">");
  }
// compilenode returning strlit855
  *var_newmode = strlit855;
  if (strlit855 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if836 = nothing;
  } else {
// Begin line 439
  setline(439);
// Begin line 437
  setline(437);
// compilenode returning *var_c
// compilenode returning *var_ordval
// Begin line 440
  setline(440);
// compilenode returning self
  params[0] = *var_c;
  params[1] = *var_ordval;
  Object call858 = callmethod(self, "isoperatorchar",
    2, params);
// compilenode returning call858
  Object if857;
  if (istrue(call858)) {
// Begin line 439
  setline(439);
// Begin line 438
  setline(438);
  if (strlit859 == NULL) {
    strlit859 = alloc_String("o");
  }
// compilenode returning strlit859
  *var_newmode = strlit859;
  if (strlit859 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if857 = nothing;
  } else {
  }
// compilenode returning if857
    if836 = if857;
  }
// compilenode returning if836
    if825 = if836;
  }
// compilenode returning if825
// Begin line 444
  setline(444);
// Begin line 445
  setline(445);
// Begin line 440
  setline(440);
// compilenode returning *var_c
  if (strlit862 == NULL) {
    strlit862 = alloc_String("(");
  }
// compilenode returning strlit862
  params[0] = strlit862;
  Object opresult864 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult864
// Begin line 445
  setline(445);
// Begin line 440
  setline(440);
// compilenode returning *var_c
  if (strlit865 == NULL) {
    strlit865 = alloc_String(")");
  }
// compilenode returning strlit865
  params[0] = strlit865;
  Object opresult867 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult867
  params[0] = opresult867;
  Object opresult869 = callmethod(opresult864, "|", 1, params);
// compilenode returning opresult869
// Begin line 445
  setline(445);
// Begin line 440
  setline(440);
// compilenode returning *var_c
  if (strlit870 == NULL) {
    strlit870 = alloc_String(",");
  }
// compilenode returning strlit870
  params[0] = strlit870;
  Object opresult872 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult872
  params[0] = opresult872;
  Object opresult874 = callmethod(opresult869, "|", 1, params);
// compilenode returning opresult874
// Begin line 445
  setline(445);
// Begin line 440
  setline(440);
// compilenode returning *var_c
  if (strlit875 == NULL) {
    strlit875 = alloc_String(".");
  }
// compilenode returning strlit875
  params[0] = strlit875;
  Object opresult877 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult877
  params[0] = opresult877;
  Object opresult879 = callmethod(opresult874, "|", 1, params);
// compilenode returning opresult879
// Begin line 445
  setline(445);
// Begin line 441
  setline(441);
// compilenode returning *var_c
  if (strlit880 == NULL) {
    strlit880 = alloc_String("{");
  }
// compilenode returning strlit880
  params[0] = strlit880;
  Object opresult882 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult882
  params[0] = opresult882;
  Object opresult884 = callmethod(opresult879, "|", 1, params);
// compilenode returning opresult884
// Begin line 445
  setline(445);
// Begin line 441
  setline(441);
// compilenode returning *var_c
  if (strlit885 == NULL) {
    strlit885 = alloc_String("}");
  }
// compilenode returning strlit885
  params[0] = strlit885;
  Object opresult887 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult887
  params[0] = opresult887;
  Object opresult889 = callmethod(opresult884, "|", 1, params);
// compilenode returning opresult889
// Begin line 445
  setline(445);
// Begin line 441
  setline(441);
// compilenode returning *var_c
  if (strlit890 == NULL) {
    strlit890 = alloc_String("[");
  }
// compilenode returning strlit890
  params[0] = strlit890;
  Object opresult892 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult892
  params[0] = opresult892;
  Object opresult894 = callmethod(opresult889, "|", 1, params);
// compilenode returning opresult894
// Begin line 445
  setline(445);
// Begin line 441
  setline(441);
// compilenode returning *var_c
  if (strlit895 == NULL) {
    strlit895 = alloc_String("]");
  }
// compilenode returning strlit895
  params[0] = strlit895;
  Object opresult897 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult897
  params[0] = opresult897;
  Object opresult899 = callmethod(opresult894, "|", 1, params);
// compilenode returning opresult899
// Begin line 445
  setline(445);
// Begin line 442
  setline(442);
// compilenode returning *var_c
  if (strlit900 == NULL) {
    strlit900 = alloc_String(";");
  }
// compilenode returning strlit900
  params[0] = strlit900;
  Object opresult902 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult902
  params[0] = opresult902;
  Object opresult904 = callmethod(opresult899, "|", 1, params);
// compilenode returning opresult904
  Object if861;
  if (istrue(opresult904)) {
// Begin line 444
  setline(444);
// Begin line 443
  setline(443);
// compilenode returning *var_c
  *var_newmode = *var_c;
  if (*var_c == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if861 = nothing;
  } else {
  }
// compilenode returning if861
// Begin line 449
  setline(449);
// Begin line 450
  setline(450);
// Begin line 445
  setline(445);
// compilenode returning *var_c
  if (strlit907 == NULL) {
    strlit907 = alloc_String(".");
  }
// compilenode returning strlit907
  params[0] = strlit907;
  Object opresult909 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult909
// Begin line 450
  setline(450);
// Begin line 445
  setline(445);
// compilenode returning *var_accum
  if (strlit910 == NULL) {
    strlit910 = alloc_String(".");
  }
// compilenode returning strlit910
  params[0] = strlit910;
  Object opresult912 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult912
  params[0] = opresult912;
  Object opresult914 = callmethod(opresult909, "&", 1, params);
// compilenode returning opresult914
  Object if906;
  if (istrue(opresult914)) {
// Begin line 448
  setline(448);
// Begin line 447
  setline(447);
  if (strlit915 == NULL) {
    strlit915 = alloc_String("o");
  }
// compilenode returning strlit915
  *var_mode = strlit915;
  if (strlit915 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 449
  setline(449);
// Begin line 448
  setline(448);
// compilenode returning *var_mode
  *var_newmode = *var_mode;
  if (*var_mode == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if906 = nothing;
  } else {
  }
// compilenode returning if906
// Begin line 454
  setline(454);
// Begin line 455
  setline(455);
// Begin line 450
  setline(450);
// compilenode returning *var_c
  if (strlit919 == NULL) {
    strlit919 = alloc_String("/");
  }
// compilenode returning strlit919
  params[0] = strlit919;
  Object opresult921 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult921
// Begin line 455
  setline(455);
// Begin line 450
  setline(450);
// compilenode returning *var_accum
  if (strlit922 == NULL) {
    strlit922 = alloc_String("/");
  }
// compilenode returning strlit922
  params[0] = strlit922;
  Object opresult924 = callmethod(*var_accum, "==", 1, params);
// compilenode returning opresult924
  params[0] = opresult924;
  Object opresult926 = callmethod(opresult921, "&", 1, params);
// compilenode returning opresult926
  Object if918;
  if (istrue(opresult926)) {
// Begin line 453
  setline(453);
// Begin line 452
  setline(452);
  if (strlit927 == NULL) {
    strlit927 = alloc_String("c");
  }
// compilenode returning strlit927
  *var_mode = strlit927;
  if (strlit927 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 454
  setline(454);
// Begin line 453
  setline(453);
// compilenode returning *var_mode
  *var_newmode = *var_mode;
  if (*var_mode == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if918 = nothing;
  } else {
  }
// compilenode returning if918
// Begin line 463
  setline(463);
// Begin line 457
  setline(457);
// Begin line 456
  setline(456);
// Begin line 466
  setline(466);
// Begin line 455
  setline(455);
// compilenode returning *var_newmode
// compilenode returning *var_mode
  params[0] = *var_mode;
  Object opresult932 = callmethod(*var_newmode, "==", 1, params);
// compilenode returning opresult932
// Begin line 466
  setline(466);
// Begin line 455
  setline(455);
// compilenode returning *var_mode
  if (strlit933 == NULL) {
    strlit933 = alloc_String("n");
  }
// compilenode returning strlit933
  params[0] = strlit933;
  Object opresult935 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult935
  params[0] = opresult935;
  Object opresult937 = callmethod(opresult932, "&", 1, params);
// compilenode returning opresult937
// Begin line 456
  setline(456);
// Begin line 633
  setline(633);
// Begin line 456
  setline(456);
// compilenode returning *var_ordval
// compilenode returning module_unicode
  params[0] = *var_ordval;
  Object call938 = callmethod(module_unicode, "isSeparator",
    1, params);
// compilenode returning call938
  Object call939 = callmethod(call938, "not",
    0, params);
// compilenode returning call939
// compilenode returning call939
  params[0] = call939;
  Object opresult941 = callmethod(opresult937, "&", 1, params);
// compilenode returning opresult941
// Begin line 457
  setline(457);
// Begin line 633
  setline(633);
// Begin line 457
  setline(457);
// compilenode returning *var_ordval
// compilenode returning module_unicode
  params[0] = *var_ordval;
  Object call942 = callmethod(module_unicode, "isControl",
    1, params);
// compilenode returning call942
  Object call943 = callmethod(call942, "not",
    0, params);
// compilenode returning call943
// compilenode returning call943
  params[0] = call943;
  Object opresult945 = callmethod(opresult941, "&", 1, params);
// compilenode returning opresult945
  Object if930;
  if (istrue(opresult945)) {
// Begin line 463
  setline(463);
// Begin line 458
  setline(458);
// Begin line 633
  setline(633);
// Begin line 458
  setline(458);
// compilenode returning *var_ordval
// compilenode returning module_unicode
  params[0] = *var_ordval;
  Object call947 = callmethod(module_unicode, "isSeparator",
    1, params);
// compilenode returning call947
  Object call948 = callmethod(call947, "not",
    0, params);
// compilenode returning call948
// compilenode returning call948
// Begin line 459
  setline(459);
// compilenode returning *var_ordval
  Object num949 = alloc_Float64(10.0);
// compilenode returning num949
  params[0] = num949;
  Object opresult951 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult951
  params[0] = opresult951;
  Object opresult953 = callmethod(call948, "&", 1, params);
// compilenode returning opresult953
// Begin line 458
  setline(458);
// Begin line 459
  setline(459);
// compilenode returning *var_ordval
  Object num954 = alloc_Float64(13.0);
// compilenode returning num954
  params[0] = num954;
  Object opresult956 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult956
  params[0] = opresult956;
  Object opresult958 = callmethod(opresult953, "&", 1, params);
// compilenode returning opresult958
// Begin line 458
  setline(458);
// Begin line 460
  setline(460);
// compilenode returning *var_ordval
  Object num959 = alloc_Float64(32.0);
// compilenode returning num959
  params[0] = num959;
  Object opresult961 = callmethod(*var_ordval, "/=", 1, params);
// compilenode returning opresult961
  params[0] = opresult961;
  Object opresult963 = callmethod(opresult958, "&", 1, params);
// compilenode returning opresult963
  Object if946;
  if (istrue(opresult963)) {
// Begin line 463
  setline(463);
// Begin line 461
  setline(461);
  if (strlit964 == NULL) {
    strlit964 = alloc_String("unknown character in ");
  }
// compilenode returning strlit964
// Begin line 463
  setline(463);
// Begin line 462
  setline(462);
  if (strlit965 == NULL) {
    strlit965 = alloc_String("input: #");
  }
// compilenode returning strlit965
// compilenode returning *var_ordval
  params[0] = *var_ordval;
  Object opresult967 = callmethod(strlit965, "++", 1, params);
// compilenode returning opresult967
  if (strlit968 == NULL) {
    strlit968 = alloc_String("");
  }
// compilenode returning strlit968
  params[0] = strlit968;
  Object opresult970 = callmethod(opresult967, "++", 1, params);
// compilenode returning opresult970
  params[0] = opresult970;
  Object opresult972 = callmethod(strlit964, "++", 1, params);
// compilenode returning opresult972
// Begin line 463
  setline(463);
  if (strlit973 == NULL) {
    strlit973 = alloc_String(" '");
  }
// compilenode returning strlit973
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult975 = callmethod(strlit973, "++", 1, params);
// compilenode returning opresult975
  if (strlit976 == NULL) {
    strlit976 = alloc_String("', ");
  }
// compilenode returning strlit976
  params[0] = strlit976;
  Object opresult978 = callmethod(opresult975, "++", 1, params);
// compilenode returning opresult978
// compilenode returning *var_c
// compilenode returning module_unicode
  params[0] = *var_c;
  Object call979 = callmethod(module_unicode, "name",
    1, params);
// compilenode returning call979
  params[0] = call979;
  Object opresult981 = callmethod(opresult978, "++", 1, params);
// compilenode returning opresult981
  if (strlit982 == NULL) {
    strlit982 = alloc_String("");
  }
// compilenode returning strlit982
  params[0] = strlit982;
  Object opresult984 = callmethod(opresult981, "++", 1, params);
// compilenode returning opresult984
  params[0] = opresult984;
  Object opresult986 = callmethod(opresult972, "++", 1, params);
// compilenode returning opresult986
// Begin line 461
  setline(461);
// compilenode returning module_util
  params[0] = opresult986;
  Object call987 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call987
    if946 = call987;
  } else {
  }
// compilenode returning if946
    if930 = if946;
  } else {
  }
// compilenode returning if930
    if764 = if930;
  } else {
  }
// compilenode returning if764
    if761 = if764;
  }
// compilenode returning if761
// Begin line 471
  setline(471);
// Begin line 472
  setline(472);
// Begin line 467
  setline(467);
// compilenode returning *var_mode
  if (strlit989 == NULL) {
    strlit989 = alloc_String("x");
  }
// compilenode returning strlit989
  params[0] = strlit989;
  Object opresult991 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult991
// Begin line 472
  setline(472);
// Begin line 467
  setline(467);
// compilenode returning *var_c
  if (strlit992 == NULL) {
    strlit992 = alloc_String("""\x22""");
  }
// compilenode returning strlit992
  params[0] = strlit992;
  Object opresult994 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult994
  params[0] = opresult994;
  Object opresult996 = callmethod(opresult991, "&", 1, params);
// compilenode returning opresult996
// Begin line 472
  setline(472);
// Begin line 633
  setline(633);
// Begin line 467
  setline(467);
// compilenode returning *var_escaped
  Object call997 = callmethod(*var_escaped, "not",
    0, params);
// compilenode returning call997
// compilenode returning call997
  params[0] = call997;
  Object opresult999 = callmethod(opresult996, "&", 1, params);
// compilenode returning opresult999
  Object if988;
  if (istrue(opresult999)) {
// Begin line 470
  setline(470);
// Begin line 469
  setline(469);
  if (strlit1000 == NULL) {
    strlit1000 = alloc_String("n");
  }
// compilenode returning strlit1000
  *var_newmode = strlit1000;
  if (strlit1000 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 471
  setline(471);
// Begin line 470
  setline(470);
  Object bool1002 = alloc_Boolean(0);
// compilenode returning bool1002
  *var_instr = bool1002;
  if (bool1002 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if988 = nothing;
  } else {
  }
// compilenode returning if988
// Begin line 481
  setline(481);
// Begin line 483
  setline(483);
// Begin line 472
  setline(472);
// compilenode returning *var_mode
  if (strlit1005 == NULL) {
    strlit1005 = alloc_String("""\x22""");
  }
// compilenode returning strlit1005
  params[0] = strlit1005;
  Object opresult1007 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1007
// Begin line 483
  setline(483);
// Begin line 472
  setline(472);
// compilenode returning *var_c
  if (strlit1008 == NULL) {
    strlit1008 = alloc_String("""\x22""");
  }
// compilenode returning strlit1008
  params[0] = strlit1008;
  Object opresult1010 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1010
  params[0] = opresult1010;
  Object opresult1012 = callmethod(opresult1007, "&", 1, params);
// compilenode returning opresult1012
// Begin line 483
  setline(483);
// Begin line 633
  setline(633);
// Begin line 472
  setline(472);
// compilenode returning *var_escaped
  Object call1013 = callmethod(*var_escaped, "not",
    0, params);
// compilenode returning call1013
// compilenode returning call1013
  params[0] = call1013;
  Object opresult1015 = callmethod(opresult1012, "&", 1, params);
// compilenode returning opresult1015
  Object if1004;
  if (istrue(opresult1015)) {
// Begin line 475
  setline(475);
// Begin line 474
  setline(474);
  if (strlit1016 == NULL) {
    strlit1016 = alloc_String("n");
  }
// compilenode returning strlit1016
  *var_newmode = strlit1016;
  if (strlit1016 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 476
  setline(476);
// Begin line 475
  setline(475);
  Object bool1018 = alloc_Boolean(0);
// compilenode returning bool1018
  *var_instr = bool1018;
  if (bool1018 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 481
  setline(481);
// Begin line 476
  setline(476);
// compilenode returning *var_interpString
  Object if1020;
  if (istrue(*var_interpString)) {
// Begin line 477
  setline(477);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 478
  setline(478);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call1021 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1021
// compilenode returning *var_tokens
  if (strlit1022 == NULL) {
    strlit1022 = alloc_String(")");
  }
// compilenode returning strlit1022
  if (strlit1023 == NULL) {
    strlit1023 = alloc_String(")");
  }
// compilenode returning strlit1023
// Begin line 479
  setline(479);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = strlit1022;
  params[2] = strlit1023;
  Object call1024 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1024
// Begin line 480
  setline(480);
// Begin line 479
  setline(479);
// compilenode returning *var_newmode
  *var_mode = *var_newmode;
  if (*var_newmode == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 481
  setline(481);
// Begin line 480
  setline(480);
  Object bool1026 = alloc_Boolean(0);
// compilenode returning bool1026
  *var_interpString = bool1026;
  if (bool1026 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1020 = nothing;
  } else {
  }
// compilenode returning if1020
    if1004 = if1020;
  } else {
  }
// compilenode returning if1004
// Begin line 488
  setline(488);
// Begin line 489
  setline(489);
// Begin line 483
  setline(483);
// compilenode returning *var_mode
  if (strlit1029 == NULL) {
    strlit1029 = alloc_String("I");
  }
// compilenode returning strlit1029
  params[0] = strlit1029;
  Object opresult1031 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1031
// compilenode returning *var_inBackticks
  params[0] = *var_inBackticks;
  Object opresult1033 = callmethod(opresult1031, "&", 1, params);
// compilenode returning opresult1033
// Begin line 489
  setline(489);
// Begin line 483
  setline(483);
// compilenode returning *var_c
  if (strlit1034 == NULL) {
    strlit1034 = alloc_String("`");
  }
// compilenode returning strlit1034
  params[0] = strlit1034;
  Object opresult1036 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1036
  params[0] = opresult1036;
  Object opresult1038 = callmethod(opresult1033, "&", 1, params);
// compilenode returning opresult1038
  Object if1028;
  if (istrue(opresult1038)) {
// Begin line 486
  setline(486);
// Begin line 485
  setline(485);
  if (strlit1039 == NULL) {
    strlit1039 = alloc_String("n");
  }
// compilenode returning strlit1039
  *var_newmode = strlit1039;
  if (strlit1039 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 487
  setline(487);
// Begin line 486
  setline(486);
  Object bool1041 = alloc_Boolean(0);
// compilenode returning bool1041
  *var_inBackticks = bool1041;
  if (bool1041 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 488
  setline(488);
// Begin line 487
  setline(487);
  Object bool1043 = alloc_Boolean(1);
// compilenode returning bool1043
  *var_backtickIdent = bool1043;
  if (bool1043 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1028 = nothing;
  } else {
  }
// compilenode returning if1028
// Begin line 612
  setline(612);
// Begin line 613
  setline(613);
// Begin line 489
  setline(489);
// compilenode returning *var_newmode
// compilenode returning *var_mode
  params[0] = *var_mode;
  Object opresult1047 = callmethod(*var_newmode, "/=", 1, params);
// compilenode returning opresult1047
  Object if1045;
  if (istrue(opresult1047)) {
// Begin line 492
  setline(492);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 493
  setline(493);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call1048 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1048
// Begin line 499
  setline(499);
// Begin line 500
  setline(500);
// Begin line 493
  setline(493);
// compilenode returning *var_newmode
  if (strlit1050 == NULL) {
    strlit1050 = alloc_String("}");
  }
// compilenode returning strlit1050
  params[0] = strlit1050;
  Object opresult1052 = callmethod(*var_newmode, "==", 1, params);
// compilenode returning opresult1052
// Begin line 500
  setline(500);
// Begin line 493
  setline(493);
// compilenode returning *var_interpdepth
  Object num1053 = alloc_Float64(0.0);
// compilenode returning num1053
  params[0] = num1053;
  Object opresult1055 = callmethod(*var_interpdepth, ">", 1, params);
// compilenode returning opresult1055
  params[0] = opresult1055;
  Object opresult1057 = callmethod(opresult1052, "&", 1, params);
// compilenode returning opresult1057
  Object if1049;
  if (istrue(opresult1057)) {
// Begin line 494
  setline(494);
// compilenode returning *var_tokens
  if (strlit1058 == NULL) {
    strlit1058 = alloc_String(")");
  }
// compilenode returning strlit1058
  if (strlit1059 == NULL) {
    strlit1059 = alloc_String(")");
  }
// compilenode returning strlit1059
// Begin line 495
  setline(495);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = strlit1058;
  params[2] = strlit1059;
  Object call1060 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1060
// compilenode returning *var_tokens
  if (strlit1061 == NULL) {
    strlit1061 = alloc_String("o");
  }
// compilenode returning strlit1061
  if (strlit1062 == NULL) {
    strlit1062 = alloc_String("++");
  }
// compilenode returning strlit1062
// Begin line 496
  setline(496);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = strlit1061;
  params[2] = strlit1062;
  Object call1063 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1063
// Begin line 497
  setline(497);
// Begin line 496
  setline(496);
  if (strlit1064 == NULL) {
    strlit1064 = alloc_String("""\x22""");
  }
// compilenode returning strlit1064
  *var_newmode = strlit1064;
  if (strlit1064 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 498
  setline(498);
// Begin line 497
  setline(497);
  Object bool1066 = alloc_Boolean(1);
// compilenode returning bool1066
  *var_instr = bool1066;
  if (bool1066 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 499
  setline(499);
// Begin line 498
  setline(498);
// compilenode returning *var_interpdepth
  Object num1068 = alloc_Float64(1.0);
// compilenode returning num1068
  params[0] = num1068;
  Object diff1070 = callmethod(*var_interpdepth, "-", 1, params);
// compilenode returning diff1070
  *var_interpdepth = diff1070;
  if (diff1070 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1049 = nothing;
  } else {
  }
// compilenode returning if1049
// Begin line 501
  setline(501);
// Begin line 500
  setline(500);
// compilenode returning *var_newmode
  *var_mode = *var_newmode;
  if (*var_newmode == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 508
  setline(508);
// Begin line 509
  setline(509);
// Begin line 501
  setline(501);
// compilenode returning *var_instr
// compilenode returning *var_inBackticks
  params[0] = *var_inBackticks;
  Object opresult1075 = callmethod(*var_instr, "|", 1, params);
// compilenode returning opresult1075
  Object if1073;
  if (istrue(opresult1075)) {
// Begin line 506
  setline(506);
// Begin line 505
  setline(505);
  if (strlit1076 == NULL) {
    strlit1076 = alloc_String("");
  }
// compilenode returning strlit1076
  *var_accum = strlit1076;
  if (strlit1076 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1073 = nothing;
  } else {
// Begin line 508
  setline(508);
// Begin line 507
  setline(507);
// compilenode returning *var_c
  *var_accum = *var_c;
  if (*var_c == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1073 = nothing;
  }
// compilenode returning if1073
// Begin line 516
  setline(516);
// Begin line 517
  setline(517);
// Begin line 509
  setline(509);
// compilenode returning *var_mode
  if (strlit1080 == NULL) {
    strlit1080 = alloc_String("(");
  }
// compilenode returning strlit1080
  params[0] = strlit1080;
  Object opresult1082 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1082
// Begin line 517
  setline(517);
// Begin line 509
  setline(509);
// compilenode returning *var_mode
  if (strlit1083 == NULL) {
    strlit1083 = alloc_String(")");
  }
// compilenode returning strlit1083
  params[0] = strlit1083;
  Object opresult1085 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1085
  params[0] = opresult1085;
  Object opresult1087 = callmethod(opresult1082, "|", 1, params);
// compilenode returning opresult1087
// Begin line 517
  setline(517);
// Begin line 509
  setline(509);
// compilenode returning *var_mode
  if (strlit1088 == NULL) {
    strlit1088 = alloc_String("[");
  }
// compilenode returning strlit1088
  params[0] = strlit1088;
  Object opresult1090 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1090
  params[0] = opresult1090;
  Object opresult1092 = callmethod(opresult1087, "|", 1, params);
// compilenode returning opresult1092
// Begin line 517
  setline(517);
// Begin line 510
  setline(510);
// compilenode returning *var_mode
  if (strlit1093 == NULL) {
    strlit1093 = alloc_String("]");
  }
// compilenode returning strlit1093
  params[0] = strlit1093;
  Object opresult1095 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1095
  params[0] = opresult1095;
  Object opresult1097 = callmethod(opresult1092, "|", 1, params);
// compilenode returning opresult1097
// Begin line 517
  setline(517);
// Begin line 510
  setline(510);
// compilenode returning *var_mode
  if (strlit1098 == NULL) {
    strlit1098 = alloc_String("{");
  }
// compilenode returning strlit1098
  params[0] = strlit1098;
  Object opresult1100 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1100
  params[0] = opresult1100;
  Object opresult1102 = callmethod(opresult1097, "|", 1, params);
// compilenode returning opresult1102
// Begin line 517
  setline(517);
// Begin line 511
  setline(511);
// compilenode returning *var_mode
  if (strlit1103 == NULL) {
    strlit1103 = alloc_String("}");
  }
// compilenode returning strlit1103
  params[0] = strlit1103;
  Object opresult1105 = callmethod(*var_mode, "==", 1, params);
// compilenode returning opresult1105
  params[0] = opresult1105;
  Object opresult1107 = callmethod(opresult1102, "|", 1, params);
// compilenode returning opresult1107
  Object if1079;
  if (istrue(opresult1107)) {
// Begin line 512
  setline(512);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 513
  setline(513);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call1108 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1108
// Begin line 514
  setline(514);
// Begin line 513
  setline(513);
  if (strlit1109 == NULL) {
    strlit1109 = alloc_String("n");
  }
// compilenode returning strlit1109
  *var_mode = strlit1109;
  if (strlit1109 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 515
  setline(515);
// Begin line 514
  setline(514);
  if (strlit1111 == NULL) {
    strlit1111 = alloc_String("n");
  }
// compilenode returning strlit1111
  *var_newmode = strlit1111;
  if (strlit1111 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 516
  setline(516);
// Begin line 515
  setline(515);
  if (strlit1113 == NULL) {
    strlit1113 = alloc_String("");
  }
// compilenode returning strlit1113
  *var_accum = strlit1113;
  if (strlit1113 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1079 = nothing;
  } else {
  }
// compilenode returning if1079
// Begin line 518
  setline(518);
// Begin line 517
  setline(517);
  Object bool1115 = alloc_Boolean(0);
// compilenode returning bool1115
  *var_backtickIdent = bool1115;
  if (bool1115 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1045 = nothing;
  } else {
// Begin line 612
  setline(612);
// Begin line 518
  setline(518);
// compilenode returning *var_instr
  Object if1117;
  if (istrue(*var_instr)) {
// Begin line 525
  setline(525);
// Begin line 528
  setline(528);
// Begin line 519
  setline(519);
// compilenode returning *var_c
  if (strlit1119 == NULL) {
    strlit1119 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1119
  params[0] = strlit1119;
  Object opresult1121 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1121
  Object if1118;
  if (istrue(opresult1121)) {
// Begin line 525
  setline(525);
// Begin line 527
  setline(527);
// Begin line 520
  setline(520);
// compilenode returning *var_interpdepth
  Object num1123 = alloc_Float64(0.0);
// compilenode returning num1123
  params[0] = num1123;
  Object opresult1125 = callmethod(*var_interpdepth, ">", 1, params);
// compilenode returning opresult1125
  Object if1122;
  if (istrue(opresult1125)) {
// Begin line 522
  setline(522);
// Begin line 521
  setline(521);
  if (strlit1126 == NULL) {
    strlit1126 = alloc_String("Runaway string ");
  }
// compilenode returning strlit1126
// Begin line 522
  setline(522);
  if (strlit1127 == NULL) {
    strlit1127 = alloc_String("interpolation");
  }
// compilenode returning strlit1127
  params[0] = strlit1127;
  Object opresult1129 = callmethod(strlit1126, "++", 1, params);
// compilenode returning opresult1129
// Begin line 521
  setline(521);
// compilenode returning module_util
  params[0] = opresult1129;
  Object call1130 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1130
    if1122 = call1130;
  } else {
// Begin line 525
  setline(525);
// Begin line 524
  setline(524);
  if (strlit1131 == NULL) {
    strlit1131 = alloc_String("Newlines not permitted ");
  }
// compilenode returning strlit1131
// Begin line 525
  setline(525);
  if (strlit1132 == NULL) {
    strlit1132 = alloc_String("in string literals");
  }
// compilenode returning strlit1132
  params[0] = strlit1132;
  Object opresult1134 = callmethod(strlit1131, "++", 1, params);
// compilenode returning opresult1134
// Begin line 524
  setline(524);
// compilenode returning module_util
  params[0] = opresult1134;
  Object call1135 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1135
    if1122 = call1135;
  }
// compilenode returning if1122
    if1118 = if1122;
  } else {
  }
// compilenode returning if1118
// Begin line 597
  setline(597);
// Begin line 528
  setline(528);
// compilenode returning *var_escaped
  Object if1136;
  if (istrue(*var_escaped)) {
// Begin line 564
  setline(564);
// Begin line 565
  setline(565);
// Begin line 529
  setline(529);
// compilenode returning *var_c
  if (strlit1138 == NULL) {
    strlit1138 = alloc_String("n");
  }
// compilenode returning strlit1138
  params[0] = strlit1138;
  Object opresult1140 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1140
  Object if1137;
  if (istrue(opresult1140)) {
// Begin line 532
  setline(532);
// Begin line 531
  setline(531);
// compilenode returning *var_accum
  if (strlit1141 == NULL) {
    strlit1141 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1141
  params[0] = strlit1141;
  Object opresult1143 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1143
  *var_accum = opresult1143;
  if (opresult1143 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1137 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 537
  setline(537);
// Begin line 532
  setline(532);
// compilenode returning *var_c
  if (strlit1146 == NULL) {
    strlit1146 = alloc_String("u");
  }
// compilenode returning strlit1146
  params[0] = strlit1146;
  Object opresult1148 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1148
  Object if1145;
  if (istrue(opresult1148)) {
// Begin line 536
  setline(536);
// Begin line 535
  setline(535);
  Object num1149 = alloc_Float64(4.0);
// compilenode returning num1149
  *var_unichars = num1149;
  if (num1149 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 537
  setline(537);
// Begin line 536
  setline(536);
  Object num1151 = alloc_Float64(0.0);
// compilenode returning num1151
  *var_codepoint = num1151;
  if (num1151 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1145 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 542
  setline(542);
// Begin line 537
  setline(537);
// compilenode returning *var_c
  if (strlit1154 == NULL) {
    strlit1154 = alloc_String("U");
  }
// compilenode returning strlit1154
  params[0] = strlit1154;
  Object opresult1156 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1156
  Object if1153;
  if (istrue(opresult1156)) {
// Begin line 541
  setline(541);
// Begin line 540
  setline(540);
  Object num1157 = alloc_Float64(6.0);
// compilenode returning num1157
  *var_unichars = num1157;
  if (num1157 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 542
  setline(542);
// Begin line 541
  setline(541);
  Object num1159 = alloc_Float64(0.0);
// compilenode returning num1159
  *var_codepoint = num1159;
  if (num1159 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1153 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 545
  setline(545);
// Begin line 542
  setline(542);
// compilenode returning *var_c
  if (strlit1162 == NULL) {
    strlit1162 = alloc_String("t");
  }
// compilenode returning strlit1162
  params[0] = strlit1162;
  Object opresult1164 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1164
  Object if1161;
  if (istrue(opresult1164)) {
// Begin line 545
  setline(545);
// Begin line 544
  setline(544);
// compilenode returning *var_accum
  if (strlit1165 == NULL) {
    strlit1165 = alloc_String("""\x09""");
  }
// compilenode returning strlit1165
  params[0] = strlit1165;
  Object opresult1167 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1167
  *var_accum = opresult1167;
  if (opresult1167 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1161 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 548
  setline(548);
// Begin line 545
  setline(545);
// compilenode returning *var_c
  if (strlit1170 == NULL) {
    strlit1170 = alloc_String("r");
  }
// compilenode returning strlit1170
  params[0] = strlit1170;
  Object opresult1172 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1172
  Object if1169;
  if (istrue(opresult1172)) {
// Begin line 548
  setline(548);
// Begin line 547
  setline(547);
// compilenode returning *var_accum
  if (strlit1173 == NULL) {
    strlit1173 = alloc_String("""\x0d""");
  }
// compilenode returning strlit1173
  params[0] = strlit1173;
  Object opresult1175 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1175
  *var_accum = opresult1175;
  if (opresult1175 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1169 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 551
  setline(551);
// Begin line 548
  setline(548);
// compilenode returning *var_c
  if (strlit1178 == NULL) {
    strlit1178 = alloc_String("b");
  }
// compilenode returning strlit1178
  params[0] = strlit1178;
  Object opresult1180 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1180
  Object if1177;
  if (istrue(opresult1180)) {
// Begin line 551
  setline(551);
// Begin line 550
  setline(550);
// compilenode returning *var_accum
  if (strlit1181 == NULL) {
    strlit1181 = alloc_String("""\x08""");
  }
// compilenode returning strlit1181
  params[0] = strlit1181;
  Object opresult1183 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1183
  *var_accum = opresult1183;
  if (opresult1183 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1177 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 554
  setline(554);
// Begin line 551
  setline(551);
// compilenode returning *var_c
  if (strlit1186 == NULL) {
    strlit1186 = alloc_String("l");
  }
// compilenode returning strlit1186
  params[0] = strlit1186;
  Object opresult1188 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1188
  Object if1185;
  if (istrue(opresult1188)) {
// Begin line 554
  setline(554);
// Begin line 553
  setline(553);
// compilenode returning *var_accum
  if (strlit1189 == NULL) {
    strlit1189 = alloc_String("""\xe2""""\x80""""\xa8""");
  }
// compilenode returning strlit1189
  params[0] = strlit1189;
  Object opresult1191 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1191
  *var_accum = opresult1191;
  if (opresult1191 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1185 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 557
  setline(557);
// Begin line 554
  setline(554);
// compilenode returning *var_c
  if (strlit1194 == NULL) {
    strlit1194 = alloc_String("f");
  }
// compilenode returning strlit1194
  params[0] = strlit1194;
  Object opresult1196 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1196
  Object if1193;
  if (istrue(opresult1196)) {
// Begin line 557
  setline(557);
// Begin line 556
  setline(556);
// compilenode returning *var_accum
  if (strlit1197 == NULL) {
    strlit1197 = alloc_String("""\x0c""");
  }
// compilenode returning strlit1197
  params[0] = strlit1197;
  Object opresult1199 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1199
  *var_accum = opresult1199;
  if (opresult1199 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1193 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 560
  setline(560);
// Begin line 557
  setline(557);
// compilenode returning *var_c
  if (strlit1202 == NULL) {
    strlit1202 = alloc_String("e");
  }
// compilenode returning strlit1202
  params[0] = strlit1202;
  Object opresult1204 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1204
  Object if1201;
  if (istrue(opresult1204)) {
// Begin line 560
  setline(560);
// Begin line 559
  setline(559);
// compilenode returning *var_accum
  if (strlit1205 == NULL) {
    strlit1205 = alloc_String("""\x1b""");
  }
// compilenode returning strlit1205
  params[0] = strlit1205;
  Object opresult1207 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1207
  *var_accum = opresult1207;
  if (opresult1207 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1201 = nothing;
  } else {
// Begin line 564
  setline(564);
// Begin line 563
  setline(563);
// compilenode returning *var_accum
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult1210 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1210
  *var_accum = opresult1210;
  if (opresult1210 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1201 = nothing;
  }
// compilenode returning if1201
    if1193 = if1201;
  }
// compilenode returning if1193
    if1185 = if1193;
  }
// compilenode returning if1185
    if1177 = if1185;
  }
// compilenode returning if1177
    if1169 = if1177;
  }
// compilenode returning if1169
    if1161 = if1169;
  }
// compilenode returning if1161
    if1153 = if1161;
  }
// compilenode returning if1153
    if1145 = if1153;
  }
// compilenode returning if1145
    if1137 = if1145;
  }
// compilenode returning if1137
// Begin line 566
  setline(566);
// Begin line 565
  setline(565);
  Object bool1212 = alloc_Boolean(0);
// compilenode returning bool1212
  *var_escaped = bool1212;
  if (bool1212 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1136 = nothing;
  } else {
// Begin line 597
  setline(597);
// Begin line 569
  setline(569);
// Begin line 566
  setline(566);
// compilenode returning *var_c
  if (strlit1215 == NULL) {
    strlit1215 = alloc_String("\\");
  }
// compilenode returning strlit1215
  params[0] = strlit1215;
  Object opresult1217 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1217
  Object if1214;
  if (istrue(opresult1217)) {
// Begin line 569
  setline(569);
// Begin line 568
  setline(568);
  Object bool1218 = alloc_Boolean(1);
// compilenode returning bool1218
  *var_escaped = bool1218;
  if (bool1218 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1214 = nothing;
  } else {
// Begin line 597
  setline(597);
// Begin line 582
  setline(582);
// Begin line 569
  setline(569);
// compilenode returning *var_unichars
  Object num1221 = alloc_Float64(0.0);
// compilenode returning num1221
  params[0] = num1221;
  Object opresult1223 = callmethod(*var_unichars, ">", 1, params);
// compilenode returning opresult1223
  Object if1220;
  if (istrue(opresult1223)) {
// Begin line 575
  setline(575);
// Begin line 574
  setline(574);
// compilenode returning *var_unichars
  Object num1224 = alloc_Float64(1.0);
// compilenode returning num1224
  params[0] = num1224;
  Object diff1226 = callmethod(*var_unichars, "-", 1, params);
// compilenode returning diff1226
  *var_unichars = diff1226;
  if (diff1226 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 576
  setline(576);
// Begin line 575
  setline(575);
// compilenode returning *var_codepoint
  Object num1228 = alloc_Float64(16.0);
// compilenode returning num1228
  params[0] = num1228;
  Object prod1230 = callmethod(*var_codepoint, "*", 1, params);
// compilenode returning prod1230
  *var_codepoint = prod1230;
  if (prod1230 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 576
  setline(576);
// compilenode returning *var_codepoint
// compilenode returning *var_c
// Begin line 577
  setline(577);
// Begin line 633
  setline(633);
// Begin line 577
  setline(577);
// Begin line 633
  setline(633);
// Begin line 577
  setline(577);
// compilenode returning self
  Object call1232 = callmethod(self, "outer",
    0, params);
// compilenode returning call1232
// compilenode returning call1232
  Object call1233 = callmethod(call1232, "outer",
    0, params);
// compilenode returning call1233
// compilenode returning call1233
  params[0] = *var_c;
  Object call1234 = callmethod(call1233, "hexdecchar",
    1, params);
// compilenode returning call1234
  params[0] = call1234;
  Object sum1236 = callmethod(*var_codepoint, "+", 1, params);
// compilenode returning sum1236
  *var_codepoint = sum1236;
  if (sum1236 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 580
  setline(580);
// Begin line 582
  setline(582);
// Begin line 577
  setline(577);
// compilenode returning *var_unichars
  Object num1239 = alloc_Float64(0.0);
// compilenode returning num1239
  params[0] = num1239;
  Object opresult1241 = callmethod(*var_unichars, "==", 1, params);
// compilenode returning opresult1241
  Object if1238;
  if (istrue(opresult1241)) {
// Begin line 580
  setline(580);
// compilenode returning *var_accum
// compilenode returning *var_codepoint
// compilenode returning module_unicode
  params[0] = *var_codepoint;
  Object call1242 = callmethod(module_unicode, "create",
    1, params);
// compilenode returning call1242
  params[0] = call1242;
  Object opresult1244 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1244
  *var_accum = opresult1244;
  if (opresult1244 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1238 = nothing;
  } else {
  }
// compilenode returning if1238
    if1220 = if1238;
  } else {
// Begin line 597
  setline(597);
// Begin line 595
  setline(595);
// Begin line 582
  setline(582);
// compilenode returning *var_c
  if (strlit1247 == NULL) {
    strlit1247 = alloc_String("{");
  }
// compilenode returning strlit1247
  params[0] = strlit1247;
  Object opresult1249 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1249
  Object if1246;
  if (istrue(opresult1249)) {
// Begin line 586
  setline(586);
// Begin line 587
  setline(587);
// Begin line 633
  setline(633);
// Begin line 583
  setline(583);
// compilenode returning *var_interpString
  Object call1251 = callmethod(*var_interpString, "not",
    0, params);
// compilenode returning call1251
// compilenode returning call1251
  Object if1250;
  if (istrue(call1251)) {
// Begin line 584
  setline(584);
// compilenode returning *var_tokens
  if (strlit1252 == NULL) {
    strlit1252 = alloc_String("(");
  }
// compilenode returning strlit1252
  if (strlit1253 == NULL) {
    strlit1253 = alloc_String("(");
  }
// compilenode returning strlit1253
// Begin line 585
  setline(585);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = strlit1252;
  params[2] = strlit1253;
  Object call1254 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1254
// Begin line 586
  setline(586);
// Begin line 585
  setline(585);
  Object bool1255 = alloc_Boolean(1);
// compilenode returning bool1255
  *var_interpString = bool1255;
  if (bool1255 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1250 = nothing;
  } else {
  }
// compilenode returning if1250
// Begin line 587
  setline(587);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 588
  setline(588);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call1257 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1257
// compilenode returning *var_tokens
  if (strlit1258 == NULL) {
    strlit1258 = alloc_String("o");
  }
// compilenode returning strlit1258
  if (strlit1259 == NULL) {
    strlit1259 = alloc_String("++");
  }
// compilenode returning strlit1259
// Begin line 589
  setline(589);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = strlit1258;
  params[2] = strlit1259;
  Object call1260 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1260
// compilenode returning *var_tokens
  if (strlit1261 == NULL) {
    strlit1261 = alloc_String("(");
  }
// compilenode returning strlit1261
  if (strlit1262 == NULL) {
    strlit1262 = alloc_String("(");
  }
// compilenode returning strlit1262
// Begin line 590
  setline(590);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = strlit1261;
  params[2] = strlit1262;
  Object call1263 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1263
// Begin line 591
  setline(591);
// Begin line 590
  setline(590);
  if (strlit1264 == NULL) {
    strlit1264 = alloc_String("n");
  }
// compilenode returning strlit1264
  *var_mode = strlit1264;
  if (strlit1264 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 592
  setline(592);
// Begin line 591
  setline(591);
  if (strlit1266 == NULL) {
    strlit1266 = alloc_String("n");
  }
// compilenode returning strlit1266
  *var_newmode = strlit1266;
  if (strlit1266 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 593
  setline(593);
// Begin line 592
  setline(592);
  if (strlit1268 == NULL) {
    strlit1268 = alloc_String("");
  }
// compilenode returning strlit1268
  *var_accum = strlit1268;
  if (strlit1268 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 594
  setline(594);
// Begin line 593
  setline(593);
  Object bool1270 = alloc_Boolean(0);
// compilenode returning bool1270
  *var_instr = bool1270;
  if (bool1270 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 595
  setline(595);
// Begin line 594
  setline(594);
// compilenode returning *var_interpdepth
  Object num1272 = alloc_Float64(1.0);
// compilenode returning num1272
  params[0] = num1272;
  Object sum1274 = callmethod(*var_interpdepth, "+", 1, params);
// compilenode returning sum1274
  *var_interpdepth = sum1274;
  if (sum1274 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1246 = nothing;
  } else {
// Begin line 597
  setline(597);
// Begin line 596
  setline(596);
// compilenode returning *var_accum
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult1277 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1277
  *var_accum = opresult1277;
  if (opresult1277 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1246 = nothing;
  }
// compilenode returning if1246
    if1220 = if1246;
  }
// compilenode returning if1220
    if1214 = if1220;
  }
// compilenode returning if1214
    if1136 = if1214;
  }
// compilenode returning if1136
    if1117 = if1136;
  } else {
// Begin line 612
  setline(612);
// Begin line 598
  setline(598);
// compilenode returning *var_inBackticks
  Object if1279;
  if (istrue(*var_inBackticks)) {
// Begin line 601
  setline(601);
// Begin line 603
  setline(603);
// Begin line 599
  setline(599);
// compilenode returning *var_c
  if (strlit1281 == NULL) {
    strlit1281 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1281
  params[0] = strlit1281;
  Object opresult1283 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1283
  Object if1280;
  if (istrue(opresult1283)) {
// Begin line 601
  setline(601);
// Begin line 600
  setline(600);
  if (strlit1284 == NULL) {
    strlit1284 = alloc_String("Newlines not permitted in");
  }
// compilenode returning strlit1284
// Begin line 601
  setline(601);
  if (strlit1285 == NULL) {
    strlit1285 = alloc_String("backtick identifiers");
  }
// compilenode returning strlit1285
  params[0] = strlit1285;
  Object opresult1287 = callmethod(strlit1284, "++", 1, params);
// compilenode returning opresult1287
// Begin line 600
  setline(600);
// compilenode returning module_util
  params[0] = opresult1287;
  Object call1288 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1288
    if1280 = call1288;
  } else {
  }
// compilenode returning if1280
// Begin line 604
  setline(604);
// Begin line 603
  setline(603);
// compilenode returning *var_accum
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult1290 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1290
  *var_accum = opresult1290;
  if (opresult1290 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1279 = nothing;
  } else {
// Begin line 612
  setline(612);
// Begin line 610
  setline(610);
// Begin line 604
  setline(604);
// compilenode returning *var_c
  if (strlit1293 == NULL) {
    strlit1293 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1293
  params[0] = strlit1293;
  Object opresult1295 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1295
  Object if1292;
  if (istrue(opresult1295)) {
// Begin line 606
  setline(606);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 607
  setline(607);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call1296 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1296
// Begin line 608
  setline(608);
// Begin line 607
  setline(607);
  if (strlit1297 == NULL) {
    strlit1297 = alloc_String("d");
  }
// compilenode returning strlit1297
  *var_mode = strlit1297;
  if (strlit1297 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 609
  setline(609);
// Begin line 608
  setline(608);
  if (strlit1299 == NULL) {
    strlit1299 = alloc_String("d");
  }
// compilenode returning strlit1299
  *var_newmode = strlit1299;
  if (strlit1299 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 610
  setline(610);
// Begin line 609
  setline(609);
  if (strlit1301 == NULL) {
    strlit1301 = alloc_String("");
  }
// compilenode returning strlit1301
  *var_accum = strlit1301;
  if (strlit1301 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1292 = nothing;
  } else {
// Begin line 612
  setline(612);
// Begin line 611
  setline(611);
// compilenode returning *var_accum
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult1304 = callmethod(*var_accum, "++", 1, params);
// compilenode returning opresult1304
  *var_accum = opresult1304;
  if (opresult1304 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1292 = nothing;
  }
// compilenode returning if1292
    if1279 = if1292;
  }
// compilenode returning if1279
    if1117 = if1279;
  }
// compilenode returning if1117
    if1045 = if1117;
  }
// compilenode returning if1045
// Begin line 621
  setline(621);
// Begin line 623
  setline(623);
// Begin line 613
  setline(613);
// compilenode returning *var_c
  if (strlit1307 == NULL) {
    strlit1307 = alloc_String("""\x0a""");
  }
// compilenode returning strlit1307
  params[0] = strlit1307;
  Object opresult1309 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult1309
  Object if1306;
  if (istrue(opresult1309)) {
// Begin line 619
  setline(619);
// Begin line 618
  setline(618);
// compilenode returning *var_lineNumber
  Object num1310 = alloc_Float64(1.0);
// compilenode returning num1310
  params[0] = num1310;
  Object sum1312 = callmethod(*var_lineNumber, "+", 1, params);
// compilenode returning sum1312
  *var_lineNumber = sum1312;
  if (sum1312 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 620
  setline(620);
// Begin line 619
  setline(619);
  Object num1314 = alloc_Float64(0.0);
// compilenode returning num1314
  *var_linePosition = num1314;
  if (num1314 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 621
  setline(621);
// Begin line 620
  setline(620);
  Object num1316 = alloc_Float64(1.0);
// compilenode returning num1316
  *var_startPosition = num1316;
  if (num1316 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 621
  setline(621);
// compilenode returning *var_lineNumber
  Object num1318 = alloc_Float64(0.0);
// compilenode returning num1318
// compilenode returning module_util
  params[0] = *var_lineNumber;
  params[1] = num1318;
  Object call1319 = callmethod(module_util, "setPosition",
    2, params);
// compilenode returning call1319
    if1306 = call1319;
  } else {
  }
// compilenode returning if1306
// Begin line 624
  setline(624);
// Begin line 623
  setline(623);
// compilenode returning *var_c
  *var_prev = *var_c;
  if (*var_c == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_lexer_lexfile645(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_file = alloc_var();
  *var_file = args[0];
  Object params[3];
  Object *var_linePosition = closure[0];
  Object *var_lineNumber = closure[1];
  Object *var_startPosition = closure[2];
  Object *var_input = alloc_var();
  *var_input = undefined;
  Object *var_tokens = alloc_var();
  *var_tokens = undefined;
  Object *var_mode = alloc_var();
  *var_mode = undefined;
  Object *var_newmode = alloc_var();
  *var_newmode = undefined;
  Object *var_instr = alloc_var();
  *var_instr = undefined;
  Object *var_inBackticks = alloc_var();
  *var_inBackticks = undefined;
  Object *var_backtickIdent = alloc_var();
  *var_backtickIdent = undefined;
  Object *var_accum = alloc_var();
  *var_accum = undefined;
  Object *var_escaped = alloc_var();
  *var_escaped = undefined;
  Object *var_prev = alloc_var();
  *var_prev = undefined;
  Object *var_unichars = alloc_var();
  *var_unichars = undefined;
  Object *var_codepoint = alloc_var();
  *var_codepoint = undefined;
  Object *var_interpdepth = alloc_var();
  *var_interpdepth = undefined;
  Object *var_interpString = alloc_var();
  *var_interpString = undefined;
  Object *var_atStart = alloc_var();
  *var_atStart = undefined;
// Begin line 353
  setline(353);
  if (strlit646 == NULL) {
    strlit646 = alloc_String("reading source.");
  }
// compilenode returning strlit646
// compilenode returning module_util
  params[0] = strlit646;
  Object call647 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call647
// Begin line 356
  setline(356);
// Begin line 633
  setline(633);
// Begin line 354
  setline(354);
// compilenode returning *var_file
  Object call648 = callmethod(*var_file, "read",
    0, params);
// compilenode returning call648
// compilenode returning call648
  var_input = alloc_var();
  *var_input = call648;
  if (call648 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 357
  setline(357);
  Object array649 = alloc_List();
// compilenode returning array649
  var_tokens = alloc_var();
  *var_tokens = array649;
  if (array649 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 358
  setline(358);
// Begin line 357
  setline(357);
  if (strlit650 == NULL) {
    strlit650 = alloc_String("n");
  }
// compilenode returning strlit650
  var_mode = alloc_var();
  *var_mode = strlit650;
  if (strlit650 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 359
  setline(359);
// Begin line 358
  setline(358);
// compilenode returning *var_mode
  var_newmode = alloc_var();
  *var_newmode = *var_mode;
  if (*var_mode == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 360
  setline(360);
// Begin line 359
  setline(359);
  Object bool651 = alloc_Boolean(0);
// compilenode returning bool651
  var_instr = alloc_var();
  *var_instr = bool651;
  if (bool651 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 361
  setline(361);
// Begin line 360
  setline(360);
  Object bool652 = alloc_Boolean(0);
// compilenode returning bool652
  var_inBackticks = alloc_var();
  *var_inBackticks = bool652;
  if (bool652 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 362
  setline(362);
// Begin line 361
  setline(361);
  Object bool653 = alloc_Boolean(0);
// compilenode returning bool653
  var_backtickIdent = alloc_var();
  *var_backtickIdent = bool653;
  if (bool653 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 363
  setline(363);
// Begin line 362
  setline(362);
  if (strlit654 == NULL) {
    strlit654 = alloc_String("");
  }
// compilenode returning strlit654
  var_accum = alloc_var();
  *var_accum = strlit654;
  if (strlit654 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 364
  setline(364);
// Begin line 363
  setline(363);
  Object bool655 = alloc_Boolean(0);
// compilenode returning bool655
  var_escaped = alloc_var();
  *var_escaped = bool655;
  if (bool655 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 365
  setline(365);
// Begin line 364
  setline(364);
  if (strlit656 == NULL) {
    strlit656 = alloc_String("");
  }
// compilenode returning strlit656
  var_prev = alloc_var();
  *var_prev = strlit656;
  if (strlit656 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 366
  setline(366);
// Begin line 365
  setline(365);
  Object num657 = alloc_Float64(0.0);
// compilenode returning num657
  var_unichars = alloc_var();
  *var_unichars = num657;
  if (num657 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 367
  setline(367);
// Begin line 366
  setline(366);
  Object num658 = alloc_Float64(0.0);
// compilenode returning num658
  var_codepoint = alloc_var();
  *var_codepoint = num658;
  if (num658 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 368
  setline(368);
// Begin line 367
  setline(367);
  Object num659 = alloc_Float64(0.0);
// compilenode returning num659
  var_interpdepth = alloc_var();
  *var_interpdepth = num659;
  if (num659 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 369
  setline(369);
// Begin line 368
  setline(368);
  Object bool660 = alloc_Boolean(0);
// compilenode returning bool660
  var_interpString = alloc_var();
  *var_interpString = bool660;
  if (bool660 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 370
  setline(370);
// Begin line 369
  setline(369);
  Object bool661 = alloc_Boolean(1);
// compilenode returning bool661
  var_atStart = alloc_var();
  *var_atStart = bool661;
  if (bool661 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 371
  setline(371);
// Begin line 370
  setline(370);
  Object num662 = alloc_Float64(0.0);
// compilenode returning num662
  *var_linePosition = num662;
  if (num662 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 371
  setline(371);
  if (strlit664 == NULL) {
    strlit664 = alloc_String("lexing.");
  }
// compilenode returning strlit664
// compilenode returning module_util
  params[0] = strlit664;
  Object call665 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call665
// Begin line 624
  setline(624);
// Begin line 372
  setline(372);
// compilenode returning *var_input
// Begin line 624
  setline(624);
// Begin line 633
  setline(633);
  Object obj668 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj668, self, 0);
  addmethod2(obj668, "outer", &reader_lexer_outer_669);
  adddatum2(obj668, self, 0);
  block_savedest(obj668);
  Object **closure670 = createclosure(18);
  addtoclosure(closure670, var_linePosition);
  addtoclosure(closure670, var_lineNumber);
  addtoclosure(closure670, var_atStart);
  addtoclosure(closure670, var_mode);
  addtoclosure(closure670, var_newmode);
  addtoclosure(closure670, var_instr);
  addtoclosure(closure670, var_inBackticks);
  addtoclosure(closure670, var_prev);
  addtoclosure(closure670, var_tokens);
  addtoclosure(closure670, var_accum);
  addtoclosure(closure670, var_escaped);
  addtoclosure(closure670, var_interpString);
  addtoclosure(closure670, var_backtickIdent);
  addtoclosure(closure670, var_interpdepth);
  addtoclosure(closure670, var_unichars);
  addtoclosure(closure670, var_codepoint);
  addtoclosure(closure670, var_startPosition);
  Object *selfpp1321 = alloc_var();
  *selfpp1321 = self;
  addtoclosure(closure670, selfpp1321);
  struct UserObject *uo670 = (struct UserObject*)obj668;
  uo670->data[1] = (Object)closure670;
  addmethod2(obj668, "apply", &meth_lexer_apply670);
  set_type(obj668, 0);
// compilenode returning obj668
  setclassname(obj668, "Block<lexer:667>");
// compilenode returning obj668
  params[0] = *var_input;
  Object iter666 = callmethod(*var_input, "iter", 1, params);
  while(1) {
    Object cond666 = callmethod(iter666, "havemore", 0, NULL);
    if (!istrue(cond666)) break;
    params[0] = callmethod(iter666, "next", 0, NULL);
    callmethod(obj668, "apply", 1, params);
  }
// compilenode returning *var_input
// Begin line 625
  setline(625);
// compilenode returning *var_tokens
// compilenode returning *var_mode
// compilenode returning *var_accum
// Begin line 626
  setline(626);
// compilenode returning self
  params[0] = *var_tokens;
  params[1] = *var_mode;
  params[2] = *var_accum;
  Object call1322 = callmethod(self, "modechange",
    3, params);
// compilenode returning call1322
// compilenode returning *var_tokens
  return *var_tokens;
}
Object meth_lexer_new40(Object self, int nparams, Object *args, int32_t flags) {
  Object params[1];
  Object *var_lineNumber = alloc_var();
  *var_lineNumber = undefined;
  Object *var_linePosition = alloc_var();
  *var_linePosition = undefined;
  Object *var_startPosition = alloc_var();
  *var_startPosition = undefined;
  Object *var_indentLevel = alloc_var();
  *var_indentLevel = undefined;
  Object *var_IdentifierToken = alloc_var();
  *var_IdentifierToken = undefined;
  Object *var_StringToken = alloc_var();
  *var_StringToken = undefined;
  Object *var_OctetsToken = alloc_var();
  *var_OctetsToken = undefined;
  Object *var_LBraceToken = alloc_var();
  *var_LBraceToken = undefined;
  Object *var_RBraceToken = alloc_var();
  *var_RBraceToken = undefined;
  Object *var_LParenToken = alloc_var();
  *var_LParenToken = undefined;
  Object *var_RParenToken = alloc_var();
  *var_RParenToken = undefined;
  Object *var_LSquareToken = alloc_var();
  *var_LSquareToken = undefined;
  Object *var_RSquareToken = alloc_var();
  *var_RSquareToken = undefined;
  Object *var_CommaToken = alloc_var();
  *var_CommaToken = undefined;
  Object *var_ColonToken = alloc_var();
  *var_ColonToken = undefined;
  Object *var_DotToken = alloc_var();
  *var_DotToken = undefined;
  Object *var_NumToken = alloc_var();
  *var_NumToken = undefined;
  Object *var_KeywordToken = alloc_var();
  *var_KeywordToken = undefined;
  Object *var_OpToken = alloc_var();
  *var_OpToken = undefined;
  Object *var_ArrowToken = alloc_var();
  *var_ArrowToken = undefined;
  Object *var_BindToken = alloc_var();
  *var_BindToken = undefined;
  Object *var_SemicolonToken = alloc_var();
  *var_SemicolonToken = undefined;
  Object *var_LGenericToken = alloc_var();
  *var_LGenericToken = undefined;
  Object *var_RGenericToken = alloc_var();
  *var_RGenericToken = undefined;
// Begin line 24
  setline(24);
// Begin line 23
  setline(23);
  Object num41 = alloc_Float64(1.0);
// compilenode returning num41
  var_lineNumber = alloc_var();
  *var_lineNumber = num41;
  if (num41 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 25
  setline(25);
// Begin line 24
  setline(24);
  Object num42 = alloc_Float64(0.0);
// compilenode returning num42
  var_linePosition = alloc_var();
  *var_linePosition = num42;
  if (num42 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 26
  setline(26);
// Begin line 25
  setline(25);
  Object num43 = alloc_Float64(1.0);
// compilenode returning num43
  var_startPosition = alloc_var();
  *var_startPosition = num43;
  if (num43 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 28
  setline(28);
// Begin line 26
  setline(26);
  Object num44 = alloc_Float64(0.0);
// compilenode returning num44
  var_indentLevel = alloc_var();
  *var_indentLevel = num44;
  if (num44 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 28
  setline(28);
// Begin line 633
  setline(633);
  Object obj45 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj45, self, 0);
  addmethod2(obj45, "outer", &reader_lexer_outer_46);
  adddatum2(obj45, self, 0);
  block_savedest(obj45);
  Object **closure47 = createclosure(3);
  addtoclosure(closure47, var_lineNumber);
  addtoclosure(closure47, var_indentLevel);
  addtoclosure(closure47, var_startPosition);
  struct UserObject *uo47 = (struct UserObject*)obj45;
  uo47->data[1] = (Object)closure47;
  addmethod2(obj45, "new", &meth_lexer_new47);
  set_type(obj45, 0);
// compilenode returning obj45
  *var_IdentifierToken = obj45;
  if (obj45 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 35
  setline(35);
// Begin line 633
  setline(633);
  Object obj56 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj56, self, 0);
  addmethod2(obj56, "outer", &reader_lexer_outer_57);
  adddatum2(obj56, self, 0);
  block_savedest(obj56);
  Object **closure58 = createclosure(3);
  addtoclosure(closure58, var_lineNumber);
  addtoclosure(closure58, var_indentLevel);
  addtoclosure(closure58, var_startPosition);
  struct UserObject *uo58 = (struct UserObject*)obj56;
  uo58->data[1] = (Object)closure58;
  addmethod2(obj56, "new", &meth_lexer_new58);
  set_type(obj56, 0);
// compilenode returning obj56
  *var_StringToken = obj56;
  if (obj56 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 42
  setline(42);
// Begin line 633
  setline(633);
  Object obj67 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj67, self, 0);
  addmethod2(obj67, "outer", &reader_lexer_outer_68);
  adddatum2(obj67, self, 0);
  block_savedest(obj67);
  Object **closure69 = createclosure(3);
  addtoclosure(closure69, var_lineNumber);
  addtoclosure(closure69, var_indentLevel);
  addtoclosure(closure69, var_startPosition);
  struct UserObject *uo69 = (struct UserObject*)obj67;
  uo69->data[1] = (Object)closure69;
  addmethod2(obj67, "new", &meth_lexer_new69);
  set_type(obj67, 0);
// compilenode returning obj67
  *var_OctetsToken = obj67;
  if (obj67 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 55
  setline(55);
// Begin line 633
  setline(633);
  Object obj78 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj78, self, 0);
  addmethod2(obj78, "outer", &reader_lexer_outer_79);
  adddatum2(obj78, self, 0);
  block_savedest(obj78);
  Object **closure80 = createclosure(3);
  addtoclosure(closure80, var_lineNumber);
  addtoclosure(closure80, var_indentLevel);
  addtoclosure(closure80, var_startPosition);
  struct UserObject *uo80 = (struct UserObject*)obj78;
  uo80->data[1] = (Object)closure80;
  addmethod2(obj78, "new", &meth_lexer_new80);
  set_type(obj78, 0);
// compilenode returning obj78
  *var_LBraceToken = obj78;
  if (obj78 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 62
  setline(62);
// Begin line 633
  setline(633);
  Object obj90 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj90, self, 0);
  addmethod2(obj90, "outer", &reader_lexer_outer_91);
  adddatum2(obj90, self, 0);
  block_savedest(obj90);
  Object **closure92 = createclosure(3);
  addtoclosure(closure92, var_lineNumber);
  addtoclosure(closure92, var_indentLevel);
  addtoclosure(closure92, var_startPosition);
  struct UserObject *uo92 = (struct UserObject*)obj90;
  uo92->data[1] = (Object)closure92;
  addmethod2(obj90, "new", &meth_lexer_new92);
  set_type(obj90, 0);
// compilenode returning obj90
  *var_RBraceToken = obj90;
  if (obj90 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 69
  setline(69);
// Begin line 633
  setline(633);
  Object obj102 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj102, self, 0);
  addmethod2(obj102, "outer", &reader_lexer_outer_103);
  adddatum2(obj102, self, 0);
  block_savedest(obj102);
  Object **closure104 = createclosure(3);
  addtoclosure(closure104, var_lineNumber);
  addtoclosure(closure104, var_indentLevel);
  addtoclosure(closure104, var_startPosition);
  struct UserObject *uo104 = (struct UserObject*)obj102;
  uo104->data[1] = (Object)closure104;
  addmethod2(obj102, "new", &meth_lexer_new104);
  set_type(obj102, 0);
// compilenode returning obj102
  *var_LParenToken = obj102;
  if (obj102 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 76
  setline(76);
// Begin line 633
  setline(633);
  Object obj114 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj114, self, 0);
  addmethod2(obj114, "outer", &reader_lexer_outer_115);
  adddatum2(obj114, self, 0);
  block_savedest(obj114);
  Object **closure116 = createclosure(3);
  addtoclosure(closure116, var_lineNumber);
  addtoclosure(closure116, var_indentLevel);
  addtoclosure(closure116, var_startPosition);
  struct UserObject *uo116 = (struct UserObject*)obj114;
  uo116->data[1] = (Object)closure116;
  addmethod2(obj114, "new", &meth_lexer_new116);
  set_type(obj114, 0);
// compilenode returning obj114
  *var_RParenToken = obj114;
  if (obj114 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 83
  setline(83);
// Begin line 633
  setline(633);
  Object obj126 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj126, self, 0);
  addmethod2(obj126, "outer", &reader_lexer_outer_127);
  adddatum2(obj126, self, 0);
  block_savedest(obj126);
  Object **closure128 = createclosure(3);
  addtoclosure(closure128, var_lineNumber);
  addtoclosure(closure128, var_indentLevel);
  addtoclosure(closure128, var_startPosition);
  struct UserObject *uo128 = (struct UserObject*)obj126;
  uo128->data[1] = (Object)closure128;
  addmethod2(obj126, "new", &meth_lexer_new128);
  set_type(obj126, 0);
// compilenode returning obj126
  *var_LSquareToken = obj126;
  if (obj126 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 90
  setline(90);
// Begin line 633
  setline(633);
  Object obj138 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj138, self, 0);
  addmethod2(obj138, "outer", &reader_lexer_outer_139);
  adddatum2(obj138, self, 0);
  block_savedest(obj138);
  Object **closure140 = createclosure(3);
  addtoclosure(closure140, var_lineNumber);
  addtoclosure(closure140, var_indentLevel);
  addtoclosure(closure140, var_startPosition);
  struct UserObject *uo140 = (struct UserObject*)obj138;
  uo140->data[1] = (Object)closure140;
  addmethod2(obj138, "new", &meth_lexer_new140);
  set_type(obj138, 0);
// compilenode returning obj138
  *var_RSquareToken = obj138;
  if (obj138 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 97
  setline(97);
// Begin line 633
  setline(633);
  Object obj150 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj150, self, 0);
  addmethod2(obj150, "outer", &reader_lexer_outer_151);
  adddatum2(obj150, self, 0);
  block_savedest(obj150);
  Object **closure152 = createclosure(3);
  addtoclosure(closure152, var_lineNumber);
  addtoclosure(closure152, var_indentLevel);
  addtoclosure(closure152, var_startPosition);
  struct UserObject *uo152 = (struct UserObject*)obj150;
  uo152->data[1] = (Object)closure152;
  addmethod2(obj150, "new", &meth_lexer_new152);
  set_type(obj150, 0);
// compilenode returning obj150
  *var_CommaToken = obj150;
  if (obj150 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 104
  setline(104);
// Begin line 633
  setline(633);
  Object obj162 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj162, self, 0);
  addmethod2(obj162, "outer", &reader_lexer_outer_163);
  adddatum2(obj162, self, 0);
  block_savedest(obj162);
  Object **closure164 = createclosure(3);
  addtoclosure(closure164, var_lineNumber);
  addtoclosure(closure164, var_indentLevel);
  addtoclosure(closure164, var_startPosition);
  struct UserObject *uo164 = (struct UserObject*)obj162;
  uo164->data[1] = (Object)closure164;
  addmethod2(obj162, "new", &meth_lexer_new164);
  set_type(obj162, 0);
// compilenode returning obj162
  *var_ColonToken = obj162;
  if (obj162 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 111
  setline(111);
// Begin line 633
  setline(633);
  Object obj174 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj174, self, 0);
  addmethod2(obj174, "outer", &reader_lexer_outer_175);
  adddatum2(obj174, self, 0);
  block_savedest(obj174);
  Object **closure176 = createclosure(3);
  addtoclosure(closure176, var_lineNumber);
  addtoclosure(closure176, var_indentLevel);
  addtoclosure(closure176, var_startPosition);
  struct UserObject *uo176 = (struct UserObject*)obj174;
  uo176->data[1] = (Object)closure176;
  addmethod2(obj174, "new", &meth_lexer_new176);
  set_type(obj174, 0);
// compilenode returning obj174
  *var_DotToken = obj174;
  if (obj174 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 112
  setline(112);
// Begin line 633
  setline(633);
  Object obj186 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj186, self, 0);
  addmethod2(obj186, "outer", &reader_lexer_outer_187);
  adddatum2(obj186, self, 0);
  block_savedest(obj186);
  Object **closure188 = createclosure(3);
  addtoclosure(closure188, var_lineNumber);
  addtoclosure(closure188, var_indentLevel);
  addtoclosure(closure188, var_startPosition);
  struct UserObject *uo188 = (struct UserObject*)obj186;
  uo188->data[1] = (Object)closure188;
  addmethod2(obj186, "new", &meth_lexer_new188);
  set_type(obj186, 0);
// compilenode returning obj186
  *var_NumToken = obj186;
  if (obj186 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 119
  setline(119);
// Begin line 633
  setline(633);
  Object obj197 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj197, self, 0);
  addmethod2(obj197, "outer", &reader_lexer_outer_198);
  adddatum2(obj197, self, 0);
  block_savedest(obj197);
  Object **closure199 = createclosure(3);
  addtoclosure(closure199, var_lineNumber);
  addtoclosure(closure199, var_indentLevel);
  addtoclosure(closure199, var_startPosition);
  struct UserObject *uo199 = (struct UserObject*)obj197;
  uo199->data[1] = (Object)closure199;
  addmethod2(obj197, "new", &meth_lexer_new199);
  set_type(obj197, 0);
// compilenode returning obj197
  *var_KeywordToken = obj197;
  if (obj197 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 126
  setline(126);
// Begin line 633
  setline(633);
  Object obj208 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj208, self, 0);
  addmethod2(obj208, "outer", &reader_lexer_outer_209);
  adddatum2(obj208, self, 0);
  block_savedest(obj208);
  Object **closure210 = createclosure(3);
  addtoclosure(closure210, var_lineNumber);
  addtoclosure(closure210, var_indentLevel);
  addtoclosure(closure210, var_startPosition);
  struct UserObject *uo210 = (struct UserObject*)obj208;
  uo210->data[1] = (Object)closure210;
  addmethod2(obj208, "new", &meth_lexer_new210);
  set_type(obj208, 0);
// compilenode returning obj208
  *var_OpToken = obj208;
  if (obj208 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 139
  setline(139);
// Begin line 633
  setline(633);
  Object obj219 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj219, self, 0);
  addmethod2(obj219, "outer", &reader_lexer_outer_220);
  adddatum2(obj219, self, 0);
  block_savedest(obj219);
  Object **closure221 = createclosure(3);
  addtoclosure(closure221, var_lineNumber);
  addtoclosure(closure221, var_indentLevel);
  addtoclosure(closure221, var_startPosition);
  struct UserObject *uo221 = (struct UserObject*)obj219;
  uo221->data[1] = (Object)closure221;
  addmethod2(obj219, "new", &meth_lexer_new221);
  set_type(obj219, 0);
// compilenode returning obj219
  *var_ArrowToken = obj219;
  if (obj219 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 146
  setline(146);
// Begin line 633
  setline(633);
  Object obj231 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj231, self, 0);
  addmethod2(obj231, "outer", &reader_lexer_outer_232);
  adddatum2(obj231, self, 0);
  block_savedest(obj231);
  Object **closure233 = createclosure(3);
  addtoclosure(closure233, var_lineNumber);
  addtoclosure(closure233, var_indentLevel);
  addtoclosure(closure233, var_startPosition);
  struct UserObject *uo233 = (struct UserObject*)obj231;
  uo233->data[1] = (Object)closure233;
  addmethod2(obj231, "new", &meth_lexer_new233);
  set_type(obj231, 0);
// compilenode returning obj231
  *var_BindToken = obj231;
  if (obj231 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 153
  setline(153);
// Begin line 633
  setline(633);
  Object obj243 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj243, self, 0);
  addmethod2(obj243, "outer", &reader_lexer_outer_244);
  adddatum2(obj243, self, 0);
  block_savedest(obj243);
  Object **closure245 = createclosure(3);
  addtoclosure(closure245, var_lineNumber);
  addtoclosure(closure245, var_indentLevel);
  addtoclosure(closure245, var_startPosition);
  struct UserObject *uo245 = (struct UserObject*)obj243;
  uo245->data[1] = (Object)closure245;
  addmethod2(obj243, "new", &meth_lexer_new245);
  set_type(obj243, 0);
// compilenode returning obj243
  *var_SemicolonToken = obj243;
  if (obj243 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 160
  setline(160);
// Begin line 633
  setline(633);
  Object obj255 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj255, self, 0);
  addmethod2(obj255, "outer", &reader_lexer_outer_256);
  adddatum2(obj255, self, 0);
  block_savedest(obj255);
  Object **closure257 = createclosure(3);
  addtoclosure(closure257, var_lineNumber);
  addtoclosure(closure257, var_indentLevel);
  addtoclosure(closure257, var_startPosition);
  struct UserObject *uo257 = (struct UserObject*)obj255;
  uo257->data[1] = (Object)closure257;
  addmethod2(obj255, "new", &meth_lexer_new257);
  set_type(obj255, 0);
// compilenode returning obj255
  *var_LGenericToken = obj255;
  if (obj255 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 167
  setline(167);
// Begin line 633
  setline(633);
  Object obj267 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj267, self, 0);
  addmethod2(obj267, "outer", &reader_lexer_outer_268);
  adddatum2(obj267, self, 0);
  block_savedest(obj267);
  Object **closure269 = createclosure(3);
  addtoclosure(closure269, var_lineNumber);
  addtoclosure(closure269, var_indentLevel);
  addtoclosure(closure269, var_startPosition);
  struct UserObject *uo269 = (struct UserObject*)obj267;
  uo269->data[1] = (Object)closure269;
  addmethod2(obj267, "new", &meth_lexer_new269);
  set_type(obj267, 0);
// compilenode returning obj267
  *var_RGenericToken = obj267;
  if (obj267 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 626
  setline(626);
  Object obj279 = alloc_obj2(5,6);
// OBJECT OUTER DEC outer
  adddatum2(obj279, self, 0);
  addmethod2(obj279, "outer", &reader_lexer_outer_280);
  adddatum2(obj279, self, 0);
  block_savedest(obj279);
  Object **closure281 = createclosure(23);
  addtoclosure(closure281, var_IdentifierToken);
  addtoclosure(closure281, var_KeywordToken);
  addtoclosure(closure281, var_StringToken);
  addtoclosure(closure281, var_OctetsToken);
  addtoclosure(closure281, var_CommaToken);
  addtoclosure(closure281, var_DotToken);
  addtoclosure(closure281, var_LBraceToken);
  addtoclosure(closure281, var_RBraceToken);
  addtoclosure(closure281, var_LParenToken);
  addtoclosure(closure281, var_RParenToken);
  addtoclosure(closure281, var_LSquareToken);
  addtoclosure(closure281, var_RSquareToken);
  addtoclosure(closure281, var_LGenericToken);
  addtoclosure(closure281, var_RGenericToken);
  addtoclosure(closure281, var_SemicolonToken);
  addtoclosure(closure281, var_NumToken);
  addtoclosure(closure281, var_OpToken);
  addtoclosure(closure281, var_ArrowToken);
  addtoclosure(closure281, var_BindToken);
  addtoclosure(closure281, var_ColonToken);
  addtoclosure(closure281, var_indentLevel);
  addtoclosure(closure281, var_linePosition);
  addtoclosure(closure281, var_startPosition);
  struct UserObject *uo281 = (struct UserObject*)obj279;
  uo281->data[1] = (Object)closure281;
  addmethod2(obj279, "modechange", &meth_lexer_modechange281);
  addmethod2(obj279, "isidentifierchar", &meth_lexer_isidentifierchar572);
  addmethod2(obj279, "isoperatorchar", &meth_lexer_isoperatorchar590);
  addmethod2(obj279, "lexinput", &meth_lexer_lexinput642);
  block_savedest(obj279);
  Object **closure645 = createclosure(3);
  addtoclosure(closure645, var_linePosition);
  addtoclosure(closure645, var_lineNumber);
  addtoclosure(closure645, var_startPosition);
  struct UserObject *uo645 = (struct UserObject*)obj279;
  uo645->data[5] = (Object)closure645;
  addmethod2(obj279, "lexfile", &meth_lexer_lexfile645);
  set_type(obj279, 45);
// compilenode returning obj279
  return obj279;
}
Object meth_lexer_Lexer1323(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object params[1];
  Object *var_LexerClass = closure[0];
// compilenode returning *var_LexerClass
  return *var_LexerClass;
}
Object module_lexer_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<lexer>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_LexerClass = alloc_var();
  *var_LexerClass = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of sys
  if (module_sys == NULL)
    module_sys = module_sys_init();
  Object *var_sys = alloc_var();
  *var_sys = module_sys;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 7
  setline(7);
// Import of unicode
  if (module_unicode == NULL)
    module_unicode = dlmodule("unicode");
  Object *var_unicode = alloc_var();
  *var_unicode = module_unicode;
// compilenode returning undefined
// Begin line 18
  setline(18);
  addmethod2(self, "hexdecchar", &meth_lexer_hexdecchar4);
// compilenode returning 
// Begin line 626
  setline(626);
  Object obj38 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj38, self, 0);
  addmethod2(obj38, "outer", &reader_lexer_outer_39);
  adddatum2(obj38, self, 0);
  addmethod2(obj38, "new", &meth_lexer_new40);
  set_type(obj38, 45);
// compilenode returning obj38
  *var_LexerClass = obj38;
  if (obj38 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 633
  setline(633);
  block_savedest(self);
  Object **closure1323 = createclosure(1);
  addtoclosure(closure1323, var_LexerClass);
  struct UserObject *uo1323 = (struct UserObject*)self;
  uo1323->data[2] = (Object)closure1323;
  addmethod2(self, "Lexer", &meth_lexer_Lexer1323);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_lexer_init();
  gracelib_stats();
  return 0;
}
