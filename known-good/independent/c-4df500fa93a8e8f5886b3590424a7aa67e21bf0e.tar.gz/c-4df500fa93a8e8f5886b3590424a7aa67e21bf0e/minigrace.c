#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_minigrace_outer_31(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_minigrace_outer_54(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_minigrace_outer_101(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_sys_init();
Object module_sys;
Object module_unicode_init();
Object module_unicode;
Object module_util_init();
Object module_util;
Object module_lexer_init();
Object module_lexer;
Object module_ast_init();
Object module_ast;
Object module_parser_init();
Object module_parser;
Object module_typechecker_init();
Object module_typechecker;
Object module_genllvm29_init();
Object module_genllvm29;
Object module_genc_init();
Object module_genc;
Object module_genjs_init();
Object module_genjs;
Object module_buildinfo_init();
Object module_buildinfo;
Object module_subtype_init();
Object module_subtype;
static Object strlit15;
static Object strlit16;
static Object strlit17;
static Object strlit18;
static Object strlit19;
static Object strlit20;
static Object strlit23;
static Object strlit26;
static Object strlit33;
static Object strlit36;
static Object strlit48;
static Object strlit57;
static Object strlit69;
static Object strlit73;
static Object strlit79;
static Object strlit85;
static Object strlit95;
static Object strlit113;
static Object strlit121;
static Object strlit132;
static Object strlit142;
static Object strlit146;
static Object strlit157;
static Object strlit161;
Object meth_minigrace_apply32(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 22
  setline(22);
  if (strlit33 == NULL) {
    strlit33 = alloc_String("  ");
  }
// compilenode returning strlit33
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult35 = callmethod(strlit33, "++", 1, params);
// compilenode returning opresult35
  if (strlit36 == NULL) {
    strlit36 = alloc_String("");
  }
// compilenode returning strlit36
  params[0] = strlit36;
  Object opresult38 = callmethod(opresult35, "++", 1, params);
// compilenode returning opresult38
  params[0] = opresult38;
  Object call39 = gracelib_print(NULL, 1,  params);
// compilenode returning call39
  return call39;
}
Object meth_minigrace_apply55(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 31
  setline(31);
// Begin line 65
  setline(65);
// Begin line 31
  setline(31);
// compilenode returning *var_v
  Object call56 = callmethod(*var_v, "kind",
    0, params);
// compilenode returning call56
// compilenode returning call56
  if (strlit57 == NULL) {
    strlit57 = alloc_String(": ");
  }
// compilenode returning strlit57
  params[0] = strlit57;
  Object opresult59 = callmethod(call56, "++", 1, params);
// compilenode returning opresult59
// Begin line 65
  setline(65);
// Begin line 31
  setline(31);
// compilenode returning *var_v
  Object call60 = callmethod(*var_v, "value",
    0, params);
// compilenode returning call60
// compilenode returning call60
  params[0] = call60;
  Object opresult62 = callmethod(opresult59, "++", 1, params);
// compilenode returning opresult62
  params[0] = opresult62;
  Object call63 = gracelib_print(NULL, 1,  params);
// compilenode returning call63
// Begin line 33
  setline(33);
// Begin line 35
  setline(35);
// Begin line 65
  setline(65);
// Begin line 32
  setline(32);
// compilenode returning module_util
  Object call65 = callmethod(module_util, "verbosity",
    0, params);
// compilenode returning call65
// compilenode returning call65
  Object num66 = alloc_Float64(30.0);
// compilenode returning num66
  params[0] = num66;
  Object opresult68 = callmethod(call65, ">", 1, params);
// compilenode returning opresult68
  Object if64;
  if (istrue(opresult68)) {
// Begin line 33
  setline(33);
  if (strlit69 == NULL) {
    strlit69 = alloc_String("  [line: ");
  }
// compilenode returning strlit69
// Begin line 65
  setline(65);
// Begin line 33
  setline(33);
// compilenode returning *var_v
  Object call70 = callmethod(*var_v, "line",
    0, params);
// compilenode returning call70
// compilenode returning call70
  params[0] = call70;
  Object opresult72 = callmethod(strlit69, "++", 1, params);
// compilenode returning opresult72
  if (strlit73 == NULL) {
    strlit73 = alloc_String(" position: ");
  }
// compilenode returning strlit73
  params[0] = strlit73;
  Object opresult75 = callmethod(opresult72, "++", 1, params);
// compilenode returning opresult75
// Begin line 65
  setline(65);
// Begin line 33
  setline(33);
// compilenode returning *var_v
  Object call76 = callmethod(*var_v, "linePos",
    0, params);
// compilenode returning call76
// compilenode returning call76
  params[0] = call76;
  Object opresult78 = callmethod(opresult75, "++", 1, params);
// compilenode returning opresult78
  if (strlit79 == NULL) {
    strlit79 = alloc_String(" indent: ");
  }
// compilenode returning strlit79
  params[0] = strlit79;
  Object opresult81 = callmethod(opresult78, "++", 1, params);
// compilenode returning opresult81
// Begin line 65
  setline(65);
// Begin line 33
  setline(33);
// compilenode returning *var_v
  Object call82 = callmethod(*var_v, "indent",
    0, params);
// compilenode returning call82
// compilenode returning call82
  params[0] = call82;
  Object opresult84 = callmethod(opresult81, "++", 1, params);
// compilenode returning opresult84
  if (strlit85 == NULL) {
    strlit85 = alloc_String("]");
  }
// compilenode returning strlit85
  params[0] = strlit85;
  Object opresult87 = callmethod(opresult84, "++", 1, params);
// compilenode returning opresult87
  params[0] = opresult87;
  Object call88 = gracelib_print(NULL, 1,  params);
// compilenode returning call88
    if64 = call88;
  } else {
  }
// compilenode returning if64
  return if64;
}
Object meth_minigrace_apply102(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_v = alloc_var();
  *var_v = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 43
  setline(43);
  Object num103 = alloc_Float64(0.0);
// compilenode returning num103
// compilenode returning *var_v
  params[0] = num103;
  Object call104 = callmethod(*var_v, "pretty",
    1, params);
// compilenode returning call104
  params[0] = call104;
  Object call105 = gracelib_print(NULL, 1,  params);
// compilenode returning call105
  return call105;
}
Object module_minigrace_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<minigrace>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[6];
  Object *var_targets = alloc_var();
  *var_targets = undefined;
  Object *var_tokens = alloc_var();
  *var_tokens = undefined;
  Object *var_values = alloc_var();
  *var_values = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of sys
  if (module_sys == NULL)
    module_sys = module_sys_init();
  Object *var_sys = alloc_var();
  *var_sys = module_sys;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of unicode
  if (module_unicode == NULL)
    module_unicode = dlmodule("unicode");
  Object *var_unicode = alloc_var();
  *var_unicode = module_unicode;
// compilenode returning undefined
// Begin line 5
  setline(5);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Import of lexer
  if (module_lexer == NULL)
    module_lexer = module_lexer_init();
  Object *var_lexer = alloc_var();
  *var_lexer = module_lexer;
// compilenode returning undefined
// Begin line 7
  setline(7);
// Import of ast
  if (module_ast == NULL)
    module_ast = module_ast_init();
  Object *var_ast = alloc_var();
  *var_ast = module_ast;
// compilenode returning undefined
// Begin line 8
  setline(8);
// Import of parser
  if (module_parser == NULL)
    module_parser = module_parser_init();
  Object *var_parser = alloc_var();
  *var_parser = module_parser;
// compilenode returning undefined
// Begin line 9
  setline(9);
// Import of typechecker
  if (module_typechecker == NULL)
    module_typechecker = module_typechecker_init();
  Object *var_typechecker = alloc_var();
  *var_typechecker = module_typechecker;
// compilenode returning undefined
// Begin line 10
  setline(10);
// Import of genllvm29
  if (module_genllvm29 == NULL)
    module_genllvm29 = module_genllvm29_init();
  Object *var_genllvm29 = alloc_var();
  *var_genllvm29 = module_genllvm29;
// compilenode returning undefined
// Begin line 11
  setline(11);
// Import of genc
  if (module_genc == NULL)
    module_genc = module_genc_init();
  Object *var_genc = alloc_var();
  *var_genc = module_genc;
// compilenode returning undefined
// Begin line 12
  setline(12);
// Import of genjs
  if (module_genjs == NULL)
    module_genjs = module_genjs_init();
  Object *var_genjs = alloc_var();
  *var_genjs = module_genjs;
// compilenode returning undefined
// Begin line 13
  setline(13);
// Import of buildinfo
  if (module_buildinfo == NULL)
    module_buildinfo = module_buildinfo_init();
  Object *var_buildinfo = alloc_var();
  *var_buildinfo = module_buildinfo;
// compilenode returning undefined
// Begin line 15
  setline(15);
// Import of subtype
  if (module_subtype == NULL)
    module_subtype = module_subtype_init();
  Object *var_subtype = alloc_var();
  *var_subtype = module_subtype;
// compilenode returning undefined
// Begin line 65
  setline(65);
// Begin line 15
  setline(15);
// compilenode returning module_util
  Object call13 = callmethod(module_util, "parseargs",
    0, params);
// compilenode returning call13
// compilenode returning call13
// Begin line 17
  setline(17);
  Object array14 = alloc_List();
  if (strlit15 == NULL) {
    strlit15 = alloc_String("lex");
  }
// compilenode returning strlit15
  params[0] = strlit15;
  callmethod(array14, "push", 1, params);
  if (strlit16 == NULL) {
    strlit16 = alloc_String("parse");
  }
// compilenode returning strlit16
  params[0] = strlit16;
  callmethod(array14, "push", 1, params);
  if (strlit17 == NULL) {
    strlit17 = alloc_String("subtypematrix");
  }
// compilenode returning strlit17
  params[0] = strlit17;
  callmethod(array14, "push", 1, params);
  if (strlit18 == NULL) {
    strlit18 = alloc_String("llvm29");
  }
// compilenode returning strlit18
  params[0] = strlit18;
  callmethod(array14, "push", 1, params);
  if (strlit19 == NULL) {
    strlit19 = alloc_String("c");
  }
// compilenode returning strlit19
  params[0] = strlit19;
  callmethod(array14, "push", 1, params);
  if (strlit20 == NULL) {
    strlit20 = alloc_String("js");
  }
// compilenode returning strlit20
  params[0] = strlit20;
  callmethod(array14, "push", 1, params);
// compilenode returning array14
  *var_targets = array14;
  if (array14 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 24
  setline(24);
// Begin line 27
  setline(27);
// Begin line 65
  setline(65);
// Begin line 19
  setline(19);
// compilenode returning module_util
  Object call22 = callmethod(module_util, "target",
    0, params);
// compilenode returning call22
// compilenode returning call22
  if (strlit23 == NULL) {
    strlit23 = alloc_String("help");
  }
// compilenode returning strlit23
  params[0] = strlit23;
  Object opresult25 = callmethod(call22, "==", 1, params);
// compilenode returning opresult25
  Object if21;
  if (istrue(opresult25)) {
// Begin line 20
  setline(20);
  if (strlit26 == NULL) {
    strlit26 = alloc_String("Valid targets:");
  }
// compilenode returning strlit26
  params[0] = strlit26;
  Object call27 = gracelib_print(NULL, 1,  params);
// compilenode returning call27
// Begin line 22
  setline(22);
// Begin line 21
  setline(21);
// compilenode returning *var_targets
// Begin line 22
  setline(22);
// Begin line 65
  setline(65);
  Object obj30 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj30, self, 0);
  addmethod2(obj30, "outer", &reader_minigrace_outer_31);
  adddatum2(obj30, self, 0);
  block_savedest(obj30);
  Object **closure32 = createclosure(1);
  Object *selfpp40 = alloc_var();
  *selfpp40 = self;
  addtoclosure(closure32, selfpp40);
  struct UserObject *uo32 = (struct UserObject*)obj30;
  uo32->data[1] = (Object)closure32;
  addmethod2(obj30, "apply", &meth_minigrace_apply32);
  set_type(obj30, 0);
// compilenode returning obj30
  setclassname(obj30, "Block<minigrace:29>");
// compilenode returning obj30
  params[0] = *var_targets;
  Object iter28 = callmethod(*var_targets, "iter", 1, params);
  while(1) {
    Object cond28 = callmethod(iter28, "havemore", 0, NULL);
    if (!istrue(cond28)) break;
    params[0] = callmethod(iter28, "next", 0, NULL);
    callmethod(obj30, "apply", 1, params);
  }
// compilenode returning *var_targets
// Begin line 24
  setline(24);
  Object num41 = alloc_Float64(0.0);
// compilenode returning num41
// compilenode returning module_sys
  params[0] = num41;
  Object call42 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call42
    if21 = call42;
  } else {
  }
// compilenode returning if21
// Begin line 28
  setline(28);
// Begin line 65
  setline(65);
// Begin line 28
  setline(28);
// Begin line 65
  setline(65);
// Begin line 28
  setline(28);
// Begin line 65
  setline(65);
// Begin line 27
  setline(27);
// compilenode returning module_lexer
  Object call43 = callmethod(module_lexer, "Lexer",
    0, params);
// compilenode returning call43
// compilenode returning call43
  Object call44 = callmethod(call43, "new",
    0, params);
// compilenode returning call44
// compilenode returning call44
  Object call45 = callmethod(call44, "lexinput",
    0, params);
// compilenode returning call45
// compilenode returning call45
  var_tokens = alloc_var();
  *var_tokens = call45;
  if (call45 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 36
  setline(36);
// Begin line 38
  setline(38);
// Begin line 65
  setline(65);
// Begin line 28
  setline(28);
// compilenode returning module_util
  Object call47 = callmethod(module_util, "target",
    0, params);
// compilenode returning call47
// compilenode returning call47
  if (strlit48 == NULL) {
    strlit48 = alloc_String("lex");
  }
// compilenode returning strlit48
  params[0] = strlit48;
  Object opresult50 = callmethod(call47, "==", 1, params);
// compilenode returning opresult50
  Object if46;
  if (istrue(opresult50)) {
// Begin line 33
  setline(33);
// Begin line 30
  setline(30);
// compilenode returning *var_tokens
// Begin line 33
  setline(33);
// Begin line 65
  setline(65);
  Object obj53 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj53, self, 0);
  addmethod2(obj53, "outer", &reader_minigrace_outer_54);
  adddatum2(obj53, self, 0);
  block_savedest(obj53);
  Object **closure55 = createclosure(1);
  Object *selfpp89 = alloc_var();
  *selfpp89 = self;
  addtoclosure(closure55, selfpp89);
  struct UserObject *uo55 = (struct UserObject*)obj53;
  uo55->data[1] = (Object)closure55;
  addmethod2(obj53, "apply", &meth_minigrace_apply55);
  set_type(obj53, 0);
// compilenode returning obj53
  setclassname(obj53, "Block<minigrace:52>");
// compilenode returning obj53
  params[0] = *var_tokens;
  Object iter51 = callmethod(*var_tokens, "iter", 1, params);
  while(1) {
    Object cond51 = callmethod(iter51, "havemore", 0, NULL);
    if (!istrue(cond51)) break;
    params[0] = callmethod(iter51, "next", 0, NULL);
    callmethod(obj53, "apply", 1, params);
  }
// compilenode returning *var_tokens
// Begin line 36
  setline(36);
  Object num90 = alloc_Float64(0.0);
// compilenode returning num90
// compilenode returning module_sys
  params[0] = num90;
  Object call91 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call91
    if46 = call91;
  } else {
  }
// compilenode returning if46
// Begin line 38
  setline(38);
// compilenode returning *var_tokens
// compilenode returning module_parser
  params[0] = *var_tokens;
  Object call92 = callmethod(module_parser, "parse",
    1, params);
// compilenode returning call92
  var_values = alloc_var();
  *var_values = call92;
  if (call92 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 45
  setline(45);
// Begin line 47
  setline(47);
// Begin line 65
  setline(65);
// Begin line 40
  setline(40);
// compilenode returning module_util
  Object call94 = callmethod(module_util, "target",
    0, params);
// compilenode returning call94
// compilenode returning call94
  if (strlit95 == NULL) {
    strlit95 = alloc_String("parse");
  }
// compilenode returning strlit95
  params[0] = strlit95;
  Object opresult97 = callmethod(call94, "==", 1, params);
// compilenode returning opresult97
  Object if93;
  if (istrue(opresult97)) {
// Begin line 43
  setline(43);
// Begin line 42
  setline(42);
// compilenode returning *var_values
// Begin line 43
  setline(43);
// Begin line 65
  setline(65);
  Object obj100 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj100, self, 0);
  addmethod2(obj100, "outer", &reader_minigrace_outer_101);
  adddatum2(obj100, self, 0);
  block_savedest(obj100);
  Object **closure102 = createclosure(1);
  Object *selfpp106 = alloc_var();
  *selfpp106 = self;
  addtoclosure(closure102, selfpp106);
  struct UserObject *uo102 = (struct UserObject*)obj100;
  uo102->data[1] = (Object)closure102;
  addmethod2(obj100, "apply", &meth_minigrace_apply102);
  set_type(obj100, 0);
// compilenode returning obj100
  setclassname(obj100, "Block<minigrace:99>");
// compilenode returning obj100
  params[0] = *var_values;
  Object iter98 = callmethod(*var_values, "iter", 1, params);
  while(1) {
    Object cond98 = callmethod(iter98, "havemore", 0, NULL);
    if (!istrue(cond98)) break;
    params[0] = callmethod(iter98, "next", 0, NULL);
    callmethod(obj100, "apply", 1, params);
  }
// compilenode returning *var_values
// Begin line 45
  setline(45);
  Object num107 = alloc_Float64(0.0);
// compilenode returning num107
// compilenode returning module_sys
  params[0] = num107;
  Object call108 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call108
    if93 = call108;
  } else {
  }
// compilenode returning if93
// Begin line 47
  setline(47);
// compilenode returning *var_values
// compilenode returning module_typechecker
  params[0] = *var_values;
  Object call109 = callmethod(module_typechecker, "typecheck",
    1, params);
// compilenode returning call109
  *var_values = call109;
  if (call109 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 50
  setline(50);
// Begin line 54
  setline(54);
// Begin line 65
  setline(65);
// Begin line 48
  setline(48);
// compilenode returning module_util
  Object call112 = callmethod(module_util, "target",
    0, params);
// compilenode returning call112
// compilenode returning call112
  if (strlit113 == NULL) {
    strlit113 = alloc_String("subtypematrix");
  }
// compilenode returning strlit113
  params[0] = strlit113;
  Object opresult115 = callmethod(call112, "==", 1, params);
// compilenode returning opresult115
  Object if111;
  if (istrue(opresult115)) {
// Begin line 49
  setline(49);
// Begin line 65
  setline(65);
// Begin line 49
  setline(49);
// compilenode returning module_subtype
  Object call116 = callmethod(module_subtype, "printMatrix",
    0, params);
// compilenode returning call116
// compilenode returning call116
// Begin line 50
  setline(50);
  Object num117 = alloc_Float64(0.0);
// compilenode returning num117
// compilenode returning module_sys
  params[0] = num117;
  Object call118 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call118
    if111 = call118;
  } else {
  }
// compilenode returning if111
// Begin line 65
  setline(65);
// Begin line 66
  setline(66);
// Begin line 65
  setline(65);
// Begin line 54
  setline(54);
// compilenode returning module_util
  Object call120 = callmethod(module_util, "target",
    0, params);
// compilenode returning call120
// compilenode returning call120
  if (strlit121 == NULL) {
    strlit121 = alloc_String("llvm29");
  }
// compilenode returning strlit121
  params[0] = strlit121;
  Object opresult123 = callmethod(call120, "==", 1, params);
// compilenode returning opresult123
  Object if119;
  if (istrue(opresult123)) {
// Begin line 56
  setline(56);
// Begin line 55
  setline(55);
// compilenode returning *var_values
// Begin line 65
  setline(65);
// Begin line 55
  setline(55);
// compilenode returning module_util
  Object call124 = callmethod(module_util, "outfile",
    0, params);
// compilenode returning call124
// compilenode returning call124
// Begin line 65
  setline(65);
// Begin line 55
  setline(55);
// compilenode returning module_util
  Object call125 = callmethod(module_util, "modname",
    0, params);
// compilenode returning call125
// compilenode returning call125
// Begin line 65
  setline(65);
// Begin line 55
  setline(55);
// compilenode returning module_util
  Object call126 = callmethod(module_util, "runmode",
    0, params);
// compilenode returning call126
// compilenode returning call126
// Begin line 56
  setline(56);
// Begin line 65
  setline(65);
// Begin line 56
  setline(56);
// compilenode returning module_util
  Object call127 = callmethod(module_util, "buildtype",
    0, params);
// compilenode returning call127
// compilenode returning call127
// Begin line 65
  setline(65);
// Begin line 56
  setline(56);
// compilenode returning module_util
  Object call128 = callmethod(module_util, "gracelibPath",
    0, params);
// compilenode returning call128
// compilenode returning call128
// Begin line 55
  setline(55);
// compilenode returning module_genllvm29
  params[0] = *var_values;
  params[1] = call124;
  params[2] = call125;
  params[3] = call126;
  params[4] = call127;
  params[5] = call128;
  Object call129 = callmethod(module_genllvm29, "compile",
    6, params);
// compilenode returning call129
    if119 = call129;
  } else {
// Begin line 65
  setline(65);
// Begin line 60
  setline(60);
// Begin line 65
  setline(65);
// Begin line 57
  setline(57);
// compilenode returning module_util
  Object call131 = callmethod(module_util, "target",
    0, params);
// compilenode returning call131
// compilenode returning call131
  if (strlit132 == NULL) {
    strlit132 = alloc_String("c");
  }
// compilenode returning strlit132
  params[0] = strlit132;
  Object opresult134 = callmethod(call131, "==", 1, params);
// compilenode returning opresult134
  Object if130;
  if (istrue(opresult134)) {
// Begin line 59
  setline(59);
// Begin line 58
  setline(58);
// compilenode returning *var_values
// Begin line 65
  setline(65);
// Begin line 58
  setline(58);
// compilenode returning module_util
  Object call135 = callmethod(module_util, "outfile",
    0, params);
// compilenode returning call135
// compilenode returning call135
// Begin line 65
  setline(65);
// Begin line 58
  setline(58);
// compilenode returning module_util
  Object call136 = callmethod(module_util, "modname",
    0, params);
// compilenode returning call136
// compilenode returning call136
// Begin line 65
  setline(65);
// Begin line 58
  setline(58);
// compilenode returning module_util
  Object call137 = callmethod(module_util, "runmode",
    0, params);
// compilenode returning call137
// compilenode returning call137
// Begin line 59
  setline(59);
// Begin line 65
  setline(65);
// Begin line 59
  setline(59);
// compilenode returning module_util
  Object call138 = callmethod(module_util, "buildtype",
    0, params);
// compilenode returning call138
// compilenode returning call138
// Begin line 58
  setline(58);
// compilenode returning module_genc
  params[0] = *var_values;
  params[1] = call135;
  params[2] = call136;
  params[3] = call137;
  params[4] = call138;
  Object call139 = callmethod(module_genc, "compile",
    5, params);
// compilenode returning call139
    if130 = call139;
  } else {
// Begin line 65
  setline(65);
// Begin line 63
  setline(63);
// Begin line 65
  setline(65);
// Begin line 60
  setline(60);
// compilenode returning module_util
  Object call141 = callmethod(module_util, "target",
    0, params);
// compilenode returning call141
// compilenode returning call141
  if (strlit142 == NULL) {
    strlit142 = alloc_String("js");
  }
// compilenode returning strlit142
  params[0] = strlit142;
  Object opresult144 = callmethod(call141, "==", 1, params);
// compilenode returning opresult144
// Begin line 63
  setline(63);
// Begin line 65
  setline(65);
// Begin line 60
  setline(60);
// compilenode returning module_util
  Object call145 = callmethod(module_util, "target",
    0, params);
// compilenode returning call145
// compilenode returning call145
  if (strlit146 == NULL) {
    strlit146 = alloc_String("ecmascript");
  }
// compilenode returning strlit146
  params[0] = strlit146;
  Object opresult148 = callmethod(call145, "==", 1, params);
// compilenode returning opresult148
  params[0] = opresult148;
  Object opresult150 = callmethod(opresult144, "|", 1, params);
// compilenode returning opresult150
  Object if140;
  if (istrue(opresult150)) {
// Begin line 62
  setline(62);
// Begin line 61
  setline(61);
// compilenode returning *var_values
// Begin line 65
  setline(65);
// Begin line 61
  setline(61);
// compilenode returning module_util
  Object call151 = callmethod(module_util, "outfile",
    0, params);
// compilenode returning call151
// compilenode returning call151
// Begin line 65
  setline(65);
// Begin line 61
  setline(61);
// compilenode returning module_util
  Object call152 = callmethod(module_util, "modname",
    0, params);
// compilenode returning call152
// compilenode returning call152
// Begin line 65
  setline(65);
// Begin line 61
  setline(61);
// compilenode returning module_util
  Object call153 = callmethod(module_util, "runmode",
    0, params);
// compilenode returning call153
// compilenode returning call153
// Begin line 62
  setline(62);
// Begin line 65
  setline(65);
// Begin line 62
  setline(62);
// compilenode returning module_util
  Object call154 = callmethod(module_util, "buildtype",
    0, params);
// compilenode returning call154
// compilenode returning call154
// Begin line 65
  setline(65);
// Begin line 62
  setline(62);
// compilenode returning module_util
  Object call155 = callmethod(module_util, "gracelibPath",
    0, params);
// compilenode returning call155
// compilenode returning call155
// Begin line 61
  setline(61);
// compilenode returning module_genjs
  params[0] = *var_values;
  params[1] = call151;
  params[2] = call152;
  params[3] = call153;
  params[4] = call154;
  params[5] = call155;
  Object call156 = callmethod(module_genjs, "compile",
    6, params);
// compilenode returning call156
    if140 = call156;
  } else {
// Begin line 64
  setline(64);
  if (strlit157 == NULL) {
    strlit157 = alloc_String("minigrace: no such target '");
  }
// compilenode returning strlit157
// Begin line 65
  setline(65);
// Begin line 64
  setline(64);
// compilenode returning module_util
  Object call158 = callmethod(module_util, "target",
    0, params);
// compilenode returning call158
// compilenode returning call158
  params[0] = call158;
  Object opresult160 = callmethod(strlit157, "++", 1, params);
// compilenode returning opresult160
  if (strlit161 == NULL) {
    strlit161 = alloc_String("'");
  }
// compilenode returning strlit161
  params[0] = strlit161;
  Object opresult163 = callmethod(opresult160, "++", 1, params);
// compilenode returning opresult163
// Begin line 65
  setline(65);
// Begin line 64
  setline(64);
// compilenode returning module_io
  Object call164 = callmethod(module_io, "error",
    0, params);
// compilenode returning call164
// compilenode returning call164
  params[0] = opresult163;
  Object call165 = callmethod(call164, "write",
    1, params);
// compilenode returning call165
// Begin line 65
  setline(65);
  Object num166 = alloc_Float64(1.0);
// compilenode returning num166
// compilenode returning module_sys
  params[0] = num166;
  Object call167 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call167
    if140 = call167;
  }
// compilenode returning if140
    if130 = if140;
  }
// compilenode returning if130
    if119 = if130;
  }
// compilenode returning if119
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_minigrace_init();
  gracelib_stats();
  return 0;
}
