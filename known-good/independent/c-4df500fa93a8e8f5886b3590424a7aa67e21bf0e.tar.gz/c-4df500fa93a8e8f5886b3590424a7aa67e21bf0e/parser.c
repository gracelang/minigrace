#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_parser_outer_31(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_kind_33(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object writer_parser_kind_33(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[1] = args[0];
  return nothing;
}
Object reader_parser_line_37(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_parser_line_37(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_parser_linePos_39(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_parser_linePos_39(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_parser_indent_41(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[4];
}
Object writer_parser_indent_41(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[4] = args[0];
  return nothing;
}
Object reader_parser_value_43(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[5];
}
Object writer_parser_value_43(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[5] = args[0];
  return nothing;
}
Object reader_parser_outer_248(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_277(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_313(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_339(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_362(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_368(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_448(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_497(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_587(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1261(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1267(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1278(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1391(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1410(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1491(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1611(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1617(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1628(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1691(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1706(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_kind_1708(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object writer_parser_kind_1708(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[1] = args[0];
  return nothing;
}
Object reader_parser_register_1710(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_parser_register_1710(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_parser_outer_1748(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1808(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1825(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_kind_1827(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object writer_parser_kind_1827(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[1] = args[0];
  return nothing;
}
Object reader_parser_register_1829(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_parser_register_1829(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_parser_outer_1905(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1928(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_1947(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2167(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_kind_2169(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object writer_parser_kind_2169(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[1] = args[0];
  return nothing;
}
Object reader_parser_register_2171(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_parser_register_2171(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_parser_outer_2244(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2301(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2330(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2400(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2579(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2617(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_parser_outer_2649(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_ast_init();
Object module_ast;
Object module_util_init();
Object module_util;
Object module_subtype_init();
Object module_subtype;
static Object strlit32;
static Object strlit42;
static Object strlit107;
static Object strlit110;
static Object strlit116;
static Object strlit122;
static Object strlit137;
static Object strlit140;
static Object strlit146;
static Object strlit152;
static Object strlit163;
static Object strlit194;
static Object strlit197;
static Object strlit213;
static Object strlit220;
static Object strlit223;
static Object strlit244;
static Object strlit250;
static Object strlit253;
static Object strlit259;
static Object strlit264;
static Object strlit267;
static Object strlit285;
static Object strlit288;
static Object strlit309;
static Object strlit315;
static Object strlit318;
static Object strlit324;
static Object strlit329;
static Object strlit348;
static Object strlit371;
static Object strlit373;
static Object strlit377;
static Object strlit384;
static Object strlit392;
static Object strlit399;
static Object strlit407;
static Object strlit410;
static Object strlit414;
static Object strlit427;
static Object strlit443;
static Object strlit472;
static Object strlit484;
static Object strlit499;
static Object strlit510;
static Object strlit522;
static Object strlit528;
static Object strlit532;
static Object strlit540;
static Object strlit551;
static Object strlit558;
static Object strlit562;
static Object strlit578;
static Object strlit589;
static Object strlit600;
static Object strlit612;
static Object strlit618;
static Object strlit622;
static Object strlit631;
static Object strlit638;
static Object strlit642;
static Object strlit652;
static Object strlit655;
static Object strlit669;
static Object strlit672;
static Object strlit679;
static Object strlit694;
static Object strlit703;
static Object strlit706;
static Object strlit717;
static Object strlit720;
static Object strlit726;
static Object strlit732;
static Object strlit735;
static Object strlit750;
static Object strlit765;
static Object strlit768;
static Object strlit775;
static Object strlit790;
static Object strlit804;
static Object strlit808;
static Object strlit811;
static Object strlit825;
static Object strlit828;
static Object strlit832;
static Object strlit840;
static Object strlit850;
static Object strlit854;
static Object strlit857;
static Object strlit867;
static Object strlit874;
static Object strlit879;
static Object strlit882;
static Object strlit888;
static Object strlit903;
static Object strlit916;
static Object strlit920;
static Object strlit924;
static Object strlit930;
static Object strlit936;
static Object strlit943;
static Object strlit948;
static Object strlit952;
static Object strlit954;
static Object strlit957;
static Object strlit966;
static Object strlit975;
static Object strlit981;
static Object strlit988;
static Object strlit991;
static Object strlit993;
static Object strlit1000;
static Object strlit1004;
static Object strlit1008;
static Object strlit1012;
static Object strlit1016;
static Object strlit1020;
static Object strlit1023;
static Object strlit1030;
static Object strlit1034;
static Object strlit1038;
static Object strlit1043;
static Object strlit1047;
static Object strlit1057;
static Object strlit1063;
static Object strlit1070;
static Object strlit1075;
static Object strlit1091;
static Object strlit1099;
static Object strlit1101;
static Object strlit1113;
static Object strlit1116;
static Object strlit1121;
static Object strlit1126;
static Object strlit1134;
static Object strlit1144;
static Object strlit1147;
static Object strlit1154;
static Object strlit1157;
static Object strlit1181;
static Object strlit1185;
static Object strlit1187;
static Object strlit1190;
static Object strlit1222;
static Object strlit1226;
static Object strlit1231;
static Object strlit1238;
static Object strlit1242;
static Object strlit1251;
static Object strlit1270;
static Object strlit1288;
static Object strlit1293;
static Object strlit1295;
static Object strlit1299;
static Object strlit1303;
static Object strlit1306;
static Object strlit1310;
static Object strlit1330;
static Object strlit1336;
static Object strlit1342;
static Object strlit1350;
static Object strlit1358;
static Object strlit1366;
static Object strlit1383;
static Object strlit1385;
static Object strlit1393;
static Object strlit1399;
static Object strlit1413;
static Object strlit1428;
static Object strlit1431;
static Object strlit1436;
static Object strlit1441;
static Object strlit1446;
static Object strlit1449;
static Object strlit1451;
static Object strlit1455;
static Object strlit1459;
static Object strlit1462;
static Object strlit1466;
static Object strlit1483;
static Object strlit1501;
static Object strlit1504;
static Object strlit1515;
static Object strlit1518;
static Object strlit1526;
static Object strlit1531;
static Object strlit1538;
static Object strlit1541;
static Object strlit1551;
static Object strlit1553;
static Object strlit1555;
static Object strlit1561;
static Object strlit1564;
static Object strlit1572;
static Object strlit1577;
static Object strlit1584;
static Object strlit1591;
static Object strlit1594;
static Object strlit1599;
static Object strlit1605;
static Object strlit1620;
static Object strlit1638;
static Object strlit1645;
static Object strlit1648;
static Object strlit1656;
static Object strlit1659;
static Object strlit1665;
static Object strlit1670;
static Object strlit1673;
static Object strlit1676;
static Object strlit1682;
static Object strlit1686;
static Object strlit1703;
static Object strlit1707;
static Object strlit1709;
static Object strlit1715;
static Object strlit1725;
static Object strlit1726;
static Object strlit1737;
static Object strlit1757;
static Object strlit1760;
static Object strlit1766;
static Object strlit1772;
static Object strlit1775;
static Object strlit1781;
static Object strlit1787;
static Object strlit1790;
static Object strlit1793;
static Object strlit1799;
static Object strlit1803;
static Object strlit1822;
static Object strlit1826;
static Object strlit1828;
static Object strlit1834;
static Object strlit1839;
static Object strlit1848;
static Object strlit1856;
static Object strlit1865;
static Object strlit1868;
static Object strlit1872;
static Object strlit1882;
static Object strlit1883;
static Object strlit1894;
static Object strlit1912;
static Object strlit1921;
static Object strlit1924;
static Object strlit1930;
static Object strlit1936;
static Object strlit1950;
static Object strlit1964;
static Object strlit1967;
static Object strlit1971;
static Object strlit1973;
static Object strlit1976;
static Object strlit1984;
static Object strlit1987;
static Object strlit1992;
static Object strlit1998;
static Object strlit2008;
static Object strlit2012;
static Object strlit2015;
static Object strlit2022;
static Object strlit2025;
static Object strlit2031;
static Object strlit2032;
static Object strlit2037;
static Object strlit2041;
static Object strlit2046;
static Object strlit2049;
static Object strlit2066;
static Object strlit2070;
static Object strlit2072;
static Object strlit2075;
static Object strlit2083;
static Object strlit2094;
static Object strlit2098;
static Object strlit2103;
static Object strlit2108;
static Object strlit2112;
static Object strlit2116;
static Object strlit2119;
static Object strlit2121;
static Object strlit2125;
static Object strlit2137;
static Object strlit2147;
static Object strlit2168;
static Object strlit2170;
static Object strlit2177;
static Object strlit2185;
static Object strlit2188;
static Object strlit2192;
static Object strlit2198;
static Object strlit2203;
static Object strlit2216;
static Object strlit2219;
static Object strlit2225;
static Object strlit2233;
static Object strlit2236;
static Object strlit2257;
static Object strlit2259;
static Object strlit2262;
static Object strlit2266;
static Object strlit2272;
static Object strlit2276;
static Object strlit2281;
static Object strlit2289;
static Object strlit2292;
static Object strlit2296;
static Object strlit2303;
static Object strlit2306;
static Object strlit2314;
static Object strlit2321;
static Object strlit2333;
static Object strlit2344;
static Object strlit2347;
static Object strlit2356;
static Object strlit2359;
static Object strlit2365;
static Object strlit2373;
static Object strlit2380;
static Object strlit2384;
static Object strlit2387;
static Object strlit2391;
static Object strlit2395;
static Object strlit2421;
static Object strlit2425;
static Object strlit2431;
static Object strlit2447;
static Object strlit2448;
static Object strlit2454;
static Object strlit2460;
static Object strlit2463;
static Object strlit2469;
static Object strlit2482;
static Object strlit2486;
static Object strlit2492;
static Object strlit2498;
static Object strlit2501;
static Object strlit2505;
static Object strlit2511;
static Object strlit2517;
static Object strlit2523;
static Object strlit2529;
static Object strlit2536;
static Object strlit2545;
static Object strlit2551;
static Object strlit2554;
static Object strlit2558;
static Object strlit2569;
static Object strlit2584;
static Object strlit2609;
static Object strlit2630;
static Object strlit2636;
static Object strlit2641;
static Object strlit2664;
static Object strlit2671;
static Object strlit2675;
static Object strlit2681;
static Object strlit2686;
Object meth_parser_next13(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_lastToken = closure[1];
  Object *var_tokens = closure[2];
  Object *var_linenum = closure[3];
  Object *var_lastline = closure[4];
  Object *var_lastIndent = closure[5];
// Begin line 25
  setline(25);
// Begin line 24
  setline(24);
// compilenode returning *var_sym
  *var_lastToken = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 38
  setline(38);
// Begin line 40
  setline(40);
// Begin line 1577
  setline(1577);
// Begin line 25
  setline(25);
// compilenode returning *var_tokens
  Object call16 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call16
// compilenode returning call16
  Object num17 = alloc_Float64(0.0);
// compilenode returning num17
  params[0] = num17;
  Object opresult19 = callmethod(call16, ">", 1, params);
// compilenode returning opresult19
  Object if15;
  if (istrue(opresult19)) {
// Begin line 27
  setline(27);
// Begin line 26
  setline(26);
// compilenode returning *var_linenum
  *var_lastline = *var_linenum;
  if (*var_linenum == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 28
  setline(28);
// Begin line 1577
  setline(1577);
// Begin line 27
  setline(27);
// compilenode returning *var_sym
  Object call21 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call21
// compilenode returning call21
  *var_lastIndent = call21;
  if (call21 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 29
  setline(29);
// Begin line 1577
  setline(1577);
// Begin line 28
  setline(28);
// compilenode returning *var_tokens
  Object call23 = callmethod(*var_tokens, "pop",
    0, params);
// compilenode returning call23
// compilenode returning call23
  *var_sym = call23;
  if (call23 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 30
  setline(30);
// Begin line 1577
  setline(1577);
// Begin line 29
  setline(29);
// compilenode returning *var_sym
  Object call25 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call25
// compilenode returning call25
  *var_linenum = call25;
  if (call25 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 30
  setline(30);
// Begin line 1577
  setline(1577);
// Begin line 30
  setline(30);
// compilenode returning *var_sym
  Object call27 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call27
// compilenode returning call27
// Begin line 1577
  setline(1577);
// Begin line 30
  setline(30);
// compilenode returning *var_sym
  Object call28 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call28
// compilenode returning call28
// compilenode returning module_util
  params[0] = call27;
  params[1] = call28;
  Object call29 = callmethod(module_util, "setPosition",
    2, params);
// compilenode returning call29
    if15 = call29;
  } else {
// Begin line 38
  setline(38);
  Object obj30 = alloc_obj2(10,6);
// OBJECT OUTER DEC outer
  adddatum2(obj30, self, 0);
  addmethod2(obj30, "outer", &reader_parser_outer_31);
  adddatum2(obj30, self, 0);
// Begin line 33
  setline(33);
  if (strlit32 == NULL) {
    strlit32 = alloc_String("eof");
  }
// compilenode returning strlit32
// OBJECT VAR DEC kind
  adddatum2(obj30, strlit32, 1);
  addmethod2(obj30, "kind", &reader_parser_kind_33);
  addmethod2(obj30, "kind:=", &writer_parser_kind_33);
// Begin line 35
  setline(35);
// Begin line 34
  setline(34);
// compilenode returning *var_linenum
  Object num34 = alloc_Float64(1.0);
// compilenode returning num34
  params[0] = num34;
  Object sum36 = callmethod(*var_linenum, "+", 1, params);
// compilenode returning sum36
// OBJECT VAR DEC line
  adddatum2(obj30, sum36, 2);
  addmethod2(obj30, "line", &reader_parser_line_37);
  addmethod2(obj30, "line:=", &writer_parser_line_37);
// Begin line 35
  setline(35);
  Object num38 = alloc_Float64(0.0);
// compilenode returning num38
// OBJECT VAR DEC linePos
  adddatum2(obj30, num38, 3);
  addmethod2(obj30, "linePos", &reader_parser_linePos_39);
  addmethod2(obj30, "linePos:=", &writer_parser_linePos_39);
// Begin line 36
  setline(36);
  Object num40 = alloc_Float64(0.0);
// compilenode returning num40
// OBJECT VAR DEC indent
  adddatum2(obj30, num40, 4);
  addmethod2(obj30, "indent", &reader_parser_indent_41);
  addmethod2(obj30, "indent:=", &writer_parser_indent_41);
// Begin line 37
  setline(37);
  if (strlit42 == NULL) {
    strlit42 = alloc_String("");
  }
// compilenode returning strlit42
// OBJECT VAR DEC value
  adddatum2(obj30, strlit42, 5);
  addmethod2(obj30, "value", &reader_parser_value_43);
  addmethod2(obj30, "value:=", &writer_parser_value_43);
  set_type(obj30, 4);
// compilenode returning obj30
  *var_sym = obj30;
  if (obj30 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if15 = nothing;
  }
// compilenode returning if15
  return if15;
}
Object meth_parser_accept45(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_sym = closure[0];
// Begin line 1577
  setline(1577);
// Begin line 45
  setline(45);
// compilenode returning *var_sym
  Object call46 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call46
// compilenode returning call46
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult48 = callmethod(call46, "==", 1, params);
// compilenode returning opresult48
  return opresult48;
}
Object meth_parser_acceptSameLine49(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_lastline = closure[1];
  Object *var_lastIndent = closure[2];
// Begin line 1577
  setline(1577);
// Begin line 52
  setline(52);
// compilenode returning *var_sym
  Object call50 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call50
// compilenode returning call50
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult52 = callmethod(call50, "==", 1, params);
// compilenode returning opresult52
// Begin line 54
  setline(54);
// Begin line 52
  setline(52);
// compilenode returning *var_lastline
// Begin line 54
  setline(54);
// Begin line 1577
  setline(1577);
// Begin line 52
  setline(52);
// compilenode returning *var_sym
  Object call53 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call53
// compilenode returning call53
  params[0] = call53;
  Object opresult55 = callmethod(*var_lastline, "==", 1, params);
// compilenode returning opresult55
// Begin line 54
  setline(54);
// Begin line 1577
  setline(1577);
// Begin line 53
  setline(53);
// compilenode returning *var_sym
  Object call56 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call56
// compilenode returning call56
// compilenode returning *var_lastIndent
  params[0] = *var_lastIndent;
  Object opresult58 = callmethod(call56, ">", 1, params);
// compilenode returning opresult58
  params[0] = opresult58;
  Object opresult60 = callmethod(opresult55, "|", 1, params);
// compilenode returning opresult60
  params[0] = opresult60;
  Object opresult62 = callmethod(opresult52, "&", 1, params);
// compilenode returning opresult62
  return opresult62;
}
Object meth_parser_accept_40_1_41_onLineOf63(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object *var_other = alloc_var();
  *var_other = args[1];
  Object params[1];
  Object *var_sym = closure[0];
// Begin line 1577
  setline(1577);
// Begin line 59
  setline(59);
// compilenode returning *var_sym
  Object call64 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call64
// compilenode returning call64
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult66 = callmethod(call64, "==", 1, params);
// compilenode returning opresult66
// Begin line 61
  setline(61);
// Begin line 1577
  setline(1577);
// Begin line 59
  setline(59);
// compilenode returning *var_other
  Object call67 = callmethod(*var_other, "line",
    0, params);
// compilenode returning call67
// compilenode returning call67
// Begin line 61
  setline(61);
// Begin line 1577
  setline(1577);
// Begin line 59
  setline(59);
// compilenode returning *var_sym
  Object call68 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call68
// compilenode returning call68
  params[0] = call68;
  Object opresult70 = callmethod(call67, "==", 1, params);
// compilenode returning opresult70
// Begin line 61
  setline(61);
// Begin line 1577
  setline(1577);
// Begin line 60
  setline(60);
// compilenode returning *var_sym
  Object call71 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call71
// compilenode returning call71
// Begin line 61
  setline(61);
// Begin line 1577
  setline(1577);
// Begin line 60
  setline(60);
// compilenode returning *var_other
  Object call72 = callmethod(*var_other, "indent",
    0, params);
// compilenode returning call72
// compilenode returning call72
  params[0] = call72;
  Object opresult74 = callmethod(call71, ">", 1, params);
// compilenode returning opresult74
  params[0] = opresult74;
  Object opresult76 = callmethod(opresult70, "|", 1, params);
// compilenode returning opresult76
  params[0] = opresult76;
  Object opresult78 = callmethod(opresult66, "&", 1, params);
// compilenode returning opresult78
  return opresult78;
}
Object meth_parser_accept_40_1_41_onLineOfLastOr79(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object *var_other = alloc_var();
  *var_other = args[1];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_lastToken = closure[1];
// Begin line 1577
  setline(1577);
// Begin line 65
  setline(65);
// compilenode returning *var_sym
  Object call80 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call80
// compilenode returning call80
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult82 = callmethod(call80, "==", 1, params);
// compilenode returning opresult82
// Begin line 67
  setline(67);
// Begin line 1577
  setline(1577);
// Begin line 65
  setline(65);
// compilenode returning *var_other
  Object call83 = callmethod(*var_other, "line",
    0, params);
// compilenode returning call83
// compilenode returning call83
// Begin line 67
  setline(67);
// Begin line 1577
  setline(1577);
// Begin line 65
  setline(65);
// compilenode returning *var_sym
  Object call84 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call84
// compilenode returning call84
  params[0] = call84;
  Object opresult86 = callmethod(call83, "==", 1, params);
// compilenode returning opresult86
// Begin line 67
  setline(67);
// Begin line 1577
  setline(1577);
// Begin line 66
  setline(66);
// compilenode returning *var_sym
  Object call87 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call87
// compilenode returning call87
// Begin line 67
  setline(67);
// Begin line 1577
  setline(1577);
// Begin line 66
  setline(66);
// compilenode returning *var_other
  Object call88 = callmethod(*var_other, "indent",
    0, params);
// compilenode returning call88
// compilenode returning call88
  params[0] = call88;
  Object opresult90 = callmethod(call87, ">", 1, params);
// compilenode returning opresult90
  params[0] = opresult90;
  Object opresult92 = callmethod(opresult86, "|", 1, params);
// compilenode returning opresult92
// Begin line 67
  setline(67);
// Begin line 1577
  setline(1577);
// Begin line 66
  setline(66);
// compilenode returning *var_lastToken
  Object call93 = callmethod(*var_lastToken, "line",
    0, params);
// compilenode returning call93
// compilenode returning call93
// Begin line 67
  setline(67);
// Begin line 1577
  setline(1577);
// Begin line 66
  setline(66);
// compilenode returning *var_sym
  Object call94 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call94
// compilenode returning call94
  params[0] = call94;
  Object opresult96 = callmethod(call93, "==", 1, params);
// compilenode returning opresult96
  params[0] = opresult96;
  Object opresult98 = callmethod(opresult92, "|", 1, params);
// compilenode returning opresult98
  params[0] = opresult98;
  Object opresult100 = callmethod(opresult82, "&", 1, params);
// compilenode returning opresult100
  return opresult100;
}
Object meth_parser_expect101(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_sym = closure[0];
// Begin line 72
  setline(72);
// Begin line 73
  setline(73);
// Begin line 1577
  setline(1577);
// Begin line 70
  setline(70);
// compilenode returning *var_sym
  Object call103 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call103
// compilenode returning call103
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult105 = callmethod(call103, "==", 1, params);
// compilenode returning opresult105
  Object if102;
  if (istrue(opresult105)) {
// Begin line 72
  setline(72);
// Begin line 71
  setline(71);
  Object bool106 = alloc_Boolean(1);
// compilenode returning bool106
  return bool106;
// compilenode returning undefined
    if102 = undefined;
  } else {
  }
// compilenode returning if102
// Begin line 73
  setline(73);
  if (strlit107 == NULL) {
    strlit107 = alloc_String("expected ");
  }
// compilenode returning strlit107
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult109 = callmethod(strlit107, "++", 1, params);
// compilenode returning opresult109
  if (strlit110 == NULL) {
    strlit110 = alloc_String(", got ");
  }
// compilenode returning strlit110
  params[0] = strlit110;
  Object opresult112 = callmethod(opresult109, "++", 1, params);
// compilenode returning opresult112
// Begin line 1577
  setline(1577);
// Begin line 73
  setline(73);
// compilenode returning *var_sym
  Object call113 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call113
// compilenode returning call113
  params[0] = call113;
  Object opresult115 = callmethod(opresult112, "++", 1, params);
// compilenode returning opresult115
  if (strlit116 == NULL) {
    strlit116 = alloc_String(": ");
  }
// compilenode returning strlit116
  params[0] = strlit116;
  Object opresult118 = callmethod(opresult115, "++", 1, params);
// compilenode returning opresult118
// Begin line 1577
  setline(1577);
// Begin line 73
  setline(73);
// compilenode returning *var_sym
  Object call119 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call119
// compilenode returning call119
  params[0] = call119;
  Object opresult121 = callmethod(opresult118, "++", 1, params);
// compilenode returning opresult121
  if (strlit122 == NULL) {
    strlit122 = alloc_String("");
  }
// compilenode returning strlit122
  params[0] = strlit122;
  Object opresult124 = callmethod(opresult121, "++", 1, params);
// compilenode returning opresult124
// compilenode returning module_util
  params[0] = opresult124;
  Object call125 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call125
  return call125;
}
Object meth_parser_expect_40_1_41_or126(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object *var_s = alloc_var();
  *var_s = args[1];
  Object params[1];
  Object *var_sym = closure[0];
// Begin line 79
  setline(79);
// Begin line 80
  setline(80);
// Begin line 1577
  setline(1577);
// Begin line 77
  setline(77);
// compilenode returning *var_sym
  Object call128 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call128
// compilenode returning call128
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult130 = callmethod(call128, "==", 1, params);
// compilenode returning opresult130
  Object if127;
  if (istrue(opresult130)) {
// Begin line 79
  setline(79);
// Begin line 78
  setline(78);
  Object bool131 = alloc_Boolean(1);
// compilenode returning bool131
  return bool131;
// compilenode returning undefined
    if127 = undefined;
  } else {
  }
// compilenode returning if127
// Begin line 82
  setline(82);
// Begin line 83
  setline(83);
// Begin line 1577
  setline(1577);
// Begin line 80
  setline(80);
// compilenode returning *var_sym
  Object call133 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call133
// compilenode returning call133
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult135 = callmethod(call133, "==", 1, params);
// compilenode returning opresult135
  Object if132;
  if (istrue(opresult135)) {
// Begin line 82
  setline(82);
// Begin line 81
  setline(81);
  Object bool136 = alloc_Boolean(1);
// compilenode returning bool136
  return bool136;
// compilenode returning undefined
    if132 = undefined;
  } else {
  }
// compilenode returning if132
// Begin line 83
  setline(83);
  if (strlit137 == NULL) {
    strlit137 = alloc_String("expected ");
  }
// compilenode returning strlit137
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult139 = callmethod(strlit137, "++", 1, params);
// compilenode returning opresult139
  if (strlit140 == NULL) {
    strlit140 = alloc_String(", got ");
  }
// compilenode returning strlit140
  params[0] = strlit140;
  Object opresult142 = callmethod(opresult139, "++", 1, params);
// compilenode returning opresult142
// Begin line 1577
  setline(1577);
// Begin line 83
  setline(83);
// compilenode returning *var_sym
  Object call143 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call143
// compilenode returning call143
  params[0] = call143;
  Object opresult145 = callmethod(opresult142, "++", 1, params);
// compilenode returning opresult145
  if (strlit146 == NULL) {
    strlit146 = alloc_String(": ");
  }
// compilenode returning strlit146
  params[0] = strlit146;
  Object opresult148 = callmethod(opresult145, "++", 1, params);
// compilenode returning opresult148
// Begin line 1577
  setline(1577);
// Begin line 83
  setline(83);
// compilenode returning *var_sym
  Object call149 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call149
// compilenode returning call149
  params[0] = call149;
  Object opresult151 = callmethod(opresult148, "++", 1, params);
// compilenode returning opresult151
  if (strlit152 == NULL) {
    strlit152 = alloc_String("");
  }
// compilenode returning strlit152
  params[0] = strlit152;
  Object opresult154 = callmethod(opresult151, "++", 1, params);
// compilenode returning opresult154
// compilenode returning module_util
  params[0] = opresult154;
  Object call155 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call155
  return call155;
}
Object meth_parser_expectConsume156(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_ablock = alloc_var();
  *var_ablock = args[0];
  Object params[1];
  Object *var_tokens = closure[0];
  Object *var_sz = alloc_var();
  *var_sz = undefined;
// Begin line 88
  setline(88);
// Begin line 1577
  setline(1577);
// Begin line 87
  setline(87);
// compilenode returning *var_tokens
  Object call157 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call157
// compilenode returning call157
  var_sz = alloc_var();
  *var_sz = call157;
  if (call157 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 88
  setline(88);
// Begin line 1577
  setline(1577);
// Begin line 88
  setline(88);
// compilenode returning *var_ablock
  Object call158 = callmethod(*var_ablock, "apply",
    0, params);
// compilenode returning call158
// compilenode returning call158
// Begin line 90
  setline(90);
// Begin line 92
  setline(92);
// Begin line 1577
  setline(1577);
// Begin line 89
  setline(89);
// compilenode returning *var_tokens
  Object call160 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call160
// compilenode returning call160
// compilenode returning *var_sz
  params[0] = *var_sz;
  Object opresult162 = callmethod(call160, "==", 1, params);
// compilenode returning opresult162
  Object if159;
  if (istrue(opresult162)) {
// Begin line 90
  setline(90);
  if (strlit163 == NULL) {
    strlit163 = alloc_String("unable to consume token");
  }
// compilenode returning strlit163
// compilenode returning module_util
  params[0] = strlit163;
  Object call164 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call164
    if159 = call164;
  } else {
  }
// compilenode returning if159
  return if159;
}
Object meth_parser_ifConsume_40_1_41_then165(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_ablock = alloc_var();
  *var_ablock = args[0];
  Object *var_tblock = alloc_var();
  *var_tblock = args[1];
  Object params[1];
  Object *var_tokens = closure[0];
  Object *var_sz = alloc_var();
  *var_sz = undefined;
// Begin line 96
  setline(96);
// Begin line 1577
  setline(1577);
// Begin line 95
  setline(95);
// compilenode returning *var_tokens
  Object call166 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call166
// compilenode returning call166
  var_sz = alloc_var();
  *var_sz = call166;
  if (call166 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 96
  setline(96);
// Begin line 1577
  setline(1577);
// Begin line 96
  setline(96);
// compilenode returning *var_ablock
  Object call167 = callmethod(*var_ablock, "apply",
    0, params);
// compilenode returning call167
// compilenode returning call167
// Begin line 98
  setline(98);
// Begin line 100
  setline(100);
// Begin line 1577
  setline(1577);
// Begin line 97
  setline(97);
// compilenode returning *var_tokens
  Object call169 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call169
// compilenode returning call169
// compilenode returning *var_sz
  params[0] = *var_sz;
  Object opresult171 = callmethod(call169, "/=", 1, params);
// compilenode returning opresult171
  Object if168;
  if (istrue(opresult171)) {
// Begin line 98
  setline(98);
// Begin line 1577
  setline(1577);
// Begin line 98
  setline(98);
// compilenode returning *var_tblock
  Object call172 = callmethod(*var_tblock, "apply",
    0, params);
// compilenode returning call172
// compilenode returning call172
    if168 = call172;
  } else {
  }
// compilenode returning if168
  return if168;
}
Object meth_parser_pushnum173(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 104
  setline(104);
// Begin line 1577
  setline(1577);
// Begin line 104
  setline(104);
// compilenode returning *var_sym
  Object call174 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call174
// compilenode returning call174
// compilenode returning module_ast
  params[0] = call174;
  Object call175 = callmethod(module_ast, "astnum",
    1, params);
// compilenode returning call175
  var_o = alloc_var();
  *var_o = call175;
  if (call175 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 105
  setline(105);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call176 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call176
// Begin line 106
  setline(106);
// compilenode returning self
  Object call177 = callmethod(self, "next",
    0, params);
// compilenode returning call177
  return call177;
}
Object meth_parser_pushoctets178(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 111
  setline(111);
// Begin line 1577
  setline(1577);
// Begin line 111
  setline(111);
// compilenode returning *var_sym
  Object call179 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call179
// compilenode returning call179
// compilenode returning module_ast
  params[0] = call179;
  Object call180 = callmethod(module_ast, "astoctets",
    1, params);
// compilenode returning call180
  var_o = alloc_var();
  *var_o = call180;
  if (call180 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 112
  setline(112);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call181 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call181
// Begin line 113
  setline(113);
// compilenode returning self
  Object call182 = callmethod(self, "next",
    0, params);
// compilenode returning call182
  return call182;
}
Object meth_parser_pushstring183(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 118
  setline(118);
// Begin line 1577
  setline(1577);
// Begin line 118
  setline(118);
// compilenode returning *var_sym
  Object call184 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call184
// compilenode returning call184
// compilenode returning module_ast
  params[0] = call184;
  Object call185 = callmethod(module_ast, "aststring",
    1, params);
// compilenode returning call185
  var_o = alloc_var();
  *var_o = call185;
  if (call185 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 119
  setline(119);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call186 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call186
// Begin line 120
  setline(120);
// compilenode returning self
  Object call187 = callmethod(self, "next",
    0, params);
// compilenode returning call187
  return call187;
}
Object meth_parser_pushidentifier188(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_auto_count = closure[1];
  Object *var_values = closure[2];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 126
  setline(126);
// Begin line 1577
  setline(1577);
// Begin line 126
  setline(126);
// compilenode returning *var_sym
  Object call189 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call189
// compilenode returning call189
  Object bool190 = alloc_Boolean(0);
// compilenode returning bool190
// compilenode returning module_ast
  params[0] = call189;
  params[1] = bool190;
  Object call191 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call191
  var_o = alloc_var();
  *var_o = call191;
  if (call191 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 130
  setline(130);
// Begin line 131
  setline(131);
// Begin line 1577
  setline(1577);
// Begin line 127
  setline(127);
// compilenode returning *var_o
  Object call193 = callmethod(*var_o, "value",
    0, params);
// compilenode returning call193
// compilenode returning call193
  if (strlit194 == NULL) {
    strlit194 = alloc_String("_");
  }
// compilenode returning strlit194
  params[0] = strlit194;
  Object opresult196 = callmethod(call193, "==", 1, params);
// compilenode returning opresult196
  Object if192;
  if (istrue(opresult196)) {
// Begin line 129
  setline(129);
// Begin line 1577
  setline(1577);
// Begin line 129
  setline(129);
// Begin line 128
  setline(128);
  if (strlit197 == NULL) {
    strlit197 = alloc_String("__");
  }
// compilenode returning strlit197
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult199 = callmethod(strlit197, "++", 1, params);
// compilenode returning opresult199
// compilenode returning *var_o
  params[0] = opresult199;
  Object call200 = callmethod(*var_o, "value:=",
    1, params);
// compilenode returning call200
// compilenode returning nothing
// Begin line 130
  setline(130);
// Begin line 129
  setline(129);
// compilenode returning *var_auto_count
  Object num201 = alloc_Float64(1.0);
// compilenode returning num201
  params[0] = num201;
  Object sum203 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum203
  *var_auto_count = sum203;
  if (sum203 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if192 = nothing;
  } else {
  }
// compilenode returning if192
// Begin line 131
  setline(131);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call205 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call205
// Begin line 132
  setline(132);
// compilenode returning self
  Object call206 = callmethod(self, "next",
    0, params);
// compilenode returning call206
  return call206;
}
Object meth_parser_apply249(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[1];
  Object *var_unionName = closure[0];
  Object self = *closure[1];
// Begin line 158
  setline(158);
// Begin line 157
  setline(157);
  if (strlit250 == NULL) {
    strlit250 = alloc_String("");
  }
// compilenode returning strlit250
// compilenode returning *var_unionName
  params[0] = *var_unionName;
  Object opresult252 = callmethod(strlit250, "++", 1, params);
// compilenode returning opresult252
  if (strlit253 == NULL) {
    strlit253 = alloc_String("|");
  }
// compilenode returning strlit253
  params[0] = strlit253;
  Object opresult255 = callmethod(opresult252, "++", 1, params);
// compilenode returning opresult255
// Begin line 158
  setline(158);
// Begin line 1577
  setline(1577);
// Begin line 157
  setline(157);
// compilenode returning *var_ut
  Object call256 = callmethod(*var_ut, "value",
    0, params);
// compilenode returning call256
// compilenode returning call256
  params[0] = call256;
  Object opresult258 = callmethod(opresult255, "++", 1, params);
// compilenode returning opresult258
  if (strlit259 == NULL) {
    strlit259 = alloc_String("");
  }
// compilenode returning strlit259
  params[0] = strlit259;
  Object opresult261 = callmethod(opresult258, "++", 1, params);
// compilenode returning opresult261
  *var_unionName = opresult261;
  if (opresult261 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply278(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[1];
  Object *var_overallType = closure[0];
  Object self = *closure[1];
// Begin line 162
  setline(162);
// compilenode returning *var_ut
// Begin line 163
  setline(163);
// Begin line 1577
  setline(1577);
// Begin line 162
  setline(162);
// compilenode returning *var_overallType
  Object call279 = callmethod(*var_overallType, "unionTypes",
    0, params);
// compilenode returning call279
// compilenode returning call279
  params[0] = *var_ut;
  Object call280 = callmethod(call279, "push",
    1, params);
// compilenode returning call280
  return call280;
}
Object meth_parser_apply314(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_it = alloc_var();
  *var_it = args[0];
  Object params[1];
  Object *var_intersectionName = closure[0];
  Object self = *closure[1];
// Begin line 180
  setline(180);
// Begin line 179
  setline(179);
  if (strlit315 == NULL) {
    strlit315 = alloc_String("");
  }
// compilenode returning strlit315
// compilenode returning *var_intersectionName
  params[0] = *var_intersectionName;
  Object opresult317 = callmethod(strlit315, "++", 1, params);
// compilenode returning opresult317
  if (strlit318 == NULL) {
    strlit318 = alloc_String("&");
  }
// compilenode returning strlit318
  params[0] = strlit318;
  Object opresult320 = callmethod(opresult317, "++", 1, params);
// compilenode returning opresult320
// Begin line 180
  setline(180);
// Begin line 1577
  setline(1577);
// Begin line 179
  setline(179);
// compilenode returning *var_it
  Object call321 = callmethod(*var_it, "value",
    0, params);
// compilenode returning call321
// compilenode returning call321
  params[0] = call321;
  Object opresult323 = callmethod(opresult320, "++", 1, params);
// compilenode returning opresult323
  if (strlit324 == NULL) {
    strlit324 = alloc_String("");
  }
// compilenode returning strlit324
  params[0] = strlit324;
  Object opresult326 = callmethod(opresult323, "++", 1, params);
// compilenode returning opresult326
  *var_intersectionName = opresult326;
  if (opresult326 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply340(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_it = alloc_var();
  *var_it = args[0];
  Object params[1];
  Object *var_overallType = closure[0];
  Object self = *closure[1];
// Begin line 184
  setline(184);
// compilenode returning *var_it
// Begin line 185
  setline(185);
// Begin line 1577
  setline(1577);
// Begin line 184
  setline(184);
// compilenode returning *var_overallType
  Object call341 = callmethod(*var_overallType, "intersectionTypes",
    0, params);
// compilenode returning call341
// compilenode returning call341
  params[0] = *var_it;
  Object call342 = callmethod(call341, "push",
    1, params);
// compilenode returning call342
  return call342;
}
Object meth_parser_dotyperef207(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object params[2];
  Object *var_values = closure[0];
  Object *var_sym = closure[1];
  Object *var_overallType = alloc_var();
  *var_overallType = undefined;
  Object *var_tp = alloc_var();
  *var_tp = undefined;
  Object *var_op = alloc_var();
  *var_op = undefined;
  Object *var_unionTypes = alloc_var();
  *var_unionTypes = undefined;
  Object *var_intersectionTypes = alloc_var();
  *var_intersectionTypes = undefined;
// Begin line 137
  setline(137);
// Begin line 136
  setline(136);
  Object bool208 = alloc_Boolean(0);
// compilenode returning bool208
  var_overallType = alloc_var();
  *var_overallType = bool208;
  if (bool208 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 138
  setline(138);
// Begin line 137
  setline(137);
  Object bool209 = alloc_Boolean(0);
// compilenode returning bool209
  var_tp = alloc_var();
  *var_tp = bool209;
  if (bool209 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 139
  setline(139);
// Begin line 138
  setline(138);
  Object bool210 = alloc_Boolean(0);
// compilenode returning bool210
  var_op = alloc_var();
  *var_op = bool210;
  if (bool210 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 140
  setline(140);
  Object array211 = alloc_List();
// compilenode returning array211
  *var_unionTypes = array211;
  if (array211 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 144
  setline(144);
// Begin line 140
  setline(140);
  if (strlit213 == NULL) {
    strlit213 = alloc_String("identifier");
  }
// compilenode returning strlit213
// Begin line 145
  setline(145);
// compilenode returning self
  params[0] = strlit213;
  Object call214 = callmethod(self, "accept",
    1, params);
// compilenode returning call214
  Object if212;
  if (istrue(call214)) {
// Begin line 141
  setline(141);
// compilenode returning self
  Object call215 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call215
// Begin line 142
  setline(142);
// compilenode returning self
  Object call216 = callmethod(self, "generic",
    0, params);
// compilenode returning call216
// Begin line 144
  setline(144);
// Begin line 1577
  setline(1577);
// Begin line 143
  setline(143);
// compilenode returning *var_values
  Object call217 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call217
// compilenode returning call217
  *var_overallType = call217;
  if (call217 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if212 = nothing;
  } else {
  }
// compilenode returning if212
// Begin line 152
  setline(152);
  Object while219;
  while (1) {
// Begin line 145
  setline(145);
  if (strlit220 == NULL) {
    strlit220 = alloc_String("op");
  }
// compilenode returning strlit220
// Begin line 154
  setline(154);
// compilenode returning self
  params[0] = strlit220;
  Object call221 = callmethod(self, "accept",
    1, params);
// compilenode returning call221
// Begin line 145
  setline(145);
// Begin line 1577
  setline(1577);
// Begin line 145
  setline(145);
// compilenode returning *var_sym
  Object call222 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call222
// compilenode returning call222
  if (strlit223 == NULL) {
    strlit223 = alloc_String("|");
  }
// compilenode returning strlit223
  params[0] = strlit223;
  Object opresult225 = callmethod(call222, "==", 1, params);
// compilenode returning opresult225
  params[0] = opresult225;
  Object opresult227 = callmethod(call221, "&", 1, params);
// compilenode returning opresult227
    while219 = opresult227;
    if (!istrue(opresult227)) break;
// Begin line 147
  setline(147);
// Begin line 149
  setline(149);
// Begin line 1577
  setline(1577);
// Begin line 146
  setline(146);
// compilenode returning *var_unionTypes
  Object call229 = callmethod(*var_unionTypes, "size",
    0, params);
// compilenode returning call229
// compilenode returning call229
  Object num230 = alloc_Float64(0.0);
// compilenode returning num230
  params[0] = num230;
  Object opresult232 = callmethod(call229, "==", 1, params);
// compilenode returning opresult232
  Object if228;
  if (istrue(opresult232)) {
// Begin line 147
  setline(147);
// compilenode returning *var_overallType
// compilenode returning *var_unionTypes
  params[0] = *var_overallType;
  Object call233 = callmethod(*var_unionTypes, "push",
    1, params);
// compilenode returning call233
    if228 = call233;
  } else {
  }
// compilenode returning if228
// Begin line 149
  setline(149);
// compilenode returning self
  Object call234 = callmethod(self, "next",
    0, params);
// compilenode returning call234
// Begin line 150
  setline(150);
// compilenode returning self
  Object call235 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call235
// Begin line 151
  setline(151);
// compilenode returning self
  Object call236 = callmethod(self, "generic",
    0, params);
// compilenode returning call236
// Begin line 152
  setline(152);
// Begin line 1577
  setline(1577);
// Begin line 152
  setline(152);
// compilenode returning *var_values
  Object call237 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call237
// compilenode returning call237
// compilenode returning *var_unionTypes
  params[0] = call237;
  Object call238 = callmethod(*var_unionTypes, "push",
    1, params);
// compilenode returning call238
  }
// compilenode returning while219
// Begin line 164
  setline(164);
// Begin line 166
  setline(166);
// Begin line 1577
  setline(1577);
// Begin line 154
  setline(154);
// compilenode returning *var_unionTypes
  Object call240 = callmethod(*var_unionTypes, "size",
    0, params);
// compilenode returning call240
// compilenode returning call240
  Object num241 = alloc_Float64(0.0);
// compilenode returning num241
  params[0] = num241;
  Object opresult243 = callmethod(call240, ">", 1, params);
// compilenode returning opresult243
  Object if239;
  if (istrue(opresult243)) {
  Object *var_unionName = alloc_var();
  *var_unionName = undefined;
// Begin line 156
  setline(156);
// Begin line 155
  setline(155);
  if (strlit244 == NULL) {
    strlit244 = alloc_String("Union<");
  }
// compilenode returning strlit244
  var_unionName = alloc_var();
  *var_unionName = strlit244;
  if (strlit244 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 158
  setline(158);
// Begin line 156
  setline(156);
// compilenode returning *var_unionTypes
// Begin line 158
  setline(158);
// Begin line 1577
  setline(1577);
  Object obj247 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj247, self, 0);
  addmethod2(obj247, "outer", &reader_parser_outer_248);
  adddatum2(obj247, self, 0);
  block_savedest(obj247);
  Object **closure249 = createclosure(2);
  addtoclosure(closure249, var_unionName);
  Object *selfpp263 = alloc_var();
  *selfpp263 = self;
  addtoclosure(closure249, selfpp263);
  struct UserObject *uo249 = (struct UserObject*)obj247;
  uo249->data[1] = (Object)closure249;
  addmethod2(obj247, "apply", &meth_parser_apply249);
  set_type(obj247, 0);
// compilenode returning obj247
  setclassname(obj247, "Block<parser:246>");
// compilenode returning obj247
  params[0] = *var_unionTypes;
  Object iter245 = callmethod(*var_unionTypes, "iter", 1, params);
  while(1) {
    Object cond245 = callmethod(iter245, "havemore", 0, NULL);
    if (!istrue(cond245)) break;
    params[0] = callmethod(iter245, "next", 0, NULL);
    callmethod(obj247, "apply", 1, params);
  }
// compilenode returning *var_unionTypes
// Begin line 160
  setline(160);
// Begin line 159
  setline(159);
  if (strlit264 == NULL) {
    strlit264 = alloc_String("");
  }
// compilenode returning strlit264
// compilenode returning *var_unionName
  params[0] = *var_unionName;
  Object opresult266 = callmethod(strlit264, "++", 1, params);
// compilenode returning opresult266
  if (strlit267 == NULL) {
    strlit267 = alloc_String("|>");
  }
// compilenode returning strlit267
  params[0] = strlit267;
  Object opresult269 = callmethod(opresult266, "++", 1, params);
// compilenode returning opresult269
  *var_unionName = opresult269;
  if (opresult269 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 160
  setline(160);
// compilenode returning *var_unionName
  Object array271 = alloc_List();
// compilenode returning array271
// compilenode returning module_ast
  params[0] = *var_unionName;
  params[1] = array271;
  Object call272 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call272
  *var_overallType = call272;
  if (call272 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 162
  setline(162);
// Begin line 161
  setline(161);
// compilenode returning *var_unionTypes
// Begin line 162
  setline(162);
// Begin line 1577
  setline(1577);
  Object obj276 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj276, self, 0);
  addmethod2(obj276, "outer", &reader_parser_outer_277);
  adddatum2(obj276, self, 0);
  block_savedest(obj276);
  Object **closure278 = createclosure(2);
  addtoclosure(closure278, var_overallType);
  Object *selfpp281 = alloc_var();
  *selfpp281 = self;
  addtoclosure(closure278, selfpp281);
  struct UserObject *uo278 = (struct UserObject*)obj276;
  uo278->data[1] = (Object)closure278;
  addmethod2(obj276, "apply", &meth_parser_apply278);
  set_type(obj276, 0);
// compilenode returning obj276
  setclassname(obj276, "Block<parser:275>");
// compilenode returning obj276
  params[0] = *var_unionTypes;
  Object iter274 = callmethod(*var_unionTypes, "iter", 1, params);
  while(1) {
    Object cond274 = callmethod(iter274, "havemore", 0, NULL);
    if (!istrue(cond274)) break;
    params[0] = callmethod(iter274, "next", 0, NULL);
    callmethod(obj276, "apply", 1, params);
  }
// compilenode returning *var_unionTypes
// Begin line 164
  setline(164);
// compilenode returning *var_overallType
// compilenode returning module_subtype
  params[0] = *var_overallType;
  Object call282 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call282
    if239 = call282;
  } else {
  }
// compilenode returning if239
// Begin line 167
  setline(167);
  Object array283 = alloc_List();
// compilenode returning array283
  *var_intersectionTypes = array283;
  if (array283 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 174
  setline(174);
  Object while284;
  while (1) {
// Begin line 167
  setline(167);
  if (strlit285 == NULL) {
    strlit285 = alloc_String("op");
  }
// compilenode returning strlit285
// Begin line 176
  setline(176);
// compilenode returning self
  params[0] = strlit285;
  Object call286 = callmethod(self, "accept",
    1, params);
// compilenode returning call286
// Begin line 167
  setline(167);
// Begin line 1577
  setline(1577);
// Begin line 167
  setline(167);
// compilenode returning *var_sym
  Object call287 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call287
// compilenode returning call287
  if (strlit288 == NULL) {
    strlit288 = alloc_String("&");
  }
// compilenode returning strlit288
  params[0] = strlit288;
  Object opresult290 = callmethod(call287, "==", 1, params);
// compilenode returning opresult290
  params[0] = opresult290;
  Object opresult292 = callmethod(call286, "&", 1, params);
// compilenode returning opresult292
    while284 = opresult292;
    if (!istrue(opresult292)) break;
// Begin line 169
  setline(169);
// Begin line 171
  setline(171);
// Begin line 1577
  setline(1577);
// Begin line 168
  setline(168);
// compilenode returning *var_intersectionTypes
  Object call294 = callmethod(*var_intersectionTypes, "size",
    0, params);
// compilenode returning call294
// compilenode returning call294
  Object num295 = alloc_Float64(0.0);
// compilenode returning num295
  params[0] = num295;
  Object opresult297 = callmethod(call294, "==", 1, params);
// compilenode returning opresult297
  Object if293;
  if (istrue(opresult297)) {
// Begin line 169
  setline(169);
// compilenode returning *var_overallType
// compilenode returning *var_intersectionTypes
  params[0] = *var_overallType;
  Object call298 = callmethod(*var_intersectionTypes, "push",
    1, params);
// compilenode returning call298
    if293 = call298;
  } else {
  }
// compilenode returning if293
// Begin line 171
  setline(171);
// compilenode returning self
  Object call299 = callmethod(self, "next",
    0, params);
// compilenode returning call299
// Begin line 172
  setline(172);
// compilenode returning self
  Object call300 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call300
// Begin line 173
  setline(173);
// compilenode returning self
  Object call301 = callmethod(self, "generic",
    0, params);
// compilenode returning call301
// Begin line 174
  setline(174);
// Begin line 1577
  setline(1577);
// Begin line 174
  setline(174);
// compilenode returning *var_values
  Object call302 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call302
// compilenode returning call302
// compilenode returning *var_intersectionTypes
  params[0] = call302;
  Object call303 = callmethod(*var_intersectionTypes, "push",
    1, params);
// compilenode returning call303
  }
// compilenode returning while284
// Begin line 186
  setline(186);
// Begin line 188
  setline(188);
// Begin line 1577
  setline(1577);
// Begin line 176
  setline(176);
// compilenode returning *var_intersectionTypes
  Object call305 = callmethod(*var_intersectionTypes, "size",
    0, params);
// compilenode returning call305
// compilenode returning call305
  Object num306 = alloc_Float64(0.0);
// compilenode returning num306
  params[0] = num306;
  Object opresult308 = callmethod(call305, ">", 1, params);
// compilenode returning opresult308
  Object if304;
  if (istrue(opresult308)) {
  Object *var_intersectionName = alloc_var();
  *var_intersectionName = undefined;
// Begin line 178
  setline(178);
// Begin line 177
  setline(177);
  if (strlit309 == NULL) {
    strlit309 = alloc_String("Intersection<");
  }
// compilenode returning strlit309
  var_intersectionName = alloc_var();
  *var_intersectionName = strlit309;
  if (strlit309 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 180
  setline(180);
// Begin line 178
  setline(178);
// compilenode returning *var_intersectionTypes
// Begin line 180
  setline(180);
// Begin line 1577
  setline(1577);
  Object obj312 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj312, self, 0);
  addmethod2(obj312, "outer", &reader_parser_outer_313);
  adddatum2(obj312, self, 0);
  block_savedest(obj312);
  Object **closure314 = createclosure(2);
  addtoclosure(closure314, var_intersectionName);
  Object *selfpp328 = alloc_var();
  *selfpp328 = self;
  addtoclosure(closure314, selfpp328);
  struct UserObject *uo314 = (struct UserObject*)obj312;
  uo314->data[1] = (Object)closure314;
  addmethod2(obj312, "apply", &meth_parser_apply314);
  set_type(obj312, 0);
// compilenode returning obj312
  setclassname(obj312, "Block<parser:311>");
// compilenode returning obj312
  params[0] = *var_intersectionTypes;
  Object iter310 = callmethod(*var_intersectionTypes, "iter", 1, params);
  while(1) {
    Object cond310 = callmethod(iter310, "havemore", 0, NULL);
    if (!istrue(cond310)) break;
    params[0] = callmethod(iter310, "next", 0, NULL);
    callmethod(obj312, "apply", 1, params);
  }
// compilenode returning *var_intersectionTypes
// Begin line 182
  setline(182);
// Begin line 181
  setline(181);
// compilenode returning *var_intersectionName
  if (strlit329 == NULL) {
    strlit329 = alloc_String("&>");
  }
// compilenode returning strlit329
  params[0] = strlit329;
  Object opresult331 = callmethod(*var_intersectionName, "++", 1, params);
// compilenode returning opresult331
  *var_intersectionName = opresult331;
  if (opresult331 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 182
  setline(182);
// compilenode returning *var_intersectionName
  Object array333 = alloc_List();
// compilenode returning array333
// compilenode returning module_ast
  params[0] = *var_intersectionName;
  params[1] = array333;
  Object call334 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call334
  *var_overallType = call334;
  if (call334 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 184
  setline(184);
// Begin line 183
  setline(183);
// compilenode returning *var_intersectionTypes
// Begin line 184
  setline(184);
// Begin line 1577
  setline(1577);
  Object obj338 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj338, self, 0);
  addmethod2(obj338, "outer", &reader_parser_outer_339);
  adddatum2(obj338, self, 0);
  block_savedest(obj338);
  Object **closure340 = createclosure(2);
  addtoclosure(closure340, var_overallType);
  Object *selfpp343 = alloc_var();
  *selfpp343 = self;
  addtoclosure(closure340, selfpp343);
  struct UserObject *uo340 = (struct UserObject*)obj338;
  uo340->data[1] = (Object)closure340;
  addmethod2(obj338, "apply", &meth_parser_apply340);
  set_type(obj338, 0);
// compilenode returning obj338
  setclassname(obj338, "Block<parser:337>");
// compilenode returning obj338
  params[0] = *var_intersectionTypes;
  Object iter336 = callmethod(*var_intersectionTypes, "iter", 1, params);
  while(1) {
    Object cond336 = callmethod(iter336, "havemore", 0, NULL);
    if (!istrue(cond336)) break;
    params[0] = callmethod(iter336, "next", 0, NULL);
    callmethod(obj338, "apply", 1, params);
  }
// compilenode returning *var_intersectionTypes
// Begin line 186
  setline(186);
// compilenode returning *var_overallType
// compilenode returning module_subtype
  params[0] = *var_overallType;
  Object call344 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call344
    if304 = call344;
  } else {
  }
// compilenode returning if304
// Begin line 188
  setline(188);
// compilenode returning *var_overallType
// compilenode returning *var_values
  params[0] = *var_overallType;
  Object call345 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call345
  return call345;
}
Object meth_parser_apply363(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 207
  setline(207);
// compilenode returning self
  Object call364 = callmethod(self, "expression",
    0, params);
// compilenode returning call364
  return call364;
}
Object meth_parser_apply369(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[2];
  Object *var_values = closure[0];
  Object *var_ident1 = closure[1];
  Object *var_params = closure[2];
  Object *var_body = closure[3];
  Object self = *closure[4];
// Begin line 242
  setline(242);
// Begin line 208
  setline(208);
  if (strlit371 == NULL) {
    strlit371 = alloc_String("comma");
  }
// compilenode returning strlit371
// Begin line 244
  setline(244);
// compilenode returning self
  params[0] = strlit371;
  Object call372 = callmethod(self, "accept",
    1, params);
// compilenode returning call372
// Begin line 208
  setline(208);
  if (strlit373 == NULL) {
    strlit373 = alloc_String("arrow");
  }
// compilenode returning strlit373
// compilenode returning self
  params[0] = strlit373;
  Object call374 = callmethod(self, "accept",
    1, params);
// compilenode returning call374
  params[0] = call374;
  Object opresult376 = callmethod(call372, "|", 1, params);
// compilenode returning opresult376
  if (strlit377 == NULL) {
    strlit377 = alloc_String("colon");
  }
// compilenode returning strlit377
// compilenode returning self
  params[0] = strlit377;
  Object call378 = callmethod(self, "accept",
    1, params);
// compilenode returning call378
  params[0] = call378;
  Object opresult380 = callmethod(opresult376, "|", 1, params);
// compilenode returning opresult380
  Object if370;
  if (istrue(opresult380)) {
// Begin line 211
  setline(211);
// Begin line 1577
  setline(1577);
// Begin line 210
  setline(210);
// compilenode returning *var_values
  Object call381 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call381
// compilenode returning call381
  *var_ident1 = call381;
  if (call381 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 217
  setline(217);
// Begin line 211
  setline(211);
  if (strlit384 == NULL) {
    strlit384 = alloc_String("colon");
  }
// compilenode returning strlit384
// Begin line 218
  setline(218);
// compilenode returning self
  params[0] = strlit384;
  Object call385 = callmethod(self, "accept",
    1, params);
// compilenode returning call385
  Object if383;
  if (istrue(call385)) {
// Begin line 214
  setline(214);
// compilenode returning self
  Object call386 = callmethod(self, "next",
    0, params);
// compilenode returning call386
// Begin line 215
  setline(215);
// compilenode returning self
  Object call387 = callmethod(self, "expression",
    0, params);
// compilenode returning call387
// Begin line 217
  setline(217);
// Begin line 1577
  setline(1577);
// Begin line 217
  setline(217);
// Begin line 1577
  setline(1577);
// Begin line 216
  setline(216);
// compilenode returning *var_values
  Object call388 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call388
// compilenode returning call388
// compilenode returning *var_ident1
  params[0] = call388;
  Object call389 = callmethod(*var_ident1, "dtype:=",
    1, params);
// compilenode returning call389
// compilenode returning nothing
    if383 = nothing;
  } else {
  }
// compilenode returning if383
// Begin line 218
  setline(218);
// compilenode returning *var_ident1
// compilenode returning *var_params
  params[0] = *var_ident1;
  Object call390 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call390
// Begin line 229
  setline(229);
  Object while391;
  while (1) {
// Begin line 219
  setline(219);
  if (strlit392 == NULL) {
    strlit392 = alloc_String("comma");
  }
// compilenode returning strlit392
// Begin line 231
  setline(231);
// compilenode returning self
  params[0] = strlit392;
  Object call393 = callmethod(self, "accept",
    1, params);
// compilenode returning call393
    while391 = call393;
    if (!istrue(call393)) break;
// Begin line 221
  setline(221);
// compilenode returning self
  Object call394 = callmethod(self, "next",
    0, params);
// compilenode returning call394
// Begin line 222
  setline(222);
// compilenode returning self
  Object call395 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call395
// Begin line 224
  setline(224);
// Begin line 1577
  setline(1577);
// Begin line 223
  setline(223);
// compilenode returning *var_values
  Object call396 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call396
// compilenode returning call396
  *var_ident1 = call396;
  if (call396 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 228
  setline(228);
// Begin line 224
  setline(224);
  if (strlit399 == NULL) {
    strlit399 = alloc_String("colon");
  }
// compilenode returning strlit399
// Begin line 229
  setline(229);
// compilenode returning self
  params[0] = strlit399;
  Object call400 = callmethod(self, "accept",
    1, params);
// compilenode returning call400
  Object if398;
  if (istrue(call400)) {
// Begin line 225
  setline(225);
// compilenode returning self
  Object call401 = callmethod(self, "next",
    0, params);
// compilenode returning call401
// Begin line 226
  setline(226);
// compilenode returning self
  Object call402 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call402
// Begin line 228
  setline(228);
// Begin line 1577
  setline(1577);
// Begin line 228
  setline(228);
// Begin line 1577
  setline(1577);
// Begin line 227
  setline(227);
// compilenode returning *var_values
  Object call403 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call403
// compilenode returning call403
// compilenode returning *var_ident1
  params[0] = call403;
  Object call404 = callmethod(*var_ident1, "dtype:=",
    1, params);
// compilenode returning call404
// compilenode returning nothing
    if398 = nothing;
  } else {
  }
// compilenode returning if398
// Begin line 229
  setline(229);
// compilenode returning *var_ident1
// compilenode returning *var_params
  params[0] = *var_ident1;
  Object call405 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call405
  }
// compilenode returning while391
// Begin line 232
  setline(232);
// Begin line 231
  setline(231);
// Begin line 1577
  setline(1577);
// Begin line 231
  setline(231);
  if (strlit407 == NULL) {
    strlit407 = alloc_String("arrow");
  }
// compilenode returning strlit407
// Begin line 234
  setline(234);
// compilenode returning self
  params[0] = strlit407;
  Object call408 = callmethod(self, "accept",
    1, params);
// compilenode returning call408
  Object call409 = callmethod(call408, "not",
    0, params);
// compilenode returning call409
// compilenode returning call409
  Object if406;
  if (istrue(call409)) {
// Begin line 232
  setline(232);
  if (strlit410 == NULL) {
    strlit410 = alloc_String("block parameter list not terminated ->.");
  }
// compilenode returning strlit410
// compilenode returning module_util
  params[0] = strlit410;
  Object call411 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call411
    if406 = call411;
  } else {
  }
// compilenode returning if406
// Begin line 234
  setline(234);
// compilenode returning self
  Object call412 = callmethod(self, "next",
    0, params);
// compilenode returning call412
    if370 = call412;
  } else {
// Begin line 242
  setline(242);
// Begin line 235
  setline(235);
  if (strlit414 == NULL) {
    strlit414 = alloc_String("bind");
  }
// compilenode returning strlit414
// Begin line 241
  setline(241);
// compilenode returning self
  params[0] = strlit414;
  Object call415 = callmethod(self, "accept",
    1, params);
// compilenode returning call415
  Object if413;
  if (istrue(call415)) {
  Object *var_lhs = alloc_var();
  *var_lhs = undefined;
  Object *var_rhs = alloc_var();
  *var_rhs = undefined;
// Begin line 237
  setline(237);
// Begin line 1577
  setline(1577);
// Begin line 236
  setline(236);
// compilenode returning *var_values
  Object call416 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call416
// compilenode returning call416
  var_lhs = alloc_var();
  *var_lhs = call416;
  if (call416 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 237
  setline(237);
// compilenode returning self
  Object call417 = callmethod(self, "next",
    0, params);
// compilenode returning call417
// Begin line 238
  setline(238);
// compilenode returning self
  Object call418 = callmethod(self, "expression",
    0, params);
// compilenode returning call418
// Begin line 240
  setline(240);
// Begin line 1577
  setline(1577);
// Begin line 239
  setline(239);
// compilenode returning *var_values
  Object call419 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call419
// compilenode returning call419
  var_rhs = alloc_var();
  *var_rhs = call419;
  if (call419 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 240
  setline(240);
// compilenode returning *var_lhs
// compilenode returning *var_rhs
// compilenode returning module_ast
  params[0] = *var_lhs;
  params[1] = *var_rhs;
  Object call420 = callmethod(module_ast, "astbind",
    2, params);
// compilenode returning call420
// compilenode returning *var_body
  params[0] = call420;
  Object call421 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call421
    if413 = call421;
  } else {
// Begin line 242
  setline(242);
// Begin line 1577
  setline(1577);
// Begin line 242
  setline(242);
// compilenode returning *var_values
  Object call422 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call422
// compilenode returning call422
// compilenode returning *var_body
  params[0] = call422;
  Object call423 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call423
    if413 = call423;
  }
// compilenode returning if413
    if370 = if413;
  }
// compilenode returning if370
  return if370;
}
Object meth_parser_apply449(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 256
  setline(256);
// compilenode returning self
  Object call450 = callmethod(self, "statement",
    0, params);
// compilenode returning call450
  return call450;
}
Object meth_parser_block346(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object params[2];
  Object *var_statementIndent = closure[0];
  Object *var_sym = closure[1];
  Object *var_tokens = closure[2];
  Object *var_statementToken = closure[3];
  Object *var_values = closure[4];
  Object *var_lastToken = closure[5];
  Object *var_minIndentLevel = closure[6];
// Begin line 193
  setline(193);
  if (strlit348 == NULL) {
    strlit348 = alloc_String("lbrace");
  }
// compilenode returning strlit348
// Begin line 266
  setline(266);
// compilenode returning self
  params[0] = strlit348;
  Object call349 = callmethod(self, "accept",
    1, params);
// compilenode returning call349
  Object if347;
  if (istrue(call349)) {
  Object *var_minInd = alloc_var();
  *var_minInd = undefined;
  Object *var_startIndent = alloc_var();
  *var_startIndent = undefined;
  Object *var_ident1 = alloc_var();
  *var_ident1 = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_havearrow = alloc_var();
  *var_havearrow = undefined;
  Object *var_found = alloc_var();
  *var_found = undefined;
  Object *var_i = alloc_var();
  *var_i = undefined;
  Object *var_toks = alloc_var();
  *var_toks = undefined;
  Object *var_ln = alloc_var();
  *var_ln = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 194
  setline(194);
// compilenode returning self
  Object call350 = callmethod(self, "next",
    0, params);
// compilenode returning call350
// Begin line 196
  setline(196);
// Begin line 195
  setline(195);
// compilenode returning *var_statementIndent
  Object num351 = alloc_Float64(1.0);
// compilenode returning num351
  params[0] = num351;
  Object sum353 = callmethod(*var_statementIndent, "+", 1, params);
// compilenode returning sum353
  var_minInd = alloc_var();
  *var_minInd = sum353;
  if (sum353 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 197
  setline(197);
// Begin line 196
  setline(196);
// compilenode returning *var_statementIndent
  var_startIndent = alloc_var();
  *var_startIndent = *var_statementIndent;
  if (*var_statementIndent == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 198
  setline(198);
  var_ident1 = alloc_var();
  *var_ident1 = undefined;
// compilenode returning nothing
// Begin line 199
  setline(199);
// Begin line 198
  setline(198);
// compilenode returning *var_sym
  var_s = alloc_var();
  *var_s = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 200
  setline(200);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 201
  setline(201);
  Object array354 = alloc_List();
// compilenode returning array354
  var_params = alloc_var();
  *var_params = array354;
  if (array354 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 202
  setline(202);
  Object array355 = alloc_List();
// compilenode returning array355
  var_body = alloc_var();
  *var_body = array355;
  if (array355 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 203
  setline(203);
// Begin line 202
  setline(202);
  Object bool356 = alloc_Boolean(1);
// compilenode returning bool356
  var_havearrow = alloc_var();
  *var_havearrow = bool356;
  if (bool356 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 204
  setline(204);
// Begin line 203
  setline(203);
  Object bool357 = alloc_Boolean(0);
// compilenode returning bool357
  var_found = alloc_var();
  *var_found = bool357;
  if (bool357 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 205
  setline(205);
// Begin line 204
  setline(204);
  Object num358 = alloc_Float64(0.0);
// compilenode returning num358
  var_i = alloc_var();
  *var_i = num358;
  if (num358 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 206
  setline(206);
// Begin line 205
  setline(205);
// compilenode returning *var_tokens
  var_toks = alloc_var();
  *var_toks = *var_tokens;
  if (*var_tokens == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 207
  setline(207);
// Begin line 206
  setline(206);
// compilenode returning *var_sym
  *var_statementToken = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 242
  setline(242);
// Begin line 207
  setline(207);
// Begin line 1577
  setline(1577);
  Object obj361 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj361, self, 0);
  addmethod2(obj361, "outer", &reader_parser_outer_362);
  adddatum2(obj361, self, 0);
  block_savedest(obj361);
  Object **closure363 = createclosure(1);
  Object *selfpp365 = alloc_var();
  *selfpp365 = self;
  addtoclosure(closure363, selfpp365);
  struct UserObject *uo363 = (struct UserObject*)obj361;
  uo363->data[1] = (Object)closure363;
  addmethod2(obj361, "apply", &meth_parser_apply363);
  set_type(obj361, 0);
// compilenode returning obj361
  setclassname(obj361, "Block<parser:360>");
// compilenode returning obj361
// Begin line 242
  setline(242);
// Begin line 1577
  setline(1577);
  Object obj367 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj367, self, 0);
  addmethod2(obj367, "outer", &reader_parser_outer_368);
  adddatum2(obj367, self, 0);
  block_savedest(obj367);
  Object **closure369 = createclosure(5);
  addtoclosure(closure369, var_values);
  addtoclosure(closure369, var_ident1);
  addtoclosure(closure369, var_params);
  addtoclosure(closure369, var_body);
  Object *selfpp424 = alloc_var();
  *selfpp424 = self;
  addtoclosure(closure369, selfpp424);
  struct UserObject *uo369 = (struct UserObject*)obj367;
  uo369->data[1] = (Object)closure369;
  addmethod2(obj367, "apply", &meth_parser_apply369);
  set_type(obj367, 0);
// compilenode returning obj367
  setclassname(obj367, "Block<parser:366>");
// compilenode returning obj367
// Begin line 245
  setline(245);
// compilenode returning self
  params[0] = obj361;
  params[1] = obj367;
  Object call425 = callmethod(self, "ifConsume(1)then",
    2, params);
// compilenode returning call425
// Begin line 246
  setline(246);
// Begin line 245
  setline(245);
  if (strlit427 == NULL) {
    strlit427 = alloc_String("arrow");
  }
// compilenode returning strlit427
// Begin line 248
  setline(248);
// compilenode returning self
  params[0] = strlit427;
  Object call428 = callmethod(self, "accept",
    1, params);
// compilenode returning call428
  Object if426;
  if (istrue(call428)) {
// Begin line 246
  setline(246);
// compilenode returning self
  Object call429 = callmethod(self, "next",
    0, params);
// compilenode returning call429
    if426 = call429;
  } else {
  }
// compilenode returning if426
// Begin line 249
  setline(249);
// Begin line 1577
  setline(1577);
// Begin line 248
  setline(248);
// compilenode returning *var_values
  Object call430 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call430
// compilenode returning call430
  var_ln = alloc_var();
  *var_ln = call430;
  if (call430 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 253
  setline(253);
// Begin line 254
  setline(254);
// Begin line 1577
  setline(1577);
// Begin line 249
  setline(249);
// compilenode returning *var_sym
  Object call432 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call432
// compilenode returning call432
// Begin line 254
  setline(254);
// Begin line 1577
  setline(1577);
// Begin line 249
  setline(249);
// compilenode returning *var_lastToken
  Object call433 = callmethod(*var_lastToken, "line",
    0, params);
// compilenode returning call433
// compilenode returning call433
  params[0] = call433;
  Object opresult435 = callmethod(call432, "==", 1, params);
// compilenode returning opresult435
  Object if431;
  if (istrue(opresult435)) {
// Begin line 251
  setline(251);
// Begin line 1577
  setline(1577);
// Begin line 250
  setline(250);
// compilenode returning *var_sym
  Object call436 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call436
// compilenode returning call436
  Object num437 = alloc_Float64(1.0);
// compilenode returning num437
  params[0] = num437;
  Object diff439 = callmethod(call436, "-", 1, params);
// compilenode returning diff439
  *var_minIndentLevel = diff439;
  if (diff439 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if431 = nothing;
  } else {
// Begin line 253
  setline(253);
// Begin line 252
  setline(252);
// compilenode returning *var_minInd
  *var_minIndentLevel = *var_minInd;
  if (*var_minInd == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if431 = nothing;
  }
// compilenode returning if431
// Begin line 258
  setline(258);
  Object while442;
  while (1) {
// Begin line 254
  setline(254);
// Begin line 1577
  setline(1577);
// Begin line 254
  setline(254);
  if (strlit443 == NULL) {
    strlit443 = alloc_String("rbrace");
  }
// compilenode returning strlit443
// Begin line 260
  setline(260);
// compilenode returning self
  params[0] = strlit443;
  Object call444 = callmethod(self, "accept",
    1, params);
// compilenode returning call444
  Object call445 = callmethod(call444, "not",
    0, params);
// compilenode returning call445
// compilenode returning call445
    while442 = call445;
    if (!istrue(call445)) break;
// Begin line 256
  setline(256);
// Begin line 1577
  setline(1577);
  Object obj447 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj447, self, 0);
  addmethod2(obj447, "outer", &reader_parser_outer_448);
  adddatum2(obj447, self, 0);
  block_savedest(obj447);
  Object **closure449 = createclosure(1);
  Object *selfpp451 = alloc_var();
  *selfpp451 = self;
  addtoclosure(closure449, selfpp451);
  struct UserObject *uo449 = (struct UserObject*)obj447;
  uo449->data[1] = (Object)closure449;
  addmethod2(obj447, "apply", &meth_parser_apply449);
  set_type(obj447, 0);
// compilenode returning obj447
  setclassname(obj447, "Block<parser:446>");
// compilenode returning obj447
// Begin line 257
  setline(257);
// compilenode returning self
  params[0] = obj447;
  Object call452 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call452
// Begin line 258
  setline(258);
// Begin line 1577
  setline(1577);
// Begin line 257
  setline(257);
// compilenode returning *var_values
  Object call453 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call453
// compilenode returning call453
  *var_tmp = call453;
  if (call453 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 258
  setline(258);
// compilenode returning *var_tmp
// compilenode returning *var_body
  params[0] = *var_tmp;
  Object call455 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call455
  }
// compilenode returning while442
// Begin line 261
  setline(261);
// Begin line 260
  setline(260);
// compilenode returning *var_minInd
  Object num456 = alloc_Float64(1.0);
// compilenode returning num456
  params[0] = num456;
  Object diff458 = callmethod(*var_minInd, "-", 1, params);
// compilenode returning diff458
  *var_minIndentLevel = diff458;
  if (diff458 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 262
  setline(262);
// Begin line 261
  setline(261);
// compilenode returning *var_startIndent
  *var_statementIndent = *var_startIndent;
  if (*var_startIndent == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 262
  setline(262);
// compilenode returning self
  Object call461 = callmethod(self, "next",
    0, params);
// compilenode returning call461
// Begin line 263
  setline(263);
// compilenode returning *var_params
// compilenode returning *var_body
// compilenode returning module_ast
  params[0] = *var_params;
  params[1] = *var_body;
  Object call462 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call462
  var_o = alloc_var();
  *var_o = call462;
  if (call462 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call463 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call463
    if347 = call463;
  } else {
  }
// compilenode returning if347
  return if347;
}
Object meth_parser_apply498(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[2];
  Object *var_auto_count = closure[0];
  Object *var_nparams = closure[1];
  Object *var_inbody = closure[2];
  Object self = *closure[3];
  Object *var_inname = alloc_var();
  *var_inname = undefined;
// Begin line 287
  setline(287);
  if (strlit499 == NULL) {
    strlit499 = alloc_String("__matchvar");
  }
// compilenode returning strlit499
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult501 = callmethod(strlit499, "++", 1, params);
// compilenode returning opresult501
  Object bool502 = alloc_Boolean(0);
// compilenode returning bool502
// compilenode returning module_ast
  params[0] = opresult501;
  params[1] = bool502;
  Object call503 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call503
  var_inname = alloc_var();
  *var_inname = call503;
  if (call503 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 289
  setline(289);
// Begin line 288
  setline(288);
// compilenode returning *var_auto_count
  Object num504 = alloc_Float64(1.0);
// compilenode returning num504
  params[0] = num504;
  Object sum506 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum506
  *var_auto_count = sum506;
  if (sum506 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 289
  setline(289);
// compilenode returning *var_inname
// compilenode returning *var_nparams
  params[0] = *var_inname;
  Object call508 = callmethod(*var_nparams, "push",
    1, params);
// compilenode returning call508
// Begin line 292
  setline(292);
  Object array509 = alloc_List();
// Begin line 291
  setline(291);
  if (strlit510 == NULL) {
    strlit510 = alloc_String("apply");
  }
// compilenode returning strlit510
// Begin line 292
  setline(292);
// Begin line 291
  setline(291);
  Object array511 = alloc_List();
// compilenode returning *var_p
  params[0] = *var_p;
  callmethod(array511, "push", 1, params);
// compilenode returning array511
// Begin line 292
  setline(292);
// compilenode returning *var_inbody
// Begin line 291
  setline(291);
// compilenode returning module_ast
  params[0] = array511;
  params[1] = *var_inbody;
  Object call512 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call512
// Begin line 292
  setline(292);
// compilenode returning self
  params[0] = call512;
  Object call513 = callmethod(self, "rewritematchblock",
    1, params);
// compilenode returning call513
// Begin line 291
  setline(291);
// compilenode returning module_ast
  params[0] = strlit510;
  params[1] = call513;
  Object call514 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call514
// Begin line 292
  setline(292);
  Object array515 = alloc_List();
// compilenode returning *var_inname
  params[0] = *var_inname;
  callmethod(array515, "push", 1, params);
// compilenode returning array515
// Begin line 290
  setline(290);
// compilenode returning module_ast
  params[0] = call514;
  params[1] = array515;
  Object call516 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call516
  params[0] = call516;
  callmethod(array509, "push", 1, params);
// compilenode returning array509
  *var_inbody = array509;
  if (array509 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply588(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_p = alloc_var();
  *var_p = args[0];
  Object params[2];
  Object *var_auto_count = closure[0];
  Object *var_nparams = closure[1];
  Object *var_inbody = closure[2];
  Object self = *closure[3];
  Object *var_inname = alloc_var();
  *var_inname = undefined;
// Begin line 321
  setline(321);
  if (strlit589 == NULL) {
    strlit589 = alloc_String("__matchvar");
  }
// compilenode returning strlit589
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult591 = callmethod(strlit589, "++", 1, params);
// compilenode returning opresult591
  Object bool592 = alloc_Boolean(0);
// compilenode returning bool592
// compilenode returning module_ast
  params[0] = opresult591;
  params[1] = bool592;
  Object call593 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call593
  var_inname = alloc_var();
  *var_inname = call593;
  if (call593 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 323
  setline(323);
// Begin line 322
  setline(322);
// compilenode returning *var_auto_count
  Object num594 = alloc_Float64(1.0);
// compilenode returning num594
  params[0] = num594;
  Object sum596 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum596
  *var_auto_count = sum596;
  if (sum596 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 323
  setline(323);
// compilenode returning *var_inname
// compilenode returning *var_nparams
  params[0] = *var_inname;
  Object call598 = callmethod(*var_nparams, "push",
    1, params);
// compilenode returning call598
// Begin line 326
  setline(326);
  Object array599 = alloc_List();
// Begin line 325
  setline(325);
  if (strlit600 == NULL) {
    strlit600 = alloc_String("apply");
  }
// compilenode returning strlit600
// Begin line 326
  setline(326);
// Begin line 325
  setline(325);
  Object array601 = alloc_List();
// compilenode returning *var_p
  params[0] = *var_p;
  callmethod(array601, "push", 1, params);
// compilenode returning array601
// Begin line 326
  setline(326);
// compilenode returning *var_inbody
// Begin line 325
  setline(325);
// compilenode returning module_ast
  params[0] = array601;
  params[1] = *var_inbody;
  Object call602 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call602
// Begin line 326
  setline(326);
// compilenode returning self
  params[0] = call602;
  Object call603 = callmethod(self, "rewritematchblock",
    1, params);
// compilenode returning call603
// Begin line 325
  setline(325);
// compilenode returning module_ast
  params[0] = strlit600;
  params[1] = call603;
  Object call604 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call604
// Begin line 326
  setline(326);
  Object array605 = alloc_List();
// compilenode returning *var_inname
  params[0] = *var_inname;
  callmethod(array605, "push", 1, params);
// compilenode returning array605
// Begin line 324
  setline(324);
// compilenode returning module_ast
  params[0] = call604;
  params[1] = array605;
  Object call606 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call606
  params[0] = call606;
  callmethod(array599, "push", 1, params);
// compilenode returning array599
  *var_inbody = array599;
  if (array599 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_rewritematchblock464(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[2];
  Object *var_auto_count = closure[0];
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_inbody = alloc_var();
  *var_inbody = undefined;
  Object *var_pat = alloc_var();
  *var_pat = undefined;
  Object *var_tmpp = alloc_var();
  *var_tmpp = undefined;
  Object *var_nparams = alloc_var();
  *var_nparams = undefined;
  Object *var_newname = alloc_var();
  *var_newname = undefined;
  Object *var_fst = alloc_var();
  *var_fst = undefined;
// Begin line 269
  setline(269);
// Begin line 1577
  setline(1577);
// Begin line 268
  setline(268);
// compilenode returning *var_o
  Object call465 = callmethod(*var_o, "params",
    0, params);
// compilenode returning call465
// compilenode returning call465
  var_params = alloc_var();
  *var_params = call465;
  if (call465 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 271
  setline(271);
// Begin line 272
  setline(272);
// Begin line 1577
  setline(1577);
// Begin line 269
  setline(269);
// compilenode returning *var_params
  Object call467 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call467
// compilenode returning call467
  Object num468 = alloc_Float64(1.0);
// compilenode returning num468
  params[0] = num468;
  Object opresult470 = callmethod(call467, "/=", 1, params);
// compilenode returning opresult470
  Object if466;
  if (istrue(opresult470)) {
// Begin line 271
  setline(271);
// Begin line 270
  setline(270);
// compilenode returning *var_o
  return *var_o;
// compilenode returning undefined
    if466 = undefined;
  } else {
  }
// compilenode returning if466
// Begin line 273
  setline(273);
// Begin line 1577
  setline(1577);
// Begin line 272
  setline(272);
// compilenode returning *var_o
  Object call471 = callmethod(*var_o, "body",
    0, params);
// compilenode returning call471
// compilenode returning call471
  var_body = alloc_var();
  *var_body = call471;
  if (call471 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 274
  setline(274);
// Begin line 273
  setline(273);
// compilenode returning *var_body
  var_inbody = alloc_var();
  *var_inbody = *var_body;
  if (*var_body == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 275
  setline(275);
  var_pat = alloc_var();
  *var_pat = undefined;
// compilenode returning nothing
// Begin line 276
  setline(276);
  var_tmpp = alloc_var();
  *var_tmpp = undefined;
// compilenode returning nothing
// Begin line 277
  setline(277);
  var_nparams = alloc_var();
  *var_nparams = undefined;
// compilenode returning nothing
// Begin line 278
  setline(278);
// Begin line 277
  setline(277);
  if (strlit472 == NULL) {
    strlit472 = alloc_String("__matchvar");
  }
// compilenode returning strlit472
// compilenode returning *var_auto_count
  params[0] = *var_auto_count;
  Object opresult474 = callmethod(strlit472, "++", 1, params);
// compilenode returning opresult474
// Begin line 278
  setline(278);
  Object bool475 = alloc_Boolean(0);
// compilenode returning bool475
// Begin line 277
  setline(277);
// compilenode returning module_ast
  params[0] = opresult474;
  params[1] = bool475;
  Object call476 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call476
  var_newname = alloc_var();
  *var_newname = call476;
  if (call476 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 280
  setline(280);
// Begin line 279
  setline(279);
// compilenode returning *var_auto_count
  Object num477 = alloc_Float64(1.0);
// compilenode returning num477
  params[0] = num477;
  Object sum479 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum479
  *var_auto_count = sum479;
  if (sum479 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 281
  setline(281);
// Begin line 1577
  setline(1577);
// Begin line 280
  setline(280);
// compilenode returning *var_params
  Object call481 = callmethod(*var_params, "first",
    0, params);
// compilenode returning call481
// compilenode returning call481
  var_fst = alloc_var();
  *var_fst = call481;
  if (call481 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 345
  setline(345);
// Begin line 349
  setline(349);
// Begin line 1577
  setline(1577);
// Begin line 281
  setline(281);
// compilenode returning *var_fst
  Object call483 = callmethod(*var_fst, "kind",
    0, params);
// compilenode returning call483
// compilenode returning call483
  if (strlit484 == NULL) {
    strlit484 = alloc_String("call");
  }
// compilenode returning strlit484
  params[0] = strlit484;
  Object opresult486 = callmethod(call483, "==", 1, params);
// compilenode returning opresult486
  Object if482;
  if (istrue(opresult486)) {
// Begin line 283
  setline(283);
// Begin line 282
  setline(282);
// compilenode returning *var_fst
  *var_pat = *var_fst;
  if (*var_fst == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 284
  setline(284);
// Begin line 283
  setline(283);
// compilenode returning *var_fst
  *var_tmpp = *var_fst;
  if (*var_fst == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 284
  setline(284);
  Object array489 = alloc_List();
// compilenode returning *var_newname
  params[0] = *var_newname;
  callmethod(array489, "push", 1, params);
// compilenode returning array489
  *var_params = array489;
  if (array489 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 286
  setline(286);
  Object array491 = alloc_List();
// compilenode returning array491
  *var_nparams = array491;
  if (array491 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 292
  setline(292);
// Begin line 294
  setline(294);
// Begin line 1577
  setline(1577);
// Begin line 286
  setline(286);
// compilenode returning *var_pat
  Object call494 = callmethod(*var_pat, "with",
    0, params);
// compilenode returning call494
// compilenode returning call494
// Begin line 292
  setline(292);
// Begin line 1577
  setline(1577);
  Object obj496 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj496, self, 0);
  addmethod2(obj496, "outer", &reader_parser_outer_497);
  adddatum2(obj496, self, 0);
  block_savedest(obj496);
  Object **closure498 = createclosure(4);
  addtoclosure(closure498, var_auto_count);
  addtoclosure(closure498, var_nparams);
  addtoclosure(closure498, var_inbody);
  Object *selfpp518 = alloc_var();
  *selfpp518 = self;
  addtoclosure(closure498, selfpp518);
  struct UserObject *uo498 = (struct UserObject*)obj496;
  uo498->data[1] = (Object)closure498;
  addmethod2(obj496, "apply", &meth_parser_apply498);
  set_type(obj496, 0);
// compilenode returning obj496
  setclassname(obj496, "Block<parser:495>");
// compilenode returning obj496
  params[0] = call494;
  Object iter493 = callmethod(call494, "iter", 1, params);
  while(1) {
    Object cond493 = callmethod(iter493, "havemore", 0, NULL);
    if (!istrue(cond493)) break;
    params[0] = callmethod(iter493, "next", 0, NULL);
    callmethod(obj496, "apply", 1, params);
  }
// compilenode returning call494
// Begin line 295
  setline(295);
// Begin line 1577
  setline(1577);
// Begin line 294
  setline(294);
// compilenode returning *var_pat
  Object call519 = callmethod(*var_pat, "value",
    0, params);
// compilenode returning call519
// compilenode returning call519
  *var_pat = call519;
  if (call519 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 301
  setline(301);
  Object array521 = alloc_List();
// Begin line 297
  setline(297);
// Begin line 296
  setline(296);
  if (strlit522 == NULL) {
    strlit522 = alloc_String("matchmatchesBindingelse");
  }
// compilenode returning strlit522
// Begin line 297
  setline(297);
// compilenode returning *var_newname
// Begin line 295
  setline(295);
// compilenode returning module_ast
  params[0] = strlit522;
  params[1] = *var_newname;
  Object call523 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call523
// Begin line 301
  setline(301);
  Object array524 = alloc_List();
// Begin line 298
  setline(298);
// compilenode returning *var_pat
  params[0] = *var_pat;
  callmethod(array524, "push", 1, params);
// compilenode returning *var_nparams
// compilenode returning *var_inbody
// compilenode returning module_ast
  params[0] = *var_nparams;
  params[1] = *var_inbody;
  Object call525 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call525
  params[0] = call525;
  callmethod(array524, "push", 1, params);
// Begin line 301
  setline(301);
// Begin line 299
  setline(299);
  Object array526 = alloc_List();
// compilenode returning array526
// Begin line 301
  setline(301);
  Object array527 = alloc_List();
// Begin line 300
  setline(300);
  if (strlit528 == NULL) {
    strlit528 = alloc_String("print");
  }
// compilenode returning strlit528
  Object bool529 = alloc_Boolean(0);
// compilenode returning bool529
// compilenode returning module_ast
  params[0] = strlit528;
  params[1] = bool529;
  Object call530 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call530
// Begin line 301
  setline(301);
  Object array531 = alloc_List();
  if (strlit532 == NULL) {
    strlit532 = alloc_String("Pattern match failed.");
  }
// compilenode returning strlit532
// compilenode returning module_ast
  params[0] = strlit532;
  Object call533 = callmethod(module_ast, "aststring",
    1, params);
// compilenode returning call533
  params[0] = call533;
  callmethod(array531, "push", 1, params);
// compilenode returning array531
// Begin line 300
  setline(300);
// compilenode returning module_ast
  params[0] = call530;
  params[1] = array531;
  Object call534 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call534
  params[0] = call534;
  callmethod(array527, "push", 1, params);
// compilenode returning array527
// Begin line 299
  setline(299);
// compilenode returning module_ast
  params[0] = array526;
  params[1] = array527;
  Object call535 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call535
  params[0] = call535;
  callmethod(array524, "push", 1, params);
// compilenode returning array524
// Begin line 295
  setline(295);
// compilenode returning module_ast
  params[0] = call523;
  params[1] = array524;
  Object call536 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call536
  params[0] = call536;
  callmethod(array521, "push", 1, params);
// compilenode returning array521
  *var_body = array521;
  if (array521 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if482 = nothing;
  } else {
// Begin line 345
  setline(345);
// Begin line 315
  setline(315);
// Begin line 1577
  setline(1577);
// Begin line 303
  setline(303);
// compilenode returning *var_fst
  Object call539 = callmethod(*var_fst, "kind",
    0, params);
// compilenode returning call539
// compilenode returning call539
  if (strlit540 == NULL) {
    strlit540 = alloc_String("identifier");
  }
// compilenode returning strlit540
  params[0] = strlit540;
  Object opresult542 = callmethod(call539, "/=", 1, params);
// compilenode returning opresult542
  Object if538;
  if (istrue(opresult542)) {
// Begin line 305
  setline(305);
// Begin line 304
  setline(304);
// compilenode returning *var_auto_count
  Object num543 = alloc_Float64(1.0);
// compilenode returning num543
  params[0] = num543;
  Object sum545 = callmethod(*var_auto_count, "+", 1, params);
// compilenode returning sum545
  *var_auto_count = sum545;
  if (sum545 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 306
  setline(306);
// Begin line 305
  setline(305);
// compilenode returning *var_fst
  *var_pat = *var_fst;
  if (*var_fst == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 306
  setline(306);
  Object array548 = alloc_List();
// compilenode returning *var_newname
  params[0] = *var_newname;
  callmethod(array548, "push", 1, params);
// compilenode returning array548
  *var_params = array548;
  if (array548 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 313
  setline(313);
  Object array550 = alloc_List();
// Begin line 309
  setline(309);
// Begin line 308
  setline(308);
  if (strlit551 == NULL) {
    strlit551 = alloc_String("matchmatchesBindingelse");
  }
// compilenode returning strlit551
// Begin line 309
  setline(309);
// compilenode returning *var_newname
// Begin line 307
  setline(307);
// compilenode returning module_ast
  params[0] = strlit551;
  params[1] = *var_newname;
  Object call552 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call552
// Begin line 313
  setline(313);
  Object array553 = alloc_List();
// Begin line 310
  setline(310);
// compilenode returning *var_pat
  params[0] = *var_pat;
  callmethod(array553, "push", 1, params);
  Object array554 = alloc_List();
// compilenode returning array554
// compilenode returning *var_inbody
// compilenode returning module_ast
  params[0] = array554;
  params[1] = *var_inbody;
  Object call555 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call555
  params[0] = call555;
  callmethod(array553, "push", 1, params);
// Begin line 313
  setline(313);
// Begin line 311
  setline(311);
  Object array556 = alloc_List();
// compilenode returning array556
// Begin line 313
  setline(313);
  Object array557 = alloc_List();
// Begin line 312
  setline(312);
  if (strlit558 == NULL) {
    strlit558 = alloc_String("print");
  }
// compilenode returning strlit558
  Object bool559 = alloc_Boolean(0);
// compilenode returning bool559
// compilenode returning module_ast
  params[0] = strlit558;
  params[1] = bool559;
  Object call560 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call560
// Begin line 313
  setline(313);
  Object array561 = alloc_List();
  if (strlit562 == NULL) {
    strlit562 = alloc_String("Pattern match failed.");
  }
// compilenode returning strlit562
// compilenode returning module_ast
  params[0] = strlit562;
  Object call563 = callmethod(module_ast, "aststring",
    1, params);
// compilenode returning call563
  params[0] = call563;
  callmethod(array561, "push", 1, params);
// compilenode returning array561
// Begin line 312
  setline(312);
// compilenode returning module_ast
  params[0] = call560;
  params[1] = array561;
  Object call564 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call564
  params[0] = call564;
  callmethod(array557, "push", 1, params);
// compilenode returning array557
// Begin line 311
  setline(311);
// compilenode returning module_ast
  params[0] = array556;
  params[1] = array557;
  Object call565 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call565
  params[0] = call565;
  callmethod(array553, "push", 1, params);
// compilenode returning array553
// Begin line 307
  setline(307);
// compilenode returning module_ast
  params[0] = call552;
  params[1] = array553;
  Object call566 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call566
  params[0] = call566;
  callmethod(array550, "push", 1, params);
// compilenode returning array550
  *var_body = array550;
  if (array550 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if538 = nothing;
  } else {
// Begin line 345
  setline(345);
// Begin line 349
  setline(349);
// Begin line 1577
  setline(1577);
// Begin line 315
  setline(315);
// compilenode returning *var_fst
  Object call569 = callmethod(*var_fst, "dtype",
    0, params);
// compilenode returning call569
// compilenode returning call569
  Object bool570 = alloc_Boolean(0);
// compilenode returning bool570
  params[0] = bool570;
  Object opresult572 = callmethod(call569, "/=", 1, params);
// compilenode returning opresult572
  Object if568;
  if (istrue(opresult572)) {
// Begin line 317
  setline(317);
// Begin line 1577
  setline(1577);
// Begin line 316
  setline(316);
// compilenode returning *var_fst
  Object call573 = callmethod(*var_fst, "dtype",
    0, params);
// compilenode returning call573
// compilenode returning call573
  *var_pat = call573;
  if (call573 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 318
  setline(318);
// Begin line 317
  setline(317);
// compilenode returning *var_fst
  *var_tmpp = *var_fst;
  if (*var_fst == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 345
  setline(345);
// Begin line 348
  setline(348);
// Begin line 1577
  setline(1577);
// Begin line 318
  setline(318);
// compilenode returning *var_pat
  Object call577 = callmethod(*var_pat, "kind",
    0, params);
// compilenode returning call577
// compilenode returning call577
  if (strlit578 == NULL) {
    strlit578 = alloc_String("call");
  }
// compilenode returning strlit578
  params[0] = strlit578;
  Object opresult580 = callmethod(call577, "==", 1, params);
// compilenode returning opresult580
  Object if576;
  if (istrue(opresult580)) {
// Begin line 320
  setline(320);
  Object array581 = alloc_List();
// compilenode returning array581
  *var_nparams = array581;
  if (array581 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 326
  setline(326);
// Begin line 328
  setline(328);
// Begin line 1577
  setline(1577);
// Begin line 320
  setline(320);
// compilenode returning *var_pat
  Object call584 = callmethod(*var_pat, "with",
    0, params);
// compilenode returning call584
// compilenode returning call584
// Begin line 326
  setline(326);
// Begin line 1577
  setline(1577);
  Object obj586 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj586, self, 0);
  addmethod2(obj586, "outer", &reader_parser_outer_587);
  adddatum2(obj586, self, 0);
  block_savedest(obj586);
  Object **closure588 = createclosure(4);
  addtoclosure(closure588, var_auto_count);
  addtoclosure(closure588, var_nparams);
  addtoclosure(closure588, var_inbody);
  Object *selfpp608 = alloc_var();
  *selfpp608 = self;
  addtoclosure(closure588, selfpp608);
  struct UserObject *uo588 = (struct UserObject*)obj586;
  uo588->data[1] = (Object)closure588;
  addmethod2(obj586, "apply", &meth_parser_apply588);
  set_type(obj586, 0);
// compilenode returning obj586
  setclassname(obj586, "Block<parser:585>");
// compilenode returning obj586
  params[0] = call584;
  Object iter583 = callmethod(call584, "iter", 1, params);
  while(1) {
    Object cond583 = callmethod(iter583, "havemore", 0, NULL);
    if (!istrue(cond583)) break;
    params[0] = callmethod(iter583, "next", 0, NULL);
    callmethod(obj586, "apply", 1, params);
  }
// compilenode returning call584
// Begin line 329
  setline(329);
// Begin line 1577
  setline(1577);
// Begin line 328
  setline(328);
// compilenode returning *var_pat
  Object call609 = callmethod(*var_pat, "value",
    0, params);
// compilenode returning call609
// compilenode returning call609
  *var_pat = call609;
  if (call609 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 335
  setline(335);
  Object array611 = alloc_List();
// Begin line 331
  setline(331);
// Begin line 330
  setline(330);
  if (strlit612 == NULL) {
    strlit612 = alloc_String("matchmatchesBindingelse");
  }
// compilenode returning strlit612
// Begin line 331
  setline(331);
// compilenode returning *var_tmpp
// Begin line 329
  setline(329);
// compilenode returning module_ast
  params[0] = strlit612;
  params[1] = *var_tmpp;
  Object call613 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call613
// Begin line 335
  setline(335);
  Object array614 = alloc_List();
// Begin line 332
  setline(332);
// compilenode returning *var_pat
  params[0] = *var_pat;
  callmethod(array614, "push", 1, params);
// compilenode returning *var_nparams
// compilenode returning *var_inbody
// compilenode returning module_ast
  params[0] = *var_nparams;
  params[1] = *var_inbody;
  Object call615 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call615
  params[0] = call615;
  callmethod(array614, "push", 1, params);
// Begin line 335
  setline(335);
// Begin line 333
  setline(333);
  Object array616 = alloc_List();
// compilenode returning *var_tmpp
  params[0] = *var_tmpp;
  callmethod(array616, "push", 1, params);
// compilenode returning array616
// Begin line 335
  setline(335);
  Object array617 = alloc_List();
// Begin line 334
  setline(334);
  if (strlit618 == NULL) {
    strlit618 = alloc_String("print");
  }
// compilenode returning strlit618
  Object bool619 = alloc_Boolean(0);
// compilenode returning bool619
// compilenode returning module_ast
  params[0] = strlit618;
  params[1] = bool619;
  Object call620 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call620
// Begin line 335
  setline(335);
  Object array621 = alloc_List();
  if (strlit622 == NULL) {
    strlit622 = alloc_String("Pattern match failed.");
  }
// compilenode returning strlit622
// compilenode returning module_ast
  params[0] = strlit622;
  Object call623 = callmethod(module_ast, "aststring",
    1, params);
// compilenode returning call623
  params[0] = call623;
  callmethod(array621, "push", 1, params);
// compilenode returning array621
// Begin line 334
  setline(334);
// compilenode returning module_ast
  params[0] = call620;
  params[1] = array621;
  Object call624 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call624
  params[0] = call624;
  callmethod(array617, "push", 1, params);
// compilenode returning array617
// Begin line 333
  setline(333);
// compilenode returning module_ast
  params[0] = array616;
  params[1] = array617;
  Object call625 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call625
  params[0] = call625;
  callmethod(array614, "push", 1, params);
// compilenode returning array614
// Begin line 329
  setline(329);
// compilenode returning module_ast
  params[0] = call613;
  params[1] = array614;
  Object call626 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call626
  params[0] = call626;
  callmethod(array611, "push", 1, params);
// compilenode returning array611
  *var_body = array611;
  if (array611 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if576 = nothing;
  } else {
// Begin line 338
  setline(338);
  Object array628 = alloc_List();
// compilenode returning *var_newname
  params[0] = *var_newname;
  callmethod(array628, "push", 1, params);
// compilenode returning array628
  *var_params = array628;
  if (array628 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 345
  setline(345);
  Object array630 = alloc_List();
// Begin line 341
  setline(341);
// Begin line 340
  setline(340);
  if (strlit631 == NULL) {
    strlit631 = alloc_String("matchmatchesBindingelse");
  }
// compilenode returning strlit631
// Begin line 341
  setline(341);
// compilenode returning *var_newname
// Begin line 339
  setline(339);
// compilenode returning module_ast
  params[0] = strlit631;
  params[1] = *var_newname;
  Object call632 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call632
// Begin line 345
  setline(345);
  Object array633 = alloc_List();
// Begin line 342
  setline(342);
// compilenode returning *var_pat
  params[0] = *var_pat;
  callmethod(array633, "push", 1, params);
  Object array634 = alloc_List();
// compilenode returning *var_tmpp
  params[0] = *var_tmpp;
  callmethod(array634, "push", 1, params);
// compilenode returning array634
// compilenode returning *var_inbody
// compilenode returning module_ast
  params[0] = array634;
  params[1] = *var_inbody;
  Object call635 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call635
  params[0] = call635;
  callmethod(array633, "push", 1, params);
// Begin line 345
  setline(345);
// Begin line 343
  setline(343);
  Object array636 = alloc_List();
// compilenode returning *var_tmpp
  params[0] = *var_tmpp;
  callmethod(array636, "push", 1, params);
// compilenode returning array636
// Begin line 345
  setline(345);
  Object array637 = alloc_List();
// Begin line 344
  setline(344);
  if (strlit638 == NULL) {
    strlit638 = alloc_String("print");
  }
// compilenode returning strlit638
  Object bool639 = alloc_Boolean(0);
// compilenode returning bool639
// compilenode returning module_ast
  params[0] = strlit638;
  params[1] = bool639;
  Object call640 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call640
// Begin line 345
  setline(345);
  Object array641 = alloc_List();
  if (strlit642 == NULL) {
    strlit642 = alloc_String("Pattern match failed.");
  }
// compilenode returning strlit642
// compilenode returning module_ast
  params[0] = strlit642;
  Object call643 = callmethod(module_ast, "aststring",
    1, params);
// compilenode returning call643
  params[0] = call643;
  callmethod(array641, "push", 1, params);
// compilenode returning array641
// Begin line 344
  setline(344);
// compilenode returning module_ast
  params[0] = call640;
  params[1] = array641;
  Object call644 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call644
  params[0] = call644;
  callmethod(array637, "push", 1, params);
// compilenode returning array637
// Begin line 343
  setline(343);
// compilenode returning module_ast
  params[0] = array636;
  params[1] = array637;
  Object call645 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call645
  params[0] = call645;
  callmethod(array633, "push", 1, params);
// compilenode returning array633
// Begin line 339
  setline(339);
// compilenode returning module_ast
  params[0] = call632;
  params[1] = array633;
  Object call646 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call646
  params[0] = call646;
  callmethod(array630, "push", 1, params);
// compilenode returning array630
  *var_body = array630;
  if (array630 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if576 = nothing;
  }
// compilenode returning if576
    if568 = if576;
  } else {
  }
// compilenode returning if568
    if538 = if568;
  }
// compilenode returning if538
    if482 = if538;
  }
// compilenode returning if482
// Begin line 349
  setline(349);
// compilenode returning *var_params
// compilenode returning *var_body
// compilenode returning module_ast
  params[0] = *var_params;
  params[1] = *var_body;
  Object call648 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call648
  *var_o = call648;
  if (call648 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 351
  setline(351);
// Begin line 350
  setline(350);
// compilenode returning *var_o
  return *var_o;
// compilenode returning undefined
  return undefined;
}
Object meth_parser_doif650(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object params[3];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
  Object *var_statementIndent = closure[2];
  Object *var_lastToken = closure[3];
  Object *var_minIndentLevel = closure[4];
  Object *var_statementToken = closure[5];
// Begin line 358
  setline(358);
  if (strlit652 == NULL) {
    strlit652 = alloc_String("identifier");
  }
// compilenode returning strlit652
// Begin line 459
  setline(459);
// compilenode returning self
  params[0] = strlit652;
  Object call653 = callmethod(self, "accept",
    1, params);
// compilenode returning call653
// Begin line 358
  setline(358);
// Begin line 1577
  setline(1577);
// Begin line 358
  setline(358);
// compilenode returning *var_sym
  Object call654 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call654
// compilenode returning call654
  if (strlit655 == NULL) {
    strlit655 = alloc_String("if");
  }
// compilenode returning strlit655
  params[0] = strlit655;
  Object opresult657 = callmethod(call654, "==", 1, params);
// compilenode returning opresult657
  params[0] = opresult657;
  Object opresult659 = callmethod(call653, "&", 1, params);
// compilenode returning opresult659
  Object if651;
  if (istrue(opresult659)) {
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_elseblock = alloc_var();
  *var_elseblock = undefined;
  Object *var_curelse = alloc_var();
  *var_curelse = undefined;
  Object *var_v = alloc_var();
  *var_v = undefined;
  Object *var_localMin = alloc_var();
  *var_localMin = undefined;
  Object *var_minInd = alloc_var();
  *var_minInd = undefined;
// Begin line 359
  setline(359);
// compilenode returning self
  Object call660 = callmethod(self, "next",
    0, params);
// compilenode returning call660
// Begin line 360
  setline(360);
// compilenode returning self
  Object call661 = callmethod(self, "expression",
    0, params);
// compilenode returning call661
// Begin line 362
  setline(362);
// Begin line 1577
  setline(1577);
// Begin line 361
  setline(361);
// compilenode returning *var_values
  Object call662 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call662
// compilenode returning call662
  var_cond = alloc_var();
  *var_cond = call662;
  if (call662 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 370
  setline(370);
  Object array663 = alloc_List();
// compilenode returning array663
  var_body = alloc_var();
  *var_body = array663;
  if (array663 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 371
  setline(371);
  Object array664 = alloc_List();
// compilenode returning array664
  var_elseblock = alloc_var();
  *var_elseblock = array664;
  if (array664 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 372
  setline(372);
// Begin line 371
  setline(371);
// compilenode returning *var_elseblock
  var_curelse = alloc_var();
  *var_curelse = *var_elseblock;
  if (*var_elseblock == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 373
  setline(373);
  var_v = alloc_var();
  *var_v = undefined;
// compilenode returning nothing
// Begin line 374
  setline(374);
  var_localMin = alloc_var();
  *var_localMin = undefined;
// compilenode returning nothing
// Begin line 375
  setline(375);
// Begin line 374
  setline(374);
// compilenode returning *var_statementIndent
  Object num665 = alloc_Float64(1.0);
// compilenode returning num665
  params[0] = num665;
  Object sum667 = callmethod(*var_statementIndent, "+", 1, params);
// compilenode returning sum667
  var_minInd = alloc_var();
  *var_minInd = sum667;
  if (sum667 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 456
  setline(456);
// Begin line 375
  setline(375);
  if (strlit669 == NULL) {
    strlit669 = alloc_String("identifier");
  }
// compilenode returning strlit669
// Begin line 458
  setline(458);
// compilenode returning self
  params[0] = strlit669;
  Object call670 = callmethod(self, "accept",
    1, params);
// compilenode returning call670
// Begin line 375
  setline(375);
// Begin line 1577
  setline(1577);
// Begin line 375
  setline(375);
// compilenode returning *var_sym
  Object call671 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call671
// compilenode returning call671
  if (strlit672 == NULL) {
    strlit672 = alloc_String("then");
  }
// compilenode returning strlit672
  params[0] = strlit672;
  Object opresult674 = callmethod(call671, "==", 1, params);
// compilenode returning opresult674
  params[0] = opresult674;
  Object opresult676 = callmethod(call670, "&", 1, params);
// compilenode returning opresult676
  Object if668;
  if (istrue(opresult676)) {
  Object *var_econd = alloc_var();
  *var_econd = undefined;
  Object *var_eif = alloc_var();
  *var_eif = undefined;
  Object *var_newelse = alloc_var();
  *var_newelse = undefined;
  Object *var_ebody = alloc_var();
  *var_ebody = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 376
  setline(376);
// compilenode returning self
  Object call677 = callmethod(self, "next",
    0, params);
// compilenode returning call677
// Begin line 389
  setline(389);
// Begin line 377
  setline(377);
  if (strlit679 == NULL) {
    strlit679 = alloc_String("lbrace");
  }
// compilenode returning strlit679
// Begin line 391
  setline(391);
// compilenode returning self
  params[0] = strlit679;
  Object call680 = callmethod(self, "accept",
    1, params);
// compilenode returning call680
  Object if678;
  if (istrue(call680)) {
// Begin line 378
  setline(378);
// compilenode returning self
  Object call681 = callmethod(self, "next",
    0, params);
// compilenode returning call681
// Begin line 383
  setline(383);
// Begin line 384
  setline(384);
// Begin line 1577
  setline(1577);
// Begin line 379
  setline(379);
// compilenode returning *var_sym
  Object call683 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call683
// compilenode returning call683
// Begin line 384
  setline(384);
// Begin line 1577
  setline(1577);
// Begin line 379
  setline(379);
// compilenode returning *var_lastToken
  Object call684 = callmethod(*var_lastToken, "line",
    0, params);
// compilenode returning call684
// compilenode returning call684
  params[0] = call684;
  Object opresult686 = callmethod(call683, "==", 1, params);
// compilenode returning opresult686
  Object if682;
  if (istrue(opresult686)) {
// Begin line 381
  setline(381);
// Begin line 1577
  setline(1577);
// Begin line 380
  setline(380);
// compilenode returning *var_sym
  Object call687 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call687
// compilenode returning call687
  Object num688 = alloc_Float64(1.0);
// compilenode returning num688
  params[0] = num688;
  Object diff690 = callmethod(call687, "-", 1, params);
// compilenode returning diff690
  *var_minIndentLevel = diff690;
  if (diff690 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if682 = nothing;
  } else {
// Begin line 383
  setline(383);
// Begin line 382
  setline(382);
// compilenode returning *var_minInd
  *var_minIndentLevel = *var_minInd;
  if (*var_minInd == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if682 = nothing;
  }
// compilenode returning if682
// Begin line 387
  setline(387);
  Object while693;
  while (1) {
// Begin line 384
  setline(384);
// Begin line 1577
  setline(1577);
// Begin line 384
  setline(384);
  if (strlit694 == NULL) {
    strlit694 = alloc_String("rbrace");
  }
// compilenode returning strlit694
// Begin line 389
  setline(389);
// compilenode returning self
  params[0] = strlit694;
  Object call695 = callmethod(self, "accept",
    1, params);
// compilenode returning call695
  Object call696 = callmethod(call695, "not",
    0, params);
// compilenode returning call696
// compilenode returning call696
    while693 = call696;
    if (!istrue(call696)) break;
// Begin line 385
  setline(385);
// compilenode returning self
  Object call697 = callmethod(self, "statement",
    0, params);
// compilenode returning call697
// Begin line 387
  setline(387);
// Begin line 1577
  setline(1577);
// Begin line 386
  setline(386);
// compilenode returning *var_values
  Object call698 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call698
// compilenode returning call698
  *var_v = call698;
  if (call698 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 387
  setline(387);
// compilenode returning *var_v
// compilenode returning *var_body
  params[0] = *var_v;
  Object call700 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call700
  }
// compilenode returning while693
// Begin line 389
  setline(389);
// compilenode returning self
  Object call701 = callmethod(self, "next",
    0, params);
// compilenode returning call701
    if678 = call701;
  } else {
  }
// compilenode returning if678
// Begin line 392
  setline(392);
  var_econd = alloc_var();
  *var_econd = undefined;
// compilenode returning nothing
// Begin line 393
  setline(393);
  var_eif = alloc_var();
  *var_eif = undefined;
// compilenode returning nothing
// Begin line 394
  setline(394);
  var_newelse = alloc_var();
  *var_newelse = undefined;
// compilenode returning nothing
// Begin line 395
  setline(395);
  var_ebody = alloc_var();
  *var_ebody = undefined;
// compilenode returning nothing
// Begin line 431
  setline(431);
  Object while702;
  while (1) {
// Begin line 395
  setline(395);
  if (strlit703 == NULL) {
    strlit703 = alloc_String("identifier");
  }
// compilenode returning strlit703
// Begin line 432
  setline(432);
// compilenode returning self
  params[0] = strlit703;
  Object call704 = callmethod(self, "accept",
    1, params);
// compilenode returning call704
// Begin line 395
  setline(395);
// Begin line 1577
  setline(1577);
// Begin line 395
  setline(395);
// compilenode returning *var_sym
  Object call705 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call705
// compilenode returning call705
  if (strlit706 == NULL) {
    strlit706 = alloc_String("elseif");
  }
// compilenode returning strlit706
  params[0] = strlit706;
  Object opresult708 = callmethod(call705, "==", 1, params);
// compilenode returning opresult708
  params[0] = opresult708;
  Object opresult710 = callmethod(call704, "&", 1, params);
// compilenode returning opresult710
    while702 = opresult710;
    if (!istrue(opresult710)) break;
// Begin line 399
  setline(399);
// Begin line 398
  setline(398);
// compilenode returning *var_sym
  *var_statementToken = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 399
  setline(399);
// compilenode returning self
  Object call712 = callmethod(self, "next",
    0, params);
// compilenode returning call712
// Begin line 400
  setline(400);
// compilenode returning self
  Object call713 = callmethod(self, "expression",
    0, params);
// compilenode returning call713
// Begin line 402
  setline(402);
// Begin line 1577
  setline(1577);
// Begin line 401
  setline(401);
// compilenode returning *var_values
  Object call714 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call714
// compilenode returning call714
  *var_econd = call714;
  if (call714 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 404
  setline(404);
// Begin line 402
  setline(402);
// Begin line 1577
  setline(1577);
// Begin line 402
  setline(402);
  if (strlit717 == NULL) {
    strlit717 = alloc_String("identifier");
  }
// compilenode returning strlit717
// Begin line 406
  setline(406);
// compilenode returning self
  params[0] = strlit717;
  Object call718 = callmethod(self, "accept",
    1, params);
// compilenode returning call718
// Begin line 402
  setline(402);
// Begin line 1577
  setline(1577);
// Begin line 403
  setline(403);
// compilenode returning *var_sym
  Object call719 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call719
// compilenode returning call719
  if (strlit720 == NULL) {
    strlit720 = alloc_String("then");
  }
// compilenode returning strlit720
  params[0] = strlit720;
  Object opresult722 = callmethod(call719, "==", 1, params);
// compilenode returning opresult722
  params[0] = opresult722;
  Object opresult724 = callmethod(call718, "&", 1, params);
// compilenode returning opresult724
  Object call725 = callmethod(opresult724, "not",
    0, params);
// compilenode returning call725
// compilenode returning call725
  Object if716;
  if (istrue(call725)) {
// Begin line 404
  setline(404);
  if (strlit726 == NULL) {
    strlit726 = alloc_String("elseif with no then.");
  }
// compilenode returning strlit726
// compilenode returning module_util
  params[0] = strlit726;
  Object call727 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call727
    if716 = call727;
  } else {
  }
// compilenode returning if716
// Begin line 406
  setline(406);
// compilenode returning self
  Object call728 = callmethod(self, "next",
    0, params);
// compilenode returning call728
// Begin line 408
  setline(408);
  Object array729 = alloc_List();
// compilenode returning array729
  *var_ebody = array729;
  if (array729 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 409
  setline(409);
// Begin line 408
  setline(408);
// Begin line 1577
  setline(1577);
// Begin line 408
  setline(408);
  if (strlit732 == NULL) {
    strlit732 = alloc_String("lbrace");
  }
// compilenode returning strlit732
// Begin line 411
  setline(411);
// compilenode returning self
  params[0] = strlit732;
  Object call733 = callmethod(self, "accept",
    1, params);
// compilenode returning call733
  Object call734 = callmethod(call733, "not",
    0, params);
// compilenode returning call734
// compilenode returning call734
  Object if731;
  if (istrue(call734)) {
// Begin line 409
  setline(409);
  if (strlit735 == NULL) {
    strlit735 = alloc_String("expected {.");
  }
// compilenode returning strlit735
// compilenode returning module_util
  params[0] = strlit735;
  Object call736 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call736
    if731 = call736;
  } else {
  }
// compilenode returning if731
// Begin line 411
  setline(411);
// compilenode returning self
  Object call737 = callmethod(self, "next",
    0, params);
// compilenode returning call737
// Begin line 416
  setline(416);
// Begin line 417
  setline(417);
// Begin line 1577
  setline(1577);
// Begin line 412
  setline(412);
// compilenode returning *var_sym
  Object call739 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call739
// compilenode returning call739
// Begin line 417
  setline(417);
// Begin line 1577
  setline(1577);
// Begin line 412
  setline(412);
// compilenode returning *var_lastToken
  Object call740 = callmethod(*var_lastToken, "line",
    0, params);
// compilenode returning call740
// compilenode returning call740
  params[0] = call740;
  Object opresult742 = callmethod(call739, "==", 1, params);
// compilenode returning opresult742
  Object if738;
  if (istrue(opresult742)) {
// Begin line 414
  setline(414);
// Begin line 1577
  setline(1577);
// Begin line 413
  setline(413);
// compilenode returning *var_sym
  Object call743 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call743
// compilenode returning call743
  Object num744 = alloc_Float64(1.0);
// compilenode returning num744
  params[0] = num744;
  Object diff746 = callmethod(call743, "-", 1, params);
// compilenode returning diff746
  *var_minIndentLevel = diff746;
  if (diff746 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if738 = nothing;
  } else {
// Begin line 416
  setline(416);
// Begin line 415
  setline(415);
// compilenode returning *var_minInd
  *var_minIndentLevel = *var_minInd;
  if (*var_minInd == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if738 = nothing;
  }
// compilenode returning if738
// Begin line 420
  setline(420);
  Object while749;
  while (1) {
// Begin line 417
  setline(417);
// Begin line 1577
  setline(1577);
// Begin line 417
  setline(417);
  if (strlit750 == NULL) {
    strlit750 = alloc_String("rbrace");
  }
// compilenode returning strlit750
// Begin line 422
  setline(422);
// compilenode returning self
  params[0] = strlit750;
  Object call751 = callmethod(self, "accept",
    1, params);
// compilenode returning call751
  Object call752 = callmethod(call751, "not",
    0, params);
// compilenode returning call752
// compilenode returning call752
    while749 = call752;
    if (!istrue(call752)) break;
// Begin line 418
  setline(418);
// compilenode returning self
  Object call753 = callmethod(self, "statement",
    0, params);
// compilenode returning call753
// Begin line 420
  setline(420);
// Begin line 1577
  setline(1577);
// Begin line 419
  setline(419);
// compilenode returning *var_values
  Object call754 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call754
// compilenode returning call754
  *var_v = call754;
  if (call754 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 420
  setline(420);
// compilenode returning *var_v
// compilenode returning *var_ebody
  params[0] = *var_v;
  Object call756 = callmethod(*var_ebody, "push",
    1, params);
// compilenode returning call756
  }
// compilenode returning while749
// Begin line 422
  setline(422);
// compilenode returning self
  Object call757 = callmethod(self, "next",
    0, params);
// compilenode returning call757
// Begin line 424
  setline(424);
  Object array758 = alloc_List();
// compilenode returning array758
  *var_newelse = array758;
  if (array758 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_econd
// compilenode returning *var_ebody
// compilenode returning *var_newelse
// compilenode returning module_ast
  params[0] = *var_econd;
  params[1] = *var_ebody;
  params[2] = *var_newelse;
  Object call760 = callmethod(module_ast, "astif",
    3, params);
// compilenode returning call760
  *var_eif = call760;
  if (call760 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 427
  setline(427);
// compilenode returning *var_eif
// compilenode returning *var_curelse
  params[0] = *var_eif;
  Object call762 = callmethod(*var_curelse, "push",
    1, params);
// compilenode returning call762
// Begin line 431
  setline(431);
// Begin line 430
  setline(430);
// compilenode returning *var_newelse
  *var_curelse = *var_newelse;
  if (*var_newelse == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while702
// Begin line 448
  setline(448);
// Begin line 432
  setline(432);
  if (strlit765 == NULL) {
    strlit765 = alloc_String("identifier");
  }
// compilenode returning strlit765
// Begin line 451
  setline(451);
// compilenode returning self
  params[0] = strlit765;
  Object call766 = callmethod(self, "accept",
    1, params);
// compilenode returning call766
// Begin line 432
  setline(432);
// Begin line 1577
  setline(1577);
// Begin line 432
  setline(432);
// compilenode returning *var_sym
  Object call767 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call767
// compilenode returning call767
  if (strlit768 == NULL) {
    strlit768 = alloc_String("else");
  }
// compilenode returning strlit768
  params[0] = strlit768;
  Object opresult770 = callmethod(call767, "==", 1, params);
// compilenode returning opresult770
  params[0] = opresult770;
  Object opresult772 = callmethod(call766, "&", 1, params);
// compilenode returning opresult772
  Object if764;
  if (istrue(opresult772)) {
// Begin line 433
  setline(433);
// compilenode returning self
  Object call773 = callmethod(self, "next",
    0, params);
// compilenode returning call773
// Begin line 448
  setline(448);
// Begin line 434
  setline(434);
  if (strlit775 == NULL) {
    strlit775 = alloc_String("lbrace");
  }
// compilenode returning strlit775
// Begin line 450
  setline(450);
// compilenode returning self
  params[0] = strlit775;
  Object call776 = callmethod(self, "accept",
    1, params);
// compilenode returning call776
  Object if774;
  if (istrue(call776)) {
// Begin line 437
  setline(437);
// compilenode returning self
  Object call777 = callmethod(self, "next",
    0, params);
// compilenode returning call777
// Begin line 442
  setline(442);
// Begin line 443
  setline(443);
// Begin line 1577
  setline(1577);
// Begin line 438
  setline(438);
// compilenode returning *var_sym
  Object call779 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call779
// compilenode returning call779
// Begin line 443
  setline(443);
// Begin line 1577
  setline(1577);
// Begin line 438
  setline(438);
// compilenode returning *var_lastToken
  Object call780 = callmethod(*var_lastToken, "line",
    0, params);
// compilenode returning call780
// compilenode returning call780
  params[0] = call780;
  Object opresult782 = callmethod(call779, "==", 1, params);
// compilenode returning opresult782
  Object if778;
  if (istrue(opresult782)) {
// Begin line 440
  setline(440);
// Begin line 1577
  setline(1577);
// Begin line 439
  setline(439);
// compilenode returning *var_sym
  Object call783 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call783
// compilenode returning call783
  Object num784 = alloc_Float64(1.0);
// compilenode returning num784
  params[0] = num784;
  Object diff786 = callmethod(call783, "-", 1, params);
// compilenode returning diff786
  *var_minIndentLevel = diff786;
  if (diff786 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if778 = nothing;
  } else {
// Begin line 442
  setline(442);
// Begin line 441
  setline(441);
// compilenode returning *var_minInd
  *var_minIndentLevel = *var_minInd;
  if (*var_minInd == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if778 = nothing;
  }
// compilenode returning if778
// Begin line 446
  setline(446);
  Object while789;
  while (1) {
// Begin line 443
  setline(443);
// Begin line 1577
  setline(1577);
// Begin line 443
  setline(443);
  if (strlit790 == NULL) {
    strlit790 = alloc_String("rbrace");
  }
// compilenode returning strlit790
// Begin line 448
  setline(448);
// compilenode returning self
  params[0] = strlit790;
  Object call791 = callmethod(self, "accept",
    1, params);
// compilenode returning call791
  Object call792 = callmethod(call791, "not",
    0, params);
// compilenode returning call792
// compilenode returning call792
    while789 = call792;
    if (!istrue(call792)) break;
// Begin line 444
  setline(444);
// compilenode returning self
  Object call793 = callmethod(self, "statement",
    0, params);
// compilenode returning call793
// Begin line 446
  setline(446);
// Begin line 1577
  setline(1577);
// Begin line 445
  setline(445);
// compilenode returning *var_values
  Object call794 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call794
// compilenode returning call794
  *var_v = call794;
  if (call794 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 446
  setline(446);
// compilenode returning *var_v
// compilenode returning *var_curelse
  params[0] = *var_v;
  Object call796 = callmethod(*var_curelse, "push",
    1, params);
// compilenode returning call796
  }
// compilenode returning while789
// Begin line 448
  setline(448);
// compilenode returning self
  Object call797 = callmethod(self, "next",
    0, params);
// compilenode returning call797
    if774 = call797;
  } else {
  }
// compilenode returning if774
    if764 = if774;
  } else {
  }
// compilenode returning if764
// Begin line 452
  setline(452);
// Begin line 451
  setline(451);
// compilenode returning *var_minInd
  Object num798 = alloc_Float64(1.0);
// compilenode returning num798
  params[0] = num798;
  Object diff800 = callmethod(*var_minInd, "-", 1, params);
// compilenode returning diff800
  *var_minIndentLevel = diff800;
  if (diff800 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 452
  setline(452);
// compilenode returning *var_cond
// compilenode returning *var_body
// compilenode returning *var_elseblock
// compilenode returning module_ast
  params[0] = *var_cond;
  params[1] = *var_body;
  params[2] = *var_elseblock;
  Object call802 = callmethod(module_ast, "astif",
    3, params);
// compilenode returning call802
  var_o = alloc_var();
  *var_o = call802;
  if (call802 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 453
  setline(453);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call803 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call803
    if668 = call803;
  } else {
// Begin line 456
  setline(456);
  if (strlit804 == NULL) {
    strlit804 = alloc_String("if with no then");
  }
// compilenode returning strlit804
// compilenode returning module_util
  params[0] = strlit804;
  Object call805 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call805
    if668 = call805;
  }
// compilenode returning if668
    if651 = if668;
  } else {
  }
// compilenode returning if651
  return if651;
}
Object meth_parser_dofor806(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[18];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
  Object *var_statementIndent = closure[2];
  Object *var_minIndentLevel = closure[3];
// Begin line 464
  setline(464);
  if (strlit808 == NULL) {
    strlit808 = alloc_String("identifier");
  }
// compilenode returning strlit808
// Begin line 486
  setline(486);
// compilenode returning self
  params[0] = strlit808;
  Object call809 = callmethod(self, "accept",
    1, params);
// compilenode returning call809
// Begin line 464
  setline(464);
// Begin line 1577
  setline(1577);
// Begin line 464
  setline(464);
// compilenode returning *var_sym
  Object call810 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call810
// compilenode returning call810
  if (strlit811 == NULL) {
    strlit811 = alloc_String("for");
  }
// compilenode returning strlit811
  params[0] = strlit811;
  Object opresult813 = callmethod(call810, "==", 1, params);
// compilenode returning opresult813
  params[0] = opresult813;
  Object opresult815 = callmethod(call809, "&", 1, params);
// compilenode returning opresult815
  Object if807;
  if (istrue(opresult815)) {
  Object *var_over = alloc_var();
  *var_over = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_variable = alloc_var();
  *var_variable = undefined;
  Object *var_localMin = alloc_var();
  *var_localMin = undefined;
  Object *var_minInd = alloc_var();
  *var_minInd = undefined;
// Begin line 465
  setline(465);
// compilenode returning self
  Object call816 = callmethod(self, "next",
    0, params);
// compilenode returning call816
// Begin line 467
  setline(467);
  var_over = alloc_var();
  *var_over = undefined;
// compilenode returning nothing
// compilenode returning self
  Object call817 = callmethod(self, "expression",
    0, params);
// compilenode returning call817
// Begin line 469
  setline(469);
// Begin line 1577
  setline(1577);
// Begin line 468
  setline(468);
// compilenode returning *var_values
  Object call818 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call818
// compilenode returning call818
  *var_over = call818;
  if (call818 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 470
  setline(470);
  Object array820 = alloc_List();
// compilenode returning array820
  var_body = alloc_var();
  *var_body = array820;
  if (array820 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 471
  setline(471);
  var_variable = alloc_var();
  *var_variable = undefined;
// compilenode returning nothing
// Begin line 472
  setline(472);
  var_localMin = alloc_var();
  *var_localMin = undefined;
// compilenode returning nothing
// Begin line 473
  setline(473);
// Begin line 472
  setline(472);
// compilenode returning *var_statementIndent
  Object num821 = alloc_Float64(1.0);
// compilenode returning num821
  params[0] = num821;
  Object sum823 = callmethod(*var_statementIndent, "+", 1, params);
// compilenode returning sum823
  var_minInd = alloc_var();
  *var_minInd = sum823;
  if (sum823 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 483
  setline(483);
// Begin line 473
  setline(473);
  if (strlit825 == NULL) {
    strlit825 = alloc_String("identifier");
  }
// compilenode returning strlit825
// Begin line 485
  setline(485);
// compilenode returning self
  params[0] = strlit825;
  Object call826 = callmethod(self, "accept",
    1, params);
// compilenode returning call826
// Begin line 473
  setline(473);
// Begin line 1577
  setline(1577);
// Begin line 473
  setline(473);
// compilenode returning *var_sym
  Object call827 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call827
// compilenode returning call827
  if (strlit828 == NULL) {
    strlit828 = alloc_String("each");
  }
// compilenode returning strlit828
  params[0] = strlit828;
  Object opresult830 = callmethod(call827, "==", 1, params);
// compilenode returning opresult830
// Begin line 1577
  setline(1577);
// Begin line 474
  setline(474);
// compilenode returning *var_sym
  Object call831 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call831
// compilenode returning call831
  if (strlit832 == NULL) {
    strlit832 = alloc_String("do");
  }
// compilenode returning strlit832
  params[0] = strlit832;
  Object opresult834 = callmethod(call831, "==", 1, params);
// compilenode returning opresult834
  params[0] = opresult834;
  Object opresult836 = callmethod(opresult830, "|", 1, params);
// compilenode returning opresult836
  params[0] = opresult836;
  Object opresult838 = callmethod(call826, "&", 1, params);
// compilenode returning opresult838
  Object if824;
  if (istrue(opresult838)) {
  Object *var_blk = alloc_var();
  *var_blk = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 475
  setline(475);
// compilenode returning self
  Object call839 = callmethod(self, "next",
    0, params);
// compilenode returning call839
// Begin line 476
  setline(476);
  if (strlit840 == NULL) {
    strlit840 = alloc_String("lbrace");
  }
// compilenode returning strlit840
// Begin line 477
  setline(477);
// compilenode returning self
  params[0] = strlit840;
  Object call841 = callmethod(self, "expect",
    1, params);
// compilenode returning call841
// compilenode returning self
  Object call842 = callmethod(self, "block",
    0, params);
// compilenode returning call842
// Begin line 479
  setline(479);
// Begin line 1577
  setline(1577);
// Begin line 478
  setline(478);
// compilenode returning *var_values
  Object call843 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call843
// compilenode returning call843
  var_blk = alloc_var();
  *var_blk = call843;
  if (call843 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 479
  setline(479);
// compilenode returning *var_over
// compilenode returning *var_blk
// compilenode returning module_ast
  params[0] = *var_over;
  params[1] = *var_blk;
  Object call844 = callmethod(module_ast, "astfor",
    2, params);
// compilenode returning call844
  var_o = alloc_var();
  *var_o = call844;
  if (call844 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 480
  setline(480);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call845 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call845
// Begin line 482
  setline(482);
// Begin line 481
  setline(481);
// compilenode returning *var_minInd
  Object num846 = alloc_Float64(1.0);
// compilenode returning num846
  params[0] = num846;
  Object diff848 = callmethod(*var_minInd, "-", 1, params);
// compilenode returning diff848
  *var_minIndentLevel = diff848;
  if (diff848 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if824 = nothing;
  } else {
// Begin line 483
  setline(483);
  if (strlit850 == NULL) {
    strlit850 = alloc_String("expected 'do'");
  }
// compilenode returning strlit850
// compilenode returning module_util
  params[0] = strlit850;
  Object call851 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call851
    if824 = call851;
  }
// compilenode returning if824
    if807 = if824;
  } else {
  }
// compilenode returning if807
  return if807;
}
Object meth_parser_dowhile852(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[19];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_statementIndent = closure[1];
  Object *var_values = closure[2];
  Object *var_lastToken = closure[3];
  Object *var_minIndentLevel = closure[4];
// Begin line 491
  setline(491);
  if (strlit854 == NULL) {
    strlit854 = alloc_String("identifier");
  }
// compilenode returning strlit854
// Begin line 526
  setline(526);
// compilenode returning self
  params[0] = strlit854;
  Object call855 = callmethod(self, "accept",
    1, params);
// compilenode returning call855
// Begin line 491
  setline(491);
// Begin line 1577
  setline(1577);
// Begin line 491
  setline(491);
// compilenode returning *var_sym
  Object call856 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call856
// compilenode returning call856
  if (strlit857 == NULL) {
    strlit857 = alloc_String("while");
  }
// compilenode returning strlit857
  params[0] = strlit857;
  Object opresult859 = callmethod(call856, "==", 1, params);
// compilenode returning opresult859
  params[0] = opresult859;
  Object opresult861 = callmethod(call855, "&", 1, params);
// compilenode returning opresult861
  Object if853;
  if (istrue(opresult861)) {
  Object *var_minInd = alloc_var();
  *var_minInd = undefined;
  Object *var_cond = alloc_var();
  *var_cond = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
// Begin line 493
  setline(493);
// Begin line 492
  setline(492);
// compilenode returning *var_statementIndent
  Object num862 = alloc_Float64(1.0);
// compilenode returning num862
  params[0] = num862;
  Object sum864 = callmethod(*var_statementIndent, "+", 1, params);
// compilenode returning sum864
  var_minInd = alloc_var();
  *var_minInd = sum864;
  if (sum864 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 493
  setline(493);
// compilenode returning self
  Object call865 = callmethod(self, "next",
    0, params);
// compilenode returning call865
// Begin line 495
  setline(495);
  var_cond = alloc_var();
  *var_cond = undefined;
// compilenode returning nothing
// Begin line 500
  setline(500);
// Begin line 495
  setline(495);
  if (strlit867 == NULL) {
    strlit867 = alloc_String("lbrace");
  }
// compilenode returning strlit867
// Begin line 503
  setline(503);
// compilenode returning self
  params[0] = strlit867;
  Object call868 = callmethod(self, "accept",
    1, params);
// compilenode returning call868
  Object if866;
  if (istrue(call868)) {
// Begin line 496
  setline(496);
// compilenode returning self
  Object call869 = callmethod(self, "next",
    0, params);
// compilenode returning call869
// Begin line 497
  setline(497);
// compilenode returning self
  Object call870 = callmethod(self, "expression",
    0, params);
// compilenode returning call870
// Begin line 499
  setline(499);
// Begin line 1577
  setline(1577);
// Begin line 498
  setline(498);
// compilenode returning *var_values
  Object call871 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call871
// compilenode returning call871
  *var_cond = call871;
  if (call871 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 500
  setline(500);
// Begin line 499
  setline(499);
  if (strlit874 == NULL) {
    strlit874 = alloc_String("rbrace");
  }
// compilenode returning strlit874
// Begin line 502
  setline(502);
// compilenode returning self
  params[0] = strlit874;
  Object call875 = callmethod(self, "accept",
    1, params);
// compilenode returning call875
  Object if873;
  if (istrue(call875)) {
// Begin line 500
  setline(500);
// compilenode returning self
  Object call876 = callmethod(self, "next",
    0, params);
// compilenode returning call876
    if873 = call876;
  } else {
  }
// compilenode returning if873
    if866 = if873;
  } else {
  }
// compilenode returning if866
// Begin line 504
  setline(504);
  Object array877 = alloc_List();
// compilenode returning array877
  var_body = alloc_var();
  *var_body = array877;
  if (array877 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 520
  setline(520);
// Begin line 504
  setline(504);
  if (strlit879 == NULL) {
    strlit879 = alloc_String("identifier");
  }
// compilenode returning strlit879
// Begin line 522
  setline(522);
// compilenode returning self
  params[0] = strlit879;
  Object call880 = callmethod(self, "accept",
    1, params);
// compilenode returning call880
// Begin line 504
  setline(504);
// Begin line 1577
  setline(1577);
// Begin line 504
  setline(504);
// compilenode returning *var_sym
  Object call881 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call881
// compilenode returning call881
  if (strlit882 == NULL) {
    strlit882 = alloc_String("do");
  }
// compilenode returning strlit882
  params[0] = strlit882;
  Object opresult884 = callmethod(call881, "==", 1, params);
// compilenode returning opresult884
  params[0] = opresult884;
  Object opresult886 = callmethod(call880, "&", 1, params);
// compilenode returning opresult886
  Object if878;
  if (istrue(opresult886)) {
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 505
  setline(505);
// compilenode returning self
  Object call887 = callmethod(self, "next",
    0, params);
// compilenode returning call887
// Begin line 506
  setline(506);
  if (strlit888 == NULL) {
    strlit888 = alloc_String("lbrace");
  }
// compilenode returning strlit888
// Begin line 507
  setline(507);
// compilenode returning self
  params[0] = strlit888;
  Object call889 = callmethod(self, "expect",
    1, params);
// compilenode returning call889
// compilenode returning self
  Object call890 = callmethod(self, "next",
    0, params);
// compilenode returning call890
// Begin line 512
  setline(512);
// Begin line 513
  setline(513);
// Begin line 1577
  setline(1577);
// Begin line 508
  setline(508);
// compilenode returning *var_sym
  Object call892 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call892
// compilenode returning call892
// Begin line 513
  setline(513);
// Begin line 1577
  setline(1577);
// Begin line 508
  setline(508);
// compilenode returning *var_lastToken
  Object call893 = callmethod(*var_lastToken, "line",
    0, params);
// compilenode returning call893
// compilenode returning call893
  params[0] = call893;
  Object opresult895 = callmethod(call892, "==", 1, params);
// compilenode returning opresult895
  Object if891;
  if (istrue(opresult895)) {
// Begin line 510
  setline(510);
// Begin line 1577
  setline(1577);
// Begin line 509
  setline(509);
// compilenode returning *var_sym
  Object call896 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call896
// compilenode returning call896
  Object num897 = alloc_Float64(1.0);
// compilenode returning num897
  params[0] = num897;
  Object diff899 = callmethod(call896, "-", 1, params);
// compilenode returning diff899
  *var_minIndentLevel = diff899;
  if (diff899 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if891 = nothing;
  } else {
// Begin line 512
  setline(512);
// Begin line 511
  setline(511);
// compilenode returning *var_minInd
  *var_minIndentLevel = *var_minInd;
  if (*var_minInd == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if891 = nothing;
  }
// compilenode returning if891
// Begin line 516
  setline(516);
  Object while902;
  while (1) {
// Begin line 513
  setline(513);
// Begin line 1577
  setline(1577);
// Begin line 513
  setline(513);
  if (strlit903 == NULL) {
    strlit903 = alloc_String("rbrace");
  }
// compilenode returning strlit903
// Begin line 518
  setline(518);
// compilenode returning self
  params[0] = strlit903;
  Object call904 = callmethod(self, "accept",
    1, params);
// compilenode returning call904
  Object call905 = callmethod(call904, "not",
    0, params);
// compilenode returning call905
// compilenode returning call905
    while902 = call905;
    if (!istrue(call905)) break;
  Object *var_v = alloc_var();
  *var_v = undefined;
// Begin line 514
  setline(514);
// compilenode returning self
  Object call906 = callmethod(self, "statement",
    0, params);
// compilenode returning call906
// Begin line 516
  setline(516);
// Begin line 1577
  setline(1577);
// Begin line 515
  setline(515);
// compilenode returning *var_values
  Object call907 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call907
// compilenode returning call907
  var_v = alloc_var();
  *var_v = call907;
  if (call907 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 516
  setline(516);
// compilenode returning *var_v
// compilenode returning *var_body
  params[0] = *var_v;
  Object call908 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call908
  }
// compilenode returning while902
// Begin line 518
  setline(518);
// compilenode returning self
  Object call909 = callmethod(self, "next",
    0, params);
// compilenode returning call909
// Begin line 519
  setline(519);
// compilenode returning *var_cond
// compilenode returning *var_body
// compilenode returning module_ast
  params[0] = *var_cond;
  params[1] = *var_body;
  Object call910 = callmethod(module_ast, "astwhile",
    2, params);
// compilenode returning call910
  var_o = alloc_var();
  *var_o = call910;
  if (call910 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 520
  setline(520);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call911 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call911
    if878 = call911;
  } else {
  }
// compilenode returning if878
// Begin line 523
  setline(523);
// Begin line 522
  setline(522);
// compilenode returning *var_minInd
  Object num912 = alloc_Float64(1.0);
// compilenode returning num912
  params[0] = num912;
  Object diff914 = callmethod(*var_minInd, "-", 1, params);
// compilenode returning diff914
  *var_minIndentLevel = diff914;
  if (diff914 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if853 = nothing;
  } else {
// Begin line 524
  setline(524);
  if (strlit916 == NULL) {
    strlit916 = alloc_String("expected 'do'");
  }
// compilenode returning strlit916
// compilenode returning module_util
  params[0] = strlit916;
  Object call917 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call917
    if853 = call917;
  }
// compilenode returning if853
  return if853;
}
Object meth_parser_identifier918(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[20];
  Object params[1];
  Object *var_sym = closure[0];
// Begin line 531
  setline(531);
  if (strlit920 == NULL) {
    strlit920 = alloc_String("identifier");
  }
// compilenode returning strlit920
// Begin line 542
  setline(542);
// compilenode returning self
  params[0] = strlit920;
  Object call921 = callmethod(self, "accept",
    1, params);
// compilenode returning call921
  Object if919;
  if (istrue(call921)) {
// Begin line 539
  setline(539);
// Begin line 541
  setline(541);
// Begin line 1577
  setline(1577);
// Begin line 532
  setline(532);
// compilenode returning *var_sym
  Object call923 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call923
// compilenode returning call923
  if (strlit924 == NULL) {
    strlit924 = alloc_String("if");
  }
// compilenode returning strlit924
  params[0] = strlit924;
  Object opresult926 = callmethod(call923, "==", 1, params);
// compilenode returning opresult926
  Object if922;
  if (istrue(opresult926)) {
// Begin line 533
  setline(533);
// compilenode returning self
  Object call927 = callmethod(self, "doif",
    0, params);
// compilenode returning call927
    if922 = call927;
  } else {
// Begin line 539
  setline(539);
// Begin line 536
  setline(536);
// Begin line 1577
  setline(1577);
// Begin line 534
  setline(534);
// compilenode returning *var_sym
  Object call929 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call929
// compilenode returning call929
  if (strlit930 == NULL) {
    strlit930 = alloc_String("while");
  }
// compilenode returning strlit930
  params[0] = strlit930;
  Object opresult932 = callmethod(call929, "==", 1, params);
// compilenode returning opresult932
  Object if928;
  if (istrue(opresult932)) {
// Begin line 535
  setline(535);
// compilenode returning self
  Object call933 = callmethod(self, "dowhile",
    0, params);
// compilenode returning call933
    if928 = call933;
  } else {
// Begin line 539
  setline(539);
// Begin line 538
  setline(538);
// Begin line 1577
  setline(1577);
// Begin line 536
  setline(536);
// compilenode returning *var_sym
  Object call935 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call935
// compilenode returning call935
  if (strlit936 == NULL) {
    strlit936 = alloc_String("for");
  }
// compilenode returning strlit936
  params[0] = strlit936;
  Object opresult938 = callmethod(call935, "==", 1, params);
// compilenode returning opresult938
  Object if934;
  if (istrue(opresult938)) {
// Begin line 537
  setline(537);
// compilenode returning self
  Object call939 = callmethod(self, "dofor",
    0, params);
// compilenode returning call939
    if934 = call939;
  } else {
// Begin line 539
  setline(539);
// compilenode returning self
  Object call940 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call940
    if934 = call940;
  }
// compilenode returning if934
    if928 = if934;
  }
// compilenode returning if928
    if922 = if928;
  }
// compilenode returning if922
    if919 = if922;
  } else {
  }
// compilenode returning if919
  return if919;
}
Object meth_parser_prefixop941(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[21];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 545
  setline(545);
  if (strlit943 == NULL) {
    strlit943 = alloc_String("op");
  }
// compilenode returning strlit943
// Begin line 568
  setline(568);
// compilenode returning self
  params[0] = strlit943;
  Object call944 = callmethod(self, "accept",
    1, params);
// compilenode returning call944
  Object if942;
  if (istrue(call944)) {
  Object *var_op = alloc_var();
  *var_op = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_mem = alloc_var();
  *var_mem = undefined;
  Object *var_call = alloc_var();
  *var_call = undefined;
// Begin line 547
  setline(547);
// Begin line 1577
  setline(1577);
// Begin line 546
  setline(546);
// compilenode returning *var_sym
  Object call945 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call945
// compilenode returning call945
  var_op = alloc_var();
  *var_op = call945;
  if (call945 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 548
  setline(548);
  var_val = alloc_var();
  *var_val = undefined;
// compilenode returning nothing
// compilenode returning self
  Object call946 = callmethod(self, "next",
    0, params);
// compilenode returning call946
// Begin line 558
  setline(558);
// Begin line 549
  setline(549);
  if (strlit948 == NULL) {
    strlit948 = alloc_String("lparen");
  }
// compilenode returning strlit948
// Begin line 560
  setline(560);
// compilenode returning self
  params[0] = strlit948;
  Object call949 = callmethod(self, "accept",
    1, params);
// compilenode returning call949
  Object if947;
  if (istrue(call949)) {
// Begin line 550
  setline(550);
// compilenode returning self
  Object call950 = callmethod(self, "next",
    0, params);
// compilenode returning call950
// Begin line 552
  setline(552);
// Begin line 551
  setline(551);
  if (strlit952 == NULL) {
    strlit952 = alloc_String("rparen");
  }
// compilenode returning strlit952
// Begin line 554
  setline(554);
// compilenode returning self
  params[0] = strlit952;
  Object call953 = callmethod(self, "accept",
    1, params);
// compilenode returning call953
  Object if951;
  if (istrue(call953)) {
// Begin line 552
  setline(552);
  if (strlit954 == NULL) {
    strlit954 = alloc_String("empty () in expression");
  }
// compilenode returning strlit954
// compilenode returning module_util
  params[0] = strlit954;
  Object call955 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call955
    if951 = call955;
  } else {
  }
// compilenode returning if951
// Begin line 554
  setline(554);
// compilenode returning self
  Object call956 = callmethod(self, "expression",
    0, params);
// compilenode returning call956
// Begin line 555
  setline(555);
  if (strlit957 == NULL) {
    strlit957 = alloc_String("rparen");
  }
// compilenode returning strlit957
// Begin line 556
  setline(556);
// compilenode returning self
  params[0] = strlit957;
  Object call958 = callmethod(self, "expect",
    1, params);
// compilenode returning call958
// compilenode returning self
  Object call959 = callmethod(self, "next",
    0, params);
// compilenode returning call959
    if947 = call959;
  } else {
// Begin line 558
  setline(558);
// compilenode returning self
  Object call960 = callmethod(self, "term",
    0, params);
// compilenode returning call960
    if947 = call960;
  }
// compilenode returning if947
// Begin line 560
  setline(560);
// compilenode returning self
  Object call961 = callmethod(self, "dotrest",
    0, params);
// compilenode returning call961
// Begin line 561
  setline(561);
// compilenode returning self
  Object call962 = callmethod(self, "postfixsquare",
    0, params);
// compilenode returning call962
// Begin line 562
  setline(562);
// compilenode returning self
  Object call963 = callmethod(self, "callrest",
    0, params);
// compilenode returning call963
// Begin line 564
  setline(564);
// Begin line 1577
  setline(1577);
// Begin line 563
  setline(563);
// compilenode returning *var_values
  Object call964 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call964
// compilenode returning call964
  *var_val = call964;
  if (call964 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 564
  setline(564);
  if (strlit966 == NULL) {
    strlit966 = alloc_String("prefix");
  }
// compilenode returning strlit966
// compilenode returning *var_op
  params[0] = *var_op;
  Object opresult968 = callmethod(strlit966, "++", 1, params);
// compilenode returning opresult968
// compilenode returning *var_val
// compilenode returning module_ast
  params[0] = opresult968;
  params[1] = *var_val;
  Object call969 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call969
  var_mem = alloc_var();
  *var_mem = call969;
  if (call969 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 565
  setline(565);
// compilenode returning *var_mem
  Object array970 = alloc_List();
// compilenode returning array970
// compilenode returning module_ast
  params[0] = *var_mem;
  params[1] = array970;
  Object call971 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call971
  var_call = alloc_var();
  *var_call = call971;
  if (call971 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 566
  setline(566);
// compilenode returning *var_call
// compilenode returning *var_values
  params[0] = *var_call;
  Object call972 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call972
    if942 = call972;
  } else {
  }
// compilenode returning if942
  return if942;
}
Object meth_parser_generic973(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[22];
  Object params[2];
  Object *var_values = closure[0];
// Begin line 571
  setline(571);
  if (strlit975 == NULL) {
    strlit975 = alloc_String("lgeneric");
  }
// compilenode returning strlit975
// Begin line 589
  setline(589);
// compilenode returning self
  params[0] = strlit975;
  Object call976 = callmethod(self, "accept",
    1, params);
// compilenode returning call976
  Object if974;
  if (istrue(call976)) {
  Object *var_id = alloc_var();
  *var_id = undefined;
  Object *var_gens = alloc_var();
  *var_gens = undefined;
// Begin line 573
  setline(573);
// Begin line 1577
  setline(1577);
// Begin line 572
  setline(572);
// compilenode returning *var_values
  Object call977 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call977
// compilenode returning call977
  *var_id = call977;
  if (call977 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 574
  setline(574);
  Object array978 = alloc_List();
// compilenode returning array978
  *var_gens = array978;
  if (array978 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning self
  Object call979 = callmethod(self, "next",
    0, params);
// compilenode returning call979
// Begin line 582
  setline(582);
  Object while980;
  while (1) {
// Begin line 575
  setline(575);
  if (strlit981 == NULL) {
    strlit981 = alloc_String("identifier");
  }
// compilenode returning strlit981
// Begin line 585
  setline(585);
// compilenode returning self
  params[0] = strlit981;
  Object call982 = callmethod(self, "accept",
    1, params);
// compilenode returning call982
    while980 = call982;
    if (!istrue(call982)) break;
// Begin line 576
  setline(576);
// compilenode returning self
  Object call983 = callmethod(self, "identifier",
    0, params);
// compilenode returning call983
// Begin line 577
  setline(577);
// compilenode returning self
  Object call984 = callmethod(self, "generic",
    0, params);
// compilenode returning call984
// Begin line 578
  setline(578);
// Begin line 1577
  setline(1577);
// Begin line 578
  setline(578);
// compilenode returning *var_values
  Object call985 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call985
// compilenode returning call985
// compilenode returning *var_gens
  params[0] = call985;
  Object call986 = callmethod(*var_gens, "push",
    1, params);
// compilenode returning call986
// Begin line 582
  setline(582);
// Begin line 579
  setline(579);
  if (strlit988 == NULL) {
    strlit988 = alloc_String("comma");
  }
// compilenode returning strlit988
// Begin line 584
  setline(584);
// compilenode returning self
  params[0] = strlit988;
  Object call989 = callmethod(self, "accept",
    1, params);
// compilenode returning call989
  Object if987;
  if (istrue(call989)) {
// Begin line 580
  setline(580);
// compilenode returning self
  Object call990 = callmethod(self, "next",
    0, params);
// compilenode returning call990
    if987 = call990;
  } else {
// Begin line 582
  setline(582);
  if (strlit991 == NULL) {
    strlit991 = alloc_String("rgeneric");
  }
// compilenode returning strlit991
// Begin line 583
  setline(583);
// compilenode returning self
  params[0] = strlit991;
  Object call992 = callmethod(self, "expect",
    1, params);
// compilenode returning call992
    if987 = call992;
  }
// compilenode returning if987
  }
// compilenode returning while980
// Begin line 585
  setline(585);
  if (strlit993 == NULL) {
    strlit993 = alloc_String("rgeneric");
  }
// compilenode returning strlit993
// Begin line 586
  setline(586);
// compilenode returning self
  params[0] = strlit993;
  Object call994 = callmethod(self, "expect",
    1, params);
// compilenode returning call994
// compilenode returning self
  Object call995 = callmethod(self, "next",
    0, params);
// compilenode returning call995
// Begin line 587
  setline(587);
// compilenode returning *var_id
// compilenode returning *var_gens
// compilenode returning module_ast
  params[0] = *var_id;
  params[1] = *var_gens;
  Object call996 = callmethod(module_ast, "astgeneric",
    2, params);
// compilenode returning call996
// compilenode returning *var_values
  params[0] = call996;
  Object call997 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call997
    if974 = call997;
  } else {
  }
// compilenode returning if974
  return if974;
}
Object meth_parser_term998(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[23];
  Object params[1];
  Object *var_sym = closure[0];
// Begin line 593
  setline(593);
  if (strlit1000 == NULL) {
    strlit1000 = alloc_String("num");
  }
// compilenode returning strlit1000
// Begin line 614
  setline(614);
// compilenode returning self
  params[0] = strlit1000;
  Object call1001 = callmethod(self, "accept",
    1, params);
// compilenode returning call1001
  Object if999;
  if (istrue(call1001)) {
// Begin line 594
  setline(594);
// compilenode returning self
  Object call1002 = callmethod(self, "pushnum",
    0, params);
// compilenode returning call1002
    if999 = call1002;
  } else {
// Begin line 612
  setline(612);
// Begin line 595
  setline(595);
  if (strlit1004 == NULL) {
    strlit1004 = alloc_String("string");
  }
// compilenode returning strlit1004
// Begin line 597
  setline(597);
// compilenode returning self
  params[0] = strlit1004;
  Object call1005 = callmethod(self, "accept",
    1, params);
// compilenode returning call1005
  Object if1003;
  if (istrue(call1005)) {
// Begin line 596
  setline(596);
// compilenode returning self
  Object call1006 = callmethod(self, "pushstring",
    0, params);
// compilenode returning call1006
    if1003 = call1006;
  } else {
// Begin line 612
  setline(612);
// Begin line 597
  setline(597);
  if (strlit1008 == NULL) {
    strlit1008 = alloc_String("octets");
  }
// compilenode returning strlit1008
// Begin line 599
  setline(599);
// compilenode returning self
  params[0] = strlit1008;
  Object call1009 = callmethod(self, "accept",
    1, params);
// compilenode returning call1009
  Object if1007;
  if (istrue(call1009)) {
// Begin line 598
  setline(598);
// compilenode returning self
  Object call1010 = callmethod(self, "pushoctets",
    0, params);
// compilenode returning call1010
    if1007 = call1010;
  } else {
// Begin line 612
  setline(612);
// Begin line 599
  setline(599);
  if (strlit1012 == NULL) {
    strlit1012 = alloc_String("identifier");
  }
// compilenode returning strlit1012
// Begin line 604
  setline(604);
// compilenode returning self
  params[0] = strlit1012;
  Object call1013 = callmethod(self, "accept",
    1, params);
// compilenode returning call1013
  Object if1011;
  if (istrue(call1013)) {
// Begin line 600
  setline(600);
// compilenode returning self
  Object call1014 = callmethod(self, "identifier",
    0, params);
// compilenode returning call1014
// Begin line 602
  setline(602);
// Begin line 601
  setline(601);
  if (strlit1016 == NULL) {
    strlit1016 = alloc_String("lgeneric");
  }
// compilenode returning strlit1016
// Begin line 604
  setline(604);
// compilenode returning self
  params[0] = strlit1016;
  Object call1017 = callmethod(self, "accept",
    1, params);
// compilenode returning call1017
  Object if1015;
  if (istrue(call1017)) {
// Begin line 602
  setline(602);
// compilenode returning self
  Object call1018 = callmethod(self, "generic",
    0, params);
// compilenode returning call1018
    if1015 = call1018;
  } else {
  }
// compilenode returning if1015
    if1011 = if1015;
  } else {
// Begin line 612
  setline(612);
// Begin line 604
  setline(604);
  if (strlit1020 == NULL) {
    strlit1020 = alloc_String("keyword");
  }
// compilenode returning strlit1020
// Begin line 606
  setline(606);
// compilenode returning self
  params[0] = strlit1020;
  Object call1021 = callmethod(self, "accept",
    1, params);
// compilenode returning call1021
// Begin line 604
  setline(604);
// Begin line 1577
  setline(1577);
// Begin line 604
  setline(604);
// compilenode returning *var_sym
  Object call1022 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1022
// compilenode returning call1022
  if (strlit1023 == NULL) {
    strlit1023 = alloc_String("object");
  }
// compilenode returning strlit1023
  params[0] = strlit1023;
  Object opresult1025 = callmethod(call1022, "==", 1, params);
// compilenode returning opresult1025
  params[0] = opresult1025;
  Object opresult1027 = callmethod(call1021, "&", 1, params);
// compilenode returning opresult1027
  Object if1019;
  if (istrue(opresult1027)) {
// Begin line 605
  setline(605);
// compilenode returning self
  Object call1028 = callmethod(self, "doobject",
    0, params);
// compilenode returning call1028
    if1019 = call1028;
  } else {
// Begin line 612
  setline(612);
// Begin line 606
  setline(606);
  if (strlit1030 == NULL) {
    strlit1030 = alloc_String("lbrace");
  }
// compilenode returning strlit1030
// Begin line 608
  setline(608);
// compilenode returning self
  params[0] = strlit1030;
  Object call1031 = callmethod(self, "accept",
    1, params);
// compilenode returning call1031
  Object if1029;
  if (istrue(call1031)) {
// Begin line 607
  setline(607);
// compilenode returning self
  Object call1032 = callmethod(self, "block",
    0, params);
// compilenode returning call1032
    if1029 = call1032;
  } else {
// Begin line 612
  setline(612);
// Begin line 608
  setline(608);
  if (strlit1034 == NULL) {
    strlit1034 = alloc_String("lsquare");
  }
// compilenode returning strlit1034
// Begin line 610
  setline(610);
// compilenode returning self
  params[0] = strlit1034;
  Object call1035 = callmethod(self, "accept",
    1, params);
// compilenode returning call1035
  Object if1033;
  if (istrue(call1035)) {
// Begin line 609
  setline(609);
// compilenode returning self
  Object call1036 = callmethod(self, "doarray",
    0, params);
// compilenode returning call1036
    if1033 = call1036;
  } else {
// Begin line 612
  setline(612);
// Begin line 610
  setline(610);
  if (strlit1038 == NULL) {
    strlit1038 = alloc_String("op");
  }
// compilenode returning strlit1038
// Begin line 614
  setline(614);
// compilenode returning self
  params[0] = strlit1038;
  Object call1039 = callmethod(self, "accept",
    1, params);
// compilenode returning call1039
  Object if1037;
  if (istrue(call1039)) {
// Begin line 612
  setline(612);
// compilenode returning self
  Object call1040 = callmethod(self, "prefixop",
    0, params);
// compilenode returning call1040
    if1037 = call1040;
  } else {
  }
// compilenode returning if1037
    if1033 = if1037;
  }
// compilenode returning if1033
    if1029 = if1033;
  }
// compilenode returning if1029
    if1019 = if1029;
  }
// compilenode returning if1019
    if1011 = if1019;
  }
// compilenode returning if1011
    if1007 = if1011;
  }
// compilenode returning if1007
    if1003 = if1007;
  }
// compilenode returning if1003
    if999 = if1003;
  }
// compilenode returning if999
  return if999;
}
Object meth_parser_expression1041(Object self, int nparams, Object *args, int32_t flags) {
  Object params[1];
// Begin line 627
  setline(627);
// Begin line 621
  setline(621);
  if (strlit1043 == NULL) {
    strlit1043 = alloc_String("lparen");
  }
// compilenode returning strlit1043
// Begin line 629
  setline(629);
// compilenode returning self
  params[0] = strlit1043;
  Object call1044 = callmethod(self, "accept",
    1, params);
// compilenode returning call1044
  Object if1042;
  if (istrue(call1044)) {
// Begin line 622
  setline(622);
// compilenode returning self
  Object call1045 = callmethod(self, "next",
    0, params);
// compilenode returning call1045
// Begin line 623
  setline(623);
// compilenode returning self
  Object call1046 = callmethod(self, "expression",
    0, params);
// compilenode returning call1046
// Begin line 624
  setline(624);
  if (strlit1047 == NULL) {
    strlit1047 = alloc_String("rparen");
  }
// compilenode returning strlit1047
// Begin line 625
  setline(625);
// compilenode returning self
  params[0] = strlit1047;
  Object call1048 = callmethod(self, "expect",
    1, params);
// compilenode returning call1048
// compilenode returning self
  Object call1049 = callmethod(self, "next",
    0, params);
// compilenode returning call1049
    if1042 = call1049;
  } else {
// Begin line 627
  setline(627);
// compilenode returning self
  Object call1050 = callmethod(self, "term",
    0, params);
// compilenode returning call1050
    if1042 = call1050;
  }
// compilenode returning if1042
// Begin line 629
  setline(629);
// compilenode returning self
  Object call1051 = callmethod(self, "dotrest",
    0, params);
// compilenode returning call1051
// Begin line 630
  setline(630);
// compilenode returning self
  Object call1052 = callmethod(self, "postfixsquare",
    0, params);
// compilenode returning call1052
// Begin line 631
  setline(631);
// compilenode returning self
  Object call1053 = callmethod(self, "callrest",
    0, params);
// compilenode returning call1053
// Begin line 632
  setline(632);
// compilenode returning self
  Object call1054 = callmethod(self, "expressionrest",
    0, params);
// compilenode returning call1054
  return call1054;
}
Object meth_parser_postfixsquare1055(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[25];
  Object params[2];
  Object *var_values = closure[0];
// Begin line 638
  setline(638);
  if (strlit1057 == NULL) {
    strlit1057 = alloc_String("lsquare");
  }
// compilenode returning strlit1057
// Begin line 648
  setline(648);
// compilenode returning self
  params[0] = strlit1057;
  Object call1058 = callmethod(self, "accept",
    1, params);
// compilenode returning call1058
  Object if1056;
  if (istrue(call1058)) {
  Object *var_expr = alloc_var();
  *var_expr = undefined;
  Object *var_index = alloc_var();
  *var_index = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 639
  setline(639);
// compilenode returning self
  Object call1059 = callmethod(self, "next",
    0, params);
// compilenode returning call1059
// Begin line 641
  setline(641);
// Begin line 1577
  setline(1577);
// Begin line 640
  setline(640);
// compilenode returning *var_values
  Object call1060 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1060
// compilenode returning call1060
  var_expr = alloc_var();
  *var_expr = call1060;
  if (call1060 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 641
  setline(641);
// compilenode returning self
  Object call1061 = callmethod(self, "expression",
    0, params);
// compilenode returning call1061
// Begin line 643
  setline(643);
// Begin line 1577
  setline(1577);
// Begin line 642
  setline(642);
// compilenode returning *var_values
  Object call1062 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1062
// compilenode returning call1062
  var_index = alloc_var();
  *var_index = call1062;
  if (call1062 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 643
  setline(643);
  if (strlit1063 == NULL) {
    strlit1063 = alloc_String("rsquare");
  }
// compilenode returning strlit1063
// Begin line 644
  setline(644);
// compilenode returning self
  params[0] = strlit1063;
  Object call1064 = callmethod(self, "expect",
    1, params);
// compilenode returning call1064
// compilenode returning self
  Object call1065 = callmethod(self, "next",
    0, params);
// compilenode returning call1065
// Begin line 645
  setline(645);
// compilenode returning *var_expr
// compilenode returning *var_index
// compilenode returning module_ast
  params[0] = *var_expr;
  params[1] = *var_index;
  Object call1066 = callmethod(module_ast, "astindex",
    2, params);
// compilenode returning call1066
  var_o = alloc_var();
  *var_o = call1066;
  if (call1066 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 646
  setline(646);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call1067 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1067
    if1056 = call1067;
  } else {
  }
// compilenode returning if1056
  return if1056;
}
Object meth_parser_oprec1068(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[26];
  Object *var_o = alloc_var();
  *var_o = args[0];
  Object params[1];
// Begin line 658
  setline(658);
// Begin line 659
  setline(659);
// Begin line 654
  setline(654);
// compilenode returning *var_o
  if (strlit1070 == NULL) {
    strlit1070 = alloc_String("*");
  }
// compilenode returning strlit1070
  params[0] = strlit1070;
  Object opresult1072 = callmethod(*var_o, "==", 1, params);
// compilenode returning opresult1072
  Object if1069;
  if (istrue(opresult1072)) {
// Begin line 656
  setline(656);
// Begin line 655
  setline(655);
  Object num1073 = alloc_Float64(10.0);
// compilenode returning num1073
  return num1073;
// compilenode returning undefined
    if1069 = undefined;
  } else {
// Begin line 658
  setline(658);
// Begin line 659
  setline(659);
// Begin line 656
  setline(656);
// compilenode returning *var_o
  if (strlit1075 == NULL) {
    strlit1075 = alloc_String("/");
  }
// compilenode returning strlit1075
  params[0] = strlit1075;
  Object opresult1077 = callmethod(*var_o, "==", 1, params);
// compilenode returning opresult1077
  Object if1074;
  if (istrue(opresult1077)) {
// Begin line 658
  setline(658);
// Begin line 657
  setline(657);
  Object num1078 = alloc_Float64(10.0);
// compilenode returning num1078
  return num1078;
// compilenode returning undefined
    if1074 = undefined;
  } else {
  }
// compilenode returning if1074
    if1069 = if1074;
  }
// compilenode returning if1069
// Begin line 660
  setline(660);
// Begin line 659
  setline(659);
  Object num1079 = alloc_Float64(5.0);
// compilenode returning num1079
  return num1079;
// compilenode returning undefined
  return undefined;
}
Object meth_parser_toprec1080(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[27];
  Object *var_ops = alloc_var();
  *var_ops = args[0];
  Object params[1];
// Begin line 666
  setline(666);
// Begin line 668
  setline(668);
// Begin line 1577
  setline(1577);
// Begin line 664
  setline(664);
// compilenode returning *var_ops
  Object call1082 = callmethod(*var_ops, "size",
    0, params);
// compilenode returning call1082
// compilenode returning call1082
  Object num1083 = alloc_Float64(0.0);
// compilenode returning num1083
  params[0] = num1083;
  Object opresult1085 = callmethod(call1082, ">", 1, params);
// compilenode returning opresult1085
  Object if1081;
  if (istrue(opresult1085)) {
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 666
  setline(666);
// Begin line 1577
  setline(1577);
// Begin line 665
  setline(665);
// compilenode returning *var_ops
  Object call1086 = callmethod(*var_ops, "last",
    0, params);
// compilenode returning call1086
// compilenode returning call1086
  var_o = alloc_var();
  *var_o = call1086;
  if (call1086 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 666
  setline(666);
// compilenode returning *var_o
// Begin line 667
  setline(667);
// compilenode returning self
  params[0] = *var_o;
  Object call1087 = callmethod(self, "oprec",
    1, params);
// compilenode returning call1087
  return call1087;
// compilenode returning undefined
    if1081 = undefined;
  } else {
  }
// compilenode returning if1081
// Begin line 668
  setline(668);
  Object num1088 = alloc_Float64(0.0);
// compilenode returning num1088
  return num1088;
}
Object meth_parser_expressionrest1089(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[28];
  Object params[3];
  Object *var_values = closure[0];
  Object *var_statementToken = closure[1];
  Object *var_sym = closure[2];
// Begin line 676
  setline(676);
  if (strlit1091 == NULL) {
    strlit1091 = alloc_String("op");
  }
// compilenode returning strlit1091
// Begin line 762
  setline(762);
// compilenode returning self
  params[0] = strlit1091;
  Object call1092 = callmethod(self, "accept",
    1, params);
// compilenode returning call1092
  Object if1090;
  if (istrue(call1092)) {
  Object *var_terms = alloc_var();
  *var_terms = undefined;
  Object *var_ops = alloc_var();
  *var_ops = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
  Object *var_o2 = alloc_var();
  *var_o2 = undefined;
  Object *var_tmp2 = alloc_var();
  *var_tmp2 = undefined;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_prec = alloc_var();
  *var_prec = undefined;
  Object *var_allarith = alloc_var();
  *var_allarith = undefined;
  Object *var_opcount = alloc_var();
  *var_opcount = undefined;
  Object *var_opdtype = alloc_var();
  *var_opdtype = undefined;
// Begin line 678
  setline(678);
  Object array1093 = alloc_List();
// compilenode returning array1093
  var_terms = alloc_var();
  *var_terms = array1093;
  if (array1093 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 679
  setline(679);
  Object array1094 = alloc_List();
// compilenode returning array1094
  var_ops = alloc_var();
  *var_ops = array1094;
  if (array1094 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 680
  setline(680);
  var_o = alloc_var();
  *var_o = undefined;
// compilenode returning nothing
// Begin line 681
  setline(681);
  var_o2 = alloc_var();
  *var_o2 = undefined;
// compilenode returning nothing
// Begin line 682
  setline(682);
  var_tmp2 = alloc_var();
  *var_tmp2 = undefined;
// compilenode returning nothing
// Begin line 683
  setline(683);
// Begin line 1577
  setline(1577);
// Begin line 682
  setline(682);
// compilenode returning *var_values
  Object call1095 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1095
// compilenode returning call1095
  var_tmp = alloc_var();
  *var_tmp = call1095;
  if (call1095 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 683
  setline(683);
// compilenode returning *var_tmp
// compilenode returning *var_terms
  params[0] = *var_tmp;
  Object call1096 = callmethod(*var_terms, "push",
    1, params);
// compilenode returning call1096
// Begin line 685
  setline(685);
  var_prec = alloc_var();
  *var_prec = undefined;
// compilenode returning nothing
// Begin line 686
  setline(686);
// Begin line 685
  setline(685);
  Object bool1097 = alloc_Boolean(1);
// compilenode returning bool1097
  var_allarith = alloc_var();
  *var_allarith = bool1097;
  if (bool1097 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 687
  setline(687);
// Begin line 686
  setline(686);
  Object num1098 = alloc_Float64(0.0);
// compilenode returning num1098
  var_opcount = alloc_var();
  *var_opcount = num1098;
  if (num1098 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 688
  setline(688);
// Begin line 687
  setline(687);
  if (strlit1099 == NULL) {
    strlit1099 = alloc_String("");
  }
// compilenode returning strlit1099
  var_opdtype = alloc_var();
  *var_opdtype = strlit1099;
  if (strlit1099 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 746
  setline(746);
  Object while1100;
  while (1) {
// Begin line 688
  setline(688);
  if (strlit1101 == NULL) {
    strlit1101 = alloc_String("op");
  }
// compilenode returning strlit1101
// compilenode returning *var_statementToken
// Begin line 748
  setline(748);
// compilenode returning self
  params[0] = strlit1101;
  params[1] = *var_statementToken;
  Object call1102 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1102
    while1100 = call1102;
    if (!istrue(call1102)) break;
// Begin line 690
  setline(690);
// Begin line 689
  setline(689);
// compilenode returning *var_opcount
  Object num1103 = alloc_Float64(1.0);
// compilenode returning num1103
  params[0] = num1103;
  Object sum1105 = callmethod(*var_opcount, "+", 1, params);
// compilenode returning sum1105
  *var_opcount = sum1105;
  if (sum1105 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 691
  setline(691);
// Begin line 1577
  setline(1577);
// Begin line 690
  setline(690);
// compilenode returning *var_sym
  Object call1107 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1107
// compilenode returning call1107
  *var_o = call1107;
  if (call1107 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 691
  setline(691);
// compilenode returning self
  Object call1109 = callmethod(self, "next",
    0, params);
// compilenode returning call1109
// Begin line 692
  setline(692);
// compilenode returning *var_o
// Begin line 693
  setline(693);
// compilenode returning self
  params[0] = *var_o;
  Object call1110 = callmethod(self, "oprec",
    1, params);
// compilenode returning call1110
  *var_prec = call1110;
  if (call1110 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 695
  setline(695);
// Begin line 696
  setline(696);
// Begin line 693
  setline(693);
// compilenode returning *var_o
  if (strlit1113 == NULL) {
    strlit1113 = alloc_String("*");
  }
// compilenode returning strlit1113
  params[0] = strlit1113;
  Object opresult1115 = callmethod(*var_o, "/=", 1, params);
// compilenode returning opresult1115
// Begin line 696
  setline(696);
// Begin line 693
  setline(693);
// compilenode returning *var_o
  if (strlit1116 == NULL) {
    strlit1116 = alloc_String("/");
  }
// compilenode returning strlit1116
  params[0] = strlit1116;
  Object opresult1118 = callmethod(*var_o, "/=", 1, params);
// compilenode returning opresult1118
  params[0] = opresult1118;
  Object opresult1120 = callmethod(opresult1115, "&", 1, params);
// compilenode returning opresult1120
// Begin line 696
  setline(696);
// Begin line 693
  setline(693);
// compilenode returning *var_o
  if (strlit1121 == NULL) {
    strlit1121 = alloc_String("+");
  }
// compilenode returning strlit1121
  params[0] = strlit1121;
  Object opresult1123 = callmethod(*var_o, "/=", 1, params);
// compilenode returning opresult1123
  params[0] = opresult1123;
  Object opresult1125 = callmethod(opresult1120, "&", 1, params);
// compilenode returning opresult1125
// Begin line 696
  setline(696);
// Begin line 693
  setline(693);
// compilenode returning *var_o
  if (strlit1126 == NULL) {
    strlit1126 = alloc_String("-");
  }
// compilenode returning strlit1126
  params[0] = strlit1126;
  Object opresult1128 = callmethod(*var_o, "/=", 1, params);
// compilenode returning opresult1128
  params[0] = opresult1128;
  Object opresult1130 = callmethod(opresult1125, "&", 1, params);
// compilenode returning opresult1130
  Object if1112;
  if (istrue(opresult1130)) {
// Begin line 695
  setline(695);
// Begin line 694
  setline(694);
  Object bool1131 = alloc_Boolean(0);
// compilenode returning bool1131
  *var_allarith = bool1131;
  if (bool1131 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1112 = nothing;
  } else {
  }
// compilenode returning if1112
// Begin line 701
  setline(701);
// Begin line 703
  setline(703);
// Begin line 696
  setline(696);
// compilenode returning *var_opdtype
  if (strlit1134 == NULL) {
    strlit1134 = alloc_String("");
  }
// compilenode returning strlit1134
  params[0] = strlit1134;
  Object opresult1136 = callmethod(*var_opdtype, "/=", 1, params);
// compilenode returning opresult1136
// Begin line 703
  setline(703);
// Begin line 696
  setline(696);
// compilenode returning *var_opdtype
// compilenode returning *var_o
  params[0] = *var_o;
  Object opresult1138 = callmethod(*var_opdtype, "/=", 1, params);
// compilenode returning opresult1138
  params[0] = opresult1138;
  Object opresult1140 = callmethod(opresult1136, "&", 1, params);
// compilenode returning opresult1140
// Begin line 703
  setline(703);
// Begin line 1577
  setline(1577);
// Begin line 696
  setline(696);
// compilenode returning *var_allarith
  Object call1141 = callmethod(*var_allarith, "not",
    0, params);
// compilenode returning call1141
// compilenode returning call1141
  params[0] = call1141;
  Object opresult1143 = callmethod(opresult1140, "&", 1, params);
// compilenode returning opresult1143
  Object if1133;
  if (istrue(opresult1143)) {
// Begin line 701
  setline(701);
// Begin line 700
  setline(700);
  if (strlit1144 == NULL) {
    strlit1144 = alloc_String("mixed operators without parentheses: ");
  }
// compilenode returning strlit1144
// Begin line 701
  setline(701);
// compilenode returning *var_opdtype
  params[0] = *var_opdtype;
  Object opresult1146 = callmethod(strlit1144, "++", 1, params);
// compilenode returning opresult1146
  if (strlit1147 == NULL) {
    strlit1147 = alloc_String(" and ");
  }
// compilenode returning strlit1147
  params[0] = strlit1147;
  Object opresult1149 = callmethod(opresult1146, "++", 1, params);
// compilenode returning opresult1149
// compilenode returning *var_o
  params[0] = *var_o;
  Object opresult1151 = callmethod(opresult1149, "++", 1, params);
// compilenode returning opresult1151
// Begin line 700
  setline(700);
// compilenode returning module_util
  params[0] = opresult1151;
  Object call1152 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1152
    if1133 = call1152;
  } else {
  }
// compilenode returning if1133
// Begin line 704
  setline(704);
// Begin line 706
  setline(706);
// Begin line 703
  setline(703);
// compilenode returning *var_o
  if (strlit1154 == NULL) {
    strlit1154 = alloc_String("=");
  }
// compilenode returning strlit1154
  params[0] = strlit1154;
  Object opresult1156 = callmethod(*var_o, "==", 1, params);
// compilenode returning opresult1156
  Object if1153;
  if (istrue(opresult1156)) {
// Begin line 704
  setline(704);
  if (strlit1157 == NULL) {
    strlit1157 = alloc_String("bare '=' outside of def declaration");
  }
// compilenode returning strlit1157
// compilenode returning module_util
  params[0] = strlit1157;
  Object call1158 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1158
    if1153 = call1158;
  } else {
  }
// compilenode returning if1153
// Begin line 707
  setline(707);
// Begin line 706
  setline(706);
// compilenode returning *var_o
  *var_opdtype = *var_o;
  if (*var_o == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 717
  setline(717);
  Object while1160;
  while (1) {
// Begin line 707
  setline(707);
// Begin line 719
  setline(719);
// Begin line 1577
  setline(1577);
// Begin line 707
  setline(707);
// compilenode returning *var_ops
  Object call1161 = callmethod(*var_ops, "size",
    0, params);
// compilenode returning call1161
// compilenode returning call1161
  Object num1162 = alloc_Float64(0.0);
// compilenode returning num1162
  params[0] = num1162;
  Object opresult1164 = callmethod(call1161, ">", 1, params);
// compilenode returning opresult1164
// compilenode returning *var_prec
// compilenode returning *var_ops
// Begin line 719
  setline(719);
// compilenode returning self
  params[0] = *var_ops;
  Object call1165 = callmethod(self, "toprec",
    1, params);
// compilenode returning call1165
  params[0] = call1165;
  Object opresult1167 = callmethod(*var_prec, "<=", 1, params);
// compilenode returning opresult1167
  params[0] = opresult1167;
  Object opresult1169 = callmethod(opresult1164, "&", 1, params);
// compilenode returning opresult1169
    while1160 = opresult1169;
    if (!istrue(opresult1169)) break;
// Begin line 714
  setline(714);
// Begin line 1577
  setline(1577);
// Begin line 713
  setline(713);
// compilenode returning *var_ops
  Object call1170 = callmethod(*var_ops, "pop",
    0, params);
// compilenode returning call1170
// compilenode returning call1170
  *var_o2 = call1170;
  if (call1170 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 715
  setline(715);
// Begin line 1577
  setline(1577);
// Begin line 714
  setline(714);
// compilenode returning *var_terms
  Object call1172 = callmethod(*var_terms, "pop",
    0, params);
// compilenode returning call1172
// compilenode returning call1172
  *var_tmp2 = call1172;
  if (call1172 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 716
  setline(716);
// Begin line 1577
  setline(1577);
// Begin line 715
  setline(715);
// compilenode returning *var_terms
  Object call1174 = callmethod(*var_terms, "pop",
    0, params);
// compilenode returning call1174
// compilenode returning call1174
  *var_tmp = call1174;
  if (call1174 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 716
  setline(716);
// compilenode returning *var_o2
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_o2;
  params[1] = *var_tmp;
  params[2] = *var_tmp2;
  Object call1176 = callmethod(module_ast, "astop",
    3, params);
// compilenode returning call1176
  *var_tmp = call1176;
  if (call1176 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 717
  setline(717);
// compilenode returning *var_tmp
// compilenode returning *var_terms
  params[0] = *var_tmp;
  Object call1178 = callmethod(*var_terms, "push",
    1, params);
// compilenode returning call1178
  }
// compilenode returning while1160
// Begin line 719
  setline(719);
// compilenode returning *var_o
// compilenode returning *var_ops
  params[0] = *var_o;
  Object call1179 = callmethod(*var_ops, "push",
    1, params);
// compilenode returning call1179
// Begin line 735
  setline(735);
// Begin line 720
  setline(720);
  if (strlit1181 == NULL) {
    strlit1181 = alloc_String("lparen");
  }
// compilenode returning strlit1181
// Begin line 742
  setline(742);
// compilenode returning self
  params[0] = strlit1181;
  Object call1182 = callmethod(self, "accept",
    1, params);
// compilenode returning call1182
  Object if1180;
  if (istrue(call1182)) {
// Begin line 727
  setline(727);
// compilenode returning self
  Object call1183 = callmethod(self, "next",
    0, params);
// compilenode returning call1183
// Begin line 729
  setline(729);
// Begin line 728
  setline(728);
  if (strlit1185 == NULL) {
    strlit1185 = alloc_String("rparen");
  }
// compilenode returning strlit1185
// Begin line 731
  setline(731);
// compilenode returning self
  params[0] = strlit1185;
  Object call1186 = callmethod(self, "accept",
    1, params);
// compilenode returning call1186
  Object if1184;
  if (istrue(call1186)) {
// Begin line 729
  setline(729);
  if (strlit1187 == NULL) {
    strlit1187 = alloc_String("empty () in expression (maybe empty interpolated {} block)");
  }
// compilenode returning strlit1187
// compilenode returning module_util
  params[0] = strlit1187;
  Object call1188 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1188
    if1184 = call1188;
  } else {
  }
// compilenode returning if1184
// Begin line 731
  setline(731);
// compilenode returning self
  Object call1189 = callmethod(self, "expression",
    0, params);
// compilenode returning call1189
// Begin line 732
  setline(732);
  if (strlit1190 == NULL) {
    strlit1190 = alloc_String("rparen");
  }
// compilenode returning strlit1190
// Begin line 733
  setline(733);
// compilenode returning self
  params[0] = strlit1190;
  Object call1191 = callmethod(self, "expect",
    1, params);
// compilenode returning call1191
// compilenode returning self
  Object call1192 = callmethod(self, "next",
    0, params);
// compilenode returning call1192
    if1180 = call1192;
  } else {
// Begin line 735
  setline(735);
// compilenode returning self
  Object call1193 = callmethod(self, "term",
    0, params);
// compilenode returning call1193
    if1180 = call1193;
  }
// compilenode returning if1180
// Begin line 742
  setline(742);
// compilenode returning self
  Object call1194 = callmethod(self, "dotrest",
    0, params);
// compilenode returning call1194
// Begin line 743
  setline(743);
// compilenode returning self
  Object call1195 = callmethod(self, "postfixsquare",
    0, params);
// compilenode returning call1195
// Begin line 744
  setline(744);
// compilenode returning self
  Object call1196 = callmethod(self, "callrest",
    0, params);
// compilenode returning call1196
// Begin line 746
  setline(746);
// Begin line 1577
  setline(1577);
// Begin line 745
  setline(745);
// compilenode returning *var_values
  Object call1197 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1197
// compilenode returning call1197
  *var_tmp = call1197;
  if (call1197 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 746
  setline(746);
// compilenode returning *var_tmp
// compilenode returning *var_terms
  params[0] = *var_tmp;
  Object call1199 = callmethod(*var_terms, "push",
    1, params);
// compilenode returning call1199
  }
// compilenode returning while1100
// Begin line 754
  setline(754);
  Object while1200;
  while (1) {
// Begin line 756
  setline(756);
// Begin line 1577
  setline(1577);
// Begin line 748
  setline(748);
// compilenode returning *var_ops
  Object call1201 = callmethod(*var_ops, "size",
    0, params);
// compilenode returning call1201
// compilenode returning call1201
  Object num1202 = alloc_Float64(0.0);
// compilenode returning num1202
  params[0] = num1202;
  Object opresult1204 = callmethod(call1201, ">", 1, params);
// compilenode returning opresult1204
    while1200 = opresult1204;
    if (!istrue(opresult1204)) break;
// Begin line 751
  setline(751);
// Begin line 1577
  setline(1577);
// Begin line 750
  setline(750);
// compilenode returning *var_ops
  Object call1205 = callmethod(*var_ops, "pop",
    0, params);
// compilenode returning call1205
// compilenode returning call1205
  *var_o = call1205;
  if (call1205 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 752
  setline(752);
// Begin line 1577
  setline(1577);
// Begin line 751
  setline(751);
// compilenode returning *var_terms
  Object call1207 = callmethod(*var_terms, "pop",
    0, params);
// compilenode returning call1207
// compilenode returning call1207
  *var_tmp2 = call1207;
  if (call1207 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 753
  setline(753);
// Begin line 1577
  setline(1577);
// Begin line 752
  setline(752);
// compilenode returning *var_terms
  Object call1209 = callmethod(*var_terms, "pop",
    0, params);
// compilenode returning call1209
// compilenode returning call1209
  *var_tmp = call1209;
  if (call1209 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 753
  setline(753);
// compilenode returning *var_o
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_o;
  params[1] = *var_tmp;
  params[2] = *var_tmp2;
  Object call1211 = callmethod(module_ast, "astop",
    3, params);
// compilenode returning call1211
  *var_tmp = call1211;
  if (call1211 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 754
  setline(754);
// compilenode returning *var_tmp
// compilenode returning *var_terms
  params[0] = *var_tmp;
  Object call1213 = callmethod(*var_terms, "push",
    1, params);
// compilenode returning call1213
  }
// compilenode returning while1200
// Begin line 757
  setline(757);
// Begin line 1577
  setline(1577);
// Begin line 756
  setline(756);
// compilenode returning *var_terms
  Object call1214 = callmethod(*var_terms, "pop",
    0, params);
// compilenode returning call1214
// compilenode returning call1214
  *var_tmp = call1214;
  if (call1214 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 757
  setline(757);
// compilenode returning *var_tmp
// compilenode returning *var_values
  params[0] = *var_tmp;
  Object call1216 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1216
// Begin line 759
  setline(759);
// Begin line 761
  setline(761);
// Begin line 1577
  setline(1577);
// Begin line 758
  setline(758);
// compilenode returning *var_terms
  Object call1218 = callmethod(*var_terms, "size",
    0, params);
// compilenode returning call1218
// compilenode returning call1218
  Object num1219 = alloc_Float64(0.0);
// compilenode returning num1219
  params[0] = num1219;
  Object opresult1221 = callmethod(call1218, ">", 1, params);
// compilenode returning opresult1221
  Object if1217;
  if (istrue(opresult1221)) {
// Begin line 759
  setline(759);
  if (strlit1222 == NULL) {
    strlit1222 = alloc_String("values left on term stack");
  }
// compilenode returning strlit1222
// compilenode returning module_util
  params[0] = strlit1222;
  Object call1223 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1223
    if1217 = call1223;
  } else {
  }
// compilenode returning if1217
    if1090 = if1217;
  } else {
  }
// compilenode returning if1090
  return if1090;
}
Object meth_parser_dotrest1224(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[29];
  Object params[2];
  Object *var_values = closure[0];
  Object *var_sym = closure[1];
// Begin line 768
  setline(768);
  if (strlit1226 == NULL) {
    strlit1226 = alloc_String("dot");
  }
// compilenode returning strlit1226
// Begin line 782
  setline(782);
// compilenode returning self
  params[0] = strlit1226;
  Object call1227 = callmethod(self, "accept",
    1, params);
// compilenode returning call1227
  Object if1225;
  if (istrue(call1227)) {
  Object *var_lookuptarget = alloc_var();
  *var_lookuptarget = undefined;
// Begin line 770
  setline(770);
// Begin line 1577
  setline(1577);
// Begin line 769
  setline(769);
// compilenode returning *var_values
  Object call1228 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1228
// compilenode returning call1228
  var_lookuptarget = alloc_var();
  *var_lookuptarget = call1228;
  if (call1228 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 770
  setline(770);
// compilenode returning self
  Object call1229 = callmethod(self, "next",
    0, params);
// compilenode returning call1229
// Begin line 778
  setline(778);
// Begin line 771
  setline(771);
  if (strlit1231 == NULL) {
    strlit1231 = alloc_String("identifier");
  }
// compilenode returning strlit1231
// Begin line 781
  setline(781);
// compilenode returning self
  params[0] = strlit1231;
  Object call1232 = callmethod(self, "accept",
    1, params);
// compilenode returning call1232
  Object if1230;
  if (istrue(call1232)) {
  Object *var_dro = alloc_var();
  *var_dro = undefined;
// Begin line 772
  setline(772);
// Begin line 1577
  setline(1577);
// Begin line 772
  setline(772);
// compilenode returning *var_sym
  Object call1233 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1233
// compilenode returning call1233
// compilenode returning *var_lookuptarget
// compilenode returning module_ast
  params[0] = call1233;
  params[1] = *var_lookuptarget;
  Object call1234 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1234
  var_dro = alloc_var();
  *var_dro = call1234;
  if (call1234 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 773
  setline(773);
// compilenode returning *var_dro
// compilenode returning *var_values
  params[0] = *var_dro;
  Object call1235 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1235
// Begin line 774
  setline(774);
// compilenode returning self
  Object call1236 = callmethod(self, "next",
    0, params);
// compilenode returning call1236
// Begin line 778
  setline(778);
// Begin line 775
  setline(775);
  if (strlit1238 == NULL) {
    strlit1238 = alloc_String("dot");
  }
// compilenode returning strlit1238
// Begin line 780
  setline(780);
// compilenode returning self
  params[0] = strlit1238;
  Object call1239 = callmethod(self, "accept",
    1, params);
// compilenode returning call1239
  Object if1237;
  if (istrue(call1239)) {
// Begin line 776
  setline(776);
// compilenode returning self
  Object call1240 = callmethod(self, "dotrest",
    0, params);
// compilenode returning call1240
    if1237 = call1240;
  } else {
// Begin line 778
  setline(778);
// Begin line 777
  setline(777);
  if (strlit1242 == NULL) {
    strlit1242 = alloc_String("lparen");
  }
// compilenode returning strlit1242
// Begin line 780
  setline(780);
// compilenode returning self
  params[0] = strlit1242;
  Object call1243 = callmethod(self, "accept",
    1, params);
// compilenode returning call1243
  Object if1241;
  if (istrue(call1243)) {
// Begin line 778
  setline(778);
// compilenode returning self
  Object call1244 = callmethod(self, "callrest",
    0, params);
// compilenode returning call1244
    if1241 = call1244;
  } else {
  }
// compilenode returning if1241
    if1237 = if1241;
  }
// compilenode returning if1237
    if1230 = if1237;
  } else {
  }
// compilenode returning if1230
    if1225 = if1230;
  } else {
  }
// compilenode returning if1225
  return if1225;
}
Object meth_parser_apply1262(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 801
  setline(801);
// compilenode returning self
  Object call1263 = callmethod(self, "expression",
    0, params);
// compilenode returning call1263
  return call1263;
}
Object meth_parser_apply1279(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 806
  setline(806);
// compilenode returning self
  Object call1280 = callmethod(self, "expression",
    0, params);
// compilenode returning call1280
  return call1280;
}
Object meth_parser_apply1268(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_values = closure[0];
  Object *var_tmp = closure[1];
  Object *var_params = closure[2];
  Object self = *closure[3];
// Begin line 806
  setline(806);
  Object while1269;
  while (1) {
// Begin line 802
  setline(802);
  if (strlit1270 == NULL) {
    strlit1270 = alloc_String("comma");
  }
// compilenode returning strlit1270
// Begin line 808
  setline(808);
// compilenode returning self
  params[0] = strlit1270;
  Object call1271 = callmethod(self, "accept",
    1, params);
// compilenode returning call1271
    while1269 = call1271;
    if (!istrue(call1271)) break;
// Begin line 804
  setline(804);
// Begin line 1577
  setline(1577);
// Begin line 803
  setline(803);
// compilenode returning *var_values
  Object call1272 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1272
// compilenode returning call1272
  *var_tmp = call1272;
  if (call1272 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 804
  setline(804);
// compilenode returning *var_tmp
// compilenode returning *var_params
  params[0] = *var_tmp;
  Object call1274 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1274
// Begin line 805
  setline(805);
// compilenode returning self
  Object call1275 = callmethod(self, "next",
    0, params);
// compilenode returning call1275
// Begin line 806
  setline(806);
// Begin line 1577
  setline(1577);
  Object obj1277 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1277, self, 0);
  addmethod2(obj1277, "outer", &reader_parser_outer_1278);
  adddatum2(obj1277, self, 0);
  block_savedest(obj1277);
  Object **closure1279 = createclosure(1);
  Object *selfpp1281 = alloc_var();
  *selfpp1281 = self;
  addtoclosure(closure1279, selfpp1281);
  struct UserObject *uo1279 = (struct UserObject*)obj1277;
  uo1279->data[1] = (Object)closure1279;
  addmethod2(obj1277, "apply", &meth_parser_apply1279);
  set_type(obj1277, 0);
// compilenode returning obj1277
  setclassname(obj1277, "Block<parser:1276>");
// compilenode returning obj1277
// Begin line 807
  setline(807);
// compilenode returning self
  params[0] = obj1277;
  Object call1282 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call1282
  }
// compilenode returning while1269
// Begin line 809
  setline(809);
// Begin line 1577
  setline(1577);
// Begin line 808
  setline(808);
// compilenode returning *var_values
  Object call1283 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1283
// compilenode returning call1283
  *var_tmp = call1283;
  if (call1283 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 809
  setline(809);
// compilenode returning *var_tmp
// compilenode returning *var_params
  params[0] = *var_tmp;
  Object call1285 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1285
  return call1285;
}
Object meth_parser_callrest1245(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[30];
  Object params[3];
  Object *var_values = closure[0];
  Object *var_lastToken = closure[1];
  Object *var_minIndentLevel = closure[2];
  Object *var_sym = closure[3];
  Object *var_linenum = closure[4];
  Object *var_meth = alloc_var();
  *var_meth = undefined;
  Object *var_methn = alloc_var();
  *var_methn = undefined;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_ln = alloc_var();
  *var_ln = undefined;
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_hadcall = alloc_var();
  *var_hadcall = undefined;
  Object *var_tok = alloc_var();
  *var_tok = undefined;
  Object *var_startInd = alloc_var();
  *var_startInd = undefined;
// Begin line 789
  setline(789);
// Begin line 1577
  setline(1577);
// Begin line 788
  setline(788);
// compilenode returning *var_values
  Object call1246 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1246
// compilenode returning call1246
  var_meth = alloc_var();
  *var_meth = call1246;
  if (call1246 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 790
  setline(790);
  var_methn = alloc_var();
  *var_methn = undefined;
// compilenode returning nothing
// Begin line 791
  setline(791);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 792
  setline(792);
// Begin line 791
  setline(791);
  Object bool1247 = alloc_Boolean(0);
// compilenode returning bool1247
  var_ln = alloc_var();
  *var_ln = bool1247;
  if (bool1247 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 793
  setline(793);
  Object array1248 = alloc_List();
// compilenode returning array1248
  var_params = alloc_var();
  *var_params = array1248;
  if (array1248 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 794
  setline(794);
// Begin line 793
  setline(793);
  Object bool1249 = alloc_Boolean(0);
// compilenode returning bool1249
  var_hadcall = alloc_var();
  *var_hadcall = bool1249;
  if (bool1249 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 795
  setline(795);
// Begin line 794
  setline(794);
// compilenode returning *var_lastToken
  var_tok = alloc_var();
  *var_tok = *var_lastToken;
  if (*var_lastToken == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 796
  setline(796);
// Begin line 795
  setline(795);
// compilenode returning *var_minIndentLevel
  var_startInd = alloc_var();
  *var_startInd = *var_minIndentLevel;
  if (*var_minIndentLevel == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 840
  setline(840);
// Begin line 796
  setline(796);
  if (strlit1251 == NULL) {
    strlit1251 = alloc_String("lparen");
  }
// compilenode returning strlit1251
// Begin line 842
  setline(842);
// compilenode returning self
  params[0] = strlit1251;
  Object call1252 = callmethod(self, "accept",
    1, params);
// compilenode returning call1252
  Object if1250;
  if (istrue(call1252)) {
// Begin line 798
  setline(798);
// Begin line 797
  setline(797);
// compilenode returning *var_sym
  *var_tok = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 799
  setline(799);
// Begin line 798
  setline(798);
  Object bool1254 = alloc_Boolean(1);
// compilenode returning bool1254
  *var_hadcall = bool1254;
  if (bool1254 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 800
  setline(800);
// Begin line 1577
  setline(1577);
// Begin line 799
  setline(799);
// compilenode returning *var_meth
  Object call1256 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call1256
// compilenode returning call1256
  *var_methn = call1256;
  if (call1256 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 800
  setline(800);
// compilenode returning self
  Object call1258 = callmethod(self, "next",
    0, params);
// compilenode returning call1258
// Begin line 809
  setline(809);
// Begin line 801
  setline(801);
// Begin line 1577
  setline(1577);
  Object obj1260 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1260, self, 0);
  addmethod2(obj1260, "outer", &reader_parser_outer_1261);
  adddatum2(obj1260, self, 0);
  block_savedest(obj1260);
  Object **closure1262 = createclosure(1);
  Object *selfpp1264 = alloc_var();
  *selfpp1264 = self;
  addtoclosure(closure1262, selfpp1264);
  struct UserObject *uo1262 = (struct UserObject*)obj1260;
  uo1262->data[1] = (Object)closure1262;
  addmethod2(obj1260, "apply", &meth_parser_apply1262);
  set_type(obj1260, 0);
// compilenode returning obj1260
  setclassname(obj1260, "Block<parser:1259>");
// compilenode returning obj1260
// Begin line 809
  setline(809);
// Begin line 1577
  setline(1577);
  Object obj1266 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1266, self, 0);
  addmethod2(obj1266, "outer", &reader_parser_outer_1267);
  adddatum2(obj1266, self, 0);
  block_savedest(obj1266);
  Object **closure1268 = createclosure(4);
  addtoclosure(closure1268, var_values);
  addtoclosure(closure1268, var_tmp);
  addtoclosure(closure1268, var_params);
  Object *selfpp1286 = alloc_var();
  *selfpp1286 = self;
  addtoclosure(closure1268, selfpp1286);
  struct UserObject *uo1268 = (struct UserObject*)obj1266;
  uo1268->data[1] = (Object)closure1268;
  addmethod2(obj1266, "apply", &meth_parser_apply1268);
  set_type(obj1266, 0);
// compilenode returning obj1266
  setclassname(obj1266, "Block<parser:1265>");
// compilenode returning obj1266
// Begin line 811
  setline(811);
// compilenode returning self
  params[0] = obj1260;
  params[1] = obj1266;
  Object call1287 = callmethod(self, "ifConsume(1)then",
    2, params);
// compilenode returning call1287
  if (strlit1288 == NULL) {
    strlit1288 = alloc_String("rparen");
  }
// compilenode returning strlit1288
// Begin line 812
  setline(812);
// compilenode returning self
  params[0] = strlit1288;
  Object call1289 = callmethod(self, "expect",
    1, params);
// compilenode returning call1289
// Begin line 813
  setline(813);
// Begin line 812
  setline(812);
// compilenode returning *var_linenum
  *var_ln = *var_linenum;
  if (*var_linenum == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 813
  setline(813);
// compilenode returning self
  Object call1291 = callmethod(self, "next",
    0, params);
// compilenode returning call1291
    if1250 = call1291;
  } else {
// Begin line 840
  setline(840);
// Begin line 816
  setline(816);
// Begin line 815
  setline(815);
// Begin line 814
  setline(814);
  if (strlit1293 == NULL) {
    strlit1293 = alloc_String("string");
  }
// compilenode returning strlit1293
// compilenode returning *var_tok
// Begin line 825
  setline(825);
// compilenode returning self
  params[0] = strlit1293;
  params[1] = *var_tok;
  Object call1294 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1294
// Begin line 814
  setline(814);
  if (strlit1295 == NULL) {
    strlit1295 = alloc_String("num");
  }
// compilenode returning strlit1295
// compilenode returning *var_tok
// compilenode returning self
  params[0] = strlit1295;
  params[1] = *var_tok;
  Object call1296 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1296
  params[0] = call1296;
  Object opresult1298 = callmethod(call1294, "|", 1, params);
// compilenode returning opresult1298
// Begin line 815
  setline(815);
  if (strlit1299 == NULL) {
    strlit1299 = alloc_String("lbrace");
  }
// compilenode returning strlit1299
// compilenode returning *var_tok
// Begin line 814
  setline(814);
// compilenode returning self
  params[0] = strlit1299;
  params[1] = *var_tok;
  Object call1300 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1300
  params[0] = call1300;
  Object opresult1302 = callmethod(opresult1298, "|", 1, params);
// compilenode returning opresult1302
// Begin line 816
  setline(816);
  if (strlit1303 == NULL) {
    strlit1303 = alloc_String("identifier");
  }
// compilenode returning strlit1303
// compilenode returning *var_tok
// Begin line 815
  setline(815);
// compilenode returning self
  params[0] = strlit1303;
  params[1] = *var_tok;
  Object call1304 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1304
// Begin line 816
  setline(816);
// Begin line 1577
  setline(1577);
// Begin line 816
  setline(816);
// compilenode returning *var_sym
  Object call1305 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1305
// compilenode returning call1305
  if (strlit1306 == NULL) {
    strlit1306 = alloc_String("true");
  }
// compilenode returning strlit1306
  params[0] = strlit1306;
  Object opresult1308 = callmethod(call1305, "==", 1, params);
// compilenode returning opresult1308
// Begin line 1577
  setline(1577);
// Begin line 817
  setline(817);
// compilenode returning *var_sym
  Object call1309 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1309
// compilenode returning call1309
  if (strlit1310 == NULL) {
    strlit1310 = alloc_String("false");
  }
// compilenode returning strlit1310
  params[0] = strlit1310;
  Object opresult1312 = callmethod(call1309, "==", 1, params);
// compilenode returning opresult1312
  params[0] = opresult1312;
  Object opresult1314 = callmethod(opresult1308, "|", 1, params);
// compilenode returning opresult1314
  params[0] = opresult1314;
  Object opresult1316 = callmethod(call1304, "&", 1, params);
// compilenode returning opresult1316
  params[0] = opresult1316;
  Object opresult1318 = callmethod(opresult1302, "|", 1, params);
// compilenode returning opresult1318
  Object if1292;
  if (istrue(opresult1318)) {
  Object *var_ar = alloc_var();
  *var_ar = undefined;
// Begin line 819
  setline(819);
// Begin line 818
  setline(818);
// compilenode returning *var_sym
  *var_tok = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 820
  setline(820);
// Begin line 819
  setline(819);
  Object bool1320 = alloc_Boolean(1);
// compilenode returning bool1320
  *var_hadcall = bool1320;
  if (bool1320 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 821
  setline(821);
// Begin line 1577
  setline(1577);
// Begin line 820
  setline(820);
// compilenode returning *var_meth
  Object call1322 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call1322
// compilenode returning call1322
  *var_methn = call1322;
  if (call1322 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 822
  setline(822);
// Begin line 821
  setline(821);
// compilenode returning *var_linenum
  *var_ln = *var_linenum;
  if (*var_linenum == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 822
  setline(822);
// compilenode returning self
  Object call1325 = callmethod(self, "term",
    0, params);
// compilenode returning call1325
// Begin line 824
  setline(824);
// Begin line 1577
  setline(1577);
// Begin line 823
  setline(823);
// compilenode returning *var_values
  Object call1326 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1326
// compilenode returning call1326
  var_ar = alloc_var();
  *var_ar = call1326;
  if (call1326 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 824
  setline(824);
// compilenode returning *var_ar
// compilenode returning *var_params
  params[0] = *var_ar;
  Object call1327 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1327
    if1292 = call1327;
  } else {
// Begin line 840
  setline(840);
// Begin line 827
  setline(827);
// Begin line 1577
  setline(1577);
// Begin line 825
  setline(825);
// compilenode returning *var_meth
  Object call1329 = callmethod(*var_meth, "kind",
    0, params);
// compilenode returning call1329
// compilenode returning call1329
  if (strlit1330 == NULL) {
    strlit1330 = alloc_String("identifier");
  }
// compilenode returning strlit1330
  params[0] = strlit1330;
  Object opresult1332 = callmethod(call1329, "==", 1, params);
// compilenode returning opresult1332
  Object if1328;
  if (istrue(opresult1332)) {
// Begin line 826
  setline(826);
// compilenode returning *var_meth
// compilenode returning *var_values
  params[0] = *var_meth;
  Object call1333 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1333
    if1328 = call1333;
  } else {
// Begin line 840
  setline(840);
// Begin line 839
  setline(839);
// Begin line 1577
  setline(1577);
// Begin line 827
  setline(827);
// compilenode returning *var_meth
  Object call1335 = callmethod(*var_meth, "kind",
    0, params);
// compilenode returning call1335
// compilenode returning call1335
  if (strlit1336 == NULL) {
    strlit1336 = alloc_String("member");
  }
// compilenode returning strlit1336
  params[0] = strlit1336;
  Object opresult1338 = callmethod(call1335, "==", 1, params);
// compilenode returning opresult1338
  Object if1334;
  if (istrue(opresult1338)) {
  Object *var_root = alloc_var();
  *var_root = undefined;
  Object *var_outroot = alloc_var();
  *var_outroot = undefined;
// Begin line 829
  setline(829);
// Begin line 1577
  setline(1577);
// Begin line 828
  setline(828);
// compilenode returning *var_meth
  Object call1339 = callmethod(*var_meth, "in",
    0, params);
// compilenode returning call1339
// compilenode returning call1339
  var_root = alloc_var();
  *var_root = call1339;
  if (call1339 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 830
  setline(830);
// Begin line 829
  setline(829);
// compilenode returning *var_meth
  var_outroot = alloc_var();
  *var_outroot = *var_meth;
  if (*var_meth == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 833
  setline(833);
  Object while1340;
  while (1) {
// Begin line 834
  setline(834);
// Begin line 1577
  setline(1577);
// Begin line 830
  setline(830);
// compilenode returning *var_root
  Object call1341 = callmethod(*var_root, "kind",
    0, params);
// compilenode returning call1341
// compilenode returning call1341
  if (strlit1342 == NULL) {
    strlit1342 = alloc_String("member");
  }
// compilenode returning strlit1342
  params[0] = strlit1342;
  Object opresult1344 = callmethod(call1341, "==", 1, params);
// compilenode returning opresult1344
    while1340 = opresult1344;
    if (!istrue(opresult1344)) break;
// Begin line 832
  setline(832);
// Begin line 831
  setline(831);
// compilenode returning *var_root
  *var_outroot = *var_root;
  if (*var_root == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 833
  setline(833);
// Begin line 1577
  setline(1577);
// Begin line 832
  setline(832);
// compilenode returning *var_root
  Object call1346 = callmethod(*var_root, "in",
    0, params);
// compilenode returning call1346
// compilenode returning call1346
  *var_root = call1346;
  if (call1346 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while1340
// Begin line 837
  setline(837);
// Begin line 839
  setline(839);
// Begin line 1577
  setline(1577);
// Begin line 834
  setline(834);
// compilenode returning *var_root
  Object call1349 = callmethod(*var_root, "kind",
    0, params);
// compilenode returning call1349
// compilenode returning call1349
  if (strlit1350 == NULL) {
    strlit1350 = alloc_String("identifier");
  }
// compilenode returning strlit1350
  params[0] = strlit1350;
  Object opresult1352 = callmethod(call1349, "==", 1, params);
// compilenode returning opresult1352
  Object if1348;
  if (istrue(opresult1352)) {
// Begin line 835
  setline(835);
// compilenode returning *var_meth
// compilenode returning *var_values
  params[0] = *var_meth;
  Object call1353 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1353
    if1348 = call1353;
  } else {
// Begin line 837
  setline(837);
// compilenode returning *var_meth
// compilenode returning *var_values
  params[0] = *var_meth;
  Object call1354 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1354
    if1348 = call1354;
  }
// compilenode returning if1348
    if1334 = if1348;
  } else {
// Begin line 840
  setline(840);
// compilenode returning *var_meth
// compilenode returning *var_values
  params[0] = *var_meth;
  Object call1355 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1355
    if1334 = call1355;
  }
// compilenode returning if1334
    if1328 = if1334;
  }
// compilenode returning if1328
    if1292 = if1328;
  }
// compilenode returning if1292
    if1250 = if1292;
  }
// compilenode returning if1250
// Begin line 856
  setline(856);
// Begin line 842
  setline(842);
// compilenode returning *var_hadcall
  Object if1356;
  if (istrue(*var_hadcall)) {
// Begin line 853
  setline(853);
// Begin line 843
  setline(843);
  if (strlit1358 == NULL) {
    strlit1358 = alloc_String("identifier");
  }
// compilenode returning strlit1358
// compilenode returning *var_tok
// Begin line 855
  setline(855);
// compilenode returning self
  params[0] = strlit1358;
  params[1] = *var_tok;
  Object call1359 = callmethod(self, "accept(1)onLineOfLastOr",
    2, params);
// compilenode returning call1359
  Object if1357;
  if (istrue(call1359)) {
// Begin line 845
  setline(845);
// compilenode returning *var_methn
  Object bool1360 = alloc_Boolean(0);
// compilenode returning bool1360
// compilenode returning module_ast
  params[0] = *var_methn;
  params[1] = bool1360;
  Object call1361 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1361
// compilenode returning *var_params
// compilenode returning *var_tok
// Begin line 846
  setline(846);
// compilenode returning self
  params[0] = call1361;
  params[1] = *var_params;
  params[2] = *var_tok;
  Object call1362 = callmethod(self, "callmprest",
    3, params);
// compilenode returning call1362
  *var_methn = call1362;
  if (call1362 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 853
  setline(853);
// Begin line 854
  setline(854);
// Begin line 1577
  setline(1577);
// Begin line 846
  setline(846);
// compilenode returning *var_meth
  Object call1365 = callmethod(*var_meth, "kind",
    0, params);
// compilenode returning call1365
// compilenode returning call1365
  if (strlit1366 == NULL) {
    strlit1366 = alloc_String("member");
  }
// compilenode returning strlit1366
  params[0] = strlit1366;
  Object opresult1368 = callmethod(call1365, "==", 1, params);
// compilenode returning opresult1368
  Object if1364;
  if (istrue(opresult1368)) {
// Begin line 850
  setline(850);
// Begin line 1577
  setline(1577);
// Begin line 850
  setline(850);
// compilenode returning *var_methn
  Object call1369 = callmethod(*var_methn, "value",
    0, params);
// compilenode returning call1369
// compilenode returning call1369
// Begin line 1577
  setline(1577);
// Begin line 850
  setline(850);
// compilenode returning *var_meth
  Object call1370 = callmethod(*var_meth, "in",
    0, params);
// compilenode returning call1370
// compilenode returning call1370
// compilenode returning module_ast
  params[0] = call1369;
  params[1] = call1370;
  Object call1371 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1371
  *var_meth = call1371;
  if (call1371 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1364 = nothing;
  } else {
// Begin line 853
  setline(853);
// Begin line 852
  setline(852);
// compilenode returning *var_methn
  *var_meth = *var_methn;
  if (*var_methn == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1364 = nothing;
  }
// compilenode returning if1364
    if1357 = if1364;
  } else {
  }
// compilenode returning if1357
// Begin line 855
  setline(855);
// compilenode returning *var_meth
// compilenode returning *var_params
// compilenode returning module_ast
  params[0] = *var_meth;
  params[1] = *var_params;
  Object call1374 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1374
  *var_tmp = call1374;
  if (call1374 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 856
  setline(856);
// compilenode returning *var_tmp
// compilenode returning *var_values
  params[0] = *var_tmp;
  Object call1376 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1376
    if1356 = call1376;
  } else {
  }
// compilenode returning if1356
// Begin line 859
  setline(859);
// Begin line 858
  setline(858);
// compilenode returning *var_startInd
  *var_minIndentLevel = *var_startInd;
  if (*var_startInd == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 859
  setline(859);
// compilenode returning self
  Object call1378 = callmethod(self, "dotrest",
    0, params);
// compilenode returning call1378
  return call1378;
}
Object meth_parser_apply1392(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_methname = closure[0];
  Object *var_params = closure[1];
  Object *var_lastparamcount = closure[2];
  Object self = *closure[3];
// Begin line 876
  setline(876);
// Begin line 875
  setline(875);
// compilenode returning *var_methname
// Begin line 876
  setline(876);
// Begin line 875
  setline(875);
  if (strlit1393 == NULL) {
    strlit1393 = alloc_String("(");
  }
// compilenode returning strlit1393
// Begin line 876
  setline(876);
// Begin line 1577
  setline(1577);
// Begin line 875
  setline(875);
// compilenode returning *var_params
  Object call1394 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call1394
// compilenode returning call1394
// compilenode returning *var_lastparamcount
  params[0] = *var_lastparamcount;
  Object diff1396 = callmethod(call1394, "-", 1, params);
// compilenode returning diff1396
  params[0] = diff1396;
  Object opresult1398 = callmethod(strlit1393, "++", 1, params);
// compilenode returning opresult1398
  if (strlit1399 == NULL) {
    strlit1399 = alloc_String(")");
  }
// compilenode returning strlit1399
  params[0] = strlit1399;
  Object opresult1401 = callmethod(opresult1398, "++", 1, params);
// compilenode returning opresult1401
  params[0] = opresult1401;
  Object opresult1403 = callmethod(*var_methname, "++", 1, params);
// compilenode returning opresult1403
  *var_methname = opresult1403;
  if (opresult1403 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 877
  setline(877);
// Begin line 1577
  setline(1577);
// Begin line 876
  setline(876);
// compilenode returning *var_params
  Object call1405 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call1405
// compilenode returning call1405
  *var_lastparamcount = call1405;
  if (call1405 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply1411(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_methname = closure[0];
  Object self = *closure[1];
// Begin line 878
  setline(878);
  Object bool1412 = alloc_Boolean(0);
// compilenode returning bool1412
// Begin line 880
  setline(880);
// Begin line 879
  setline(879);
// compilenode returning *var_methname
  if (strlit1413 == NULL) {
    strlit1413 = alloc_String("()");
  }
// compilenode returning strlit1413
  params[0] = strlit1413;
  Object opresult1415 = callmethod(*var_methname, "++", 1, params);
// compilenode returning opresult1415
  *var_methname = opresult1415;
  if (opresult1415 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply1492(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 908
  setline(908);
// compilenode returning self
  Object call1493 = callmethod(self, "expression",
    0, params);
// compilenode returning call1493
  return call1493;
}
Object meth_parser_callmprest1379(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[31];
  Object *var_meth = alloc_var();
  *var_meth = args[0];
  Object *var_params = alloc_var();
  *var_params = args[1];
  Object *var_tok = alloc_var();
  *var_tok = args[2];
  Object params[2];
  Object *var_linenum = closure[0];
  Object *var_lastToken = closure[1];
  Object *var_values = closure[2];
  Object *var_sym = closure[3];
  Object *var_lastline = closure[4];
  Object *var_methname = alloc_var();
  *var_methname = undefined;
  Object *var_nxt = alloc_var();
  *var_nxt = undefined;
  Object *var_ln = alloc_var();
  *var_ln = undefined;
  Object *var_lastparamcount = alloc_var();
  *var_lastparamcount = undefined;
// Begin line 867
  setline(867);
// Begin line 1577
  setline(1577);
// Begin line 866
  setline(866);
// compilenode returning *var_meth
  Object call1380 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call1380
// compilenode returning call1380
  var_methname = alloc_var();
  *var_methname = call1380;
  if (call1380 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 868
  setline(868);
  var_nxt = alloc_var();
  *var_nxt = undefined;
// compilenode returning nothing
// Begin line 869
  setline(869);
// Begin line 868
  setline(868);
// compilenode returning *var_linenum
  var_ln = alloc_var();
  *var_ln = *var_linenum;
  if (*var_linenum == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 870
  setline(870);
// Begin line 869
  setline(869);
  Object num1381 = alloc_Float64(0.0);
// compilenode returning num1381
  var_lastparamcount = alloc_var();
  *var_lastparamcount = num1381;
  if (num1381 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 918
  setline(918);
  Object while1382;
  while (1) {
// Begin line 871
  setline(871);
// Begin line 870
  setline(870);
  if (strlit1383 == NULL) {
    strlit1383 = alloc_String("identifier");
  }
// compilenode returning strlit1383
// compilenode returning *var_tok
// Begin line 921
  setline(921);
// compilenode returning self
  params[0] = strlit1383;
  params[1] = *var_tok;
  Object call1384 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1384
// Begin line 871
  setline(871);
  if (strlit1385 == NULL) {
    strlit1385 = alloc_String("identifier");
  }
// compilenode returning strlit1385
// compilenode returning *var_lastToken
// Begin line 870
  setline(870);
// compilenode returning self
  params[0] = strlit1385;
  params[1] = *var_lastToken;
  Object call1386 = callmethod(self, "accept(1)onLineOf",
    2, params);
// compilenode returning call1386
  params[0] = call1386;
  Object opresult1388 = callmethod(call1384, "|", 1, params);
// compilenode returning opresult1388
    while1382 = opresult1388;
    if (!istrue(opresult1388)) break;
  Object *var_isTerm = alloc_var();
  *var_isTerm = undefined;
// Begin line 880
  setline(880);
// Begin line 877
  setline(877);
// Begin line 1577
  setline(1577);
  Object obj1390 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1390, self, 0);
  addmethod2(obj1390, "outer", &reader_parser_outer_1391);
  adddatum2(obj1390, self, 0);
  block_savedest(obj1390);
  Object **closure1392 = createclosure(4);
  addtoclosure(closure1392, var_methname);
  addtoclosure(closure1392, var_params);
  addtoclosure(closure1392, var_lastparamcount);
  Object *selfpp1407 = alloc_var();
  *selfpp1407 = self;
  addtoclosure(closure1392, selfpp1407);
  struct UserObject *uo1392 = (struct UserObject*)obj1390;
  uo1392->data[1] = (Object)closure1392;
  addmethod2(obj1390, "apply", &meth_parser_apply1392);
  set_type(obj1390, 0);
// compilenode returning obj1390
  setclassname(obj1390, "Block<parser:1389>");
// compilenode returning obj1390
// Begin line 880
  setline(880);
// Begin line 1577
  setline(1577);
  Object obj1409 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1409, self, 0);
  addmethod2(obj1409, "outer", &reader_parser_outer_1410);
  adddatum2(obj1409, self, 0);
  block_savedest(obj1409);
  Object **closure1411 = createclosure(2);
  addtoclosure(closure1411, var_methname);
  Object *selfpp1417 = alloc_var();
  *selfpp1417 = self;
  addtoclosure(closure1411, selfpp1417);
  struct UserObject *uo1411 = (struct UserObject*)obj1409;
  uo1411->data[1] = (Object)closure1411;
  addmethod2(obj1409, "apply", &meth_parser_apply1411);
  set_type(obj1409, 0);
// compilenode returning obj1409
  setclassname(obj1409, "Block<parser:1408>");
// compilenode returning obj1409
// Begin line 874
  setline(874);
// compilenode returning module_util
  params[0] = obj1390;
  params[1] = obj1409;
  Object call1418 = callmethod(module_util, "runOnNew(1)else",
    2, params);
// compilenode returning call1418
// Begin line 881
  setline(881);
// compilenode returning self
  Object call1419 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1419
// Begin line 883
  setline(883);
// Begin line 1577
  setline(1577);
// Begin line 882
  setline(882);
// compilenode returning *var_values
  Object call1420 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1420
// compilenode returning call1420
  *var_nxt = call1420;
  if (call1420 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 884
  setline(884);
// Begin line 883
  setline(883);
// compilenode returning *var_methname
// Begin line 884
  setline(884);
// Begin line 1577
  setline(1577);
// Begin line 883
  setline(883);
// compilenode returning *var_nxt
  Object call1422 = callmethod(*var_nxt, "value",
    0, params);
// compilenode returning call1422
// compilenode returning call1422
  params[0] = call1422;
  Object opresult1424 = callmethod(*var_methname, "++", 1, params);
// compilenode returning opresult1424
  *var_methname = opresult1424;
  if (opresult1424 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 885
  setline(885);
// Begin line 884
  setline(884);
  Object bool1426 = alloc_Boolean(0);
// compilenode returning bool1426
  var_isTerm = alloc_var();
  *var_isTerm = bool1426;
  if (bool1426 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 887
  setline(887);
// Begin line 886
  setline(886);
// Begin line 885
  setline(885);
// Begin line 1577
  setline(1577);
// Begin line 885
  setline(885);
  if (strlit1428 == NULL) {
    strlit1428 = alloc_String("lparen");
  }
// compilenode returning strlit1428
// Begin line 889
  setline(889);
// compilenode returning self
  params[0] = strlit1428;
  Object call1429 = callmethod(self, "accept",
    1, params);
// compilenode returning call1429
  Object call1430 = callmethod(call1429, "not",
    0, params);
// compilenode returning call1430
// compilenode returning call1430
// Begin line 885
  setline(885);
// Begin line 1577
  setline(1577);
// Begin line 885
  setline(885);
  if (strlit1431 == NULL) {
    strlit1431 = alloc_String("lbrace");
  }
// compilenode returning strlit1431
// compilenode returning self
  params[0] = strlit1431;
  Object call1432 = callmethod(self, "accept",
    1, params);
// compilenode returning call1432
  Object call1433 = callmethod(call1432, "not",
    0, params);
// compilenode returning call1433
// compilenode returning call1433
  params[0] = call1433;
  Object opresult1435 = callmethod(call1430, "&", 1, params);
// compilenode returning opresult1435
// Begin line 886
  setline(886);
// Begin line 1577
  setline(1577);
// Begin line 886
  setline(886);
  if (strlit1436 == NULL) {
    strlit1436 = alloc_String("string");
  }
// compilenode returning strlit1436
// Begin line 885
  setline(885);
// compilenode returning self
  params[0] = strlit1436;
  Object call1437 = callmethod(self, "accept",
    1, params);
// compilenode returning call1437
  Object call1438 = callmethod(call1437, "not",
    0, params);
// compilenode returning call1438
// compilenode returning call1438
  params[0] = call1438;
  Object opresult1440 = callmethod(opresult1435, "&", 1, params);
// compilenode returning opresult1440
// Begin line 886
  setline(886);
// Begin line 1577
  setline(1577);
// Begin line 886
  setline(886);
  if (strlit1441 == NULL) {
    strlit1441 = alloc_String("num");
  }
// compilenode returning strlit1441
// compilenode returning self
  params[0] = strlit1441;
  Object call1442 = callmethod(self, "accept",
    1, params);
// compilenode returning call1442
  Object call1443 = callmethod(call1442, "not",
    0, params);
// compilenode returning call1443
// compilenode returning call1443
  params[0] = call1443;
  Object opresult1445 = callmethod(opresult1440, "&", 1, params);
// compilenode returning opresult1445
  Object if1427;
  if (istrue(opresult1445)) {
// Begin line 887
  setline(887);
  if (strlit1446 == NULL) {
    strlit1446 = alloc_String("multi-part method name parameters require .");
  }
// compilenode returning strlit1446
// compilenode returning module_util
  params[0] = strlit1446;
  Object call1447 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1447
    if1427 = call1447;
  } else {
  }
// compilenode returning if1427
// Begin line 897
  setline(897);
// Begin line 892
  setline(892);
// Begin line 891
  setline(891);
// Begin line 890
  setline(890);
// Begin line 889
  setline(889);
  if (strlit1449 == NULL) {
    strlit1449 = alloc_String("lbrace");
  }
// compilenode returning strlit1449
// compilenode returning *var_tok
// Begin line 899
  setline(899);
// compilenode returning self
  params[0] = strlit1449;
  params[1] = *var_tok;
  Object call1450 = callmethod(self, "accept(1)onLineOfLastOr",
    2, params);
// compilenode returning call1450
// Begin line 890
  setline(890);
  if (strlit1451 == NULL) {
    strlit1451 = alloc_String("string");
  }
// compilenode returning strlit1451
// compilenode returning *var_tok
// Begin line 889
  setline(889);
// compilenode returning self
  params[0] = strlit1451;
  params[1] = *var_tok;
  Object call1452 = callmethod(self, "accept(1)onLineOfLastOr",
    2, params);
// compilenode returning call1452
  params[0] = call1452;
  Object opresult1454 = callmethod(call1450, "|", 1, params);
// compilenode returning opresult1454
// Begin line 891
  setline(891);
  if (strlit1455 == NULL) {
    strlit1455 = alloc_String("num");
  }
// compilenode returning strlit1455
// compilenode returning *var_tok
// Begin line 890
  setline(890);
// compilenode returning self
  params[0] = strlit1455;
  params[1] = *var_tok;
  Object call1456 = callmethod(self, "accept(1)onLineOfLastOr",
    2, params);
// compilenode returning call1456
  params[0] = call1456;
  Object opresult1458 = callmethod(opresult1454, "|", 1, params);
// compilenode returning opresult1458
// Begin line 892
  setline(892);
  if (strlit1459 == NULL) {
    strlit1459 = alloc_String("identifier");
  }
// compilenode returning strlit1459
// compilenode returning *var_tok
// Begin line 891
  setline(891);
// compilenode returning self
  params[0] = strlit1459;
  params[1] = *var_tok;
  Object call1460 = callmethod(self, "accept(1)onLineOfLastOr",
    2, params);
// compilenode returning call1460
// Begin line 892
  setline(892);
// Begin line 1577
  setline(1577);
// Begin line 893
  setline(893);
// compilenode returning *var_sym
  Object call1461 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1461
// compilenode returning call1461
  if (strlit1462 == NULL) {
    strlit1462 = alloc_String("true");
  }
// compilenode returning strlit1462
  params[0] = strlit1462;
  Object opresult1464 = callmethod(call1461, "==", 1, params);
// compilenode returning opresult1464
// Begin line 892
  setline(892);
// Begin line 1577
  setline(1577);
// Begin line 894
  setline(894);
// compilenode returning *var_sym
  Object call1465 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1465
// compilenode returning call1465
  if (strlit1466 == NULL) {
    strlit1466 = alloc_String("false");
  }
// compilenode returning strlit1466
  params[0] = strlit1466;
  Object opresult1468 = callmethod(call1465, "==", 1, params);
// compilenode returning opresult1468
  params[0] = opresult1468;
  Object opresult1470 = callmethod(opresult1464, "|", 1, params);
// compilenode returning opresult1470
  params[0] = opresult1470;
  Object opresult1472 = callmethod(call1460, "&", 1, params);
// compilenode returning opresult1472
  params[0] = opresult1472;
  Object opresult1474 = callmethod(opresult1458, "|", 1, params);
// compilenode returning opresult1474
  Object if1448;
  if (istrue(opresult1474)) {
// Begin line 896
  setline(896);
// Begin line 895
  setline(895);
  Object bool1475 = alloc_Boolean(1);
// compilenode returning bool1475
  *var_isTerm = bool1475;
  if (bool1475 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1448 = nothing;
  } else {
// Begin line 897
  setline(897);
// compilenode returning self
  Object call1477 = callmethod(self, "next",
    0, params);
// compilenode returning call1477
    if1448 = call1477;
  }
// compilenode returning if1448
// Begin line 908
  setline(908);
// Begin line 899
  setline(899);
// compilenode returning *var_isTerm
  Object if1478;
  if (istrue(*var_isTerm)) {
// Begin line 901
  setline(901);
// Begin line 900
  setline(900);
// compilenode returning *var_lastline
  *var_ln = *var_lastline;
  if (*var_lastline == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 901
  setline(901);
// compilenode returning self
  Object call1480 = callmethod(self, "term",
    0, params);
// compilenode returning call1480
    if1478 = call1480;
  } else {
// Begin line 903
  setline(903);
// compilenode returning self
  Object call1481 = callmethod(self, "expression",
    0, params);
// compilenode returning call1481
// Begin line 908
  setline(908);
  Object while1482;
  while (1) {
// Begin line 904
  setline(904);
  if (strlit1483 == NULL) {
    strlit1483 = alloc_String("comma");
  }
// compilenode returning strlit1483
// Begin line 910
  setline(910);
// compilenode returning self
  params[0] = strlit1483;
  Object call1484 = callmethod(self, "accept",
    1, params);
// compilenode returning call1484
    while1482 = call1484;
    if (!istrue(call1484)) break;
// Begin line 906
  setline(906);
// Begin line 1577
  setline(1577);
// Begin line 905
  setline(905);
// compilenode returning *var_values
  Object call1485 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1485
// compilenode returning call1485
  *var_nxt = call1485;
  if (call1485 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 906
  setline(906);
// compilenode returning *var_nxt
// compilenode returning *var_params
  params[0] = *var_nxt;
  Object call1487 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1487
// Begin line 907
  setline(907);
// compilenode returning self
  Object call1488 = callmethod(self, "next",
    0, params);
// compilenode returning call1488
// Begin line 908
  setline(908);
// Begin line 1577
  setline(1577);
  Object obj1490 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1490, self, 0);
  addmethod2(obj1490, "outer", &reader_parser_outer_1491);
  adddatum2(obj1490, self, 0);
  block_savedest(obj1490);
  Object **closure1492 = createclosure(1);
  Object *selfpp1494 = alloc_var();
  *selfpp1494 = self;
  addtoclosure(closure1492, selfpp1494);
  struct UserObject *uo1492 = (struct UserObject*)obj1490;
  uo1492->data[1] = (Object)closure1492;
  addmethod2(obj1490, "apply", &meth_parser_apply1492);
  set_type(obj1490, 0);
// compilenode returning obj1490
  setclassname(obj1490, "Block<parser:1489>");
// compilenode returning obj1490
// Begin line 909
  setline(909);
// compilenode returning self
  params[0] = obj1490;
  Object call1495 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call1495
  }
// compilenode returning while1482
    if1478 = while1482;
  }
// compilenode returning if1478
// Begin line 912
  setline(912);
// Begin line 1577
  setline(1577);
// Begin line 911
  setline(911);
// compilenode returning *var_values
  Object call1496 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1496
// compilenode returning call1496
  *var_nxt = call1496;
  if (call1496 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 912
  setline(912);
// compilenode returning *var_nxt
// compilenode returning *var_params
  params[0] = *var_nxt;
  Object call1498 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1498
// Begin line 914
  setline(914);
// Begin line 916
  setline(916);
// Begin line 1577
  setline(1577);
// Begin line 913
  setline(913);
// compilenode returning *var_isTerm
  Object call1500 = callmethod(*var_isTerm, "not",
    0, params);
// compilenode returning call1500
// compilenode returning call1500
  Object if1499;
  if (istrue(call1500)) {
// Begin line 914
  setline(914);
  if (strlit1501 == NULL) {
    strlit1501 = alloc_String("rparen");
  }
// compilenode returning strlit1501
// Begin line 915
  setline(915);
// compilenode returning self
  params[0] = strlit1501;
  Object call1502 = callmethod(self, "expect",
    1, params);
// compilenode returning call1502
    if1499 = call1502;
  } else {
  }
// compilenode returning if1499
// Begin line 918
  setline(918);
// Begin line 916
  setline(916);
  if (strlit1504 == NULL) {
    strlit1504 = alloc_String("rparen");
  }
// compilenode returning strlit1504
// Begin line 920
  setline(920);
// compilenode returning self
  params[0] = strlit1504;
  Object call1505 = callmethod(self, "accept",
    1, params);
// compilenode returning call1505
// Begin line 916
  setline(916);
// Begin line 1577
  setline(1577);
// Begin line 916
  setline(916);
// compilenode returning *var_isTerm
  Object call1506 = callmethod(*var_isTerm, "not",
    0, params);
// compilenode returning call1506
// compilenode returning call1506
  params[0] = call1506;
  Object opresult1508 = callmethod(call1505, "&", 1, params);
// compilenode returning opresult1508
  Object if1503;
  if (istrue(opresult1508)) {
// Begin line 918
  setline(918);
// Begin line 917
  setline(917);
// compilenode returning *var_lastline
  *var_ln = *var_lastline;
  if (*var_lastline == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 918
  setline(918);
// compilenode returning self
  Object call1510 = callmethod(self, "next",
    0, params);
// compilenode returning call1510
    if1503 = call1510;
  } else {
  }
// compilenode returning if1503
  }
// compilenode returning while1382
// Begin line 921
  setline(921);
// compilenode returning *var_methname
  Object bool1511 = alloc_Boolean(0);
// compilenode returning bool1511
// compilenode returning module_ast
  params[0] = *var_methname;
  params[1] = bool1511;
  Object call1512 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1512
  return call1512;
}
Object meth_parser_defdec1513(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[32];
  Object params[3];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 926
  setline(926);
  if (strlit1515 == NULL) {
    strlit1515 = alloc_String("keyword");
  }
// compilenode returning strlit1515
// Begin line 949
  setline(949);
// compilenode returning self
  params[0] = strlit1515;
  Object call1516 = callmethod(self, "accept",
    1, params);
// compilenode returning call1516
// Begin line 926
  setline(926);
// Begin line 1577
  setline(1577);
// Begin line 926
  setline(926);
// compilenode returning *var_sym
  Object call1517 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1517
// compilenode returning call1517
  if (strlit1518 == NULL) {
    strlit1518 = alloc_String("def");
  }
// compilenode returning strlit1518
  params[0] = strlit1518;
  Object opresult1520 = callmethod(call1517, "==", 1, params);
// compilenode returning opresult1520
  params[0] = opresult1520;
  Object opresult1522 = callmethod(call1516, "&", 1, params);
// compilenode returning opresult1522
  Object if1514;
  if (istrue(opresult1522)) {
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_dtype = alloc_var();
  *var_dtype = undefined;
  Object *var_name = alloc_var();
  *var_name = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 927
  setline(927);
// compilenode returning self
  Object call1523 = callmethod(self, "next",
    0, params);
// compilenode returning call1523
// Begin line 928
  setline(928);
// compilenode returning self
  Object call1524 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1524
// Begin line 930
  setline(930);
// Begin line 929
  setline(929);
  Object bool1525 = alloc_Boolean(0);
// compilenode returning bool1525
  var_val = alloc_var();
  *var_val = bool1525;
  if (bool1525 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 930
  setline(930);
  if (strlit1526 == NULL) {
    strlit1526 = alloc_String("Dynamic");
  }
// compilenode returning strlit1526
  Object bool1527 = alloc_Boolean(0);
// compilenode returning bool1527
// compilenode returning module_ast
  params[0] = strlit1526;
  params[1] = bool1527;
  Object call1528 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1528
  var_dtype = alloc_var();
  *var_dtype = call1528;
  if (call1528 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 932
  setline(932);
// Begin line 1577
  setline(1577);
// Begin line 931
  setline(931);
// compilenode returning *var_values
  Object call1529 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1529
// compilenode returning call1529
  var_name = alloc_var();
  *var_name = call1529;
  if (call1529 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 936
  setline(936);
// Begin line 932
  setline(932);
  if (strlit1531 == NULL) {
    strlit1531 = alloc_String("colon");
  }
// compilenode returning strlit1531
// Begin line 937
  setline(937);
// compilenode returning self
  params[0] = strlit1531;
  Object call1532 = callmethod(self, "accept",
    1, params);
// compilenode returning call1532
  Object if1530;
  if (istrue(call1532)) {
// Begin line 933
  setline(933);
// compilenode returning self
  Object call1533 = callmethod(self, "next",
    0, params);
// compilenode returning call1533
// Begin line 934
  setline(934);
// compilenode returning self
  Object call1534 = callmethod(self, "dotyperef",
    0, params);
// compilenode returning call1534
// Begin line 936
  setline(936);
// Begin line 1577
  setline(1577);
// Begin line 935
  setline(935);
// compilenode returning *var_values
  Object call1535 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1535
// compilenode returning call1535
  *var_dtype = call1535;
  if (call1535 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1530 = nothing;
  } else {
  }
// compilenode returning if1530
// Begin line 944
  setline(944);
// Begin line 937
  setline(937);
  if (strlit1538 == NULL) {
    strlit1538 = alloc_String("op");
  }
// compilenode returning strlit1538
// Begin line 946
  setline(946);
// compilenode returning self
  params[0] = strlit1538;
  Object call1539 = callmethod(self, "accept",
    1, params);
// compilenode returning call1539
// Begin line 937
  setline(937);
// Begin line 1577
  setline(1577);
// Begin line 937
  setline(937);
// compilenode returning *var_sym
  Object call1540 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1540
// compilenode returning call1540
  if (strlit1541 == NULL) {
    strlit1541 = alloc_String("=");
  }
// compilenode returning strlit1541
  params[0] = strlit1541;
  Object opresult1543 = callmethod(call1540, "==", 1, params);
// compilenode returning opresult1543
  params[0] = opresult1543;
  Object opresult1545 = callmethod(call1539, "&", 1, params);
// compilenode returning opresult1545
  Object if1537;
  if (istrue(opresult1545)) {
// Begin line 938
  setline(938);
// compilenode returning self
  Object call1546 = callmethod(self, "next",
    0, params);
// compilenode returning call1546
// Begin line 939
  setline(939);
// compilenode returning self
  Object call1547 = callmethod(self, "expression",
    0, params);
// compilenode returning call1547
// Begin line 941
  setline(941);
// Begin line 1577
  setline(1577);
// Begin line 940
  setline(940);
// compilenode returning *var_values
  Object call1548 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1548
// compilenode returning call1548
  *var_val = call1548;
  if (call1548 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1537 = nothing;
  } else {
// Begin line 944
  setline(944);
// Begin line 941
  setline(941);
  if (strlit1551 == NULL) {
    strlit1551 = alloc_String("bind");
  }
// compilenode returning strlit1551
// Begin line 943
  setline(943);
// compilenode returning self
  params[0] = strlit1551;
  Object call1552 = callmethod(self, "accept",
    1, params);
// compilenode returning call1552
  Object if1550;
  if (istrue(call1552)) {
// Begin line 942
  setline(942);
  if (strlit1553 == NULL) {
    strlit1553 = alloc_String("def declaration uses '=', not ':='");
  }
// compilenode returning strlit1553
// compilenode returning module_util
  params[0] = strlit1553;
  Object call1554 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1554
    if1550 = call1554;
  } else {
// Begin line 944
  setline(944);
  if (strlit1555 == NULL) {
    strlit1555 = alloc_String("def declaration requires value");
  }
// compilenode returning strlit1555
// compilenode returning module_util
  params[0] = strlit1555;
  Object call1556 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1556
    if1550 = call1556;
  }
// compilenode returning if1550
    if1537 = if1550;
  }
// compilenode returning if1537
// Begin line 946
  setline(946);
// compilenode returning *var_name
// compilenode returning *var_val
// compilenode returning *var_dtype
// compilenode returning module_ast
  params[0] = *var_name;
  params[1] = *var_val;
  params[2] = *var_dtype;
  Object call1557 = callmethod(module_ast, "astdefdec",
    3, params);
// compilenode returning call1557
  var_o = alloc_var();
  *var_o = call1557;
  if (call1557 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 947
  setline(947);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call1558 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1558
    if1514 = call1558;
  } else {
  }
// compilenode returning if1514
  return if1514;
}
Object meth_parser_vardec1559(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[33];
  Object params[3];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 953
  setline(953);
  if (strlit1561 == NULL) {
    strlit1561 = alloc_String("keyword");
  }
// compilenode returning strlit1561
// Begin line 975
  setline(975);
// compilenode returning self
  params[0] = strlit1561;
  Object call1562 = callmethod(self, "accept",
    1, params);
// compilenode returning call1562
// Begin line 953
  setline(953);
// Begin line 1577
  setline(1577);
// Begin line 953
  setline(953);
// compilenode returning *var_sym
  Object call1563 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1563
// compilenode returning call1563
  if (strlit1564 == NULL) {
    strlit1564 = alloc_String("var");
  }
// compilenode returning strlit1564
  params[0] = strlit1564;
  Object opresult1566 = callmethod(call1563, "==", 1, params);
// compilenode returning opresult1566
  params[0] = opresult1566;
  Object opresult1568 = callmethod(call1562, "&", 1, params);
// compilenode returning opresult1568
  Object if1560;
  if (istrue(opresult1568)) {
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_dtype = alloc_var();
  *var_dtype = undefined;
  Object *var_name = alloc_var();
  *var_name = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 954
  setline(954);
// compilenode returning self
  Object call1569 = callmethod(self, "next",
    0, params);
// compilenode returning call1569
// Begin line 955
  setline(955);
// compilenode returning self
  Object call1570 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1570
// Begin line 957
  setline(957);
// Begin line 956
  setline(956);
  Object bool1571 = alloc_Boolean(0);
// compilenode returning bool1571
  var_val = alloc_var();
  *var_val = bool1571;
  if (bool1571 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 957
  setline(957);
  if (strlit1572 == NULL) {
    strlit1572 = alloc_String("Dynamic");
  }
// compilenode returning strlit1572
  Object bool1573 = alloc_Boolean(0);
// compilenode returning bool1573
// compilenode returning module_ast
  params[0] = strlit1572;
  params[1] = bool1573;
  Object call1574 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1574
  var_dtype = alloc_var();
  *var_dtype = call1574;
  if (call1574 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 959
  setline(959);
// Begin line 1577
  setline(1577);
// Begin line 958
  setline(958);
// compilenode returning *var_values
  Object call1575 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1575
// compilenode returning call1575
  var_name = alloc_var();
  *var_name = call1575;
  if (call1575 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 963
  setline(963);
// Begin line 959
  setline(959);
  if (strlit1577 == NULL) {
    strlit1577 = alloc_String("colon");
  }
// compilenode returning strlit1577
// Begin line 964
  setline(964);
// compilenode returning self
  params[0] = strlit1577;
  Object call1578 = callmethod(self, "accept",
    1, params);
// compilenode returning call1578
  Object if1576;
  if (istrue(call1578)) {
// Begin line 960
  setline(960);
// compilenode returning self
  Object call1579 = callmethod(self, "next",
    0, params);
// compilenode returning call1579
// Begin line 961
  setline(961);
// compilenode returning self
  Object call1580 = callmethod(self, "dotyperef",
    0, params);
// compilenode returning call1580
// Begin line 963
  setline(963);
// Begin line 1577
  setline(1577);
// Begin line 962
  setline(962);
// compilenode returning *var_values
  Object call1581 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1581
// compilenode returning call1581
  *var_dtype = call1581;
  if (call1581 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1576 = nothing;
  } else {
  }
// compilenode returning if1576
// Begin line 968
  setline(968);
// Begin line 964
  setline(964);
  if (strlit1584 == NULL) {
    strlit1584 = alloc_String("bind");
  }
// compilenode returning strlit1584
// Begin line 969
  setline(969);
// compilenode returning self
  params[0] = strlit1584;
  Object call1585 = callmethod(self, "accept",
    1, params);
// compilenode returning call1585
  Object if1583;
  if (istrue(call1585)) {
// Begin line 965
  setline(965);
// compilenode returning self
  Object call1586 = callmethod(self, "next",
    0, params);
// compilenode returning call1586
// Begin line 966
  setline(966);
// compilenode returning self
  Object call1587 = callmethod(self, "expression",
    0, params);
// compilenode returning call1587
// Begin line 968
  setline(968);
// Begin line 1577
  setline(1577);
// Begin line 967
  setline(967);
// compilenode returning *var_values
  Object call1588 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1588
// compilenode returning call1588
  *var_val = call1588;
  if (call1588 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1583 = nothing;
  } else {
  }
// compilenode returning if1583
// Begin line 970
  setline(970);
// Begin line 969
  setline(969);
  if (strlit1591 == NULL) {
    strlit1591 = alloc_String("op");
  }
// compilenode returning strlit1591
// Begin line 972
  setline(972);
// compilenode returning self
  params[0] = strlit1591;
  Object call1592 = callmethod(self, "accept",
    1, params);
// compilenode returning call1592
// Begin line 969
  setline(969);
// Begin line 1577
  setline(1577);
// Begin line 969
  setline(969);
// compilenode returning *var_sym
  Object call1593 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1593
// compilenode returning call1593
  if (strlit1594 == NULL) {
    strlit1594 = alloc_String("=");
  }
// compilenode returning strlit1594
  params[0] = strlit1594;
  Object opresult1596 = callmethod(call1593, "==", 1, params);
// compilenode returning opresult1596
  params[0] = opresult1596;
  Object opresult1598 = callmethod(call1592, "&", 1, params);
// compilenode returning opresult1598
  Object if1590;
  if (istrue(opresult1598)) {
// Begin line 970
  setline(970);
  if (strlit1599 == NULL) {
    strlit1599 = alloc_String("var declaration uses ':=', not '='");
  }
// compilenode returning strlit1599
// compilenode returning module_util
  params[0] = strlit1599;
  Object call1600 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1600
    if1590 = call1600;
  } else {
  }
// compilenode returning if1590
// Begin line 972
  setline(972);
// compilenode returning *var_name
// compilenode returning *var_val
// compilenode returning *var_dtype
// compilenode returning module_ast
  params[0] = *var_name;
  params[1] = *var_val;
  params[2] = *var_dtype;
  Object call1601 = callmethod(module_ast, "astvardec",
    3, params);
// compilenode returning call1601
  var_o = alloc_var();
  *var_o = call1601;
  if (call1601 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 973
  setline(973);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call1602 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1602
    if1560 = call1602;
  } else {
  }
// compilenode returning if1560
  return if1560;
}
Object meth_parser_apply1612(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 983
  setline(983);
// compilenode returning self
  Object call1613 = callmethod(self, "expression",
    0, params);
// compilenode returning call1613
  return call1613;
}
Object meth_parser_apply1629(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 988
  setline(988);
// compilenode returning self
  Object call1630 = callmethod(self, "expression",
    0, params);
// compilenode returning call1630
  return call1630;
}
Object meth_parser_apply1618(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_values = closure[0];
  Object *var_tmp = closure[1];
  Object *var_params = closure[2];
  Object self = *closure[3];
// Begin line 988
  setline(988);
  Object while1619;
  while (1) {
// Begin line 984
  setline(984);
  if (strlit1620 == NULL) {
    strlit1620 = alloc_String("comma");
  }
// compilenode returning strlit1620
// Begin line 990
  setline(990);
// compilenode returning self
  params[0] = strlit1620;
  Object call1621 = callmethod(self, "accept",
    1, params);
// compilenode returning call1621
    while1619 = call1621;
    if (!istrue(call1621)) break;
// Begin line 986
  setline(986);
// Begin line 1577
  setline(1577);
// Begin line 985
  setline(985);
// compilenode returning *var_values
  Object call1622 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1622
// compilenode returning call1622
  *var_tmp = call1622;
  if (call1622 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 986
  setline(986);
// compilenode returning *var_tmp
// compilenode returning *var_params
  params[0] = *var_tmp;
  Object call1624 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1624
// Begin line 987
  setline(987);
// compilenode returning self
  Object call1625 = callmethod(self, "next",
    0, params);
// compilenode returning call1625
// Begin line 988
  setline(988);
// Begin line 1577
  setline(1577);
  Object obj1627 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1627, self, 0);
  addmethod2(obj1627, "outer", &reader_parser_outer_1628);
  adddatum2(obj1627, self, 0);
  block_savedest(obj1627);
  Object **closure1629 = createclosure(1);
  Object *selfpp1631 = alloc_var();
  *selfpp1631 = self;
  addtoclosure(closure1629, selfpp1631);
  struct UserObject *uo1629 = (struct UserObject*)obj1627;
  uo1629->data[1] = (Object)closure1629;
  addmethod2(obj1627, "apply", &meth_parser_apply1629);
  set_type(obj1627, 0);
// compilenode returning obj1627
  setclassname(obj1627, "Block<parser:1626>");
// compilenode returning obj1627
// Begin line 989
  setline(989);
// compilenode returning self
  params[0] = obj1627;
  Object call1632 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call1632
  }
// compilenode returning while1619
// Begin line 991
  setline(991);
// Begin line 1577
  setline(1577);
// Begin line 990
  setline(990);
// compilenode returning *var_values
  Object call1633 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1633
// compilenode returning call1633
  *var_tmp = call1633;
  if (call1633 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 991
  setline(991);
// compilenode returning *var_tmp
// compilenode returning *var_params
  params[0] = *var_tmp;
  Object call1635 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1635
  return call1635;
}
Object meth_parser_doarray1603(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[34];
  Object params[2];
  Object *var_values = closure[0];
// Begin line 979
  setline(979);
  if (strlit1605 == NULL) {
    strlit1605 = alloc_String("lsquare");
  }
// compilenode returning strlit1605
// Begin line 998
  setline(998);
// compilenode returning self
  params[0] = strlit1605;
  Object call1606 = callmethod(self, "accept",
    1, params);
// compilenode returning call1606
  Object if1604;
  if (istrue(call1606)) {
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 980
  setline(980);
// compilenode returning self
  Object call1607 = callmethod(self, "next",
    0, params);
// compilenode returning call1607
// Begin line 982
  setline(982);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 983
  setline(983);
  Object array1608 = alloc_List();
// compilenode returning array1608
  var_params = alloc_var();
  *var_params = array1608;
  if (array1608 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 991
  setline(991);
// Begin line 983
  setline(983);
// Begin line 1577
  setline(1577);
  Object obj1610 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1610, self, 0);
  addmethod2(obj1610, "outer", &reader_parser_outer_1611);
  adddatum2(obj1610, self, 0);
  block_savedest(obj1610);
  Object **closure1612 = createclosure(1);
  Object *selfpp1614 = alloc_var();
  *selfpp1614 = self;
  addtoclosure(closure1612, selfpp1614);
  struct UserObject *uo1612 = (struct UserObject*)obj1610;
  uo1612->data[1] = (Object)closure1612;
  addmethod2(obj1610, "apply", &meth_parser_apply1612);
  set_type(obj1610, 0);
// compilenode returning obj1610
  setclassname(obj1610, "Block<parser:1609>");
// compilenode returning obj1610
// Begin line 991
  setline(991);
// Begin line 1577
  setline(1577);
  Object obj1616 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1616, self, 0);
  addmethod2(obj1616, "outer", &reader_parser_outer_1617);
  adddatum2(obj1616, self, 0);
  block_savedest(obj1616);
  Object **closure1618 = createclosure(4);
  addtoclosure(closure1618, var_values);
  addtoclosure(closure1618, var_tmp);
  addtoclosure(closure1618, var_params);
  Object *selfpp1636 = alloc_var();
  *selfpp1636 = self;
  addtoclosure(closure1618, selfpp1636);
  struct UserObject *uo1618 = (struct UserObject*)obj1616;
  uo1618->data[1] = (Object)closure1618;
  addmethod2(obj1616, "apply", &meth_parser_apply1618);
  set_type(obj1616, 0);
// compilenode returning obj1616
  setclassname(obj1616, "Block<parser:1615>");
// compilenode returning obj1616
// Begin line 993
  setline(993);
// compilenode returning self
  params[0] = obj1610;
  params[1] = obj1616;
  Object call1637 = callmethod(self, "ifConsume(1)then",
    2, params);
// compilenode returning call1637
  if (strlit1638 == NULL) {
    strlit1638 = alloc_String("rsquare");
  }
// compilenode returning strlit1638
// Begin line 994
  setline(994);
// compilenode returning self
  params[0] = strlit1638;
  Object call1639 = callmethod(self, "expect",
    1, params);
// compilenode returning call1639
// compilenode returning *var_params
// compilenode returning module_ast
  params[0] = *var_params;
  Object call1640 = callmethod(module_ast, "astarray",
    1, params);
// compilenode returning call1640
  var_o = alloc_var();
  *var_o = call1640;
  if (call1640 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 995
  setline(995);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call1641 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1641
// Begin line 996
  setline(996);
// compilenode returning self
  Object call1642 = callmethod(self, "next",
    0, params);
// compilenode returning call1642
    if1604 = call1642;
  } else {
  }
// compilenode returning if1604
  return if1604;
}
Object meth_parser_apply1692(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 1022
  setline(1022);
// compilenode returning self
  Object call1693 = callmethod(self, "expression",
    0, params);
// compilenode returning call1693
  return call1693;
}
Object meth_parser_apply1749(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = args + 0;
  Object params[1];
  Object *var_rbody = closure[0];
  Object *var_body = closure[1];
  Object self = *closure[2];
  Object *var_p = alloc_var();
  *var_p = undefined;
// Begin line 1061
  setline(1061);
// Begin line 1577
  setline(1577);
// Begin line 1060
  setline(1060);
// compilenode returning *var_rbody
  Object call1750 = callmethod(*var_rbody, "pop",
    0, params);
// compilenode returning call1750
// compilenode returning call1750
  var_p = alloc_var();
  *var_p = call1750;
  if (call1750 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1061
  setline(1061);
// compilenode returning *var_p
// compilenode returning *var_body
  params[0] = *var_p;
  Object call1751 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call1751
  return call1751;
}
Object meth_parser_doobject1643(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[35];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 1003
  setline(1003);
  if (strlit1645 == NULL) {
    strlit1645 = alloc_String("keyword");
  }
// compilenode returning strlit1645
// Begin line 1066
  setline(1066);
// compilenode returning self
  params[0] = strlit1645;
  Object call1646 = callmethod(self, "accept",
    1, params);
// compilenode returning call1646
// Begin line 1003
  setline(1003);
// Begin line 1577
  setline(1577);
// Begin line 1003
  setline(1003);
// compilenode returning *var_sym
  Object call1647 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1647
// compilenode returning call1647
  if (strlit1648 == NULL) {
    strlit1648 = alloc_String("object");
  }
// compilenode returning strlit1648
  params[0] = strlit1648;
  Object opresult1650 = callmethod(call1647, "==", 1, params);
// compilenode returning opresult1650
  params[0] = opresult1650;
  Object opresult1652 = callmethod(call1646, "&", 1, params);
// compilenode returning opresult1652
  Object if1644;
  if (istrue(opresult1652)) {
  Object *var_superclass = alloc_var();
  *var_superclass = undefined;
  Object *var_sz = alloc_var();
  *var_sz = undefined;
  Object *var_rbody = alloc_var();
  *var_rbody = undefined;
  Object *var_n = alloc_var();
  *var_n = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1004
  setline(1004);
// compilenode returning self
  Object call1653 = callmethod(self, "next",
    0, params);
// compilenode returning call1653
// Begin line 1006
  setline(1006);
// Begin line 1005
  setline(1005);
  Object bool1654 = alloc_Boolean(0);
// compilenode returning bool1654
  var_superclass = alloc_var();
  *var_superclass = bool1654;
  if (bool1654 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1028
  setline(1028);
// Begin line 1006
  setline(1006);
  if (strlit1656 == NULL) {
    strlit1656 = alloc_String("identifier");
  }
// compilenode returning strlit1656
// Begin line 1030
  setline(1030);
// compilenode returning self
  params[0] = strlit1656;
  Object call1657 = callmethod(self, "accept",
    1, params);
// compilenode returning call1657
// Begin line 1006
  setline(1006);
// Begin line 1577
  setline(1577);
// Begin line 1006
  setline(1006);
// compilenode returning *var_sym
  Object call1658 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1658
// compilenode returning call1658
  if (strlit1659 == NULL) {
    strlit1659 = alloc_String("extends");
  }
// compilenode returning strlit1659
  params[0] = strlit1659;
  Object opresult1661 = callmethod(call1658, "==", 1, params);
// compilenode returning opresult1661
  params[0] = opresult1661;
  Object opresult1663 = callmethod(call1657, "&", 1, params);
// compilenode returning opresult1663
  Object if1655;
  if (istrue(opresult1663)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_mn = alloc_var();
  *var_mn = undefined;
  Object *var_scargs = alloc_var();
  *var_scargs = undefined;
// Begin line 1007
  setline(1007);
// compilenode returning self
  Object call1664 = callmethod(self, "next",
    0, params);
// compilenode returning call1664
// Begin line 1008
  setline(1008);
  if (strlit1665 == NULL) {
    strlit1665 = alloc_String("identifier");
  }
// compilenode returning strlit1665
// Begin line 1009
  setline(1009);
// compilenode returning self
  params[0] = strlit1665;
  Object call1666 = callmethod(self, "expect",
    1, params);
// compilenode returning call1666
// compilenode returning self
  Object call1667 = callmethod(self, "identifier",
    0, params);
// compilenode returning call1667
// Begin line 1011
  setline(1011);
// Begin line 1577
  setline(1577);
// Begin line 1010
  setline(1010);
// compilenode returning *var_values
  Object call1668 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1668
// compilenode returning call1668
  var_nm = alloc_var();
  *var_nm = call1668;
  if (call1668 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1012
  setline(1012);
// Begin line 1011
  setline(1011);
// Begin line 1577
  setline(1577);
// Begin line 1011
  setline(1011);
  if (strlit1670 == NULL) {
    strlit1670 = alloc_String("dot");
  }
// compilenode returning strlit1670
// Begin line 1014
  setline(1014);
// compilenode returning self
  params[0] = strlit1670;
  Object call1671 = callmethod(self, "accept",
    1, params);
// compilenode returning call1671
  Object call1672 = callmethod(call1671, "not",
    0, params);
// compilenode returning call1672
// compilenode returning call1672
  Object if1669;
  if (istrue(call1672)) {
// Begin line 1012
  setline(1012);
  if (strlit1673 == NULL) {
    strlit1673 = alloc_String("extends must have .new invocation on right");
  }
// compilenode returning strlit1673
// compilenode returning module_util
  params[0] = strlit1673;
  Object call1674 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1674
    if1669 = call1674;
  } else {
  }
// compilenode returning if1669
// Begin line 1014
  setline(1014);
// compilenode returning self
  Object call1675 = callmethod(self, "next",
    0, params);
// compilenode returning call1675
// Begin line 1015
  setline(1015);
  if (strlit1676 == NULL) {
    strlit1676 = alloc_String("identifier");
  }
// compilenode returning strlit1676
// Begin line 1016
  setline(1016);
// compilenode returning self
  params[0] = strlit1676;
  Object call1677 = callmethod(self, "expect",
    1, params);
// compilenode returning call1677
// compilenode returning self
  Object call1678 = callmethod(self, "identifier",
    0, params);
// compilenode returning call1678
// Begin line 1018
  setline(1018);
// Begin line 1577
  setline(1577);
// Begin line 1017
  setline(1017);
// compilenode returning *var_values
  Object call1679 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1679
// compilenode returning call1679
  var_mn = alloc_var();
  *var_mn = call1679;
  if (call1679 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1019
  setline(1019);
  Object array1680 = alloc_List();
// compilenode returning array1680
  var_scargs = alloc_var();
  *var_scargs = array1680;
  if (array1680 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1026
  setline(1026);
// Begin line 1019
  setline(1019);
  if (strlit1682 == NULL) {
    strlit1682 = alloc_String("(");
  }
// compilenode returning strlit1682
// Begin line 1028
  setline(1028);
// compilenode returning self
  params[0] = strlit1682;
  Object call1683 = callmethod(self, "accept",
    1, params);
// compilenode returning call1683
  Object if1681;
  if (istrue(call1683)) {
// Begin line 1020
  setline(1020);
// compilenode returning self
  Object call1684 = callmethod(self, "next",
    0, params);
// compilenode returning call1684
// Begin line 1024
  setline(1024);
  Object while1685;
  while (1) {
// Begin line 1021
  setline(1021);
// Begin line 1577
  setline(1577);
// Begin line 1021
  setline(1021);
  if (strlit1686 == NULL) {
    strlit1686 = alloc_String(")");
  }
// compilenode returning strlit1686
// Begin line 1026
  setline(1026);
// compilenode returning self
  params[0] = strlit1686;
  Object call1687 = callmethod(self, "accept",
    1, params);
// compilenode returning call1687
  Object call1688 = callmethod(call1687, "not",
    0, params);
// compilenode returning call1688
// compilenode returning call1688
    while1685 = call1688;
    if (!istrue(call1688)) break;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
// Begin line 1022
  setline(1022);
// Begin line 1577
  setline(1577);
  Object obj1690 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1690, self, 0);
  addmethod2(obj1690, "outer", &reader_parser_outer_1691);
  adddatum2(obj1690, self, 0);
  block_savedest(obj1690);
  Object **closure1692 = createclosure(1);
  Object *selfpp1694 = alloc_var();
  *selfpp1694 = self;
  addtoclosure(closure1692, selfpp1694);
  struct UserObject *uo1692 = (struct UserObject*)obj1690;
  uo1692->data[1] = (Object)closure1692;
  addmethod2(obj1690, "apply", &meth_parser_apply1692);
  set_type(obj1690, 0);
// compilenode returning obj1690
  setclassname(obj1690, "Block<parser:1689>");
// compilenode returning obj1690
// Begin line 1023
  setline(1023);
// compilenode returning self
  params[0] = obj1690;
  Object call1695 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call1695
// Begin line 1024
  setline(1024);
// Begin line 1577
  setline(1577);
// Begin line 1023
  setline(1023);
// compilenode returning *var_values
  Object call1696 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1696
// compilenode returning call1696
  var_tmp = alloc_var();
  *var_tmp = call1696;
  if (call1696 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1024
  setline(1024);
// compilenode returning *var_tmp
// compilenode returning *var_scargs
  params[0] = *var_tmp;
  Object call1697 = callmethod(*var_scargs, "push",
    1, params);
// compilenode returning call1697
  }
// compilenode returning while1685
// Begin line 1026
  setline(1026);
// compilenode returning self
  Object call1698 = callmethod(self, "next",
    0, params);
// compilenode returning call1698
    if1681 = call1698;
  } else {
  }
// compilenode returning if1681
// Begin line 1028
  setline(1028);
// Begin line 1577
  setline(1577);
// Begin line 1028
  setline(1028);
// compilenode returning *var_mn
  Object call1699 = callmethod(*var_mn, "value",
    0, params);
// compilenode returning call1699
// compilenode returning call1699
// compilenode returning *var_nm
// compilenode returning module_ast
  params[0] = call1699;
  params[1] = *var_nm;
  Object call1700 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1700
// compilenode returning *var_scargs
// compilenode returning module_ast
  params[0] = call1700;
  params[1] = *var_scargs;
  Object call1701 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1701
  *var_superclass = call1701;
  if (call1701 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1655 = nothing;
  } else {
  }
// compilenode returning if1655
// Begin line 1030
  setline(1030);
  if (strlit1703 == NULL) {
    strlit1703 = alloc_String("lbrace");
  }
// compilenode returning strlit1703
// Begin line 1031
  setline(1031);
// compilenode returning self
  params[0] = strlit1703;
  Object call1704 = callmethod(self, "expect",
    1, params);
// compilenode returning call1704
// Begin line 1034
  setline(1034);
  Object obj1705 = alloc_obj2(4,4);
// OBJECT OUTER DEC outer
  adddatum2(obj1705, self, 0);
  addmethod2(obj1705, "outer", &reader_parser_outer_1706);
  adddatum2(obj1705, self, 0);
// Begin line 1032
  setline(1032);
  if (strlit1707 == NULL) {
    strlit1707 = alloc_String("lbrace");
  }
// compilenode returning strlit1707
// OBJECT VAR DEC kind
  adddatum2(obj1705, strlit1707, 1);
  addmethod2(obj1705, "kind", &reader_parser_kind_1708);
  addmethod2(obj1705, "kind:=", &writer_parser_kind_1708);
// Begin line 1033
  setline(1033);
  if (strlit1709 == NULL) {
    strlit1709 = alloc_String("");
  }
// compilenode returning strlit1709
// OBJECT VAR DEC register
  adddatum2(obj1705, strlit1709, 2);
  addmethod2(obj1705, "register", &reader_parser_register_1710);
  addmethod2(obj1705, "register:=", &writer_parser_register_1710);
  set_type(obj1705, 5);
// compilenode returning obj1705
// Begin line 1031
  setline(1031);
// compilenode returning *var_values
  params[0] = obj1705;
  Object call1711 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1711
// Begin line 1035
  setline(1035);
// compilenode returning self
  Object call1712 = callmethod(self, "next",
    0, params);
// compilenode returning call1712
// Begin line 1037
  setline(1037);
// Begin line 1577
  setline(1577);
// Begin line 1036
  setline(1036);
// compilenode returning *var_values
  Object call1713 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call1713
// compilenode returning call1713
  var_sz = alloc_var();
  *var_sz = call1713;
  if (call1713 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1049
  setline(1049);
  Object while1714;
  while (1) {
// Begin line 1037
  setline(1037);
// Begin line 1577
  setline(1577);
// Begin line 1037
  setline(1037);
  if (strlit1715 == NULL) {
    strlit1715 = alloc_String("rbrace");
  }
// compilenode returning strlit1715
// Begin line 1050
  setline(1050);
// compilenode returning self
  params[0] = strlit1715;
  Object call1716 = callmethod(self, "accept",
    1, params);
// compilenode returning call1716
  Object call1717 = callmethod(call1716, "not",
    0, params);
// compilenode returning call1717
// compilenode returning call1717
    while1714 = call1717;
    if (!istrue(call1717)) break;
// Begin line 1041
  setline(1041);
// compilenode returning self
  Object call1718 = callmethod(self, "vardec",
    0, params);
// compilenode returning call1718
// Begin line 1042
  setline(1042);
// compilenode returning self
  Object call1719 = callmethod(self, "methoddec",
    0, params);
// compilenode returning call1719
// Begin line 1043
  setline(1043);
// compilenode returning self
  Object call1720 = callmethod(self, "defdec",
    0, params);
// compilenode returning call1720
// Begin line 1046
  setline(1046);
// Begin line 1048
  setline(1048);
// Begin line 1577
  setline(1577);
// Begin line 1044
  setline(1044);
// compilenode returning *var_values
  Object call1722 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call1722
// compilenode returning call1722
// compilenode returning *var_sz
  params[0] = *var_sz;
  Object opresult1724 = callmethod(call1722, "==", 1, params);
// compilenode returning opresult1724
  Object if1721;
  if (istrue(opresult1724)) {
// Begin line 1046
  setline(1046);
// Begin line 1045
  setline(1045);
  if (strlit1725 == NULL) {
    strlit1725 = alloc_String("did not consume anything in ");
  }
// compilenode returning strlit1725
// Begin line 1046
  setline(1046);
  if (strlit1726 == NULL) {
    strlit1726 = alloc_String("object declaration.");
  }
// compilenode returning strlit1726
  params[0] = strlit1726;
  Object opresult1728 = callmethod(strlit1725, "++", 1, params);
// compilenode returning opresult1728
// Begin line 1045
  setline(1045);
// compilenode returning module_util
  params[0] = opresult1728;
  Object call1729 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1729
    if1721 = call1729;
  } else {
  }
// compilenode returning if1721
// Begin line 1049
  setline(1049);
// Begin line 1577
  setline(1577);
// Begin line 1048
  setline(1048);
// compilenode returning *var_values
  Object call1730 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call1730
// compilenode returning call1730
  *var_sz = call1730;
  if (call1730 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while1714
// Begin line 1050
  setline(1050);
// compilenode returning self
  Object call1732 = callmethod(self, "next",
    0, params);
// compilenode returning call1732
// Begin line 1052
  setline(1052);
  Object array1733 = alloc_List();
// compilenode returning array1733
  var_rbody = alloc_var();
  *var_rbody = array1733;
  if (array1733 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1053
  setline(1053);
// Begin line 1577
  setline(1577);
// Begin line 1052
  setline(1052);
// compilenode returning *var_values
  Object call1734 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1734
// compilenode returning call1734
  var_n = alloc_var();
  *var_n = call1734;
  if (call1734 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1056
  setline(1056);
  Object while1735;
  while (1) {
// Begin line 1057
  setline(1057);
// Begin line 1577
  setline(1577);
// Begin line 1053
  setline(1053);
// compilenode returning *var_n
  Object call1736 = callmethod(*var_n, "kind",
    0, params);
// compilenode returning call1736
// compilenode returning call1736
  if (strlit1737 == NULL) {
    strlit1737 = alloc_String("lbrace");
  }
// compilenode returning strlit1737
  params[0] = strlit1737;
  Object opresult1739 = callmethod(call1736, "/=", 1, params);
// compilenode returning opresult1739
    while1735 = opresult1739;
    if (!istrue(opresult1739)) break;
// Begin line 1054
  setline(1054);
// compilenode returning *var_n
// compilenode returning *var_rbody
  params[0] = *var_n;
  Object call1740 = callmethod(*var_rbody, "push",
    1, params);
// compilenode returning call1740
// Begin line 1056
  setline(1056);
// Begin line 1577
  setline(1577);
// Begin line 1055
  setline(1055);
// compilenode returning *var_values
  Object call1741 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1741
// compilenode returning call1741
  *var_n = call1741;
  if (call1741 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while1735
// Begin line 1058
  setline(1058);
  Object array1743 = alloc_List();
// compilenode returning array1743
  var_body = alloc_var();
  *var_body = array1743;
  if (array1743 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1061
  setline(1061);
// Begin line 1063
  setline(1063);
// Begin line 1577
  setline(1577);
// Begin line 1058
  setline(1058);
// compilenode returning *var_rbody
  Object call1745 = callmethod(*var_rbody, "indices",
    0, params);
// compilenode returning call1745
// compilenode returning call1745
// Begin line 1061
  setline(1061);
// Begin line 1577
  setline(1577);
  Object obj1747 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1747, self, 0);
  addmethod2(obj1747, "outer", &reader_parser_outer_1748);
  adddatum2(obj1747, self, 0);
  block_savedest(obj1747);
  Object **closure1749 = createclosure(3);
  addtoclosure(closure1749, var_rbody);
  addtoclosure(closure1749, var_body);
  Object *selfpp1752 = alloc_var();
  *selfpp1752 = self;
  addtoclosure(closure1749, selfpp1752);
  struct UserObject *uo1749 = (struct UserObject*)obj1747;
  uo1749->data[1] = (Object)closure1749;
  addmethod2(obj1747, "apply", &meth_parser_apply1749);
  set_type(obj1747, 0);
// compilenode returning obj1747
  setclassname(obj1747, "Block<parser:1746>");
// compilenode returning obj1747
  params[0] = call1745;
  Object iter1744 = callmethod(call1745, "iter", 1, params);
  while(1) {
    Object cond1744 = callmethod(iter1744, "havemore", 0, NULL);
    if (!istrue(cond1744)) break;
    params[0] = callmethod(iter1744, "next", 0, NULL);
    callmethod(obj1747, "apply", 1, params);
  }
// compilenode returning call1745
// Begin line 1063
  setline(1063);
// compilenode returning *var_body
// compilenode returning *var_superclass
// compilenode returning module_ast
  params[0] = *var_body;
  params[1] = *var_superclass;
  Object call1753 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call1753
  var_o = alloc_var();
  *var_o = call1753;
  if (call1753 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1064
  setline(1064);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call1754 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1754
    if1644 = call1754;
  } else {
  }
// compilenode returning if1644
  return if1644;
}
Object meth_parser_apply1809(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 1098
  setline(1098);
// compilenode returning self
  Object call1810 = callmethod(self, "expression",
    0, params);
// compilenode returning call1810
  return call1810;
}
Object meth_parser_apply1906(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_x = args + 0;
  Object params[1];
  Object *var_rbody = closure[0];
  Object *var_body = closure[1];
  Object self = *closure[2];
  Object *var_p = alloc_var();
  *var_p = undefined;
// Begin line 1167
  setline(1167);
// Begin line 1577
  setline(1577);
// Begin line 1166
  setline(1166);
// compilenode returning *var_rbody
  Object call1907 = callmethod(*var_rbody, "pop",
    0, params);
// compilenode returning call1907
// compilenode returning call1907
  var_p = alloc_var();
  *var_p = call1907;
  if (call1907 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1167
  setline(1167);
// compilenode returning *var_p
// compilenode returning *var_body
  params[0] = *var_p;
  Object call1908 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call1908
  return call1908;
}
Object meth_parser_doclass1755(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[36];
  Object params[4];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 1075
  setline(1075);
  if (strlit1757 == NULL) {
    strlit1757 = alloc_String("keyword");
  }
// compilenode returning strlit1757
// Begin line 1175
  setline(1175);
// compilenode returning self
  params[0] = strlit1757;
  Object call1758 = callmethod(self, "accept",
    1, params);
// compilenode returning call1758
// Begin line 1075
  setline(1075);
// Begin line 1577
  setline(1577);
// Begin line 1075
  setline(1075);
// compilenode returning *var_sym
  Object call1759 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1759
// compilenode returning call1759
  if (strlit1760 == NULL) {
    strlit1760 = alloc_String("class");
  }
// compilenode returning strlit1760
  params[0] = strlit1760;
  Object opresult1762 = callmethod(call1759, "==", 1, params);
// compilenode returning opresult1762
  params[0] = opresult1762;
  Object opresult1764 = callmethod(call1758, "&", 1, params);
// compilenode returning opresult1764
  Object if1756;
  if (istrue(opresult1764)) {
  Object *var_superclass = alloc_var();
  *var_superclass = undefined;
  Object *var_cname = alloc_var();
  *var_cname = undefined;
// Begin line 1076
  setline(1076);
// compilenode returning self
  Object call1765 = callmethod(self, "next",
    0, params);
// compilenode returning call1765
// Begin line 1077
  setline(1077);
  if (strlit1766 == NULL) {
    strlit1766 = alloc_String("identifier");
  }
// compilenode returning strlit1766
// Begin line 1078
  setline(1078);
// compilenode returning self
  params[0] = strlit1766;
  Object call1767 = callmethod(self, "expect",
    1, params);
// compilenode returning call1767
// compilenode returning self
  Object call1768 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1768
// Begin line 1079
  setline(1079);
// compilenode returning self
  Object call1769 = callmethod(self, "generic",
    0, params);
// compilenode returning call1769
// Begin line 1081
  setline(1081);
// Begin line 1080
  setline(1080);
  Object bool1770 = alloc_Boolean(0);
// compilenode returning bool1770
  var_superclass = alloc_var();
  *var_superclass = bool1770;
  if (bool1770 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1104
  setline(1104);
// Begin line 1081
  setline(1081);
  if (strlit1772 == NULL) {
    strlit1772 = alloc_String("identifier");
  }
// compilenode returning strlit1772
// Begin line 1106
  setline(1106);
// compilenode returning self
  params[0] = strlit1772;
  Object call1773 = callmethod(self, "accept",
    1, params);
// compilenode returning call1773
// Begin line 1081
  setline(1081);
// Begin line 1577
  setline(1577);
// Begin line 1081
  setline(1081);
// compilenode returning *var_sym
  Object call1774 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1774
// compilenode returning call1774
  if (strlit1775 == NULL) {
    strlit1775 = alloc_String("extends");
  }
// compilenode returning strlit1775
  params[0] = strlit1775;
  Object opresult1777 = callmethod(call1774, "==", 1, params);
// compilenode returning opresult1777
  params[0] = opresult1777;
  Object opresult1779 = callmethod(call1773, "&", 1, params);
// compilenode returning opresult1779
  Object if1771;
  if (istrue(opresult1779)) {
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_mn = alloc_var();
  *var_mn = undefined;
  Object *var_scargs = alloc_var();
  *var_scargs = undefined;
// Begin line 1082
  setline(1082);
// compilenode returning self
  Object call1780 = callmethod(self, "next",
    0, params);
// compilenode returning call1780
// Begin line 1083
  setline(1083);
  if (strlit1781 == NULL) {
    strlit1781 = alloc_String("identifier");
  }
// compilenode returning strlit1781
// Begin line 1084
  setline(1084);
// compilenode returning self
  params[0] = strlit1781;
  Object call1782 = callmethod(self, "expect",
    1, params);
// compilenode returning call1782
// compilenode returning self
  Object call1783 = callmethod(self, "identifier",
    0, params);
// compilenode returning call1783
// Begin line 1085
  setline(1085);
// compilenode returning self
  Object call1784 = callmethod(self, "generic",
    0, params);
// compilenode returning call1784
// Begin line 1087
  setline(1087);
// Begin line 1577
  setline(1577);
// Begin line 1086
  setline(1086);
// compilenode returning *var_values
  Object call1785 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1785
// compilenode returning call1785
  var_nm = alloc_var();
  *var_nm = call1785;
  if (call1785 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1088
  setline(1088);
// Begin line 1087
  setline(1087);
// Begin line 1577
  setline(1577);
// Begin line 1087
  setline(1087);
  if (strlit1787 == NULL) {
    strlit1787 = alloc_String("dot");
  }
// compilenode returning strlit1787
// Begin line 1090
  setline(1090);
// compilenode returning self
  params[0] = strlit1787;
  Object call1788 = callmethod(self, "accept",
    1, params);
// compilenode returning call1788
  Object call1789 = callmethod(call1788, "not",
    0, params);
// compilenode returning call1789
// compilenode returning call1789
  Object if1786;
  if (istrue(call1789)) {
// Begin line 1088
  setline(1088);
  if (strlit1790 == NULL) {
    strlit1790 = alloc_String("extends must have .new invocation on right");
  }
// compilenode returning strlit1790
// compilenode returning module_util
  params[0] = strlit1790;
  Object call1791 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1791
    if1786 = call1791;
  } else {
  }
// compilenode returning if1786
// Begin line 1090
  setline(1090);
// compilenode returning self
  Object call1792 = callmethod(self, "next",
    0, params);
// compilenode returning call1792
// Begin line 1091
  setline(1091);
  if (strlit1793 == NULL) {
    strlit1793 = alloc_String("identifier");
  }
// compilenode returning strlit1793
// Begin line 1092
  setline(1092);
// compilenode returning self
  params[0] = strlit1793;
  Object call1794 = callmethod(self, "expect",
    1, params);
// compilenode returning call1794
// compilenode returning self
  Object call1795 = callmethod(self, "identifier",
    0, params);
// compilenode returning call1795
// Begin line 1094
  setline(1094);
// Begin line 1577
  setline(1577);
// Begin line 1093
  setline(1093);
// compilenode returning *var_values
  Object call1796 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1796
// compilenode returning call1796
  var_mn = alloc_var();
  *var_mn = call1796;
  if (call1796 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1095
  setline(1095);
  Object array1797 = alloc_List();
// compilenode returning array1797
  var_scargs = alloc_var();
  *var_scargs = array1797;
  if (array1797 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1102
  setline(1102);
// Begin line 1095
  setline(1095);
  if (strlit1799 == NULL) {
    strlit1799 = alloc_String("lparen");
  }
// compilenode returning strlit1799
// Begin line 1104
  setline(1104);
// compilenode returning self
  params[0] = strlit1799;
  Object call1800 = callmethod(self, "accept",
    1, params);
// compilenode returning call1800
  Object if1798;
  if (istrue(call1800)) {
// Begin line 1096
  setline(1096);
// compilenode returning self
  Object call1801 = callmethod(self, "next",
    0, params);
// compilenode returning call1801
// Begin line 1100
  setline(1100);
  Object while1802;
  while (1) {
// Begin line 1097
  setline(1097);
// Begin line 1577
  setline(1577);
// Begin line 1097
  setline(1097);
  if (strlit1803 == NULL) {
    strlit1803 = alloc_String("rparen");
  }
// compilenode returning strlit1803
// Begin line 1102
  setline(1102);
// compilenode returning self
  params[0] = strlit1803;
  Object call1804 = callmethod(self, "accept",
    1, params);
// compilenode returning call1804
  Object call1805 = callmethod(call1804, "not",
    0, params);
// compilenode returning call1805
// compilenode returning call1805
    while1802 = call1805;
    if (!istrue(call1805)) break;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
// Begin line 1098
  setline(1098);
// Begin line 1577
  setline(1577);
  Object obj1807 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1807, self, 0);
  addmethod2(obj1807, "outer", &reader_parser_outer_1808);
  adddatum2(obj1807, self, 0);
  block_savedest(obj1807);
  Object **closure1809 = createclosure(1);
  Object *selfpp1811 = alloc_var();
  *selfpp1811 = self;
  addtoclosure(closure1809, selfpp1811);
  struct UserObject *uo1809 = (struct UserObject*)obj1807;
  uo1809->data[1] = (Object)closure1809;
  addmethod2(obj1807, "apply", &meth_parser_apply1809);
  set_type(obj1807, 0);
// compilenode returning obj1807
  setclassname(obj1807, "Block<parser:1806>");
// compilenode returning obj1807
// Begin line 1099
  setline(1099);
// compilenode returning self
  params[0] = obj1807;
  Object call1812 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call1812
// Begin line 1100
  setline(1100);
// Begin line 1577
  setline(1577);
// Begin line 1099
  setline(1099);
// compilenode returning *var_values
  Object call1813 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1813
// compilenode returning call1813
  var_tmp = alloc_var();
  *var_tmp = call1813;
  if (call1813 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1100
  setline(1100);
// compilenode returning *var_tmp
// compilenode returning *var_scargs
  params[0] = *var_tmp;
  Object call1814 = callmethod(*var_scargs, "push",
    1, params);
// compilenode returning call1814
  }
// compilenode returning while1802
// Begin line 1102
  setline(1102);
// compilenode returning self
  Object call1815 = callmethod(self, "next",
    0, params);
// compilenode returning call1815
    if1798 = call1815;
  } else {
  }
// compilenode returning if1798
// Begin line 1104
  setline(1104);
// Begin line 1577
  setline(1577);
// Begin line 1104
  setline(1104);
// compilenode returning *var_mn
  Object call1816 = callmethod(*var_mn, "value",
    0, params);
// compilenode returning call1816
// compilenode returning call1816
// compilenode returning *var_nm
// compilenode returning module_ast
  params[0] = call1816;
  params[1] = *var_nm;
  Object call1817 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1817
// compilenode returning *var_scargs
// compilenode returning module_ast
  params[0] = call1817;
  params[1] = *var_scargs;
  Object call1818 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1818
  *var_superclass = call1818;
  if (call1818 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1771 = nothing;
  } else {
  }
// compilenode returning if1771
// Begin line 1107
  setline(1107);
// Begin line 1577
  setline(1577);
// Begin line 1106
  setline(1106);
// compilenode returning *var_values
  Object call1820 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1820
// compilenode returning call1820
  var_cname = alloc_var();
  *var_cname = call1820;
  if (call1820 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1172
  setline(1172);
// Begin line 1107
  setline(1107);
  if (strlit1822 == NULL) {
    strlit1822 = alloc_String("lbrace");
  }
// compilenode returning strlit1822
// Begin line 1174
  setline(1174);
// compilenode returning self
  params[0] = strlit1822;
  Object call1823 = callmethod(self, "accept",
    1, params);
// compilenode returning call1823
  Object if1821;
  if (istrue(call1823)) {
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_sz = alloc_var();
  *var_sz = undefined;
  Object *var_rbody = alloc_var();
  *var_rbody = undefined;
  Object *var_n = alloc_var();
  *var_n = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1111
  setline(1111);
  Object obj1824 = alloc_obj2(4,4);
// OBJECT OUTER DEC outer
  adddatum2(obj1824, self, 0);
  addmethod2(obj1824, "outer", &reader_parser_outer_1825);
  adddatum2(obj1824, self, 0);
// Begin line 1109
  setline(1109);
  if (strlit1826 == NULL) {
    strlit1826 = alloc_String("lbrace");
  }
// compilenode returning strlit1826
// OBJECT VAR DEC kind
  adddatum2(obj1824, strlit1826, 1);
  addmethod2(obj1824, "kind", &reader_parser_kind_1827);
  addmethod2(obj1824, "kind:=", &writer_parser_kind_1827);
// Begin line 1110
  setline(1110);
  if (strlit1828 == NULL) {
    strlit1828 = alloc_String("");
  }
// compilenode returning strlit1828
// OBJECT VAR DEC register
  adddatum2(obj1824, strlit1828, 2);
  addmethod2(obj1824, "register", &reader_parser_register_1829);
  addmethod2(obj1824, "register:=", &writer_parser_register_1829);
  set_type(obj1824, 6);
// compilenode returning obj1824
// Begin line 1108
  setline(1108);
// compilenode returning *var_values
  params[0] = obj1824;
  Object call1830 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1830
// Begin line 1112
  setline(1112);
// compilenode returning self
  Object call1831 = callmethod(self, "next",
    0, params);
// compilenode returning call1831
// Begin line 1114
  setline(1114);
  Object array1832 = alloc_List();
// compilenode returning array1832
  var_params = alloc_var();
  *var_params = array1832;
  if (array1832 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1142
  setline(1142);
// Begin line 1114
  setline(1114);
  if (strlit1834 == NULL) {
    strlit1834 = alloc_String("identifier");
  }
// compilenode returning strlit1834
// Begin line 1145
  setline(1145);
// compilenode returning self
  params[0] = strlit1834;
  Object call1835 = callmethod(self, "accept",
    1, params);
// compilenode returning call1835
  Object if1833;
  if (istrue(call1835)) {
  Object *var_pid = alloc_var();
  *var_pid = undefined;
// Begin line 1117
  setline(1117);
// compilenode returning self
  Object call1836 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1836
// Begin line 1119
  setline(1119);
// Begin line 1577
  setline(1577);
// Begin line 1118
  setline(1118);
// compilenode returning *var_values
  Object call1837 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1837
// compilenode returning call1837
  var_pid = alloc_var();
  *var_pid = call1837;
  if (call1837 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1124
  setline(1124);
// Begin line 1119
  setline(1119);
  if (strlit1839 == NULL) {
    strlit1839 = alloc_String("colon");
  }
// compilenode returning strlit1839
// Begin line 1125
  setline(1125);
// compilenode returning self
  params[0] = strlit1839;
  Object call1840 = callmethod(self, "accept",
    1, params);
// compilenode returning call1840
  Object if1838;
  if (istrue(call1840)) {
// Begin line 1120
  setline(1120);
// compilenode returning self
  Object call1841 = callmethod(self, "next",
    0, params);
// compilenode returning call1841
// Begin line 1121
  setline(1121);
// compilenode returning self
  Object call1842 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1842
// Begin line 1122
  setline(1122);
// compilenode returning self
  Object call1843 = callmethod(self, "generic",
    0, params);
// compilenode returning call1843
// Begin line 1124
  setline(1124);
// Begin line 1577
  setline(1577);
// Begin line 1124
  setline(1124);
// Begin line 1577
  setline(1577);
// Begin line 1123
  setline(1123);
// compilenode returning *var_values
  Object call1844 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1844
// compilenode returning call1844
// compilenode returning *var_pid
  params[0] = call1844;
  Object call1845 = callmethod(*var_pid, "dtype:=",
    1, params);
// compilenode returning call1845
// compilenode returning nothing
    if1838 = nothing;
  } else {
  }
// compilenode returning if1838
// Begin line 1125
  setline(1125);
// compilenode returning *var_pid
// compilenode returning *var_params
  params[0] = *var_pid;
  Object call1846 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1846
// Begin line 1137
  setline(1137);
  Object while1847;
  while (1) {
// Begin line 1126
  setline(1126);
  if (strlit1848 == NULL) {
    strlit1848 = alloc_String("comma");
  }
// compilenode returning strlit1848
// Begin line 1139
  setline(1139);
// compilenode returning self
  params[0] = strlit1848;
  Object call1849 = callmethod(self, "accept",
    1, params);
// compilenode returning call1849
    while1847 = call1849;
    if (!istrue(call1849)) break;
// Begin line 1127
  setline(1127);
// compilenode returning self
  Object call1850 = callmethod(self, "next",
    0, params);
// compilenode returning call1850
// Begin line 1128
  setline(1128);
// compilenode returning self
  Object call1851 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1851
// Begin line 1129
  setline(1129);
// compilenode returning self
  Object call1852 = callmethod(self, "generic",
    0, params);
// compilenode returning call1852
// Begin line 1131
  setline(1131);
// Begin line 1577
  setline(1577);
// Begin line 1130
  setline(1130);
// compilenode returning *var_values
  Object call1853 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1853
// compilenode returning call1853
  *var_pid = call1853;
  if (call1853 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1136
  setline(1136);
// Begin line 1131
  setline(1131);
  if (strlit1856 == NULL) {
    strlit1856 = alloc_String("colon");
  }
// compilenode returning strlit1856
// Begin line 1137
  setline(1137);
// compilenode returning self
  params[0] = strlit1856;
  Object call1857 = callmethod(self, "accept",
    1, params);
// compilenode returning call1857
  Object if1855;
  if (istrue(call1857)) {
// Begin line 1132
  setline(1132);
// compilenode returning self
  Object call1858 = callmethod(self, "next",
    0, params);
// compilenode returning call1858
// Begin line 1133
  setline(1133);
// compilenode returning self
  Object call1859 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1859
// Begin line 1134
  setline(1134);
// compilenode returning self
  Object call1860 = callmethod(self, "generic",
    0, params);
// compilenode returning call1860
// Begin line 1136
  setline(1136);
// Begin line 1577
  setline(1577);
// Begin line 1136
  setline(1136);
// Begin line 1577
  setline(1577);
// Begin line 1135
  setline(1135);
// compilenode returning *var_values
  Object call1861 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1861
// compilenode returning call1861
// compilenode returning *var_pid
  params[0] = call1861;
  Object call1862 = callmethod(*var_pid, "dtype:=",
    1, params);
// compilenode returning call1862
// compilenode returning nothing
    if1855 = nothing;
  } else {
  }
// compilenode returning if1855
// Begin line 1137
  setline(1137);
// compilenode returning *var_pid
// compilenode returning *var_params
  params[0] = *var_pid;
  Object call1863 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call1863
  }
// compilenode returning while1847
// Begin line 1142
  setline(1142);
// Begin line 1139
  setline(1139);
  if (strlit1865 == NULL) {
    strlit1865 = alloc_String("arrow");
  }
// compilenode returning strlit1865
// Begin line 1144
  setline(1144);
// compilenode returning self
  params[0] = strlit1865;
  Object call1866 = callmethod(self, "accept",
    1, params);
// compilenode returning call1866
  Object if1864;
  if (istrue(call1866)) {
// Begin line 1140
  setline(1140);
// compilenode returning self
  Object call1867 = callmethod(self, "next",
    0, params);
// compilenode returning call1867
    if1864 = call1867;
  } else {
// Begin line 1142
  setline(1142);
  if (strlit1868 == NULL) {
    strlit1868 = alloc_String("expected ->.");
  }
// compilenode returning strlit1868
// compilenode returning module_util
  params[0] = strlit1868;
  Object call1869 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1869
    if1864 = call1869;
  }
// compilenode returning if1864
    if1833 = if1864;
  } else {
  }
// compilenode returning if1833
// Begin line 1146
  setline(1146);
// Begin line 1577
  setline(1577);
// Begin line 1145
  setline(1145);
// compilenode returning *var_values
  Object call1870 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call1870
// compilenode returning call1870
  var_sz = alloc_var();
  *var_sz = call1870;
  if (call1870 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1156
  setline(1156);
  Object while1871;
  while (1) {
// Begin line 1146
  setline(1146);
// Begin line 1577
  setline(1577);
// Begin line 1146
  setline(1146);
  if (strlit1872 == NULL) {
    strlit1872 = alloc_String("rbrace");
  }
// compilenode returning strlit1872
// Begin line 1157
  setline(1157);
// compilenode returning self
  params[0] = strlit1872;
  Object call1873 = callmethod(self, "accept",
    1, params);
// compilenode returning call1873
  Object call1874 = callmethod(call1873, "not",
    0, params);
// compilenode returning call1874
// compilenode returning call1874
    while1871 = call1874;
    if (!istrue(call1874)) break;
// Begin line 1148
  setline(1148);
// compilenode returning self
  Object call1875 = callmethod(self, "vardec",
    0, params);
// compilenode returning call1875
// Begin line 1149
  setline(1149);
// compilenode returning self
  Object call1876 = callmethod(self, "methoddec",
    0, params);
// compilenode returning call1876
// Begin line 1150
  setline(1150);
// compilenode returning self
  Object call1877 = callmethod(self, "defdec",
    0, params);
// compilenode returning call1877
// Begin line 1153
  setline(1153);
// Begin line 1155
  setline(1155);
// Begin line 1577
  setline(1577);
// Begin line 1151
  setline(1151);
// compilenode returning *var_values
  Object call1879 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call1879
// compilenode returning call1879
// compilenode returning *var_sz
  params[0] = *var_sz;
  Object opresult1881 = callmethod(call1879, "==", 1, params);
// compilenode returning opresult1881
  Object if1878;
  if (istrue(opresult1881)) {
// Begin line 1153
  setline(1153);
// Begin line 1152
  setline(1152);
  if (strlit1882 == NULL) {
    strlit1882 = alloc_String("did not consume anything in ");
  }
// compilenode returning strlit1882
// Begin line 1153
  setline(1153);
  if (strlit1883 == NULL) {
    strlit1883 = alloc_String("class declaration.");
  }
// compilenode returning strlit1883
  params[0] = strlit1883;
  Object opresult1885 = callmethod(strlit1882, "++", 1, params);
// compilenode returning opresult1885
// Begin line 1152
  setline(1152);
// compilenode returning module_util
  params[0] = opresult1885;
  Object call1886 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1886
    if1878 = call1886;
  } else {
  }
// compilenode returning if1878
// Begin line 1156
  setline(1156);
// Begin line 1577
  setline(1577);
// Begin line 1155
  setline(1155);
// compilenode returning *var_values
  Object call1887 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call1887
// compilenode returning call1887
  *var_sz = call1887;
  if (call1887 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while1871
// Begin line 1157
  setline(1157);
// compilenode returning self
  Object call1889 = callmethod(self, "next",
    0, params);
// compilenode returning call1889
// Begin line 1159
  setline(1159);
  Object array1890 = alloc_List();
// compilenode returning array1890
  var_rbody = alloc_var();
  *var_rbody = array1890;
  if (array1890 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1160
  setline(1160);
// Begin line 1577
  setline(1577);
// Begin line 1159
  setline(1159);
// compilenode returning *var_values
  Object call1891 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1891
// compilenode returning call1891
  var_n = alloc_var();
  *var_n = call1891;
  if (call1891 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1163
  setline(1163);
  Object while1892;
  while (1) {
// Begin line 1164
  setline(1164);
// Begin line 1577
  setline(1577);
// Begin line 1160
  setline(1160);
// compilenode returning *var_n
  Object call1893 = callmethod(*var_n, "kind",
    0, params);
// compilenode returning call1893
// compilenode returning call1893
  if (strlit1894 == NULL) {
    strlit1894 = alloc_String("lbrace");
  }
// compilenode returning strlit1894
  params[0] = strlit1894;
  Object opresult1896 = callmethod(call1893, "/=", 1, params);
// compilenode returning opresult1896
    while1892 = opresult1896;
    if (!istrue(opresult1896)) break;
// Begin line 1161
  setline(1161);
// compilenode returning *var_n
// compilenode returning *var_rbody
  params[0] = *var_n;
  Object call1897 = callmethod(*var_rbody, "push",
    1, params);
// compilenode returning call1897
// Begin line 1163
  setline(1163);
// Begin line 1577
  setline(1577);
// Begin line 1162
  setline(1162);
// compilenode returning *var_values
  Object call1898 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1898
// compilenode returning call1898
  *var_n = call1898;
  if (call1898 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while1892
// Begin line 1165
  setline(1165);
  Object array1900 = alloc_List();
// compilenode returning array1900
  var_body = alloc_var();
  *var_body = array1900;
  if (array1900 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1167
  setline(1167);
// Begin line 1169
  setline(1169);
// Begin line 1577
  setline(1577);
// Begin line 1165
  setline(1165);
// compilenode returning *var_rbody
  Object call1902 = callmethod(*var_rbody, "indices",
    0, params);
// compilenode returning call1902
// compilenode returning call1902
// Begin line 1167
  setline(1167);
// Begin line 1577
  setline(1577);
  Object obj1904 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1904, self, 0);
  addmethod2(obj1904, "outer", &reader_parser_outer_1905);
  adddatum2(obj1904, self, 0);
  block_savedest(obj1904);
  Object **closure1906 = createclosure(3);
  addtoclosure(closure1906, var_rbody);
  addtoclosure(closure1906, var_body);
  Object *selfpp1909 = alloc_var();
  *selfpp1909 = self;
  addtoclosure(closure1906, selfpp1909);
  struct UserObject *uo1906 = (struct UserObject*)obj1904;
  uo1906->data[1] = (Object)closure1906;
  addmethod2(obj1904, "apply", &meth_parser_apply1906);
  set_type(obj1904, 0);
// compilenode returning obj1904
  setclassname(obj1904, "Block<parser:1903>");
// compilenode returning obj1904
  params[0] = call1902;
  Object iter1901 = callmethod(call1902, "iter", 1, params);
  while(1) {
    Object cond1901 = callmethod(iter1901, "havemore", 0, NULL);
    if (!istrue(cond1901)) break;
    params[0] = callmethod(iter1901, "next", 0, NULL);
    callmethod(obj1904, "apply", 1, params);
  }
// compilenode returning call1902
// Begin line 1169
  setline(1169);
// compilenode returning *var_cname
// compilenode returning *var_params
// compilenode returning *var_body
// compilenode returning *var_superclass
// compilenode returning module_ast
  params[0] = *var_cname;
  params[1] = *var_params;
  params[2] = *var_body;
  params[3] = *var_superclass;
  Object call1910 = callmethod(module_ast, "astclass",
    4, params);
// compilenode returning call1910
  var_o = alloc_var();
  *var_o = call1910;
  if (call1910 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1170
  setline(1170);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call1911 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call1911
    if1821 = call1911;
  } else {
// Begin line 1172
  setline(1172);
  if (strlit1912 == NULL) {
    strlit1912 = alloc_String("class definition without body");
  }
// compilenode returning strlit1912
// compilenode returning module_util
  params[0] = strlit1912;
  Object call1913 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1913
    if1821 = call1913;
  }
// compilenode returning if1821
    if1756 = if1821;
  } else {
  }
// compilenode returning if1756
  return if1756;
}
Object meth_parser_apply1929(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_methname = closure[0];
  Object *var_params = closure[1];
  Object *var_lastparamcount = closure[2];
  Object self = *closure[3];
// Begin line 1194
  setline(1194);
// Begin line 1193
  setline(1193);
// compilenode returning *var_methname
// Begin line 1194
  setline(1194);
// Begin line 1193
  setline(1193);
  if (strlit1930 == NULL) {
    strlit1930 = alloc_String("(");
  }
// compilenode returning strlit1930
// Begin line 1194
  setline(1194);
// Begin line 1577
  setline(1577);
// Begin line 1193
  setline(1193);
// compilenode returning *var_params
  Object call1931 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call1931
// compilenode returning call1931
// compilenode returning *var_lastparamcount
  params[0] = *var_lastparamcount;
  Object diff1933 = callmethod(call1931, "-", 1, params);
// compilenode returning diff1933
  params[0] = diff1933;
  Object opresult1935 = callmethod(strlit1930, "++", 1, params);
// compilenode returning opresult1935
  if (strlit1936 == NULL) {
    strlit1936 = alloc_String(")");
  }
// compilenode returning strlit1936
  params[0] = strlit1936;
  Object opresult1938 = callmethod(opresult1935, "++", 1, params);
// compilenode returning opresult1938
  params[0] = opresult1938;
  Object opresult1940 = callmethod(*var_methname, "++", 1, params);
// compilenode returning opresult1940
  *var_methname = opresult1940;
  if (opresult1940 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1195
  setline(1195);
// Begin line 1577
  setline(1577);
// Begin line 1194
  setline(1194);
// compilenode returning *var_params
  Object call1942 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call1942
// compilenode returning call1942
  *var_lastparamcount = call1942;
  if (call1942 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply1948(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_methname = closure[0];
  Object self = *closure[1];
// Begin line 1196
  setline(1196);
  Object bool1949 = alloc_Boolean(0);
// compilenode returning bool1949
// Begin line 1198
  setline(1198);
// Begin line 1197
  setline(1197);
// compilenode returning *var_methname
  if (strlit1950 == NULL) {
    strlit1950 = alloc_String("()");
  }
// compilenode returning strlit1950
  params[0] = strlit1950;
  Object opresult1952 = callmethod(*var_methname, "++", 1, params);
// compilenode returning opresult1952
  *var_methname = opresult1952;
  if (opresult1952 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_parsempmndecrest1914(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[37];
  Object *var_tm = alloc_var();
  *var_tm = args[0];
  Object params[2];
  Object *var_values = closure[0];
  Object *var_sym = closure[1];
  Object *var_methname = alloc_var();
  *var_methname = undefined;
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_lastparamcount = alloc_var();
  *var_lastparamcount = undefined;
  Object *var_nxt = alloc_var();
  *var_nxt = undefined;
  Object *var_varargs = alloc_var();
  *var_varargs = undefined;
// Begin line 1184
  setline(1184);
// Begin line 1577
  setline(1577);
// Begin line 1184
  setline(1184);
// Begin line 1577
  setline(1577);
// Begin line 1183
  setline(1183);
// compilenode returning *var_tm
  Object call1915 = callmethod(*var_tm, "value",
    0, params);
// compilenode returning call1915
// compilenode returning call1915
  Object call1916 = callmethod(call1915, "value",
    0, params);
// compilenode returning call1916
// compilenode returning call1916
  var_methname = alloc_var();
  *var_methname = call1916;
  if (call1916 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1185
  setline(1185);
// Begin line 1577
  setline(1577);
// Begin line 1184
  setline(1184);
// compilenode returning *var_tm
  Object call1917 = callmethod(*var_tm, "params",
    0, params);
// compilenode returning call1917
// compilenode returning call1917
  *var_params = call1917;
  if (call1917 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1186
  setline(1186);
// Begin line 1185
  setline(1185);
  Object num1918 = alloc_Float64(0.0);
// compilenode returning num1918
  var_lastparamcount = alloc_var();
  *var_lastparamcount = num1918;
  if (num1918 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1187
  setline(1187);
  var_nxt = alloc_var();
  *var_nxt = undefined;
// compilenode returning nothing
// Begin line 1188
  setline(1188);
// Begin line 1187
  setline(1187);
  Object bool1919 = alloc_Boolean(0);
// compilenode returning bool1919
  var_varargs = alloc_var();
  *var_varargs = bool1919;
  if (bool1919 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1236
  setline(1236);
  Object while1920;
  while (1) {
// Begin line 1188
  setline(1188);
  if (strlit1921 == NULL) {
    strlit1921 = alloc_String("identifier");
  }
// compilenode returning strlit1921
// Begin line 1238
  setline(1238);
// compilenode returning self
  params[0] = strlit1921;
  Object call1922 = callmethod(self, "accept",
    1, params);
// compilenode returning call1922
    while1920 = call1922;
    if (!istrue(call1922)) break;
// Begin line 1190
  setline(1190);
// Begin line 1189
  setline(1189);
// compilenode returning *var_varargs
  Object if1923;
  if (istrue(*var_varargs)) {
// Begin line 1190
  setline(1190);
  if (strlit1924 == NULL) {
    strlit1924 = alloc_String("varargs parameter must be last.");
  }
// compilenode returning strlit1924
// compilenode returning module_util
  params[0] = strlit1924;
  Object call1925 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1925
    if1923 = call1925;
  } else {
  }
// compilenode returning if1923
// Begin line 1198
  setline(1198);
// Begin line 1195
  setline(1195);
// Begin line 1577
  setline(1577);
  Object obj1927 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1927, self, 0);
  addmethod2(obj1927, "outer", &reader_parser_outer_1928);
  adddatum2(obj1927, self, 0);
  block_savedest(obj1927);
  Object **closure1929 = createclosure(4);
  addtoclosure(closure1929, var_methname);
  addtoclosure(closure1929, var_params);
  addtoclosure(closure1929, var_lastparamcount);
  Object *selfpp1944 = alloc_var();
  *selfpp1944 = self;
  addtoclosure(closure1929, selfpp1944);
  struct UserObject *uo1929 = (struct UserObject*)obj1927;
  uo1929->data[1] = (Object)closure1929;
  addmethod2(obj1927, "apply", &meth_parser_apply1929);
  set_type(obj1927, 0);
// compilenode returning obj1927
  setclassname(obj1927, "Block<parser:1926>");
// compilenode returning obj1927
// Begin line 1198
  setline(1198);
// Begin line 1577
  setline(1577);
  Object obj1946 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1946, self, 0);
  addmethod2(obj1946, "outer", &reader_parser_outer_1947);
  adddatum2(obj1946, self, 0);
  block_savedest(obj1946);
  Object **closure1948 = createclosure(2);
  addtoclosure(closure1948, var_methname);
  Object *selfpp1954 = alloc_var();
  *selfpp1954 = self;
  addtoclosure(closure1948, selfpp1954);
  struct UserObject *uo1948 = (struct UserObject*)obj1946;
  uo1948->data[1] = (Object)closure1948;
  addmethod2(obj1946, "apply", &meth_parser_apply1948);
  set_type(obj1946, 0);
// compilenode returning obj1946
  setclassname(obj1946, "Block<parser:1945>");
// compilenode returning obj1946
// Begin line 1192
  setline(1192);
// compilenode returning module_util
  params[0] = obj1927;
  params[1] = obj1946;
  Object call1955 = callmethod(module_util, "runOnNew(1)else",
    2, params);
// compilenode returning call1955
// Begin line 1199
  setline(1199);
// compilenode returning self
  Object call1956 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1956
// Begin line 1201
  setline(1201);
// Begin line 1577
  setline(1577);
// Begin line 1200
  setline(1200);
// compilenode returning *var_values
  Object call1957 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1957
// compilenode returning call1957
  *var_nxt = call1957;
  if (call1957 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1202
  setline(1202);
// Begin line 1201
  setline(1201);
// compilenode returning *var_methname
// Begin line 1202
  setline(1202);
// Begin line 1577
  setline(1577);
// Begin line 1201
  setline(1201);
// compilenode returning *var_nxt
  Object call1959 = callmethod(*var_nxt, "value",
    0, params);
// compilenode returning call1959
// compilenode returning call1959
  params[0] = call1959;
  Object opresult1961 = callmethod(*var_methname, "++", 1, params);
// compilenode returning opresult1961
  *var_methname = opresult1961;
  if (opresult1961 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1203
  setline(1203);
// Begin line 1202
  setline(1202);
// Begin line 1577
  setline(1577);
// Begin line 1202
  setline(1202);
  if (strlit1964 == NULL) {
    strlit1964 = alloc_String("lparen");
  }
// compilenode returning strlit1964
// Begin line 1205
  setline(1205);
// compilenode returning self
  params[0] = strlit1964;
  Object call1965 = callmethod(self, "accept",
    1, params);
// compilenode returning call1965
  Object call1966 = callmethod(call1965, "not",
    0, params);
// compilenode returning call1966
// compilenode returning call1966
  Object if1963;
  if (istrue(call1966)) {
// Begin line 1203
  setline(1203);
  if (strlit1967 == NULL) {
    strlit1967 = alloc_String("multi-part method name parameters require .");
  }
// compilenode returning strlit1967
// compilenode returning module_util
  params[0] = strlit1967;
  Object call1968 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1968
    if1963 = call1968;
  } else {
  }
// compilenode returning if1963
// Begin line 1205
  setline(1205);
// compilenode returning self
  Object call1969 = callmethod(self, "next",
    0, params);
// compilenode returning call1969
// Begin line 1232
  setline(1232);
  Object while1970;
  while (1) {
// Begin line 1207
  setline(1207);
// Begin line 1206
  setline(1206);
  if (strlit1971 == NULL) {
    strlit1971 = alloc_String("identifier");
  }
// compilenode returning strlit1971
// Begin line 1235
  setline(1235);
// compilenode returning self
  params[0] = strlit1971;
  Object call1972 = callmethod(self, "accept",
    1, params);
// compilenode returning call1972
// Begin line 1207
  setline(1207);
  if (strlit1973 == NULL) {
    strlit1973 = alloc_String("op");
  }
// compilenode returning strlit1973
// Begin line 1206
  setline(1206);
// compilenode returning self
  params[0] = strlit1973;
  Object call1974 = callmethod(self, "accept",
    1, params);
// compilenode returning call1974
// Begin line 1207
  setline(1207);
// Begin line 1577
  setline(1577);
// Begin line 1207
  setline(1207);
// compilenode returning *var_sym
  Object call1975 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call1975
// compilenode returning call1975
  if (strlit1976 == NULL) {
    strlit1976 = alloc_String("*");
  }
// compilenode returning strlit1976
  params[0] = strlit1976;
  Object opresult1978 = callmethod(call1975, "==", 1, params);
// compilenode returning opresult1978
  params[0] = opresult1978;
  Object opresult1980 = callmethod(call1974, "&", 1, params);
// compilenode returning opresult1980
  params[0] = opresult1980;
  Object opresult1982 = callmethod(call1972, "|", 1, params);
// compilenode returning opresult1982
    while1970 = opresult1982;
    if (!istrue(opresult1982)) break;
// Begin line 1209
  setline(1209);
// Begin line 1208
  setline(1208);
// compilenode returning *var_varargs
  Object if1983;
  if (istrue(*var_varargs)) {
// Begin line 1209
  setline(1209);
  if (strlit1984 == NULL) {
    strlit1984 = alloc_String("varargs parameter must be last.");
  }
// compilenode returning strlit1984
// compilenode returning module_util
  params[0] = strlit1984;
  Object call1985 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1985
    if1983 = call1985;
  } else {
  }
// compilenode returning if1983
// Begin line 1214
  setline(1214);
// Begin line 1211
  setline(1211);
  if (strlit1987 == NULL) {
    strlit1987 = alloc_String("op");
  }
// compilenode returning strlit1987
// Begin line 1216
  setline(1216);
// compilenode returning self
  params[0] = strlit1987;
  Object call1988 = callmethod(self, "accept",
    1, params);
// compilenode returning call1988
  Object if1986;
  if (istrue(call1988)) {
// Begin line 1212
  setline(1212);
// compilenode returning self
  Object call1989 = callmethod(self, "next",
    0, params);
// compilenode returning call1989
// Begin line 1214
  setline(1214);
// Begin line 1213
  setline(1213);
  Object bool1990 = alloc_Boolean(1);
// compilenode returning bool1990
  *var_varargs = bool1990;
  if (bool1990 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1214
  setline(1214);
  if (strlit1992 == NULL) {
    strlit1992 = alloc_String("identifier");
  }
// compilenode returning strlit1992
// Begin line 1215
  setline(1215);
// compilenode returning self
  params[0] = strlit1992;
  Object call1993 = callmethod(self, "expect",
    1, params);
// compilenode returning call1993
    if1986 = call1993;
  } else {
  }
// compilenode returning if1986
// Begin line 1216
  setline(1216);
// compilenode returning self
  Object call1994 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call1994
// Begin line 1218
  setline(1218);
// Begin line 1577
  setline(1577);
// Begin line 1217
  setline(1217);
// compilenode returning *var_values
  Object call1995 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call1995
// compilenode returning call1995
  *var_nxt = call1995;
  if (call1995 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1223
  setline(1223);
// Begin line 1218
  setline(1218);
  if (strlit1998 == NULL) {
    strlit1998 = alloc_String("colon");
  }
// compilenode returning strlit1998
// Begin line 1224
  setline(1224);
// compilenode returning self
  params[0] = strlit1998;
  Object call1999 = callmethod(self, "accept",
    1, params);
// compilenode returning call1999
  Object if1997;
  if (istrue(call1999)) {
  Object *var_tp = alloc_var();
  *var_tp = undefined;
// Begin line 1219
  setline(1219);
// compilenode returning self
  Object call2000 = callmethod(self, "next",
    0, params);
// compilenode returning call2000
// Begin line 1220
  setline(1220);
// compilenode returning self
  Object call2001 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2001
// Begin line 1222
  setline(1222);
// Begin line 1577
  setline(1577);
// Begin line 1221
  setline(1221);
// compilenode returning *var_values
  Object call2002 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2002
// compilenode returning call2002
  var_tp = alloc_var();
  *var_tp = call2002;
  if (call2002 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1223
  setline(1223);
// Begin line 1577
  setline(1577);
// Begin line 1222
  setline(1222);
// compilenode returning *var_tp
// compilenode returning *var_nxt
  params[0] = *var_tp;
  Object call2003 = callmethod(*var_nxt, "dtype:=",
    1, params);
// compilenode returning call2003
// compilenode returning nothing
    if1997 = nothing;
  } else {
  }
// compilenode returning if1997
// Begin line 1229
  setline(1229);
// Begin line 1224
  setline(1224);
// compilenode returning *var_varargs
  Object if2004;
  if (istrue(*var_varargs)) {
// Begin line 1226
  setline(1226);
// Begin line 1577
  setline(1577);
// Begin line 1225
  setline(1225);
// compilenode returning *var_nxt
// compilenode returning *var_tm
  params[0] = *var_nxt;
  Object call2005 = callmethod(*var_tm, "vararg:=",
    1, params);
// compilenode returning call2005
// compilenode returning nothing
// Begin line 1227
  setline(1227);
// Begin line 1577
  setline(1577);
// Begin line 1226
  setline(1226);
  Object bool2006 = alloc_Boolean(1);
// compilenode returning bool2006
// compilenode returning *var_tm
  params[0] = bool2006;
  Object call2007 = callmethod(*var_tm, "varargs:=",
    1, params);
// compilenode returning call2007
// compilenode returning nothing
// Begin line 1227
  setline(1227);
  if (strlit2008 == NULL) {
    strlit2008 = alloc_String("rparen");
  }
// compilenode returning strlit2008
// Begin line 1228
  setline(1228);
// compilenode returning self
  params[0] = strlit2008;
  Object call2009 = callmethod(self, "expect",
    1, params);
// compilenode returning call2009
    if2004 = call2009;
  } else {
// Begin line 1229
  setline(1229);
// compilenode returning *var_nxt
// compilenode returning *var_params
  params[0] = *var_nxt;
  Object call2010 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call2010
    if2004 = call2010;
  }
// compilenode returning if2004
// Begin line 1232
  setline(1232);
// Begin line 1231
  setline(1231);
  if (strlit2012 == NULL) {
    strlit2012 = alloc_String("comma");
  }
// compilenode returning strlit2012
// Begin line 1234
  setline(1234);
// compilenode returning self
  params[0] = strlit2012;
  Object call2013 = callmethod(self, "accept",
    1, params);
// compilenode returning call2013
  Object if2011;
  if (istrue(call2013)) {
// Begin line 1232
  setline(1232);
// compilenode returning self
  Object call2014 = callmethod(self, "next",
    0, params);
// compilenode returning call2014
    if2011 = call2014;
  } else {
  }
// compilenode returning if2011
  }
// compilenode returning while1970
// Begin line 1235
  setline(1235);
  if (strlit2015 == NULL) {
    strlit2015 = alloc_String("rparen");
  }
// compilenode returning strlit2015
// Begin line 1236
  setline(1236);
// compilenode returning self
  params[0] = strlit2015;
  Object call2016 = callmethod(self, "expect",
    1, params);
// compilenode returning call2016
// compilenode returning self
  Object call2017 = callmethod(self, "next",
    0, params);
// compilenode returning call2017
  }
// compilenode returning while1920
// Begin line 1238
  setline(1238);
// compilenode returning *var_methname
  Object bool2018 = alloc_Boolean(0);
// compilenode returning bool2018
// compilenode returning module_ast
  params[0] = *var_methname;
  params[1] = bool2018;
  Object call2019 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call2019
  return call2019;
}
Object meth_parser_methoddec2020(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[38];
  Object params[4];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
  Object *var_minIndentLevel = closure[2];
// Begin line 1243
  setline(1243);
  if (strlit2022 == NULL) {
    strlit2022 = alloc_String("keyword");
  }
// compilenode returning strlit2022
// Begin line 1358
  setline(1358);
// compilenode returning self
  params[0] = strlit2022;
  Object call2023 = callmethod(self, "accept",
    1, params);
// compilenode returning call2023
// Begin line 1243
  setline(1243);
// Begin line 1577
  setline(1577);
// Begin line 1243
  setline(1243);
// compilenode returning *var_sym
  Object call2024 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2024
// compilenode returning call2024
  if (strlit2025 == NULL) {
    strlit2025 = alloc_String("method");
  }
// compilenode returning strlit2025
  params[0] = strlit2025;
  Object opresult2027 = callmethod(call2024, "==", 1, params);
// compilenode returning opresult2027
  params[0] = opresult2027;
  Object opresult2029 = callmethod(call2023, "&", 1, params);
// compilenode returning opresult2029
  Object if2021;
  if (istrue(opresult2029)) {
  Object *var_meth = alloc_var();
  *var_meth = undefined;
  Object *var_rparams = alloc_var();
  *var_rparams = undefined;
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_dtype = alloc_var();
  *var_dtype = undefined;
  Object *var_varargs = alloc_var();
  *var_varargs = undefined;
  Object *var_vararg = alloc_var();
  *var_vararg = undefined;
  Object *var_body = alloc_var();
  *var_body = undefined;
  Object *var_stok = alloc_var();
  *var_stok = undefined;
  Object *var_localMin = alloc_var();
  *var_localMin = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1244
  setline(1244);
// compilenode returning self
  Object call2030 = callmethod(self, "next",
    0, params);
// compilenode returning call2030
// Begin line 1245
  setline(1245);
  if (strlit2031 == NULL) {
    strlit2031 = alloc_String("identifier");
  }
// compilenode returning strlit2031
  if (strlit2032 == NULL) {
    strlit2032 = alloc_String("op");
  }
// compilenode returning strlit2032
// Begin line 1246
  setline(1246);
// compilenode returning self
  params[0] = strlit2031;
  params[1] = strlit2032;
  Object call2033 = callmethod(self, "expect(1)or",
    2, params);
// compilenode returning call2033
// compilenode returning self
  Object call2034 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2034
// Begin line 1248
  setline(1248);
// Begin line 1577
  setline(1577);
// Begin line 1247
  setline(1247);
// compilenode returning *var_values
  Object call2035 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2035
// compilenode returning call2035
  var_meth = alloc_var();
  *var_meth = call2035;
  if (call2035 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1253
  setline(1253);
// Begin line 1248
  setline(1248);
  if (strlit2037 == NULL) {
    strlit2037 = alloc_String("bind");
  }
// compilenode returning strlit2037
// Begin line 1255
  setline(1255);
// compilenode returning self
  params[0] = strlit2037;
  Object call2038 = callmethod(self, "accept",
    1, params);
// compilenode returning call2038
  Object if2036;
  if (istrue(call2038)) {
// Begin line 1249
  setline(1249);
// compilenode returning self
  Object call2039 = callmethod(self, "next",
    0, params);
// compilenode returning call2039
// Begin line 1251
  setline(1251);
// Begin line 1577
  setline(1577);
// Begin line 1251
  setline(1251);
// Begin line 1577
  setline(1577);
// Begin line 1250
  setline(1250);
// compilenode returning *var_meth
  Object call2040 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call2040
// compilenode returning call2040
  if (strlit2041 == NULL) {
    strlit2041 = alloc_String(":=");
  }
// compilenode returning strlit2041
  params[0] = strlit2041;
  Object opresult2043 = callmethod(call2040, "++", 1, params);
// compilenode returning opresult2043
// compilenode returning *var_meth
  params[0] = opresult2043;
  Object call2044 = callmethod(*var_meth, "value:=",
    1, params);
// compilenode returning call2044
// compilenode returning nothing
    if2036 = nothing;
  } else {
// Begin line 1253
  setline(1253);
// Begin line 1251
  setline(1251);
  if (strlit2046 == NULL) {
    strlit2046 = alloc_String("op");
  }
// compilenode returning strlit2046
// Begin line 1255
  setline(1255);
// compilenode returning self
  params[0] = strlit2046;
  Object call2047 = callmethod(self, "accept",
    1, params);
// compilenode returning call2047
// Begin line 1251
  setline(1251);
// Begin line 1577
  setline(1577);
// Begin line 1251
  setline(1251);
// compilenode returning *var_meth
  Object call2048 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call2048
// compilenode returning call2048
  if (strlit2049 == NULL) {
    strlit2049 = alloc_String("prefix");
  }
// compilenode returning strlit2049
  params[0] = strlit2049;
  Object opresult2051 = callmethod(call2048, "==", 1, params);
// compilenode returning opresult2051
  params[0] = opresult2051;
  Object opresult2053 = callmethod(call2047, "&", 1, params);
// compilenode returning opresult2053
  Object if2045;
  if (istrue(opresult2053)) {
// Begin line 1253
  setline(1253);
// Begin line 1577
  setline(1577);
// Begin line 1253
  setline(1253);
// Begin line 1577
  setline(1577);
// Begin line 1252
  setline(1252);
// compilenode returning *var_meth
  Object call2054 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call2054
// compilenode returning call2054
// Begin line 1253
  setline(1253);
// Begin line 1577
  setline(1577);
// Begin line 1252
  setline(1252);
// compilenode returning *var_sym
  Object call2055 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2055
// compilenode returning call2055
  params[0] = call2055;
  Object opresult2057 = callmethod(call2054, "++", 1, params);
// compilenode returning opresult2057
// compilenode returning *var_meth
  params[0] = opresult2057;
  Object call2058 = callmethod(*var_meth, "value:=",
    1, params);
// compilenode returning call2058
// compilenode returning nothing
// Begin line 1253
  setline(1253);
// compilenode returning self
  Object call2059 = callmethod(self, "next",
    0, params);
// compilenode returning call2059
    if2045 = call2059;
  } else {
  }
// compilenode returning if2045
    if2036 = if2045;
  }
// compilenode returning if2036
// Begin line 1256
  setline(1256);
  Object array2060 = alloc_List();
// compilenode returning array2060
  var_rparams = alloc_var();
  *var_rparams = array2060;
  if (array2060 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1257
  setline(1257);
  Object array2061 = alloc_List();
// compilenode returning array2061
  var_params = alloc_var();
  *var_params = array2061;
  if (array2061 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1258
  setline(1258);
// Begin line 1257
  setline(1257);
  Object bool2062 = alloc_Boolean(0);
// compilenode returning bool2062
  var_dtype = alloc_var();
  *var_dtype = bool2062;
  if (bool2062 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1259
  setline(1259);
// Begin line 1258
  setline(1258);
  Object bool2063 = alloc_Boolean(0);
// compilenode returning bool2063
  var_varargs = alloc_var();
  *var_varargs = bool2063;
  if (bool2063 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1260
  setline(1260);
// Begin line 1259
  setline(1259);
  Object bool2064 = alloc_Boolean(0);
// compilenode returning bool2064
  var_vararg = alloc_var();
  *var_vararg = bool2064;
  if (bool2064 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1305
  setline(1305);
// Begin line 1260
  setline(1260);
  if (strlit2066 == NULL) {
    strlit2066 = alloc_String("lparen");
  }
// compilenode returning strlit2066
// Begin line 1307
  setline(1307);
// compilenode returning self
  params[0] = strlit2066;
  Object call2067 = callmethod(self, "accept",
    1, params);
// compilenode returning call2067
  Object if2065;
  if (istrue(call2067)) {
  Object *var_id = alloc_var();
  *var_id = undefined;
// Begin line 1261
  setline(1261);
// compilenode returning self
  Object call2068 = callmethod(self, "next",
    0, params);
// compilenode returning call2068
// Begin line 1263
  setline(1263);
  var_id = alloc_var();
  *var_id = undefined;
// compilenode returning nothing
// Begin line 1293
  setline(1293);
  Object while2069;
  while (1) {
// Begin line 1264
  setline(1264);
// Begin line 1263
  setline(1263);
  if (strlit2070 == NULL) {
    strlit2070 = alloc_String("identifier");
  }
// compilenode returning strlit2070
// Begin line 1296
  setline(1296);
// compilenode returning self
  params[0] = strlit2070;
  Object call2071 = callmethod(self, "accept",
    1, params);
// compilenode returning call2071
// Begin line 1264
  setline(1264);
  if (strlit2072 == NULL) {
    strlit2072 = alloc_String("op");
  }
// compilenode returning strlit2072
// Begin line 1263
  setline(1263);
// compilenode returning self
  params[0] = strlit2072;
  Object call2073 = callmethod(self, "accept",
    1, params);
// compilenode returning call2073
// Begin line 1264
  setline(1264);
// Begin line 1577
  setline(1577);
// Begin line 1264
  setline(1264);
// compilenode returning *var_sym
  Object call2074 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2074
// compilenode returning call2074
  if (strlit2075 == NULL) {
    strlit2075 = alloc_String("*");
  }
// compilenode returning strlit2075
  params[0] = strlit2075;
  Object opresult2077 = callmethod(call2074, "==", 1, params);
// compilenode returning opresult2077
  params[0] = opresult2077;
  Object opresult2079 = callmethod(call2073, "&", 1, params);
// compilenode returning opresult2079
  params[0] = opresult2079;
  Object opresult2081 = callmethod(call2071, "|", 1, params);
// compilenode returning opresult2081
    while2069 = opresult2081;
    if (!istrue(opresult2081)) break;
// Begin line 1270
  setline(1270);
// Begin line 1267
  setline(1267);
  if (strlit2083 == NULL) {
    strlit2083 = alloc_String("op");
  }
// compilenode returning strlit2083
// Begin line 1271
  setline(1271);
// compilenode returning self
  params[0] = strlit2083;
  Object call2084 = callmethod(self, "accept",
    1, params);
// compilenode returning call2084
  Object if2082;
  if (istrue(call2084)) {
// Begin line 1268
  setline(1268);
// compilenode returning self
  Object call2085 = callmethod(self, "next",
    0, params);
// compilenode returning call2085
// Begin line 1270
  setline(1270);
// Begin line 1269
  setline(1269);
  Object bool2086 = alloc_Boolean(1);
// compilenode returning bool2086
  *var_varargs = bool2086;
  if (bool2086 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2082 = nothing;
  } else {
  }
// compilenode returning if2082
// Begin line 1271
  setline(1271);
// compilenode returning self
  Object call2088 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2088
// Begin line 1273
  setline(1273);
// Begin line 1577
  setline(1577);
// Begin line 1272
  setline(1272);
// compilenode returning *var_values
  Object call2089 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2089
// compilenode returning call2089
  *var_id = call2089;
  if (call2089 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1274
  setline(1274);
// Begin line 1273
  setline(1273);
  Object bool2091 = alloc_Boolean(0);
// compilenode returning bool2091
  *var_dtype = bool2091;
  if (bool2091 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1280
  setline(1280);
// Begin line 1274
  setline(1274);
  if (strlit2094 == NULL) {
    strlit2094 = alloc_String("colon");
  }
// compilenode returning strlit2094
// Begin line 1283
  setline(1283);
// compilenode returning self
  params[0] = strlit2094;
  Object call2095 = callmethod(self, "accept",
    1, params);
// compilenode returning call2095
  Object if2093;
  if (istrue(call2095)) {
// Begin line 1275
  setline(1275);
// compilenode returning self
  Object call2096 = callmethod(self, "next",
    0, params);
// compilenode returning call2096
// Begin line 1280
  setline(1280);
// Begin line 1276
  setline(1276);
  if (strlit2098 == NULL) {
    strlit2098 = alloc_String("identifier");
  }
// compilenode returning strlit2098
// Begin line 1282
  setline(1282);
// compilenode returning self
  params[0] = strlit2098;
  Object call2099 = callmethod(self, "accept",
    1, params);
// compilenode returning call2099
  Object if2097;
  if (istrue(call2099)) {
// Begin line 1277
  setline(1277);
// compilenode returning self
  Object call2100 = callmethod(self, "dotyperef",
    0, params);
// compilenode returning call2100
// Begin line 1279
  setline(1279);
// Begin line 1577
  setline(1577);
// Begin line 1278
  setline(1278);
// compilenode returning *var_values
  Object call2101 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2101
// compilenode returning call2101
  *var_dtype = call2101;
  if (call2101 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2097 = nothing;
  } else {
// Begin line 1280
  setline(1280);
  if (strlit2103 == NULL) {
    strlit2103 = alloc_String("expected type after :.");
  }
// compilenode returning strlit2103
// compilenode returning module_util
  params[0] = strlit2103;
  Object call2104 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2104
    if2097 = call2104;
  }
// compilenode returning if2097
    if2093 = if2097;
  } else {
  }
// compilenode returning if2093
// Begin line 1284
  setline(1284);
// Begin line 1577
  setline(1577);
// Begin line 1283
  setline(1283);
// compilenode returning *var_dtype
// compilenode returning *var_id
  params[0] = *var_dtype;
  Object call2105 = callmethod(*var_id, "dtype:=",
    1, params);
// compilenode returning call2105
// compilenode returning nothing
// Begin line 1288
  setline(1288);
// Begin line 1284
  setline(1284);
// compilenode returning *var_varargs
  Object if2106;
  if (istrue(*var_varargs)) {
// Begin line 1286
  setline(1286);
// Begin line 1285
  setline(1285);
// compilenode returning *var_id
  *var_vararg = *var_id;
  if (*var_id == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1286
  setline(1286);
  if (strlit2108 == NULL) {
    strlit2108 = alloc_String("rparen");
  }
// compilenode returning strlit2108
// Begin line 1287
  setline(1287);
// compilenode returning self
  params[0] = strlit2108;
  Object call2109 = callmethod(self, "expect",
    1, params);
// compilenode returning call2109
    if2106 = call2109;
  } else {
// Begin line 1288
  setline(1288);
// compilenode returning *var_id
// compilenode returning *var_params
  params[0] = *var_id;
  Object call2110 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call2110
    if2106 = call2110;
  }
// compilenode returning if2106
// Begin line 1293
  setline(1293);
// Begin line 1290
  setline(1290);
  if (strlit2112 == NULL) {
    strlit2112 = alloc_String("comma");
  }
// compilenode returning strlit2112
// Begin line 1295
  setline(1295);
// compilenode returning self
  params[0] = strlit2112;
  Object call2113 = callmethod(self, "accept",
    1, params);
// compilenode returning call2113
  Object if2111;
  if (istrue(call2113)) {
// Begin line 1291
  setline(1291);
// compilenode returning self
  Object call2114 = callmethod(self, "next",
    0, params);
// compilenode returning call2114
    if2111 = call2114;
  } else {
// Begin line 1293
  setline(1293);
// Begin line 1292
  setline(1292);
// Begin line 1577
  setline(1577);
// Begin line 1292
  setline(1292);
  if (strlit2116 == NULL) {
    strlit2116 = alloc_String("rparen");
  }
// compilenode returning strlit2116
// Begin line 1295
  setline(1295);
// compilenode returning self
  params[0] = strlit2116;
  Object call2117 = callmethod(self, "accept",
    1, params);
// compilenode returning call2117
  Object call2118 = callmethod(call2117, "not",
    0, params);
// compilenode returning call2118
// compilenode returning call2118
  Object if2115;
  if (istrue(call2118)) {
// Begin line 1293
  setline(1293);
  if (strlit2119 == NULL) {
    strlit2119 = alloc_String("expected comma or rparen.");
  }
// compilenode returning strlit2119
// compilenode returning module_util
  params[0] = strlit2119;
  Object call2120 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2120
    if2115 = call2120;
  } else {
  }
// compilenode returning if2115
    if2111 = if2115;
  }
// compilenode returning if2111
  }
// compilenode returning while2069
// Begin line 1296
  setline(1296);
  if (strlit2121 == NULL) {
    strlit2121 = alloc_String("rparen");
  }
// compilenode returning strlit2121
// Begin line 1297
  setline(1297);
// compilenode returning self
  params[0] = strlit2121;
  Object call2122 = callmethod(self, "expect",
    1, params);
// compilenode returning call2122
// compilenode returning self
  Object call2123 = callmethod(self, "next",
    0, params);
// compilenode returning call2123
// Begin line 1305
  setline(1305);
// Begin line 1298
  setline(1298);
  if (strlit2125 == NULL) {
    strlit2125 = alloc_String("identifier");
  }
// compilenode returning strlit2125
// Begin line 1306
  setline(1306);
// compilenode returning self
  params[0] = strlit2125;
  Object call2126 = callmethod(self, "accept",
    1, params);
// compilenode returning call2126
  Object if2124;
  if (istrue(call2126)) {
  Object *var_tm = alloc_var();
  *var_tm = undefined;
// Begin line 1301
  setline(1301);
// compilenode returning *var_meth
// compilenode returning *var_params
  Object array2127 = alloc_List();
// compilenode returning array2127
  Object bool2128 = alloc_Boolean(0);
// compilenode returning bool2128
// compilenode returning module_ast
  params[0] = *var_meth;
  params[1] = *var_params;
  params[2] = array2127;
  params[3] = bool2128;
  Object call2129 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call2129
  var_tm = alloc_var();
  *var_tm = call2129;
  if (call2129 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1302
  setline(1302);
// compilenode returning *var_tm
// Begin line 1303
  setline(1303);
// compilenode returning self
  params[0] = *var_tm;
  Object call2130 = callmethod(self, "parsempmndecrest",
    1, params);
// compilenode returning call2130
  *var_meth = call2130;
  if (call2130 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1304
  setline(1304);
// Begin line 1577
  setline(1577);
// Begin line 1303
  setline(1303);
// compilenode returning *var_tm
  Object call2132 = callmethod(*var_tm, "varargs",
    0, params);
// compilenode returning call2132
// compilenode returning call2132
  *var_varargs = call2132;
  if (call2132 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1305
  setline(1305);
// Begin line 1577
  setline(1577);
// Begin line 1304
  setline(1304);
// compilenode returning *var_tm
  Object call2134 = callmethod(*var_tm, "vararg",
    0, params);
// compilenode returning call2134
// compilenode returning call2134
  *var_vararg = call2134;
  if (call2134 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2124 = nothing;
  } else {
  }
// compilenode returning if2124
    if2065 = if2124;
  } else {
  }
// compilenode returning if2065
// Begin line 1314
  setline(1314);
// Begin line 1307
  setline(1307);
  if (strlit2137 == NULL) {
    strlit2137 = alloc_String("arrow");
  }
// compilenode returning strlit2137
// Begin line 1315
  setline(1315);
// compilenode returning self
  params[0] = strlit2137;
  Object call2138 = callmethod(self, "accept",
    1, params);
// compilenode returning call2138
  Object if2136;
  if (istrue(call2138)) {
// Begin line 1309
  setline(1309);
// compilenode returning self
  Object call2139 = callmethod(self, "next",
    0, params);
// compilenode returning call2139
// Begin line 1310
  setline(1310);
// compilenode returning self
  Object call2140 = callmethod(self, "dotyperef",
    0, params);
// compilenode returning call2140
// Begin line 1312
  setline(1312);
// Begin line 1577
  setline(1577);
// Begin line 1311
  setline(1311);
// compilenode returning *var_values
  Object call2141 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2141
// compilenode returning call2141
  *var_dtype = call2141;
  if (call2141 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2136 = nothing;
  } else {
// Begin line 1314
  setline(1314);
// Begin line 1313
  setline(1313);
  Object bool2143 = alloc_Boolean(0);
// compilenode returning bool2143
  *var_dtype = bool2143;
  if (bool2143 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2136 = nothing;
  }
// compilenode returning if2136
// Begin line 1316
  setline(1316);
  Object array2145 = alloc_List();
// compilenode returning array2145
  var_body = alloc_var();
  *var_body = array2145;
  if (array2145 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1317
  setline(1317);
// Begin line 1316
  setline(1316);
// compilenode returning *var_sym
  var_stok = alloc_var();
  *var_stok = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1318
  setline(1318);
  var_localMin = alloc_var();
  *var_localMin = undefined;
// compilenode returning nothing
// Begin line 1349
  setline(1349);
// Begin line 1318
  setline(1318);
  if (strlit2147 == NULL) {
    strlit2147 = alloc_String("lbrace");
  }
// compilenode returning strlit2147
// Begin line 1351
  setline(1351);
// compilenode returning self
  params[0] = strlit2147;
  Object call2148 = callmethod(self, "accept",
    1, params);
// compilenode returning call2148
  Object if2146;
  if (istrue(call2148)) {
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 1319
  setline(1319);
// compilenode returning self
  Object call2149 = callmethod(self, "next",
    0, params);
// compilenode returning call2149
// Begin line 1321
  setline(1321);
// Begin line 1320
  setline(1320);
// compilenode returning *var_minIndentLevel
  *var_localMin = *var_minIndentLevel;
  if (*var_minIndentLevel == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1325
  setline(1325);
// Begin line 1326
  setline(1326);
// Begin line 1577
  setline(1577);
// Begin line 1321
  setline(1321);
// compilenode returning *var_sym
  Object call2152 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call2152
// compilenode returning call2152
// Begin line 1326
  setline(1326);
// Begin line 1577
  setline(1577);
// Begin line 1321
  setline(1321);
// compilenode returning *var_stok
  Object call2153 = callmethod(*var_stok, "line",
    0, params);
// compilenode returning call2153
// compilenode returning call2153
  params[0] = call2153;
  Object opresult2155 = callmethod(call2152, "==", 1, params);
// compilenode returning opresult2155
  Object if2151;
  if (istrue(opresult2155)) {
// Begin line 1323
  setline(1323);
// Begin line 1577
  setline(1577);
// Begin line 1322
  setline(1322);
// compilenode returning *var_sym
  Object call2156 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call2156
// compilenode returning call2156
  Object num2157 = alloc_Float64(1.0);
// compilenode returning num2157
  params[0] = num2157;
  Object diff2159 = callmethod(call2156, "-", 1, params);
// compilenode returning diff2159
  *var_minIndentLevel = diff2159;
  if (diff2159 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2151 = nothing;
  } else {
// Begin line 1325
  setline(1325);
// Begin line 1577
  setline(1577);
// Begin line 1324
  setline(1324);
// compilenode returning *var_stok
  Object call2161 = callmethod(*var_stok, "indent",
    0, params);
// compilenode returning call2161
// compilenode returning call2161
  Object num2162 = alloc_Float64(1.0);
// compilenode returning num2162
  params[0] = num2162;
  Object sum2164 = callmethod(call2161, "+", 1, params);
// compilenode returning sum2164
  *var_minIndentLevel = sum2164;
  if (sum2164 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2151 = nothing;
  }
// compilenode returning if2151
// Begin line 1329
  setline(1329);
  Object obj2166 = alloc_obj2(4,4);
// OBJECT OUTER DEC outer
  adddatum2(obj2166, self, 0);
  addmethod2(obj2166, "outer", &reader_parser_outer_2167);
  adddatum2(obj2166, self, 0);
// Begin line 1327
  setline(1327);
  if (strlit2168 == NULL) {
    strlit2168 = alloc_String("lbrace");
  }
// compilenode returning strlit2168
// OBJECT VAR DEC kind
  adddatum2(obj2166, strlit2168, 1);
  addmethod2(obj2166, "kind", &reader_parser_kind_2169);
  addmethod2(obj2166, "kind:=", &writer_parser_kind_2169);
// Begin line 1328
  setline(1328);
  if (strlit2170 == NULL) {
    strlit2170 = alloc_String("");
  }
// compilenode returning strlit2170
// OBJECT VAR DEC register
  adddatum2(obj2166, strlit2170, 2);
  addmethod2(obj2166, "register", &reader_parser_register_2171);
  addmethod2(obj2166, "register:=", &writer_parser_register_2171);
  set_type(obj2166, 7);
// compilenode returning obj2166
// Begin line 1326
  setline(1326);
// compilenode returning *var_values
  params[0] = obj2166;
  Object call2172 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2172
// Begin line 1330
  setline(1330);
// compilenode returning self
  Object call2173 = callmethod(self, "statement",
    0, params);
// compilenode returning call2173
// Begin line 1332
  setline(1332);
// Begin line 1577
  setline(1577);
// Begin line 1331
  setline(1331);
// compilenode returning *var_values
  Object call2174 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2174
// compilenode returning call2174
  var_s = alloc_var();
  *var_s = call2174;
  if (call2174 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1339
  setline(1339);
  Object while2175;
  while (1) {
// Begin line 1340
  setline(1340);
// Begin line 1577
  setline(1577);
// Begin line 1332
  setline(1332);
// compilenode returning *var_s
  Object call2176 = callmethod(*var_s, "kind",
    0, params);
// compilenode returning call2176
// compilenode returning call2176
  if (strlit2177 == NULL) {
    strlit2177 = alloc_String("lbrace");
  }
// compilenode returning strlit2177
  params[0] = strlit2177;
  Object opresult2179 = callmethod(call2176, "/=", 1, params);
// compilenode returning opresult2179
    while2175 = opresult2179;
    if (!istrue(opresult2179)) break;
// Begin line 1336
  setline(1336);
// compilenode returning *var_s
// compilenode returning *var_body
  params[0] = *var_s;
  Object call2180 = callmethod(*var_body, "push",
    1, params);
// compilenode returning call2180
// Begin line 1337
  setline(1337);
// compilenode returning self
  Object call2181 = callmethod(self, "statement",
    0, params);
// compilenode returning call2181
// Begin line 1339
  setline(1339);
// Begin line 1577
  setline(1577);
// Begin line 1338
  setline(1338);
// compilenode returning *var_values
  Object call2182 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2182
// compilenode returning call2182
  *var_s = call2182;
  if (call2182 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while2175
// Begin line 1344
  setline(1344);
// Begin line 1340
  setline(1340);
  if (strlit2185 == NULL) {
    strlit2185 = alloc_String("rbrace");
  }
// compilenode returning strlit2185
// Begin line 1346
  setline(1346);
// compilenode returning self
  params[0] = strlit2185;
  Object call2186 = callmethod(self, "accept",
    1, params);
// compilenode returning call2186
  Object if2184;
  if (istrue(call2186)) {
// Begin line 1341
  setline(1341);
// compilenode returning self
  Object call2187 = callmethod(self, "next",
    0, params);
// compilenode returning call2187
    if2184 = call2187;
  } else {
// Begin line 1344
  setline(1344);
// Begin line 1343
  setline(1343);
  if (strlit2188 == NULL) {
    strlit2188 = alloc_String("No statement but not end of ");
  }
// compilenode returning strlit2188
// Begin line 1344
  setline(1344);
// Begin line 1577
  setline(1577);
// Begin line 1344
  setline(1344);
// compilenode returning *var_meth
  Object call2189 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call2189
// compilenode returning call2189
  params[0] = call2189;
  Object opresult2191 = callmethod(strlit2188, "++", 1, params);
// compilenode returning opresult2191
  if (strlit2192 == NULL) {
    strlit2192 = alloc_String(". Have ");
  }
// compilenode returning strlit2192
  params[0] = strlit2192;
  Object opresult2194 = callmethod(opresult2191, "++", 1, params);
// compilenode returning opresult2194
// Begin line 1577
  setline(1577);
// Begin line 1344
  setline(1344);
// compilenode returning *var_sym
  Object call2195 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call2195
// compilenode returning call2195
  params[0] = call2195;
  Object opresult2197 = callmethod(opresult2194, "++", 1, params);
// compilenode returning opresult2197
  if (strlit2198 == NULL) {
    strlit2198 = alloc_String(".");
  }
// compilenode returning strlit2198
  params[0] = strlit2198;
  Object opresult2200 = callmethod(opresult2197, "++", 1, params);
// compilenode returning opresult2200
// Begin line 1343
  setline(1343);
// compilenode returning module_util
  params[0] = opresult2200;
  Object call2201 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2201
    if2184 = call2201;
  }
// compilenode returning if2184
// Begin line 1347
  setline(1347);
// Begin line 1346
  setline(1346);
// compilenode returning *var_localMin
  *var_minIndentLevel = *var_localMin;
  if (*var_localMin == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2146 = nothing;
  } else {
// Begin line 1349
  setline(1349);
// Begin line 1348
  setline(1348);
  if (strlit2203 == NULL) {
    strlit2203 = alloc_String("No body in method declaration for ");
  }
// compilenode returning strlit2203
// Begin line 1349
  setline(1349);
// Begin line 1577
  setline(1577);
// Begin line 1349
  setline(1349);
// compilenode returning *var_meth
  Object call2204 = callmethod(*var_meth, "value",
    0, params);
// compilenode returning call2204
// compilenode returning call2204
  params[0] = call2204;
  Object opresult2206 = callmethod(strlit2203, "++", 1, params);
// compilenode returning opresult2206
// Begin line 1348
  setline(1348);
// compilenode returning module_util
  params[0] = opresult2206;
  Object call2207 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2207
    if2146 = call2207;
  }
// compilenode returning if2146
// Begin line 1351
  setline(1351);
// compilenode returning *var_meth
// compilenode returning *var_params
// compilenode returning *var_body
// compilenode returning *var_dtype
// compilenode returning module_ast
  params[0] = *var_meth;
  params[1] = *var_params;
  params[2] = *var_body;
  params[3] = *var_dtype;
  Object call2208 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call2208
  var_o = alloc_var();
  *var_o = call2208;
  if (call2208 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1355
  setline(1355);
// Begin line 1352
  setline(1352);
// compilenode returning *var_varargs
  Object if2209;
  if (istrue(*var_varargs)) {
// Begin line 1354
  setline(1354);
// Begin line 1577
  setline(1577);
// Begin line 1353
  setline(1353);
  Object bool2210 = alloc_Boolean(1);
// compilenode returning bool2210
// compilenode returning *var_o
  params[0] = bool2210;
  Object call2211 = callmethod(*var_o, "varargs:=",
    1, params);
// compilenode returning call2211
// compilenode returning nothing
// Begin line 1355
  setline(1355);
// Begin line 1577
  setline(1577);
// Begin line 1354
  setline(1354);
// compilenode returning *var_vararg
// compilenode returning *var_o
  params[0] = *var_vararg;
  Object call2212 = callmethod(*var_o, "vararg:=",
    1, params);
// compilenode returning call2212
// compilenode returning nothing
    if2209 = nothing;
  } else {
  }
// compilenode returning if2209
// Begin line 1356
  setline(1356);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call2213 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2213
    if2021 = call2213;
  } else {
  }
// compilenode returning if2021
  return if2021;
}
Object meth_parser_doimport2214(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[39];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 1363
  setline(1363);
  if (strlit2216 == NULL) {
    strlit2216 = alloc_String("keyword");
  }
// compilenode returning strlit2216
// Begin line 1371
  setline(1371);
// compilenode returning self
  params[0] = strlit2216;
  Object call2217 = callmethod(self, "accept",
    1, params);
// compilenode returning call2217
// Begin line 1363
  setline(1363);
// Begin line 1577
  setline(1577);
// Begin line 1363
  setline(1363);
// compilenode returning *var_sym
  Object call2218 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2218
// compilenode returning call2218
  if (strlit2219 == NULL) {
    strlit2219 = alloc_String("import");
  }
// compilenode returning strlit2219
  params[0] = strlit2219;
  Object opresult2221 = callmethod(call2218, "==", 1, params);
// compilenode returning opresult2221
  params[0] = opresult2221;
  Object opresult2223 = callmethod(call2217, "&", 1, params);
// compilenode returning opresult2223
  Object if2215;
  if (istrue(opresult2223)) {
  Object *var_p = alloc_var();
  *var_p = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1364
  setline(1364);
// compilenode returning self
  Object call2224 = callmethod(self, "next",
    0, params);
// compilenode returning call2224
// Begin line 1365
  setline(1365);
  if (strlit2225 == NULL) {
    strlit2225 = alloc_String("identifier");
  }
// compilenode returning strlit2225
// Begin line 1366
  setline(1366);
// compilenode returning self
  params[0] = strlit2225;
  Object call2226 = callmethod(self, "expect",
    1, params);
// compilenode returning call2226
// compilenode returning self
  Object call2227 = callmethod(self, "identifier",
    0, params);
// compilenode returning call2227
// Begin line 1368
  setline(1368);
// Begin line 1577
  setline(1577);
// Begin line 1367
  setline(1367);
// compilenode returning *var_values
  Object call2228 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2228
// compilenode returning call2228
  var_p = alloc_var();
  *var_p = call2228;
  if (call2228 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1368
  setline(1368);
// compilenode returning *var_p
// compilenode returning module_ast
  params[0] = *var_p;
  Object call2229 = callmethod(module_ast, "astimport",
    1, params);
// compilenode returning call2229
  var_o = alloc_var();
  *var_o = call2229;
  if (call2229 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1369
  setline(1369);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call2230 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2230
    if2215 = call2230;
  } else {
  }
// compilenode returning if2215
  return if2215;
}
Object meth_parser_apply2245(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 1378
  setline(1378);
// compilenode returning self
  Object call2246 = callmethod(self, "expression",
    0, params);
// compilenode returning call2246
  return call2246;
}
Object meth_parser_doreturn2231(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[40];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 1376
  setline(1376);
  if (strlit2233 == NULL) {
    strlit2233 = alloc_String("keyword");
  }
// compilenode returning strlit2233
// Begin line 1383
  setline(1383);
// compilenode returning self
  params[0] = strlit2233;
  Object call2234 = callmethod(self, "accept",
    1, params);
// compilenode returning call2234
// Begin line 1376
  setline(1376);
// Begin line 1577
  setline(1577);
// Begin line 1376
  setline(1376);
// compilenode returning *var_sym
  Object call2235 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2235
// compilenode returning call2235
  if (strlit2236 == NULL) {
    strlit2236 = alloc_String("return");
  }
// compilenode returning strlit2236
  params[0] = strlit2236;
  Object opresult2238 = callmethod(call2235, "==", 1, params);
// compilenode returning opresult2238
  params[0] = opresult2238;
  Object opresult2240 = callmethod(call2234, "&", 1, params);
// compilenode returning opresult2240
  Object if2232;
  if (istrue(opresult2240)) {
  Object *var_p = alloc_var();
  *var_p = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1377
  setline(1377);
// compilenode returning self
  Object call2241 = callmethod(self, "next",
    0, params);
// compilenode returning call2241
// Begin line 1378
  setline(1378);
// Begin line 1577
  setline(1577);
  Object obj2243 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2243, self, 0);
  addmethod2(obj2243, "outer", &reader_parser_outer_2244);
  adddatum2(obj2243, self, 0);
  block_savedest(obj2243);
  Object **closure2245 = createclosure(1);
  Object *selfpp2247 = alloc_var();
  *selfpp2247 = self;
  addtoclosure(closure2245, selfpp2247);
  struct UserObject *uo2245 = (struct UserObject*)obj2243;
  uo2245->data[1] = (Object)closure2245;
  addmethod2(obj2243, "apply", &meth_parser_apply2245);
  set_type(obj2243, 0);
// compilenode returning obj2243
  setclassname(obj2243, "Block<parser:2242>");
// compilenode returning obj2243
// Begin line 1379
  setline(1379);
// compilenode returning self
  params[0] = obj2243;
  Object call2248 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call2248
// Begin line 1380
  setline(1380);
// Begin line 1577
  setline(1577);
// Begin line 1379
  setline(1379);
// compilenode returning *var_values
  Object call2249 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2249
// compilenode returning call2249
  var_p = alloc_var();
  *var_p = call2249;
  if (call2249 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1380
  setline(1380);
// compilenode returning *var_p
// compilenode returning module_ast
  params[0] = *var_p;
  Object call2250 = callmethod(module_ast, "astreturn",
    1, params);
// compilenode returning call2250
  var_o = alloc_var();
  *var_o = call2250;
  if (call2250 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1381
  setline(1381);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call2251 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2251
    if2232 = call2251;
  } else {
  }
// compilenode returning if2232
  return if2232;
}
Object meth_parser_apply2302(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_mn = closure[0];
  Object *var_params = closure[1];
  Object *var_lastparamcount = closure[2];
  Object *var_values = closure[3];
  Object self = *closure[4];
// Begin line 1417
  setline(1417);
// Begin line 1416
  setline(1416);
  if (strlit2303 == NULL) {
    strlit2303 = alloc_String("");
  }
// compilenode returning strlit2303
// compilenode returning *var_mn
  params[0] = *var_mn;
  Object opresult2305 = callmethod(strlit2303, "++", 1, params);
// compilenode returning opresult2305
  if (strlit2306 == NULL) {
    strlit2306 = alloc_String("(");
  }
// compilenode returning strlit2306
  params[0] = strlit2306;
  Object opresult2308 = callmethod(opresult2305, "++", 1, params);
// compilenode returning opresult2308
// Begin line 1417
  setline(1417);
// Begin line 1577
  setline(1577);
// Begin line 1416
  setline(1416);
// compilenode returning *var_params
  Object call2309 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call2309
// compilenode returning call2309
// compilenode returning *var_lastparamcount
  params[0] = *var_lastparamcount;
  Object diff2311 = callmethod(call2309, "-", 1, params);
// compilenode returning diff2311
  params[0] = diff2311;
  Object opresult2313 = callmethod(opresult2308, "++", 1, params);
// compilenode returning opresult2313
  if (strlit2314 == NULL) {
    strlit2314 = alloc_String(")");
  }
// compilenode returning strlit2314
  params[0] = strlit2314;
  Object opresult2316 = callmethod(opresult2313, "++", 1, params);
// compilenode returning opresult2316
// Begin line 1417
  setline(1417);
// Begin line 1577
  setline(1577);
// Begin line 1417
  setline(1417);
// Begin line 1577
  setline(1577);
// Begin line 1416
  setline(1416);
// compilenode returning *var_values
  Object call2317 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2317
// compilenode returning call2317
  Object call2318 = callmethod(call2317, "value",
    0, params);
// compilenode returning call2318
// compilenode returning call2318
  params[0] = call2318;
  Object opresult2320 = callmethod(opresult2316, "++", 1, params);
// compilenode returning opresult2320
  if (strlit2321 == NULL) {
    strlit2321 = alloc_String("");
  }
// compilenode returning strlit2321
  params[0] = strlit2321;
  Object opresult2323 = callmethod(opresult2320, "++", 1, params);
// compilenode returning opresult2323
  *var_mn = opresult2323;
  if (opresult2323 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1418
  setline(1418);
// Begin line 1577
  setline(1577);
// Begin line 1417
  setline(1417);
// compilenode returning *var_params
  Object call2325 = callmethod(*var_params, "size",
    0, params);
// compilenode returning call2325
// compilenode returning call2325
  *var_lastparamcount = call2325;
  if (call2325 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_apply2331(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object *var_mn = closure[0];
  Object *var_values = closure[1];
  Object self = *closure[2];
// Begin line 1419
  setline(1419);
  Object bool2332 = alloc_Boolean(0);
// compilenode returning bool2332
// Begin line 1421
  setline(1421);
// Begin line 1420
  setline(1420);
// compilenode returning *var_mn
  if (strlit2333 == NULL) {
    strlit2333 = alloc_String("()");
  }
// compilenode returning strlit2333
  params[0] = strlit2333;
  Object opresult2335 = callmethod(*var_mn, "++", 1, params);
// compilenode returning opresult2335
// Begin line 1421
  setline(1421);
// Begin line 1577
  setline(1577);
// Begin line 1421
  setline(1421);
// Begin line 1577
  setline(1577);
// Begin line 1420
  setline(1420);
// compilenode returning *var_values
  Object call2336 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2336
// compilenode returning call2336
  Object call2337 = callmethod(call2336, "value",
    0, params);
// compilenode returning call2337
// compilenode returning call2337
  params[0] = call2337;
  Object opresult2339 = callmethod(opresult2335, "++", 1, params);
// compilenode returning opresult2339
  *var_mn = opresult2339;
  if (opresult2339 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_parser_domethodtype2252(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[41];
  Object params[3];
  Object *var_values = closure[0];
  Object *var_id = alloc_var();
  *var_id = undefined;
  Object *var_mn = alloc_var();
  *var_mn = undefined;
  Object *var_rtype = alloc_var();
  *var_rtype = undefined;
  Object *var_params = alloc_var();
  *var_params = undefined;
  Object *var_lastparamcount = alloc_var();
  *var_lastparamcount = undefined;
// Begin line 1386
  setline(1386);
// compilenode returning self
  Object call2253 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2253
// Begin line 1388
  setline(1388);
// Begin line 1577
  setline(1577);
// Begin line 1387
  setline(1387);
// compilenode returning *var_values
  Object call2254 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2254
// compilenode returning call2254
  var_id = alloc_var();
  *var_id = call2254;
  if (call2254 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1389
  setline(1389);
// Begin line 1577
  setline(1577);
// Begin line 1388
  setline(1388);
// compilenode returning *var_id
  Object call2255 = callmethod(*var_id, "value",
    0, params);
// compilenode returning call2255
// compilenode returning call2255
  var_mn = alloc_var();
  *var_mn = call2255;
  if (call2255 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1391
  setline(1391);
// Begin line 1389
  setline(1389);
  if (strlit2257 == NULL) {
    strlit2257 = alloc_String("bind");
  }
// compilenode returning strlit2257
// Begin line 1392
  setline(1392);
// compilenode returning self
  params[0] = strlit2257;
  Object call2258 = callmethod(self, "accept",
    1, params);
// compilenode returning call2258
  Object if2256;
  if (istrue(call2258)) {
// Begin line 1391
  setline(1391);
// Begin line 1390
  setline(1390);
  if (strlit2259 == NULL) {
    strlit2259 = alloc_String("");
  }
// compilenode returning strlit2259
// compilenode returning *var_mn
  params[0] = *var_mn;
  Object opresult2261 = callmethod(strlit2259, "++", 1, params);
// compilenode returning opresult2261
  if (strlit2262 == NULL) {
    strlit2262 = alloc_String(":=");
  }
// compilenode returning strlit2262
  params[0] = strlit2262;
  Object opresult2264 = callmethod(opresult2261, "++", 1, params);
// compilenode returning opresult2264
  *var_mn = opresult2264;
  if (opresult2264 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2256 = nothing;
  } else {
  }
// compilenode returning if2256
// Begin line 1392
  setline(1392);
  if (strlit2266 == NULL) {
    strlit2266 = alloc_String("Unit");
  }
// compilenode returning strlit2266
  Object bool2267 = alloc_Boolean(0);
// compilenode returning bool2267
// compilenode returning module_ast
  params[0] = strlit2266;
  params[1] = bool2267;
  Object call2268 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call2268
  var_rtype = alloc_var();
  *var_rtype = call2268;
  if (call2268 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1394
  setline(1394);
  Object array2269 = alloc_List();
// compilenode returning array2269
  var_params = alloc_var();
  *var_params = array2269;
  if (array2269 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1395
  setline(1395);
// Begin line 1394
  setline(1394);
  Object num2270 = alloc_Float64(0.0);
// compilenode returning num2270
  var_lastparamcount = alloc_var();
  *var_lastparamcount = num2270;
  if (num2270 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1421
  setline(1421);
  Object while2271;
  while (1) {
// Begin line 1395
  setline(1395);
  if (strlit2272 == NULL) {
    strlit2272 = alloc_String("lparen");
  }
// compilenode returning strlit2272
// Begin line 1424
  setline(1424);
// compilenode returning self
  params[0] = strlit2272;
  Object call2273 = callmethod(self, "accept",
    1, params);
// compilenode returning call2273
    while2271 = call2273;
    if (!istrue(call2273)) break;
// Begin line 1396
  setline(1396);
// compilenode returning self
  Object call2274 = callmethod(self, "next",
    0, params);
// compilenode returning call2274
// Begin line 1408
  setline(1408);
  Object while2275;
  while (1) {
// Begin line 1397
  setline(1397);
  if (strlit2276 == NULL) {
    strlit2276 = alloc_String("identifier");
  }
// compilenode returning strlit2276
// Begin line 1411
  setline(1411);
// compilenode returning self
  params[0] = strlit2276;
  Object call2277 = callmethod(self, "accept",
    1, params);
// compilenode returning call2277
    while2275 = call2277;
    if (!istrue(call2277)) break;
  Object *var_prm = alloc_var();
  *var_prm = undefined;
// Begin line 1398
  setline(1398);
// compilenode returning self
  Object call2278 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2278
// Begin line 1400
  setline(1400);
// Begin line 1577
  setline(1577);
// Begin line 1399
  setline(1399);
// compilenode returning *var_values
  Object call2279 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2279
// compilenode returning call2279
  var_prm = alloc_var();
  *var_prm = call2279;
  if (call2279 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1405
  setline(1405);
// Begin line 1400
  setline(1400);
  if (strlit2281 == NULL) {
    strlit2281 = alloc_String("colon");
  }
// compilenode returning strlit2281
// Begin line 1406
  setline(1406);
// compilenode returning self
  params[0] = strlit2281;
  Object call2282 = callmethod(self, "accept",
    1, params);
// compilenode returning call2282
  Object if2280;
  if (istrue(call2282)) {
  Object *var_tp = alloc_var();
  *var_tp = undefined;
// Begin line 1401
  setline(1401);
// compilenode returning self
  Object call2283 = callmethod(self, "next",
    0, params);
// compilenode returning call2283
// Begin line 1402
  setline(1402);
// compilenode returning self
  Object call2284 = callmethod(self, "dotyperef",
    0, params);
// compilenode returning call2284
// Begin line 1404
  setline(1404);
// Begin line 1577
  setline(1577);
// Begin line 1403
  setline(1403);
// compilenode returning *var_values
  Object call2285 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2285
// compilenode returning call2285
  var_tp = alloc_var();
  *var_tp = call2285;
  if (call2285 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1405
  setline(1405);
// Begin line 1577
  setline(1577);
// Begin line 1404
  setline(1404);
// compilenode returning *var_tp
// compilenode returning *var_prm
  params[0] = *var_tp;
  Object call2286 = callmethod(*var_prm, "dtype:=",
    1, params);
// compilenode returning call2286
// compilenode returning nothing
    if2280 = nothing;
  } else {
  }
// compilenode returning if2280
// Begin line 1406
  setline(1406);
// compilenode returning *var_prm
// compilenode returning *var_params
  params[0] = *var_prm;
  Object call2287 = callmethod(*var_params, "push",
    1, params);
// compilenode returning call2287
// Begin line 1408
  setline(1408);
// Begin line 1407
  setline(1407);
  if (strlit2289 == NULL) {
    strlit2289 = alloc_String("comma");
  }
// compilenode returning strlit2289
// Begin line 1410
  setline(1410);
// compilenode returning self
  params[0] = strlit2289;
  Object call2290 = callmethod(self, "accept",
    1, params);
// compilenode returning call2290
  Object if2288;
  if (istrue(call2290)) {
// Begin line 1408
  setline(1408);
// compilenode returning self
  Object call2291 = callmethod(self, "next",
    0, params);
// compilenode returning call2291
    if2288 = call2291;
  } else {
  }
// compilenode returning if2288
  }
// compilenode returning while2275
// Begin line 1411
  setline(1411);
  if (strlit2292 == NULL) {
    strlit2292 = alloc_String("rparen");
  }
// compilenode returning strlit2292
// Begin line 1412
  setline(1412);
// compilenode returning self
  params[0] = strlit2292;
  Object call2293 = callmethod(self, "expect",
    1, params);
// compilenode returning call2293
// compilenode returning self
  Object call2294 = callmethod(self, "next",
    0, params);
// compilenode returning call2294
// Begin line 1421
  setline(1421);
// Begin line 1413
  setline(1413);
  if (strlit2296 == NULL) {
    strlit2296 = alloc_String("identifier");
  }
// compilenode returning strlit2296
// Begin line 1423
  setline(1423);
// compilenode returning self
  params[0] = strlit2296;
  Object call2297 = callmethod(self, "accept",
    1, params);
// compilenode returning call2297
  Object if2295;
  if (istrue(call2297)) {
// Begin line 1414
  setline(1414);
// compilenode returning self
  Object call2298 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2298
// Begin line 1421
  setline(1421);
// Begin line 1418
  setline(1418);
// Begin line 1577
  setline(1577);
  Object obj2300 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2300, self, 0);
  addmethod2(obj2300, "outer", &reader_parser_outer_2301);
  adddatum2(obj2300, self, 0);
  block_savedest(obj2300);
  Object **closure2302 = createclosure(5);
  addtoclosure(closure2302, var_mn);
  addtoclosure(closure2302, var_params);
  addtoclosure(closure2302, var_lastparamcount);
  addtoclosure(closure2302, var_values);
  Object *selfpp2327 = alloc_var();
  *selfpp2327 = self;
  addtoclosure(closure2302, selfpp2327);
  struct UserObject *uo2302 = (struct UserObject*)obj2300;
  uo2302->data[1] = (Object)closure2302;
  addmethod2(obj2300, "apply", &meth_parser_apply2302);
  set_type(obj2300, 0);
// compilenode returning obj2300
  setclassname(obj2300, "Block<parser:2299>");
// compilenode returning obj2300
// Begin line 1421
  setline(1421);
// Begin line 1577
  setline(1577);
  Object obj2329 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2329, self, 0);
  addmethod2(obj2329, "outer", &reader_parser_outer_2330);
  adddatum2(obj2329, self, 0);
  block_savedest(obj2329);
  Object **closure2331 = createclosure(3);
  addtoclosure(closure2331, var_mn);
  addtoclosure(closure2331, var_values);
  Object *selfpp2341 = alloc_var();
  *selfpp2341 = self;
  addtoclosure(closure2331, selfpp2341);
  struct UserObject *uo2331 = (struct UserObject*)obj2329;
  uo2331->data[1] = (Object)closure2331;
  addmethod2(obj2329, "apply", &meth_parser_apply2331);
  set_type(obj2329, 0);
// compilenode returning obj2329
  setclassname(obj2329, "Block<parser:2328>");
// compilenode returning obj2329
// Begin line 1415
  setline(1415);
// compilenode returning module_util
  params[0] = obj2300;
  params[1] = obj2329;
  Object call2342 = callmethod(module_util, "runOnNew(1)else",
    2, params);
// compilenode returning call2342
    if2295 = call2342;
  } else {
  }
// compilenode returning if2295
  }
// compilenode returning while2271
// Begin line 1429
  setline(1429);
// Begin line 1424
  setline(1424);
  if (strlit2344 == NULL) {
    strlit2344 = alloc_String("arrow");
  }
// compilenode returning strlit2344
// Begin line 1430
  setline(1430);
// compilenode returning self
  params[0] = strlit2344;
  Object call2345 = callmethod(self, "accept",
    1, params);
// compilenode returning call2345
  Object if2343;
  if (istrue(call2345)) {
// Begin line 1425
  setline(1425);
// compilenode returning self
  Object call2346 = callmethod(self, "next",
    0, params);
// compilenode returning call2346
// Begin line 1426
  setline(1426);
  if (strlit2347 == NULL) {
    strlit2347 = alloc_String("identifier");
  }
// compilenode returning strlit2347
// Begin line 1427
  setline(1427);
// compilenode returning self
  params[0] = strlit2347;
  Object call2348 = callmethod(self, "expect",
    1, params);
// compilenode returning call2348
// compilenode returning self
  Object call2349 = callmethod(self, "dotyperef",
    0, params);
// compilenode returning call2349
// Begin line 1429
  setline(1429);
// Begin line 1577
  setline(1577);
// Begin line 1428
  setline(1428);
// compilenode returning *var_values
  Object call2350 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2350
// compilenode returning call2350
  *var_rtype = call2350;
  if (call2350 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2343 = nothing;
  } else {
  }
// compilenode returning if2343
// Begin line 1430
  setline(1430);
// compilenode returning *var_mn
// compilenode returning *var_params
// compilenode returning *var_rtype
// compilenode returning module_ast
  params[0] = *var_mn;
  params[1] = *var_params;
  params[2] = *var_rtype;
  Object call2352 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call2352
// compilenode returning *var_values
  params[0] = call2352;
  Object call2353 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2353
  return call2353;
}
Object meth_parser_apply2401(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
// Begin line 1455
  setline(1455);
// compilenode returning self
  Object call2402 = callmethod(self, "domethodtype",
    0, params);
// compilenode returning call2402
  return call2402;
}
Object meth_parser_dotype2354(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[42];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_values = closure[1];
// Begin line 1435
  setline(1435);
  if (strlit2356 == NULL) {
    strlit2356 = alloc_String("keyword");
  }
// compilenode returning strlit2356
// Begin line 1463
  setline(1463);
// compilenode returning self
  params[0] = strlit2356;
  Object call2357 = callmethod(self, "accept",
    1, params);
// compilenode returning call2357
// Begin line 1435
  setline(1435);
// Begin line 1577
  setline(1577);
// Begin line 1435
  setline(1435);
// compilenode returning *var_sym
  Object call2358 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2358
// compilenode returning call2358
  if (strlit2359 == NULL) {
    strlit2359 = alloc_String("type");
  }
// compilenode returning strlit2359
  params[0] = strlit2359;
  Object opresult2361 = callmethod(call2358, "==", 1, params);
// compilenode returning opresult2361
  params[0] = opresult2361;
  Object opresult2363 = callmethod(call2357, "&", 1, params);
// compilenode returning opresult2363
  Object if2355;
  if (istrue(opresult2363)) {
  Object *var_p = alloc_var();
  *var_p = undefined;
  Object *var_gens = alloc_var();
  *var_gens = undefined;
  Object *var_methods = alloc_var();
  *var_methods = undefined;
  Object *var_t = alloc_var();
  *var_t = undefined;
// Begin line 1436
  setline(1436);
// compilenode returning self
  Object call2364 = callmethod(self, "next",
    0, params);
// compilenode returning call2364
// Begin line 1437
  setline(1437);
  if (strlit2365 == NULL) {
    strlit2365 = alloc_String("identifier");
  }
// compilenode returning strlit2365
// Begin line 1438
  setline(1438);
// compilenode returning self
  params[0] = strlit2365;
  Object call2366 = callmethod(self, "expect",
    1, params);
// compilenode returning call2366
// compilenode returning self
  Object call2367 = callmethod(self, "pushidentifier",
    0, params);
// compilenode returning call2367
// Begin line 1439
  setline(1439);
// compilenode returning self
  Object call2368 = callmethod(self, "generic",
    0, params);
// compilenode returning call2368
// Begin line 1441
  setline(1441);
// Begin line 1577
  setline(1577);
// Begin line 1440
  setline(1440);
// compilenode returning *var_values
  Object call2369 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2369
// compilenode returning call2369
  var_p = alloc_var();
  *var_p = call2369;
  if (call2369 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1442
  setline(1442);
  Object array2370 = alloc_List();
// compilenode returning array2370
  var_gens = alloc_var();
  *var_gens = array2370;
  if (array2370 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1445
  setline(1445);
// Begin line 1446
  setline(1446);
// Begin line 1577
  setline(1577);
// Begin line 1442
  setline(1442);
// compilenode returning *var_p
  Object call2372 = callmethod(*var_p, "kind",
    0, params);
// compilenode returning call2372
// compilenode returning call2372
  if (strlit2373 == NULL) {
    strlit2373 = alloc_String("generic");
  }
// compilenode returning strlit2373
  params[0] = strlit2373;
  Object opresult2375 = callmethod(call2372, "==", 1, params);
// compilenode returning opresult2375
  Object if2371;
  if (istrue(opresult2375)) {
// Begin line 1444
  setline(1444);
// Begin line 1577
  setline(1577);
// Begin line 1443
  setline(1443);
// compilenode returning *var_p
  Object call2376 = callmethod(*var_p, "params",
    0, params);
// compilenode returning call2376
// compilenode returning call2376
  *var_gens = call2376;
  if (call2376 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1445
  setline(1445);
// Begin line 1577
  setline(1577);
// Begin line 1444
  setline(1444);
// compilenode returning *var_p
  Object call2378 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call2378
// compilenode returning call2378
  *var_p = call2378;
  if (call2378 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2371 = nothing;
  } else {
  }
// compilenode returning if2371
// Begin line 1446
  setline(1446);
  if (strlit2380 == NULL) {
    strlit2380 = alloc_String("op");
  }
// compilenode returning strlit2380
// Begin line 1447
  setline(1447);
// compilenode returning self
  params[0] = strlit2380;
  Object call2381 = callmethod(self, "expect",
    1, params);
// compilenode returning call2381
// Begin line 1448
  setline(1448);
// Begin line 1450
  setline(1450);
// Begin line 1577
  setline(1577);
// Begin line 1447
  setline(1447);
// compilenode returning *var_sym
  Object call2383 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2383
// compilenode returning call2383
  if (strlit2384 == NULL) {
    strlit2384 = alloc_String("=");
  }
// compilenode returning strlit2384
  params[0] = strlit2384;
  Object opresult2386 = callmethod(call2383, "/=", 1, params);
// compilenode returning opresult2386
  Object if2382;
  if (istrue(opresult2386)) {
// Begin line 1448
  setline(1448);
  if (strlit2387 == NULL) {
    strlit2387 = alloc_String("type declarations require =.");
  }
// compilenode returning strlit2387
// compilenode returning module_util
  params[0] = strlit2387;
  Object call2388 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2388
    if2382 = call2388;
  } else {
  }
// compilenode returning if2382
// Begin line 1450
  setline(1450);
// compilenode returning self
  Object call2389 = callmethod(self, "next",
    0, params);
// compilenode returning call2389
// Begin line 1452
  setline(1452);
  Object array2390 = alloc_List();
// compilenode returning array2390
  *var_methods = array2390;
  if (array2390 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit2391 == NULL) {
    strlit2391 = alloc_String("lbrace");
  }
// compilenode returning strlit2391
// Begin line 1453
  setline(1453);
// compilenode returning self
  params[0] = strlit2391;
  Object call2392 = callmethod(self, "expect",
    1, params);
// compilenode returning call2392
// compilenode returning self
  Object call2393 = callmethod(self, "next",
    0, params);
// compilenode returning call2393
// Begin line 1456
  setline(1456);
  Object while2394;
  while (1) {
// Begin line 1454
  setline(1454);
// Begin line 1577
  setline(1577);
// Begin line 1454
  setline(1454);
  if (strlit2395 == NULL) {
    strlit2395 = alloc_String("rbrace");
  }
// compilenode returning strlit2395
// Begin line 1458
  setline(1458);
// compilenode returning self
  params[0] = strlit2395;
  Object call2396 = callmethod(self, "accept",
    1, params);
// compilenode returning call2396
  Object call2397 = callmethod(call2396, "not",
    0, params);
// compilenode returning call2397
// compilenode returning call2397
    while2394 = call2397;
    if (!istrue(call2397)) break;
// Begin line 1455
  setline(1455);
// Begin line 1577
  setline(1577);
  Object obj2399 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2399, self, 0);
  addmethod2(obj2399, "outer", &reader_parser_outer_2400);
  adddatum2(obj2399, self, 0);
  block_savedest(obj2399);
  Object **closure2401 = createclosure(1);
  Object *selfpp2403 = alloc_var();
  *selfpp2403 = self;
  addtoclosure(closure2401, selfpp2403);
  struct UserObject *uo2401 = (struct UserObject*)obj2399;
  uo2401->data[1] = (Object)closure2401;
  addmethod2(obj2399, "apply", &meth_parser_apply2401);
  set_type(obj2399, 0);
// compilenode returning obj2399
  setclassname(obj2399, "Block<parser:2398>");
// compilenode returning obj2399
// Begin line 1456
  setline(1456);
// compilenode returning self
  params[0] = obj2399;
  Object call2404 = callmethod(self, "expectConsume",
    1, params);
// compilenode returning call2404
// Begin line 1577
  setline(1577);
// Begin line 1456
  setline(1456);
// compilenode returning *var_values
  Object call2405 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2405
// compilenode returning call2405
// compilenode returning *var_methods
  params[0] = call2405;
  Object call2406 = callmethod(*var_methods, "push",
    1, params);
// compilenode returning call2406
  }
// compilenode returning while2394
// Begin line 1458
  setline(1458);
// compilenode returning self
  Object call2407 = callmethod(self, "next",
    0, params);
// compilenode returning call2407
// Begin line 1459
  setline(1459);
// Begin line 1577
  setline(1577);
// Begin line 1459
  setline(1459);
// compilenode returning *var_p
  Object call2408 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call2408
// compilenode returning call2408
// compilenode returning *var_methods
// compilenode returning module_ast
  params[0] = call2408;
  params[1] = *var_methods;
  Object call2409 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call2409
  *var_t = call2409;
  if (call2409 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1461
  setline(1461);
// Begin line 1577
  setline(1577);
// Begin line 1460
  setline(1460);
// compilenode returning *var_gens
// compilenode returning *var_t
  params[0] = *var_gens;
  Object call2410 = callmethod(*var_t, "generics:=",
    1, params);
// compilenode returning call2410
// compilenode returning nothing
// Begin line 1461
  setline(1461);
// compilenode returning *var_t
// compilenode returning *var_values
  params[0] = *var_t;
  Object call2411 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2411
    if2355 = call2411;
  } else {
  }
// compilenode returning if2355
  return if2355;
}
Object meth_parser_statement2412(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[43];
  Object params[2];
  Object *var_sym = closure[0];
  Object *var_statementIndent = closure[1];
  Object *var_statementToken = closure[2];
  Object *var_indentFreePass = closure[3];
  Object *var_minIndentLevel = closure[4];
  Object *var_values = closure[5];
// Begin line 1472
  setline(1472);
// Begin line 1577
  setline(1577);
// Begin line 1471
  setline(1471);
// compilenode returning *var_sym
  Object call2413 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call2413
// compilenode returning call2413
  *var_statementIndent = call2413;
  if (call2413 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1473
  setline(1473);
// Begin line 1472
  setline(1472);
// compilenode returning *var_sym
  *var_statementToken = *var_sym;
  if (*var_sym == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1487
  setline(1487);
// Begin line 1473
  setline(1473);
// compilenode returning *var_indentFreePass
  Object if2416;
  if (istrue(*var_indentFreePass)) {
// Begin line 1475
  setline(1475);
// Begin line 1474
  setline(1474);
  Object bool2417 = alloc_Boolean(0);
// compilenode returning bool2417
  *var_indentFreePass = bool2417;
  if (bool2417 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2416 = nothing;
  } else {
// Begin line 1487
  setline(1487);
// Begin line 1478
  setline(1478);
// Begin line 1577
  setline(1577);
// Begin line 1475
  setline(1475);
// compilenode returning *var_sym
  Object call2420 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call2420
// compilenode returning call2420
  if (strlit2421 == NULL) {
    strlit2421 = alloc_String("rbrace");
  }
// compilenode returning strlit2421
  params[0] = strlit2421;
  Object opresult2423 = callmethod(call2420, "==", 1, params);
// compilenode returning opresult2423
// Begin line 1478
  setline(1478);
// Begin line 1577
  setline(1577);
// Begin line 1475
  setline(1475);
// compilenode returning *var_sym
  Object call2424 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call2424
// compilenode returning call2424
  if (strlit2425 == NULL) {
    strlit2425 = alloc_String("rparen");
  }
// compilenode returning strlit2425
  params[0] = strlit2425;
  Object opresult2427 = callmethod(call2424, "==", 1, params);
// compilenode returning opresult2427
  params[0] = opresult2427;
  Object opresult2429 = callmethod(opresult2423, "|", 1, params);
// compilenode returning opresult2429
// Begin line 1478
  setline(1478);
// Begin line 1577
  setline(1577);
// Begin line 1476
  setline(1476);
// compilenode returning *var_sym
  Object call2430 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call2430
// compilenode returning call2430
  if (strlit2431 == NULL) {
    strlit2431 = alloc_String("rsquare");
  }
// compilenode returning strlit2431
  params[0] = strlit2431;
  Object opresult2433 = callmethod(call2430, "==", 1, params);
// compilenode returning opresult2433
  params[0] = opresult2433;
  Object opresult2435 = callmethod(opresult2429, "|", 1, params);
// compilenode returning opresult2435
  Object if2419;
  if (istrue(opresult2435)) {
    if2419 = undefined;
  } else {
// Begin line 1487
  setline(1487);
// Begin line 1485
  setline(1485);
// Begin line 1577
  setline(1577);
// Begin line 1478
  setline(1478);
// compilenode returning *var_sym
  Object call2437 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call2437
// compilenode returning call2437
// compilenode returning *var_minIndentLevel
  params[0] = *var_minIndentLevel;
  Object opresult2439 = callmethod(call2437, "<", 1, params);
// compilenode returning opresult2439
  Object if2436;
  if (istrue(opresult2439)) {
// Begin line 1483
  setline(1483);
// Begin line 1485
  setline(1485);
// Begin line 1577
  setline(1577);
// Begin line 1479
  setline(1479);
// compilenode returning *var_sym
  Object call2441 = callmethod(*var_sym, "linePos",
    0, params);
// compilenode returning call2441
// compilenode returning call2441
  Object num2442 = alloc_Float64(1.0);
// compilenode returning num2442
  params[0] = num2442;
  Object diff2444 = callmethod(call2441, "-", 1, params);
// compilenode returning diff2444
// compilenode returning *var_minIndentLevel
  params[0] = *var_minIndentLevel;
  Object opresult2446 = callmethod(diff2444, "/=", 1, params);
// compilenode returning opresult2446
  Object if2440;
  if (istrue(opresult2446)) {
// Begin line 1483
  setline(1483);
// Begin line 1480
  setline(1480);
  if (strlit2447 == NULL) {
    strlit2447 = alloc_String("block and indentation inconsistent ");
  }
// compilenode returning strlit2447
// Begin line 1481
  setline(1481);
  if (strlit2448 == NULL) {
    strlit2448 = alloc_String("for token ");
  }
// compilenode returning strlit2448
  params[0] = strlit2448;
  Object opresult2450 = callmethod(strlit2447, "++", 1, params);
// compilenode returning opresult2450
// Begin line 1483
  setline(1483);
// Begin line 1577
  setline(1577);
// Begin line 1481
  setline(1481);
// compilenode returning *var_sym
  Object call2451 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call2451
// compilenode returning call2451
  params[0] = call2451;
  Object opresult2453 = callmethod(opresult2450, "++", 1, params);
// compilenode returning opresult2453
  if (strlit2454 == NULL) {
    strlit2454 = alloc_String(": ");
  }
// compilenode returning strlit2454
  params[0] = strlit2454;
  Object opresult2456 = callmethod(opresult2453, "++", 1, params);
// compilenode returning opresult2456
// Begin line 1483
  setline(1483);
// Begin line 1577
  setline(1577);
// Begin line 1481
  setline(1481);
// compilenode returning *var_sym
  Object call2457 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2457
// compilenode returning call2457
  params[0] = call2457;
  Object opresult2459 = callmethod(opresult2456, "++", 1, params);
// compilenode returning opresult2459
  if (strlit2460 == NULL) {
    strlit2460 = alloc_String("; ");
  }
// compilenode returning strlit2460
  params[0] = strlit2460;
  Object opresult2462 = callmethod(opresult2459, "++", 1, params);
// compilenode returning opresult2462
// Begin line 1482
  setline(1482);
  if (strlit2463 == NULL) {
    strlit2463 = alloc_String("indentation is ");
  }
// compilenode returning strlit2463
  params[0] = strlit2463;
  Object opresult2465 = callmethod(opresult2462, "++", 1, params);
// compilenode returning opresult2465
// Begin line 1483
  setline(1483);
// Begin line 1577
  setline(1577);
// Begin line 1482
  setline(1482);
// compilenode returning *var_sym
  Object call2466 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call2466
// compilenode returning call2466
  params[0] = call2466;
  Object opresult2468 = callmethod(opresult2465, "++", 1, params);
// compilenode returning opresult2468
  if (strlit2469 == NULL) {
    strlit2469 = alloc_String(", must be at least ");
  }
// compilenode returning strlit2469
  params[0] = strlit2469;
  Object opresult2471 = callmethod(opresult2468, "++", 1, params);
// compilenode returning opresult2471
// Begin line 1483
  setline(1483);
// compilenode returning *var_minIndentLevel
  params[0] = *var_minIndentLevel;
  Object opresult2473 = callmethod(opresult2471, "++", 1, params);
// compilenode returning opresult2473
// Begin line 1480
  setline(1480);
// compilenode returning module_util
  params[0] = opresult2473;
  Object call2474 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2474
    if2440 = call2474;
  } else {
  }
// compilenode returning if2440
    if2436 = if2440;
  } else {
// Begin line 1487
  setline(1487);
// Begin line 1488
  setline(1488);
// Begin line 1577
  setline(1577);
// Begin line 1485
  setline(1485);
// compilenode returning *var_sym
  Object call2476 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call2476
// compilenode returning call2476
// compilenode returning *var_minIndentLevel
  params[0] = *var_minIndentLevel;
  Object opresult2478 = callmethod(call2476, ">", 1, params);
// compilenode returning opresult2478
  Object if2475;
  if (istrue(opresult2478)) {
// Begin line 1487
  setline(1487);
// Begin line 1577
  setline(1577);
// Begin line 1486
  setline(1486);
// compilenode returning *var_sym
  Object call2479 = callmethod(*var_sym, "indent",
    0, params);
// compilenode returning call2479
// compilenode returning call2479
  *var_minIndentLevel = call2479;
  if (call2479 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2475 = nothing;
  } else {
  }
// compilenode returning if2475
    if2436 = if2475;
  }
// compilenode returning if2436
    if2419 = if2436;
  }
// compilenode returning if2419
    if2416 = if2419;
  }
// compilenode returning if2416
// Begin line 1521
  setline(1521);
// Begin line 1488
  setline(1488);
  if (strlit2482 == NULL) {
    strlit2482 = alloc_String("keyword");
  }
// compilenode returning strlit2482
// Begin line 1524
  setline(1524);
// compilenode returning self
  params[0] = strlit2482;
  Object call2483 = callmethod(self, "accept",
    1, params);
// compilenode returning call2483
  Object if2481;
  if (istrue(call2483)) {
// Begin line 1506
  setline(1506);
// Begin line 1508
  setline(1508);
// Begin line 1577
  setline(1577);
// Begin line 1489
  setline(1489);
// compilenode returning *var_sym
  Object call2485 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2485
// compilenode returning call2485
  if (strlit2486 == NULL) {
    strlit2486 = alloc_String("var");
  }
// compilenode returning strlit2486
  params[0] = strlit2486;
  Object opresult2488 = callmethod(call2485, "==", 1, params);
// compilenode returning opresult2488
  Object if2484;
  if (istrue(opresult2488)) {
// Begin line 1490
  setline(1490);
// compilenode returning self
  Object call2489 = callmethod(self, "vardec",
    0, params);
// compilenode returning call2489
    if2484 = call2489;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1493
  setline(1493);
// Begin line 1577
  setline(1577);
// Begin line 1491
  setline(1491);
// compilenode returning *var_sym
  Object call2491 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2491
// compilenode returning call2491
  if (strlit2492 == NULL) {
    strlit2492 = alloc_String("def");
  }
// compilenode returning strlit2492
  params[0] = strlit2492;
  Object opresult2494 = callmethod(call2491, "==", 1, params);
// compilenode returning opresult2494
  Object if2490;
  if (istrue(opresult2494)) {
// Begin line 1492
  setline(1492);
// compilenode returning self
  Object call2495 = callmethod(self, "defdec",
    0, params);
// compilenode returning call2495
    if2490 = call2495;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1495
  setline(1495);
// Begin line 1577
  setline(1577);
// Begin line 1493
  setline(1493);
// compilenode returning *var_sym
  Object call2497 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2497
// compilenode returning call2497
  if (strlit2498 == NULL) {
    strlit2498 = alloc_String("const");
  }
// compilenode returning strlit2498
  params[0] = strlit2498;
  Object opresult2500 = callmethod(call2497, "==", 1, params);
// compilenode returning opresult2500
  Object if2496;
  if (istrue(opresult2500)) {
// Begin line 1494
  setline(1494);
  if (strlit2501 == NULL) {
    strlit2501 = alloc_String("no such keyword const; did you mean def?");
  }
// compilenode returning strlit2501
// compilenode returning module_util
  params[0] = strlit2501;
  Object call2502 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2502
    if2496 = call2502;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1497
  setline(1497);
// Begin line 1577
  setline(1577);
// Begin line 1495
  setline(1495);
// compilenode returning *var_sym
  Object call2504 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2504
// compilenode returning call2504
  if (strlit2505 == NULL) {
    strlit2505 = alloc_String("method");
  }
// compilenode returning strlit2505
  params[0] = strlit2505;
  Object opresult2507 = callmethod(call2504, "==", 1, params);
// compilenode returning opresult2507
  Object if2503;
  if (istrue(opresult2507)) {
// Begin line 1496
  setline(1496);
// compilenode returning self
  Object call2508 = callmethod(self, "methoddec",
    0, params);
// compilenode returning call2508
    if2503 = call2508;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1499
  setline(1499);
// Begin line 1577
  setline(1577);
// Begin line 1497
  setline(1497);
// compilenode returning *var_sym
  Object call2510 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2510
// compilenode returning call2510
  if (strlit2511 == NULL) {
    strlit2511 = alloc_String("import");
  }
// compilenode returning strlit2511
  params[0] = strlit2511;
  Object opresult2513 = callmethod(call2510, "==", 1, params);
// compilenode returning opresult2513
  Object if2509;
  if (istrue(opresult2513)) {
// Begin line 1498
  setline(1498);
// compilenode returning self
  Object call2514 = callmethod(self, "doimport",
    0, params);
// compilenode returning call2514
    if2509 = call2514;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1501
  setline(1501);
// Begin line 1577
  setline(1577);
// Begin line 1499
  setline(1499);
// compilenode returning *var_sym
  Object call2516 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2516
// compilenode returning call2516
  if (strlit2517 == NULL) {
    strlit2517 = alloc_String("type");
  }
// compilenode returning strlit2517
  params[0] = strlit2517;
  Object opresult2519 = callmethod(call2516, "==", 1, params);
// compilenode returning opresult2519
  Object if2515;
  if (istrue(opresult2519)) {
// Begin line 1500
  setline(1500);
// compilenode returning self
  Object call2520 = callmethod(self, "dotype",
    0, params);
// compilenode returning call2520
    if2515 = call2520;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1503
  setline(1503);
// Begin line 1577
  setline(1577);
// Begin line 1501
  setline(1501);
// compilenode returning *var_sym
  Object call2522 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2522
// compilenode returning call2522
  if (strlit2523 == NULL) {
    strlit2523 = alloc_String("class");
  }
// compilenode returning strlit2523
  params[0] = strlit2523;
  Object opresult2525 = callmethod(call2522, "==", 1, params);
// compilenode returning opresult2525
  Object if2521;
  if (istrue(opresult2525)) {
// Begin line 1502
  setline(1502);
// compilenode returning self
  Object call2526 = callmethod(self, "doclass",
    0, params);
// compilenode returning call2526
    if2521 = call2526;
  } else {
// Begin line 1506
  setline(1506);
// Begin line 1505
  setline(1505);
// Begin line 1577
  setline(1577);
// Begin line 1503
  setline(1503);
// compilenode returning *var_sym
  Object call2528 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2528
// compilenode returning call2528
  if (strlit2529 == NULL) {
    strlit2529 = alloc_String("return");
  }
// compilenode returning strlit2529
  params[0] = strlit2529;
  Object opresult2531 = callmethod(call2528, "==", 1, params);
// compilenode returning opresult2531
  Object if2527;
  if (istrue(opresult2531)) {
// Begin line 1504
  setline(1504);
// compilenode returning self
  Object call2532 = callmethod(self, "doreturn",
    0, params);
// compilenode returning call2532
    if2527 = call2532;
  } else {
// Begin line 1506
  setline(1506);
// compilenode returning self
  Object call2533 = callmethod(self, "expression",
    0, params);
// compilenode returning call2533
    if2527 = call2533;
  }
// compilenode returning if2527
    if2521 = if2527;
  }
// compilenode returning if2521
    if2515 = if2521;
  }
// compilenode returning if2515
    if2509 = if2515;
  }
// compilenode returning if2509
    if2503 = if2509;
  }
// compilenode returning if2503
    if2496 = if2503;
  }
// compilenode returning if2496
    if2490 = if2496;
  }
// compilenode returning if2490
    if2484 = if2490;
  }
// compilenode returning if2484
    if2481 = if2484;
  } else {
// Begin line 1509
  setline(1509);
// compilenode returning self
  Object call2534 = callmethod(self, "expression",
    0, params);
// compilenode returning call2534
// Begin line 1521
  setline(1521);
// Begin line 1510
  setline(1510);
  if (strlit2536 == NULL) {
    strlit2536 = alloc_String("bind");
  }
// compilenode returning strlit2536
// Begin line 1523
  setline(1523);
// compilenode returning self
  params[0] = strlit2536;
  Object call2537 = callmethod(self, "accept",
    1, params);
// compilenode returning call2537
  Object if2535;
  if (istrue(call2537)) {
  Object *var_dest = alloc_var();
  *var_dest = undefined;
  Object *var_val = alloc_var();
  *var_val = undefined;
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1512
  setline(1512);
// Begin line 1577
  setline(1577);
// Begin line 1511
  setline(1511);
// compilenode returning *var_values
  Object call2538 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2538
// compilenode returning call2538
  var_dest = alloc_var();
  *var_dest = call2538;
  if (call2538 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1512
  setline(1512);
// compilenode returning self
  Object call2539 = callmethod(self, "next",
    0, params);
// compilenode returning call2539
// Begin line 1513
  setline(1513);
// compilenode returning self
  Object call2540 = callmethod(self, "expression",
    0, params);
// compilenode returning call2540
// Begin line 1515
  setline(1515);
// Begin line 1577
  setline(1577);
// Begin line 1514
  setline(1514);
// compilenode returning *var_values
  Object call2541 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2541
// compilenode returning call2541
  var_val = alloc_var();
  *var_val = call2541;
  if (call2541 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1515
  setline(1515);
// compilenode returning *var_dest
// compilenode returning *var_val
// compilenode returning module_ast
  params[0] = *var_dest;
  params[1] = *var_val;
  Object call2542 = callmethod(module_ast, "astbind",
    2, params);
// compilenode returning call2542
  var_o = alloc_var();
  *var_o = call2542;
  if (call2542 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1518
  setline(1518);
// Begin line 1521
  setline(1521);
// Begin line 1577
  setline(1577);
// Begin line 1516
  setline(1516);
// compilenode returning *var_dest
  Object call2544 = callmethod(*var_dest, "kind",
    0, params);
// compilenode returning call2544
// compilenode returning call2544
  if (strlit2545 == NULL) {
    strlit2545 = alloc_String("call");
  }
// compilenode returning strlit2545
  params[0] = strlit2545;
  Object opresult2547 = callmethod(call2544, "==", 1, params);
// compilenode returning opresult2547
  Object if2543;
  if (istrue(opresult2547)) {
// Begin line 1518
  setline(1518);
// Begin line 1520
  setline(1520);
// Begin line 1577
  setline(1577);
// Begin line 1520
  setline(1520);
// Begin line 1577
  setline(1577);
// Begin line 1517
  setline(1517);
// compilenode returning *var_dest
  Object call2549 = callmethod(*var_dest, "value",
    0, params);
// compilenode returning call2549
// compilenode returning call2549
  Object call2550 = callmethod(call2549, "kind",
    0, params);
// compilenode returning call2550
// compilenode returning call2550
  if (strlit2551 == NULL) {
    strlit2551 = alloc_String("member");
  }
// compilenode returning strlit2551
  params[0] = strlit2551;
  Object opresult2553 = callmethod(call2550, "/=", 1, params);
// compilenode returning opresult2553
  Object if2548;
  if (istrue(opresult2553)) {
// Begin line 1518
  setline(1518);
  if (strlit2554 == NULL) {
    strlit2554 = alloc_String("assignment to method call");
  }
// compilenode returning strlit2554
// compilenode returning module_util
  params[0] = strlit2554;
  Object call2555 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2555
    if2548 = call2555;
  } else {
  }
// compilenode returning if2548
    if2543 = if2548;
  } else {
  }
// compilenode returning if2543
// Begin line 1521
  setline(1521);
// compilenode returning *var_o
// compilenode returning *var_values
  params[0] = *var_o;
  Object call2556 = callmethod(*var_values, "push",
    1, params);
// compilenode returning call2556
    if2535 = call2556;
  } else {
  }
// compilenode returning if2535
    if2481 = if2535;
  }
// compilenode returning if2481
// Begin line 1529
  setline(1529);
// Begin line 1524
  setline(1524);
  if (strlit2558 == NULL) {
    strlit2558 = alloc_String("semicolon");
  }
// compilenode returning strlit2558
// Begin line 1531
  setline(1531);
// compilenode returning self
  params[0] = strlit2558;
  Object call2559 = callmethod(self, "accept",
    1, params);
// compilenode returning call2559
  Object if2557;
  if (istrue(call2559)) {
  Object *var_oldLine = alloc_var();
  *var_oldLine = undefined;
// Begin line 1526
  setline(1526);
// Begin line 1577
  setline(1577);
// Begin line 1525
  setline(1525);
// compilenode returning *var_sym
  Object call2560 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call2560
// compilenode returning call2560
  *var_oldLine = call2560;
  if (call2560 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1526
  setline(1526);
// compilenode returning self
  Object call2561 = callmethod(self, "next",
    0, params);
// compilenode returning call2561
// Begin line 1529
  setline(1529);
// Begin line 1530
  setline(1530);
// Begin line 1577
  setline(1577);
// Begin line 1527
  setline(1527);
// compilenode returning *var_sym
  Object call2563 = callmethod(*var_sym, "line",
    0, params);
// compilenode returning call2563
// compilenode returning call2563
// compilenode returning *var_oldLine
  params[0] = *var_oldLine;
  Object opresult2565 = callmethod(call2563, "==", 1, params);
// compilenode returning opresult2565
  Object if2562;
  if (istrue(opresult2565)) {
// Begin line 1529
  setline(1529);
// Begin line 1528
  setline(1528);
  Object bool2566 = alloc_Boolean(1);
// compilenode returning bool2566
  *var_indentFreePass = bool2566;
  if (bool2566 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2562 = nothing;
  } else {
  }
// compilenode returning if2562
    if2557 = if2562;
  } else {
  }
// compilenode returning if2557
  return if2557;
}
Object meth_parser_apply2580(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_otoks = closure[0];
  Object *var_tokens = closure[1];
  Object self = *closure[2];
  Object *var_o = alloc_var();
  *var_o = undefined;
// Begin line 1542
  setline(1542);
// Begin line 1577
  setline(1577);
// Begin line 1541
  setline(1541);
// compilenode returning *var_otoks
  Object call2581 = callmethod(*var_otoks, "pop",
    0, params);
// compilenode returning call2581
// compilenode returning call2581
  var_o = alloc_var();
  *var_o = call2581;
  if (call2581 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1542
  setline(1542);
// compilenode returning *var_o
// compilenode returning *var_tokens
  params[0] = *var_o;
  Object call2582 = callmethod(*var_tokens, "push",
    1, params);
// compilenode returning call2582
  return call2582;
}
Object meth_parser_apply2618(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[1];
  Object *var_tokens = closure[0];
  Object *var_nxtToks = closure[1];
  Object self = *closure[2];
// Begin line 1560
  setline(1560);
// Begin line 1561
  setline(1561);
// Begin line 1557
  setline(1557);
// compilenode returning *var_i
// Begin line 1561
  setline(1561);
// Begin line 1577
  setline(1577);
// Begin line 1557
  setline(1557);
// compilenode returning *var_tokens
  Object call2620 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2620
// compilenode returning call2620
  params[0] = call2620;
  Object opresult2622 = callmethod(*var_i, "<", 1, params);
// compilenode returning opresult2622
  Object if2619;
  if (istrue(opresult2622)) {
  Object *var_t = alloc_var();
  *var_t = undefined;
// Begin line 1558
  setline(1558);
// Begin line 1577
  setline(1577);
// Begin line 1558
  setline(1558);
// compilenode returning *var_tokens
  Object call2623 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2623
// compilenode returning call2623
// compilenode returning *var_i
  params[0] = *var_i;
  Object diff2625 = callmethod(call2623, "-", 1, params);
// compilenode returning diff2625
// compilenode returning *var_tokens
  params[0] = diff2625;
  Object call2626 = callmethod(*var_tokens, "at",
    1, params);
// compilenode returning call2626
  var_t = alloc_var();
  *var_t = call2626;
  if (call2626 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1560
  setline(1560);
// Begin line 1559
  setline(1559);
// compilenode returning *var_nxtToks
// Begin line 1560
  setline(1560);
// Begin line 1577
  setline(1577);
// Begin line 1559
  setline(1559);
// compilenode returning *var_t
  Object call2627 = callmethod(*var_t, "kind",
    0, params);
// compilenode returning call2627
// compilenode returning call2627
  params[0] = call2627;
  Object opresult2629 = callmethod(*var_nxtToks, "++", 1, params);
// compilenode returning opresult2629
  if (strlit2630 == NULL) {
    strlit2630 = alloc_String(": ");
  }
// compilenode returning strlit2630
  params[0] = strlit2630;
  Object opresult2632 = callmethod(opresult2629, "++", 1, params);
// compilenode returning opresult2632
// Begin line 1560
  setline(1560);
// Begin line 1577
  setline(1577);
// Begin line 1559
  setline(1559);
// compilenode returning *var_t
  Object call2633 = callmethod(*var_t, "value",
    0, params);
// compilenode returning call2633
// compilenode returning call2633
  params[0] = call2633;
  Object opresult2635 = callmethod(opresult2632, "++", 1, params);
// compilenode returning opresult2635
  if (strlit2636 == NULL) {
    strlit2636 = alloc_String(", ");
  }
// compilenode returning strlit2636
  params[0] = strlit2636;
  Object opresult2638 = callmethod(opresult2635, "++", 1, params);
// compilenode returning opresult2638
  *var_nxtToks = opresult2638;
  if (opresult2638 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2619 = nothing;
  } else {
  }
// compilenode returning if2619
  return if2619;
}
Object meth_parser_apply2650(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = args + 0;
  Object params[1];
  Object *var_values = closure[0];
  Object *var_lstAST = closure[1];
  Object self = *closure[2];
// Begin line 1568
  setline(1568);
// Begin line 1570
  setline(1570);
// Begin line 1577
  setline(1577);
// Begin line 1564
  setline(1564);
// compilenode returning *var_values
  Object call2652 = callmethod(*var_values, "size",
    0, params);
// compilenode returning call2652
// compilenode returning call2652
  Object num2653 = alloc_Float64(0.0);
// compilenode returning num2653
  params[0] = num2653;
  Object opresult2655 = callmethod(call2652, ">", 1, params);
// compilenode returning opresult2655
  Object if2651;
  if (istrue(opresult2655)) {
  Object *var_t = alloc_var();
  *var_t = undefined;
// Begin line 1566
  setline(1566);
// Begin line 1577
  setline(1577);
// Begin line 1565
  setline(1565);
// compilenode returning *var_values
  Object call2656 = callmethod(*var_values, "pop",
    0, params);
// compilenode returning call2656
// compilenode returning call2656
  var_t = alloc_var();
  *var_t = call2656;
  if (call2656 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1566
  setline(1566);
// Begin line 1577
  setline(1577);
// Begin line 1566
  setline(1566);
// compilenode returning *var_t
  Object call2657 = callmethod(*var_t, "kind",
    0, params);
// compilenode returning call2657
// compilenode returning call2657
  params[0] = call2657;
  Object call2658 = gracelib_print(NULL, 1,  params);
// compilenode returning call2658
// Begin line 1567
  setline(1567);
  Object num2659 = alloc_Float64(2.0);
// compilenode returning num2659
// compilenode returning *var_t
  params[0] = num2659;
  Object call2660 = callmethod(*var_t, "pretty",
    1, params);
// compilenode returning call2660
  params[0] = call2660;
  Object call2661 = gracelib_print(NULL, 1,  params);
// compilenode returning call2661
// Begin line 1568
  setline(1568);
  Object num2662 = alloc_Float64(1.0);
// compilenode returning num2662
// compilenode returning *var_t
  params[0] = num2662;
  Object call2663 = callmethod(*var_t, "pretty",
    1, params);
// compilenode returning call2663
  if (strlit2664 == NULL) {
    strlit2664 = alloc_String("""\x0a""");
  }
// compilenode returning strlit2664
  params[0] = strlit2664;
  Object opresult2666 = callmethod(call2663, "++", 1, params);
// compilenode returning opresult2666
// compilenode returning *var_lstAST
  params[0] = *var_lstAST;
  Object opresult2668 = callmethod(opresult2666, "++", 1, params);
// compilenode returning opresult2668
  *var_lstAST = opresult2668;
  if (opresult2668 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2651 = nothing;
  } else {
  }
// compilenode returning if2651
  return if2651;
}
Object meth_parser_parse2568(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[44];
  Object *var_toks = alloc_var();
  *var_toks = args[0];
  Object params[1];
  Object *var_sym = closure[0];
  Object *var_tokens = closure[1];
  Object *var_linenum = closure[2];
  Object *var_values = closure[3];
  Object *var_otoks = alloc_var();
  *var_otoks = undefined;
  Object *var_oldlength = alloc_var();
  *var_oldlength = undefined;
// Begin line 1536
  setline(1536);
  if (strlit2569 == NULL) {
    strlit2569 = alloc_String("processing tokens.");
  }
// compilenode returning strlit2569
// compilenode returning module_util
  params[0] = strlit2569;
  Object call2570 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call2570
// Begin line 1538
  setline(1538);
// Begin line 1537
  setline(1537);
// compilenode returning *var_toks
  var_otoks = alloc_var();
  *var_otoks = *var_toks;
  if (*var_toks == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1539
  setline(1539);
// Begin line 1577
  setline(1577);
// Begin line 1538
  setline(1538);
// compilenode returning *var_toks
  Object call2571 = callmethod(*var_toks, "first",
    0, params);
// compilenode returning call2571
// compilenode returning call2571
  *var_sym = call2571;
  if (call2571 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1540
  setline(1540);
  Object array2573 = alloc_List();
// compilenode returning array2573
  *var_tokens = array2573;
  if (array2573 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1542
  setline(1542);
// Begin line 1544
  setline(1544);
// Begin line 1577
  setline(1577);
// Begin line 1540
  setline(1540);
// compilenode returning *var_otoks
  Object call2576 = callmethod(*var_otoks, "indices",
    0, params);
// compilenode returning call2576
// compilenode returning call2576
// Begin line 1542
  setline(1542);
// Begin line 1577
  setline(1577);
  Object obj2578 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2578, self, 0);
  addmethod2(obj2578, "outer", &reader_parser_outer_2579);
  adddatum2(obj2578, self, 0);
  block_savedest(obj2578);
  Object **closure2580 = createclosure(3);
  addtoclosure(closure2580, var_otoks);
  addtoclosure(closure2580, var_tokens);
  Object *selfpp2583 = alloc_var();
  *selfpp2583 = self;
  addtoclosure(closure2580, selfpp2583);
  struct UserObject *uo2580 = (struct UserObject*)obj2578;
  uo2580->data[1] = (Object)closure2580;
  addmethod2(obj2578, "apply", &meth_parser_apply2580);
  set_type(obj2578, 0);
// compilenode returning obj2578
  setclassname(obj2578, "Block<parser:2577>");
// compilenode returning obj2578
  params[0] = call2576;
  Object iter2575 = callmethod(call2576, "iter", 1, params);
  while(1) {
    Object cond2575 = callmethod(iter2575, "havemore", 0, NULL);
    if (!istrue(cond2575)) break;
    params[0] = callmethod(iter2575, "next", 0, NULL);
    callmethod(obj2578, "apply", 1, params);
  }
// compilenode returning call2576
// Begin line 1544
  setline(1544);
  if (strlit2584 == NULL) {
    strlit2584 = alloc_String("parsing.");
  }
// compilenode returning strlit2584
// compilenode returning module_util
  params[0] = strlit2584;
  Object call2585 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call2585
// Begin line 1546
  setline(1546);
// Begin line 1545
  setline(1545);
  Object num2586 = alloc_Float64(1.0);
// compilenode returning num2586
  *var_linenum = num2586;
  if (num2586 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1546
  setline(1546);
// compilenode returning self
  Object call2588 = callmethod(self, "next",
    0, params);
// compilenode returning call2588
// Begin line 1548
  setline(1548);
// Begin line 1577
  setline(1577);
// Begin line 1547
  setline(1547);
// compilenode returning *var_tokens
  Object call2589 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2589
// compilenode returning call2589
  Object num2590 = alloc_Float64(0.0);
// compilenode returning num2590
  params[0] = num2590;
  Object sum2592 = callmethod(call2589, "+", 1, params);
// compilenode returning sum2592
  var_oldlength = alloc_var();
  *var_oldlength = sum2592;
  if (sum2592 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1550
  setline(1550);
// Begin line 1552
  setline(1552);
// Begin line 1577
  setline(1577);
// Begin line 1548
  setline(1548);
// compilenode returning *var_tokens
  Object call2594 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2594
// compilenode returning call2594
  Object num2595 = alloc_Float64(0.0);
// compilenode returning num2595
  params[0] = num2595;
  Object opresult2597 = callmethod(call2594, "==", 1, params);
// compilenode returning opresult2597
  Object if2593;
  if (istrue(opresult2597)) {
// Begin line 1550
  setline(1550);
// compilenode returning self
  Object call2598 = callmethod(self, "statement",
    0, params);
// compilenode returning call2598
    if2593 = call2598;
  } else {
  }
// compilenode returning if2593
// Begin line 1576
  setline(1576);
  Object while2599;
  while (1) {
// Begin line 1577
  setline(1577);
// Begin line 1552
  setline(1552);
// compilenode returning *var_tokens
  Object call2600 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2600
// compilenode returning call2600
  Object num2601 = alloc_Float64(0.0);
// compilenode returning num2601
  params[0] = num2601;
  Object opresult2603 = callmethod(call2600, ">", 1, params);
// compilenode returning opresult2603
    while2599 = opresult2603;
    if (!istrue(opresult2603)) break;
// Begin line 1553
  setline(1553);
// compilenode returning self
  Object call2604 = callmethod(self, "statement",
    0, params);
// compilenode returning call2604
// Begin line 1573
  setline(1573);
// Begin line 1575
  setline(1575);
// Begin line 1577
  setline(1577);
// Begin line 1554
  setline(1554);
// compilenode returning *var_tokens
  Object call2606 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2606
// compilenode returning call2606
// compilenode returning *var_oldlength
  params[0] = *var_oldlength;
  Object opresult2608 = callmethod(call2606, "==", 1, params);
// compilenode returning opresult2608
  Object if2605;
  if (istrue(opresult2608)) {
  Object *var_nxtToks = alloc_var();
  *var_nxtToks = undefined;
  Object *var_lstAST = alloc_var();
  *var_lstAST = undefined;
// Begin line 1556
  setline(1556);
// Begin line 1555
  setline(1555);
  if (strlit2609 == NULL) {
    strlit2609 = alloc_String("");
  }
// compilenode returning strlit2609
  var_nxtToks = alloc_var();
  *var_nxtToks = strlit2609;
  if (strlit2609 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1560
  setline(1560);
// Begin line 1562
  setline(1562);
// Begin line 1556
  setline(1556);
  Object num2611 = alloc_Float64(0.0);
// compilenode returning num2611
  Object num2612 = alloc_Float64(5.0);
// compilenode returning num2612
  params[0] = num2612;
  Object opresult2614 = callmethod(num2611, "..", 1, params);
// compilenode returning opresult2614
// Begin line 1560
  setline(1560);
// Begin line 1577
  setline(1577);
  Object obj2616 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2616, self, 0);
  addmethod2(obj2616, "outer", &reader_parser_outer_2617);
  adddatum2(obj2616, self, 0);
  block_savedest(obj2616);
  Object **closure2618 = createclosure(3);
  addtoclosure(closure2618, var_tokens);
  addtoclosure(closure2618, var_nxtToks);
  Object *selfpp2640 = alloc_var();
  *selfpp2640 = self;
  addtoclosure(closure2618, selfpp2640);
  struct UserObject *uo2618 = (struct UserObject*)obj2616;
  uo2618->data[1] = (Object)closure2618;
  addmethod2(obj2616, "apply", &meth_parser_apply2618);
  set_type(obj2616, 0);
// compilenode returning obj2616
  setclassname(obj2616, "Block<parser:2615>");
// compilenode returning obj2616
  params[0] = opresult2614;
  Object iter2610 = callmethod(opresult2614, "iter", 1, params);
  while(1) {
    Object cond2610 = callmethod(iter2610, "havemore", 0, NULL);
    if (!istrue(cond2610)) break;
    params[0] = callmethod(iter2610, "next", 0, NULL);
    callmethod(obj2616, "apply", 1, params);
  }
// compilenode returning opresult2614
// Begin line 1563
  setline(1563);
// Begin line 1562
  setline(1562);
  if (strlit2641 == NULL) {
    strlit2641 = alloc_String("");
  }
// compilenode returning strlit2641
  var_lstAST = alloc_var();
  *var_lstAST = strlit2641;
  if (strlit2641 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1568
  setline(1568);
// Begin line 1571
  setline(1571);
// Begin line 1563
  setline(1563);
  Object num2643 = alloc_Float64(0.0);
// compilenode returning num2643
  Object num2644 = alloc_Float64(1.0);
// compilenode returning num2644
  params[0] = num2644;
  Object opresult2646 = callmethod(num2643, "..", 1, params);
// compilenode returning opresult2646
// Begin line 1568
  setline(1568);
// Begin line 1577
  setline(1577);
  Object obj2648 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2648, self, 0);
  addmethod2(obj2648, "outer", &reader_parser_outer_2649);
  adddatum2(obj2648, self, 0);
  block_savedest(obj2648);
  Object **closure2650 = createclosure(3);
  addtoclosure(closure2650, var_values);
  addtoclosure(closure2650, var_lstAST);
  Object *selfpp2670 = alloc_var();
  *selfpp2670 = self;
  addtoclosure(closure2650, selfpp2670);
  struct UserObject *uo2650 = (struct UserObject*)obj2648;
  uo2650->data[1] = (Object)closure2650;
  addmethod2(obj2648, "apply", &meth_parser_apply2650);
  set_type(obj2648, 0);
// compilenode returning obj2648
  setclassname(obj2648, "Block<parser:2647>");
// compilenode returning obj2648
  params[0] = opresult2646;
  Object iter2642 = callmethod(opresult2646, "iter", 1, params);
  while(1) {
    Object cond2642 = callmethod(iter2642, "havemore", 0, NULL);
    if (!istrue(cond2642)) break;
    params[0] = callmethod(iter2642, "next", 0, NULL);
    callmethod(obj2648, "apply", 1, params);
  }
// compilenode returning opresult2646
// Begin line 1573
  setline(1573);
// Begin line 1571
  setline(1571);
  if (strlit2671 == NULL) {
    strlit2671 = alloc_String("No token consumed. Have ");
  }
// compilenode returning strlit2671
// Begin line 1573
  setline(1573);
// Begin line 1577
  setline(1577);
// Begin line 1571
  setline(1571);
// compilenode returning *var_sym
  Object call2672 = callmethod(*var_sym, "kind",
    0, params);
// compilenode returning call2672
// compilenode returning call2672
  params[0] = call2672;
  Object opresult2674 = callmethod(strlit2671, "++", 1, params);
// compilenode returning opresult2674
// Begin line 1572
  setline(1572);
  if (strlit2675 == NULL) {
    strlit2675 = alloc_String(": ");
  }
// compilenode returning strlit2675
  params[0] = strlit2675;
  Object opresult2677 = callmethod(opresult2674, "++", 1, params);
// compilenode returning opresult2677
// Begin line 1573
  setline(1573);
// Begin line 1577
  setline(1577);
// Begin line 1572
  setline(1572);
// compilenode returning *var_sym
  Object call2678 = callmethod(*var_sym, "value",
    0, params);
// compilenode returning call2678
// compilenode returning call2678
  params[0] = call2678;
  Object opresult2680 = callmethod(opresult2677, "++", 1, params);
// compilenode returning opresult2680
  if (strlit2681 == NULL) {
    strlit2681 = alloc_String(". Recent AST:""\x0a""");
  }
// compilenode returning strlit2681
  params[0] = strlit2681;
  Object opresult2683 = callmethod(opresult2680, "++", 1, params);
// compilenode returning opresult2683
// Begin line 1573
  setline(1573);
// compilenode returning *var_lstAST
  params[0] = *var_lstAST;
  Object opresult2685 = callmethod(opresult2683, "++", 1, params);
// compilenode returning opresult2685
  if (strlit2686 == NULL) {
    strlit2686 = alloc_String("""\x0a""Next tokens: ");
  }
// compilenode returning strlit2686
  params[0] = strlit2686;
  Object opresult2688 = callmethod(opresult2685, "++", 1, params);
// compilenode returning opresult2688
// compilenode returning *var_nxtToks
  params[0] = *var_nxtToks;
  Object opresult2690 = callmethod(opresult2688, "++", 1, params);
// compilenode returning opresult2690
// Begin line 1571
  setline(1571);
// compilenode returning module_util
  params[0] = opresult2690;
  Object call2691 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call2691
    if2605 = call2691;
  } else {
  }
// compilenode returning if2605
// Begin line 1576
  setline(1576);
// Begin line 1577
  setline(1577);
// Begin line 1575
  setline(1575);
// compilenode returning *var_tokens
  Object call2692 = callmethod(*var_tokens, "size",
    0, params);
// compilenode returning call2692
// compilenode returning call2692
  Object num2693 = alloc_Float64(0.0);
// compilenode returning num2693
  params[0] = num2693;
  Object sum2695 = callmethod(call2692, "+", 1, params);
// compilenode returning sum2695
  *var_oldlength = sum2695;
  if (sum2695 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while2599
// Begin line 1577
  setline(1577);
// compilenode returning *var_values
  return *var_values;
}
Object module_parser_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<parser>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_lastline = alloc_var();
  *var_lastline = undefined;
  Object *var_linenum = alloc_var();
  *var_linenum = undefined;
  Object *var_lastIndent = alloc_var();
  *var_lastIndent = undefined;
  Object *var_indentFreePass = alloc_var();
  *var_indentFreePass = undefined;
  Object *var_minIndentLevel = alloc_var();
  *var_minIndentLevel = undefined;
  Object *var_statementIndent = alloc_var();
  *var_statementIndent = undefined;
  Object *var_statementToken = alloc_var();
  *var_statementToken = undefined;
  Object *var_tokens = alloc_var();
  *var_tokens = undefined;
  Object *var_values = alloc_var();
  *var_values = undefined;
  Object *var_auto_count = alloc_var();
  *var_auto_count = undefined;
  Object *var_sym = alloc_var();
  *var_sym = undefined;
  Object *var_lastToken = alloc_var();
  *var_lastToken = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of ast
  if (module_ast == NULL)
    module_ast = module_ast_init();
  Object *var_ast = alloc_var();
  *var_ast = module_ast;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Import of subtype
  if (module_subtype == NULL)
    module_subtype = module_subtype_init();
  Object *var_subtype = alloc_var();
  *var_subtype = module_subtype;
// compilenode returning undefined
// Begin line 7
  setline(7);
// Begin line 6
  setline(6);
  Object num4 = alloc_Float64(0.0);
// compilenode returning num4
  var_lastline = alloc_var();
  *var_lastline = num4;
  if (num4 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 8
  setline(8);
// Begin line 7
  setline(7);
  Object num5 = alloc_Float64(0.0);
// compilenode returning num5
  var_linenum = alloc_var();
  *var_linenum = num5;
  if (num5 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 9
  setline(9);
// Begin line 8
  setline(8);
  Object num6 = alloc_Float64(0.0);
// compilenode returning num6
  var_lastIndent = alloc_var();
  *var_lastIndent = num6;
  if (num6 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 10
  setline(10);
// Begin line 9
  setline(9);
  Object bool7 = alloc_Boolean(0);
// compilenode returning bool7
  var_indentFreePass = alloc_var();
  *var_indentFreePass = bool7;
  if (bool7 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 11
  setline(11);
// Begin line 10
  setline(10);
  Object num8 = alloc_Float64(0.0);
// compilenode returning num8
  var_minIndentLevel = alloc_var();
  *var_minIndentLevel = num8;
  if (num8 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 12
  setline(12);
// Begin line 11
  setline(11);
  Object num9 = alloc_Float64(0.0);
// compilenode returning num9
  var_statementIndent = alloc_var();
  *var_statementIndent = num9;
  if (num9 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 13
  setline(13);
  var_statementToken = alloc_var();
  *var_statementToken = undefined;
// compilenode returning nothing
// Begin line 14
  setline(14);
// Begin line 13
  setline(13);
  Object num10 = alloc_Float64(0.0);
// compilenode returning num10
  var_tokens = alloc_var();
  *var_tokens = num10;
  if (num10 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 15
  setline(15);
  Object array11 = alloc_List();
// compilenode returning array11
  var_values = alloc_var();
  *var_values = array11;
  if (array11 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 18
  setline(18);
// Begin line 15
  setline(15);
  Object num12 = alloc_Float64(0.0);
// compilenode returning num12
  var_auto_count = alloc_var();
  *var_auto_count = num12;
  if (num12 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 19
  setline(19);
  var_sym = alloc_var();
  *var_sym = undefined;
// compilenode returning nothing
// Begin line 23
  setline(23);
  var_lastToken = alloc_var();
  *var_lastToken = undefined;
// compilenode returning nothing
// Begin line 38
  setline(38);
  block_savedest(self);
  Object **closure13 = createclosure(6);
  addtoclosure(closure13, var_sym);
  addtoclosure(closure13, var_lastToken);
  addtoclosure(closure13, var_tokens);
  addtoclosure(closure13, var_linenum);
  addtoclosure(closure13, var_lastline);
  addtoclosure(closure13, var_lastIndent);
  struct UserObject *uo13 = (struct UserObject*)self;
  uo13->data[1] = (Object)closure13;
  addmethod2(self, "next", &meth_parser_next13);
// compilenode returning 
// Begin line 46
  setline(46);
  block_savedest(self);
  Object **closure45 = createclosure(1);
  addtoclosure(closure45, var_sym);
  struct UserObject *uo45 = (struct UserObject*)self;
  uo45->data[2] = (Object)closure45;
  addmethod2(self, "accept", &meth_parser_accept45);
// compilenode returning 
// Begin line 54
  setline(54);
  block_savedest(self);
  Object **closure49 = createclosure(3);
  addtoclosure(closure49, var_sym);
  addtoclosure(closure49, var_lastline);
  addtoclosure(closure49, var_lastIndent);
  struct UserObject *uo49 = (struct UserObject*)self;
  uo49->data[3] = (Object)closure49;
  addmethod2(self, "acceptSameLine", &meth_parser_acceptSameLine49);
// compilenode returning 
// Begin line 61
  setline(61);
  block_savedest(self);
  Object **closure63 = createclosure(1);
  addtoclosure(closure63, var_sym);
  struct UserObject *uo63 = (struct UserObject*)self;
  uo63->data[4] = (Object)closure63;
  addmethod2(self, "accept(1)onLineOf", &meth_parser_accept_40_1_41_onLineOf63);
// compilenode returning 
// Begin line 67
  setline(67);
  block_savedest(self);
  Object **closure79 = createclosure(2);
  addtoclosure(closure79, var_sym);
  addtoclosure(closure79, var_lastToken);
  struct UserObject *uo79 = (struct UserObject*)self;
  uo79->data[5] = (Object)closure79;
  addmethod2(self, "accept(1)onLineOfLastOr", &meth_parser_accept_40_1_41_onLineOfLastOr79);
// compilenode returning 
// Begin line 73
  setline(73);
  block_savedest(self);
  Object **closure101 = createclosure(1);
  addtoclosure(closure101, var_sym);
  struct UserObject *uo101 = (struct UserObject*)self;
  uo101->data[6] = (Object)closure101;
  addmethod2(self, "expect", &meth_parser_expect101);
// compilenode returning 
// Begin line 83
  setline(83);
  block_savedest(self);
  Object **closure126 = createclosure(1);
  addtoclosure(closure126, var_sym);
  struct UserObject *uo126 = (struct UserObject*)self;
  uo126->data[7] = (Object)closure126;
  addmethod2(self, "expect(1)or", &meth_parser_expect_40_1_41_or126);
// compilenode returning 
// Begin line 90
  setline(90);
  block_savedest(self);
  Object **closure156 = createclosure(1);
  addtoclosure(closure156, var_tokens);
  struct UserObject *uo156 = (struct UserObject*)self;
  uo156->data[8] = (Object)closure156;
  addmethod2(self, "expectConsume", &meth_parser_expectConsume156);
// compilenode returning 
// Begin line 98
  setline(98);
  block_savedest(self);
  Object **closure165 = createclosure(1);
  addtoclosure(closure165, var_tokens);
  struct UserObject *uo165 = (struct UserObject*)self;
  uo165->data[9] = (Object)closure165;
  addmethod2(self, "ifConsume(1)then", &meth_parser_ifConsume_40_1_41_then165);
// compilenode returning 
// Begin line 106
  setline(106);
  block_savedest(self);
  Object **closure173 = createclosure(2);
  addtoclosure(closure173, var_sym);
  addtoclosure(closure173, var_values);
  struct UserObject *uo173 = (struct UserObject*)self;
  uo173->data[10] = (Object)closure173;
  addmethod2(self, "pushnum", &meth_parser_pushnum173);
// compilenode returning 
// Begin line 113
  setline(113);
  block_savedest(self);
  Object **closure178 = createclosure(2);
  addtoclosure(closure178, var_sym);
  addtoclosure(closure178, var_values);
  struct UserObject *uo178 = (struct UserObject*)self;
  uo178->data[11] = (Object)closure178;
  addmethod2(self, "pushoctets", &meth_parser_pushoctets178);
// compilenode returning 
// Begin line 120
  setline(120);
  block_savedest(self);
  Object **closure183 = createclosure(2);
  addtoclosure(closure183, var_sym);
  addtoclosure(closure183, var_values);
  struct UserObject *uo183 = (struct UserObject*)self;
  uo183->data[12] = (Object)closure183;
  addmethod2(self, "pushstring", &meth_parser_pushstring183);
// compilenode returning 
// Begin line 132
  setline(132);
  block_savedest(self);
  Object **closure188 = createclosure(3);
  addtoclosure(closure188, var_sym);
  addtoclosure(closure188, var_auto_count);
  addtoclosure(closure188, var_values);
  struct UserObject *uo188 = (struct UserObject*)self;
  uo188->data[13] = (Object)closure188;
  addmethod2(self, "pushidentifier", &meth_parser_pushidentifier188);
// compilenode returning 
// Begin line 188
  setline(188);
  block_savedest(self);
  Object **closure207 = createclosure(2);
  addtoclosure(closure207, var_values);
  addtoclosure(closure207, var_sym);
  struct UserObject *uo207 = (struct UserObject*)self;
  uo207->data[14] = (Object)closure207;
  addmethod2(self, "dotyperef", &meth_parser_dotyperef207);
// compilenode returning 
// Begin line 264
  setline(264);
  block_savedest(self);
  Object **closure346 = createclosure(7);
  addtoclosure(closure346, var_statementIndent);
  addtoclosure(closure346, var_sym);
  addtoclosure(closure346, var_tokens);
  addtoclosure(closure346, var_statementToken);
  addtoclosure(closure346, var_values);
  addtoclosure(closure346, var_lastToken);
  addtoclosure(closure346, var_minIndentLevel);
  struct UserObject *uo346 = (struct UserObject*)self;
  uo346->data[15] = (Object)closure346;
  addmethod2(self, "block", &meth_parser_block346);
// compilenode returning 
// Begin line 351
  setline(351);
  block_savedest(self);
  Object **closure464 = createclosure(1);
  addtoclosure(closure464, var_auto_count);
  struct UserObject *uo464 = (struct UserObject*)self;
  uo464->data[16] = (Object)closure464;
  addmethod2(self, "rewritematchblock", &meth_parser_rewritematchblock464);
// compilenode returning 
// Begin line 456
  setline(456);
  block_savedest(self);
  Object **closure650 = createclosure(6);
  addtoclosure(closure650, var_sym);
  addtoclosure(closure650, var_values);
  addtoclosure(closure650, var_statementIndent);
  addtoclosure(closure650, var_lastToken);
  addtoclosure(closure650, var_minIndentLevel);
  addtoclosure(closure650, var_statementToken);
  struct UserObject *uo650 = (struct UserObject*)self;
  uo650->data[17] = (Object)closure650;
  addmethod2(self, "doif", &meth_parser_doif650);
// compilenode returning 
// Begin line 483
  setline(483);
  block_savedest(self);
  Object **closure806 = createclosure(4);
  addtoclosure(closure806, var_sym);
  addtoclosure(closure806, var_values);
  addtoclosure(closure806, var_statementIndent);
  addtoclosure(closure806, var_minIndentLevel);
  struct UserObject *uo806 = (struct UserObject*)self;
  uo806->data[18] = (Object)closure806;
  addmethod2(self, "dofor", &meth_parser_dofor806);
// compilenode returning 
// Begin line 524
  setline(524);
  block_savedest(self);
  Object **closure852 = createclosure(5);
  addtoclosure(closure852, var_sym);
  addtoclosure(closure852, var_statementIndent);
  addtoclosure(closure852, var_values);
  addtoclosure(closure852, var_lastToken);
  addtoclosure(closure852, var_minIndentLevel);
  struct UserObject *uo852 = (struct UserObject*)self;
  uo852->data[19] = (Object)closure852;
  addmethod2(self, "dowhile", &meth_parser_dowhile852);
// compilenode returning 
// Begin line 539
  setline(539);
  block_savedest(self);
  Object **closure918 = createclosure(1);
  addtoclosure(closure918, var_sym);
  struct UserObject *uo918 = (struct UserObject*)self;
  uo918->data[20] = (Object)closure918;
  addmethod2(self, "identifier", &meth_parser_identifier918);
// compilenode returning 
// Begin line 566
  setline(566);
  block_savedest(self);
  Object **closure941 = createclosure(2);
  addtoclosure(closure941, var_sym);
  addtoclosure(closure941, var_values);
  struct UserObject *uo941 = (struct UserObject*)self;
  uo941->data[21] = (Object)closure941;
  addmethod2(self, "prefixop", &meth_parser_prefixop941);
// compilenode returning 
// Begin line 587
  setline(587);
  block_savedest(self);
  Object **closure973 = createclosure(1);
  addtoclosure(closure973, var_values);
  struct UserObject *uo973 = (struct UserObject*)self;
  uo973->data[22] = (Object)closure973;
  addmethod2(self, "generic", &meth_parser_generic973);
// compilenode returning 
// Begin line 612
  setline(612);
  block_savedest(self);
  Object **closure998 = createclosure(1);
  addtoclosure(closure998, var_sym);
  struct UserObject *uo998 = (struct UserObject*)self;
  uo998->data[23] = (Object)closure998;
  addmethod2(self, "term", &meth_parser_term998);
// compilenode returning 
// Begin line 632
  setline(632);
  addmethod2(self, "expression", &meth_parser_expression1041);
// compilenode returning 
// Begin line 646
  setline(646);
  block_savedest(self);
  Object **closure1055 = createclosure(1);
  addtoclosure(closure1055, var_values);
  struct UserObject *uo1055 = (struct UserObject*)self;
  uo1055->data[25] = (Object)closure1055;
  addmethod2(self, "postfixsquare", &meth_parser_postfixsquare1055);
// compilenode returning 
// Begin line 660
  setline(660);
  addmethod2(self, "oprec", &meth_parser_oprec1068);
// compilenode returning 
// Begin line 668
  setline(668);
  addmethod2(self, "toprec", &meth_parser_toprec1080);
// compilenode returning 
// Begin line 759
  setline(759);
  block_savedest(self);
  Object **closure1089 = createclosure(3);
  addtoclosure(closure1089, var_values);
  addtoclosure(closure1089, var_statementToken);
  addtoclosure(closure1089, var_sym);
  struct UserObject *uo1089 = (struct UserObject*)self;
  uo1089->data[28] = (Object)closure1089;
  addmethod2(self, "expressionrest", &meth_parser_expressionrest1089);
// compilenode returning 
// Begin line 778
  setline(778);
  block_savedest(self);
  Object **closure1224 = createclosure(2);
  addtoclosure(closure1224, var_values);
  addtoclosure(closure1224, var_sym);
  struct UserObject *uo1224 = (struct UserObject*)self;
  uo1224->data[29] = (Object)closure1224;
  addmethod2(self, "dotrest", &meth_parser_dotrest1224);
// compilenode returning 
// Begin line 859
  setline(859);
  block_savedest(self);
  Object **closure1245 = createclosure(5);
  addtoclosure(closure1245, var_values);
  addtoclosure(closure1245, var_lastToken);
  addtoclosure(closure1245, var_minIndentLevel);
  addtoclosure(closure1245, var_sym);
  addtoclosure(closure1245, var_linenum);
  struct UserObject *uo1245 = (struct UserObject*)self;
  uo1245->data[30] = (Object)closure1245;
  addmethod2(self, "callrest", &meth_parser_callrest1245);
// compilenode returning 
// Begin line 921
  setline(921);
  block_savedest(self);
  Object **closure1379 = createclosure(5);
  addtoclosure(closure1379, var_linenum);
  addtoclosure(closure1379, var_lastToken);
  addtoclosure(closure1379, var_values);
  addtoclosure(closure1379, var_sym);
  addtoclosure(closure1379, var_lastline);
  struct UserObject *uo1379 = (struct UserObject*)self;
  uo1379->data[31] = (Object)closure1379;
  addmethod2(self, "callmprest", &meth_parser_callmprest1379);
// compilenode returning 
// Begin line 947
  setline(947);
  block_savedest(self);
  Object **closure1513 = createclosure(2);
  addtoclosure(closure1513, var_sym);
  addtoclosure(closure1513, var_values);
  struct UserObject *uo1513 = (struct UserObject*)self;
  uo1513->data[32] = (Object)closure1513;
  addmethod2(self, "defdec", &meth_parser_defdec1513);
// compilenode returning 
// Begin line 973
  setline(973);
  block_savedest(self);
  Object **closure1559 = createclosure(2);
  addtoclosure(closure1559, var_sym);
  addtoclosure(closure1559, var_values);
  struct UserObject *uo1559 = (struct UserObject*)self;
  uo1559->data[33] = (Object)closure1559;
  addmethod2(self, "vardec", &meth_parser_vardec1559);
// compilenode returning 
// Begin line 996
  setline(996);
  block_savedest(self);
  Object **closure1603 = createclosure(1);
  addtoclosure(closure1603, var_values);
  struct UserObject *uo1603 = (struct UserObject*)self;
  uo1603->data[34] = (Object)closure1603;
  addmethod2(self, "doarray", &meth_parser_doarray1603);
// compilenode returning 
// Begin line 1064
  setline(1064);
  block_savedest(self);
  Object **closure1643 = createclosure(2);
  addtoclosure(closure1643, var_sym);
  addtoclosure(closure1643, var_values);
  struct UserObject *uo1643 = (struct UserObject*)self;
  uo1643->data[35] = (Object)closure1643;
  addmethod2(self, "doobject", &meth_parser_doobject1643);
// compilenode returning 
// Begin line 1172
  setline(1172);
  block_savedest(self);
  Object **closure1755 = createclosure(2);
  addtoclosure(closure1755, var_sym);
  addtoclosure(closure1755, var_values);
  struct UserObject *uo1755 = (struct UserObject*)self;
  uo1755->data[36] = (Object)closure1755;
  addmethod2(self, "doclass", &meth_parser_doclass1755);
// compilenode returning 
// Begin line 1238
  setline(1238);
  block_savedest(self);
  Object **closure1914 = createclosure(2);
  addtoclosure(closure1914, var_values);
  addtoclosure(closure1914, var_sym);
  struct UserObject *uo1914 = (struct UserObject*)self;
  uo1914->data[37] = (Object)closure1914;
  addmethod2(self, "parsempmndecrest", &meth_parser_parsempmndecrest1914);
// compilenode returning 
// Begin line 1356
  setline(1356);
  block_savedest(self);
  Object **closure2020 = createclosure(3);
  addtoclosure(closure2020, var_sym);
  addtoclosure(closure2020, var_values);
  addtoclosure(closure2020, var_minIndentLevel);
  struct UserObject *uo2020 = (struct UserObject*)self;
  uo2020->data[38] = (Object)closure2020;
  addmethod2(self, "methoddec", &meth_parser_methoddec2020);
// compilenode returning 
// Begin line 1369
  setline(1369);
  block_savedest(self);
  Object **closure2214 = createclosure(2);
  addtoclosure(closure2214, var_sym);
  addtoclosure(closure2214, var_values);
  struct UserObject *uo2214 = (struct UserObject*)self;
  uo2214->data[39] = (Object)closure2214;
  addmethod2(self, "doimport", &meth_parser_doimport2214);
// compilenode returning 
// Begin line 1381
  setline(1381);
  block_savedest(self);
  Object **closure2231 = createclosure(2);
  addtoclosure(closure2231, var_sym);
  addtoclosure(closure2231, var_values);
  struct UserObject *uo2231 = (struct UserObject*)self;
  uo2231->data[40] = (Object)closure2231;
  addmethod2(self, "doreturn", &meth_parser_doreturn2231);
// compilenode returning 
// Begin line 1430
  setline(1430);
  block_savedest(self);
  Object **closure2252 = createclosure(1);
  addtoclosure(closure2252, var_values);
  struct UserObject *uo2252 = (struct UserObject*)self;
  uo2252->data[41] = (Object)closure2252;
  addmethod2(self, "domethodtype", &meth_parser_domethodtype2252);
// compilenode returning 
// Begin line 1461
  setline(1461);
  block_savedest(self);
  Object **closure2354 = createclosure(2);
  addtoclosure(closure2354, var_sym);
  addtoclosure(closure2354, var_values);
  struct UserObject *uo2354 = (struct UserObject*)self;
  uo2354->data[42] = (Object)closure2354;
  addmethod2(self, "dotype", &meth_parser_dotype2354);
// compilenode returning 
// Begin line 1529
  setline(1529);
  block_savedest(self);
  Object **closure2412 = createclosure(6);
  addtoclosure(closure2412, var_sym);
  addtoclosure(closure2412, var_statementIndent);
  addtoclosure(closure2412, var_statementToken);
  addtoclosure(closure2412, var_indentFreePass);
  addtoclosure(closure2412, var_minIndentLevel);
  addtoclosure(closure2412, var_values);
  struct UserObject *uo2412 = (struct UserObject*)self;
  uo2412->data[43] = (Object)closure2412;
  addmethod2(self, "statement", &meth_parser_statement2412);
// compilenode returning 
// Begin line 1577
  setline(1577);
  block_savedest(self);
  Object **closure2568 = createclosure(4);
  addtoclosure(closure2568, var_sym);
  addtoclosure(closure2568, var_tokens);
  addtoclosure(closure2568, var_linenum);
  addtoclosure(closure2568, var_values);
  struct UserObject *uo2568 = (struct UserObject*)self;
  uo2568->data[44] = (Object)closure2568;
  addmethod2(self, "parse", &meth_parser_parse2568);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_parser_init();
  gracelib_stats();
  return 0;
}
