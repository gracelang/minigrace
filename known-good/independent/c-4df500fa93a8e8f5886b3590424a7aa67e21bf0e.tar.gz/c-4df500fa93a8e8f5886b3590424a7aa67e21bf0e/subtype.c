#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_subtype_outer_23(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_43(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_50(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_75(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_101(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_116(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_142(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_150(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_164(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_172(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_216(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_277(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_296(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_316(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_323(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_365(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_394(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_401(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_448(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_subtype_outer_468(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_util_init();
Object module_util;
static Object strlit9;
static Object strlit28;
static Object strlit31;
static Object strlit35;
static Object strlit64;
static Object strlit168;
static Object strlit177;
static Object strlit180;
static Object strlit185;
static Object strlit190;
static Object strlit193;
static Object strlit198;
static Object strlit210;
static Object strlit243;
static Object strlit249;
static Object strlit440;
static Object strlit452;
static Object strlit464;
static Object strlit478;
Object meth_subtype_apply24(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_g = alloc_var();
  *var_g = args[0];
  Object params[1];
  Object *var_joinees = closure[0];
  Object self = *closure[1];
// Begin line 18
  setline(18);
// compilenode returning *var_g
// compilenode returning self
  params[0] = *var_g;
  Object call25 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call25
// compilenode returning *var_joinees
  params[0] = call25;
  Object call26 = callmethod(*var_joinees, "push",
    1, params);
// compilenode returning call26
  return call26;
}
Object meth_subtype_stringifyType5(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[2];
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 12
  setline(12);
// Begin line 262
  setline(262);
// Begin line 11
  setline(11);
// compilenode returning *var_t
  Object call6 = callmethod(*var_t, "value",
    0, params);
// compilenode returning call6
// compilenode returning call6
  var_s = alloc_var();
  *var_s = call6;
  if (call6 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 14
  setline(14);
// Begin line 15
  setline(15);
// Begin line 262
  setline(262);
// Begin line 12
  setline(12);
// compilenode returning *var_t
  Object call8 = callmethod(*var_t, "kind",
    0, params);
// compilenode returning call8
// compilenode returning call8
  if (strlit9 == NULL) {
    strlit9 = alloc_String("identifier");
  }
// compilenode returning strlit9
  params[0] = strlit9;
  Object opresult11 = callmethod(call8, "==", 1, params);
// compilenode returning opresult11
  Object if7;
  if (istrue(opresult11)) {
// Begin line 14
  setline(14);
// Begin line 13
  setline(13);
// compilenode returning *var_s
  return *var_s;
// compilenode returning undefined
    if7 = undefined;
  } else {
  }
// compilenode returning if7
// Begin line 20
  setline(20);
// Begin line 22
  setline(22);
// Begin line 262
  setline(262);
// Begin line 22
  setline(22);
// Begin line 262
  setline(262);
// Begin line 15
  setline(15);
// compilenode returning *var_t
  Object call13 = callmethod(*var_t, "generics",
    0, params);
// compilenode returning call13
// compilenode returning call13
  Object call14 = callmethod(call13, "size",
    0, params);
// compilenode returning call14
// compilenode returning call14
  Object num15 = alloc_Float64(0.0);
// compilenode returning num15
  params[0] = num15;
  Object opresult17 = callmethod(call14, ">", 1, params);
// compilenode returning opresult17
  Object if12;
  if (istrue(opresult17)) {
  Object *var_joinees = alloc_var();
  *var_joinees = undefined;
// Begin line 17
  setline(17);
  Object array18 = alloc_List();
// compilenode returning array18
  *var_joinees = array18;
  if (array18 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 18
  setline(18);
// Begin line 20
  setline(20);
// Begin line 262
  setline(262);
// Begin line 17
  setline(17);
// compilenode returning *var_t
  Object call20 = callmethod(*var_t, "generics",
    0, params);
// compilenode returning call20
// compilenode returning call20
// Begin line 18
  setline(18);
// Begin line 262
  setline(262);
  Object obj22 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj22, self, 0);
  addmethod2(obj22, "outer", &reader_subtype_outer_23);
  adddatum2(obj22, self, 0);
  block_savedest(obj22);
  Object **closure24 = createclosure(2);
  addtoclosure(closure24, var_joinees);
  Object *selfpp27 = alloc_var();
  *selfpp27 = self;
  addtoclosure(closure24, selfpp27);
  struct UserObject *uo24 = (struct UserObject*)obj22;
  uo24->data[1] = (Object)closure24;
  addmethod2(obj22, "apply", &meth_subtype_apply24);
  set_type(obj22, 0);
// compilenode returning obj22
  setclassname(obj22, "Block<subtype:21>");
// compilenode returning obj22
  params[0] = call20;
  Object iter19 = callmethod(call20, "iter", 1, params);
  while(1) {
    Object cond19 = callmethod(iter19, "havemore", 0, NULL);
    if (!istrue(cond19)) break;
    params[0] = callmethod(iter19, "next", 0, NULL);
    callmethod(obj22, "apply", 1, params);
  }
// compilenode returning call20
// Begin line 20
  setline(20);
// Begin line 21
  setline(21);
// Begin line 20
  setline(20);
// compilenode returning *var_s
  if (strlit28 == NULL) {
    strlit28 = alloc_String("<");
  }
// compilenode returning strlit28
  params[0] = strlit28;
  Object opresult30 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult30
  if (strlit31 == NULL) {
    strlit31 = alloc_String(",");
  }
// compilenode returning strlit31
// compilenode returning *var_joinees
// compilenode returning module_util
  params[0] = strlit31;
  params[1] = *var_joinees;
  Object call32 = callmethod(module_util, "join",
    2, params);
// compilenode returning call32
  params[0] = call32;
  Object opresult34 = callmethod(opresult30, "++", 1, params);
// compilenode returning opresult34
  if (strlit35 == NULL) {
    strlit35 = alloc_String(">");
  }
// compilenode returning strlit35
  params[0] = strlit35;
  Object opresult37 = callmethod(opresult34, "++", 1, params);
// compilenode returning opresult37
  *var_s = opresult37;
  if (opresult37 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if12 = nothing;
  } else {
  }
// compilenode returning if12
// Begin line 22
  setline(22);
// compilenode returning *var_s
  return *var_s;
}
Object meth_subtype_apply51(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[2];
  Object *var_inner = closure[0];
  Object self = *closure[1];
// Begin line 30
  setline(30);
// compilenode returning *var_t2
// compilenode returning self
  params[0] = *var_t2;
  Object call52 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call52
  Object bool53 = alloc_Boolean(1);
// compilenode returning bool53
// compilenode returning *var_inner
  params[0] = call52;
  params[1] = bool53;
  Object call54 = callmethod(*var_inner, "put",
    2, params);
// compilenode returning call54
  return call54;
}
Object meth_subtype_apply44(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[2];
  Object *var_HashMap = closure[0];
  Object *var_types = closure[1];
  Object *var_matrix = closure[2];
  Object self = *closure[3];
  Object *var_inner = alloc_var();
  *var_inner = undefined;
  Object *var_d = alloc_var();
  *var_d = undefined;
// Begin line 28
  setline(28);
// Begin line 262
  setline(262);
// Begin line 27
  setline(27);
// compilenode returning *var_HashMap
  Object call45 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call45
// compilenode returning call45
  *var_inner = call45;
  if (call45 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 28
  setline(28);
// compilenode returning *var_t
// Begin line 29
  setline(29);
// compilenode returning self
  params[0] = *var_t;
  Object call46 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call46
  *var_d = call46;
  if (call46 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 30
  setline(30);
// Begin line 29
  setline(29);
// compilenode returning *var_types
// Begin line 30
  setline(30);
// Begin line 262
  setline(262);
  Object obj49 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj49, self, 0);
  addmethod2(obj49, "outer", &reader_subtype_outer_50);
  adddatum2(obj49, self, 0);
  block_savedest(obj49);
  Object **closure51 = createclosure(2);
  addtoclosure(closure51, var_inner);
  Object *selfpp55 = alloc_var();
  *selfpp55 = self;
  addtoclosure(closure51, selfpp55);
  struct UserObject *uo51 = (struct UserObject*)obj49;
  uo51->data[1] = (Object)closure51;
  addmethod2(obj49, "apply", &meth_subtype_apply51);
  set_type(obj49, 0);
// compilenode returning obj49
  setclassname(obj49, "Block<subtype:48>");
// compilenode returning obj49
  params[0] = *var_types;
  Object iter47 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond47 = callmethod(iter47, "havemore", 0, NULL);
    if (!istrue(cond47)) break;
    params[0] = callmethod(iter47, "next", 0, NULL);
    callmethod(obj49, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 32
  setline(32);
// compilenode returning *var_d
// compilenode returning *var_inner
// compilenode returning *var_matrix
  params[0] = *var_d;
  params[1] = *var_inner;
  Object call56 = callmethod(*var_matrix, "put",
    2, params);
// compilenode returning call56
  return call56;
}
Object meth_subtype_resetMatrix39(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object params[1];
  Object *var_types = closure[0];
  Object *var_HashMap = closure[1];
  Object *var_matrix = closure[2];
// Begin line 26
  setline(26);
// compilenode returning *var_types
// Begin line 32
  setline(32);
// Begin line 262
  setline(262);
  Object obj42 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj42, self, 0);
  addmethod2(obj42, "outer", &reader_subtype_outer_43);
  adddatum2(obj42, self, 0);
  block_savedest(obj42);
  Object **closure44 = createclosure(4);
  addtoclosure(closure44, var_HashMap);
  addtoclosure(closure44, var_types);
  addtoclosure(closure44, var_matrix);
  Object *selfpp57 = alloc_var();
  *selfpp57 = self;
  addtoclosure(closure44, selfpp57);
  struct UserObject *uo44 = (struct UserObject*)obj42;
  uo44->data[1] = (Object)closure44;
  addmethod2(obj42, "apply", &meth_subtype_apply44);
  set_type(obj42, 0);
// compilenode returning obj42
  setclassname(obj42, "Block<subtype:41>");
// compilenode returning obj42
  params[0] = *var_types;
  Object iter40 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond40 = callmethod(iter40, "havemore", 0, NULL);
    if (!istrue(cond40)) break;
    params[0] = callmethod(iter40, "next", 0, NULL);
    callmethod(obj42, "apply", 1, params);
  }
// compilenode returning *var_types
  return *var_types;
}
Object meth_subtype_apply76(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[2];
  Object *var_inner = closure[0];
  Object *var_t = closure[1];
  Object *var_d = closure[2];
  Object *var_matrix = closure[3];
  Object self = *closure[4];
  Object *var_d2 = alloc_var();
  *var_d2 = undefined;
// Begin line 48
  setline(48);
// compilenode returning *var_t2
// Begin line 49
  setline(49);
// compilenode returning self
  params[0] = *var_t2;
  Object call77 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call77
  *var_d2 = call77;
  if (call77 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_d2
  Object bool78 = alloc_Boolean(1);
// compilenode returning bool78
// compilenode returning *var_inner
  params[0] = *var_d2;
  params[1] = bool78;
  Object call79 = callmethod(*var_inner, "put",
    2, params);
// compilenode returning call79
// Begin line 51
  setline(51);
// Begin line 53
  setline(53);
// Begin line 50
  setline(50);
// compilenode returning *var_t2
// compilenode returning *var_t
  params[0] = *var_t;
  Object opresult82 = callmethod(*var_t2, "/=", 1, params);
// compilenode returning opresult82
  Object if80;
  if (istrue(opresult82)) {
// Begin line 51
  setline(51);
// compilenode returning *var_d
  Object bool83 = alloc_Boolean(1);
// compilenode returning bool83
// compilenode returning *var_d2
// compilenode returning *var_matrix
  params[0] = *var_d2;
  Object call84 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call84
  params[0] = *var_d;
  params[1] = bool83;
  Object call85 = callmethod(call84, "put",
    2, params);
// compilenode returning call85
    if80 = call85;
  } else {
  }
// compilenode returning if80
  return if80;
}
Object meth_subtype_addType58(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[2];
  Object *var_matrix = closure[0];
  Object *var_DynamicType = closure[1];
  Object *var_types = closure[2];
  Object *var_typesToId = closure[3];
  Object *var_HashMap = closure[4];
  Object *var_modified = closure[5];
  Object *var_d = alloc_var();
  *var_d = undefined;
  Object *var_inner = alloc_var();
  *var_inner = undefined;
// Begin line 37
  setline(37);
// compilenode returning *var_t
// Begin line 38
  setline(38);
// compilenode returning self
  params[0] = *var_t;
  Object call59 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call59
  *var_d = call59;
  if (call59 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 40
  setline(40);
// Begin line 38
  setline(38);
// compilenode returning *var_d
// compilenode returning *var_matrix
  params[0] = *var_d;
  Object call61 = callmethod(*var_matrix, "contains",
    1, params);
// compilenode returning call61
  Object if60;
  if (istrue(call61)) {
// Begin line 40
  setline(40);
// Begin line 39
  setline(39);
  Object bool62 = alloc_Boolean(0);
// compilenode returning bool62
  return bool62;
// compilenode returning undefined
    if60 = undefined;
  } else {
  }
// compilenode returning if60
// Begin line 43
  setline(43);
// Begin line 44
  setline(44);
// Begin line 41
  setline(41);
// compilenode returning *var_d
  if (strlit64 == NULL) {
    strlit64 = alloc_String("Dynamic");
  }
// compilenode returning strlit64
  params[0] = strlit64;
  Object opresult66 = callmethod(*var_d, "==", 1, params);
// compilenode returning opresult66
  Object if63;
  if (istrue(opresult66)) {
// Begin line 43
  setline(43);
// Begin line 42
  setline(42);
// compilenode returning *var_t
  *var_DynamicType = *var_t;
  if (*var_t == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if63 = nothing;
  } else {
  }
// compilenode returning if63
// Begin line 44
  setline(44);
// compilenode returning *var_d
// Begin line 262
  setline(262);
// Begin line 44
  setline(44);
// compilenode returning *var_types
  Object call68 = callmethod(*var_types, "size",
    0, params);
// compilenode returning call68
// compilenode returning call68
// compilenode returning *var_typesToId
  params[0] = *var_d;
  params[1] = call68;
  Object call69 = callmethod(*var_typesToId, "put",
    2, params);
// compilenode returning call69
// Begin line 45
  setline(45);
// compilenode returning *var_t
// compilenode returning *var_types
  params[0] = *var_t;
  Object call70 = callmethod(*var_types, "push",
    1, params);
// compilenode returning call70
// Begin line 47
  setline(47);
// Begin line 262
  setline(262);
// Begin line 46
  setline(46);
// compilenode returning *var_HashMap
  Object call71 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call71
// compilenode returning call71
  *var_inner = call71;
  if (call71 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 51
  setline(51);
// Begin line 47
  setline(47);
// compilenode returning *var_types
// Begin line 51
  setline(51);
// Begin line 262
  setline(262);
  Object obj74 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj74, self, 0);
  addmethod2(obj74, "outer", &reader_subtype_outer_75);
  adddatum2(obj74, self, 0);
  block_savedest(obj74);
  Object **closure76 = createclosure(5);
  addtoclosure(closure76, var_inner);
  addtoclosure(closure76, var_t);
  addtoclosure(closure76, var_d);
  addtoclosure(closure76, var_matrix);
  Object *selfpp86 = alloc_var();
  *selfpp86 = self;
  addtoclosure(closure76, selfpp86);
  struct UserObject *uo76 = (struct UserObject*)obj74;
  uo76->data[1] = (Object)closure76;
  addmethod2(obj74, "apply", &meth_subtype_apply76);
  set_type(obj74, 0);
// compilenode returning obj74
  setclassname(obj74, "Block<subtype:73>");
// compilenode returning obj74
  params[0] = *var_types;
  Object iter72 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond72 = callmethod(iter72, "havemore", 0, NULL);
    if (!istrue(cond72)) break;
    params[0] = callmethod(iter72, "next", 0, NULL);
    callmethod(obj74, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 54
  setline(54);
// compilenode returning *var_d
// compilenode returning *var_inner
// compilenode returning *var_matrix
  params[0] = *var_d;
  params[1] = *var_inner;
  Object call87 = callmethod(*var_matrix, "put",
    2, params);
// compilenode returning call87
// Begin line 56
  setline(56);
// Begin line 55
  setline(55);
  Object bool88 = alloc_Boolean(1);
// compilenode returning bool88
  *var_modified = bool88;
  if (bool88 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 56
  setline(56);
  Object bool90 = alloc_Boolean(1);
// compilenode returning bool90
  return bool90;
}
Object meth_subtype_apply117(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_tm = alloc_var();
  *var_tm = args[0];
  Object params[1];
  Object *var_t2 = closure[0];
  Object self = *closure[1];
// Begin line 71
  setline(71);
// compilenode returning *var_tm
// Begin line 72
  setline(72);
// Begin line 262
  setline(262);
// Begin line 71
  setline(71);
// compilenode returning *var_t2
  Object call118 = callmethod(*var_t2, "methods",
    0, params);
// compilenode returning call118
// compilenode returning call118
  params[0] = *var_tm;
  Object call119 = callmethod(call118, "push",
    1, params);
// compilenode returning call119
  return call119;
}
Object meth_subtype_apply102(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[2];
  Object *var_inner = closure[0];
  Object *var_d = closure[1];
  Object *var_matrix = closure[2];
  Object *var_t = closure[3];
  Object self = *closure[4];
  Object *var_d2 = alloc_var();
  *var_d2 = undefined;
// Begin line 66
  setline(66);
// compilenode returning *var_t2
// Begin line 67
  setline(67);
// compilenode returning self
  params[0] = *var_t2;
  Object call103 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call103
  *var_d2 = call103;
  if (call103 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_d2
  Object bool104 = alloc_Boolean(1);
// compilenode returning bool104
// compilenode returning *var_inner
  params[0] = *var_d2;
  params[1] = bool104;
  Object call105 = callmethod(*var_inner, "put",
    2, params);
// compilenode returning call105
// Begin line 68
  setline(68);
// compilenode returning *var_d
  Object bool106 = alloc_Boolean(1);
// compilenode returning bool106
// compilenode returning *var_d2
// compilenode returning *var_matrix
  params[0] = *var_d2;
  Object call107 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call107
  params[0] = *var_d;
  params[1] = bool106;
  Object call108 = callmethod(call107, "put",
    2, params);
// compilenode returning call108
// Begin line 71
  setline(71);
// Begin line 74
  setline(74);
// Begin line 69
  setline(69);
// compilenode returning *var_d2
// compilenode returning *var_d
  params[0] = *var_d;
  Object opresult111 = callmethod(*var_d2, "==", 1, params);
// compilenode returning opresult111
  Object if109;
  if (istrue(opresult111)) {
// Begin line 71
  setline(71);
// Begin line 73
  setline(73);
// Begin line 262
  setline(262);
// Begin line 70
  setline(70);
// compilenode returning *var_t
  Object call113 = callmethod(*var_t, "methods",
    0, params);
// compilenode returning call113
// compilenode returning call113
// Begin line 71
  setline(71);
// Begin line 262
  setline(262);
  Object obj115 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj115, self, 0);
  addmethod2(obj115, "outer", &reader_subtype_outer_116);
  adddatum2(obj115, self, 0);
  block_savedest(obj115);
  Object **closure117 = createclosure(2);
  addtoclosure(closure117, var_t2);
  Object *selfpp120 = alloc_var();
  *selfpp120 = self;
  addtoclosure(closure117, selfpp120);
  struct UserObject *uo117 = (struct UserObject*)obj115;
  uo117->data[1] = (Object)closure117;
  addmethod2(obj115, "apply", &meth_subtype_apply117);
  set_type(obj115, 0);
// compilenode returning obj115
  setclassname(obj115, "Block<subtype:114>");
// compilenode returning obj115
  params[0] = call113;
  Object iter112 = callmethod(call113, "iter", 1, params);
  while(1) {
    Object cond112 = callmethod(iter112, "havemore", 0, NULL);
    if (!istrue(cond112)) break;
    params[0] = callmethod(iter112, "next", 0, NULL);
    callmethod(obj115, "apply", 1, params);
  }
// compilenode returning call113
    if109 = call113;
  } else {
  }
// compilenode returning if109
  return if109;
}
Object meth_subtype_resetType91(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[2];
  Object *var_matrix = closure[0];
  Object *var_HashMap = closure[1];
  Object *var_types = closure[2];
  Object *var_modified = closure[3];
  Object *var_d = alloc_var();
  *var_d = undefined;
  Object *var_inner = alloc_var();
  *var_inner = undefined;
// Begin line 60
  setline(60);
// compilenode returning *var_t
// Begin line 61
  setline(61);
// compilenode returning self
  params[0] = *var_t;
  Object call92 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call92
  *var_d = call92;
  if (call92 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 62
  setline(62);
// Begin line 61
  setline(61);
// Begin line 262
  setline(262);
// Begin line 61
  setline(61);
// compilenode returning *var_d
// compilenode returning *var_matrix
  params[0] = *var_d;
  Object call94 = callmethod(*var_matrix, "contains",
    1, params);
// compilenode returning call94
  Object call95 = callmethod(call94, "not",
    0, params);
// compilenode returning call95
// compilenode returning call95
  Object if93;
  if (istrue(call95)) {
// Begin line 62
  setline(62);
// compilenode returning *var_t
// Begin line 63
  setline(63);
// compilenode returning self
  params[0] = *var_t;
  Object call96 = callmethod(self, "addType",
    1, params);
// compilenode returning call96
  return call96;
// compilenode returning undefined
    if93 = undefined;
  } else {
  }
// compilenode returning if93
// Begin line 65
  setline(65);
// Begin line 262
  setline(262);
// Begin line 64
  setline(64);
// compilenode returning *var_HashMap
  Object call97 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call97
// compilenode returning call97
  *var_inner = call97;
  if (call97 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 71
  setline(71);
// Begin line 65
  setline(65);
// compilenode returning *var_types
// Begin line 71
  setline(71);
// Begin line 262
  setline(262);
  Object obj100 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj100, self, 0);
  addmethod2(obj100, "outer", &reader_subtype_outer_101);
  adddatum2(obj100, self, 0);
  block_savedest(obj100);
  Object **closure102 = createclosure(5);
  addtoclosure(closure102, var_inner);
  addtoclosure(closure102, var_d);
  addtoclosure(closure102, var_matrix);
  addtoclosure(closure102, var_t);
  Object *selfpp121 = alloc_var();
  *selfpp121 = self;
  addtoclosure(closure102, selfpp121);
  struct UserObject *uo102 = (struct UserObject*)obj100;
  uo102->data[1] = (Object)closure102;
  addmethod2(obj100, "apply", &meth_subtype_apply102);
  set_type(obj100, 0);
// compilenode returning obj100
  setclassname(obj100, "Block<subtype:99>");
// compilenode returning obj100
  params[0] = *var_types;
  Object iter98 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond98 = callmethod(iter98, "havemore", 0, NULL);
    if (!istrue(cond98)) break;
    params[0] = callmethod(iter98, "next", 0, NULL);
    callmethod(obj100, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 75
  setline(75);
// Begin line 262
  setline(262);
// Begin line 75
  setline(75);
// compilenode returning *var_t
  Object call122 = callmethod(*var_t, "value",
    0, params);
// compilenode returning call122
// compilenode returning call122
// compilenode returning *var_inner
// compilenode returning *var_matrix
  params[0] = call122;
  params[1] = *var_inner;
  Object call123 = callmethod(*var_matrix, "put",
    2, params);
// compilenode returning call123
// Begin line 77
  setline(77);
// Begin line 76
  setline(76);
  Object bool124 = alloc_Boolean(1);
// compilenode returning bool124
  *var_modified = bool124;
  if (bool124 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 77
  setline(77);
  Object bool126 = alloc_Boolean(1);
// compilenode returning bool126
  return bool126;
}
Object meth_subtype_typeId127(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_DynamicType = closure[0];
  Object *var_typesToId = closure[1];
// Begin line 82
  setline(82);
// Begin line 84
  setline(84);
// Begin line 81
  setline(81);
// compilenode returning *var_t
  Object bool129 = alloc_Boolean(0);
// compilenode returning bool129
  params[0] = bool129;
  Object opresult131 = callmethod(*var_t, "==", 1, params);
// compilenode returning opresult131
  Object if128;
  if (istrue(opresult131)) {
// Begin line 82
  setline(82);
// compilenode returning *var_DynamicType
// Begin line 83
  setline(83);
// compilenode returning self
  params[0] = *var_DynamicType;
  Object call132 = callmethod(self, "typeId",
    1, params);
// compilenode returning call132
  return call132;
// compilenode returning undefined
    if128 = undefined;
  } else {
  }
// compilenode returning if128
// Begin line 84
  setline(84);
// compilenode returning *var_t
// compilenode returning self
  params[0] = *var_t;
  Object call133 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call133
// compilenode returning *var_typesToId
  params[0] = call133;
  Object call134 = callmethod(*var_typesToId, "get",
    1, params);
// compilenode returning call134
  return call134;
}
Object meth_subtype_apply151(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[1];
  Object *var_row = closure[0];
  Object *var_inner = closure[1];
  Object self = *closure[2];
// Begin line 96
  setline(96);
// compilenode returning *var_t2
// compilenode returning self
  params[0] = *var_t2;
  Object call152 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call152
// compilenode returning *var_row
  params[0] = call152;
  Object call153 = callmethod(*var_row, "get",
    1, params);
// compilenode returning call153
// compilenode returning *var_inner
  params[0] = call153;
  Object call154 = callmethod(*var_inner, "push",
    1, params);
// compilenode returning call154
  return call154;
}
Object meth_subtype_apply143(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_matrix = closure[0];
  Object *var_types = closure[1];
  Object *var_mtrx = closure[2];
  Object self = *closure[3];
  Object *var_row = alloc_var();
  *var_row = undefined;
  Object *var_inner = alloc_var();
  *var_inner = undefined;
// Begin line 93
  setline(93);
// compilenode returning *var_t
// compilenode returning self
  params[0] = *var_t;
  Object call144 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call144
// compilenode returning *var_matrix
  params[0] = call144;
  Object call145 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call145
  *var_row = call145;
  if (call145 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 95
  setline(95);
  Object array146 = alloc_List();
// compilenode returning array146
  *var_inner = array146;
  if (array146 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 96
  setline(96);
// Begin line 95
  setline(95);
// compilenode returning *var_types
// Begin line 96
  setline(96);
// Begin line 262
  setline(262);
  Object obj149 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj149, self, 0);
  addmethod2(obj149, "outer", &reader_subtype_outer_150);
  adddatum2(obj149, self, 0);
  block_savedest(obj149);
  Object **closure151 = createclosure(3);
  addtoclosure(closure151, var_row);
  addtoclosure(closure151, var_inner);
  Object *selfpp155 = alloc_var();
  *selfpp155 = self;
  addtoclosure(closure151, selfpp155);
  struct UserObject *uo151 = (struct UserObject*)obj149;
  uo151->data[1] = (Object)closure151;
  addmethod2(obj149, "apply", &meth_subtype_apply151);
  set_type(obj149, 0);
// compilenode returning obj149
  setclassname(obj149, "Block<subtype:148>");
// compilenode returning obj149
  params[0] = *var_types;
  Object iter147 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond147 = callmethod(iter147, "havemore", 0, NULL);
    if (!istrue(cond147)) break;
    params[0] = callmethod(iter147, "next", 0, NULL);
    callmethod(obj149, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 98
  setline(98);
// compilenode returning *var_inner
// compilenode returning *var_mtrx
  params[0] = *var_inner;
  Object call156 = callmethod(*var_mtrx, "push",
    1, params);
// compilenode returning call156
  return call156;
}
Object meth_subtype_boolMatrix135(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object params[1];
  Object *var_modified = closure[0];
  Object *var_types = closure[1];
  Object *var_matrix = closure[2];
  Object *var_mtrx = alloc_var();
  *var_mtrx = undefined;
// Begin line 89
  setline(89);
// Begin line 88
  setline(88);
// compilenode returning *var_modified
  Object if136;
  if (istrue(*var_modified)) {
// Begin line 89
  setline(89);
// compilenode returning self
  Object call137 = callmethod(self, "findSubtypes",
    0, params);
// compilenode returning call137
    if136 = call137;
  } else {
  }
// compilenode returning if136
// Begin line 92
  setline(92);
  Object array138 = alloc_List();
// compilenode returning array138
  *var_mtrx = array138;
  if (array138 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 98
  setline(98);
// Begin line 92
  setline(92);
// compilenode returning *var_types
// Begin line 98
  setline(98);
// Begin line 262
  setline(262);
  Object obj141 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj141, self, 0);
  addmethod2(obj141, "outer", &reader_subtype_outer_142);
  adddatum2(obj141, self, 0);
  block_savedest(obj141);
  Object **closure143 = createclosure(4);
  addtoclosure(closure143, var_matrix);
  addtoclosure(closure143, var_types);
  addtoclosure(closure143, var_mtrx);
  Object *selfpp157 = alloc_var();
  *selfpp157 = self;
  addtoclosure(closure143, selfpp157);
  struct UserObject *uo143 = (struct UserObject*)obj141;
  uo143->data[1] = (Object)closure143;
  addmethod2(obj141, "apply", &meth_subtype_apply143);
  set_type(obj141, 0);
// compilenode returning obj141
  setclassname(obj141, "Block<subtype:140>");
// compilenode returning obj141
  params[0] = *var_types;
  Object iter139 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond139 = callmethod(iter139, "havemore", 0, NULL);
    if (!istrue(cond139)) break;
    params[0] = callmethod(iter139, "next", 0, NULL);
    callmethod(obj141, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 100
  setline(100);
// compilenode returning *var_mtrx
  return *var_mtrx;
}
Object meth_subtype_apply173(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[1];
  Object *var_row = closure[0];
  Object *var_st = closure[1];
  Object self = *closure[2];
  Object *var_d2 = alloc_var();
  *var_d2 = undefined;
// Begin line 112
  setline(112);
// compilenode returning *var_t2
// Begin line 113
  setline(113);
// compilenode returning self
  params[0] = *var_t2;
  Object call174 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call174
  *var_d2 = call174;
  if (call174 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 115
  setline(115);
// Begin line 113
  setline(113);
// compilenode returning *var_d2
// compilenode returning *var_row
  params[0] = *var_d2;
  Object call176 = callmethod(*var_row, "get",
    1, params);
// compilenode returning call176
  Object if175;
  if (istrue(call176)) {
// Begin line 115
  setline(115);
// Begin line 114
  setline(114);
  if (strlit177 == NULL) {
    strlit177 = alloc_String("");
  }
// compilenode returning strlit177
// compilenode returning *var_st
  params[0] = *var_st;
  Object opresult179 = callmethod(strlit177, "++", 1, params);
// compilenode returning opresult179
  if (strlit180 == NULL) {
    strlit180 = alloc_String(" ");
  }
// compilenode returning strlit180
  params[0] = strlit180;
  Object opresult182 = callmethod(opresult179, "++", 1, params);
// compilenode returning opresult182
// compilenode returning *var_d2
  params[0] = *var_d2;
  Object opresult184 = callmethod(opresult182, "++", 1, params);
// compilenode returning opresult184
  if (strlit185 == NULL) {
    strlit185 = alloc_String("");
  }
// compilenode returning strlit185
  params[0] = strlit185;
  Object opresult187 = callmethod(opresult184, "++", 1, params);
// compilenode returning opresult187
  *var_st = opresult187;
  if (opresult187 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if175 = nothing;
  } else {
  }
// compilenode returning if175
  return if175;
}
Object meth_subtype_apply165(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_matrix = closure[0];
  Object *var_types = closure[1];
  Object self = *closure[2];
  Object *var_d = alloc_var();
  *var_d = undefined;
  Object *var_row = alloc_var();
  *var_row = undefined;
  Object *var_st = alloc_var();
  *var_st = undefined;
// Begin line 108
  setline(108);
// compilenode returning *var_t
// Begin line 109
  setline(109);
// compilenode returning self
  params[0] = *var_t;
  Object call166 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call166
  *var_d = call166;
  if (call166 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_d
// compilenode returning *var_matrix
  params[0] = *var_d;
  Object call167 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call167
  *var_row = call167;
  if (call167 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 111
  setline(111);
// Begin line 110
  setline(110);
  if (strlit168 == NULL) {
    strlit168 = alloc_String("");
  }
// compilenode returning strlit168
  var_st = alloc_var();
  *var_st = strlit168;
  if (strlit168 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 115
  setline(115);
// Begin line 111
  setline(111);
// compilenode returning *var_types
// Begin line 115
  setline(115);
// Begin line 262
  setline(262);
  Object obj171 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj171, self, 0);
  addmethod2(obj171, "outer", &reader_subtype_outer_172);
  adddatum2(obj171, self, 0);
  block_savedest(obj171);
  Object **closure173 = createclosure(3);
  addtoclosure(closure173, var_row);
  addtoclosure(closure173, var_st);
  Object *selfpp189 = alloc_var();
  *selfpp189 = self;
  addtoclosure(closure173, selfpp189);
  struct UserObject *uo173 = (struct UserObject*)obj171;
  uo173->data[1] = (Object)closure173;
  addmethod2(obj171, "apply", &meth_subtype_apply173);
  set_type(obj171, 0);
// compilenode returning obj171
  setclassname(obj171, "Block<subtype:170>");
// compilenode returning obj171
  params[0] = *var_types;
  Object iter169 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond169 = callmethod(iter169, "havemore", 0, NULL);
    if (!istrue(cond169)) break;
    params[0] = callmethod(iter169, "next", 0, NULL);
    callmethod(obj171, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 117
  setline(117);
  if (strlit190 == NULL) {
    strlit190 = alloc_String("");
  }
// compilenode returning strlit190
// compilenode returning *var_d
  params[0] = *var_d;
  Object opresult192 = callmethod(strlit190, "++", 1, params);
// compilenode returning opresult192
  if (strlit193 == NULL) {
    strlit193 = alloc_String(" is a subtype of:");
  }
// compilenode returning strlit193
  params[0] = strlit193;
  Object opresult195 = callmethod(opresult192, "++", 1, params);
// compilenode returning opresult195
// compilenode returning *var_st
  params[0] = *var_st;
  Object opresult197 = callmethod(opresult195, "++", 1, params);
// compilenode returning opresult197
  if (strlit198 == NULL) {
    strlit198 = alloc_String("");
  }
// compilenode returning strlit198
  params[0] = strlit198;
  Object opresult200 = callmethod(opresult197, "++", 1, params);
// compilenode returning opresult200
  params[0] = opresult200;
  Object call201 = gracelib_print(NULL, 1,  params);
// compilenode returning call201
  return call201;
}
Object meth_subtype_printMatrix158(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object params[1];
  Object *var_modified = closure[0];
  Object *var_types = closure[1];
  Object *var_matrix = closure[2];
// Begin line 105
  setline(105);
// Begin line 104
  setline(104);
// compilenode returning *var_modified
  Object if159;
  if (istrue(*var_modified)) {
// Begin line 105
  setline(105);
// compilenode returning self
  Object call160 = callmethod(self, "findSubtypes",
    0, params);
// compilenode returning call160
    if159 = call160;
  } else {
  }
// compilenode returning if159
// Begin line 117
  setline(117);
// Begin line 107
  setline(107);
// compilenode returning *var_types
// Begin line 117
  setline(117);
// Begin line 262
  setline(262);
  Object obj163 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj163, self, 0);
  addmethod2(obj163, "outer", &reader_subtype_outer_164);
  adddatum2(obj163, self, 0);
  block_savedest(obj163);
  Object **closure165 = createclosure(3);
  addtoclosure(closure165, var_matrix);
  addtoclosure(closure165, var_types);
  Object *selfpp202 = alloc_var();
  *selfpp202 = self;
  addtoclosure(closure165, selfpp202);
  struct UserObject *uo165 = (struct UserObject*)obj163;
  uo165->data[1] = (Object)closure165;
  addmethod2(obj163, "apply", &meth_subtype_apply165);
  set_type(obj163, 0);
// compilenode returning obj163
  setclassname(obj163, "Block<subtype:162>");
// compilenode returning obj163
  params[0] = *var_types;
  Object iter161 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond161 = callmethod(iter161, "havemore", 0, NULL);
    if (!istrue(cond161)) break;
    params[0] = callmethod(iter161, "next", 0, NULL);
    callmethod(obj163, "apply", 1, params);
  }
// compilenode returning *var_types
  return *var_types;
}
Object meth_subtype_apply217(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_typeid = closure[0];
  Object self = *closure[1];
// Begin line 130
  setline(130);
// Begin line 128
  setline(128);
// compilenode returning *var_t
// Begin line 131
  setline(131);
// compilenode returning self
  params[0] = *var_t;
  Object call219 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call219
// Begin line 128
  setline(128);
// Begin line 262
  setline(262);
// Begin line 128
  setline(128);
// compilenode returning *var_typeid
  Object call220 = callmethod(*var_typeid, "value",
    0, params);
// compilenode returning call220
// compilenode returning call220
  params[0] = call220;
  Object opresult222 = callmethod(call219, "==", 1, params);
// compilenode returning opresult222
  Object if218;
  if (istrue(opresult222)) {
// Begin line 130
  setline(130);
// Begin line 129
  setline(129);
// compilenode returning *var_t
  block_return(realself, *var_t);
// compilenode returning undefined
    if218 = undefined;
  } else {
  }
// compilenode returning if218
  return if218;
}
Object meth_subtype_findType203(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_typeid = alloc_var();
  *var_typeid = args[0];
  Object params[1];
  Object *var_DynamicType = closure[0];
  Object *var_types = closure[1];
// Begin line 123
  setline(123);
// Begin line 124
  setline(124);
// Begin line 121
  setline(121);
// compilenode returning *var_typeid
  Object bool205 = alloc_Boolean(0);
// compilenode returning bool205
  params[0] = bool205;
  Object opresult207 = callmethod(*var_typeid, "==", 1, params);
// compilenode returning opresult207
  Object if204;
  if (istrue(opresult207)) {
// Begin line 123
  setline(123);
// Begin line 122
  setline(122);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if204 = undefined;
  } else {
  }
// compilenode returning if204
// Begin line 126
  setline(126);
// Begin line 127
  setline(127);
// Begin line 262
  setline(262);
// Begin line 124
  setline(124);
// compilenode returning *var_typeid
  Object call209 = callmethod(*var_typeid, "kind",
    0, params);
// compilenode returning call209
// compilenode returning call209
  if (strlit210 == NULL) {
    strlit210 = alloc_String("type");
  }
// compilenode returning strlit210
  params[0] = strlit210;
  Object opresult212 = callmethod(call209, "==", 1, params);
// compilenode returning opresult212
  Object if208;
  if (istrue(opresult212)) {
// Begin line 126
  setline(126);
// Begin line 125
  setline(125);
// compilenode returning *var_typeid
  return *var_typeid;
// compilenode returning undefined
    if208 = undefined;
  } else {
  }
// compilenode returning if208
// Begin line 130
  setline(130);
// Begin line 127
  setline(127);
// compilenode returning *var_types
// Begin line 130
  setline(130);
// Begin line 262
  setline(262);
  Object obj215 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj215, self, 0);
  addmethod2(obj215, "outer", &reader_subtype_outer_216);
  adddatum2(obj215, self, 0);
  block_savedest(obj215);
  Object **closure217 = createclosure(2);
  addtoclosure(closure217, var_typeid);
  Object *selfpp223 = alloc_var();
  *selfpp223 = self;
  addtoclosure(closure217, selfpp223);
  struct UserObject *uo217 = (struct UserObject*)obj215;
  uo217->data[1] = (Object)closure217;
  addmethod2(obj215, "apply", &meth_subtype_apply217);
  set_type(obj215, 0);
// compilenode returning obj215
  setclassname(obj215, "Block<subtype:214>");
// compilenode returning obj215
  params[0] = *var_types;
  Object iter213 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond213 = callmethod(iter213, "havemore", 0, NULL);
    if (!istrue(cond213)) break;
    params[0] = callmethod(iter213, "next", 0, NULL);
    callmethod(obj215, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 132
  setline(132);
  Object bool224 = alloc_Boolean(0);
// compilenode returning bool224
  return bool224;
}
Object meth_subtype_simpleCheckThat_40_1_41_mayBeSubtypeOf225(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_a = alloc_var();
  *var_a = args[0];
  Object *var_b = alloc_var();
  *var_b = args[1];
  Object params[1];
  Object *var_matrix = closure[0];
// Begin line 138
  setline(138);
// Begin line 139
  setline(139);
// Begin line 136
  setline(136);
// compilenode returning *var_a
  Object bool227 = alloc_Boolean(0);
// compilenode returning bool227
  params[0] = bool227;
  Object opresult229 = callmethod(*var_a, "==", 1, params);
// compilenode returning opresult229
// Begin line 139
  setline(139);
// Begin line 136
  setline(136);
// compilenode returning *var_b
  Object bool230 = alloc_Boolean(0);
// compilenode returning bool230
  params[0] = bool230;
  Object opresult232 = callmethod(*var_b, "==", 1, params);
// compilenode returning opresult232
  params[0] = opresult232;
  Object opresult234 = callmethod(opresult229, "|", 1, params);
// compilenode returning opresult234
  Object if226;
  if (istrue(opresult234)) {
// Begin line 138
  setline(138);
// Begin line 137
  setline(137);
  Object bool235 = alloc_Boolean(1);
// compilenode returning bool235
  return bool235;
// compilenode returning undefined
    if226 = undefined;
  } else {
  }
// compilenode returning if226
// Begin line 139
  setline(139);
// compilenode returning *var_b
// compilenode returning self
  params[0] = *var_b;
  Object call236 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call236
// compilenode returning *var_a
// compilenode returning self
  params[0] = *var_a;
  Object call237 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call237
// compilenode returning *var_matrix
  params[0] = call237;
  Object call238 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call238
  params[0] = call236;
  Object call239 = callmethod(call238, "get",
    1, params);
// compilenode returning call239
  return call239;
}
Object meth_subtype_apply278(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[2];
  Object *var_b = closure[0];
  Object self = *closure[1];
// Begin line 160
  setline(160);
// Begin line 158
  setline(158);
// Begin line 262
  setline(262);
// Begin line 158
  setline(158);
// compilenode returning *var_ut
// compilenode returning self
  params[0] = *var_ut;
  Object call280 = callmethod(self, "findType",
    1, params);
// compilenode returning call280
// compilenode returning *var_b
// Begin line 161
  setline(161);
// compilenode returning self
  params[0] = call280;
  params[1] = *var_b;
  Object call281 = callmethod(self, "checkThat(1)mayBeSubtypeOf",
    2, params);
// compilenode returning call281
  Object call282 = callmethod(call281, "not",
    0, params);
// compilenode returning call282
// compilenode returning call282
  Object if279;
  if (istrue(call282)) {
// Begin line 160
  setline(160);
// Begin line 159
  setline(159);
  Object bool283 = alloc_Boolean(0);
// compilenode returning bool283
  block_return(realself, bool283);
// compilenode returning undefined
    if279 = undefined;
  } else {
  }
// compilenode returning if279
  return if279;
}
Object meth_subtype_apply297(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[2];
  Object *var_a = closure[0];
  Object self = *closure[1];
// Begin line 168
  setline(168);
// Begin line 166
  setline(166);
// compilenode returning *var_a
// compilenode returning *var_ut
// compilenode returning self
  params[0] = *var_ut;
  Object call299 = callmethod(self, "findType",
    1, params);
// compilenode returning call299
// Begin line 169
  setline(169);
// compilenode returning self
  params[0] = *var_a;
  params[1] = call299;
  Object call300 = callmethod(self, "checkThat(1)mayBeSubtypeOf",
    2, params);
// compilenode returning call300
  Object if298;
  if (istrue(call300)) {
// Begin line 168
  setline(168);
// Begin line 167
  setline(167);
  Object bool301 = alloc_Boolean(1);
// compilenode returning bool301
  block_return(realself, bool301);
// compilenode returning undefined
    if298 = undefined;
  } else {
  }
// compilenode returning if298
  return if298;
}
Object meth_subtype_apply366(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[2];
  Object *var_am = closure[0];
  Object *var_bm = closure[1];
  Object self = *closure[2];
  Object *var_ap = alloc_var();
  *var_ap = undefined;
  Object *var_bp = alloc_var();
  *var_bp = undefined;
// Begin line 191
  setline(191);
// compilenode returning *var_i
// Begin line 192
  setline(192);
// Begin line 262
  setline(262);
// Begin line 191
  setline(191);
// compilenode returning *var_am
  Object call367 = callmethod(*var_am, "params",
    0, params);
// compilenode returning call367
// compilenode returning call367
  params[0] = *var_i;
  Object call368 = callmethod(call367, "at",
    1, params);
// compilenode returning call368
  *var_ap = call368;
  if (call368 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 192
  setline(192);
// compilenode returning *var_i
// Begin line 193
  setline(193);
// Begin line 262
  setline(262);
// Begin line 192
  setline(192);
// compilenode returning *var_bm
  Object call369 = callmethod(*var_bm, "params",
    0, params);
// compilenode returning call369
// compilenode returning call369
  params[0] = *var_i;
  Object call370 = callmethod(call369, "at",
    1, params);
// compilenode returning call370
  *var_bp = call370;
  if (call370 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 195
  setline(195);
// Begin line 193
  setline(193);
// Begin line 262
  setline(262);
// Begin line 193
  setline(193);
// Begin line 262
  setline(262);
// Begin line 193
  setline(193);
// compilenode returning *var_bp
  Object call372 = callmethod(*var_bp, "dtype",
    0, params);
// compilenode returning call372
// compilenode returning call372
// compilenode returning self
  params[0] = call372;
  Object call373 = callmethod(self, "findType",
    1, params);
// compilenode returning call373
// Begin line 262
  setline(262);
// Begin line 193
  setline(193);
// compilenode returning *var_ap
  Object call374 = callmethod(*var_ap, "dtype",
    0, params);
// compilenode returning call374
// compilenode returning call374
// compilenode returning self
  params[0] = call374;
  Object call375 = callmethod(self, "findType",
    1, params);
// compilenode returning call375
// Begin line 196
  setline(196);
// compilenode returning self
  params[0] = call373;
  params[1] = call375;
  Object call376 = callmethod(self, "simpleCheckThat(1)mayBeSubtypeOf",
    2, params);
// compilenode returning call376
  Object call377 = callmethod(call376, "not",
    0, params);
// compilenode returning call377
// compilenode returning call377
  Object if371;
  if (istrue(call377)) {
// Begin line 195
  setline(195);
// Begin line 194
  setline(194);
  Object bool378 = alloc_Boolean(0);
// compilenode returning bool378
  block_return(realself, bool378);
// compilenode returning undefined
    if371 = undefined;
  } else {
  }
// compilenode returning if371
  return if371;
}
Object meth_subtype_apply324(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_am = alloc_var();
  *var_am = args[0];
  Object params[2];
  Object *var_bm = closure[0];
  Object *var_found = closure[1];
  Object self = *closure[2];
// Begin line 195
  setline(195);
// Begin line 199
  setline(199);
// Begin line 262
  setline(262);
// Begin line 178
  setline(178);
// compilenode returning *var_am
  Object call326 = callmethod(*var_am, "value",
    0, params);
// compilenode returning call326
// compilenode returning call326
// Begin line 199
  setline(199);
// Begin line 262
  setline(262);
// Begin line 178
  setline(178);
// compilenode returning *var_bm
  Object call327 = callmethod(*var_bm, "value",
    0, params);
// compilenode returning call327
// compilenode returning call327
  params[0] = call327;
  Object opresult329 = callmethod(call326, "==", 1, params);
// compilenode returning opresult329
  Object if325;
  if (istrue(opresult329)) {
// Begin line 180
  setline(180);
// Begin line 179
  setline(179);
  Object bool330 = alloc_Boolean(1);
// compilenode returning bool330
  *var_found = bool330;
  if (bool330 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 182
  setline(182);
// Begin line 180
  setline(180);
// Begin line 262
  setline(262);
// Begin line 180
  setline(180);
// Begin line 262
  setline(262);
// Begin line 180
  setline(180);
// compilenode returning *var_am
  Object call333 = callmethod(*var_am, "rtype",
    0, params);
// compilenode returning call333
// compilenode returning call333
// compilenode returning self
  params[0] = call333;
  Object call334 = callmethod(self, "findType",
    1, params);
// compilenode returning call334
// Begin line 262
  setline(262);
// Begin line 180
  setline(180);
// compilenode returning *var_bm
  Object call335 = callmethod(*var_bm, "rtype",
    0, params);
// compilenode returning call335
// compilenode returning call335
// compilenode returning self
  params[0] = call335;
  Object call336 = callmethod(self, "findType",
    1, params);
// compilenode returning call336
// Begin line 183
  setline(183);
// compilenode returning self
  params[0] = call334;
  params[1] = call336;
  Object call337 = callmethod(self, "simpleCheckThat(1)mayBeSubtypeOf",
    2, params);
// compilenode returning call337
  Object call338 = callmethod(call337, "not",
    0, params);
// compilenode returning call338
// compilenode returning call338
  Object if332;
  if (istrue(call338)) {
// Begin line 182
  setline(182);
// Begin line 181
  setline(181);
  Object bool339 = alloc_Boolean(0);
// compilenode returning bool339
  block_return(realself, bool339);
// compilenode returning undefined
    if332 = undefined;
  } else {
  }
// compilenode returning if332
// Begin line 185
  setline(185);
// Begin line 186
  setline(186);
// Begin line 262
  setline(262);
// Begin line 186
  setline(186);
// Begin line 262
  setline(262);
// Begin line 183
  setline(183);
// compilenode returning *var_am
  Object call341 = callmethod(*var_am, "params",
    0, params);
// compilenode returning call341
// compilenode returning call341
  Object call342 = callmethod(call341, "size",
    0, params);
// compilenode returning call342
// compilenode returning call342
// Begin line 186
  setline(186);
// Begin line 262
  setline(262);
// Begin line 186
  setline(186);
// Begin line 262
  setline(262);
// Begin line 183
  setline(183);
// compilenode returning *var_bm
  Object call343 = callmethod(*var_bm, "params",
    0, params);
// compilenode returning call343
// compilenode returning call343
  Object call344 = callmethod(call343, "size",
    0, params);
// compilenode returning call344
// compilenode returning call344
  params[0] = call344;
  Object opresult346 = callmethod(call342, "/=", 1, params);
// compilenode returning opresult346
  Object if340;
  if (istrue(opresult346)) {
// Begin line 185
  setline(185);
// Begin line 184
  setline(184);
  Object bool347 = alloc_Boolean(0);
// compilenode returning bool347
  block_return(realself, bool347);
// compilenode returning undefined
    if340 = undefined;
  } else {
  }
// compilenode returning if340
// Begin line 195
  setline(195);
// Begin line 198
  setline(198);
// Begin line 262
  setline(262);
// Begin line 198
  setline(198);
// Begin line 262
  setline(262);
// Begin line 186
  setline(186);
// compilenode returning *var_am
  Object call349 = callmethod(*var_am, "params",
    0, params);
// compilenode returning call349
// compilenode returning call349
  Object call350 = callmethod(call349, "size",
    0, params);
// compilenode returning call350
// compilenode returning call350
  Object num351 = alloc_Float64(0.0);
// compilenode returning num351
  params[0] = num351;
  Object opresult353 = callmethod(call350, ">", 1, params);
// compilenode returning opresult353
  Object if348;
  if (istrue(opresult353)) {
  Object *var_mini = alloc_var();
  *var_mini = undefined;
  Object *var_maxi = alloc_var();
  *var_maxi = undefined;
  Object *var_range = alloc_var();
  *var_range = undefined;
// Begin line 188
  setline(188);
// Begin line 262
  setline(262);
// Begin line 188
  setline(188);
// Begin line 262
  setline(262);
// Begin line 188
  setline(188);
// Begin line 262
  setline(262);
// Begin line 187
  setline(187);
// compilenode returning *var_am
  Object call354 = callmethod(*var_am, "params",
    0, params);
// compilenode returning call354
// compilenode returning call354
  Object call355 = callmethod(call354, "indices",
    0, params);
// compilenode returning call355
// compilenode returning call355
  Object call356 = callmethod(call355, "first",
    0, params);
// compilenode returning call356
// compilenode returning call356
  *var_mini = call356;
  if (call356 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 189
  setline(189);
// Begin line 262
  setline(262);
// Begin line 189
  setline(189);
// Begin line 262
  setline(262);
// Begin line 189
  setline(189);
// Begin line 262
  setline(262);
// Begin line 188
  setline(188);
// compilenode returning *var_am
  Object call357 = callmethod(*var_am, "params",
    0, params);
// compilenode returning call357
// compilenode returning call357
  Object call358 = callmethod(call357, "indices",
    0, params);
// compilenode returning call358
// compilenode returning call358
  Object call359 = callmethod(call358, "last",
    0, params);
// compilenode returning call359
// compilenode returning call359
  *var_maxi = call359;
  if (call359 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 190
  setline(190);
// Begin line 189
  setline(189);
// compilenode returning *var_mini
// compilenode returning *var_maxi
  params[0] = *var_maxi;
  Object opresult361 = callmethod(*var_mini, "..", 1, params);
// compilenode returning opresult361
  *var_range = opresult361;
  if (opresult361 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 195
  setline(195);
// Begin line 190
  setline(190);
// compilenode returning *var_range
// Begin line 195
  setline(195);
// Begin line 262
  setline(262);
  Object obj364 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj364, self, 0);
  addmethod2(obj364, "outer", &reader_subtype_outer_365);
  adddatum2(obj364, self, 0);
  block_savedest(obj364);
  Object **closure366 = createclosure(3);
  addtoclosure(closure366, var_am);
  addtoclosure(closure366, var_bm);
  Object *selfpp379 = alloc_var();
  *selfpp379 = self;
  addtoclosure(closure366, selfpp379);
  struct UserObject *uo366 = (struct UserObject*)obj364;
  uo366->data[1] = (Object)closure366;
  addmethod2(obj364, "apply", &meth_subtype_apply366);
  set_type(obj364, 0);
// compilenode returning obj364
  setclassname(obj364, "Block<subtype:363>");
// compilenode returning obj364
  params[0] = *var_range;
  Object iter362 = callmethod(*var_range, "iter", 1, params);
  while(1) {
    Object cond362 = callmethod(iter362, "havemore", 0, NULL);
    if (!istrue(cond362)) break;
    params[0] = callmethod(iter362, "next", 0, NULL);
    callmethod(obj364, "apply", 1, params);
  }
// compilenode returning *var_range
    if348 = *var_range;
  } else {
  }
// compilenode returning if348
    if325 = if348;
  } else {
  }
// compilenode returning if325
  return if325;
}
Object meth_subtype_apply317(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_bm = alloc_var();
  *var_bm = args[0];
  Object params[1];
  Object *var_a = closure[0];
  Object self = *closure[1];
  Object *var_found = alloc_var();
  *var_found = undefined;
// Begin line 177
  setline(177);
// Begin line 176
  setline(176);
  Object bool318 = alloc_Boolean(0);
// compilenode returning bool318
  var_found = alloc_var();
  *var_found = bool318;
  if (bool318 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 195
  setline(195);
// Begin line 200
  setline(200);
// Begin line 262
  setline(262);
// Begin line 177
  setline(177);
// compilenode returning *var_a
  Object call320 = callmethod(*var_a, "methods",
    0, params);
// compilenode returning call320
// compilenode returning call320
// Begin line 195
  setline(195);
// Begin line 262
  setline(262);
  Object obj322 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj322, self, 0);
  addmethod2(obj322, "outer", &reader_subtype_outer_323);
  adddatum2(obj322, self, 0);
  block_savedest(obj322);
  Object **closure324 = createclosure(3);
  addtoclosure(closure324, var_bm);
  addtoclosure(closure324, var_found);
  Object *selfpp380 = alloc_var();
  *selfpp380 = self;
  addtoclosure(closure324, selfpp380);
  struct UserObject *uo324 = (struct UserObject*)obj322;
  uo324->data[1] = (Object)closure324;
  addmethod2(obj322, "apply", &meth_subtype_apply324);
  set_type(obj322, 0);
// compilenode returning obj322
  setclassname(obj322, "Block<subtype:321>");
// compilenode returning obj322
  params[0] = call320;
  Object iter319 = callmethod(call320, "iter", 1, params);
  while(1) {
    Object cond319 = callmethod(iter319, "havemore", 0, NULL);
    if (!istrue(cond319)) break;
    params[0] = callmethod(iter319, "next", 0, NULL);
    callmethod(obj322, "apply", 1, params);
  }
// compilenode returning call320
// Begin line 202
  setline(202);
// Begin line 203
  setline(203);
// Begin line 200
  setline(200);
// compilenode returning *var_found
  Object call382 = callmethod(*var_found, "prefix!",
    0, params);
// compilenode returning call382
  Object if381;
  if (istrue(call382)) {
// Begin line 202
  setline(202);
// Begin line 201
  setline(201);
  Object bool383 = alloc_Boolean(0);
// compilenode returning bool383
  block_return(realself, bool383);
// compilenode returning undefined
    if381 = undefined;
  } else {
  }
// compilenode returning if381
  return if381;
}
Object meth_subtype_checkThat_40_1_41_mayBeSubtypeOf240(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_a = alloc_var();
  *var_a = args[0];
  Object *var_b = alloc_var();
  *var_b = args[1];
  Object params[1];
  Object *var_matrix = closure[0];
  Object *var_at = alloc_var();
  *var_at = undefined;
  Object *var_bt = alloc_var();
  *var_bt = undefined;
// Begin line 144
  setline(144);
// Begin line 145
  setline(145);
// Begin line 262
  setline(262);
// Begin line 142
  setline(142);
// compilenode returning *var_a
  Object call242 = callmethod(*var_a, "value",
    0, params);
// compilenode returning call242
// compilenode returning call242
  if (strlit243 == NULL) {
    strlit243 = alloc_String("Dynamic");
  }
// compilenode returning strlit243
  params[0] = strlit243;
  Object opresult245 = callmethod(call242, "==", 1, params);
// compilenode returning opresult245
  Object if241;
  if (istrue(opresult245)) {
// Begin line 144
  setline(144);
// Begin line 143
  setline(143);
  Object bool246 = alloc_Boolean(1);
// compilenode returning bool246
  return bool246;
// compilenode returning undefined
    if241 = undefined;
  } else {
  }
// compilenode returning if241
// Begin line 147
  setline(147);
// Begin line 148
  setline(148);
// Begin line 262
  setline(262);
// Begin line 145
  setline(145);
// compilenode returning *var_b
  Object call248 = callmethod(*var_b, "value",
    0, params);
// compilenode returning call248
// compilenode returning call248
  if (strlit249 == NULL) {
    strlit249 = alloc_String("Dynamic");
  }
// compilenode returning strlit249
  params[0] = strlit249;
  Object opresult251 = callmethod(call248, "==", 1, params);
// compilenode returning opresult251
  Object if247;
  if (istrue(opresult251)) {
// Begin line 147
  setline(147);
// Begin line 146
  setline(146);
  Object bool252 = alloc_Boolean(1);
// compilenode returning bool252
  return bool252;
// compilenode returning undefined
    if247 = undefined;
  } else {
  }
// compilenode returning if247
// Begin line 148
  setline(148);
// compilenode returning *var_a
// Begin line 149
  setline(149);
// compilenode returning self
  params[0] = *var_a;
  Object call253 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call253
  *var_at = call253;
  if (call253 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_b
// Begin line 150
  setline(150);
// compilenode returning self
  params[0] = *var_b;
  Object call254 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call254
  *var_bt = call254;
  if (call254 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 152
  setline(152);
// Begin line 150
  setline(150);
// Begin line 262
  setline(262);
// Begin line 150
  setline(150);
// compilenode returning *var_bt
// compilenode returning *var_at
// compilenode returning *var_matrix
  params[0] = *var_at;
  Object call256 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call256
  params[0] = *var_bt;
  Object call257 = callmethod(call256, "get",
    1, params);
// compilenode returning call257
  Object call258 = callmethod(call257, "not",
    0, params);
// compilenode returning call258
// compilenode returning call258
  Object if255;
  if (istrue(call258)) {
// Begin line 152
  setline(152);
// Begin line 151
  setline(151);
  Object bool259 = alloc_Boolean(0);
// compilenode returning bool259
  return bool259;
// compilenode returning undefined
    if255 = undefined;
  } else {
  }
// compilenode returning if255
// Begin line 155
  setline(155);
// Begin line 156
  setline(156);
// Begin line 262
  setline(262);
// Begin line 153
  setline(153);
// compilenode returning *var_a
  Object call261 = callmethod(*var_a, "nominal",
    0, params);
// compilenode returning call261
// compilenode returning call261
// Begin line 156
  setline(156);
// Begin line 262
  setline(262);
// Begin line 153
  setline(153);
// compilenode returning *var_b
  Object call262 = callmethod(*var_b, "nominal",
    0, params);
// compilenode returning call262
// compilenode returning call262
  params[0] = call262;
  Object opresult264 = callmethod(call261, "|", 1, params);
// compilenode returning opresult264
  Object if260;
  if (istrue(opresult264)) {
// Begin line 155
  setline(155);
// Begin line 154
  setline(154);
// compilenode returning *var_a
// compilenode returning *var_b
  params[0] = *var_b;
  Object opresult266 = callmethod(*var_a, "==", 1, params);
// compilenode returning opresult266
  return opresult266;
// compilenode returning undefined
    if260 = undefined;
  } else {
  }
// compilenode returning if260
// Begin line 163
  setline(163);
// Begin line 164
  setline(164);
// Begin line 262
  setline(262);
// Begin line 164
  setline(164);
// Begin line 262
  setline(262);
// Begin line 156
  setline(156);
// compilenode returning *var_a
  Object call268 = callmethod(*var_a, "unionTypes",
    0, params);
// compilenode returning call268
// compilenode returning call268
  Object call269 = callmethod(call268, "size",
    0, params);
// compilenode returning call269
// compilenode returning call269
  Object num270 = alloc_Float64(0.0);
// compilenode returning num270
  params[0] = num270;
  Object opresult272 = callmethod(call269, ">", 1, params);
// compilenode returning opresult272
  Object if267;
  if (istrue(opresult272)) {
// Begin line 160
  setline(160);
// Begin line 162
  setline(162);
// Begin line 262
  setline(262);
// Begin line 157
  setline(157);
// compilenode returning *var_a
  Object call274 = callmethod(*var_a, "unionTypes",
    0, params);
// compilenode returning call274
// compilenode returning call274
// Begin line 160
  setline(160);
// Begin line 262
  setline(262);
  Object obj276 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj276, self, 0);
  addmethod2(obj276, "outer", &reader_subtype_outer_277);
  adddatum2(obj276, self, 0);
  block_savedest(obj276);
  Object **closure278 = createclosure(2);
  addtoclosure(closure278, var_b);
  Object *selfpp284 = alloc_var();
  *selfpp284 = self;
  addtoclosure(closure278, selfpp284);
  struct UserObject *uo278 = (struct UserObject*)obj276;
  uo278->data[1] = (Object)closure278;
  addmethod2(obj276, "apply", &meth_subtype_apply278);
  set_type(obj276, 0);
// compilenode returning obj276
  setclassname(obj276, "Block<subtype:275>");
// compilenode returning obj276
  params[0] = call274;
  Object iter273 = callmethod(call274, "iter", 1, params);
  while(1) {
    Object cond273 = callmethod(iter273, "havemore", 0, NULL);
    if (!istrue(cond273)) break;
    params[0] = callmethod(iter273, "next", 0, NULL);
    callmethod(obj276, "apply", 1, params);
  }
// compilenode returning call274
// Begin line 163
  setline(163);
// Begin line 162
  setline(162);
  Object bool285 = alloc_Boolean(1);
// compilenode returning bool285
  return bool285;
// compilenode returning undefined
    if267 = undefined;
  } else {
  }
// compilenode returning if267
// Begin line 171
  setline(171);
// Begin line 172
  setline(172);
// Begin line 262
  setline(262);
// Begin line 172
  setline(172);
// Begin line 262
  setline(262);
// Begin line 164
  setline(164);
// compilenode returning *var_b
  Object call287 = callmethod(*var_b, "unionTypes",
    0, params);
// compilenode returning call287
// compilenode returning call287
  Object call288 = callmethod(call287, "size",
    0, params);
// compilenode returning call288
// compilenode returning call288
  Object num289 = alloc_Float64(0.0);
// compilenode returning num289
  params[0] = num289;
  Object opresult291 = callmethod(call288, ">", 1, params);
// compilenode returning opresult291
  Object if286;
  if (istrue(opresult291)) {
// Begin line 168
  setline(168);
// Begin line 170
  setline(170);
// Begin line 262
  setline(262);
// Begin line 165
  setline(165);
// compilenode returning *var_b
  Object call293 = callmethod(*var_b, "unionTypes",
    0, params);
// compilenode returning call293
// compilenode returning call293
// Begin line 168
  setline(168);
// Begin line 262
  setline(262);
  Object obj295 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj295, self, 0);
  addmethod2(obj295, "outer", &reader_subtype_outer_296);
  adddatum2(obj295, self, 0);
  block_savedest(obj295);
  Object **closure297 = createclosure(2);
  addtoclosure(closure297, var_a);
  Object *selfpp302 = alloc_var();
  *selfpp302 = self;
  addtoclosure(closure297, selfpp302);
  struct UserObject *uo297 = (struct UserObject*)obj295;
  uo297->data[1] = (Object)closure297;
  addmethod2(obj295, "apply", &meth_subtype_apply297);
  set_type(obj295, 0);
// compilenode returning obj295
  setclassname(obj295, "Block<subtype:294>");
// compilenode returning obj295
  params[0] = call293;
  Object iter292 = callmethod(call293, "iter", 1, params);
  while(1) {
    Object cond292 = callmethod(iter292, "havemore", 0, NULL);
    if (!istrue(cond292)) break;
    params[0] = callmethod(iter292, "next", 0, NULL);
    callmethod(obj295, "apply", 1, params);
  }
// compilenode returning call293
// Begin line 171
  setline(171);
// Begin line 170
  setline(170);
  Object bool303 = alloc_Boolean(0);
// compilenode returning bool303
  return bool303;
// compilenode returning undefined
    if286 = undefined;
  } else {
  }
// compilenode returning if286
// Begin line 174
  setline(174);
// Begin line 175
  setline(175);
// Begin line 262
  setline(262);
// Begin line 175
  setline(175);
// Begin line 262
  setline(262);
// Begin line 172
  setline(172);
// compilenode returning *var_a
  Object call305 = callmethod(*var_a, "methods",
    0, params);
// compilenode returning call305
// compilenode returning call305
  Object call306 = callmethod(call305, "size",
    0, params);
// compilenode returning call306
// compilenode returning call306
// Begin line 175
  setline(175);
// Begin line 262
  setline(262);
// Begin line 175
  setline(175);
// Begin line 262
  setline(262);
// Begin line 172
  setline(172);
// compilenode returning *var_b
  Object call307 = callmethod(*var_b, "methods",
    0, params);
// compilenode returning call307
// compilenode returning call307
  Object call308 = callmethod(call307, "size",
    0, params);
// compilenode returning call308
// compilenode returning call308
  params[0] = call308;
  Object opresult310 = callmethod(call306, "<", 1, params);
// compilenode returning opresult310
  Object if304;
  if (istrue(opresult310)) {
// Begin line 174
  setline(174);
// Begin line 173
  setline(173);
  Object bool311 = alloc_Boolean(0);
// compilenode returning bool311
  return bool311;
// compilenode returning undefined
    if304 = undefined;
  } else {
  }
// compilenode returning if304
// Begin line 202
  setline(202);
// Begin line 204
  setline(204);
// Begin line 262
  setline(262);
// Begin line 175
  setline(175);
// compilenode returning *var_b
  Object call313 = callmethod(*var_b, "methods",
    0, params);
// compilenode returning call313
// compilenode returning call313
// Begin line 202
  setline(202);
// Begin line 262
  setline(262);
  Object obj315 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj315, self, 0);
  addmethod2(obj315, "outer", &reader_subtype_outer_316);
  adddatum2(obj315, self, 0);
  block_savedest(obj315);
  Object **closure317 = createclosure(2);
  addtoclosure(closure317, var_a);
  Object *selfpp384 = alloc_var();
  *selfpp384 = self;
  addtoclosure(closure317, selfpp384);
  struct UserObject *uo317 = (struct UserObject*)obj315;
  uo317->data[1] = (Object)closure317;
  addmethod2(obj315, "apply", &meth_subtype_apply317);
  set_type(obj315, 0);
// compilenode returning obj315
  setclassname(obj315, "Block<subtype:314>");
// compilenode returning obj315
  params[0] = call313;
  Object iter312 = callmethod(call313, "iter", 1, params);
  while(1) {
    Object cond312 = callmethod(iter312, "havemore", 0, NULL);
    if (!istrue(cond312)) break;
    params[0] = callmethod(iter312, "next", 0, NULL);
    callmethod(obj315, "apply", 1, params);
  }
// compilenode returning call313
// Begin line 205
  setline(205);
// Begin line 204
  setline(204);
  Object bool385 = alloc_Boolean(1);
// compilenode returning bool385
  return bool385;
// compilenode returning undefined
  return undefined;
}
Object meth_subtype_apply402(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[2];
  Object *var_row = closure[0];
  Object *var_t1 = closure[1];
  Object *var_changed = closure[2];
  Object self = *closure[3];
  Object *var_d2 = alloc_var();
  *var_d2 = undefined;
// Begin line 214
  setline(214);
// compilenode returning *var_t2
// Begin line 215
  setline(215);
// compilenode returning self
  params[0] = *var_t2;
  Object call403 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call403
  *var_d2 = call403;
  if (call403 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 219
  setline(219);
// Begin line 215
  setline(215);
// compilenode returning *var_d2
// compilenode returning *var_row
  params[0] = *var_d2;
  Object call405 = callmethod(*var_row, "get",
    1, params);
// compilenode returning call405
  Object if404;
  if (istrue(call405)) {
// Begin line 219
  setline(219);
// Begin line 216
  setline(216);
// Begin line 262
  setline(262);
// Begin line 216
  setline(216);
// compilenode returning *var_t1
// compilenode returning *var_t2
// Begin line 220
  setline(220);
// compilenode returning self
  params[0] = *var_t1;
  params[1] = *var_t2;
  Object call407 = callmethod(self, "checkThat(1)mayBeSubtypeOf",
    2, params);
// compilenode returning call407
  Object call408 = callmethod(call407, "not",
    0, params);
// compilenode returning call408
// compilenode returning call408
  Object if406;
  if (istrue(call408)) {
// Begin line 217
  setline(217);
// compilenode returning *var_d2
  Object bool409 = alloc_Boolean(0);
// compilenode returning bool409
// compilenode returning *var_row
  params[0] = *var_d2;
  params[1] = bool409;
  Object call410 = callmethod(*var_row, "put",
    2, params);
// compilenode returning call410
// Begin line 219
  setline(219);
// Begin line 218
  setline(218);
  Object bool411 = alloc_Boolean(1);
// compilenode returning bool411
  *var_changed = bool411;
  if (bool411 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if406 = nothing;
  } else {
  }
// compilenode returning if406
    if404 = if406;
  } else {
  }
// compilenode returning if404
  return if404;
}
Object meth_subtype_apply395(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t1 = alloc_var();
  *var_t1 = args[0];
  Object params[1];
  Object *var_matrix = closure[0];
  Object *var_types = closure[1];
  Object *var_changed = closure[2];
  Object self = *closure[3];
  Object *var_row = alloc_var();
  *var_row = undefined;
// Begin line 212
  setline(212);
// compilenode returning *var_t1
// compilenode returning self
  params[0] = *var_t1;
  Object call396 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call396
// compilenode returning *var_matrix
  params[0] = call396;
  Object call397 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call397
  *var_row = call397;
  if (call397 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 219
  setline(219);
// Begin line 213
  setline(213);
// compilenode returning *var_types
// Begin line 219
  setline(219);
// Begin line 262
  setline(262);
  Object obj400 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj400, self, 0);
  addmethod2(obj400, "outer", &reader_subtype_outer_401);
  adddatum2(obj400, self, 0);
  block_savedest(obj400);
  Object **closure402 = createclosure(4);
  addtoclosure(closure402, var_row);
  addtoclosure(closure402, var_t1);
  addtoclosure(closure402, var_changed);
  Object *selfpp413 = alloc_var();
  *selfpp413 = self;
  addtoclosure(closure402, selfpp413);
  struct UserObject *uo402 = (struct UserObject*)obj400;
  uo402->data[1] = (Object)closure402;
  addmethod2(obj400, "apply", &meth_subtype_apply402);
  set_type(obj400, 0);
// compilenode returning obj400
  setclassname(obj400, "Block<subtype:399>");
// compilenode returning obj400
  params[0] = *var_types;
  Object iter398 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond398 = callmethod(iter398, "havemore", 0, NULL);
    if (!istrue(cond398)) break;
    params[0] = callmethod(iter398, "next", 0, NULL);
    callmethod(obj400, "apply", 1, params);
  }
// compilenode returning *var_types
  return *var_types;
}
Object meth_subtype_findSubtypes386(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object params[1];
  Object *var_types = closure[0];
  Object *var_matrix = closure[1];
  Object *var_modified = closure[2];
  Object *var_changed = alloc_var();
  *var_changed = undefined;
// Begin line 209
  setline(209);
// Begin line 208
  setline(208);
  Object bool387 = alloc_Boolean(1);
// compilenode returning bool387
  var_changed = alloc_var();
  *var_changed = bool387;
  if (bool387 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 219
  setline(219);
  Object while388;
  while (1) {
// Begin line 209
  setline(209);
// compilenode returning *var_changed
    while388 = *var_changed;
    if (!istrue(*var_changed)) break;
// Begin line 211
  setline(211);
// Begin line 210
  setline(210);
  Object bool389 = alloc_Boolean(0);
// compilenode returning bool389
  *var_changed = bool389;
  if (bool389 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 219
  setline(219);
// Begin line 211
  setline(211);
// compilenode returning *var_types
// Begin line 219
  setline(219);
// Begin line 262
  setline(262);
  Object obj393 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj393, self, 0);
  addmethod2(obj393, "outer", &reader_subtype_outer_394);
  adddatum2(obj393, self, 0);
  block_savedest(obj393);
  Object **closure395 = createclosure(4);
  addtoclosure(closure395, var_matrix);
  addtoclosure(closure395, var_types);
  addtoclosure(closure395, var_changed);
  Object *selfpp414 = alloc_var();
  *selfpp414 = self;
  addtoclosure(closure395, selfpp414);
  struct UserObject *uo395 = (struct UserObject*)obj393;
  uo395->data[1] = (Object)closure395;
  addmethod2(obj393, "apply", &meth_subtype_apply395);
  set_type(obj393, 0);
// compilenode returning obj393
  setclassname(obj393, "Block<subtype:392>");
// compilenode returning obj393
  params[0] = *var_types;
  Object iter391 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond391 = callmethod(iter391, "havemore", 0, NULL);
    if (!istrue(cond391)) break;
    params[0] = callmethod(iter391, "next", 0, NULL);
    callmethod(obj393, "apply", 1, params);
  }
// compilenode returning *var_types
  }
// compilenode returning while388
// Begin line 225
  setline(225);
// Begin line 224
  setline(224);
  Object bool415 = alloc_Boolean(0);
// compilenode returning bool415
  *var_modified = bool415;
  if (bool415 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_subtype_conformsType_40_1_41_to417(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object *var_a = alloc_var();
  *var_a = args[0];
  Object *var_b = alloc_var();
  *var_b = args[1];
  Object params[1];
  Object *var_modified = closure[0];
  Object *var_matrix = closure[1];
// Begin line 229
  setline(229);
// Begin line 228
  setline(228);
// compilenode returning *var_a
// Begin line 231
  setline(231);
// compilenode returning self
  params[0] = *var_a;
  Object call419 = callmethod(self, "addType",
    1, params);
// compilenode returning call419
// Begin line 228
  setline(228);
// compilenode returning *var_b
// compilenode returning self
  params[0] = *var_b;
  Object call420 = callmethod(self, "addType",
    1, params);
// compilenode returning call420
  params[0] = call420;
  Object opresult422 = callmethod(call419, "|", 1, params);
// compilenode returning opresult422
// compilenode returning *var_modified
  params[0] = *var_modified;
  Object opresult424 = callmethod(opresult422, "|", 1, params);
// compilenode returning opresult424
  Object if418;
  if (istrue(opresult424)) {
// Begin line 229
  setline(229);
// compilenode returning self
  Object call425 = callmethod(self, "findSubtypes",
    0, params);
// compilenode returning call425
    if418 = call425;
  } else {
  }
// compilenode returning if418
// Begin line 231
  setline(231);
// compilenode returning *var_b
// compilenode returning self
  params[0] = *var_b;
  Object call426 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call426
// compilenode returning *var_a
// compilenode returning self
  params[0] = *var_a;
  Object call427 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call427
// compilenode returning *var_matrix
  params[0] = call427;
  Object call428 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call428
  params[0] = call426;
  Object call429 = callmethod(call428, "get",
    1, params);
// compilenode returning call429
  return call429;
}
Object meth_subtype_apply449(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_t2 = alloc_var();
  *var_t2 = args[0];
  Object params[1];
  Object *var_st = closure[0];
  Object *var_id = closure[1];
  Object *var_matrix = closure[2];
  Object *var_maybe = closure[3];
  Object self = *closure[4];
  Object *var_d2 = alloc_var();
  *var_d2 = undefined;
// Begin line 245
  setline(245);
// compilenode returning *var_t2
// Begin line 246
  setline(246);
// compilenode returning self
  params[0] = *var_t2;
  Object call450 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call450
  *var_d2 = call450;
  if (call450 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 247
  setline(247);
// Begin line 246
  setline(246);
// Begin line 249
  setline(249);
// Begin line 246
  setline(246);
// compilenode returning *var_d2
  if (strlit452 == NULL) {
    strlit452 = alloc_String("Dynamic");
  }
// compilenode returning strlit452
  params[0] = strlit452;
  Object opresult454 = callmethod(*var_d2, "/=", 1, params);
// compilenode returning opresult454
// compilenode returning *var_d2
// compilenode returning *var_st
  params[0] = *var_d2;
  Object call455 = callmethod(*var_st, "get",
    1, params);
// compilenode returning call455
  params[0] = call455;
  Object opresult457 = callmethod(opresult454, "&", 1, params);
// compilenode returning opresult457
// compilenode returning *var_id
// compilenode returning *var_d2
// compilenode returning *var_matrix
  params[0] = *var_d2;
  Object call458 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call458
  params[0] = *var_id;
  Object call459 = callmethod(call458, "get",
    1, params);
// compilenode returning call459
  params[0] = call459;
  Object opresult461 = callmethod(opresult457, "&", 1, params);
// compilenode returning opresult461
  Object if451;
  if (istrue(opresult461)) {
// Begin line 247
  setline(247);
// compilenode returning *var_d2
// compilenode returning *var_maybe
  params[0] = *var_d2;
  Object call462 = callmethod(*var_maybe, "push",
    1, params);
// compilenode returning call462
    if451 = call462;
  } else {
  }
// compilenode returning if451
  return if451;
}
Object meth_subtype_apply469(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mn = alloc_var();
  *var_mn = args[0];
  Object params[1];
  Object *var_best = closure[0];
  Object self = *closure[1];
// Begin line 255
  setline(255);
// Begin line 257
  setline(257);
// Begin line 262
  setline(262);
// Begin line 252
  setline(252);
// compilenode returning *var_mn
  Object call471 = callmethod(*var_mn, "size",
    0, params);
// compilenode returning call471
// compilenode returning call471
// Begin line 257
  setline(257);
// Begin line 262
  setline(262);
// Begin line 252
  setline(252);
// compilenode returning *var_best
  Object call472 = callmethod(*var_best, "size",
    0, params);
// compilenode returning call472
// compilenode returning call472
  params[0] = call472;
  Object opresult474 = callmethod(call471, ">", 1, params);
// compilenode returning opresult474
  Object if470;
  if (istrue(opresult474)) {
// Begin line 255
  setline(255);
// Begin line 253
  setline(253);
  Object num476 = alloc_Float64(1.0);
// compilenode returning num476
// compilenode returning *var_mn
  params[0] = num476;
  Object call477 = callmethod(*var_mn, "at",
    1, params);
// compilenode returning call477
  if (strlit478 == NULL) {
    strlit478 = alloc_String("<");
  }
// compilenode returning strlit478
  params[0] = strlit478;
  Object opresult480 = callmethod(call477, "/=", 1, params);
// compilenode returning opresult480
  Object if475;
  if (istrue(opresult480)) {
// Begin line 255
  setline(255);
// Begin line 254
  setline(254);
// compilenode returning *var_mn
  *var_best = *var_mn;
  if (*var_mn == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if475 = nothing;
  } else {
  }
// compilenode returning if475
    if470 = if475;
  } else {
  }
// compilenode returning if470
  return if470;
}
Object meth_subtype_nicename430(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object *var_t = alloc_var();
  *var_t = args[0];
  Object params[1];
  Object *var_modified = closure[0];
  Object *var_matrix = closure[1];
  Object *var_types = closure[2];
  Object *var_id = alloc_var();
  *var_id = undefined;
  Object *var_st = alloc_var();
  *var_st = undefined;
  Object *var_maybe = alloc_var();
  *var_maybe = undefined;
  Object *var_best = alloc_var();
  *var_best = undefined;
// Begin line 236
  setline(236);
// Begin line 235
  setline(235);
// compilenode returning *var_t
// Begin line 238
  setline(238);
// compilenode returning self
  params[0] = *var_t;
  Object call432 = callmethod(self, "addType",
    1, params);
// compilenode returning call432
// Begin line 235
  setline(235);
// compilenode returning *var_modified
  params[0] = *var_modified;
  Object opresult434 = callmethod(call432, "|", 1, params);
// compilenode returning opresult434
  Object if431;
  if (istrue(opresult434)) {
// Begin line 236
  setline(236);
// compilenode returning self
  Object call435 = callmethod(self, "findSubtypes",
    0, params);
// compilenode returning call435
    if431 = call435;
  } else {
  }
// compilenode returning if431
// Begin line 238
  setline(238);
// compilenode returning *var_t
// Begin line 239
  setline(239);
// compilenode returning self
  params[0] = *var_t;
  Object call436 = callmethod(self, "stringifyType",
    1, params);
// compilenode returning call436
  *var_id = call436;
  if (call436 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 241
  setline(241);
// Begin line 239
  setline(239);
  Object num438 = alloc_Float64(1.0);
// compilenode returning num438
// compilenode returning *var_id
  params[0] = num438;
  Object call439 = callmethod(*var_id, "at",
    1, params);
// compilenode returning call439
  if (strlit440 == NULL) {
    strlit440 = alloc_String("<");
  }
// compilenode returning strlit440
  params[0] = strlit440;
  Object opresult442 = callmethod(call439, "/=", 1, params);
// compilenode returning opresult442
  Object if437;
  if (istrue(opresult442)) {
// Begin line 241
  setline(241);
// Begin line 240
  setline(240);
// compilenode returning *var_id
  return *var_id;
// compilenode returning undefined
    if437 = undefined;
  } else {
  }
// compilenode returning if437
// Begin line 242
  setline(242);
// compilenode returning *var_id
// compilenode returning *var_matrix
  params[0] = *var_id;
  Object call443 = callmethod(*var_matrix, "get",
    1, params);
// compilenode returning call443
  *var_st = call443;
  if (call443 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 244
  setline(244);
  Object array444 = alloc_List();
// compilenode returning array444
  *var_maybe = array444;
  if (array444 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 247
  setline(247);
// Begin line 244
  setline(244);
// compilenode returning *var_types
// Begin line 247
  setline(247);
// Begin line 262
  setline(262);
  Object obj447 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj447, self, 0);
  addmethod2(obj447, "outer", &reader_subtype_outer_448);
  adddatum2(obj447, self, 0);
  block_savedest(obj447);
  Object **closure449 = createclosure(5);
  addtoclosure(closure449, var_st);
  addtoclosure(closure449, var_id);
  addtoclosure(closure449, var_matrix);
  addtoclosure(closure449, var_maybe);
  Object *selfpp463 = alloc_var();
  *selfpp463 = self;
  addtoclosure(closure449, selfpp463);
  struct UserObject *uo449 = (struct UserObject*)obj447;
  uo449->data[1] = (Object)closure449;
  addmethod2(obj447, "apply", &meth_subtype_apply449);
  set_type(obj447, 0);
// compilenode returning obj447
  setclassname(obj447, "Block<subtype:446>");
// compilenode returning obj447
  params[0] = *var_types;
  Object iter445 = callmethod(*var_types, "iter", 1, params);
  while(1) {
    Object cond445 = callmethod(iter445, "havemore", 0, NULL);
    if (!istrue(cond445)) break;
    params[0] = callmethod(iter445, "next", 0, NULL);
    callmethod(obj447, "apply", 1, params);
  }
// compilenode returning *var_types
// Begin line 251
  setline(251);
// Begin line 250
  setline(250);
  if (strlit464 == NULL) {
    strlit464 = alloc_String("");
  }
// compilenode returning strlit464
  var_best = alloc_var();
  *var_best = strlit464;
  if (strlit464 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 255
  setline(255);
// Begin line 251
  setline(251);
// compilenode returning *var_maybe
// Begin line 255
  setline(255);
// Begin line 262
  setline(262);
  Object obj467 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj467, self, 0);
  addmethod2(obj467, "outer", &reader_subtype_outer_468);
  adddatum2(obj467, self, 0);
  block_savedest(obj467);
  Object **closure469 = createclosure(2);
  addtoclosure(closure469, var_best);
  Object *selfpp482 = alloc_var();
  *selfpp482 = self;
  addtoclosure(closure469, selfpp482);
  struct UserObject *uo469 = (struct UserObject*)obj467;
  uo469->data[1] = (Object)closure469;
  addmethod2(obj467, "apply", &meth_subtype_apply469);
  set_type(obj467, 0);
// compilenode returning obj467
  setclassname(obj467, "Block<subtype:466>");
// compilenode returning obj467
  params[0] = *var_maybe;
  Object iter465 = callmethod(*var_maybe, "iter", 1, params);
  while(1) {
    Object cond465 = callmethod(iter465, "havemore", 0, NULL);
    if (!istrue(cond465)) break;
    params[0] = callmethod(iter465, "next", 0, NULL);
    callmethod(obj467, "apply", 1, params);
  }
// compilenode returning *var_maybe
// Begin line 260
  setline(260);
// Begin line 261
  setline(261);
// Begin line 262
  setline(262);
// Begin line 258
  setline(258);
// compilenode returning *var_best
  Object call484 = callmethod(*var_best, "size",
    0, params);
// compilenode returning call484
// compilenode returning call484
  Object num485 = alloc_Float64(0.0);
// compilenode returning num485
  params[0] = num485;
  Object opresult487 = callmethod(call484, ">", 1, params);
// compilenode returning opresult487
  Object if483;
  if (istrue(opresult487)) {
// Begin line 260
  setline(260);
// Begin line 259
  setline(259);
// compilenode returning *var_best
  return *var_best;
// compilenode returning undefined
    if483 = undefined;
  } else {
  }
// compilenode returning if483
// Begin line 262
  setline(262);
// Begin line 261
  setline(261);
// compilenode returning *var_id
  return *var_id;
// compilenode returning undefined
  return undefined;
}
Object module_subtype_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<subtype>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var_types = alloc_var();
  *var_types = undefined;
  Object *var_typesToId = alloc_var();
  *var_typesToId = undefined;
  Object *var_matrix = alloc_var();
  *var_matrix = undefined;
  Object *var_DynamicType = alloc_var();
  *var_DynamicType = undefined;
  Object *var_modified = alloc_var();
  *var_modified = undefined;
// Begin line 4
  setline(4);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 5
  setline(5);
  Object array1 = alloc_List();
// compilenode returning array1
  *var_types = array1;
  if (array1 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 6
  setline(6);
// Begin line 262
  setline(262);
// Begin line 5
  setline(5);
// compilenode returning *var_HashMap
  Object call2 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call2
// compilenode returning call2
  *var_typesToId = call2;
  if (call2 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 7
  setline(7);
// Begin line 262
  setline(262);
// Begin line 6
  setline(6);
// compilenode returning *var_HashMap
  Object call3 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call3
// compilenode returning call3
  *var_matrix = call3;
  if (call3 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 8
  setline(8);
  var_DynamicType = alloc_var();
  *var_DynamicType = undefined;
// compilenode returning nothing
// Begin line 10
  setline(10);
// Begin line 8
  setline(8);
  Object bool4 = alloc_Boolean(1);
// compilenode returning bool4
  var_modified = alloc_var();
  *var_modified = bool4;
  if (bool4 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 22
  setline(22);
  addmethod2(self, "stringifyType", &meth_subtype_stringifyType5);
// compilenode returning 
// Begin line 32
  setline(32);
  block_savedest(self);
  Object **closure39 = createclosure(3);
  addtoclosure(closure39, var_types);
  addtoclosure(closure39, var_HashMap);
  addtoclosure(closure39, var_matrix);
  struct UserObject *uo39 = (struct UserObject*)self;
  uo39->data[2] = (Object)closure39;
  addmethod2(self, "resetMatrix", &meth_subtype_resetMatrix39);
// compilenode returning 
// Begin line 56
  setline(56);
  block_savedest(self);
  Object **closure58 = createclosure(6);
  addtoclosure(closure58, var_matrix);
  addtoclosure(closure58, var_DynamicType);
  addtoclosure(closure58, var_types);
  addtoclosure(closure58, var_typesToId);
  addtoclosure(closure58, var_HashMap);
  addtoclosure(closure58, var_modified);
  struct UserObject *uo58 = (struct UserObject*)self;
  uo58->data[3] = (Object)closure58;
  addmethod2(self, "addType", &meth_subtype_addType58);
// compilenode returning 
// Begin line 77
  setline(77);
  block_savedest(self);
  Object **closure91 = createclosure(4);
  addtoclosure(closure91, var_matrix);
  addtoclosure(closure91, var_HashMap);
  addtoclosure(closure91, var_types);
  addtoclosure(closure91, var_modified);
  struct UserObject *uo91 = (struct UserObject*)self;
  uo91->data[4] = (Object)closure91;
  addmethod2(self, "resetType", &meth_subtype_resetType91);
// compilenode returning 
// Begin line 84
  setline(84);
  block_savedest(self);
  Object **closure127 = createclosure(2);
  addtoclosure(closure127, var_DynamicType);
  addtoclosure(closure127, var_typesToId);
  struct UserObject *uo127 = (struct UserObject*)self;
  uo127->data[5] = (Object)closure127;
  addmethod2(self, "typeId", &meth_subtype_typeId127);
// compilenode returning 
// Begin line 100
  setline(100);
  block_savedest(self);
  Object **closure135 = createclosure(3);
  addtoclosure(closure135, var_modified);
  addtoclosure(closure135, var_types);
  addtoclosure(closure135, var_matrix);
  struct UserObject *uo135 = (struct UserObject*)self;
  uo135->data[6] = (Object)closure135;
  addmethod2(self, "boolMatrix", &meth_subtype_boolMatrix135);
// compilenode returning 
// Begin line 117
  setline(117);
  block_savedest(self);
  Object **closure158 = createclosure(3);
  addtoclosure(closure158, var_modified);
  addtoclosure(closure158, var_types);
  addtoclosure(closure158, var_matrix);
  struct UserObject *uo158 = (struct UserObject*)self;
  uo158->data[7] = (Object)closure158;
  addmethod2(self, "printMatrix", &meth_subtype_printMatrix158);
// compilenode returning 
// Begin line 132
  setline(132);
  block_savedest(self);
  Object **closure203 = createclosure(2);
  addtoclosure(closure203, var_DynamicType);
  addtoclosure(closure203, var_types);
  struct UserObject *uo203 = (struct UserObject*)self;
  uo203->data[8] = (Object)closure203;
  addmethod2(self, "findType", &meth_subtype_findType203);
// compilenode returning 
// Begin line 139
  setline(139);
  block_savedest(self);
  Object **closure225 = createclosure(1);
  addtoclosure(closure225, var_matrix);
  struct UserObject *uo225 = (struct UserObject*)self;
  uo225->data[9] = (Object)closure225;
  addmethod2(self, "simpleCheckThat(1)mayBeSubtypeOf", &meth_subtype_simpleCheckThat_40_1_41_mayBeSubtypeOf225);
// compilenode returning 
// Begin line 205
  setline(205);
  block_savedest(self);
  Object **closure240 = createclosure(1);
  addtoclosure(closure240, var_matrix);
  struct UserObject *uo240 = (struct UserObject*)self;
  uo240->data[10] = (Object)closure240;
  addmethod2(self, "checkThat(1)mayBeSubtypeOf", &meth_subtype_checkThat_40_1_41_mayBeSubtypeOf240);
// compilenode returning 
// Begin line 225
  setline(225);
  block_savedest(self);
  Object **closure386 = createclosure(3);
  addtoclosure(closure386, var_types);
  addtoclosure(closure386, var_matrix);
  addtoclosure(closure386, var_modified);
  struct UserObject *uo386 = (struct UserObject*)self;
  uo386->data[11] = (Object)closure386;
  addmethod2(self, "findSubtypes", &meth_subtype_findSubtypes386);
// compilenode returning 
// Begin line 231
  setline(231);
  block_savedest(self);
  Object **closure417 = createclosure(2);
  addtoclosure(closure417, var_modified);
  addtoclosure(closure417, var_matrix);
  struct UserObject *uo417 = (struct UserObject*)self;
  uo417->data[12] = (Object)closure417;
  addmethod2(self, "conformsType(1)to", &meth_subtype_conformsType_40_1_41_to417);
// compilenode returning 
// Begin line 262
  setline(262);
  block_savedest(self);
  Object **closure430 = createclosure(3);
  addtoclosure(closure430, var_modified);
  addtoclosure(closure430, var_matrix);
  addtoclosure(closure430, var_types);
  struct UserObject *uo430 = (struct UserObject*)self;
  uo430->data[13] = (Object)closure430;
  addmethod2(self, "nicename", &meth_subtype_nicename430);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_subtype_init();
  gracelib_stats();
  return 0;
}
