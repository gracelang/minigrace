#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_typechecker_outer_166(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_169(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_kind_170(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[1];
}
Object writer_typechecker_kind_170(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[1] = args[0];
  return nothing;
}
Object reader_typechecker_dtype_171(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[2];
}
Object writer_typechecker_dtype_171(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[2] = args[0];
  return nothing;
}
Object reader_typechecker_value_173(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  return uo->data[3];
}
Object writer_typechecker_value_173(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject *)self;
  uo->data[3] = args[0];
  return nothing;
}
Object reader_typechecker_outer_179(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_191(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_279(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_298(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_312(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_321(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_380(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_423(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_499(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_591(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_672(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_744(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_752(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_844(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_958(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_996(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1147(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1184(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1354(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1427(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1445(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1474(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1504(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1522(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1658(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1677(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1686(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1726(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1738(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1752(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1757(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1780(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1803(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1815(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1827(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1835(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1841(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_1867(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_2148(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_2165(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_2183(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_2314(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_2373(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_typechecker_outer_2386(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_ast_init();
Object module_ast;
Object module_util_init();
Object module_util;
Object module_subtype_init();
Object module_subtype;
static Object strlit6;
static Object strlit9;
static Object strlit10;
static Object strlit14;
static Object strlit17;
static Object strlit19;
static Object strlit22;
static Object strlit24;
static Object strlit27;
static Object strlit29;
static Object strlit32;
static Object strlit34;
static Object strlit37;
static Object strlit40;
static Object strlit43;
static Object strlit46;
static Object strlit49;
static Object strlit52;
static Object strlit55;
static Object strlit58;
static Object strlit61;
static Object strlit64;
static Object strlit67;
static Object strlit70;
static Object strlit73;
static Object strlit76;
static Object strlit79;
static Object strlit83;
static Object strlit85;
static Object strlit88;
static Object strlit91;
static Object strlit94;
static Object strlit97;
static Object strlit100;
static Object strlit103;
static Object strlit106;
static Object strlit109;
static Object strlit112;
static Object strlit115;
static Object strlit118;
static Object strlit121;
static Object strlit125;
static Object strlit127;
static Object strlit130;
static Object strlit133;
static Object strlit136;
static Object strlit139;
static Object strlit142;
static Object strlit145;
static Object strlit148;
static Object strlit151;
static Object strlit154;
static Object strlit157;
static Object strlit160;
static Object strlit202;
static Object strlit206;
static Object strlit218;
static Object strlit221;
static Object strlit225;
static Object strlit228;
static Object strlit259;
static Object strlit265;
static Object strlit341;
static Object strlit346;
static Object strlit350;
static Object strlit363;
static Object strlit388;
static Object strlit393;
static Object strlit398;
static Object strlit414;
static Object strlit435;
static Object strlit438;
static Object strlit444;
static Object strlit457;
static Object strlit458;
static Object strlit462;
static Object strlit478;
static Object strlit490;
static Object strlit511;
static Object strlit514;
static Object strlit520;
static Object strlit530;
static Object strlit533;
static Object strlit539;
static Object strlit542;
static Object strlit547;
static Object strlit556;
static Object strlit564;
static Object strlit570;
static Object strlit582;
static Object strlit603;
static Object strlit606;
static Object strlit612;
static Object strlit623;
static Object strlit626;
static Object strlit632;
static Object strlit635;
static Object strlit640;
static Object strlit645;
static Object strlit650;
static Object strlit682;
static Object strlit685;
static Object strlit690;
static Object strlit693;
static Object strlit697;
static Object strlit703;
static Object strlit713;
static Object strlit721;
static Object strlit725;
static Object strlit729;
static Object strlit756;
static Object strlit768;
static Object strlit780;
static Object strlit792;
static Object strlit796;
static Object strlit806;
static Object strlit812;
static Object strlit823;
static Object strlit864;
static Object strlit868;
static Object strlit872;
static Object strlit880;
static Object strlit883;
static Object strlit886;
static Object strlit891;
static Object strlit894;
static Object strlit897;
static Object strlit909;
static Object strlit912;
static Object strlit915;
static Object strlit919;
static Object strlit922;
static Object strlit927;
static Object strlit929;
static Object strlit939;
static Object strlit979;
static Object strlit1020;
static Object strlit1031;
static Object strlit1035;
static Object strlit1041;
static Object strlit1065;
static Object strlit1068;
static Object strlit1072;
static Object strlit1078;
static Object strlit1084;
static Object strlit1092;
static Object strlit1096;
static Object strlit1102;
static Object strlit1108;
static Object strlit1121;
static Object strlit1126;
static Object strlit1156;
static Object strlit1163;
static Object strlit1170;
static Object strlit1173;
static Object strlit1196;
static Object strlit1200;
static Object strlit1211;
static Object strlit1218;
static Object strlit1221;
static Object strlit1226;
static Object strlit1229;
static Object strlit1230;
static Object strlit1237;
static Object strlit1249;
static Object strlit1261;
static Object strlit1274;
static Object strlit1281;
static Object strlit1293;
static Object strlit1304;
static Object strlit1311;
static Object strlit1323;
static Object strlit1333;
static Object strlit1346;
static Object strlit1374;
static Object strlit1388;
static Object strlit1394;
static Object strlit1395;
static Object strlit1399;
static Object strlit1419;
static Object strlit1440;
static Object strlit1447;
static Object strlit1448;
static Object strlit1452;
static Object strlit1453;
static Object strlit1468;
static Object strlit1476;
static Object strlit1477;
static Object strlit1481;
static Object strlit1482;
static Object strlit1486;
static Object strlit1487;
static Object strlit1496;
static Object strlit1512;
static Object strlit1540;
static Object strlit1551;
static Object strlit1562;
static Object strlit1565;
static Object strlit1569;
static Object strlit1575;
static Object strlit1578;
static Object strlit1583;
static Object strlit1589;
static Object strlit1592;
static Object strlit1596;
static Object strlit1605;
static Object strlit1610;
static Object strlit1621;
static Object strlit1625;
static Object strlit1644;
static Object strlit1665;
static Object strlit1877;
static Object strlit1898;
static Object strlit1902;
static Object strlit1926;
static Object strlit1942;
static Object strlit1946;
static Object strlit1960;
static Object strlit1983;
static Object strlit1990;
static Object strlit2001;
static Object strlit2002;
static Object strlit2006;
static Object strlit2021;
static Object strlit2042;
static Object strlit2064;
static Object strlit2093;
static Object strlit2114;
static Object strlit2140;
static Object strlit2152;
static Object strlit2155;
static Object strlit2169;
static Object strlit2187;
static Object strlit2191;
static Object strlit2200;
static Object strlit2205;
static Object strlit2213;
static Object strlit2216;
static Object strlit2221;
static Object strlit2228;
static Object strlit2232;
static Object strlit2241;
static Object strlit2249;
static Object strlit2252;
static Object strlit2257;
static Object strlit2264;
static Object strlit2268;
static Object strlit2277;
static Object strlit2282;
static Object strlit2287;
static Object strlit2290;
static Object strlit2298;
static Object strlit2322;
static Object strlit2333;
static Object strlit2336;
static Object strlit2341;
static Object strlit2344;
static Object strlit2348;
static Object strlit2359;
static Object strlit2362;
static Object strlit2391;
static Object strlit2393;
static Object strlit2394;
static Object strlit2397;
static Object strlit2398;
static Object strlit2401;
static Object strlit2402;
static Object strlit2405;
static Object strlit2406;
static Object strlit2409;
static Object strlit2410;
static Object strlit2413;
static Object strlit2414;
static Object strlit2417;
static Object strlit2418;
static Object strlit2421;
static Object strlit2422;
static Object strlit2425;
static Object strlit2429;
static Object strlit2431;
static Object strlit2435;
static Object strlit2437;
static Object strlit2441;
static Object strlit2443;
static Object strlit2447;
Object meth_typechecker_new167(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_kind_39_ = alloc_var();
  *var_kind_39_ = args[0];
  Object params[1];
  Object *var_DynamicType = closure[0];
  Object obj168 = alloc_obj2(6,4);
// OBJECT OUTER DEC outer
  adddatum2(obj168, self, 0);
  addmethod2(obj168, "outer", &reader_typechecker_outer_169);
  adddatum2(obj168, self, 0);
// Begin line 69
  setline(69);
// compilenode returning *var_kind_39_
// OBJECT VAR DEC kind
  adddatum2(obj168, *var_kind_39_, 1);
  addmethod2(obj168, "kind", &reader_typechecker_kind_170);
  addmethod2(obj168, "kind:=", &writer_typechecker_kind_170);
// Begin line 70
  setline(70);
// compilenode returning *var_DynamicType
// OBJECT VAR DEC dtype
  adddatum2(obj168, *var_DynamicType, 2);
  addmethod2(obj168, "dtype", &reader_typechecker_dtype_171);
  addmethod2(obj168, "dtype:=", &writer_typechecker_dtype_171);
// Begin line 71
  setline(71);
  Object bool172 = alloc_Boolean(0);
// compilenode returning bool172
// OBJECT VAR DEC value
  adddatum2(obj168, bool172, 3);
  addmethod2(obj168, "value", &reader_typechecker_value_173);
  addmethod2(obj168, "value:=", &writer_typechecker_value_173);
  set_type(obj168, 0);
// compilenode returning obj168
  return obj168;
}
Object meth_typechecker_apply180(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_sc = alloc_var();
  *var_sc = args[0];
  Object params[1];
  Object *var_name = closure[0];
  Object *var_ret = closure[1];
  Object self = *closure[2];
// Begin line 79
  setline(79);
// Begin line 77
  setline(77);
// compilenode returning *var_name
// compilenode returning *var_sc
  params[0] = *var_name;
  Object call182 = callmethod(*var_sc, "contains",
    1, params);
// compilenode returning call182
  Object if181;
  if (istrue(call182)) {
// Begin line 79
  setline(79);
// Begin line 78
  setline(78);
  Object bool183 = alloc_Boolean(1);
// compilenode returning bool183
  *var_ret = bool183;
  if (bool183 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if181 = nothing;
  } else {
  }
// compilenode returning if181
  return if181;
}
Object meth_typechecker_haveBinding174(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_name = alloc_var();
  *var_name = args[0];
  Object params[1];
  Object *var_scopes = closure[0];
  Object *var_ret = alloc_var();
  *var_ret = undefined;
// Begin line 76
  setline(76);
// Begin line 75
  setline(75);
  Object bool175 = alloc_Boolean(0);
// compilenode returning bool175
  var_ret = alloc_var();
  *var_ret = bool175;
  if (bool175 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 79
  setline(79);
// Begin line 76
  setline(76);
// compilenode returning *var_scopes
// Begin line 79
  setline(79);
// Begin line 1017
  setline(1017);
  Object obj178 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj178, self, 0);
  addmethod2(obj178, "outer", &reader_typechecker_outer_179);
  adddatum2(obj178, self, 0);
  block_savedest(obj178);
  Object **closure180 = createclosure(3);
  addtoclosure(closure180, var_name);
  addtoclosure(closure180, var_ret);
  Object *selfpp185 = alloc_var();
  *selfpp185 = self;
  addtoclosure(closure180, selfpp185);
  struct UserObject *uo180 = (struct UserObject*)obj178;
  uo180->data[1] = (Object)closure180;
  addmethod2(obj178, "apply", &meth_typechecker_apply180);
  set_type(obj178, 0);
// compilenode returning obj178
  setclassname(obj178, "Block<typechecker:177>");
// compilenode returning obj178
  params[0] = *var_scopes;
  Object iter176 = callmethod(*var_scopes, "iter", 1, params);
  while(1) {
    Object cond176 = callmethod(iter176, "havemore", 0, NULL);
    if (!istrue(cond176)) break;
    params[0] = callmethod(iter176, "next", 0, NULL);
    callmethod(obj178, "apply", 1, params);
  }
// compilenode returning *var_scopes
// Begin line 81
  setline(81);
// compilenode returning *var_ret
  return *var_ret;
}
Object meth_typechecker_apply192(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_sc = alloc_var();
  *var_sc = args[0];
  Object params[1];
  Object *var_name = closure[0];
  Object *var_ret = closure[1];
  Object self = *closure[2];
// Begin line 87
  setline(87);
// Begin line 86
  setline(86);
// compilenode returning *var_name
// compilenode returning *var_sc
  params[0] = *var_name;
  Object call194 = callmethod(*var_sc, "contains",
    1, params);
// compilenode returning call194
  Object if193;
  if (istrue(call194)) {
// Begin line 87
  setline(87);
// compilenode returning *var_name
// compilenode returning *var_sc
  params[0] = *var_name;
  Object call195 = callmethod(*var_sc, "get",
    1, params);
// compilenode returning call195
  *var_ret = call195;
  if (call195 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if193 = nothing;
  } else {
  }
// compilenode returning if193
  return if193;
}
Object meth_typechecker_findName186(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object *var_name = alloc_var();
  *var_name = args[0];
  Object params[1];
  Object *var_scopes = closure[0];
  Object *var_Binding = closure[1];
  Object *var_ret = alloc_var();
  *var_ret = undefined;
// Begin line 85
  setline(85);
// Begin line 84
  setline(84);
  Object bool187 = alloc_Boolean(0);
// compilenode returning bool187
  var_ret = alloc_var();
  *var_ret = bool187;
  if (bool187 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 87
  setline(87);
// Begin line 85
  setline(85);
// compilenode returning *var_scopes
// Begin line 87
  setline(87);
// Begin line 1017
  setline(1017);
  Object obj190 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj190, self, 0);
  addmethod2(obj190, "outer", &reader_typechecker_outer_191);
  adddatum2(obj190, self, 0);
  block_savedest(obj190);
  Object **closure192 = createclosure(3);
  addtoclosure(closure192, var_name);
  addtoclosure(closure192, var_ret);
  Object *selfpp197 = alloc_var();
  *selfpp197 = self;
  addtoclosure(closure192, selfpp197);
  struct UserObject *uo192 = (struct UserObject*)obj190;
  uo192->data[1] = (Object)closure192;
  addmethod2(obj190, "apply", &meth_typechecker_apply192);
  set_type(obj190, 0);
// compilenode returning obj190
  setclassname(obj190, "Block<typechecker:189>");
// compilenode returning obj190
  params[0] = *var_scopes;
  Object iter188 = callmethod(*var_scopes, "iter", 1, params);
  while(1) {
    Object cond188 = callmethod(iter188, "havemore", 0, NULL);
    if (!istrue(cond188)) break;
    params[0] = callmethod(iter188, "next", 0, NULL);
    callmethod(obj190, "apply", 1, params);
  }
// compilenode returning *var_scopes
// Begin line 91
  setline(91);
// Begin line 93
  setline(93);
// Begin line 90
  setline(90);
// compilenode returning *var_ret
  Object bool199 = alloc_Boolean(0);
// compilenode returning bool199
  params[0] = bool199;
  Object opresult201 = callmethod(*var_ret, "==", 1, params);
// compilenode returning opresult201
  Object if198;
  if (istrue(opresult201)) {
// Begin line 91
  setline(91);
  if (strlit202 == NULL) {
    strlit202 = alloc_String("undef");
  }
// compilenode returning strlit202
// compilenode returning *var_Binding
  params[0] = strlit202;
  Object call203 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call203
  *var_ret = call203;
  if (call203 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if198 = nothing;
  } else {
  }
// compilenode returning if198
// Begin line 93
  setline(93);
// compilenode returning *var_ret
  return *var_ret;
}
Object meth_typechecker_findDeepMethod205(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_name = alloc_var();
  *var_name = args[0];
  Object params[2];
  Object *var_scopes = closure[0];
  Object *var_mem = alloc_var();
  *var_mem = undefined;
  Object *var_lv = alloc_var();
  *var_lv = undefined;
  Object *var_min = alloc_var();
  *var_min = undefined;
// Begin line 96
  setline(96);
  if (strlit206 == NULL) {
    strlit206 = alloc_String("self");
  }
// compilenode returning strlit206
  Object bool207 = alloc_Boolean(0);
// compilenode returning bool207
// compilenode returning module_ast
  params[0] = strlit206;
  params[1] = bool207;
  Object call208 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call208
  var_mem = alloc_var();
  *var_mem = call208;
  if (call208 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 98
  setline(98);
// Begin line 1017
  setline(1017);
// Begin line 98
  setline(98);
// Begin line 1017
  setline(1017);
// Begin line 97
  setline(97);
// compilenode returning *var_scopes
  Object call209 = callmethod(*var_scopes, "indices",
    0, params);
// compilenode returning call209
// compilenode returning call209
  Object call210 = callmethod(call209, "last",
    0, params);
// compilenode returning call210
// compilenode returning call210
  var_lv = alloc_var();
  *var_lv = call210;
  if (call210 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 99
  setline(99);
// Begin line 1017
  setline(1017);
// Begin line 99
  setline(99);
// Begin line 1017
  setline(1017);
// Begin line 98
  setline(98);
// compilenode returning *var_scopes
  Object call211 = callmethod(*var_scopes, "indices",
    0, params);
// compilenode returning call211
// compilenode returning call211
  Object call212 = callmethod(call211, "first",
    0, params);
// compilenode returning call212
// compilenode returning call212
  var_min = alloc_var();
  *var_min = call212;
  if (call212 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 108
  setline(108);
  Object while213;
  while (1) {
// Begin line 99
  setline(99);
// Begin line 1017
  setline(1017);
// Begin line 99
  setline(99);
// compilenode returning *var_name
// compilenode returning *var_lv
// compilenode returning *var_scopes
  params[0] = *var_lv;
  Object call214 = callmethod(*var_scopes, "at",
    1, params);
// compilenode returning call214
  params[0] = *var_name;
  Object call215 = callmethod(call214, "contains",
    1, params);
// compilenode returning call215
  Object call216 = callmethod(call215, "not",
    0, params);
// compilenode returning call216
// compilenode returning call216
    while213 = call216;
    if (!istrue(call216)) break;
// Begin line 101
  setline(101);
// Begin line 100
  setline(100);
  if (strlit218 == NULL) {
    strlit218 = alloc_String("___is_object");
  }
// compilenode returning strlit218
// compilenode returning *var_lv
// compilenode returning *var_scopes
  params[0] = *var_lv;
  Object call219 = callmethod(*var_scopes, "at",
    1, params);
// compilenode returning call219
  params[0] = strlit218;
  Object call220 = callmethod(call219, "contains",
    1, params);
// compilenode returning call220
  Object if217;
  if (istrue(call220)) {
// Begin line 101
  setline(101);
  if (strlit221 == NULL) {
    strlit221 = alloc_String("outer");
  }
// compilenode returning strlit221
// compilenode returning *var_mem
// compilenode returning module_ast
  params[0] = strlit221;
  params[1] = *var_mem;
  Object call222 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call222
  *var_mem = call222;
  if (call222 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if217 = nothing;
  } else {
  }
// compilenode returning if217
// Begin line 104
  setline(104);
// Begin line 103
  setline(103);
  if (strlit225 == NULL) {
    strlit225 = alloc_String("___is_class");
  }
// compilenode returning strlit225
// compilenode returning *var_lv
// compilenode returning *var_scopes
  params[0] = *var_lv;
  Object call226 = callmethod(*var_scopes, "at",
    1, params);
// compilenode returning call226
  params[0] = strlit225;
  Object call227 = callmethod(call226, "contains",
    1, params);
// compilenode returning call227
  Object if224;
  if (istrue(call227)) {
// Begin line 104
  setline(104);
  if (strlit228 == NULL) {
    strlit228 = alloc_String("outer");
  }
// compilenode returning strlit228
// compilenode returning *var_mem
// compilenode returning module_ast
  params[0] = strlit228;
  params[1] = *var_mem;
  Object call229 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call229
  *var_mem = call229;
  if (call229 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if224 = nothing;
  } else {
  }
// compilenode returning if224
// Begin line 107
  setline(107);
// Begin line 106
  setline(106);
// compilenode returning *var_lv
  Object num231 = alloc_Float64(1.0);
// compilenode returning num231
  params[0] = num231;
  Object diff233 = callmethod(*var_lv, "-", 1, params);
// compilenode returning diff233
  *var_lv = diff233;
  if (diff233 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 108
  setline(108);
// Begin line 110
  setline(110);
// Begin line 107
  setline(107);
// compilenode returning *var_lv
// compilenode returning *var_min
  params[0] = *var_min;
  Object opresult237 = callmethod(*var_lv, "==", 1, params);
// compilenode returning opresult237
  Object if235;
  if (istrue(opresult237)) {
// Begin line 108
  setline(108);
// compilenode returning *var_name
  Object bool238 = alloc_Boolean(0);
// compilenode returning bool238
// compilenode returning module_ast
  params[0] = *var_name;
  params[1] = bool238;
  Object call239 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call239
  return call239;
// compilenode returning undefined
    if235 = undefined;
  } else {
  }
// compilenode returning if235
  }
// compilenode returning while213
// Begin line 111
  setline(111);
// compilenode returning *var_name
// compilenode returning *var_mem
// compilenode returning module_ast
  params[0] = *var_name;
  params[1] = *var_mem;
  Object call240 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call240
  return call240;
}
Object meth_typechecker_pushScope241(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object params[1];
  Object *var_HashMap = closure[0];
  Object *var_scopes = closure[1];
  Object *var_scope = alloc_var();
  *var_scope = undefined;
// Begin line 1017
  setline(1017);
// Begin line 115
  setline(115);
// compilenode returning *var_HashMap
  Object call242 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call242
// compilenode returning call242
  var_scope = alloc_var();
  *var_scope = call242;
  if (call242 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 116
  setline(116);
// compilenode returning *var_scope
// compilenode returning *var_scopes
  params[0] = *var_scope;
  Object call243 = callmethod(*var_scopes, "push",
    1, params);
// compilenode returning call243
  return call243;
}
Object meth_typechecker_popScope244(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object params[1];
  Object *var_scopes = closure[0];
// Begin line 1017
  setline(1017);
// Begin line 120
  setline(120);
// compilenode returning *var_scopes
  Object call245 = callmethod(*var_scopes, "pop",
    0, params);
// compilenode returning call245
// compilenode returning call245
  return call245;
}
Object meth_typechecker_apply280(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[2];
  Object *var_a = closure[0];
  Object self = *closure[1];
// Begin line 137
  setline(137);
// Begin line 135
  setline(135);
// Begin line 1017
  setline(1017);
// Begin line 135
  setline(135);
// compilenode returning *var_ut
// compilenode returning self
  params[0] = *var_ut;
  Object call282 = callmethod(self, "findType",
    1, params);
// compilenode returning call282
// compilenode returning *var_a
// Begin line 138
  setline(138);
// compilenode returning self
  params[0] = call282;
  params[1] = *var_a;
  Object call283 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call283
  Object call284 = callmethod(call283, "not",
    0, params);
// compilenode returning call284
// compilenode returning call284
  Object if281;
  if (istrue(call284)) {
// Begin line 137
  setline(137);
// Begin line 136
  setline(136);
  Object bool285 = alloc_Boolean(0);
// compilenode returning bool285
  block_return(realself, bool285);
// compilenode returning undefined
    if281 = undefined;
  } else {
  }
// compilenode returning if281
  return if281;
}
Object meth_typechecker_apply299(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[2];
  Object *var_b = closure[0];
  Object self = *closure[1];
// Begin line 145
  setline(145);
// Begin line 143
  setline(143);
// compilenode returning *var_b
// compilenode returning *var_ut
// compilenode returning self
  params[0] = *var_ut;
  Object call301 = callmethod(self, "findType",
    1, params);
// compilenode returning call301
// Begin line 146
  setline(146);
// compilenode returning self
  params[0] = *var_b;
  params[1] = call301;
  Object call302 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call302
  Object if300;
  if (istrue(call302)) {
// Begin line 145
  setline(145);
// Begin line 144
  setline(144);
  Object bool303 = alloc_Boolean(1);
// compilenode returning bool303
  block_return(realself, bool303);
// compilenode returning undefined
    if300 = undefined;
  } else {
  }
// compilenode returning if300
  return if300;
}
Object meth_typechecker_apply322(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m2 = alloc_var();
  *var_m2 = args[0];
  Object params[1];
  Object *var_m1 = closure[0];
  Object *var_found = closure[1];
  Object self = *closure[2];
// Begin line 158
  setline(158);
// Begin line 159
  setline(159);
// Begin line 1017
  setline(1017);
// Begin line 155
  setline(155);
// compilenode returning *var_m2
  Object call324 = callmethod(*var_m2, "value",
    0, params);
// compilenode returning call324
// compilenode returning call324
// Begin line 159
  setline(159);
// Begin line 1017
  setline(1017);
// Begin line 155
  setline(155);
// compilenode returning *var_m1
  Object call325 = callmethod(*var_m1, "value",
    0, params);
// compilenode returning call325
// compilenode returning call325
  params[0] = call325;
  Object opresult327 = callmethod(call324, "==", 1, params);
// compilenode returning opresult327
  Object if323;
  if (istrue(opresult327)) {
  Object *var_rtype2 = alloc_var();
  *var_rtype2 = undefined;
// Begin line 156
  setline(156);
// Begin line 1017
  setline(1017);
// Begin line 156
  setline(156);
// compilenode returning *var_m2
  Object call328 = callmethod(*var_m2, "rtype",
    0, params);
// compilenode returning call328
// compilenode returning call328
// Begin line 157
  setline(157);
// compilenode returning self
  params[0] = call328;
  Object call329 = callmethod(self, "findType",
    1, params);
// compilenode returning call329
  *var_rtype2 = call329;
  if (call329 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 158
  setline(158);
// Begin line 157
  setline(157);
  Object bool330 = alloc_Boolean(1);
// compilenode returning bool330
  *var_found = bool330;
  if (bool330 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if323 = nothing;
  } else {
  }
// compilenode returning if323
  return if323;
}
Object meth_typechecker_apply313(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m1 = alloc_var();
  *var_m1 = args[0];
  Object params[1];
  Object *var_b = closure[0];
  Object self = *closure[1];
  Object *var_rtype1 = alloc_var();
  *var_rtype1 = undefined;
  Object *var_found = alloc_var();
  *var_found = undefined;
// Begin line 152
  setline(152);
// Begin line 1017
  setline(1017);
// Begin line 152
  setline(152);
// compilenode returning *var_m1
  Object call314 = callmethod(*var_m1, "rtype",
    0, params);
// compilenode returning call314
// compilenode returning call314
// Begin line 153
  setline(153);
// compilenode returning self
  params[0] = call314;
  Object call315 = callmethod(self, "findType",
    1, params);
// compilenode returning call315
  *var_rtype1 = call315;
  if (call315 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 154
  setline(154);
// Begin line 153
  setline(153);
  Object bool316 = alloc_Boolean(0);
// compilenode returning bool316
  var_found = alloc_var();
  *var_found = bool316;
  if (bool316 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 158
  setline(158);
// Begin line 160
  setline(160);
// Begin line 1017
  setline(1017);
// Begin line 154
  setline(154);
// compilenode returning *var_b
  Object call318 = callmethod(*var_b, "methods",
    0, params);
// compilenode returning call318
// compilenode returning call318
// Begin line 158
  setline(158);
// Begin line 1017
  setline(1017);
  Object obj320 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj320, self, 0);
  addmethod2(obj320, "outer", &reader_typechecker_outer_321);
  adddatum2(obj320, self, 0);
  block_savedest(obj320);
  Object **closure322 = createclosure(3);
  addtoclosure(closure322, var_m1);
  addtoclosure(closure322, var_found);
  Object *selfpp332 = alloc_var();
  *selfpp332 = self;
  addtoclosure(closure322, selfpp332);
  struct UserObject *uo322 = (struct UserObject*)obj320;
  uo322->data[1] = (Object)closure322;
  addmethod2(obj320, "apply", &meth_typechecker_apply322);
  set_type(obj320, 0);
// compilenode returning obj320
  setclassname(obj320, "Block<typechecker:319>");
// compilenode returning obj320
  params[0] = call318;
  Object iter317 = callmethod(call318, "iter", 1, params);
  while(1) {
    Object cond317 = callmethod(iter317, "havemore", 0, NULL);
    if (!istrue(cond317)) break;
    params[0] = callmethod(iter317, "next", 0, NULL);
    callmethod(obj320, "apply", 1, params);
  }
// compilenode returning call318
// Begin line 162
  setline(162);
// Begin line 163
  setline(163);
// Begin line 160
  setline(160);
// compilenode returning *var_found
  Object call334 = callmethod(*var_found, "prefix!",
    0, params);
// compilenode returning call334
  Object if333;
  if (istrue(call334)) {
// Begin line 162
  setline(162);
// Begin line 161
  setline(161);
  Object bool335 = alloc_Boolean(0);
// compilenode returning bool335
  block_return(realself, bool335);
// compilenode returning undefined
    if333 = undefined;
  } else {
  }
// compilenode returning if333
  return if333;
}
Object meth_typechecker_conformsType_40_1_41_to246(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_b = alloc_var();
  *var_b = args[0];
  Object *var_a = alloc_var();
  *var_a = args[1];
  Object params[2];
  Object *var_foundall = alloc_var();
  *var_foundall = undefined;
// Begin line 126
  setline(126);
// Begin line 127
  setline(127);
// Begin line 124
  setline(124);
// compilenode returning *var_b
  Object bool248 = alloc_Boolean(0);
// compilenode returning bool248
  params[0] = bool248;
  Object opresult250 = callmethod(*var_b, "==", 1, params);
// compilenode returning opresult250
// Begin line 127
  setline(127);
// Begin line 124
  setline(124);
// compilenode returning *var_a
  Object bool251 = alloc_Boolean(0);
// compilenode returning bool251
  params[0] = bool251;
  Object opresult253 = callmethod(*var_a, "==", 1, params);
// compilenode returning opresult253
  params[0] = opresult253;
  Object opresult255 = callmethod(opresult250, "|", 1, params);
// compilenode returning opresult255
  Object if247;
  if (istrue(opresult255)) {
// Begin line 126
  setline(126);
// Begin line 125
  setline(125);
  Object bool256 = alloc_Boolean(1);
// compilenode returning bool256
  return bool256;
// compilenode returning undefined
    if247 = undefined;
  } else {
  }
// compilenode returning if247
// Begin line 129
  setline(129);
// Begin line 130
  setline(130);
// Begin line 1017
  setline(1017);
// Begin line 127
  setline(127);
// compilenode returning *var_a
  Object call258 = callmethod(*var_a, "value",
    0, params);
// compilenode returning call258
// compilenode returning call258
  if (strlit259 == NULL) {
    strlit259 = alloc_String("Dynamic");
  }
// compilenode returning strlit259
  params[0] = strlit259;
  Object opresult261 = callmethod(call258, "==", 1, params);
// compilenode returning opresult261
  Object if257;
  if (istrue(opresult261)) {
// Begin line 129
  setline(129);
// Begin line 128
  setline(128);
  Object bool262 = alloc_Boolean(1);
// compilenode returning bool262
  return bool262;
// compilenode returning undefined
    if257 = undefined;
  } else {
  }
// compilenode returning if257
// Begin line 132
  setline(132);
// Begin line 133
  setline(133);
// Begin line 1017
  setline(1017);
// Begin line 130
  setline(130);
// compilenode returning *var_b
  Object call264 = callmethod(*var_b, "value",
    0, params);
// compilenode returning call264
// compilenode returning call264
  if (strlit265 == NULL) {
    strlit265 = alloc_String("Dynamic");
  }
// compilenode returning strlit265
  params[0] = strlit265;
  Object opresult267 = callmethod(call264, "==", 1, params);
// compilenode returning opresult267
  Object if263;
  if (istrue(opresult267)) {
// Begin line 132
  setline(132);
// Begin line 131
  setline(131);
  Object bool268 = alloc_Boolean(1);
// compilenode returning bool268
  return bool268;
// compilenode returning undefined
    if263 = undefined;
  } else {
  }
// compilenode returning if263
// Begin line 140
  setline(140);
// Begin line 141
  setline(141);
// Begin line 1017
  setline(1017);
// Begin line 141
  setline(141);
// Begin line 1017
  setline(1017);
// Begin line 133
  setline(133);
// compilenode returning *var_b
  Object call270 = callmethod(*var_b, "unionTypes",
    0, params);
// compilenode returning call270
// compilenode returning call270
  Object call271 = callmethod(call270, "size",
    0, params);
// compilenode returning call271
// compilenode returning call271
  Object num272 = alloc_Float64(0.0);
// compilenode returning num272
  params[0] = num272;
  Object opresult274 = callmethod(call271, ">", 1, params);
// compilenode returning opresult274
  Object if269;
  if (istrue(opresult274)) {
// Begin line 137
  setline(137);
// Begin line 139
  setline(139);
// Begin line 1017
  setline(1017);
// Begin line 134
  setline(134);
// compilenode returning *var_b
  Object call276 = callmethod(*var_b, "unionTypes",
    0, params);
// compilenode returning call276
// compilenode returning call276
// Begin line 137
  setline(137);
// Begin line 1017
  setline(1017);
  Object obj278 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj278, self, 0);
  addmethod2(obj278, "outer", &reader_typechecker_outer_279);
  adddatum2(obj278, self, 0);
  block_savedest(obj278);
  Object **closure280 = createclosure(2);
  addtoclosure(closure280, var_a);
  Object *selfpp286 = alloc_var();
  *selfpp286 = self;
  addtoclosure(closure280, selfpp286);
  struct UserObject *uo280 = (struct UserObject*)obj278;
  uo280->data[1] = (Object)closure280;
  addmethod2(obj278, "apply", &meth_typechecker_apply280);
  set_type(obj278, 0);
// compilenode returning obj278
  setclassname(obj278, "Block<typechecker:277>");
// compilenode returning obj278
  params[0] = call276;
  Object iter275 = callmethod(call276, "iter", 1, params);
  while(1) {
    Object cond275 = callmethod(iter275, "havemore", 0, NULL);
    if (!istrue(cond275)) break;
    params[0] = callmethod(iter275, "next", 0, NULL);
    callmethod(obj278, "apply", 1, params);
  }
// compilenode returning call276
// Begin line 140
  setline(140);
// Begin line 139
  setline(139);
  Object bool287 = alloc_Boolean(1);
// compilenode returning bool287
  return bool287;
// compilenode returning undefined
    if269 = undefined;
  } else {
  }
// compilenode returning if269
// Begin line 148
  setline(148);
// Begin line 149
  setline(149);
// Begin line 1017
  setline(1017);
// Begin line 149
  setline(149);
// Begin line 1017
  setline(1017);
// Begin line 141
  setline(141);
// compilenode returning *var_a
  Object call289 = callmethod(*var_a, "unionTypes",
    0, params);
// compilenode returning call289
// compilenode returning call289
  Object call290 = callmethod(call289, "size",
    0, params);
// compilenode returning call290
// compilenode returning call290
  Object num291 = alloc_Float64(0.0);
// compilenode returning num291
  params[0] = num291;
  Object opresult293 = callmethod(call290, ">", 1, params);
// compilenode returning opresult293
  Object if288;
  if (istrue(opresult293)) {
// Begin line 145
  setline(145);
// Begin line 147
  setline(147);
// Begin line 1017
  setline(1017);
// Begin line 142
  setline(142);
// compilenode returning *var_a
  Object call295 = callmethod(*var_a, "unionTypes",
    0, params);
// compilenode returning call295
// compilenode returning call295
// Begin line 145
  setline(145);
// Begin line 1017
  setline(1017);
  Object obj297 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj297, self, 0);
  addmethod2(obj297, "outer", &reader_typechecker_outer_298);
  adddatum2(obj297, self, 0);
  block_savedest(obj297);
  Object **closure299 = createclosure(2);
  addtoclosure(closure299, var_b);
  Object *selfpp304 = alloc_var();
  *selfpp304 = self;
  addtoclosure(closure299, selfpp304);
  struct UserObject *uo299 = (struct UserObject*)obj297;
  uo299->data[1] = (Object)closure299;
  addmethod2(obj297, "apply", &meth_typechecker_apply299);
  set_type(obj297, 0);
// compilenode returning obj297
  setclassname(obj297, "Block<typechecker:296>");
// compilenode returning obj297
  params[0] = call295;
  Object iter294 = callmethod(call295, "iter", 1, params);
  while(1) {
    Object cond294 = callmethod(iter294, "havemore", 0, NULL);
    if (!istrue(cond294)) break;
    params[0] = callmethod(iter294, "next", 0, NULL);
    callmethod(obj297, "apply", 1, params);
  }
// compilenode returning call295
// Begin line 148
  setline(148);
// Begin line 147
  setline(147);
  Object bool305 = alloc_Boolean(0);
// compilenode returning bool305
  return bool305;
// compilenode returning undefined
    if288 = undefined;
  } else {
  }
// compilenode returning if288
// Begin line 149
  setline(149);
// compilenode returning *var_b
// compilenode returning *var_a
// compilenode returning module_subtype
  params[0] = *var_b;
  params[1] = *var_a;
  Object call306 = callmethod(module_subtype, "conformsType(1)to",
    2, params);
// compilenode returning call306
  return call306;
// compilenode returning undefined
// Begin line 151
  setline(151);
// Begin line 150
  setline(150);
  Object bool307 = alloc_Boolean(1);
// compilenode returning bool307
  var_foundall = alloc_var();
  *var_foundall = bool307;
  if (bool307 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 162
  setline(162);
// Begin line 164
  setline(164);
// Begin line 1017
  setline(1017);
// Begin line 151
  setline(151);
// compilenode returning *var_a
  Object call309 = callmethod(*var_a, "methods",
    0, params);
// compilenode returning call309
// compilenode returning call309
// Begin line 162
  setline(162);
// Begin line 1017
  setline(1017);
  Object obj311 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj311, self, 0);
  addmethod2(obj311, "outer", &reader_typechecker_outer_312);
  adddatum2(obj311, self, 0);
  block_savedest(obj311);
  Object **closure313 = createclosure(2);
  addtoclosure(closure313, var_b);
  Object *selfpp336 = alloc_var();
  *selfpp336 = self;
  addtoclosure(closure313, selfpp336);
  struct UserObject *uo313 = (struct UserObject*)obj311;
  uo313->data[1] = (Object)closure313;
  addmethod2(obj311, "apply", &meth_typechecker_apply313);
  set_type(obj311, 0);
// compilenode returning obj311
  setclassname(obj311, "Block<typechecker:310>");
// compilenode returning obj311
  params[0] = call309;
  Object iter308 = callmethod(call309, "iter", 1, params);
  while(1) {
    Object cond308 = callmethod(iter308, "havemore", 0, NULL);
    if (!istrue(cond308)) break;
    params[0] = callmethod(iter308, "next", 0, NULL);
    callmethod(obj311, "apply", 1, params);
  }
// compilenode returning call309
// Begin line 165
  setline(165);
// Begin line 164
  setline(164);
  Object bool337 = alloc_Boolean(1);
// compilenode returning bool337
  return bool337;
// compilenode returning undefined
  return undefined;
}
Object meth_typechecker_apply381(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_gt = alloc_var();
  *var_gt = args[0];
  Object params[3];
  Object *var_gitype = closure[0];
  Object *var_DynamicType = closure[1];
  Object self = *closure[2];
// Begin line 177
  setline(177);
// compilenode returning *var_gitype
// compilenode returning *var_gt
// compilenode returning *var_DynamicType
// Begin line 178
  setline(178);
// compilenode returning self
  params[0] = *var_gitype;
  params[1] = *var_gt;
  params[2] = *var_DynamicType;
  Object call382 = callmethod(self, "betaReduceType",
    3, params);
// compilenode returning call382
  *var_gitype = call382;
  if (call382 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_typechecker_apply424(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m = alloc_var();
  *var_m = args[0];
  Object params[1];
  Object *var_opname = closure[0];
  Object *var_opfound = closure[1];
  Object *var_opmeth = closure[2];
  Object self = *closure[3];
// Begin line 209
  setline(209);
// Begin line 210
  setline(210);
// Begin line 1017
  setline(1017);
// Begin line 206
  setline(206);
// compilenode returning *var_m
  Object call426 = callmethod(*var_m, "value",
    0, params);
// compilenode returning call426
// compilenode returning call426
// compilenode returning *var_opname
  params[0] = *var_opname;
  Object opresult428 = callmethod(call426, "==", 1, params);
// compilenode returning opresult428
  Object if425;
  if (istrue(opresult428)) {
// Begin line 208
  setline(208);
// Begin line 207
  setline(207);
  Object bool429 = alloc_Boolean(1);
// compilenode returning bool429
  *var_opfound = bool429;
  if (bool429 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 209
  setline(209);
// Begin line 208
  setline(208);
// compilenode returning *var_m
  *var_opmeth = *var_m;
  if (*var_m == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if425 = nothing;
  } else {
  }
// compilenode returning if425
  return if425;
}
Object meth_typechecker_apply500(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m = alloc_var();
  *var_m = args[0];
  Object params[1];
  Object *var_memname = closure[0];
  Object *var_memfound = closure[1];
  Object *var_memmeth = closure[2];
  Object self = *closure[3];
// Begin line 241
  setline(241);
// Begin line 242
  setline(242);
// Begin line 1017
  setline(1017);
// Begin line 238
  setline(238);
// compilenode returning *var_m
  Object call502 = callmethod(*var_m, "value",
    0, params);
// compilenode returning call502
// compilenode returning call502
// compilenode returning *var_memname
  params[0] = *var_memname;
  Object opresult504 = callmethod(call502, "==", 1, params);
// compilenode returning opresult504
  Object if501;
  if (istrue(opresult504)) {
// Begin line 240
  setline(240);
// Begin line 239
  setline(239);
  Object bool505 = alloc_Boolean(1);
// compilenode returning bool505
  *var_memfound = bool505;
  if (bool505 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 241
  setline(241);
// Begin line 240
  setline(240);
// compilenode returning *var_m
  *var_memmeth = *var_m;
  if (*var_m == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if501 = nothing;
  } else {
  }
// compilenode returning if501
  return if501;
}
Object meth_typechecker_apply592(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m = alloc_var();
  *var_m = args[0];
  Object params[1];
  Object *var_callname = closure[0];
  Object *var_callfound = closure[1];
  Object *var_callmeth = closure[2];
  Object self = *closure[3];
// Begin line 277
  setline(277);
// Begin line 278
  setline(278);
// Begin line 1017
  setline(1017);
// Begin line 274
  setline(274);
// compilenode returning *var_m
  Object call594 = callmethod(*var_m, "value",
    0, params);
// compilenode returning call594
// compilenode returning call594
// compilenode returning *var_callname
  params[0] = *var_callname;
  Object opresult596 = callmethod(call594, "==", 1, params);
// compilenode returning opresult596
  Object if593;
  if (istrue(opresult596)) {
// Begin line 276
  setline(276);
// Begin line 275
  setline(275);
  Object bool597 = alloc_Boolean(1);
// compilenode returning bool597
  *var_callfound = bool597;
  if (bool597 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 277
  setline(277);
// Begin line 276
  setline(276);
// compilenode returning *var_m
  *var_callmeth = *var_m;
  if (*var_m == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if593 = nothing;
  } else {
  }
// compilenode returning if593
  return if593;
}
Object meth_typechecker_apply673(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[2];
  Object *var_callargs = closure[0];
  Object *var_callparams = closure[1];
  Object *var_callname = closure[2];
  Object self = *closure[3];
  Object *var_arg = alloc_var();
  *var_arg = undefined;
  Object *var_prm = alloc_var();
  *var_prm = undefined;
  Object *var_argtp = alloc_var();
  *var_argtp = undefined;
  Object *var_prmtypeid = alloc_var();
  *var_prmtypeid = undefined;
  Object *var_prmtype = alloc_var();
  *var_prmtype = undefined;
// Begin line 293
  setline(293);
// compilenode returning *var_i
// compilenode returning *var_callargs
  params[0] = *var_i;
  Object call674 = callmethod(*var_callargs, "at",
    1, params);
// compilenode returning call674
  *var_arg = call674;
  if (call674 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 294
  setline(294);
// compilenode returning *var_i
// compilenode returning *var_callparams
  params[0] = *var_i;
  Object call675 = callmethod(*var_callparams, "at",
    1, params);
// compilenode returning call675
  *var_prm = call675;
  if (call675 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 295
  setline(295);
// compilenode returning *var_arg
// Begin line 296
  setline(296);
// compilenode returning self
  params[0] = *var_arg;
  Object call676 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call676
  *var_argtp = call676;
  if (call676 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 297
  setline(297);
// Begin line 1017
  setline(1017);
// Begin line 296
  setline(296);
// compilenode returning *var_prm
  Object call677 = callmethod(*var_prm, "dtype",
    0, params);
// compilenode returning call677
// compilenode returning call677
  *var_prmtypeid = call677;
  if (call677 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 297
  setline(297);
// compilenode returning *var_prmtypeid
// Begin line 298
  setline(298);
// compilenode returning self
  params[0] = *var_prmtypeid;
  Object call678 = callmethod(self, "findType",
    1, params);
// compilenode returning call678
  *var_prmtype = call678;
  if (call678 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 300
  setline(300);
// Begin line 298
  setline(298);
// Begin line 1017
  setline(1017);
// Begin line 298
  setline(298);
// compilenode returning *var_argtp
// compilenode returning *var_prmtype
// Begin line 302
  setline(302);
// compilenode returning self
  params[0] = *var_argtp;
  params[1] = *var_prmtype;
  Object call680 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call680
  Object call681 = callmethod(call680, "not",
    0, params);
// compilenode returning call681
// compilenode returning call681
  Object if679;
  if (istrue(call681)) {
// Begin line 300
  setline(300);
// Begin line 299
  setline(299);
  if (strlit682 == NULL) {
    strlit682 = alloc_String("argument ");
  }
// compilenode returning strlit682
// compilenode returning *var_i
  params[0] = *var_i;
  Object opresult684 = callmethod(strlit682, "++", 1, params);
// compilenode returning opresult684
  if (strlit685 == NULL) {
    strlit685 = alloc_String(" of '");
  }
// compilenode returning strlit685
  params[0] = strlit685;
  Object opresult687 = callmethod(opresult684, "++", 1, params);
// compilenode returning opresult687
// compilenode returning *var_callname
  params[0] = *var_callname;
  Object opresult689 = callmethod(opresult687, "++", 1, params);
// compilenode returning opresult689
  if (strlit690 == NULL) {
    strlit690 = alloc_String("' must be of ");
  }
// compilenode returning strlit690
  params[0] = strlit690;
  Object opresult692 = callmethod(opresult689, "++", 1, params);
// compilenode returning opresult692
// Begin line 300
  setline(300);
  if (strlit693 == NULL) {
    strlit693 = alloc_String("type ");
  }
// compilenode returning strlit693
// Begin line 1017
  setline(1017);
// Begin line 300
  setline(300);
// compilenode returning *var_prmtype
  Object call694 = callmethod(*var_prmtype, "value",
    0, params);
// compilenode returning call694
// compilenode returning call694
  params[0] = call694;
  Object opresult696 = callmethod(strlit693, "++", 1, params);
// compilenode returning opresult696
  if (strlit697 == NULL) {
    strlit697 = alloc_String(", given ");
  }
// compilenode returning strlit697
  params[0] = strlit697;
  Object opresult699 = callmethod(opresult696, "++", 1, params);
// compilenode returning opresult699
// Begin line 1017
  setline(1017);
// Begin line 300
  setline(300);
// compilenode returning *var_argtp
  Object call700 = callmethod(*var_argtp, "value",
    0, params);
// compilenode returning call700
// compilenode returning call700
  params[0] = call700;
  Object opresult702 = callmethod(opresult699, "++", 1, params);
// compilenode returning opresult702
  if (strlit703 == NULL) {
    strlit703 = alloc_String("");
  }
// compilenode returning strlit703
  params[0] = strlit703;
  Object opresult705 = callmethod(opresult702, "++", 1, params);
// compilenode returning opresult705
  params[0] = opresult705;
  Object opresult707 = callmethod(opresult692, "++", 1, params);
// compilenode returning opresult707
// Begin line 299
  setline(299);
// compilenode returning module_util
  params[0] = opresult707;
  Object call708 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call708
    if679 = call708;
  } else {
  }
// compilenode returning if679
  return if679;
}
Object meth_typechecker_apply745(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object *var_objectmeths = closure[0];
  Object self = *closure[1];
// Begin line 317
  setline(317);
// compilenode returning *var_e
// compilenode returning *var_objectmeths
  params[0] = *var_e;
  Object call746 = callmethod(*var_objectmeths, "push",
    1, params);
// compilenode returning call746
  return call746;
}
Object meth_typechecker_apply753(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[3];
  Object *var_objectmeths = closure[0];
  Object self = *closure[1];
// Begin line 333
  setline(333);
// Begin line 335
  setline(335);
// Begin line 1017
  setline(1017);
// Begin line 321
  setline(321);
// compilenode returning *var_e
  Object call755 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call755
// compilenode returning call755
  if (strlit756 == NULL) {
    strlit756 = alloc_String("defdec");
  }
// compilenode returning strlit756
  params[0] = strlit756;
  Object opresult758 = callmethod(call755, "==", 1, params);
// compilenode returning opresult758
  Object if754;
  if (istrue(opresult758)) {
// Begin line 323
  setline(323);
// Begin line 322
  setline(322);
// Begin line 1017
  setline(1017);
// Begin line 322
  setline(322);
// Begin line 1017
  setline(1017);
// Begin line 322
  setline(322);
// compilenode returning *var_e
  Object call759 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call759
// compilenode returning call759
  Object call760 = callmethod(call759, "value",
    0, params);
// compilenode returning call760
// compilenode returning call760
  Object array761 = alloc_List();
// compilenode returning array761
// Begin line 323
  setline(323);
// Begin line 1017
  setline(1017);
// Begin line 323
  setline(323);
// compilenode returning *var_e
  Object call762 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call762
// compilenode returning call762
// compilenode returning self
  params[0] = call762;
  Object call763 = callmethod(self, "findType",
    1, params);
// compilenode returning call763
// Begin line 322
  setline(322);
// compilenode returning module_ast
  params[0] = call760;
  params[1] = array761;
  params[2] = call763;
  Object call764 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call764
// compilenode returning *var_objectmeths
  params[0] = call764;
  Object call765 = callmethod(*var_objectmeths, "push",
    1, params);
// compilenode returning call765
    if754 = call765;
  } else {
// Begin line 333
  setline(333);
// Begin line 327
  setline(327);
// Begin line 1017
  setline(1017);
// Begin line 324
  setline(324);
// compilenode returning *var_e
  Object call767 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call767
// compilenode returning call767
  if (strlit768 == NULL) {
    strlit768 = alloc_String("method");
  }
// compilenode returning strlit768
  params[0] = strlit768;
  Object opresult770 = callmethod(call767, "==", 1, params);
// compilenode returning opresult770
  Object if766;
  if (istrue(opresult770)) {
// Begin line 326
  setline(326);
// Begin line 325
  setline(325);
// Begin line 1017
  setline(1017);
// Begin line 325
  setline(325);
// Begin line 1017
  setline(1017);
// Begin line 325
  setline(325);
// compilenode returning *var_e
  Object call771 = callmethod(*var_e, "value",
    0, params);
// compilenode returning call771
// compilenode returning call771
  Object call772 = callmethod(call771, "value",
    0, params);
// compilenode returning call772
// compilenode returning call772
// Begin line 1017
  setline(1017);
// Begin line 325
  setline(325);
// compilenode returning *var_e
  Object call773 = callmethod(*var_e, "params",
    0, params);
// compilenode returning call773
// compilenode returning call773
// Begin line 326
  setline(326);
// Begin line 1017
  setline(1017);
// Begin line 326
  setline(326);
// compilenode returning *var_e
  Object call774 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call774
// compilenode returning call774
// compilenode returning self
  params[0] = call774;
  Object call775 = callmethod(self, "findType",
    1, params);
// compilenode returning call775
// Begin line 325
  setline(325);
// compilenode returning module_ast
  params[0] = call772;
  params[1] = call773;
  params[2] = call775;
  Object call776 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call776
// compilenode returning *var_objectmeths
  params[0] = call776;
  Object call777 = callmethod(*var_objectmeths, "push",
    1, params);
// compilenode returning call777
    if766 = call777;
  } else {
// Begin line 333
  setline(333);
// Begin line 335
  setline(335);
// Begin line 1017
  setline(1017);
// Begin line 327
  setline(327);
// compilenode returning *var_e
  Object call779 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call779
// compilenode returning call779
  if (strlit780 == NULL) {
    strlit780 = alloc_String("vardec");
  }
// compilenode returning strlit780
  params[0] = strlit780;
  Object opresult782 = callmethod(call779, "==", 1, params);
// compilenode returning opresult782
  Object if778;
  if (istrue(opresult782)) {
  Object *var_vtype = alloc_var();
  *var_vtype = undefined;
// Begin line 328
  setline(328);
// Begin line 1017
  setline(1017);
// Begin line 328
  setline(328);
// compilenode returning *var_e
  Object call783 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call783
// compilenode returning call783
// Begin line 329
  setline(329);
// compilenode returning self
  params[0] = call783;
  Object call784 = callmethod(self, "findType",
    1, params);
// compilenode returning call784
  *var_vtype = call784;
  if (call784 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 330
  setline(330);
// Begin line 329
  setline(329);
// Begin line 1017
  setline(1017);
// Begin line 329
  setline(329);
// Begin line 1017
  setline(1017);
// Begin line 329
  setline(329);
// compilenode returning *var_e
  Object call785 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call785
// compilenode returning call785
  Object call786 = callmethod(call785, "value",
    0, params);
// compilenode returning call786
// compilenode returning call786
  Object array787 = alloc_List();
// compilenode returning array787
// Begin line 330
  setline(330);
// compilenode returning *var_vtype
// Begin line 329
  setline(329);
// compilenode returning module_ast
  params[0] = call786;
  params[1] = array787;
  params[2] = *var_vtype;
  Object call788 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call788
// compilenode returning *var_objectmeths
  params[0] = call788;
  Object call789 = callmethod(*var_objectmeths, "push",
    1, params);
// compilenode returning call789
// Begin line 333
  setline(333);
// Begin line 331
  setline(331);
// Begin line 1017
  setline(1017);
// Begin line 331
  setline(331);
// Begin line 1017
  setline(1017);
// Begin line 331
  setline(331);
// compilenode returning *var_e
  Object call790 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call790
// compilenode returning call790
  Object call791 = callmethod(call790, "value",
    0, params);
// compilenode returning call791
// compilenode returning call791
  if (strlit792 == NULL) {
    strlit792 = alloc_String(":=");
  }
// compilenode returning strlit792
  params[0] = strlit792;
  Object opresult794 = callmethod(call791, "++", 1, params);
// compilenode returning opresult794
// Begin line 332
  setline(332);
  Object array795 = alloc_List();
  if (strlit796 == NULL) {
    strlit796 = alloc_String("_");
  }
// compilenode returning strlit796
// compilenode returning *var_vtype
// compilenode returning module_ast
  params[0] = strlit796;
  params[1] = *var_vtype;
  Object call797 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call797
  params[0] = call797;
  callmethod(array795, "push", 1, params);
// compilenode returning array795
// Begin line 333
  setline(333);
  Object bool798 = alloc_Boolean(0);
// compilenode returning bool798
// Begin line 331
  setline(331);
// compilenode returning module_ast
  params[0] = opresult794;
  params[1] = array795;
  params[2] = bool798;
  Object call799 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call799
// compilenode returning *var_objectmeths
  params[0] = call799;
  Object call800 = callmethod(*var_objectmeths, "push",
    1, params);
// compilenode returning call800
    if778 = call800;
  } else {
  }
// compilenode returning if778
    if766 = if778;
  }
// compilenode returning if766
    if754 = if766;
  }
// compilenode returning if754
  return if754;
}
Object meth_typechecker_apply845(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[3];
  Object *var_gtb = closure[0];
  Object *var_expr = closure[1];
  Object *var_gtype = closure[2];
  Object self = *closure[3];
  Object *var_tv = alloc_var();
  *var_tv = undefined;
  Object *var_ct = alloc_var();
  *var_ct = undefined;
// Begin line 356
  setline(356);
// compilenode returning *var_i
// Begin line 357
  setline(357);
// Begin line 1017
  setline(1017);
// Begin line 356
  setline(356);
// compilenode returning *var_gtb
  Object call846 = callmethod(*var_gtb, "generics",
    0, params);
// compilenode returning call846
// compilenode returning call846
  params[0] = *var_i;
  Object call847 = callmethod(call846, "at",
    1, params);
// compilenode returning call847
  *var_tv = call847;
  if (call847 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 357
  setline(357);
// compilenode returning *var_i
// Begin line 1017
  setline(1017);
// Begin line 357
  setline(357);
// compilenode returning *var_expr
  Object call848 = callmethod(*var_expr, "params",
    0, params);
// compilenode returning call848
// compilenode returning call848
  params[0] = *var_i;
  Object call849 = callmethod(call848, "at",
    1, params);
// compilenode returning call849
// Begin line 358
  setline(358);
// compilenode returning self
  params[0] = call849;
  Object call850 = callmethod(self, "findType",
    1, params);
// compilenode returning call850
  *var_ct = call850;
  if (call850 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_gtype
// compilenode returning *var_tv
// compilenode returning *var_ct
// Begin line 359
  setline(359);
// compilenode returning self
  params[0] = *var_gtype;
  params[1] = *var_tv;
  params[2] = *var_ct;
  Object call851 = callmethod(self, "betaReduceType",
    3, params);
// compilenode returning call851
  *var_gtype = call851;
  if (call851 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_typechecker_expressionType338(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_expr = alloc_var();
  *var_expr = args[0];
  Object params[2];
  Object *var_BooleanType = closure[0];
  Object *var_DynamicType = closure[1];
  Object *var_NumberType = closure[2];
  Object *var_StringType = closure[3];
// Begin line 184
  setline(184);
// Begin line 185
  setline(185);
// Begin line 1017
  setline(1017);
// Begin line 168
  setline(168);
// compilenode returning *var_expr
  Object call340 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call340
// compilenode returning call340
  if (strlit341 == NULL) {
    strlit341 = alloc_String("identifier");
  }
// compilenode returning strlit341
  params[0] = strlit341;
  Object opresult343 = callmethod(call340, "==", 1, params);
// compilenode returning opresult343
  Object if339;
  if (istrue(opresult343)) {
// Begin line 171
  setline(171);
// Begin line 172
  setline(172);
// Begin line 1017
  setline(1017);
// Begin line 169
  setline(169);
// compilenode returning *var_expr
  Object call345 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call345
// compilenode returning call345
  if (strlit346 == NULL) {
    strlit346 = alloc_String("true");
  }
// compilenode returning strlit346
  params[0] = strlit346;
  Object opresult348 = callmethod(call345, "==", 1, params);
// compilenode returning opresult348
// Begin line 172
  setline(172);
// Begin line 1017
  setline(1017);
// Begin line 169
  setline(169);
// compilenode returning *var_expr
  Object call349 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call349
// compilenode returning call349
  if (strlit350 == NULL) {
    strlit350 = alloc_String("false");
  }
// compilenode returning strlit350
  params[0] = strlit350;
  Object opresult352 = callmethod(call349, "==", 1, params);
// compilenode returning opresult352
  params[0] = opresult352;
  Object opresult354 = callmethod(opresult348, "|", 1, params);
// compilenode returning opresult354
  Object if344;
  if (istrue(opresult354)) {
// Begin line 171
  setline(171);
// Begin line 170
  setline(170);
// compilenode returning *var_BooleanType
  return *var_BooleanType;
// compilenode returning undefined
    if344 = undefined;
  } else {
  }
// compilenode returning if344
// Begin line 180
  setline(180);
// Begin line 183
  setline(183);
// Begin line 1017
  setline(1017);
// Begin line 172
  setline(172);
// compilenode returning *var_expr
  Object call356 = callmethod(*var_expr, "dtype",
    0, params);
// compilenode returning call356
// compilenode returning call356
  Object bool357 = alloc_Boolean(0);
// compilenode returning bool357
  params[0] = bool357;
  Object opresult359 = callmethod(call356, "/=", 1, params);
// compilenode returning opresult359
  Object if355;
  if (istrue(opresult359)) {
// Begin line 180
  setline(180);
// Begin line 182
  setline(182);
// Begin line 1017
  setline(1017);
// Begin line 182
  setline(182);
// Begin line 1017
  setline(1017);
// Begin line 173
  setline(173);
// compilenode returning *var_expr
  Object call361 = callmethod(*var_expr, "dtype",
    0, params);
// compilenode returning call361
// compilenode returning call361
  Object call362 = callmethod(call361, "kind",
    0, params);
// compilenode returning call362
// compilenode returning call362
  if (strlit363 == NULL) {
    strlit363 = alloc_String("type");
  }
// compilenode returning strlit363
  params[0] = strlit363;
  Object opresult365 = callmethod(call362, "==", 1, params);
// compilenode returning opresult365
  Object if360;
  if (istrue(opresult365)) {
// Begin line 180
  setline(180);
// Begin line 181
  setline(181);
// Begin line 1017
  setline(1017);
// Begin line 181
  setline(181);
// Begin line 1017
  setline(1017);
// Begin line 181
  setline(181);
// Begin line 1017
  setline(1017);
// Begin line 174
  setline(174);
// compilenode returning *var_expr
  Object call367 = callmethod(*var_expr, "dtype",
    0, params);
// compilenode returning call367
// compilenode returning call367
  Object call368 = callmethod(call367, "generics",
    0, params);
// compilenode returning call368
// compilenode returning call368
  Object call369 = callmethod(call368, "size",
    0, params);
// compilenode returning call369
// compilenode returning call369
  Object num370 = alloc_Float64(0.0);
// compilenode returning num370
  params[0] = num370;
  Object opresult372 = callmethod(call369, ">", 1, params);
// compilenode returning opresult372
  Object if366;
  if (istrue(opresult372)) {
  Object *var_gitype = alloc_var();
  *var_gitype = undefined;
// Begin line 175
  setline(175);
// Begin line 1017
  setline(1017);
// Begin line 175
  setline(175);
// compilenode returning *var_expr
  Object call373 = callmethod(*var_expr, "dtype",
    0, params);
// compilenode returning call373
// compilenode returning call373
// Begin line 176
  setline(176);
// compilenode returning self
  params[0] = call373;
  Object call374 = callmethod(self, "findType",
    1, params);
// compilenode returning call374
  var_gitype = alloc_var();
  *var_gitype = call374;
  if (call374 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 177
  setline(177);
// Begin line 179
  setline(179);
// Begin line 1017
  setline(1017);
// Begin line 179
  setline(179);
// Begin line 1017
  setline(1017);
// Begin line 176
  setline(176);
// compilenode returning *var_expr
  Object call376 = callmethod(*var_expr, "dtype",
    0, params);
// compilenode returning call376
// compilenode returning call376
  Object call377 = callmethod(call376, "generics",
    0, params);
// compilenode returning call377
// compilenode returning call377
// Begin line 177
  setline(177);
// Begin line 1017
  setline(1017);
  Object obj379 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj379, self, 0);
  addmethod2(obj379, "outer", &reader_typechecker_outer_380);
  adddatum2(obj379, self, 0);
  block_savedest(obj379);
  Object **closure381 = createclosure(3);
  addtoclosure(closure381, var_gitype);
  addtoclosure(closure381, var_DynamicType);
  Object *selfpp384 = alloc_var();
  *selfpp384 = self;
  addtoclosure(closure381, selfpp384);
  struct UserObject *uo381 = (struct UserObject*)obj379;
  uo381->data[1] = (Object)closure381;
  addmethod2(obj379, "apply", &meth_typechecker_apply381);
  set_type(obj379, 0);
// compilenode returning obj379
  setclassname(obj379, "Block<typechecker:378>");
// compilenode returning obj379
  params[0] = call377;
  Object iter375 = callmethod(call377, "iter", 1, params);
  while(1) {
    Object cond375 = callmethod(iter375, "havemore", 0, NULL);
    if (!istrue(cond375)) break;
    params[0] = callmethod(iter375, "next", 0, NULL);
    callmethod(obj379, "apply", 1, params);
  }
// compilenode returning call377
// Begin line 180
  setline(180);
// Begin line 179
  setline(179);
// compilenode returning *var_gitype
  return *var_gitype;
// compilenode returning undefined
    if366 = undefined;
  } else {
  }
// compilenode returning if366
    if360 = if366;
  } else {
  }
// compilenode returning if360
    if355 = if360;
  } else {
  }
// compilenode returning if355
// Begin line 184
  setline(184);
// Begin line 1017
  setline(1017);
// Begin line 183
  setline(183);
// compilenode returning *var_expr
  Object call385 = callmethod(*var_expr, "dtype",
    0, params);
// compilenode returning call385
// compilenode returning call385
  return call385;
// compilenode returning undefined
    if339 = undefined;
  } else {
  }
// compilenode returning if339
// Begin line 187
  setline(187);
// Begin line 188
  setline(188);
// Begin line 1017
  setline(1017);
// Begin line 185
  setline(185);
// compilenode returning *var_expr
  Object call387 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call387
// compilenode returning call387
  if (strlit388 == NULL) {
    strlit388 = alloc_String("num");
  }
// compilenode returning strlit388
  params[0] = strlit388;
  Object opresult390 = callmethod(call387, "==", 1, params);
// compilenode returning opresult390
  Object if386;
  if (istrue(opresult390)) {
// Begin line 187
  setline(187);
// Begin line 186
  setline(186);
// compilenode returning *var_NumberType
  return *var_NumberType;
// compilenode returning undefined
    if386 = undefined;
  } else {
  }
// compilenode returning if386
// Begin line 190
  setline(190);
// Begin line 191
  setline(191);
// Begin line 1017
  setline(1017);
// Begin line 188
  setline(188);
// compilenode returning *var_expr
  Object call392 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call392
// compilenode returning call392
  if (strlit393 == NULL) {
    strlit393 = alloc_String("string");
  }
// compilenode returning strlit393
  params[0] = strlit393;
  Object opresult395 = callmethod(call392, "==", 1, params);
// compilenode returning opresult395
  Object if391;
  if (istrue(opresult395)) {
// Begin line 190
  setline(190);
// Begin line 189
  setline(189);
// compilenode returning *var_StringType
  return *var_StringType;
// compilenode returning undefined
    if391 = undefined;
  } else {
  }
// compilenode returning if391
// Begin line 224
  setline(224);
// Begin line 225
  setline(225);
// Begin line 1017
  setline(1017);
// Begin line 191
  setline(191);
// compilenode returning *var_expr
  Object call397 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call397
// compilenode returning call397
  if (strlit398 == NULL) {
    strlit398 = alloc_String("op");
  }
// compilenode returning strlit398
  params[0] = strlit398;
  Object opresult400 = callmethod(call397, "==", 1, params);
// compilenode returning opresult400
  Object if396;
  if (istrue(opresult400)) {
  Object *var_opname = alloc_var();
  *var_opname = undefined;
  Object *var_opreceiver = alloc_var();
  *var_opreceiver = undefined;
  Object *var_opargument = alloc_var();
  *var_opargument = undefined;
  Object *var_opreceivertype = alloc_var();
  *var_opreceivertype = undefined;
  Object *var_opargumenttype = alloc_var();
  *var_opargumenttype = undefined;
  Object *var_opfound = alloc_var();
  *var_opfound = undefined;
  Object *var_opmeth = alloc_var();
  *var_opmeth = undefined;
  Object *var_opparamtypeid = alloc_var();
  *var_opparamtypeid = undefined;
  Object *var_opparamtypebd = alloc_var();
  *var_opparamtypebd = undefined;
  Object *var_opreturntypeid = alloc_var();
  *var_opreturntypeid = undefined;
  Object *var_opreturntypebd = alloc_var();
  *var_opreturntypebd = undefined;
// Begin line 193
  setline(193);
// Begin line 1017
  setline(1017);
// Begin line 192
  setline(192);
// compilenode returning *var_expr
  Object call401 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call401
// compilenode returning call401
  *var_opname = call401;
  if (call401 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 194
  setline(194);
// Begin line 1017
  setline(1017);
// Begin line 193
  setline(193);
// compilenode returning *var_expr
  Object call402 = callmethod(*var_expr, "left",
    0, params);
// compilenode returning call402
// compilenode returning call402
  *var_opreceiver = call402;
  if (call402 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 195
  setline(195);
// Begin line 1017
  setline(1017);
// Begin line 194
  setline(194);
// compilenode returning *var_expr
  Object call403 = callmethod(*var_expr, "right",
    0, params);
// compilenode returning call403
// compilenode returning call403
  *var_opargument = call403;
  if (call403 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 195
  setline(195);
// Begin line 1017
  setline(1017);
// Begin line 195
  setline(195);
// compilenode returning *var_expr
  Object call404 = callmethod(*var_expr, "left",
    0, params);
// compilenode returning call404
// compilenode returning call404
// Begin line 196
  setline(196);
// compilenode returning self
  params[0] = call404;
  Object call405 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call405
  *var_opreceivertype = call405;
  if (call405 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 196
  setline(196);
// compilenode returning *var_expr
  Object call406 = callmethod(*var_expr, "right",
    0, params);
// compilenode returning call406
// compilenode returning call406
// Begin line 197
  setline(197);
// compilenode returning self
  params[0] = call406;
  Object call407 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call407
  *var_opargumenttype = call407;
  if (call407 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 199
  setline(199);
// Begin line 200
  setline(200);
// Begin line 197
  setline(197);
// compilenode returning *var_opreceivertype
  Object bool409 = alloc_Boolean(0);
// compilenode returning bool409
  params[0] = bool409;
  Object opresult411 = callmethod(*var_opreceivertype, "==", 1, params);
// compilenode returning opresult411
  Object if408;
  if (istrue(opresult411)) {
// Begin line 199
  setline(199);
// Begin line 198
  setline(198);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if408 = undefined;
  } else {
  }
// compilenode returning if408
// Begin line 202
  setline(202);
// Begin line 203
  setline(203);
// Begin line 1017
  setline(1017);
// Begin line 200
  setline(200);
// compilenode returning *var_opreceivertype
  Object call413 = callmethod(*var_opreceivertype, "value",
    0, params);
// compilenode returning call413
// compilenode returning call413
  if (strlit414 == NULL) {
    strlit414 = alloc_String("Dynamic");
  }
// compilenode returning strlit414
  params[0] = strlit414;
  Object opresult416 = callmethod(call413, "==", 1, params);
// compilenode returning opresult416
  Object if412;
  if (istrue(opresult416)) {
// Begin line 202
  setline(202);
// Begin line 201
  setline(201);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if412 = undefined;
  } else {
  }
// compilenode returning if412
// Begin line 204
  setline(204);
// Begin line 203
  setline(203);
  Object bool417 = alloc_Boolean(0);
// compilenode returning bool417
  var_opfound = alloc_var();
  *var_opfound = bool417;
  if (bool417 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 205
  setline(205);
// Begin line 204
  setline(204);
  Object bool418 = alloc_Boolean(0);
// compilenode returning bool418
  var_opmeth = alloc_var();
  *var_opmeth = bool418;
  if (bool418 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 209
  setline(209);
// Begin line 211
  setline(211);
// Begin line 1017
  setline(1017);
// Begin line 205
  setline(205);
// compilenode returning *var_opreceivertype
  Object call420 = callmethod(*var_opreceivertype, "methods",
    0, params);
// compilenode returning call420
// compilenode returning call420
// Begin line 209
  setline(209);
// Begin line 1017
  setline(1017);
  Object obj422 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj422, self, 0);
  addmethod2(obj422, "outer", &reader_typechecker_outer_423);
  adddatum2(obj422, self, 0);
  block_savedest(obj422);
  Object **closure424 = createclosure(4);
  addtoclosure(closure424, var_opname);
  addtoclosure(closure424, var_opfound);
  addtoclosure(closure424, var_opmeth);
  Object *selfpp432 = alloc_var();
  *selfpp432 = self;
  addtoclosure(closure424, selfpp432);
  struct UserObject *uo424 = (struct UserObject*)obj422;
  uo424->data[1] = (Object)closure424;
  addmethod2(obj422, "apply", &meth_typechecker_apply424);
  set_type(obj422, 0);
// compilenode returning obj422
  setclassname(obj422, "Block<typechecker:421>");
// compilenode returning obj422
  params[0] = call420;
  Object iter419 = callmethod(call420, "iter", 1, params);
  while(1) {
    Object cond419 = callmethod(iter419, "havemore", 0, NULL);
    if (!istrue(cond419)) break;
    params[0] = callmethod(iter419, "next", 0, NULL);
    callmethod(obj422, "apply", 1, params);
  }
// compilenode returning call420
// Begin line 212
  setline(212);
// Begin line 214
  setline(214);
// Begin line 1017
  setline(1017);
// Begin line 211
  setline(211);
// compilenode returning *var_opfound
  Object call434 = callmethod(*var_opfound, "not",
    0, params);
// compilenode returning call434
// compilenode returning call434
  Object if433;
  if (istrue(call434)) {
// Begin line 212
  setline(212);
  if (strlit435 == NULL) {
    strlit435 = alloc_String("no such operator '");
  }
// compilenode returning strlit435
// compilenode returning *var_opname
  params[0] = *var_opname;
  Object opresult437 = callmethod(strlit435, "++", 1, params);
// compilenode returning opresult437
  if (strlit438 == NULL) {
    strlit438 = alloc_String("' in ");
  }
// compilenode returning strlit438
  params[0] = strlit438;
  Object opresult440 = callmethod(opresult437, "++", 1, params);
// compilenode returning opresult440
// Begin line 1017
  setline(1017);
// Begin line 212
  setline(212);
// compilenode returning *var_opreceivertype
  Object call441 = callmethod(*var_opreceivertype, "value",
    0, params);
// compilenode returning call441
// compilenode returning call441
  params[0] = call441;
  Object opresult443 = callmethod(opresult440, "++", 1, params);
// compilenode returning opresult443
  if (strlit444 == NULL) {
    strlit444 = alloc_String("");
  }
// compilenode returning strlit444
  params[0] = strlit444;
  Object opresult446 = callmethod(opresult443, "++", 1, params);
// compilenode returning opresult446
// compilenode returning module_util
  params[0] = opresult446;
  Object call447 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call447
    if433 = call447;
  } else {
  }
// compilenode returning if433
// Begin line 215
  setline(215);
// Begin line 1017
  setline(1017);
// Begin line 215
  setline(215);
// Begin line 1017
  setline(1017);
// Begin line 215
  setline(215);
// Begin line 1017
  setline(1017);
// Begin line 214
  setline(214);
// compilenode returning *var_opmeth
  Object call448 = callmethod(*var_opmeth, "params",
    0, params);
// compilenode returning call448
// compilenode returning call448
  Object call449 = callmethod(call448, "first",
    0, params);
// compilenode returning call449
// compilenode returning call449
  Object call450 = callmethod(call449, "dtype",
    0, params);
// compilenode returning call450
// compilenode returning call450
  *var_opparamtypeid = call450;
  if (call450 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 215
  setline(215);
// Begin line 1017
  setline(1017);
// Begin line 215
  setline(215);
// compilenode returning *var_opparamtypeid
  Object call451 = callmethod(*var_opparamtypeid, "value",
    0, params);
// compilenode returning call451
// compilenode returning call451
// Begin line 216
  setline(216);
// compilenode returning self
  params[0] = call451;
  Object call452 = callmethod(self, "findName",
    1, params);
// compilenode returning call452
  *var_opparamtypebd = call452;
  if (call452 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 219
  setline(219);
// Begin line 216
  setline(216);
// Begin line 1017
  setline(1017);
// Begin line 216
  setline(216);
// compilenode returning *var_opargumenttype
// Begin line 1017
  setline(1017);
// Begin line 216
  setline(216);
// compilenode returning *var_opparamtypebd
  Object call454 = callmethod(*var_opparamtypebd, "value",
    0, params);
// compilenode returning call454
// compilenode returning call454
// Begin line 221
  setline(221);
// compilenode returning self
  params[0] = *var_opargumenttype;
  params[1] = call454;
  Object call455 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call455
  Object call456 = callmethod(call455, "not",
    0, params);
// compilenode returning call456
// compilenode returning call456
  Object if453;
  if (istrue(call456)) {
// Begin line 219
  setline(219);
// Begin line 217
  setline(217);
  if (strlit457 == NULL) {
    strlit457 = alloc_String("passed argument of type ");
  }
// compilenode returning strlit457
// Begin line 219
  setline(219);
// Begin line 218
  setline(218);
  if (strlit458 == NULL) {
    strlit458 = alloc_String("");
  }
// compilenode returning strlit458
// Begin line 219
  setline(219);
// Begin line 1017
  setline(1017);
// Begin line 218
  setline(218);
// compilenode returning *var_opargumenttype
  Object call459 = callmethod(*var_opargumenttype, "value",
    0, params);
// compilenode returning call459
// compilenode returning call459
  params[0] = call459;
  Object opresult461 = callmethod(strlit458, "++", 1, params);
// compilenode returning opresult461
  if (strlit462 == NULL) {
    strlit462 = alloc_String(" to parameter of type ");
  }
// compilenode returning strlit462
  params[0] = strlit462;
  Object opresult464 = callmethod(opresult461, "++", 1, params);
// compilenode returning opresult464
  params[0] = opresult464;
  Object opresult466 = callmethod(strlit457, "++", 1, params);
// compilenode returning opresult466
// Begin line 219
  setline(219);
// Begin line 1017
  setline(1017);
// Begin line 219
  setline(219);
// Begin line 1017
  setline(1017);
// Begin line 219
  setline(219);
// compilenode returning *var_opparamtypebd
  Object call467 = callmethod(*var_opparamtypebd, "value",
    0, params);
// compilenode returning call467
// compilenode returning call467
  Object call468 = callmethod(call467, "value",
    0, params);
// compilenode returning call468
// compilenode returning call468
  params[0] = call468;
  Object opresult470 = callmethod(opresult466, "++", 1, params);
// compilenode returning opresult470
// Begin line 217
  setline(217);
// compilenode returning module_util
  params[0] = opresult470;
  Object call471 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call471
    if453 = call471;
  } else {
  }
// compilenode returning if453
// Begin line 222
  setline(222);
// Begin line 1017
  setline(1017);
// Begin line 221
  setline(221);
// compilenode returning *var_opmeth
  Object call472 = callmethod(*var_opmeth, "rtype",
    0, params);
// compilenode returning call472
// compilenode returning call472
  *var_opreturntypeid = call472;
  if (call472 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 222
  setline(222);
// Begin line 1017
  setline(1017);
// Begin line 222
  setline(222);
// compilenode returning *var_opreturntypeid
  Object call473 = callmethod(*var_opreturntypeid, "value",
    0, params);
// compilenode returning call473
// compilenode returning call473
// Begin line 223
  setline(223);
// compilenode returning self
  params[0] = call473;
  Object call474 = callmethod(self, "findName",
    1, params);
// compilenode returning call474
  *var_opreturntypebd = call474;
  if (call474 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 224
  setline(224);
// Begin line 1017
  setline(1017);
// Begin line 223
  setline(223);
// compilenode returning *var_opreturntypebd
  Object call475 = callmethod(*var_opreturntypebd, "value",
    0, params);
// compilenode returning call475
// compilenode returning call475
  return call475;
// compilenode returning undefined
    if396 = undefined;
  } else {
  }
// compilenode returning if396
// Begin line 256
  setline(256);
// Begin line 257
  setline(257);
// Begin line 1017
  setline(1017);
// Begin line 225
  setline(225);
// compilenode returning *var_expr
  Object call477 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call477
// compilenode returning call477
  if (strlit478 == NULL) {
    strlit478 = alloc_String("member");
  }
// compilenode returning strlit478
  params[0] = strlit478;
  Object opresult480 = callmethod(call477, "==", 1, params);
// compilenode returning opresult480
  Object if476;
  if (istrue(opresult480)) {
  Object *var_memname = alloc_var();
  *var_memname = undefined;
  Object *var_memin = alloc_var();
  *var_memin = undefined;
  Object *var_memreceivertype = alloc_var();
  *var_memreceivertype = undefined;
  Object *var_memfound = alloc_var();
  *var_memfound = undefined;
  Object *var_memmeth = alloc_var();
  *var_memmeth = undefined;
  Object *var_memreturntypeid = alloc_var();
  *var_memreturntypeid = undefined;
  Object *var_memreturntypebd = alloc_var();
  *var_memreturntypebd = undefined;
// Begin line 227
  setline(227);
// Begin line 1017
  setline(1017);
// Begin line 226
  setline(226);
// compilenode returning *var_expr
  Object call481 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call481
// compilenode returning call481
  *var_memname = call481;
  if (call481 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 228
  setline(228);
// Begin line 1017
  setline(1017);
// Begin line 227
  setline(227);
// compilenode returning *var_expr
  Object call482 = callmethod(*var_expr, "in",
    0, params);
// compilenode returning call482
// compilenode returning call482
  *var_memin = call482;
  if (call482 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 228
  setline(228);
// compilenode returning *var_memin
// Begin line 229
  setline(229);
// compilenode returning self
  params[0] = *var_memin;
  Object call483 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call483
  *var_memreceivertype = call483;
  if (call483 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 231
  setline(231);
// Begin line 232
  setline(232);
// Begin line 229
  setline(229);
// compilenode returning *var_memreceivertype
  Object bool485 = alloc_Boolean(0);
// compilenode returning bool485
  params[0] = bool485;
  Object opresult487 = callmethod(*var_memreceivertype, "==", 1, params);
// compilenode returning opresult487
  Object if484;
  if (istrue(opresult487)) {
// Begin line 231
  setline(231);
// Begin line 230
  setline(230);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if484 = undefined;
  } else {
  }
// compilenode returning if484
// Begin line 234
  setline(234);
// Begin line 235
  setline(235);
// Begin line 1017
  setline(1017);
// Begin line 232
  setline(232);
// compilenode returning *var_memreceivertype
  Object call489 = callmethod(*var_memreceivertype, "value",
    0, params);
// compilenode returning call489
// compilenode returning call489
  if (strlit490 == NULL) {
    strlit490 = alloc_String("Dynamic");
  }
// compilenode returning strlit490
  params[0] = strlit490;
  Object opresult492 = callmethod(call489, "==", 1, params);
// compilenode returning opresult492
  Object if488;
  if (istrue(opresult492)) {
// Begin line 234
  setline(234);
// Begin line 233
  setline(233);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if488 = undefined;
  } else {
  }
// compilenode returning if488
// Begin line 236
  setline(236);
// Begin line 235
  setline(235);
  Object bool493 = alloc_Boolean(0);
// compilenode returning bool493
  var_memfound = alloc_var();
  *var_memfound = bool493;
  if (bool493 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 237
  setline(237);
// Begin line 236
  setline(236);
  Object bool494 = alloc_Boolean(0);
// compilenode returning bool494
  var_memmeth = alloc_var();
  *var_memmeth = bool494;
  if (bool494 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 241
  setline(241);
// Begin line 243
  setline(243);
// Begin line 1017
  setline(1017);
// Begin line 237
  setline(237);
// compilenode returning *var_memreceivertype
  Object call496 = callmethod(*var_memreceivertype, "methods",
    0, params);
// compilenode returning call496
// compilenode returning call496
// Begin line 241
  setline(241);
// Begin line 1017
  setline(1017);
  Object obj498 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj498, self, 0);
  addmethod2(obj498, "outer", &reader_typechecker_outer_499);
  adddatum2(obj498, self, 0);
  block_savedest(obj498);
  Object **closure500 = createclosure(4);
  addtoclosure(closure500, var_memname);
  addtoclosure(closure500, var_memfound);
  addtoclosure(closure500, var_memmeth);
  Object *selfpp508 = alloc_var();
  *selfpp508 = self;
  addtoclosure(closure500, selfpp508);
  struct UserObject *uo500 = (struct UserObject*)obj498;
  uo500->data[1] = (Object)closure500;
  addmethod2(obj498, "apply", &meth_typechecker_apply500);
  set_type(obj498, 0);
// compilenode returning obj498
  setclassname(obj498, "Block<typechecker:497>");
// compilenode returning obj498
  params[0] = call496;
  Object iter495 = callmethod(call496, "iter", 1, params);
  while(1) {
    Object cond495 = callmethod(iter495, "havemore", 0, NULL);
    if (!istrue(cond495)) break;
    params[0] = callmethod(iter495, "next", 0, NULL);
    callmethod(obj498, "apply", 1, params);
  }
// compilenode returning call496
// Begin line 244
  setline(244);
// Begin line 246
  setline(246);
// Begin line 1017
  setline(1017);
// Begin line 243
  setline(243);
// compilenode returning *var_memfound
  Object call510 = callmethod(*var_memfound, "not",
    0, params);
// compilenode returning call510
// compilenode returning call510
  Object if509;
  if (istrue(call510)) {
// Begin line 244
  setline(244);
  if (strlit511 == NULL) {
    strlit511 = alloc_String("no such method '");
  }
// compilenode returning strlit511
// compilenode returning *var_memname
  params[0] = *var_memname;
  Object opresult513 = callmethod(strlit511, "++", 1, params);
// compilenode returning opresult513
  if (strlit514 == NULL) {
    strlit514 = alloc_String("' in ");
  }
// compilenode returning strlit514
  params[0] = strlit514;
  Object opresult516 = callmethod(opresult513, "++", 1, params);
// compilenode returning opresult516
// Begin line 1017
  setline(1017);
// Begin line 244
  setline(244);
// compilenode returning *var_memreceivertype
  Object call517 = callmethod(*var_memreceivertype, "value",
    0, params);
// compilenode returning call517
// compilenode returning call517
  params[0] = call517;
  Object opresult519 = callmethod(opresult516, "++", 1, params);
// compilenode returning opresult519
  if (strlit520 == NULL) {
    strlit520 = alloc_String("");
  }
// compilenode returning strlit520
  params[0] = strlit520;
  Object opresult522 = callmethod(opresult519, "++", 1, params);
// compilenode returning opresult522
// compilenode returning module_util
  params[0] = opresult522;
  Object call523 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call523
    if509 = call523;
  } else {
  }
// compilenode returning if509
// Begin line 248
  setline(248);
// Begin line 250
  setline(250);
// Begin line 1017
  setline(1017);
// Begin line 250
  setline(250);
// Begin line 1017
  setline(1017);
// Begin line 246
  setline(246);
// compilenode returning *var_memmeth
  Object call525 = callmethod(*var_memmeth, "params",
    0, params);
// compilenode returning call525
// compilenode returning call525
  Object call526 = callmethod(call525, "size",
    0, params);
// compilenode returning call526
// compilenode returning call526
  Object num527 = alloc_Float64(0.0);
// compilenode returning num527
  params[0] = num527;
  Object opresult529 = callmethod(call526, "/=", 1, params);
// compilenode returning opresult529
  Object if524;
  if (istrue(opresult529)) {
// Begin line 248
  setline(248);
// Begin line 247
  setline(247);
  if (strlit530 == NULL) {
    strlit530 = alloc_String("method '");
  }
// compilenode returning strlit530
// compilenode returning *var_memname
  params[0] = *var_memname;
  Object opresult532 = callmethod(strlit530, "++", 1, params);
// compilenode returning opresult532
  if (strlit533 == NULL) {
    strlit533 = alloc_String("' in ");
  }
// compilenode returning strlit533
  params[0] = strlit533;
  Object opresult535 = callmethod(opresult532, "++", 1, params);
// compilenode returning opresult535
// Begin line 248
  setline(248);
// Begin line 1017
  setline(1017);
// Begin line 247
  setline(247);
// compilenode returning *var_memreceivertype
  Object call536 = callmethod(*var_memreceivertype, "value",
    0, params);
// compilenode returning call536
// compilenode returning call536
  params[0] = call536;
  Object opresult538 = callmethod(opresult535, "++", 1, params);
// compilenode returning opresult538
  if (strlit539 == NULL) {
    strlit539 = alloc_String(" ");
  }
// compilenode returning strlit539
  params[0] = strlit539;
  Object opresult541 = callmethod(opresult538, "++", 1, params);
// compilenode returning opresult541
// Begin line 248
  setline(248);
  if (strlit542 == NULL) {
    strlit542 = alloc_String("requires ");
  }
// compilenode returning strlit542
// Begin line 1017
  setline(1017);
// Begin line 248
  setline(248);
// Begin line 1017
  setline(1017);
// Begin line 248
  setline(248);
// compilenode returning *var_memmeth
  Object call543 = callmethod(*var_memmeth, "params",
    0, params);
// compilenode returning call543
// compilenode returning call543
  Object call544 = callmethod(call543, "size",
    0, params);
// compilenode returning call544
// compilenode returning call544
  params[0] = call544;
  Object opresult546 = callmethod(strlit542, "++", 1, params);
// compilenode returning opresult546
  if (strlit547 == NULL) {
    strlit547 = alloc_String(" arguments, not 0");
  }
// compilenode returning strlit547
  params[0] = strlit547;
  Object opresult549 = callmethod(opresult546, "++", 1, params);
// compilenode returning opresult549
  params[0] = opresult549;
  Object opresult551 = callmethod(opresult541, "++", 1, params);
// compilenode returning opresult551
// Begin line 247
  setline(247);
// compilenode returning module_util
  params[0] = opresult551;
  Object call552 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call552
    if524 = call552;
  } else {
  }
// compilenode returning if524
// Begin line 251
  setline(251);
// Begin line 1017
  setline(1017);
// Begin line 250
  setline(250);
// compilenode returning *var_memmeth
  Object call553 = callmethod(*var_memmeth, "rtype",
    0, params);
// compilenode returning call553
// compilenode returning call553
  *var_memreturntypeid = call553;
  if (call553 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 253
  setline(253);
// Begin line 254
  setline(254);
// Begin line 1017
  setline(1017);
// Begin line 251
  setline(251);
// compilenode returning *var_memreturntypeid
  Object call555 = callmethod(*var_memreturntypeid, "kind",
    0, params);
// compilenode returning call555
// compilenode returning call555
  if (strlit556 == NULL) {
    strlit556 = alloc_String("type");
  }
// compilenode returning strlit556
  params[0] = strlit556;
  Object opresult558 = callmethod(call555, "==", 1, params);
// compilenode returning opresult558
  Object if554;
  if (istrue(opresult558)) {
// Begin line 253
  setline(253);
// Begin line 252
  setline(252);
// compilenode returning *var_memreturntypeid
  return *var_memreturntypeid;
// compilenode returning undefined
    if554 = undefined;
  } else {
  }
// compilenode returning if554
// Begin line 254
  setline(254);
// Begin line 1017
  setline(1017);
// Begin line 254
  setline(254);
// compilenode returning *var_memreturntypeid
  Object call559 = callmethod(*var_memreturntypeid, "value",
    0, params);
// compilenode returning call559
// compilenode returning call559
// Begin line 255
  setline(255);
// compilenode returning self
  params[0] = call559;
  Object call560 = callmethod(self, "findName",
    1, params);
// compilenode returning call560
  *var_memreturntypebd = call560;
  if (call560 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 256
  setline(256);
// Begin line 1017
  setline(1017);
// Begin line 255
  setline(255);
// compilenode returning *var_memreturntypebd
  Object call561 = callmethod(*var_memreturntypebd, "value",
    0, params);
// compilenode returning call561
// compilenode returning call561
  return call561;
// compilenode returning undefined
    if476 = undefined;
  } else {
  }
// compilenode returning if476
// Begin line 310
  setline(310);
// Begin line 311
  setline(311);
// Begin line 1017
  setline(1017);
// Begin line 257
  setline(257);
// compilenode returning *var_expr
  Object call563 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call563
// compilenode returning call563
  if (strlit564 == NULL) {
    strlit564 = alloc_String("call");
  }
// compilenode returning strlit564
  params[0] = strlit564;
  Object opresult566 = callmethod(call563, "==", 1, params);
// compilenode returning opresult566
  Object if562;
  if (istrue(opresult566)) {
  Object *var_callmem = alloc_var();
  *var_callmem = undefined;
  Object *var_callname = alloc_var();
  *var_callname = undefined;
  Object *var_callin = alloc_var();
  *var_callin = undefined;
  Object *var_callreceivertype = alloc_var();
  *var_callreceivertype = undefined;
  Object *var_callfound = alloc_var();
  *var_callfound = undefined;
  Object *var_callmeth = alloc_var();
  *var_callmeth = undefined;
  Object *var_callparams = alloc_var();
  *var_callparams = undefined;
  Object *var_callargs = alloc_var();
  *var_callargs = undefined;
  Object *var_callreturntypeid = alloc_var();
  *var_callreturntypeid = undefined;
  Object *var_callreturntypebd = alloc_var();
  *var_callreturntypebd = undefined;
// Begin line 259
  setline(259);
// Begin line 1017
  setline(1017);
// Begin line 258
  setline(258);
// compilenode returning *var_expr
  Object call567 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call567
// compilenode returning call567
  *var_callmem = call567;
  if (call567 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 261
  setline(261);
// Begin line 262
  setline(262);
// Begin line 1017
  setline(1017);
// Begin line 259
  setline(259);
// compilenode returning *var_callmem
  Object call569 = callmethod(*var_callmem, "kind",
    0, params);
// compilenode returning call569
// compilenode returning call569
  if (strlit570 == NULL) {
    strlit570 = alloc_String("member");
  }
// compilenode returning strlit570
  params[0] = strlit570;
  Object opresult572 = callmethod(call569, "/=", 1, params);
// compilenode returning opresult572
  Object if568;
  if (istrue(opresult572)) {
// Begin line 261
  setline(261);
// Begin line 260
  setline(260);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if568 = undefined;
  } else {
  }
// compilenode returning if568
// Begin line 263
  setline(263);
// Begin line 1017
  setline(1017);
// Begin line 262
  setline(262);
// compilenode returning *var_callmem
  Object call573 = callmethod(*var_callmem, "value",
    0, params);
// compilenode returning call573
// compilenode returning call573
  *var_callname = call573;
  if (call573 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// Begin line 1017
  setline(1017);
// Begin line 263
  setline(263);
// compilenode returning *var_callmem
  Object call574 = callmethod(*var_callmem, "in",
    0, params);
// compilenode returning call574
// compilenode returning call574
  *var_callin = call574;
  if (call574 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 264
  setline(264);
// compilenode returning *var_callin
// Begin line 265
  setline(265);
// compilenode returning self
  params[0] = *var_callin;
  Object call575 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call575
  *var_callreceivertype = call575;
  if (call575 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 267
  setline(267);
// Begin line 268
  setline(268);
// Begin line 265
  setline(265);
// compilenode returning *var_callreceivertype
  Object bool577 = alloc_Boolean(0);
// compilenode returning bool577
  params[0] = bool577;
  Object opresult579 = callmethod(*var_callreceivertype, "==", 1, params);
// compilenode returning opresult579
  Object if576;
  if (istrue(opresult579)) {
// Begin line 267
  setline(267);
// Begin line 266
  setline(266);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if576 = undefined;
  } else {
  }
// compilenode returning if576
// Begin line 270
  setline(270);
// Begin line 271
  setline(271);
// Begin line 1017
  setline(1017);
// Begin line 268
  setline(268);
// compilenode returning *var_callreceivertype
  Object call581 = callmethod(*var_callreceivertype, "value",
    0, params);
// compilenode returning call581
// compilenode returning call581
  if (strlit582 == NULL) {
    strlit582 = alloc_String("Dynamic");
  }
// compilenode returning strlit582
  params[0] = strlit582;
  Object opresult584 = callmethod(call581, "==", 1, params);
// compilenode returning opresult584
  Object if580;
  if (istrue(opresult584)) {
// Begin line 270
  setline(270);
// Begin line 269
  setline(269);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if580 = undefined;
  } else {
  }
// compilenode returning if580
// Begin line 272
  setline(272);
// Begin line 271
  setline(271);
  Object bool585 = alloc_Boolean(0);
// compilenode returning bool585
  var_callfound = alloc_var();
  *var_callfound = bool585;
  if (bool585 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 273
  setline(273);
// Begin line 272
  setline(272);
  Object bool586 = alloc_Boolean(0);
// compilenode returning bool586
  var_callmeth = alloc_var();
  *var_callmeth = bool586;
  if (bool586 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 277
  setline(277);
// Begin line 279
  setline(279);
// Begin line 1017
  setline(1017);
// Begin line 273
  setline(273);
// compilenode returning *var_callreceivertype
  Object call588 = callmethod(*var_callreceivertype, "methods",
    0, params);
// compilenode returning call588
// compilenode returning call588
// Begin line 277
  setline(277);
// Begin line 1017
  setline(1017);
  Object obj590 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj590, self, 0);
  addmethod2(obj590, "outer", &reader_typechecker_outer_591);
  adddatum2(obj590, self, 0);
  block_savedest(obj590);
  Object **closure592 = createclosure(4);
  addtoclosure(closure592, var_callname);
  addtoclosure(closure592, var_callfound);
  addtoclosure(closure592, var_callmeth);
  Object *selfpp600 = alloc_var();
  *selfpp600 = self;
  addtoclosure(closure592, selfpp600);
  struct UserObject *uo592 = (struct UserObject*)obj590;
  uo592->data[1] = (Object)closure592;
  addmethod2(obj590, "apply", &meth_typechecker_apply592);
  set_type(obj590, 0);
// compilenode returning obj590
  setclassname(obj590, "Block<typechecker:589>");
// compilenode returning obj590
  params[0] = call588;
  Object iter587 = callmethod(call588, "iter", 1, params);
  while(1) {
    Object cond587 = callmethod(iter587, "havemore", 0, NULL);
    if (!istrue(cond587)) break;
    params[0] = callmethod(iter587, "next", 0, NULL);
    callmethod(obj590, "apply", 1, params);
  }
// compilenode returning call588
// Begin line 280
  setline(280);
// Begin line 282
  setline(282);
// Begin line 1017
  setline(1017);
// Begin line 279
  setline(279);
// compilenode returning *var_callfound
  Object call602 = callmethod(*var_callfound, "not",
    0, params);
// compilenode returning call602
// compilenode returning call602
  Object if601;
  if (istrue(call602)) {
// Begin line 280
  setline(280);
  if (strlit603 == NULL) {
    strlit603 = alloc_String("no such method '");
  }
// compilenode returning strlit603
// compilenode returning *var_callname
  params[0] = *var_callname;
  Object opresult605 = callmethod(strlit603, "++", 1, params);
// compilenode returning opresult605
  if (strlit606 == NULL) {
    strlit606 = alloc_String("' in ");
  }
// compilenode returning strlit606
  params[0] = strlit606;
  Object opresult608 = callmethod(opresult605, "++", 1, params);
// compilenode returning opresult608
// Begin line 1017
  setline(1017);
// Begin line 280
  setline(280);
// compilenode returning *var_callreceivertype
  Object call609 = callmethod(*var_callreceivertype, "value",
    0, params);
// compilenode returning call609
// compilenode returning call609
  params[0] = call609;
  Object opresult611 = callmethod(opresult608, "++", 1, params);
// compilenode returning opresult611
  if (strlit612 == NULL) {
    strlit612 = alloc_String("");
  }
// compilenode returning strlit612
  params[0] = strlit612;
  Object opresult614 = callmethod(opresult611, "++", 1, params);
// compilenode returning opresult614
// compilenode returning module_util
  params[0] = opresult614;
  Object call615 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call615
    if601 = call615;
  } else {
  }
// compilenode returning if601
// Begin line 285
  setline(285);
// Begin line 287
  setline(287);
// Begin line 1017
  setline(1017);
// Begin line 287
  setline(287);
// Begin line 1017
  setline(1017);
// Begin line 282
  setline(282);
// compilenode returning *var_callmeth
  Object call617 = callmethod(*var_callmeth, "params",
    0, params);
// compilenode returning call617
// compilenode returning call617
  Object call618 = callmethod(call617, "size",
    0, params);
// compilenode returning call618
// compilenode returning call618
// Begin line 287
  setline(287);
// Begin line 1017
  setline(1017);
// Begin line 287
  setline(287);
// Begin line 1017
  setline(1017);
// Begin line 282
  setline(282);
// compilenode returning *var_expr
  Object call619 = callmethod(*var_expr, "with",
    0, params);
// compilenode returning call619
// compilenode returning call619
  Object call620 = callmethod(call619, "size",
    0, params);
// compilenode returning call620
// compilenode returning call620
  params[0] = call620;
  Object opresult622 = callmethod(call618, ">", 1, params);
// compilenode returning opresult622
  Object if616;
  if (istrue(opresult622)) {
// Begin line 285
  setline(285);
// Begin line 283
  setline(283);
  if (strlit623 == NULL) {
    strlit623 = alloc_String("method '");
  }
// compilenode returning strlit623
// compilenode returning *var_callname
  params[0] = *var_callname;
  Object opresult625 = callmethod(strlit623, "++", 1, params);
// compilenode returning opresult625
  if (strlit626 == NULL) {
    strlit626 = alloc_String("' in ");
  }
// compilenode returning strlit626
  params[0] = strlit626;
  Object opresult628 = callmethod(opresult625, "++", 1, params);
// compilenode returning opresult628
// Begin line 285
  setline(285);
// Begin line 1017
  setline(1017);
// Begin line 283
  setline(283);
// compilenode returning *var_callreceivertype
  Object call629 = callmethod(*var_callreceivertype, "value",
    0, params);
// compilenode returning call629
// compilenode returning call629
  params[0] = call629;
  Object opresult631 = callmethod(opresult628, "++", 1, params);
// compilenode returning opresult631
  if (strlit632 == NULL) {
    strlit632 = alloc_String(" ");
  }
// compilenode returning strlit632
  params[0] = strlit632;
  Object opresult634 = callmethod(opresult631, "++", 1, params);
// compilenode returning opresult634
// Begin line 285
  setline(285);
// Begin line 284
  setline(284);
  if (strlit635 == NULL) {
    strlit635 = alloc_String("requires ");
  }
// compilenode returning strlit635
// Begin line 285
  setline(285);
// Begin line 1017
  setline(1017);
// Begin line 285
  setline(285);
// Begin line 1017
  setline(1017);
// Begin line 284
  setline(284);
// compilenode returning *var_callmeth
  Object call636 = callmethod(*var_callmeth, "params",
    0, params);
// compilenode returning call636
// compilenode returning call636
  Object call637 = callmethod(call636, "size",
    0, params);
// compilenode returning call637
// compilenode returning call637
  params[0] = call637;
  Object opresult639 = callmethod(strlit635, "++", 1, params);
// compilenode returning opresult639
  if (strlit640 == NULL) {
    strlit640 = alloc_String(" arguments, not ");
  }
// compilenode returning strlit640
  params[0] = strlit640;
  Object opresult642 = callmethod(opresult639, "++", 1, params);
// compilenode returning opresult642
  params[0] = opresult642;
  Object opresult644 = callmethod(opresult634, "++", 1, params);
// compilenode returning opresult644
// Begin line 285
  setline(285);
  if (strlit645 == NULL) {
    strlit645 = alloc_String("");
  }
// compilenode returning strlit645
// Begin line 1017
  setline(1017);
// Begin line 285
  setline(285);
// Begin line 1017
  setline(1017);
// Begin line 285
  setline(285);
// compilenode returning *var_expr
  Object call646 = callmethod(*var_expr, "with",
    0, params);
// compilenode returning call646
// compilenode returning call646
  Object call647 = callmethod(call646, "size",
    0, params);
// compilenode returning call647
// compilenode returning call647
  params[0] = call647;
  Object opresult649 = callmethod(strlit645, "++", 1, params);
// compilenode returning opresult649
  if (strlit650 == NULL) {
    strlit650 = alloc_String("");
  }
// compilenode returning strlit650
  params[0] = strlit650;
  Object opresult652 = callmethod(opresult649, "++", 1, params);
// compilenode returning opresult652
  params[0] = opresult652;
  Object opresult654 = callmethod(opresult644, "++", 1, params);
// compilenode returning opresult654
// Begin line 283
  setline(283);
// compilenode returning module_util
  params[0] = opresult654;
  Object call655 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call655
    if616 = call655;
  } else {
  }
// compilenode returning if616
// Begin line 288
  setline(288);
// Begin line 1017
  setline(1017);
// Begin line 287
  setline(287);
// compilenode returning *var_callmeth
  Object call656 = callmethod(*var_callmeth, "params",
    0, params);
// compilenode returning call656
// compilenode returning call656
  *var_callparams = call656;
  if (call656 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 289
  setline(289);
// Begin line 1017
  setline(1017);
// Begin line 288
  setline(288);
// compilenode returning *var_expr
  Object call657 = callmethod(*var_expr, "with",
    0, params);
// compilenode returning call657
// compilenode returning call657
  *var_callargs = call657;
  if (call657 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 300
  setline(300);
// Begin line 304
  setline(304);
// Begin line 1017
  setline(1017);
// Begin line 289
  setline(289);
// compilenode returning *var_callparams
  Object call659 = callmethod(*var_callparams, "size",
    0, params);
// compilenode returning call659
// compilenode returning call659
  Object num660 = alloc_Float64(0.0);
// compilenode returning num660
  params[0] = num660;
  Object opresult662 = callmethod(call659, ">", 1, params);
// compilenode returning opresult662
  Object if658;
  if (istrue(opresult662)) {
  Object *var_calli = alloc_var();
  *var_calli = undefined;
  Object *var_callimax = alloc_var();
  *var_callimax = undefined;
// Begin line 291
  setline(291);
// Begin line 1017
  setline(1017);
// Begin line 291
  setline(291);
// Begin line 1017
  setline(1017);
// Begin line 290
  setline(290);
// compilenode returning *var_callparams
  Object call663 = callmethod(*var_callparams, "indices",
    0, params);
// compilenode returning call663
// compilenode returning call663
  Object call664 = callmethod(call663, "first",
    0, params);
// compilenode returning call664
// compilenode returning call664
  var_calli = alloc_var();
  *var_calli = call664;
  if (call664 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 292
  setline(292);
// Begin line 1017
  setline(1017);
// Begin line 292
  setline(292);
// Begin line 1017
  setline(1017);
// Begin line 291
  setline(291);
// compilenode returning *var_callparams
  Object call665 = callmethod(*var_callparams, "indices",
    0, params);
// compilenode returning call665
// compilenode returning call665
  Object call666 = callmethod(call665, "last",
    0, params);
// compilenode returning call666
// compilenode returning call666
  *var_callimax = call666;
  if (call666 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 300
  setline(300);
// Begin line 303
  setline(303);
// Begin line 292
  setline(292);
// compilenode returning *var_calli
// compilenode returning *var_callimax
  params[0] = *var_callimax;
  Object opresult669 = callmethod(*var_calli, "..", 1, params);
// compilenode returning opresult669
// Begin line 300
  setline(300);
// Begin line 1017
  setline(1017);
  Object obj671 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj671, self, 0);
  addmethod2(obj671, "outer", &reader_typechecker_outer_672);
  adddatum2(obj671, self, 0);
  block_savedest(obj671);
  Object **closure673 = createclosure(4);
  addtoclosure(closure673, var_callargs);
  addtoclosure(closure673, var_callparams);
  addtoclosure(closure673, var_callname);
  Object *selfpp709 = alloc_var();
  *selfpp709 = self;
  addtoclosure(closure673, selfpp709);
  struct UserObject *uo673 = (struct UserObject*)obj671;
  uo673->data[1] = (Object)closure673;
  addmethod2(obj671, "apply", &meth_typechecker_apply673);
  set_type(obj671, 0);
// compilenode returning obj671
  setclassname(obj671, "Block<typechecker:670>");
// compilenode returning obj671
  params[0] = opresult669;
  Object iter667 = callmethod(opresult669, "iter", 1, params);
  while(1) {
    Object cond667 = callmethod(iter667, "havemore", 0, NULL);
    if (!istrue(cond667)) break;
    params[0] = callmethod(iter667, "next", 0, NULL);
    callmethod(obj671, "apply", 1, params);
  }
// compilenode returning opresult669
    if658 = opresult669;
  } else {
  }
// compilenode returning if658
// Begin line 305
  setline(305);
// Begin line 1017
  setline(1017);
// Begin line 304
  setline(304);
// compilenode returning *var_callmeth
  Object call710 = callmethod(*var_callmeth, "rtype",
    0, params);
// compilenode returning call710
// compilenode returning call710
  *var_callreturntypeid = call710;
  if (call710 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 307
  setline(307);
// Begin line 308
  setline(308);
// Begin line 1017
  setline(1017);
// Begin line 305
  setline(305);
// compilenode returning *var_callreturntypeid
  Object call712 = callmethod(*var_callreturntypeid, "kind",
    0, params);
// compilenode returning call712
// compilenode returning call712
  if (strlit713 == NULL) {
    strlit713 = alloc_String("type");
  }
// compilenode returning strlit713
  params[0] = strlit713;
  Object opresult715 = callmethod(call712, "==", 1, params);
// compilenode returning opresult715
  Object if711;
  if (istrue(opresult715)) {
// Begin line 307
  setline(307);
// Begin line 306
  setline(306);
// compilenode returning *var_callreturntypeid
  return *var_callreturntypeid;
// compilenode returning undefined
    if711 = undefined;
  } else {
  }
// compilenode returning if711
// Begin line 308
  setline(308);
// Begin line 1017
  setline(1017);
// Begin line 308
  setline(308);
// compilenode returning *var_callreturntypeid
  Object call716 = callmethod(*var_callreturntypeid, "value",
    0, params);
// compilenode returning call716
// compilenode returning call716
// Begin line 309
  setline(309);
// compilenode returning self
  params[0] = call716;
  Object call717 = callmethod(self, "findName",
    1, params);
// compilenode returning call717
  *var_callreturntypebd = call717;
  if (call717 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 310
  setline(310);
// Begin line 1017
  setline(1017);
// Begin line 309
  setline(309);
// compilenode returning *var_callreturntypebd
  Object call718 = callmethod(*var_callreturntypebd, "value",
    0, params);
// compilenode returning call718
// compilenode returning call718
  return call718;
// compilenode returning undefined
    if562 = undefined;
  } else {
  }
// compilenode returning if562
// Begin line 339
  setline(339);
// Begin line 340
  setline(340);
// Begin line 1017
  setline(1017);
// Begin line 311
  setline(311);
// compilenode returning *var_expr
  Object call720 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call720
// compilenode returning call720
  if (strlit721 == NULL) {
    strlit721 = alloc_String("object");
  }
// compilenode returning strlit721
  params[0] = strlit721;
  Object opresult723 = callmethod(call720, "==", 1, params);
// compilenode returning opresult723
  Object if719;
  if (istrue(opresult723)) {
  Object *var_objectmeths = alloc_var();
  *var_objectmeths = undefined;
  Object *var_objecttp = alloc_var();
  *var_objecttp = undefined;
// Begin line 313
  setline(313);
  Object array724 = alloc_List();
// compilenode returning array724
  *var_objectmeths = array724;
  if (array724 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  if (strlit725 == NULL) {
    strlit725 = alloc_String("<Object_");
  }
// compilenode returning strlit725
// Begin line 1017
  setline(1017);
// Begin line 313
  setline(313);
// compilenode returning *var_expr
  Object call726 = callmethod(*var_expr, "line",
    0, params);
// compilenode returning call726
// compilenode returning call726
  params[0] = call726;
  Object opresult728 = callmethod(strlit725, "++", 1, params);
// compilenode returning opresult728
  if (strlit729 == NULL) {
    strlit729 = alloc_String(">");
  }
// compilenode returning strlit729
  params[0] = strlit729;
  Object opresult731 = callmethod(opresult728, "++", 1, params);
// compilenode returning opresult731
// compilenode returning *var_objectmeths
// compilenode returning module_ast
  params[0] = opresult731;
  params[1] = *var_objectmeths;
  Object call732 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call732
  *var_objecttp = call732;
  if (call732 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 317
  setline(317);
// Begin line 320
  setline(320);
// Begin line 1017
  setline(1017);
// Begin line 314
  setline(314);
// compilenode returning *var_expr
  Object call734 = callmethod(*var_expr, "superclass",
    0, params);
// compilenode returning call734
// compilenode returning call734
  Object bool735 = alloc_Boolean(0);
// compilenode returning bool735
  params[0] = bool735;
  Object opresult737 = callmethod(call734, "/=", 1, params);
// compilenode returning opresult737
  Object if733;
  if (istrue(opresult737)) {
  Object *var_supertype = alloc_var();
  *var_supertype = undefined;
// Begin line 315
  setline(315);
// Begin line 1017
  setline(1017);
// Begin line 315
  setline(315);
// compilenode returning *var_expr
  Object call738 = callmethod(*var_expr, "superclass",
    0, params);
// compilenode returning call738
// compilenode returning call738
// Begin line 316
  setline(316);
// compilenode returning self
  params[0] = call738;
  Object call739 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call739
  *var_supertype = call739;
  if (call739 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 317
  setline(317);
// Begin line 319
  setline(319);
// Begin line 1017
  setline(1017);
// Begin line 316
  setline(316);
// compilenode returning *var_supertype
  Object call741 = callmethod(*var_supertype, "methods",
    0, params);
// compilenode returning call741
// compilenode returning call741
// Begin line 317
  setline(317);
// Begin line 1017
  setline(1017);
  Object obj743 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj743, self, 0);
  addmethod2(obj743, "outer", &reader_typechecker_outer_744);
  adddatum2(obj743, self, 0);
  block_savedest(obj743);
  Object **closure745 = createclosure(2);
  addtoclosure(closure745, var_objectmeths);
  Object *selfpp747 = alloc_var();
  *selfpp747 = self;
  addtoclosure(closure745, selfpp747);
  struct UserObject *uo745 = (struct UserObject*)obj743;
  uo745->data[1] = (Object)closure745;
  addmethod2(obj743, "apply", &meth_typechecker_apply745);
  set_type(obj743, 0);
// compilenode returning obj743
  setclassname(obj743, "Block<typechecker:742>");
// compilenode returning obj743
  params[0] = call741;
  Object iter740 = callmethod(call741, "iter", 1, params);
  while(1) {
    Object cond740 = callmethod(iter740, "havemore", 0, NULL);
    if (!istrue(cond740)) break;
    params[0] = callmethod(iter740, "next", 0, NULL);
    callmethod(obj743, "apply", 1, params);
  }
// compilenode returning call741
    if733 = call741;
  } else {
  }
// compilenode returning if733
// Begin line 333
  setline(333);
// Begin line 336
  setline(336);
// Begin line 1017
  setline(1017);
// Begin line 320
  setline(320);
// compilenode returning *var_expr
  Object call749 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call749
// compilenode returning call749
// Begin line 333
  setline(333);
// Begin line 1017
  setline(1017);
  Object obj751 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj751, self, 0);
  addmethod2(obj751, "outer", &reader_typechecker_outer_752);
  adddatum2(obj751, self, 0);
  block_savedest(obj751);
  Object **closure753 = createclosure(2);
  addtoclosure(closure753, var_objectmeths);
  Object *selfpp801 = alloc_var();
  *selfpp801 = self;
  addtoclosure(closure753, selfpp801);
  struct UserObject *uo753 = (struct UserObject*)obj751;
  uo753->data[1] = (Object)closure753;
  addmethod2(obj751, "apply", &meth_typechecker_apply753);
  set_type(obj751, 0);
// compilenode returning obj751
  setclassname(obj751, "Block<typechecker:750>");
// compilenode returning obj751
  params[0] = call749;
  Object iter748 = callmethod(call749, "iter", 1, params);
  while(1) {
    Object cond748 = callmethod(iter748, "havemore", 0, NULL);
    if (!istrue(cond748)) break;
    params[0] = callmethod(iter748, "next", 0, NULL);
    callmethod(obj751, "apply", 1, params);
  }
// compilenode returning call749
// Begin line 336
  setline(336);
// compilenode returning *var_objecttp
// compilenode returning module_subtype
  params[0] = *var_objecttp;
  Object call802 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call802
// Begin line 338
  setline(338);
// Begin line 1017
  setline(1017);
// Begin line 337
  setline(337);
// compilenode returning *var_objecttp
// compilenode returning *var_expr
  params[0] = *var_objecttp;
  Object call803 = callmethod(*var_expr, "otype:=",
    1, params);
// compilenode returning call803
// compilenode returning nothing
// Begin line 339
  setline(339);
// Begin line 338
  setline(338);
// compilenode returning *var_objecttp
  return *var_objecttp;
// compilenode returning undefined
    if719 = undefined;
  } else {
  }
// compilenode returning if719
// Begin line 364
  setline(364);
// Begin line 365
  setline(365);
// Begin line 1017
  setline(1017);
// Begin line 340
  setline(340);
// compilenode returning *var_expr
  Object call805 = callmethod(*var_expr, "kind",
    0, params);
// compilenode returning call805
// compilenode returning call805
  if (strlit806 == NULL) {
    strlit806 = alloc_String("generic");
  }
// compilenode returning strlit806
  params[0] = strlit806;
  Object opresult808 = callmethod(call805, "==", 1, params);
// compilenode returning opresult808
  Object if804;
  if (istrue(opresult808)) {
  Object *var_gtype = alloc_var();
  *var_gtype = undefined;
  Object *var_gname = alloc_var();
  *var_gname = undefined;
  Object *var_gtb = alloc_var();
  *var_gtb = undefined;
  Object *var_nt = alloc_var();
  *var_nt = undefined;
// Begin line 342
  setline(342);
  var_gtype = alloc_var();
  *var_gtype = undefined;
// compilenode returning nothing
// Begin line 343
  setline(343);
  var_gname = alloc_var();
  *var_gname = undefined;
// compilenode returning nothing
// Begin line 352
  setline(352);
// Begin line 354
  setline(354);
// Begin line 1017
  setline(1017);
// Begin line 354
  setline(354);
// Begin line 1017
  setline(1017);
// Begin line 343
  setline(343);
// compilenode returning *var_expr
  Object call810 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call810
// compilenode returning call810
  Object call811 = callmethod(call810, "kind",
    0, params);
// compilenode returning call811
// compilenode returning call811
  if (strlit812 == NULL) {
    strlit812 = alloc_String("type");
  }
// compilenode returning strlit812
  params[0] = strlit812;
  Object opresult814 = callmethod(call811, "==", 1, params);
// compilenode returning opresult814
  Object if809;
  if (istrue(opresult814)) {
// Begin line 345
  setline(345);
// Begin line 1017
  setline(1017);
// Begin line 345
  setline(345);
// Begin line 1017
  setline(1017);
// Begin line 344
  setline(344);
// compilenode returning *var_expr
  Object call815 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call815
// compilenode returning call815
  Object call816 = callmethod(call815, "value",
    0, params);
// compilenode returning call816
// compilenode returning call816
  *var_gname = call816;
  if (call816 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 346
  setline(346);
// Begin line 1017
  setline(1017);
// Begin line 345
  setline(345);
// compilenode returning *var_expr
  Object call818 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call818
// compilenode returning call818
  *var_gtype = call818;
  if (call818 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if809 = nothing;
  } else {
// Begin line 352
  setline(352);
// Begin line 350
  setline(350);
// Begin line 1017
  setline(1017);
// Begin line 350
  setline(350);
// Begin line 1017
  setline(1017);
// Begin line 346
  setline(346);
// compilenode returning *var_expr
  Object call821 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call821
// compilenode returning call821
  Object call822 = callmethod(call821, "kind",
    0, params);
// compilenode returning call822
// compilenode returning call822
  if (strlit823 == NULL) {
    strlit823 = alloc_String("identifier");
  }
// compilenode returning strlit823
  params[0] = strlit823;
  Object opresult825 = callmethod(call822, "==", 1, params);
// compilenode returning opresult825
  Object if820;
  if (istrue(opresult825)) {
  Object *var_gidb = alloc_var();
  *var_gidb = undefined;
// Begin line 348
  setline(348);
// Begin line 1017
  setline(1017);
// Begin line 348
  setline(348);
// Begin line 1017
  setline(1017);
// Begin line 347
  setline(347);
// compilenode returning *var_expr
  Object call826 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call826
// compilenode returning call826
  Object call827 = callmethod(call826, "value",
    0, params);
// compilenode returning call827
// compilenode returning call827
  *var_gname = call827;
  if (call827 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 348
  setline(348);
// compilenode returning *var_gname
// Begin line 349
  setline(349);
// compilenode returning self
  params[0] = *var_gname;
  Object call829 = callmethod(self, "findName",
    1, params);
// compilenode returning call829
  *var_gidb = call829;
  if (call829 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 349
  setline(349);
// compilenode returning *var_gidb
  Object call830 = callmethod(*var_gidb, "dtype",
    0, params);
// compilenode returning call830
// compilenode returning call830
// Begin line 350
  setline(350);
// compilenode returning self
  params[0] = call830;
  Object call831 = callmethod(self, "findType",
    1, params);
// compilenode returning call831
  *var_gtype = call831;
  if (call831 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if820 = nothing;
  } else {
// Begin line 352
  setline(352);
// Begin line 1017
  setline(1017);
// Begin line 352
  setline(352);
// Begin line 1017
  setline(1017);
// Begin line 351
  setline(351);
// compilenode returning *var_expr
  Object call833 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call833
// compilenode returning call833
  Object call834 = callmethod(call833, "value",
    0, params);
// compilenode returning call834
// compilenode returning call834
  *var_gname = call834;
  if (call834 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 352
  setline(352);
// Begin line 1017
  setline(1017);
// Begin line 352
  setline(352);
// compilenode returning *var_expr
  Object call836 = callmethod(*var_expr, "value",
    0, params);
// compilenode returning call836
// compilenode returning call836
// Begin line 353
  setline(353);
// compilenode returning self
  params[0] = call836;
  Object call837 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call837
  *var_gtype = call837;
  if (call837 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if820 = nothing;
  }
// compilenode returning if820
    if809 = if820;
  }
// compilenode returning if809
// Begin line 355
  setline(355);
// Begin line 354
  setline(354);
// compilenode returning *var_gtype
  *var_gtb = *var_gtype;
  if (*var_gtype == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 358
  setline(358);
// Begin line 360
  setline(360);
// Begin line 1017
  setline(1017);
// Begin line 360
  setline(360);
// Begin line 1017
  setline(1017);
// Begin line 355
  setline(355);
// compilenode returning *var_expr
  Object call840 = callmethod(*var_expr, "params",
    0, params);
// compilenode returning call840
// compilenode returning call840
  Object call841 = callmethod(call840, "indices",
    0, params);
// compilenode returning call841
// compilenode returning call841
// Begin line 358
  setline(358);
// Begin line 1017
  setline(1017);
  Object obj843 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj843, self, 0);
  addmethod2(obj843, "outer", &reader_typechecker_outer_844);
  adddatum2(obj843, self, 0);
  block_savedest(obj843);
  Object **closure845 = createclosure(4);
  addtoclosure(closure845, var_gtb);
  addtoclosure(closure845, var_expr);
  addtoclosure(closure845, var_gtype);
  Object *selfpp853 = alloc_var();
  *selfpp853 = self;
  addtoclosure(closure845, selfpp853);
  struct UserObject *uo845 = (struct UserObject*)obj843;
  uo845->data[1] = (Object)closure845;
  addmethod2(obj843, "apply", &meth_typechecker_apply845);
  set_type(obj843, 0);
// compilenode returning obj843
  setclassname(obj843, "Block<typechecker:842>");
// compilenode returning obj843
  params[0] = call841;
  Object iter839 = callmethod(call841, "iter", 1, params);
  while(1) {
    Object cond839 = callmethod(iter839, "havemore", 0, NULL);
    if (!istrue(cond839)) break;
    params[0] = callmethod(iter839, "next", 0, NULL);
    callmethod(obj843, "apply", 1, params);
  }
// compilenode returning call841
// Begin line 360
  setline(360);
// compilenode returning *var_gname
// Begin line 1017
  setline(1017);
// Begin line 360
  setline(360);
// compilenode returning *var_gtype
  Object call854 = callmethod(*var_gtype, "methods",
    0, params);
// compilenode returning call854
// compilenode returning call854
// compilenode returning module_ast
  params[0] = *var_gname;
  params[1] = call854;
  Object call855 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call855
  *var_nt = call855;
  if (call855 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 362
  setline(362);
// Begin line 1017
  setline(1017);
// Begin line 362
  setline(362);
// Begin line 1017
  setline(1017);
// Begin line 361
  setline(361);
// compilenode returning *var_expr
  Object call856 = callmethod(*var_expr, "params",
    0, params);
// compilenode returning call856
// compilenode returning call856
// compilenode returning *var_nt
  params[0] = call856;
  Object call857 = callmethod(*var_nt, "generics:=",
    1, params);
// compilenode returning call857
// compilenode returning nothing
// Begin line 362
  setline(362);
// compilenode returning *var_nt
// compilenode returning module_subtype
  params[0] = *var_nt;
  Object call858 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call858
// Begin line 364
  setline(364);
// Begin line 363
  setline(363);
// compilenode returning *var_nt
  return *var_nt;
// compilenode returning undefined
    if804 = undefined;
  } else {
  }
// compilenode returning if804
// Begin line 366
  setline(366);
// Begin line 365
  setline(365);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
  return undefined;
}
Object meth_typechecker_checkShadowing859(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object *var_name = alloc_var();
  *var_name = args[0];
  Object *var_kd = alloc_var();
  *var_kd = args[1];
  Object params[1];
// Begin line 369
  setline(369);
// compilenode returning *var_name
// Begin line 382
  setline(382);
// compilenode returning self
  params[0] = *var_name;
  Object call861 = callmethod(self, "haveBinding",
    1, params);
// compilenode returning call861
  Object if860;
  if (istrue(call861)) {
  Object *var_namebinding = alloc_var();
  *var_namebinding = undefined;
// Begin line 370
  setline(370);
// compilenode returning *var_name
// Begin line 371
  setline(371);
// compilenode returning self
  params[0] = *var_name;
  Object call862 = callmethod(self, "findName",
    1, params);
// compilenode returning call862
  var_namebinding = alloc_var();
  *var_namebinding = call862;
  if (call862 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 379
  setline(379);
// Begin line 381
  setline(381);
// Begin line 371
  setline(371);
// compilenode returning *var_kd
  if (strlit864 == NULL) {
    strlit864 = alloc_String("method");
  }
// compilenode returning strlit864
  params[0] = strlit864;
  Object opresult866 = callmethod(*var_kd, "==", 1, params);
// compilenode returning opresult866
// Begin line 381
  setline(381);
// Begin line 1017
  setline(1017);
// Begin line 371
  setline(371);
// compilenode returning *var_namebinding
  Object call867 = callmethod(*var_namebinding, "kind",
    0, params);
// compilenode returning call867
// compilenode returning call867
  if (strlit868 == NULL) {
    strlit868 = alloc_String("var");
  }
// compilenode returning strlit868
  params[0] = strlit868;
  Object opresult870 = callmethod(call867, "==", 1, params);
// compilenode returning opresult870
// Begin line 381
  setline(381);
// Begin line 1017
  setline(1017);
// Begin line 372
  setline(372);
// compilenode returning *var_namebinding
  Object call871 = callmethod(*var_namebinding, "kind",
    0, params);
// compilenode returning call871
// compilenode returning call871
  if (strlit872 == NULL) {
    strlit872 = alloc_String("method");
  }
// compilenode returning strlit872
  params[0] = strlit872;
  Object opresult874 = callmethod(call871, "==", 1, params);
// compilenode returning opresult874
  params[0] = opresult874;
  Object opresult876 = callmethod(opresult870, "|", 1, params);
// compilenode returning opresult876
  params[0] = opresult876;
  Object opresult878 = callmethod(opresult866, "&", 1, params);
// compilenode returning opresult878
  Object if863;
  if (istrue(opresult878)) {
    if863 = undefined;
  } else {
// Begin line 379
  setline(379);
// Begin line 374
  setline(374);
  if (strlit880 == NULL) {
    strlit880 = alloc_String("ShadowingWarnOnly");
  }
// compilenode returning strlit880
// Begin line 376
  setline(376);
// Begin line 1017
  setline(1017);
// Begin line 374
  setline(374);
// compilenode returning module_util
  Object call881 = callmethod(module_util, "extensions",
    0, params);
// compilenode returning call881
// compilenode returning call881
  params[0] = strlit880;
  Object call882 = callmethod(call881, "contains",
    1, params);
// compilenode returning call882
  Object if879;
  if (istrue(call882)) {
// Begin line 375
  setline(375);
  if (strlit883 == NULL) {
    strlit883 = alloc_String("name ");
  }
// compilenode returning strlit883
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult885 = callmethod(strlit883, "++", 1, params);
// compilenode returning opresult885
  if (strlit886 == NULL) {
    strlit886 = alloc_String(" shadows lexically enclosing name");
  }
// compilenode returning strlit886
  params[0] = strlit886;
  Object opresult888 = callmethod(opresult885, "++", 1, params);
// compilenode returning opresult888
// compilenode returning module_util
  params[0] = opresult888;
  Object call889 = callmethod(module_util, "warning",
    1, params);
// compilenode returning call889
    if879 = call889;
  } else {
// Begin line 379
  setline(379);
// Begin line 376
  setline(376);
  if (strlit891 == NULL) {
    strlit891 = alloc_String("IgnoreShadowing");
  }
// compilenode returning strlit891
// Begin line 378
  setline(378);
// Begin line 1017
  setline(1017);
// Begin line 376
  setline(376);
// compilenode returning module_util
  Object call892 = callmethod(module_util, "extensions",
    0, params);
// compilenode returning call892
// compilenode returning call892
  params[0] = strlit891;
  Object call893 = callmethod(call892, "contains",
    1, params);
// compilenode returning call893
  Object if890;
  if (istrue(call893)) {
    if890 = undefined;
  } else {
// Begin line 379
  setline(379);
  if (strlit894 == NULL) {
    strlit894 = alloc_String("name ");
  }
// compilenode returning strlit894
// compilenode returning *var_name
  params[0] = *var_name;
  Object opresult896 = callmethod(strlit894, "++", 1, params);
// compilenode returning opresult896
  if (strlit897 == NULL) {
    strlit897 = alloc_String(" shadows lexically enclosing name");
  }
// compilenode returning strlit897
  params[0] = strlit897;
  Object opresult899 = callmethod(opresult896, "++", 1, params);
// compilenode returning opresult899
// compilenode returning module_util
  params[0] = opresult899;
  Object call900 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call900
    if890 = call900;
  }
// compilenode returning if890
    if879 = if890;
  }
// compilenode returning if879
    if863 = if879;
  }
// compilenode returning if863
    if860 = if863;
  } else {
  }
// compilenode returning if860
  return if860;
}
Object meth_typechecker_bindName901(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object *var_name = alloc_var();
  *var_name = args[0];
  Object *var_binding = alloc_var();
  *var_binding = args[1];
  Object params[2];
  Object *var_scopes = closure[0];
// Begin line 384
  setline(384);
// compilenode returning *var_name
// Begin line 1017
  setline(1017);
// Begin line 384
  setline(384);
// compilenode returning *var_binding
  Object call902 = callmethod(*var_binding, "kind",
    0, params);
// compilenode returning call902
// compilenode returning call902
// Begin line 385
  setline(385);
// compilenode returning self
  params[0] = *var_name;
  params[1] = call902;
  Object call903 = callmethod(self, "checkShadowing",
    2, params);
// compilenode returning call903
// compilenode returning *var_name
// compilenode returning *var_binding
// Begin line 386
  setline(386);
// Begin line 1017
  setline(1017);
// Begin line 385
  setline(385);
// compilenode returning *var_scopes
  Object call904 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call904
// compilenode returning call904
  params[0] = *var_name;
  params[1] = *var_binding;
  Object call905 = callmethod(call904, "put",
    2, params);
// compilenode returning call905
  return call905;
}
Object meth_typechecker_bindIdentifier906(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object *var_ident = alloc_var();
  *var_ident = args[0];
  Object params[2];
  Object *var_scopes = closure[0];
  Object *var_Binding = closure[1];
  Object *var_DynamicType = closure[2];
// Begin line 389
  setline(389);
// Begin line 391
  setline(391);
// Begin line 1017
  setline(1017);
// Begin line 388
  setline(388);
// compilenode returning *var_ident
  Object call908 = callmethod(*var_ident, "kind",
    0, params);
// compilenode returning call908
// compilenode returning call908
  if (strlit909 == NULL) {
    strlit909 = alloc_String("call");
  }
// compilenode returning strlit909
  params[0] = strlit909;
  Object opresult911 = callmethod(call908, "==", 1, params);
// compilenode returning opresult911
  Object if907;
  if (istrue(opresult911)) {
// Begin line 389
  setline(389);
  if (strlit912 == NULL) {
    strlit912 = alloc_String("name shadows method");
  }
// compilenode returning strlit912
// compilenode returning module_util
  params[0] = strlit912;
  Object call913 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call913
    if907 = call913;
  } else {
  }
// compilenode returning if907
// Begin line 405
  setline(405);
// Begin line 391
  setline(391);
  if (strlit915 == NULL) {
    strlit915 = alloc_String("___is_object");
  }
// compilenode returning strlit915
// Begin line 407
  setline(407);
// Begin line 1017
  setline(1017);
// Begin line 391
  setline(391);
// compilenode returning *var_scopes
  Object call916 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call916
// compilenode returning call916
  params[0] = strlit915;
  Object call917 = callmethod(call916, "contains",
    1, params);
// compilenode returning call917
  Object if914;
  if (istrue(call917)) {
// Begin line 392
  setline(392);
// Begin line 1017
  setline(1017);
// Begin line 392
  setline(392);
// compilenode returning *var_ident
  Object call918 = callmethod(*var_ident, "value",
    0, params);
// compilenode returning call918
// compilenode returning call918
  if (strlit919 == NULL) {
    strlit919 = alloc_String("method");
  }
// compilenode returning strlit919
// Begin line 393
  setline(393);
// compilenode returning self
  params[0] = call918;
  params[1] = strlit919;
  Object call920 = callmethod(self, "checkShadowing",
    2, params);
// compilenode returning call920
// Begin line 1017
  setline(1017);
// Begin line 393
  setline(393);
// compilenode returning *var_ident
  Object call921 = callmethod(*var_ident, "value",
    0, params);
// compilenode returning call921
// compilenode returning call921
  if (strlit922 == NULL) {
    strlit922 = alloc_String("method");
  }
// compilenode returning strlit922
// compilenode returning *var_Binding
  params[0] = strlit922;
  Object call923 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call923
// Begin line 394
  setline(394);
// Begin line 1017
  setline(1017);
// Begin line 393
  setline(393);
// compilenode returning *var_scopes
  Object call924 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call924
// compilenode returning call924
  params[0] = call921;
  params[1] = call923;
  Object call925 = callmethod(call924, "put",
    2, params);
// compilenode returning call925
    if914 = call925;
  } else {
  Object *var_tmpb = alloc_var();
  *var_tmpb = undefined;
  Object *var_tdtype = alloc_var();
  *var_tdtype = undefined;
// Begin line 395
  setline(395);
// Begin line 1017
  setline(1017);
// Begin line 395
  setline(395);
// compilenode returning *var_ident
  Object call926 = callmethod(*var_ident, "value",
    0, params);
// compilenode returning call926
// compilenode returning call926
  if (strlit927 == NULL) {
    strlit927 = alloc_String("var");
  }
// compilenode returning strlit927
// Begin line 396
  setline(396);
// compilenode returning self
  params[0] = call926;
  params[1] = strlit927;
  Object call928 = callmethod(self, "checkShadowing",
    2, params);
// compilenode returning call928
  if (strlit929 == NULL) {
    strlit929 = alloc_String("var");
  }
// compilenode returning strlit929
// compilenode returning *var_Binding
  params[0] = strlit929;
  Object call930 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call930
  var_tmpb = alloc_var();
  *var_tmpb = call930;
  if (call930 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 398
  setline(398);
// Begin line 397
  setline(397);
// compilenode returning *var_DynamicType
  var_tdtype = alloc_var();
  *var_tdtype = *var_DynamicType;
  if (*var_DynamicType == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 403
  setline(403);
// Begin line 404
  setline(404);
// Begin line 1017
  setline(1017);
// Begin line 398
  setline(398);
// compilenode returning *var_ident
  Object call932 = callmethod(*var_ident, "dtype",
    0, params);
// compilenode returning call932
// compilenode returning call932
  Object bool933 = alloc_Boolean(0);
// compilenode returning bool933
  params[0] = bool933;
  Object opresult935 = callmethod(call932, "==", 1, params);
// compilenode returning opresult935
  Object if931;
  if (istrue(opresult935)) {
    if931 = undefined;
  } else {
// Begin line 403
  setline(403);
// Begin line 404
  setline(404);
// Begin line 1017
  setline(1017);
// Begin line 404
  setline(404);
// Begin line 1017
  setline(1017);
// Begin line 400
  setline(400);
// compilenode returning *var_ident
  Object call937 = callmethod(*var_ident, "dtype",
    0, params);
// compilenode returning call937
// compilenode returning call937
  Object call938 = callmethod(call937, "kind",
    0, params);
// compilenode returning call938
// compilenode returning call938
  if (strlit939 == NULL) {
    strlit939 = alloc_String("identifier");
  }
// compilenode returning strlit939
  params[0] = strlit939;
  Object opresult941 = callmethod(call938, "==", 1, params);
// compilenode returning opresult941
  Object if936;
  if (istrue(opresult941)) {
  Object *var_tdb = alloc_var();
  *var_tdb = undefined;
// Begin line 401
  setline(401);
// Begin line 1017
  setline(1017);
// Begin line 401
  setline(401);
// Begin line 1017
  setline(1017);
// Begin line 401
  setline(401);
// compilenode returning *var_ident
  Object call942 = callmethod(*var_ident, "dtype",
    0, params);
// compilenode returning call942
// compilenode returning call942
  Object call943 = callmethod(call942, "value",
    0, params);
// compilenode returning call943
// compilenode returning call943
// Begin line 402
  setline(402);
// compilenode returning self
  params[0] = call943;
  Object call944 = callmethod(self, "findName",
    1, params);
// compilenode returning call944
  *var_tdb = call944;
  if (call944 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 403
  setline(403);
// Begin line 1017
  setline(1017);
// Begin line 402
  setline(402);
// compilenode returning *var_tdb
  Object call945 = callmethod(*var_tdb, "value",
    0, params);
// compilenode returning call945
// compilenode returning call945
  *var_tdtype = call945;
  if (call945 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if936 = nothing;
  } else {
  }
// compilenode returning if936
    if931 = if936;
  }
// compilenode returning if931
// Begin line 405
  setline(405);
// Begin line 1017
  setline(1017);
// Begin line 404
  setline(404);
// compilenode returning *var_tdtype
// compilenode returning *var_tmpb
  params[0] = *var_tdtype;
  Object call947 = callmethod(*var_tmpb, "dtype:=",
    1, params);
// compilenode returning call947
// compilenode returning nothing
// Begin line 405
  setline(405);
// Begin line 1017
  setline(1017);
// Begin line 405
  setline(405);
// compilenode returning *var_ident
  Object call948 = callmethod(*var_ident, "value",
    0, params);
// compilenode returning call948
// compilenode returning call948
// compilenode returning *var_tmpb
// Begin line 406
  setline(406);
// Begin line 1017
  setline(1017);
// Begin line 405
  setline(405);
// compilenode returning *var_scopes
  Object call949 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call949
// compilenode returning call949
  params[0] = call948;
  params[1] = *var_tmpb;
  Object call950 = callmethod(call949, "put",
    2, params);
// compilenode returning call950
    if914 = call950;
  }
// compilenode returning if914
  return if914;
}
Object meth_typechecker_apply997(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_pp = alloc_var();
  *var_pp = args[0];
  Object params[3];
  Object *var_tmpparams = closure[0];
  Object *var_typevar = closure[1];
  Object *var_concrete = closure[2];
  Object *var_changed = closure[3];
  Object self = *closure[4];
// Begin line 449
  setline(449);
// Begin line 451
  setline(451);
// Begin line 1017
  setline(1017);
// Begin line 431
  setline(431);
// compilenode returning *var_pp
  Object call999 = callmethod(*var_pp, "dtype",
    0, params);
// compilenode returning call999
// compilenode returning call999
  Object bool1000 = alloc_Boolean(0);
// compilenode returning bool1000
  params[0] = bool1000;
  Object opresult1002 = callmethod(call999, "==", 1, params);
// compilenode returning opresult1002
  Object if998;
  if (istrue(opresult1002)) {
// Begin line 432
  setline(432);
// compilenode returning *var_pp
// compilenode returning *var_tmpparams
  params[0] = *var_pp;
  Object call1003 = callmethod(*var_tmpparams, "push",
    1, params);
// compilenode returning call1003
    if998 = call1003;
  } else {
// Begin line 449
  setline(449);
// Begin line 436
  setline(436);
// Begin line 1017
  setline(1017);
// Begin line 436
  setline(436);
// Begin line 1017
  setline(1017);
// Begin line 433
  setline(433);
// compilenode returning *var_pp
  Object call1005 = callmethod(*var_pp, "dtype",
    0, params);
// compilenode returning call1005
// compilenode returning call1005
  Object call1006 = callmethod(call1005, "value",
    0, params);
// compilenode returning call1006
// compilenode returning call1006
// Begin line 436
  setline(436);
// Begin line 1017
  setline(1017);
// Begin line 433
  setline(433);
// compilenode returning *var_typevar
  Object call1007 = callmethod(*var_typevar, "value",
    0, params);
// compilenode returning call1007
// compilenode returning call1007
  params[0] = call1007;
  Object opresult1009 = callmethod(call1006, "==", 1, params);
// compilenode returning opresult1009
  Object if1004;
  if (istrue(opresult1009)) {
// Begin line 434
  setline(434);
// Begin line 1017
  setline(1017);
// Begin line 434
  setline(434);
// compilenode returning *var_pp
  Object call1010 = callmethod(*var_pp, "value",
    0, params);
// compilenode returning call1010
// compilenode returning call1010
// compilenode returning *var_concrete
// compilenode returning module_ast
  params[0] = call1010;
  params[1] = *var_concrete;
  Object call1011 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1011
// compilenode returning *var_tmpparams
  params[0] = call1011;
  Object call1012 = callmethod(*var_tmpparams, "push",
    1, params);
// compilenode returning call1012
// Begin line 436
  setline(436);
// Begin line 435
  setline(435);
  Object bool1013 = alloc_Boolean(1);
// compilenode returning bool1013
  *var_changed = bool1013;
  if (bool1013 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1004 = nothing;
  } else {
// Begin line 449
  setline(449);
// Begin line 436
  setline(436);
  Object num1016 = alloc_Float64(1.0);
// compilenode returning num1016
// Begin line 448
  setline(448);
// Begin line 1017
  setline(1017);
// Begin line 448
  setline(448);
// Begin line 1017
  setline(1017);
// Begin line 436
  setline(436);
// compilenode returning *var_pp
  Object call1017 = callmethod(*var_pp, "dtype",
    0, params);
// compilenode returning call1017
// compilenode returning call1017
  Object call1018 = callmethod(call1017, "value",
    0, params);
// compilenode returning call1018
// compilenode returning call1018
  params[0] = num1016;
  Object call1019 = callmethod(call1018, "at",
    1, params);
// compilenode returning call1019
  if (strlit1020 == NULL) {
    strlit1020 = alloc_String("<");
  }
// compilenode returning strlit1020
  params[0] = strlit1020;
  Object opresult1022 = callmethod(call1019, "==", 1, params);
// compilenode returning opresult1022
  Object if1015;
  if (istrue(opresult1022)) {
  Object *var_otype = alloc_var();
  *var_otype = undefined;
  Object *var_tryrep = alloc_var();
  *var_tryrep = undefined;
// Begin line 437
  setline(437);
// Begin line 1017
  setline(1017);
// Begin line 437
  setline(437);
// compilenode returning *var_pp
  Object call1023 = callmethod(*var_pp, "dtype",
    0, params);
// compilenode returning call1023
// compilenode returning call1023
// Begin line 438
  setline(438);
// compilenode returning self
  params[0] = call1023;
  Object call1024 = callmethod(self, "findType",
    1, params);
// compilenode returning call1024
  *var_otype = call1024;
  if (call1024 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_otype
// compilenode returning *var_typevar
// compilenode returning *var_concrete
// Begin line 439
  setline(439);
// compilenode returning self
  params[0] = *var_otype;
  params[1] = *var_typevar;
  params[2] = *var_concrete;
  Object call1025 = callmethod(self, "betaReduceType",
    3, params);
// compilenode returning call1025
  *var_tryrep = call1025;
  if (call1025 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 447
  setline(447);
// Begin line 448
  setline(448);
// Begin line 439
  setline(439);
// compilenode returning *var_otype
// compilenode returning *var_tryrep
  params[0] = *var_tryrep;
  Object opresult1028 = callmethod(*var_otype, "==", 1, params);
// compilenode returning opresult1028
  Object if1026;
  if (istrue(opresult1028)) {
// Begin line 440
  setline(440);
// compilenode returning *var_pp
// compilenode returning *var_tmpparams
  params[0] = *var_pp;
  Object call1029 = callmethod(*var_tmpparams, "push",
    1, params);
// compilenode returning call1029
    if1026 = call1029;
  } else {
  Object *var_trynamed = alloc_var();
  *var_trynamed = undefined;
// Begin line 444
  setline(444);
// Begin line 443
  setline(443);
// Begin line 1017
  setline(1017);
// Begin line 442
  setline(442);
// compilenode returning *var_tryrep
  Object call1030 = callmethod(*var_tryrep, "value",
    0, params);
// compilenode returning call1030
// compilenode returning call1030
// Begin line 443
  setline(443);
  if (strlit1031 == NULL) {
    strlit1031 = alloc_String("<");
  }
// compilenode returning strlit1031
// Begin line 1017
  setline(1017);
// Begin line 443
  setline(443);
// compilenode returning *var_typevar
  Object call1032 = callmethod(*var_typevar, "value",
    0, params);
// compilenode returning call1032
// compilenode returning call1032
  params[0] = call1032;
  Object opresult1034 = callmethod(strlit1031, "++", 1, params);
// compilenode returning opresult1034
  if (strlit1035 == NULL) {
    strlit1035 = alloc_String("=");
  }
// compilenode returning strlit1035
  params[0] = strlit1035;
  Object opresult1037 = callmethod(opresult1034, "++", 1, params);
// compilenode returning opresult1037
// Begin line 1017
  setline(1017);
// Begin line 443
  setline(443);
// compilenode returning *var_concrete
  Object call1038 = callmethod(*var_concrete, "value",
    0, params);
// compilenode returning call1038
// compilenode returning call1038
  params[0] = call1038;
  Object opresult1040 = callmethod(opresult1037, "++", 1, params);
// compilenode returning opresult1040
  if (strlit1041 == NULL) {
    strlit1041 = alloc_String(">");
  }
// compilenode returning strlit1041
  params[0] = strlit1041;
  Object opresult1043 = callmethod(opresult1040, "++", 1, params);
// compilenode returning opresult1043
  params[0] = opresult1043;
  Object opresult1045 = callmethod(call1030, "++", 1, params);
// compilenode returning opresult1045
// Begin line 444
  setline(444);
// Begin line 1017
  setline(1017);
// Begin line 444
  setline(444);
// compilenode returning *var_tryrep
  Object call1046 = callmethod(*var_tryrep, "methods",
    0, params);
// compilenode returning call1046
// compilenode returning call1046
// Begin line 442
  setline(442);
// compilenode returning module_ast
  params[0] = opresult1045;
  params[1] = call1046;
  Object call1047 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1047
  *var_trynamed = call1047;
  if (call1047 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 445
  setline(445);
// Begin line 1017
  setline(1017);
// Begin line 445
  setline(445);
// compilenode returning *var_pp
  Object call1048 = callmethod(*var_pp, "value",
    0, params);
// compilenode returning call1048
// compilenode returning call1048
// compilenode returning *var_trynamed
// compilenode returning module_ast
  params[0] = call1048;
  params[1] = *var_trynamed;
  Object call1049 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1049
// compilenode returning *var_tmpparams
  params[0] = call1049;
  Object call1050 = callmethod(*var_tmpparams, "push",
    1, params);
// compilenode returning call1050
// Begin line 447
  setline(447);
// Begin line 446
  setline(446);
  Object bool1051 = alloc_Boolean(1);
// compilenode returning bool1051
  *var_changed = bool1051;
  if (bool1051 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1026 = nothing;
  }
// compilenode returning if1026
    if1015 = if1026;
  } else {
// Begin line 449
  setline(449);
// compilenode returning *var_pp
// compilenode returning *var_tmpparams
  params[0] = *var_pp;
  Object call1053 = callmethod(*var_tmpparams, "push",
    1, params);
// compilenode returning call1053
    if1015 = call1053;
  }
// compilenode returning if1015
    if1004 = if1015;
  }
// compilenode returning if1004
    if998 = if1004;
  }
// compilenode returning if998
  return if998;
}
Object meth_typechecker_apply959(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_m = alloc_var();
  *var_m = args[0];
  Object params[3];
  Object *var_tmprt = closure[0];
  Object *var_typevar = closure[1];
  Object *var_concrete = closure[2];
  Object *var_changed = closure[3];
  Object *var_tmpparams = closure[4];
  Object *var_newmeth = closure[5];
  Object self = *closure[6];
// Begin line 417
  setline(417);
// Begin line 1017
  setline(1017);
// Begin line 416
  setline(416);
// compilenode returning *var_m
  Object call960 = callmethod(*var_m, "rtype",
    0, params);
// compilenode returning call960
// compilenode returning call960
  *var_tmprt = call960;
  if (call960 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 427
  setline(427);
// Begin line 429
  setline(429);
// Begin line 417
  setline(417);
// compilenode returning *var_tmprt
  Object bool963 = alloc_Boolean(0);
// compilenode returning bool963
  params[0] = bool963;
  Object opresult965 = callmethod(*var_tmprt, "==", 1, params);
// compilenode returning opresult965
  Object if962;
  if (istrue(opresult965)) {
    if962 = undefined;
  } else {
// Begin line 427
  setline(427);
// Begin line 421
  setline(421);
// Begin line 1017
  setline(1017);
// Begin line 418
  setline(418);
// compilenode returning *var_tmprt
  Object call967 = callmethod(*var_tmprt, "value",
    0, params);
// compilenode returning call967
// compilenode returning call967
// Begin line 421
  setline(421);
// Begin line 1017
  setline(1017);
// Begin line 418
  setline(418);
// compilenode returning *var_typevar
  Object call968 = callmethod(*var_typevar, "value",
    0, params);
// compilenode returning call968
// compilenode returning call968
  params[0] = call968;
  Object opresult970 = callmethod(call967, "==", 1, params);
// compilenode returning opresult970
  Object if966;
  if (istrue(opresult970)) {
// Begin line 420
  setline(420);
// Begin line 419
  setline(419);
// compilenode returning *var_concrete
  *var_tmprt = *var_concrete;
  if (*var_concrete == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 421
  setline(421);
// Begin line 420
  setline(420);
  Object bool972 = alloc_Boolean(1);
// compilenode returning bool972
  *var_changed = bool972;
  if (bool972 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if966 = nothing;
  } else {
// Begin line 427
  setline(427);
// Begin line 421
  setline(421);
  Object num975 = alloc_Float64(1.0);
// compilenode returning num975
  Object num976 = alloc_Float64(11.0);
// compilenode returning num976
// Begin line 429
  setline(429);
// Begin line 1017
  setline(1017);
// Begin line 421
  setline(421);
// compilenode returning *var_tmprt
  Object call977 = callmethod(*var_tmprt, "value",
    0, params);
// compilenode returning call977
// compilenode returning call977
  params[0] = num975;
  params[1] = num976;
  Object call978 = callmethod(call977, "substringFrom(1)to",
    2, params);
// compilenode returning call978
  if (strlit979 == NULL) {
    strlit979 = alloc_String("InstanceOf<");
  }
// compilenode returning strlit979
  params[0] = strlit979;
  Object opresult981 = callmethod(call978, "==", 1, params);
// compilenode returning opresult981
  Object if974;
  if (istrue(opresult981)) {
  Object *var_ortype = alloc_var();
  *var_ortype = undefined;
  Object *var_tryrrep = alloc_var();
  *var_tryrrep = undefined;
// Begin line 422
  setline(422);
// compilenode returning *var_tmprt
// Begin line 423
  setline(423);
// compilenode returning self
  params[0] = *var_tmprt;
  Object call982 = callmethod(self, "findType",
    1, params);
// compilenode returning call982
  *var_ortype = call982;
  if (call982 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_ortype
// compilenode returning *var_typevar
// compilenode returning *var_concrete
// Begin line 424
  setline(424);
// compilenode returning self
  params[0] = *var_ortype;
  params[1] = *var_typevar;
  params[2] = *var_concrete;
  Object call983 = callmethod(self, "betaReduceType",
    3, params);
// compilenode returning call983
  *var_tryrrep = call983;
  if (call983 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 427
  setline(427);
// Begin line 428
  setline(428);
// Begin line 424
  setline(424);
// compilenode returning *var_ortype
// compilenode returning *var_tryrrep
  params[0] = *var_tryrrep;
  Object opresult986 = callmethod(*var_ortype, "/=", 1, params);
// compilenode returning opresult986
  Object if984;
  if (istrue(opresult986)) {
// Begin line 426
  setline(426);
// Begin line 425
  setline(425);
// compilenode returning *var_tryrrep
  *var_tmprt = *var_tryrrep;
  if (*var_tryrrep == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 427
  setline(427);
// Begin line 426
  setline(426);
  Object bool988 = alloc_Boolean(1);
// compilenode returning bool988
  *var_changed = bool988;
  if (bool988 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if984 = nothing;
  } else {
  }
// compilenode returning if984
    if974 = if984;
  } else {
  }
// compilenode returning if974
    if966 = if974;
  }
// compilenode returning if966
    if962 = if966;
  }
// compilenode returning if962
// Begin line 430
  setline(430);
  Object array990 = alloc_List();
// compilenode returning array990
  *var_tmpparams = array990;
  if (array990 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 449
  setline(449);
// Begin line 452
  setline(452);
// Begin line 1017
  setline(1017);
// Begin line 430
  setline(430);
// compilenode returning *var_m
  Object call993 = callmethod(*var_m, "params",
    0, params);
// compilenode returning call993
// compilenode returning call993
// Begin line 449
  setline(449);
// Begin line 1017
  setline(1017);
  Object obj995 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj995, self, 0);
  addmethod2(obj995, "outer", &reader_typechecker_outer_996);
  adddatum2(obj995, self, 0);
  block_savedest(obj995);
  Object **closure997 = createclosure(5);
  addtoclosure(closure997, var_tmpparams);
  addtoclosure(closure997, var_typevar);
  addtoclosure(closure997, var_concrete);
  addtoclosure(closure997, var_changed);
  Object *selfpp1054 = alloc_var();
  *selfpp1054 = self;
  addtoclosure(closure997, selfpp1054);
  struct UserObject *uo997 = (struct UserObject*)obj995;
  uo997->data[1] = (Object)closure997;
  addmethod2(obj995, "apply", &meth_typechecker_apply997);
  set_type(obj995, 0);
// compilenode returning obj995
  setclassname(obj995, "Block<typechecker:994>");
// compilenode returning obj995
  params[0] = call993;
  Object iter992 = callmethod(call993, "iter", 1, params);
  while(1) {
    Object cond992 = callmethod(iter992, "havemore", 0, NULL);
    if (!istrue(cond992)) break;
    params[0] = callmethod(iter992, "next", 0, NULL);
    callmethod(obj995, "apply", 1, params);
  }
// compilenode returning call993
// Begin line 452
  setline(452);
// Begin line 1017
  setline(1017);
// Begin line 452
  setline(452);
// compilenode returning *var_m
  Object call1055 = callmethod(*var_m, "value",
    0, params);
// compilenode returning call1055
// compilenode returning call1055
// compilenode returning *var_tmpparams
// compilenode returning *var_tmprt
// compilenode returning module_ast
  params[0] = call1055;
  params[1] = *var_tmpparams;
  params[2] = *var_tmprt;
  Object call1056 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call1056
// compilenode returning *var_newmeth
  params[0] = call1056;
  Object call1057 = callmethod(*var_newmeth, "push",
    1, params);
// compilenode returning call1057
  return call1057;
}
Object meth_typechecker_betaReduceType951(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object *var_tp = alloc_var();
  *var_tp = args[0];
  Object *var_typevar = alloc_var();
  *var_typevar = args[1];
  Object *var_concrete = alloc_var();
  *var_concrete = args[2];
  Object params[2];
  Object *var_methods = alloc_var();
  *var_methods = undefined;
  Object *var_tmpparams = alloc_var();
  *var_tmpparams = undefined;
  Object *var_tmprt = alloc_var();
  *var_tmprt = undefined;
  Object *var_newmeth = alloc_var();
  *var_newmeth = undefined;
  Object *var_changed = alloc_var();
  *var_changed = undefined;
// Begin line 411
  setline(411);
// Begin line 1017
  setline(1017);
// Begin line 410
  setline(410);
// compilenode returning *var_tp
  Object call952 = callmethod(*var_tp, "methods",
    0, params);
// compilenode returning call952
// compilenode returning call952
  var_methods = alloc_var();
  *var_methods = call952;
  if (call952 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 412
  setline(412);
  var_tmpparams = alloc_var();
  *var_tmpparams = undefined;
// compilenode returning nothing
// Begin line 413
  setline(413);
  var_tmprt = alloc_var();
  *var_tmprt = undefined;
// compilenode returning nothing
// Begin line 414
  setline(414);
  Object array953 = alloc_List();
// compilenode returning array953
  var_newmeth = alloc_var();
  *var_newmeth = array953;
  if (array953 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 415
  setline(415);
// Begin line 414
  setline(414);
  Object bool954 = alloc_Boolean(0);
// compilenode returning bool954
  var_changed = alloc_var();
  *var_changed = bool954;
  if (bool954 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 452
  setline(452);
// Begin line 415
  setline(415);
// compilenode returning *var_methods
// Begin line 452
  setline(452);
// Begin line 1017
  setline(1017);
  Object obj957 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj957, self, 0);
  addmethod2(obj957, "outer", &reader_typechecker_outer_958);
  adddatum2(obj957, self, 0);
  block_savedest(obj957);
  Object **closure959 = createclosure(7);
  addtoclosure(closure959, var_tmprt);
  addtoclosure(closure959, var_typevar);
  addtoclosure(closure959, var_concrete);
  addtoclosure(closure959, var_changed);
  addtoclosure(closure959, var_tmpparams);
  addtoclosure(closure959, var_newmeth);
  Object *selfpp1058 = alloc_var();
  *selfpp1058 = self;
  addtoclosure(closure959, selfpp1058);
  struct UserObject *uo959 = (struct UserObject*)obj957;
  uo959->data[1] = (Object)closure959;
  addmethod2(obj957, "apply", &meth_typechecker_apply959);
  set_type(obj957, 0);
// compilenode returning obj957
  setclassname(obj957, "Block<typechecker:956>");
// compilenode returning obj957
  params[0] = *var_methods;
  Object iter955 = callmethod(*var_methods, "iter", 1, params);
  while(1) {
    Object cond955 = callmethod(iter955, "havemore", 0, NULL);
    if (!istrue(cond955)) break;
    params[0] = callmethod(iter955, "next", 0, NULL);
    callmethod(obj957, "apply", 1, params);
  }
// compilenode returning *var_methods
// Begin line 468
  setline(468);
// Begin line 454
  setline(454);
// compilenode returning *var_changed
  Object if1059;
  if (istrue(*var_changed)) {
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
// Begin line 456
  setline(456);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 460
  setline(460);
// Begin line 456
  setline(456);
  Object num1061 = alloc_Float64(1.0);
// compilenode returning num1061
  Object num1062 = alloc_Float64(11.0);
// compilenode returning num1062
// Begin line 462
  setline(462);
// Begin line 1017
  setline(1017);
// Begin line 456
  setline(456);
// compilenode returning *var_tp
  Object call1063 = callmethod(*var_tp, "value",
    0, params);
// compilenode returning call1063
// compilenode returning call1063
  params[0] = num1061;
  params[1] = num1062;
  Object call1064 = callmethod(call1063, "substringFrom(1)to",
    2, params);
// compilenode returning call1064
  if (strlit1065 == NULL) {
    strlit1065 = alloc_String("InstanceOf<");
  }
// compilenode returning strlit1065
  params[0] = strlit1065;
  Object opresult1067 = callmethod(call1064, "==", 1, params);
// compilenode returning opresult1067
  Object if1060;
  if (istrue(opresult1067)) {
// Begin line 458
  setline(458);
// Begin line 457
  setline(457);
  if (strlit1068 == NULL) {
    strlit1068 = alloc_String("");
  }
// compilenode returning strlit1068
// Begin line 1017
  setline(1017);
// Begin line 457
  setline(457);
// compilenode returning *var_tp
  Object call1069 = callmethod(*var_tp, "value",
    0, params);
// compilenode returning call1069
// compilenode returning call1069
  params[0] = call1069;
  Object opresult1071 = callmethod(strlit1068, "++", 1, params);
// compilenode returning opresult1071
  if (strlit1072 == NULL) {
    strlit1072 = alloc_String("<");
  }
// compilenode returning strlit1072
  params[0] = strlit1072;
  Object opresult1074 = callmethod(opresult1071, "++", 1, params);
// compilenode returning opresult1074
// Begin line 1017
  setline(1017);
// Begin line 457
  setline(457);
// compilenode returning *var_typevar
  Object call1075 = callmethod(*var_typevar, "value",
    0, params);
// compilenode returning call1075
// compilenode returning call1075
  params[0] = call1075;
  Object opresult1077 = callmethod(opresult1074, "++", 1, params);
// compilenode returning opresult1077
  if (strlit1078 == NULL) {
    strlit1078 = alloc_String("=");
  }
// compilenode returning strlit1078
  params[0] = strlit1078;
  Object opresult1080 = callmethod(opresult1077, "++", 1, params);
// compilenode returning opresult1080
// Begin line 1017
  setline(1017);
// Begin line 457
  setline(457);
// compilenode returning *var_concrete
  Object call1081 = callmethod(*var_concrete, "value",
    0, params);
// compilenode returning call1081
// compilenode returning call1081
  params[0] = call1081;
  Object opresult1083 = callmethod(opresult1080, "++", 1, params);
// compilenode returning opresult1083
  if (strlit1084 == NULL) {
    strlit1084 = alloc_String(">");
  }
// compilenode returning strlit1084
  params[0] = strlit1084;
  Object opresult1086 = callmethod(opresult1083, "++", 1, params);
// compilenode returning opresult1086
// Begin line 458
  setline(458);
// compilenode returning *var_newmeth
// Begin line 457
  setline(457);
// compilenode returning module_ast
  params[0] = opresult1086;
  params[1] = *var_newmeth;
  Object call1087 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1087
  *var_tmp = call1087;
  if (call1087 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1060 = nothing;
  } else {
// Begin line 460
  setline(460);
// Begin line 1017
  setline(1017);
// Begin line 460
  setline(460);
// compilenode returning *var_tp
  Object call1089 = callmethod(*var_tp, "value",
    0, params);
// compilenode returning call1089
// compilenode returning call1089
// compilenode returning *var_newmeth
// compilenode returning module_ast
  params[0] = call1089;
  params[1] = *var_newmeth;
  Object call1090 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1090
  *var_tmp = call1090;
  if (call1090 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1060 = nothing;
  }
// compilenode returning if1060
// Begin line 463
  setline(463);
// Begin line 462
  setline(462);
  if (strlit1092 == NULL) {
    strlit1092 = alloc_String("");
  }
// compilenode returning strlit1092
// Begin line 1017
  setline(1017);
// Begin line 462
  setline(462);
// compilenode returning *var_tp
  Object call1093 = callmethod(*var_tp, "value",
    0, params);
// compilenode returning call1093
// compilenode returning call1093
  params[0] = call1093;
  Object opresult1095 = callmethod(strlit1092, "++", 1, params);
// compilenode returning opresult1095
  if (strlit1096 == NULL) {
    strlit1096 = alloc_String("<");
  }
// compilenode returning strlit1096
  params[0] = strlit1096;
  Object opresult1098 = callmethod(opresult1095, "++", 1, params);
// compilenode returning opresult1098
// Begin line 1017
  setline(1017);
// Begin line 462
  setline(462);
// compilenode returning *var_typevar
  Object call1099 = callmethod(*var_typevar, "value",
    0, params);
// compilenode returning call1099
// compilenode returning call1099
  params[0] = call1099;
  Object opresult1101 = callmethod(opresult1098, "++", 1, params);
// compilenode returning opresult1101
  if (strlit1102 == NULL) {
    strlit1102 = alloc_String("=");
  }
// compilenode returning strlit1102
  params[0] = strlit1102;
  Object opresult1104 = callmethod(opresult1101, "++", 1, params);
// compilenode returning opresult1104
// Begin line 1017
  setline(1017);
// Begin line 462
  setline(462);
// compilenode returning *var_concrete
  Object call1105 = callmethod(*var_concrete, "value",
    0, params);
// compilenode returning call1105
// compilenode returning call1105
  params[0] = call1105;
  Object opresult1107 = callmethod(opresult1104, "++", 1, params);
// compilenode returning opresult1107
  if (strlit1108 == NULL) {
    strlit1108 = alloc_String(">");
  }
// compilenode returning strlit1108
  params[0] = strlit1108;
  Object opresult1110 = callmethod(opresult1107, "++", 1, params);
// compilenode returning opresult1110
// Begin line 463
  setline(463);
// compilenode returning *var_newmeth
// Begin line 462
  setline(462);
// compilenode returning module_ast
  params[0] = opresult1110;
  params[1] = *var_newmeth;
  Object call1111 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1111
  *var_tmp = call1111;
  if (call1111 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 464
  setline(464);
// compilenode returning *var_tmp
// compilenode returning module_subtype
  params[0] = *var_tmp;
  Object call1113 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call1113
// Begin line 466
  setline(466);
// Begin line 465
  setline(465);
// compilenode returning *var_tmp
  return *var_tmp;
// compilenode returning undefined
    if1059 = undefined;
  } else {
// Begin line 468
  setline(468);
// Begin line 467
  setline(467);
// compilenode returning *var_tp
  return *var_tp;
// compilenode returning undefined
    if1059 = undefined;
  }
// compilenode returning if1059
  return if1059;
}
Object meth_typechecker_apply1148(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_gdt = alloc_var();
  *var_gdt = args[0];
  Object params[3];
  Object *var_gtp = closure[0];
  Object *var_DynamicType = closure[1];
  Object *var_gdyns = closure[2];
  Object self = *closure[3];
// Begin line 485
  setline(485);
// compilenode returning *var_gtp
// compilenode returning *var_gdt
// compilenode returning *var_DynamicType
// Begin line 486
  setline(486);
// compilenode returning self
  params[0] = *var_gtp;
  params[1] = *var_gdt;
  params[2] = *var_DynamicType;
  Object call1149 = callmethod(self, "betaReduceType",
    3, params);
// compilenode returning call1149
  *var_gtp = call1149;
  if (call1149 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_gdt
// compilenode returning *var_gdyns
  params[0] = *var_gdt;
  Object call1151 = callmethod(*var_gdyns, "push",
    1, params);
// compilenode returning call1151
  return call1151;
}
Object meth_typechecker_apply1185(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[3];
  Object *var_gtg = closure[0];
  Object *var_tp = closure[1];
  Object *var_gnms = closure[2];
  Object *var_tmptp = closure[3];
  Object self = *closure[4];
  Object *var_tv = alloc_var();
  *var_tv = undefined;
  Object *var_ct = alloc_var();
  *var_ct = undefined;
// Begin line 507
  setline(507);
// compilenode returning *var_i
// Begin line 508
  setline(508);
// Begin line 1017
  setline(1017);
// Begin line 507
  setline(507);
// compilenode returning *var_gtg
  Object call1186 = callmethod(*var_gtg, "generics",
    0, params);
// compilenode returning call1186
// compilenode returning call1186
  params[0] = *var_i;
  Object call1187 = callmethod(call1186, "at",
    1, params);
// compilenode returning call1187
  *var_tv = call1187;
  if (call1187 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 508
  setline(508);
// compilenode returning *var_i
// Begin line 1017
  setline(1017);
// Begin line 508
  setline(508);
// compilenode returning *var_tp
  Object call1188 = callmethod(*var_tp, "params",
    0, params);
// compilenode returning call1188
// compilenode returning call1188
  params[0] = *var_i;
  Object call1189 = callmethod(call1188, "at",
    1, params);
// compilenode returning call1189
// Begin line 509
  setline(509);
// compilenode returning self
  params[0] = call1189;
  Object call1190 = callmethod(self, "findType",
    1, params);
// compilenode returning call1190
  *var_ct = call1190;
  if (call1190 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 509
  setline(509);
// compilenode returning *var_ct
  Object call1191 = callmethod(*var_ct, "value",
    0, params);
// compilenode returning call1191
// compilenode returning call1191
// compilenode returning *var_gnms
  params[0] = call1191;
  Object call1192 = callmethod(*var_gnms, "push",
    1, params);
// compilenode returning call1192
// Begin line 510
  setline(510);
// compilenode returning *var_tmptp
// compilenode returning *var_tv
// compilenode returning *var_ct
// Begin line 511
  setline(511);
// compilenode returning self
  params[0] = *var_tmptp;
  params[1] = *var_tv;
  params[2] = *var_ct;
  Object call1193 = callmethod(self, "betaReduceType",
    3, params);
// compilenode returning call1193
  *var_tmptp = call1193;
  if (call1193 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_typechecker_findType1114(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object *var_tp = alloc_var();
  *var_tp = args[0];
  Object params[2];
  Object *var_DynamicType = closure[0];
// Begin line 473
  setline(473);
// Begin line 474
  setline(474);
// Begin line 471
  setline(471);
// compilenode returning *var_tp
  Object bool1116 = alloc_Boolean(0);
// compilenode returning bool1116
  params[0] = bool1116;
  Object opresult1118 = callmethod(*var_tp, "==", 1, params);
// compilenode returning opresult1118
  Object if1115;
  if (istrue(opresult1118)) {
// Begin line 473
  setline(473);
// Begin line 472
  setline(472);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
    if1115 = undefined;
  } else {
  }
// compilenode returning if1115
// Begin line 476
  setline(476);
// Begin line 477
  setline(477);
// Begin line 1017
  setline(1017);
// Begin line 474
  setline(474);
// compilenode returning *var_tp
  Object call1120 = callmethod(*var_tp, "kind",
    0, params);
// compilenode returning call1120
// compilenode returning call1120
  if (strlit1121 == NULL) {
    strlit1121 = alloc_String("type");
  }
// compilenode returning strlit1121
  params[0] = strlit1121;
  Object opresult1123 = callmethod(call1120, "==", 1, params);
// compilenode returning opresult1123
  Object if1119;
  if (istrue(opresult1123)) {
// Begin line 476
  setline(476);
// Begin line 475
  setline(475);
// compilenode returning *var_tp
  return *var_tp;
// compilenode returning undefined
    if1119 = undefined;
  } else {
  }
// compilenode returning if1119
// Begin line 492
  setline(492);
// Begin line 493
  setline(493);
// Begin line 1017
  setline(1017);
// Begin line 477
  setline(477);
// compilenode returning *var_tp
  Object call1125 = callmethod(*var_tp, "kind",
    0, params);
// compilenode returning call1125
// compilenode returning call1125
  if (strlit1126 == NULL) {
    strlit1126 = alloc_String("identifier");
  }
// compilenode returning strlit1126
  params[0] = strlit1126;
  Object opresult1128 = callmethod(call1125, "==", 1, params);
// compilenode returning opresult1128
  Object if1124;
  if (istrue(opresult1128)) {
  Object *var_tpnm = alloc_var();
  *var_tpnm = undefined;
  Object *var_tpbd = alloc_var();
  *var_tpbd = undefined;
  Object *var_gtp = alloc_var();
  *var_gtp = undefined;
// Begin line 479
  setline(479);
// Begin line 1017
  setline(1017);
// Begin line 478
  setline(478);
// compilenode returning *var_tp
  Object call1129 = callmethod(*var_tp, "value",
    0, params);
// compilenode returning call1129
// compilenode returning call1129
  *var_tpnm = call1129;
  if (call1129 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 479
  setline(479);
// compilenode returning *var_tpnm
// Begin line 480
  setline(480);
// compilenode returning self
  params[0] = *var_tpnm;
  Object call1130 = callmethod(self, "findName",
    1, params);
// compilenode returning call1130
  *var_tpbd = call1130;
  if (call1130 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 481
  setline(481);
// Begin line 1017
  setline(1017);
// Begin line 480
  setline(480);
// compilenode returning *var_tpbd
  Object call1131 = callmethod(*var_tpbd, "value",
    0, params);
// compilenode returning call1131
// compilenode returning call1131
  var_gtp = alloc_var();
  *var_gtp = call1131;
  if (call1131 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 486
  setline(486);
// Begin line 490
  setline(490);
// Begin line 481
  setline(481);
// compilenode returning *var_gtp
  Object bool1133 = alloc_Boolean(0);
// compilenode returning bool1133
  params[0] = bool1133;
  Object opresult1135 = callmethod(*var_gtp, "/=", 1, params);
// compilenode returning opresult1135
  Object if1132;
  if (istrue(opresult1135)) {
// Begin line 486
  setline(486);
// Begin line 489
  setline(489);
// Begin line 1017
  setline(1017);
// Begin line 489
  setline(489);
// Begin line 1017
  setline(1017);
// Begin line 482
  setline(482);
// compilenode returning *var_gtp
  Object call1137 = callmethod(*var_gtp, "generics",
    0, params);
// compilenode returning call1137
// compilenode returning call1137
  Object call1138 = callmethod(call1137, "size",
    0, params);
// compilenode returning call1138
// compilenode returning call1138
  Object num1139 = alloc_Float64(0.0);
// compilenode returning num1139
  params[0] = num1139;
  Object opresult1141 = callmethod(call1138, ">", 1, params);
// compilenode returning opresult1141
  Object if1136;
  if (istrue(opresult1141)) {
  Object *var_gdyns = alloc_var();
  *var_gdyns = undefined;
// Begin line 484
  setline(484);
  Object array1142 = alloc_List();
// compilenode returning array1142
  *var_gdyns = array1142;
  if (array1142 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 486
  setline(486);
// Begin line 488
  setline(488);
// Begin line 1017
  setline(1017);
// Begin line 484
  setline(484);
// compilenode returning *var_gtp
  Object call1144 = callmethod(*var_gtp, "generics",
    0, params);
// compilenode returning call1144
// compilenode returning call1144
// Begin line 486
  setline(486);
// Begin line 1017
  setline(1017);
  Object obj1146 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1146, self, 0);
  addmethod2(obj1146, "outer", &reader_typechecker_outer_1147);
  adddatum2(obj1146, self, 0);
  block_savedest(obj1146);
  Object **closure1148 = createclosure(4);
  addtoclosure(closure1148, var_gtp);
  addtoclosure(closure1148, var_DynamicType);
  addtoclosure(closure1148, var_gdyns);
  Object *selfpp1152 = alloc_var();
  *selfpp1152 = self;
  addtoclosure(closure1148, selfpp1152);
  struct UserObject *uo1148 = (struct UserObject*)obj1146;
  uo1148->data[1] = (Object)closure1148;
  addmethod2(obj1146, "apply", &meth_typechecker_apply1148);
  set_type(obj1146, 0);
// compilenode returning obj1146
  setclassname(obj1146, "Block<typechecker:1145>");
// compilenode returning obj1146
  params[0] = call1144;
  Object iter1143 = callmethod(call1144, "iter", 1, params);
  while(1) {
    Object cond1143 = callmethod(iter1143, "havemore", 0, NULL);
    if (!istrue(cond1143)) break;
    params[0] = callmethod(iter1143, "next", 0, NULL);
    callmethod(obj1146, "apply", 1, params);
  }
// compilenode returning call1144
    if1136 = call1144;
  } else {
  }
// compilenode returning if1136
    if1132 = if1136;
  } else {
  }
// compilenode returning if1132
// Begin line 491
  setline(491);
// Begin line 490
  setline(490);
// compilenode returning *var_gtp
  return *var_gtp;
// compilenode returning undefined
// Begin line 492
  setline(492);
// Begin line 1017
  setline(1017);
// Begin line 491
  setline(491);
// compilenode returning *var_tpbd
  Object call1153 = callmethod(*var_tpbd, "value",
    0, params);
// compilenode returning call1153
// compilenode returning call1153
  return call1153;
// compilenode returning undefined
    if1124 = undefined;
  } else {
  }
// compilenode returning if1124
// Begin line 517
  setline(517);
// Begin line 518
  setline(518);
// Begin line 1017
  setline(1017);
// Begin line 493
  setline(493);
// compilenode returning *var_tp
  Object call1155 = callmethod(*var_tp, "kind",
    0, params);
// compilenode returning call1155
// compilenode returning call1155
  if (strlit1156 == NULL) {
    strlit1156 = alloc_String("generic");
  }
// compilenode returning strlit1156
  params[0] = strlit1156;
  Object opresult1158 = callmethod(call1155, "==", 1, params);
// compilenode returning opresult1158
  Object if1154;
  if (istrue(opresult1158)) {
  Object *var_gtnm = alloc_var();
  *var_gtnm = undefined;
  Object *var_gtbd = alloc_var();
  *var_gtbd = undefined;
  Object *var_gtg = alloc_var();
  *var_gtg = undefined;
  Object *var_gnm = alloc_var();
  *var_gnm = undefined;
  Object *var_methods = alloc_var();
  *var_methods = undefined;
  Object *var_tmprt = alloc_var();
  *var_tmprt = undefined;
  Object *var_tmpparams = alloc_var();
  *var_tmpparams = undefined;
  Object *var_tmptp = alloc_var();
  *var_tmptp = undefined;
  Object *var_gnms = alloc_var();
  *var_gnms = undefined;
  Object *var_nt = alloc_var();
  *var_nt = undefined;
// Begin line 495
  setline(495);
// Begin line 1017
  setline(1017);
// Begin line 495
  setline(495);
// Begin line 1017
  setline(1017);
// Begin line 494
  setline(494);
// compilenode returning *var_tp
  Object call1159 = callmethod(*var_tp, "value",
    0, params);
// compilenode returning call1159
// compilenode returning call1159
  Object call1160 = callmethod(call1159, "value",
    0, params);
// compilenode returning call1160
// compilenode returning call1160
  *var_gtnm = call1160;
  if (call1160 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 495
  setline(495);
// compilenode returning *var_gtnm
// Begin line 496
  setline(496);
// compilenode returning self
  params[0] = *var_gtnm;
  Object call1161 = callmethod(self, "findName",
    1, params);
// compilenode returning call1161
  *var_gtbd = call1161;
  if (call1161 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 497
  setline(497);
// Begin line 1017
  setline(1017);
// Begin line 496
  setline(496);
// compilenode returning *var_gtbd
  Object call1162 = callmethod(*var_gtbd, "value",
    0, params);
// compilenode returning call1162
// compilenode returning call1162
  *var_gtg = call1162;
  if (call1162 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 498
  setline(498);
// Begin line 497
  setline(497);
// compilenode returning *var_gtnm
  if (strlit1163 == NULL) {
    strlit1163 = alloc_String("<");
  }
// compilenode returning strlit1163
  params[0] = strlit1163;
  Object opresult1165 = callmethod(*var_gtnm, "++", 1, params);
// compilenode returning opresult1165
  var_gnm = alloc_var();
  *var_gnm = opresult1165;
  if (opresult1165 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 499
  setline(499);
// Begin line 501
  setline(501);
// Begin line 498
  setline(498);
// compilenode returning *var_gtg
  Object bool1167 = alloc_Boolean(0);
// compilenode returning bool1167
  params[0] = bool1167;
  Object opresult1169 = callmethod(*var_gtg, "==", 1, params);
// compilenode returning opresult1169
  Object if1166;
  if (istrue(opresult1169)) {
// Begin line 499
  setline(499);
  if (strlit1170 == NULL) {
    strlit1170 = alloc_String("could not find base type to instantiate: ");
  }
// compilenode returning strlit1170
// compilenode returning *var_gtnm
  params[0] = *var_gtnm;
  Object opresult1172 = callmethod(strlit1170, "++", 1, params);
// compilenode returning opresult1172
  if (strlit1173 == NULL) {
    strlit1173 = alloc_String("");
  }
// compilenode returning strlit1173
  params[0] = strlit1173;
  Object opresult1175 = callmethod(opresult1172, "++", 1, params);
// compilenode returning opresult1175
// compilenode returning module_util
  params[0] = opresult1175;
  Object call1176 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call1176
    if1166 = call1176;
  } else {
  }
// compilenode returning if1166
// Begin line 502
  setline(502);
// Begin line 1017
  setline(1017);
// Begin line 501
  setline(501);
// compilenode returning *var_gtg
  Object call1177 = callmethod(*var_gtg, "methods",
    0, params);
// compilenode returning call1177
// compilenode returning call1177
  var_methods = alloc_var();
  *var_methods = call1177;
  if (call1177 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 503
  setline(503);
  var_tmprt = alloc_var();
  *var_tmprt = undefined;
// compilenode returning nothing
// Begin line 504
  setline(504);
  var_tmpparams = alloc_var();
  *var_tmpparams = undefined;
// compilenode returning nothing
// Begin line 505
  setline(505);
// Begin line 504
  setline(504);
// compilenode returning *var_gtg
  var_tmptp = alloc_var();
  *var_tmptp = *var_gtg;
  if (*var_gtg == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 506
  setline(506);
  Object array1178 = alloc_List();
// compilenode returning array1178
  *var_gnms = array1178;
  if (array1178 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 510
  setline(510);
// Begin line 512
  setline(512);
// Begin line 1017
  setline(1017);
// Begin line 512
  setline(512);
// Begin line 1017
  setline(1017);
// Begin line 506
  setline(506);
// compilenode returning *var_tp
  Object call1180 = callmethod(*var_tp, "params",
    0, params);
// compilenode returning call1180
// compilenode returning call1180
  Object call1181 = callmethod(call1180, "indices",
    0, params);
// compilenode returning call1181
// compilenode returning call1181
// Begin line 510
  setline(510);
// Begin line 1017
  setline(1017);
  Object obj1183 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1183, self, 0);
  addmethod2(obj1183, "outer", &reader_typechecker_outer_1184);
  adddatum2(obj1183, self, 0);
  block_savedest(obj1183);
  Object **closure1185 = createclosure(5);
  addtoclosure(closure1185, var_gtg);
  addtoclosure(closure1185, var_tp);
  addtoclosure(closure1185, var_gnms);
  addtoclosure(closure1185, var_tmptp);
  Object *selfpp1195 = alloc_var();
  *selfpp1195 = self;
  addtoclosure(closure1185, selfpp1195);
  struct UserObject *uo1185 = (struct UserObject*)obj1183;
  uo1185->data[1] = (Object)closure1185;
  addmethod2(obj1183, "apply", &meth_typechecker_apply1185);
  set_type(obj1183, 0);
// compilenode returning obj1183
  setclassname(obj1183, "Block<typechecker:1182>");
// compilenode returning obj1183
  params[0] = call1181;
  Object iter1179 = callmethod(call1181, "iter", 1, params);
  while(1) {
    Object cond1179 = callmethod(iter1179, "havemore", 0, NULL);
    if (!istrue(cond1179)) break;
    params[0] = callmethod(iter1179, "next", 0, NULL);
    callmethod(obj1183, "apply", 1, params);
  }
// compilenode returning call1181
// Begin line 512
  setline(512);
// compilenode returning *var_gnm
  if (strlit1196 == NULL) {
    strlit1196 = alloc_String(",");
  }
// compilenode returning strlit1196
// compilenode returning *var_gnms
// compilenode returning module_util
  params[0] = strlit1196;
  params[1] = *var_gnms;
  Object call1197 = callmethod(module_util, "join",
    2, params);
// compilenode returning call1197
  params[0] = call1197;
  Object opresult1199 = callmethod(*var_gnm, "++", 1, params);
// compilenode returning opresult1199
  if (strlit1200 == NULL) {
    strlit1200 = alloc_String(">");
  }
// compilenode returning strlit1200
  params[0] = strlit1200;
  Object opresult1202 = callmethod(opresult1199, "++", 1, params);
// compilenode returning opresult1202
  *var_gnm = opresult1202;
  if (opresult1202 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 513
  setline(513);
// compilenode returning *var_gnm
// Begin line 1017
  setline(1017);
// Begin line 513
  setline(513);
// compilenode returning *var_tmptp
  Object call1204 = callmethod(*var_tmptp, "methods",
    0, params);
// compilenode returning call1204
// compilenode returning call1204
// compilenode returning module_ast
  params[0] = *var_gnm;
  params[1] = call1204;
  Object call1205 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1205
  *var_nt = call1205;
  if (call1205 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 514
  setline(514);
// compilenode returning *var_nt
// compilenode returning module_subtype
  params[0] = *var_nt;
  Object call1206 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call1206
// Begin line 515
  setline(515);
// compilenode returning *var_gtg
// compilenode returning module_subtype
  params[0] = *var_gtg;
  Object call1207 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call1207
// Begin line 517
  setline(517);
// Begin line 516
  setline(516);
// compilenode returning *var_nt
  return *var_nt;
// compilenode returning undefined
    if1154 = undefined;
  } else {
  }
// compilenode returning if1154
// Begin line 519
  setline(519);
// Begin line 518
  setline(518);
// compilenode returning *var_DynamicType
  return *var_DynamicType;
// compilenode returning undefined
  return undefined;
}
Object meth_typechecker_resolveIdentifier1208(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object *var_node = alloc_var();
  *var_node = args[0];
  Object params[2];
  Object *var_nm = alloc_var();
  *var_nm = undefined;
  Object *var_b = alloc_var();
  *var_b = undefined;
// Begin line 523
  setline(523);
// Begin line 524
  setline(524);
// Begin line 1017
  setline(1017);
// Begin line 521
  setline(521);
// compilenode returning *var_node
  Object call1210 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1210
// compilenode returning call1210
  if (strlit1211 == NULL) {
    strlit1211 = alloc_String("identifier");
  }
// compilenode returning strlit1211
  params[0] = strlit1211;
  Object opresult1213 = callmethod(call1210, "/=", 1, params);
// compilenode returning opresult1213
  Object if1209;
  if (istrue(opresult1213)) {
// Begin line 523
  setline(523);
// Begin line 522
  setline(522);
// compilenode returning *var_node
  return *var_node;
// compilenode returning undefined
    if1209 = undefined;
  } else {
  }
// compilenode returning if1209
// Begin line 525
  setline(525);
// Begin line 1017
  setline(1017);
// Begin line 524
  setline(524);
// compilenode returning *var_node
  Object call1214 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1214
// compilenode returning call1214
  var_nm = alloc_var();
  *var_nm = call1214;
  if (call1214 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 526
  setline(526);
// Begin line 525
  setline(525);
// Begin line 1017
  setline(1017);
// Begin line 525
  setline(525);
// compilenode returning *var_nm
// Begin line 528
  setline(528);
// compilenode returning self
  params[0] = *var_nm;
  Object call1216 = callmethod(self, "haveBinding",
    1, params);
// compilenode returning call1216
  Object call1217 = callmethod(call1216, "not",
    0, params);
// compilenode returning call1217
// compilenode returning call1217
  Object if1215;
  if (istrue(call1217)) {
// Begin line 526
  setline(526);
  if (strlit1218 == NULL) {
    strlit1218 = alloc_String("use of undefined identifier ");
  }
// compilenode returning strlit1218
// compilenode returning *var_nm
  params[0] = *var_nm;
  Object opresult1220 = callmethod(strlit1218, "++", 1, params);
// compilenode returning opresult1220
  if (strlit1221 == NULL) {
    strlit1221 = alloc_String("");
  }
// compilenode returning strlit1221
  params[0] = strlit1221;
  Object opresult1223 = callmethod(opresult1220, "++", 1, params);
// compilenode returning opresult1223
// compilenode returning module_util
  params[0] = opresult1223;
  Object call1224 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1224
    if1215 = call1224;
  } else {
  }
// compilenode returning if1215
// Begin line 529
  setline(529);
// Begin line 531
  setline(531);
// Begin line 528
  setline(528);
// compilenode returning *var_nm
  if (strlit1226 == NULL) {
    strlit1226 = alloc_String("outer");
  }
// compilenode returning strlit1226
  params[0] = strlit1226;
  Object opresult1228 = callmethod(*var_nm, "==", 1, params);
// compilenode returning opresult1228
  Object if1225;
  if (istrue(opresult1228)) {
// Begin line 529
  setline(529);
  if (strlit1229 == NULL) {
    strlit1229 = alloc_String("outer");
  }
// compilenode returning strlit1229
  if (strlit1230 == NULL) {
    strlit1230 = alloc_String("self");
  }
// compilenode returning strlit1230
  Object bool1231 = alloc_Boolean(0);
// compilenode returning bool1231
// compilenode returning module_ast
  params[0] = strlit1230;
  params[1] = bool1231;
  Object call1232 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call1232
// compilenode returning module_ast
  params[0] = strlit1229;
  params[1] = call1232;
  Object call1233 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1233
  return call1233;
// compilenode returning undefined
    if1225 = undefined;
  } else {
  }
// compilenode returning if1225
// Begin line 531
  setline(531);
// compilenode returning *var_nm
// Begin line 532
  setline(532);
// compilenode returning self
  params[0] = *var_nm;
  Object call1234 = callmethod(self, "findName",
    1, params);
// compilenode returning call1234
  var_b = alloc_var();
  *var_b = call1234;
  if (call1234 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 545
  setline(545);
// Begin line 547
  setline(547);
// Begin line 1017
  setline(1017);
// Begin line 532
  setline(532);
// compilenode returning *var_b
  Object call1236 = callmethod(*var_b, "kind",
    0, params);
// compilenode returning call1236
// compilenode returning call1236
  if (strlit1237 == NULL) {
    strlit1237 = alloc_String("var");
  }
// compilenode returning strlit1237
  params[0] = strlit1237;
  Object opresult1239 = callmethod(call1236, "==", 1, params);
// compilenode returning opresult1239
  Object if1235;
  if (istrue(opresult1239)) {
  Object *var_vtp = alloc_var();
  *var_vtp = undefined;
// Begin line 533
  setline(533);
// Begin line 1017
  setline(1017);
// Begin line 533
  setline(533);
// compilenode returning *var_b
  Object call1240 = callmethod(*var_b, "dtype",
    0, params);
// compilenode returning call1240
// compilenode returning call1240
// Begin line 534
  setline(534);
// compilenode returning self
  params[0] = call1240;
  Object call1241 = callmethod(self, "findType",
    1, params);
// compilenode returning call1241
  *var_vtp = call1241;
  if (call1241 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 536
  setline(536);
// Begin line 537
  setline(537);
// Begin line 1017
  setline(1017);
// Begin line 534
  setline(534);
// compilenode returning *var_node
  Object call1243 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1243
// compilenode returning call1243
// compilenode returning *var_vtp
  params[0] = *var_vtp;
  Object opresult1245 = callmethod(call1243, "/=", 1, params);
// compilenode returning opresult1245
  Object if1242;
  if (istrue(opresult1245)) {
// Begin line 536
  setline(536);
// Begin line 1017
  setline(1017);
// Begin line 535
  setline(535);
// compilenode returning *var_vtp
// compilenode returning *var_node
  params[0] = *var_vtp;
  Object call1246 = callmethod(*var_node, "dtype:=",
    1, params);
// compilenode returning call1246
// compilenode returning nothing
    if1242 = nothing;
  } else {
  }
// compilenode returning if1242
// Begin line 538
  setline(538);
// Begin line 537
  setline(537);
// compilenode returning *var_node
  return *var_node;
// compilenode returning undefined
    if1235 = undefined;
  } else {
// Begin line 545
  setline(545);
// Begin line 544
  setline(544);
// Begin line 1017
  setline(1017);
// Begin line 538
  setline(538);
// compilenode returning *var_b
  Object call1248 = callmethod(*var_b, "kind",
    0, params);
// compilenode returning call1248
// compilenode returning call1248
  if (strlit1249 == NULL) {
    strlit1249 = alloc_String("def");
  }
// compilenode returning strlit1249
  params[0] = strlit1249;
  Object opresult1251 = callmethod(call1248, "==", 1, params);
// compilenode returning opresult1251
  Object if1247;
  if (istrue(opresult1251)) {
  Object *var_dtp = alloc_var();
  *var_dtp = undefined;
// Begin line 539
  setline(539);
// Begin line 1017
  setline(1017);
// Begin line 539
  setline(539);
// compilenode returning *var_b
  Object call1252 = callmethod(*var_b, "dtype",
    0, params);
// compilenode returning call1252
// compilenode returning call1252
// Begin line 540
  setline(540);
// compilenode returning self
  params[0] = call1252;
  Object call1253 = callmethod(self, "findType",
    1, params);
// compilenode returning call1253
  *var_dtp = call1253;
  if (call1253 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 542
  setline(542);
// Begin line 543
  setline(543);
// Begin line 1017
  setline(1017);
// Begin line 540
  setline(540);
// compilenode returning *var_node
  Object call1255 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1255
// compilenode returning call1255
// compilenode returning *var_dtp
  params[0] = *var_dtp;
  Object opresult1257 = callmethod(call1255, "/=", 1, params);
// compilenode returning opresult1257
  Object if1254;
  if (istrue(opresult1257)) {
// Begin line 542
  setline(542);
// Begin line 1017
  setline(1017);
// Begin line 541
  setline(541);
// compilenode returning *var_dtp
// compilenode returning *var_node
  params[0] = *var_dtp;
  Object call1258 = callmethod(*var_node, "dtype:=",
    1, params);
// compilenode returning call1258
// compilenode returning nothing
    if1254 = nothing;
  } else {
  }
// compilenode returning if1254
// Begin line 544
  setline(544);
// Begin line 543
  setline(543);
// compilenode returning *var_node
  return *var_node;
// compilenode returning undefined
    if1247 = undefined;
  } else {
// Begin line 545
  setline(545);
// Begin line 547
  setline(547);
// Begin line 1017
  setline(1017);
// Begin line 544
  setline(544);
// compilenode returning *var_b
  Object call1260 = callmethod(*var_b, "kind",
    0, params);
// compilenode returning call1260
// compilenode returning call1260
  if (strlit1261 == NULL) {
    strlit1261 = alloc_String("method");
  }
// compilenode returning strlit1261
  params[0] = strlit1261;
  Object opresult1263 = callmethod(call1260, "==", 1, params);
// compilenode returning opresult1263
  Object if1259;
  if (istrue(opresult1263)) {
// Begin line 545
  setline(545);
// compilenode returning *var_nm
// compilenode returning self
  params[0] = *var_nm;
  Object call1264 = callmethod(self, "findDeepMethod",
    1, params);
// compilenode returning call1264
  Object array1265 = alloc_List();
// compilenode returning array1265
// compilenode returning module_ast
  params[0] = call1264;
  params[1] = array1265;
  Object call1266 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1266
  return call1266;
// compilenode returning undefined
    if1259 = undefined;
  } else {
  }
// compilenode returning if1259
    if1247 = if1259;
  }
// compilenode returning if1247
    if1235 = if1247;
  }
// compilenode returning if1235
// Begin line 547
  setline(547);
// compilenode returning *var_node
  return *var_node;
}
Object meth_typechecker_apply1355(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 594
  setline(594);
// compilenode returning *var_e
// Begin line 595
  setline(595);
// compilenode returning self
  params[0] = *var_e;
  Object call1356 = callmethod(self, "bindIdentifier",
    1, params);
// compilenode returning call1356
  return call1356;
}
Object meth_typechecker_apply1428(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 629
  setline(629);
// compilenode returning *var_e
// Begin line 630
  setline(630);
// compilenode returning self
  params[0] = *var_e;
  Object call1429 = callmethod(self, "bindIdentifier",
    1, params);
// compilenode returning call1429
  return call1429;
}
Object meth_typechecker_apply1446(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[2];
  Object *var_Binding = closure[0];
  Object *var_scopes = closure[1];
  Object self = *closure[2];
// Begin line 638
  setline(638);
  if (strlit1447 == NULL) {
    strlit1447 = alloc_String("___is_object");
  }
// compilenode returning strlit1447
  if (strlit1448 == NULL) {
    strlit1448 = alloc_String("yes");
  }
// compilenode returning strlit1448
// compilenode returning *var_Binding
  params[0] = strlit1448;
  Object call1449 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1449
// Begin line 639
  setline(639);
// Begin line 1017
  setline(1017);
// Begin line 638
  setline(638);
// compilenode returning *var_scopes
  Object call1450 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call1450
// compilenode returning call1450
  params[0] = strlit1447;
  params[1] = call1449;
  Object call1451 = callmethod(call1450, "put",
    2, params);
// compilenode returning call1451
// Begin line 639
  setline(639);
  if (strlit1452 == NULL) {
    strlit1452 = alloc_String("outer");
  }
// compilenode returning strlit1452
  if (strlit1453 == NULL) {
    strlit1453 = alloc_String("method");
  }
// compilenode returning strlit1453
// compilenode returning *var_Binding
  params[0] = strlit1453;
  Object call1454 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1454
// Begin line 640
  setline(640);
// Begin line 1017
  setline(1017);
// Begin line 639
  setline(639);
// compilenode returning *var_scopes
  Object call1455 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call1455
// compilenode returning call1455
  params[0] = strlit1452;
  params[1] = call1454;
  Object call1456 = callmethod(call1455, "put",
    2, params);
// compilenode returning call1456
  return call1456;
}
Object meth_typechecker_apply1475(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[2];
  Object *var_Binding = closure[0];
  Object *var_scopes = closure[1];
  Object self = *closure[2];
// Begin line 649
  setline(649);
  if (strlit1476 == NULL) {
    strlit1476 = alloc_String("___is_object");
  }
// compilenode returning strlit1476
  if (strlit1477 == NULL) {
    strlit1477 = alloc_String("yes");
  }
// compilenode returning strlit1477
// compilenode returning *var_Binding
  params[0] = strlit1477;
  Object call1478 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1478
// Begin line 650
  setline(650);
// Begin line 1017
  setline(1017);
// Begin line 649
  setline(649);
// compilenode returning *var_scopes
  Object call1479 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call1479
// compilenode returning call1479
  params[0] = strlit1476;
  params[1] = call1478;
  Object call1480 = callmethod(call1479, "put",
    2, params);
// compilenode returning call1480
// Begin line 650
  setline(650);
  if (strlit1481 == NULL) {
    strlit1481 = alloc_String("___is_class");
  }
// compilenode returning strlit1481
  if (strlit1482 == NULL) {
    strlit1482 = alloc_String("yes");
  }
// compilenode returning strlit1482
// compilenode returning *var_Binding
  params[0] = strlit1482;
  Object call1483 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1483
// Begin line 651
  setline(651);
// Begin line 1017
  setline(1017);
// Begin line 650
  setline(650);
// compilenode returning *var_scopes
  Object call1484 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call1484
// compilenode returning call1484
  params[0] = strlit1481;
  params[1] = call1483;
  Object call1485 = callmethod(call1484, "put",
    2, params);
// compilenode returning call1485
// Begin line 651
  setline(651);
  if (strlit1486 == NULL) {
    strlit1486 = alloc_String("outer");
  }
// compilenode returning strlit1486
  if (strlit1487 == NULL) {
    strlit1487 = alloc_String("method");
  }
// compilenode returning strlit1487
// compilenode returning *var_Binding
  params[0] = strlit1487;
  Object call1488 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1488
// Begin line 652
  setline(652);
// Begin line 1017
  setline(1017);
// Begin line 651
  setline(651);
// compilenode returning *var_scopes
  Object call1489 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call1489
// compilenode returning call1489
  params[0] = strlit1486;
  params[1] = call1488;
  Object call1490 = callmethod(call1489, "put",
    2, params);
// compilenode returning call1490
  return call1490;
}
Object meth_typechecker_apply1505(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_gp = alloc_var();
  *var_gp = args[0];
  Object params[2];
  Object *var_Binding = closure[0];
  Object self = *closure[1];
  Object *var_nomnm = alloc_var();
  *var_nomnm = undefined;
  Object *var_nom = alloc_var();
  *var_nom = undefined;
  Object *var_tpb = alloc_var();
  *var_tpb = undefined;
// Begin line 656
  setline(656);
// Begin line 1017
  setline(1017);
// Begin line 655
  setline(655);
// compilenode returning *var_gp
  Object call1506 = callmethod(*var_gp, "value",
    0, params);
// compilenode returning call1506
// compilenode returning call1506
  *var_nomnm = call1506;
  if (call1506 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 656
  setline(656);
// compilenode returning *var_nomnm
  Object array1507 = alloc_List();
// compilenode returning array1507
// compilenode returning module_ast
  params[0] = *var_nomnm;
  params[1] = array1507;
  Object call1508 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1508
  *var_nom = call1508;
  if (call1508 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 658
  setline(658);
// Begin line 1017
  setline(1017);
// Begin line 657
  setline(657);
  Object bool1509 = alloc_Boolean(1);
// compilenode returning bool1509
// compilenode returning *var_nom
  params[0] = bool1509;
  Object call1510 = callmethod(*var_nom, "nominal:=",
    1, params);
// compilenode returning call1510
// compilenode returning nothing
// Begin line 658
  setline(658);
// compilenode returning *var_nom
// compilenode returning module_subtype
  params[0] = *var_nom;
  Object call1511 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call1511
// Begin line 659
  setline(659);
  if (strlit1512 == NULL) {
    strlit1512 = alloc_String("type");
  }
// compilenode returning strlit1512
// compilenode returning *var_Binding
  params[0] = strlit1512;
  Object call1513 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1513
  *var_tpb = call1513;
  if (call1513 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 661
  setline(661);
// Begin line 1017
  setline(1017);
// Begin line 660
  setline(660);
// compilenode returning *var_nom
// compilenode returning *var_tpb
  params[0] = *var_nom;
  Object call1514 = callmethod(*var_tpb, "value:=",
    1, params);
// compilenode returning call1514
// compilenode returning nothing
// Begin line 661
  setline(661);
// Begin line 1017
  setline(1017);
// Begin line 661
  setline(661);
// compilenode returning *var_gp
  Object call1515 = callmethod(*var_gp, "value",
    0, params);
// compilenode returning call1515
// compilenode returning call1515
// compilenode returning *var_tpb
// Begin line 662
  setline(662);
// compilenode returning self
  params[0] = call1515;
  params[1] = *var_tpb;
  Object call1516 = callmethod(self, "bindName",
    2, params);
// compilenode returning call1516
  return call1516;
}
Object meth_typechecker_apply1523(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object self = *closure[0];
// Begin line 665
  setline(665);
// compilenode returning *var_e
// Begin line 666
  setline(666);
// compilenode returning self
  params[0] = *var_e;
  Object call1524 = callmethod(self, "bindIdentifier",
    1, params);
// compilenode returning call1524
  return call1524;
}
Object meth_typechecker_apply1659(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_g = alloc_var();
  *var_g = args[0];
  Object params[2];
  Object *var_Binding = closure[0];
  Object self = *closure[1];
  Object *var_nom = alloc_var();
  *var_nom = undefined;
  Object *var_tpb = alloc_var();
  *var_tpb = undefined;
// Begin line 704
  setline(704);
// Begin line 1017
  setline(1017);
// Begin line 704
  setline(704);
// compilenode returning *var_g
  Object call1660 = callmethod(*var_g, "value",
    0, params);
// compilenode returning call1660
// compilenode returning call1660
  Object array1661 = alloc_List();
// compilenode returning array1661
// compilenode returning module_ast
  params[0] = call1660;
  params[1] = array1661;
  Object call1662 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1662
  *var_nom = call1662;
  if (call1662 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 706
  setline(706);
// Begin line 1017
  setline(1017);
// Begin line 705
  setline(705);
  Object bool1663 = alloc_Boolean(1);
// compilenode returning bool1663
// compilenode returning *var_nom
  params[0] = bool1663;
  Object call1664 = callmethod(*var_nom, "nominal:=",
    1, params);
// compilenode returning call1664
// compilenode returning nothing
// Begin line 706
  setline(706);
  if (strlit1665 == NULL) {
    strlit1665 = alloc_String("type");
  }
// compilenode returning strlit1665
// compilenode returning *var_Binding
  params[0] = strlit1665;
  Object call1666 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call1666
  *var_tpb = call1666;
  if (call1666 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 708
  setline(708);
// Begin line 1017
  setline(1017);
// Begin line 707
  setline(707);
// compilenode returning *var_nom
// compilenode returning *var_tpb
  params[0] = *var_nom;
  Object call1667 = callmethod(*var_tpb, "value:=",
    1, params);
// compilenode returning call1667
// compilenode returning nothing
// Begin line 708
  setline(708);
// Begin line 1017
  setline(1017);
// Begin line 708
  setline(708);
// compilenode returning *var_g
  Object call1668 = callmethod(*var_g, "value",
    0, params);
// compilenode returning call1668
// compilenode returning call1668
// compilenode returning *var_tpb
// Begin line 709
  setline(709);
// compilenode returning self
  params[0] = call1668;
  params[1] = *var_tpb;
  Object call1669 = callmethod(self, "bindName",
    2, params);
// compilenode returning call1669
  return call1669;
}
Object meth_typechecker_apply1687(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object *var_tmp2 = closure[0];
  Object self = *closure[1];
// Begin line 715
  setline(715);
// Begin line 1017
  setline(1017);
// Begin line 715
  setline(715);
// Begin line 1017
  setline(1017);
// Begin line 715
  setline(715);
// compilenode returning *var_e
  Object call1688 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call1688
// compilenode returning call1688
// Begin line 716
  setline(716);
// compilenode returning self
  params[0] = call1688;
  Object call1689 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1689
// Begin line 715
  setline(715);
// compilenode returning *var_e
  params[0] = call1689;
  Object call1690 = callmethod(*var_e, "dtype:=",
    1, params);
// compilenode returning call1690
// compilenode returning nothing
// Begin line 716
  setline(716);
// compilenode returning *var_e
// Begin line 717
  setline(717);
// compilenode returning self
  params[0] = *var_e;
  Object call1691 = callmethod(self, "bindIdentifier",
    1, params);
// compilenode returning call1691
// compilenode returning *var_e
// compilenode returning *var_tmp2
  params[0] = *var_e;
  Object call1692 = callmethod(*var_tmp2, "push",
    1, params);
// compilenode returning call1692
  return call1692;
}
Object meth_typechecker_apply1678(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_mt = alloc_var();
  *var_mt = args[0];
  Object params[3];
  Object *var_tmp2 = closure[0];
  Object *var_tmp3 = closure[1];
  Object *var_tmp = closure[2];
  Object self = *closure[3];
// Begin line 712
  setline(712);
// compilenode returning self
  Object call1679 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call1679
// Begin line 714
  setline(714);
  Object array1680 = alloc_List();
// compilenode returning array1680
  *var_tmp2 = array1680;
  if (array1680 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 717
  setline(717);
// Begin line 719
  setline(719);
// Begin line 1017
  setline(1017);
// Begin line 714
  setline(714);
// compilenode returning *var_mt
  Object call1683 = callmethod(*var_mt, "params",
    0, params);
// compilenode returning call1683
// compilenode returning call1683
// Begin line 717
  setline(717);
// Begin line 1017
  setline(1017);
  Object obj1685 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1685, self, 0);
  addmethod2(obj1685, "outer", &reader_typechecker_outer_1686);
  adddatum2(obj1685, self, 0);
  block_savedest(obj1685);
  Object **closure1687 = createclosure(2);
  addtoclosure(closure1687, var_tmp2);
  Object *selfpp1693 = alloc_var();
  *selfpp1693 = self;
  addtoclosure(closure1687, selfpp1693);
  struct UserObject *uo1687 = (struct UserObject*)obj1685;
  uo1687->data[1] = (Object)closure1687;
  addmethod2(obj1685, "apply", &meth_typechecker_apply1687);
  set_type(obj1685, 0);
// compilenode returning obj1685
  setclassname(obj1685, "Block<typechecker:1684>");
// compilenode returning obj1685
  params[0] = call1683;
  Object iter1682 = callmethod(call1683, "iter", 1, params);
  while(1) {
    Object cond1682 = callmethod(iter1682, "havemore", 0, NULL);
    if (!istrue(cond1682)) break;
    params[0] = callmethod(iter1682, "next", 0, NULL);
    callmethod(obj1685, "apply", 1, params);
  }
// compilenode returning call1683
// Begin line 719
  setline(719);
// Begin line 1017
  setline(1017);
// Begin line 719
  setline(719);
// compilenode returning *var_mt
  Object call1694 = callmethod(*var_mt, "rtype",
    0, params);
// compilenode returning call1694
// compilenode returning call1694
// Begin line 720
  setline(720);
// compilenode returning self
  params[0] = call1694;
  Object call1695 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1695
  *var_tmp3 = call1695;
  if (call1695 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 720
  setline(720);
// compilenode returning *var_mt
  Object call1697 = callmethod(*var_mt, "value",
    0, params);
// compilenode returning call1697
// compilenode returning call1697
// compilenode returning *var_tmp2
// compilenode returning *var_tmp3
// compilenode returning module_ast
  params[0] = call1697;
  params[1] = *var_tmp2;
  params[2] = *var_tmp3;
  Object call1698 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call1698
// compilenode returning *var_tmp
  params[0] = call1698;
  Object call1699 = callmethod(*var_tmp, "push",
    1, params);
// compilenode returning call1699
// Begin line 721
  setline(721);
// compilenode returning self
  Object call1700 = callmethod(self, "popScope",
    0, params);
// compilenode returning call1700
  return call1700;
}
Object meth_typechecker_apply1727(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[1];
  Object *var_tmp2 = closure[0];
  Object self = *closure[1];
// Begin line 732
  setline(732);
// compilenode returning *var_ut
// compilenode returning self
  params[0] = *var_ut;
  Object call1728 = callmethod(self, "findType",
    1, params);
// compilenode returning call1728
// Begin line 733
  setline(733);
// Begin line 1017
  setline(1017);
// Begin line 732
  setline(732);
// compilenode returning *var_tmp2
  Object call1729 = callmethod(*var_tmp2, "unionTypes",
    0, params);
// compilenode returning call1729
// compilenode returning call1729
  params[0] = call1728;
  Object call1730 = callmethod(call1729, "push",
    1, params);
// compilenode returning call1730
  return call1730;
}
Object meth_typechecker_apply1758(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_existingmeth = alloc_var();
  *var_existingmeth = args[0];
  Object params[1];
  Object *var_utm = closure[0];
  Object *var_tmp3 = closure[1];
  Object self = *closure[2];
// Begin line 743
  setline(743);
// Begin line 745
  setline(745);
// Begin line 1017
  setline(1017);
// Begin line 742
  setline(742);
// compilenode returning *var_existingmeth
  Object call1760 = callmethod(*var_existingmeth, "value",
    0, params);
// compilenode returning call1760
// compilenode returning call1760
// Begin line 745
  setline(745);
// Begin line 1017
  setline(1017);
// Begin line 742
  setline(742);
// compilenode returning *var_utm
  Object call1761 = callmethod(*var_utm, "value",
    0, params);
// compilenode returning call1761
// compilenode returning call1761
  params[0] = call1761;
  Object opresult1763 = callmethod(call1760, "==", 1, params);
// compilenode returning opresult1763
  Object if1759;
  if (istrue(opresult1763)) {
// Begin line 743
  setline(743);
// compilenode returning *var_existingmeth
// compilenode returning *var_tmp3
  params[0] = *var_existingmeth;
  Object call1764 = callmethod(*var_tmp3, "push",
    1, params);
// compilenode returning call1764
    if1759 = call1764;
  } else {
  }
// compilenode returning if1759
  return if1759;
}
Object meth_typechecker_apply1753(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_utm = alloc_var();
  *var_utm = args[0];
  Object params[1];
  Object *var_tmp4 = closure[0];
  Object *var_tmp3 = closure[1];
  Object self = *closure[2];
// Begin line 743
  setline(743);
// Begin line 741
  setline(741);
// compilenode returning *var_tmp4
// Begin line 743
  setline(743);
// Begin line 1017
  setline(1017);
  Object obj1756 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1756, self, 0);
  addmethod2(obj1756, "outer", &reader_typechecker_outer_1757);
  adddatum2(obj1756, self, 0);
  block_savedest(obj1756);
  Object **closure1758 = createclosure(3);
  addtoclosure(closure1758, var_utm);
  addtoclosure(closure1758, var_tmp3);
  Object *selfpp1765 = alloc_var();
  *selfpp1765 = self;
  addtoclosure(closure1758, selfpp1765);
  struct UserObject *uo1758 = (struct UserObject*)obj1756;
  uo1758->data[1] = (Object)closure1758;
  addmethod2(obj1756, "apply", &meth_typechecker_apply1758);
  set_type(obj1756, 0);
// compilenode returning obj1756
  setclassname(obj1756, "Block<typechecker:1755>");
// compilenode returning obj1756
  params[0] = *var_tmp4;
  Object iter1754 = callmethod(*var_tmp4, "iter", 1, params);
  while(1) {
    Object cond1754 = callmethod(iter1754, "havemore", 0, NULL);
    if (!istrue(cond1754)) break;
    params[0] = callmethod(iter1754, "next", 0, NULL);
    callmethod(obj1756, "apply", 1, params);
  }
// compilenode returning *var_tmp4
  return *var_tmp4;
}
Object meth_typechecker_apply1739(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_utt = alloc_var();
  *var_utt = args[0];
  Object params[1];
  Object *var_tmp4 = closure[0];
  Object *var_tmp3 = closure[1];
  Object self = *closure[2];
// Begin line 748
  setline(748);
// Begin line 749
  setline(749);
// Begin line 736
  setline(736);
// compilenode returning *var_tmp4
  Object bool1741 = alloc_Boolean(0);
// compilenode returning bool1741
  params[0] = bool1741;
  Object opresult1743 = callmethod(*var_tmp4, "==", 1, params);
// compilenode returning opresult1743
  Object if1740;
  if (istrue(opresult1743)) {
// Begin line 738
  setline(738);
// Begin line 1017
  setline(1017);
// Begin line 737
  setline(737);
// compilenode returning *var_utt
  Object call1744 = callmethod(*var_utt, "methods",
    0, params);
// compilenode returning call1744
// compilenode returning call1744
  *var_tmp4 = call1744;
  if (call1744 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1740 = nothing;
  } else {
// Begin line 740
  setline(740);
  Object array1746 = alloc_List();
// compilenode returning array1746
  *var_tmp3 = array1746;
  if (array1746 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 743
  setline(743);
// Begin line 747
  setline(747);
// Begin line 1017
  setline(1017);
// Begin line 740
  setline(740);
// compilenode returning *var_utt
  Object call1749 = callmethod(*var_utt, "methods",
    0, params);
// compilenode returning call1749
// compilenode returning call1749
// Begin line 743
  setline(743);
// Begin line 1017
  setline(1017);
  Object obj1751 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1751, self, 0);
  addmethod2(obj1751, "outer", &reader_typechecker_outer_1752);
  adddatum2(obj1751, self, 0);
  block_savedest(obj1751);
  Object **closure1753 = createclosure(3);
  addtoclosure(closure1753, var_tmp4);
  addtoclosure(closure1753, var_tmp3);
  Object *selfpp1766 = alloc_var();
  *selfpp1766 = self;
  addtoclosure(closure1753, selfpp1766);
  struct UserObject *uo1753 = (struct UserObject*)obj1751;
  uo1753->data[1] = (Object)closure1753;
  addmethod2(obj1751, "apply", &meth_typechecker_apply1753);
  set_type(obj1751, 0);
// compilenode returning obj1751
  setclassname(obj1751, "Block<typechecker:1750>");
// compilenode returning obj1751
  params[0] = call1749;
  Object iter1748 = callmethod(call1749, "iter", 1, params);
  while(1) {
    Object cond1748 = callmethod(iter1748, "havemore", 0, NULL);
    if (!istrue(cond1748)) break;
    params[0] = callmethod(iter1748, "next", 0, NULL);
    callmethod(obj1751, "apply", 1, params);
  }
// compilenode returning call1749
// Begin line 748
  setline(748);
// Begin line 747
  setline(747);
// compilenode returning *var_tmp3
  *var_tmp4 = *var_tmp3;
  if (*var_tmp3 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1740 = nothing;
  }
// compilenode returning if1740
  return if1740;
}
Object meth_typechecker_apply1781(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[1];
  Object *var_tmp3 = closure[0];
  Object self = *closure[1];
// Begin line 753
  setline(753);
// compilenode returning *var_ut
// Begin line 754
  setline(754);
// Begin line 1017
  setline(1017);
// Begin line 753
  setline(753);
// compilenode returning *var_tmp3
  Object call1782 = callmethod(*var_tmp3, "unionTypes",
    0, params);
// compilenode returning call1782
// compilenode returning call1782
  params[0] = *var_ut;
  Object call1783 = callmethod(call1782, "push",
    1, params);
// compilenode returning call1783
  return call1783;
}
Object meth_typechecker_apply1804(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_it = alloc_var();
  *var_it = args[0];
  Object params[1];
  Object *var_tmp2 = closure[0];
  Object self = *closure[1];
// Begin line 762
  setline(762);
// compilenode returning *var_it
// compilenode returning self
  params[0] = *var_it;
  Object call1805 = callmethod(self, "findType",
    1, params);
// compilenode returning call1805
// Begin line 763
  setline(763);
// Begin line 1017
  setline(1017);
// Begin line 762
  setline(762);
// compilenode returning *var_tmp2
  Object call1806 = callmethod(*var_tmp2, "intersectionTypes",
    0, params);
// compilenode returning call1806
// compilenode returning call1806
  params[0] = call1805;
  Object call1807 = callmethod(call1806, "push",
    1, params);
// compilenode returning call1807
  return call1807;
}
Object meth_typechecker_apply1828(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_tm = alloc_var();
  *var_tm = args[0];
  Object params[1];
  Object *var_tmp4 = closure[0];
  Object self = *closure[1];
// Begin line 769
  setline(769);
// compilenode returning *var_tm
// compilenode returning *var_tmp4
  params[0] = *var_tm;
  Object call1829 = callmethod(*var_tmp4, "push",
    1, params);
// compilenode returning call1829
  return call1829;
}
Object meth_typechecker_apply1842(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_existingmeth = alloc_var();
  *var_existingmeth = args[0];
  Object params[1];
  Object *var_utm = closure[0];
  Object *var_imfound = closure[1];
  Object self = *closure[2];
// Begin line 777
  setline(777);
// Begin line 778
  setline(778);
// Begin line 1017
  setline(1017);
// Begin line 775
  setline(775);
// compilenode returning *var_existingmeth
  Object call1844 = callmethod(*var_existingmeth, "value",
    0, params);
// compilenode returning call1844
// compilenode returning call1844
// Begin line 778
  setline(778);
// Begin line 1017
  setline(1017);
// Begin line 775
  setline(775);
// compilenode returning *var_utm
  Object call1845 = callmethod(*var_utm, "value",
    0, params);
// compilenode returning call1845
// compilenode returning call1845
  params[0] = call1845;
  Object opresult1847 = callmethod(call1844, "==", 1, params);
// compilenode returning opresult1847
  Object if1843;
  if (istrue(opresult1847)) {
// Begin line 777
  setline(777);
// Begin line 776
  setline(776);
  Object bool1848 = alloc_Boolean(1);
// compilenode returning bool1848
  *var_imfound = bool1848;
  if (bool1848 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1843 = nothing;
  } else {
  }
// compilenode returning if1843
  return if1843;
}
Object meth_typechecker_apply1836(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_utm = alloc_var();
  *var_utm = args[0];
  Object params[1];
  Object *var_tmp4 = closure[0];
  Object self = *closure[1];
  Object *var_imfound = alloc_var();
  *var_imfound = undefined;
// Begin line 774
  setline(774);
// Begin line 773
  setline(773);
  Object bool1837 = alloc_Boolean(0);
// compilenode returning bool1837
  var_imfound = alloc_var();
  *var_imfound = bool1837;
  if (bool1837 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 777
  setline(777);
// Begin line 774
  setline(774);
// compilenode returning *var_tmp4
// Begin line 777
  setline(777);
// Begin line 1017
  setline(1017);
  Object obj1840 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1840, self, 0);
  addmethod2(obj1840, "outer", &reader_typechecker_outer_1841);
  adddatum2(obj1840, self, 0);
  block_savedest(obj1840);
  Object **closure1842 = createclosure(3);
  addtoclosure(closure1842, var_utm);
  addtoclosure(closure1842, var_imfound);
  Object *selfpp1850 = alloc_var();
  *selfpp1850 = self;
  addtoclosure(closure1842, selfpp1850);
  struct UserObject *uo1842 = (struct UserObject*)obj1840;
  uo1842->data[1] = (Object)closure1842;
  addmethod2(obj1840, "apply", &meth_typechecker_apply1842);
  set_type(obj1840, 0);
// compilenode returning obj1840
  setclassname(obj1840, "Block<typechecker:1839>");
// compilenode returning obj1840
  params[0] = *var_tmp4;
  Object iter1838 = callmethod(*var_tmp4, "iter", 1, params);
  while(1) {
    Object cond1838 = callmethod(iter1838, "havemore", 0, NULL);
    if (!istrue(cond1838)) break;
    params[0] = callmethod(iter1838, "next", 0, NULL);
    callmethod(obj1840, "apply", 1, params);
  }
// compilenode returning *var_tmp4
// Begin line 780
  setline(780);
// Begin line 782
  setline(782);
// Begin line 779
  setline(779);
// compilenode returning *var_imfound
  Object call1852 = callmethod(*var_imfound, "prefix!",
    0, params);
// compilenode returning call1852
  Object if1851;
  if (istrue(call1852)) {
// Begin line 780
  setline(780);
// compilenode returning *var_utm
// compilenode returning *var_tmp4
  params[0] = *var_utm;
  Object call1853 = callmethod(*var_tmp4, "push",
    1, params);
// compilenode returning call1853
    if1851 = call1853;
  } else {
  }
// compilenode returning if1851
  return if1851;
}
Object meth_typechecker_apply1816(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_utt = alloc_var();
  *var_utt = args[0];
  Object params[1];
  Object *var_tmp4 = closure[0];
  Object self = *closure[1];
// Begin line 780
  setline(780);
// Begin line 784
  setline(784);
// Begin line 766
  setline(766);
// compilenode returning *var_tmp4
  Object bool1818 = alloc_Boolean(0);
// compilenode returning bool1818
  params[0] = bool1818;
  Object opresult1820 = callmethod(*var_tmp4, "==", 1, params);
// compilenode returning opresult1820
  Object if1817;
  if (istrue(opresult1820)) {
// Begin line 768
  setline(768);
  Object array1821 = alloc_List();
// compilenode returning array1821
  *var_tmp4 = array1821;
  if (array1821 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 769
  setline(769);
// Begin line 771
  setline(771);
// Begin line 1017
  setline(1017);
// Begin line 768
  setline(768);
// compilenode returning *var_utt
  Object call1824 = callmethod(*var_utt, "methods",
    0, params);
// compilenode returning call1824
// compilenode returning call1824
// Begin line 769
  setline(769);
// Begin line 1017
  setline(1017);
  Object obj1826 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1826, self, 0);
  addmethod2(obj1826, "outer", &reader_typechecker_outer_1827);
  adddatum2(obj1826, self, 0);
  block_savedest(obj1826);
  Object **closure1828 = createclosure(2);
  addtoclosure(closure1828, var_tmp4);
  Object *selfpp1830 = alloc_var();
  *selfpp1830 = self;
  addtoclosure(closure1828, selfpp1830);
  struct UserObject *uo1828 = (struct UserObject*)obj1826;
  uo1828->data[1] = (Object)closure1828;
  addmethod2(obj1826, "apply", &meth_typechecker_apply1828);
  set_type(obj1826, 0);
// compilenode returning obj1826
  setclassname(obj1826, "Block<typechecker:1825>");
// compilenode returning obj1826
  params[0] = call1824;
  Object iter1823 = callmethod(call1824, "iter", 1, params);
  while(1) {
    Object cond1823 = callmethod(iter1823, "havemore", 0, NULL);
    if (!istrue(cond1823)) break;
    params[0] = callmethod(iter1823, "next", 0, NULL);
    callmethod(obj1826, "apply", 1, params);
  }
// compilenode returning call1824
    if1817 = call1824;
  } else {
// Begin line 780
  setline(780);
// Begin line 783
  setline(783);
// Begin line 1017
  setline(1017);
// Begin line 772
  setline(772);
// compilenode returning *var_utt
  Object call1832 = callmethod(*var_utt, "methods",
    0, params);
// compilenode returning call1832
// compilenode returning call1832
// Begin line 780
  setline(780);
// Begin line 1017
  setline(1017);
  Object obj1834 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1834, self, 0);
  addmethod2(obj1834, "outer", &reader_typechecker_outer_1835);
  adddatum2(obj1834, self, 0);
  block_savedest(obj1834);
  Object **closure1836 = createclosure(2);
  addtoclosure(closure1836, var_tmp4);
  Object *selfpp1854 = alloc_var();
  *selfpp1854 = self;
  addtoclosure(closure1836, selfpp1854);
  struct UserObject *uo1836 = (struct UserObject*)obj1834;
  uo1836->data[1] = (Object)closure1836;
  addmethod2(obj1834, "apply", &meth_typechecker_apply1836);
  set_type(obj1834, 0);
// compilenode returning obj1834
  setclassname(obj1834, "Block<typechecker:1833>");
// compilenode returning obj1834
  params[0] = call1832;
  Object iter1831 = callmethod(call1832, "iter", 1, params);
  while(1) {
    Object cond1831 = callmethod(iter1831, "havemore", 0, NULL);
    if (!istrue(cond1831)) break;
    params[0] = callmethod(iter1831, "next", 0, NULL);
    callmethod(obj1834, "apply", 1, params);
  }
// compilenode returning call1832
    if1817 = call1832;
  }
// compilenode returning if1817
  return if1817;
}
Object meth_typechecker_apply1868(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ut = alloc_var();
  *var_ut = args[0];
  Object params[1];
  Object *var_tmp3 = closure[0];
  Object self = *closure[1];
// Begin line 788
  setline(788);
// compilenode returning *var_ut
// Begin line 789
  setline(789);
// Begin line 1017
  setline(1017);
// Begin line 788
  setline(788);
// compilenode returning *var_tmp3
  Object call1869 = callmethod(*var_tmp3, "intersectionTypes",
    0, params);
// compilenode returning call1869
// compilenode returning call1869
  params[0] = *var_ut;
  Object call1870 = callmethod(call1869, "push",
    1, params);
// compilenode returning call1870
  return call1870;
}
Object meth_typechecker_resolveIdentifiers1267(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object *var_node = alloc_var();
  *var_node = args[0];
  Object params[4];
  Object *var_currentReturnType = closure[0];
  Object *var_Binding = closure[1];
  Object *var_scopes = closure[2];
  Object *var_l = alloc_var();
  *var_l = undefined;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
  Object *var_tmp2 = alloc_var();
  *var_tmp2 = undefined;
  Object *var_tmp3 = alloc_var();
  *var_tmp3 = undefined;
  Object *var_tmp4 = alloc_var();
  *var_tmp4 = undefined;
// Begin line 552
  setline(552);
  var_l = alloc_var();
  *var_l = undefined;
// compilenode returning nothing
// Begin line 553
  setline(553);
  var_tmp = alloc_var();
  *var_tmp = undefined;
// compilenode returning nothing
// Begin line 554
  setline(554);
  var_tmp2 = alloc_var();
  *var_tmp2 = undefined;
// compilenode returning nothing
// Begin line 555
  setline(555);
  var_tmp3 = alloc_var();
  *var_tmp3 = undefined;
// compilenode returning nothing
// Begin line 556
  setline(556);
  var_tmp4 = alloc_var();
  *var_tmp4 = undefined;
// compilenode returning nothing
// Begin line 558
  setline(558);
// Begin line 559
  setline(559);
// Begin line 556
  setline(556);
// compilenode returning *var_node
  Object bool1269 = alloc_Boolean(0);
// compilenode returning bool1269
  params[0] = bool1269;
  Object opresult1271 = callmethod(*var_node, "==", 1, params);
// compilenode returning opresult1271
  Object if1268;
  if (istrue(opresult1271)) {
// Begin line 558
  setline(558);
// Begin line 557
  setline(557);
// compilenode returning *var_node
  return *var_node;
// compilenode returning undefined
    if1268 = undefined;
  } else {
  }
// compilenode returning if1268
// Begin line 562
  setline(562);
// Begin line 563
  setline(563);
// Begin line 1017
  setline(1017);
// Begin line 559
  setline(559);
// compilenode returning *var_node
  Object call1273 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1273
// compilenode returning call1273
  if (strlit1274 == NULL) {
    strlit1274 = alloc_String("identifier");
  }
// compilenode returning strlit1274
  params[0] = strlit1274;
  Object opresult1276 = callmethod(call1273, "==", 1, params);
// compilenode returning opresult1276
  Object if1272;
  if (istrue(opresult1276)) {
// Begin line 560
  setline(560);
// compilenode returning *var_node
// Begin line 561
  setline(561);
// compilenode returning self
  params[0] = *var_node;
  Object call1277 = callmethod(self, "resolveIdentifier",
    1, params);
// compilenode returning call1277
  *var_tmp = call1277;
  if (call1277 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 562
  setline(562);
// Begin line 561
  setline(561);
// compilenode returning *var_tmp
  return *var_tmp;
// compilenode returning undefined
    if1272 = undefined;
  } else {
  }
// compilenode returning if1272
// Begin line 566
  setline(566);
// Begin line 568
  setline(568);
// Begin line 1017
  setline(1017);
// Begin line 563
  setline(563);
// compilenode returning *var_node
  Object call1280 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1280
// compilenode returning call1280
  if (strlit1281 == NULL) {
    strlit1281 = alloc_String("generic");
  }
// compilenode returning strlit1281
  params[0] = strlit1281;
  Object opresult1283 = callmethod(call1280, "==", 1, params);
// compilenode returning opresult1283
  Object if1279;
  if (istrue(opresult1283)) {
// Begin line 564
  setline(564);
// Begin line 1017
  setline(1017);
// Begin line 564
  setline(564);
// compilenode returning *var_node
  Object call1284 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1284
// compilenode returning call1284
// Begin line 565
  setline(565);
// compilenode returning self
  params[0] = call1284;
  Object call1285 = callmethod(self, "resolveIdentifier",
    1, params);
// compilenode returning call1285
  *var_tmp = call1285;
  if (call1285 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 565
  setline(565);
// compilenode returning *var_node
  Object call1287 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1287
// compilenode returning call1287
// Begin line 566
  setline(566);
// compilenode returning self
  params[0] = call1287;
  Object call1288 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1288
  *var_tmp2 = call1288;
  if (call1288 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = *var_tmp2;
  Object call1290 = callmethod(module_ast, "astgeneric",
    2, params);
// compilenode returning call1290
  return call1290;
// compilenode returning undefined
    if1279 = undefined;
  } else {
  }
// compilenode returning if1279
// Begin line 570
  setline(570);
// Begin line 572
  setline(572);
// Begin line 1017
  setline(1017);
// Begin line 568
  setline(568);
// compilenode returning *var_node
  Object call1292 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1292
// compilenode returning call1292
  if (strlit1293 == NULL) {
    strlit1293 = alloc_String("op");
  }
// compilenode returning strlit1293
  params[0] = strlit1293;
  Object opresult1295 = callmethod(call1292, "==", 1, params);
// compilenode returning opresult1295
  Object if1291;
  if (istrue(opresult1295)) {
// Begin line 570
  setline(570);
// Begin line 569
  setline(569);
// Begin line 1017
  setline(1017);
// Begin line 569
  setline(569);
// compilenode returning *var_node
  Object call1296 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1296
// compilenode returning call1296
// Begin line 1017
  setline(1017);
// Begin line 569
  setline(569);
// compilenode returning *var_node
  Object call1297 = callmethod(*var_node, "left",
    0, params);
// compilenode returning call1297
// compilenode returning call1297
// compilenode returning self
  params[0] = call1297;
  Object call1298 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1298
// Begin line 570
  setline(570);
// Begin line 1017
  setline(1017);
// Begin line 570
  setline(570);
// compilenode returning *var_node
  Object call1299 = callmethod(*var_node, "right",
    0, params);
// compilenode returning call1299
// compilenode returning call1299
// compilenode returning self
  params[0] = call1299;
  Object call1300 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1300
// Begin line 569
  setline(569);
// compilenode returning module_ast
  params[0] = call1296;
  params[1] = call1298;
  params[2] = call1300;
  Object call1301 = callmethod(module_ast, "astop",
    3, params);
// compilenode returning call1301
  return call1301;
// compilenode returning undefined
    if1291 = undefined;
  } else {
  }
// compilenode returning if1291
// Begin line 579
  setline(579);
// Begin line 581
  setline(581);
// Begin line 1017
  setline(1017);
// Begin line 572
  setline(572);
// compilenode returning *var_node
  Object call1303 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1303
// compilenode returning call1303
  if (strlit1304 == NULL) {
    strlit1304 = alloc_String("call");
  }
// compilenode returning strlit1304
  params[0] = strlit1304;
  Object opresult1306 = callmethod(call1303, "==", 1, params);
// compilenode returning opresult1306
  Object if1302;
  if (istrue(opresult1306)) {
  Object *var_p = alloc_var();
  *var_p = undefined;
// Begin line 573
  setline(573);
// Begin line 1017
  setline(1017);
// Begin line 573
  setline(573);
// compilenode returning *var_node
  Object call1307 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1307
// compilenode returning call1307
// Begin line 574
  setline(574);
// compilenode returning self
  params[0] = call1307;
  Object call1308 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1308
  var_p = alloc_var();
  *var_p = call1308;
  if (call1308 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 576
  setline(576);
// Begin line 578
  setline(578);
// Begin line 1017
  setline(1017);
// Begin line 574
  setline(574);
// compilenode returning *var_p
  Object call1310 = callmethod(*var_p, "kind",
    0, params);
// compilenode returning call1310
// compilenode returning call1310
  if (strlit1311 == NULL) {
    strlit1311 = alloc_String("call");
  }
// compilenode returning strlit1311
  params[0] = strlit1311;
  Object opresult1313 = callmethod(call1310, "==", 1, params);
// compilenode returning opresult1313
  Object if1309;
  if (istrue(opresult1313)) {
// Begin line 576
  setline(576);
// Begin line 575
  setline(575);
// Begin line 1017
  setline(1017);
// Begin line 575
  setline(575);
// compilenode returning *var_p
  Object call1314 = callmethod(*var_p, "value",
    0, params);
// compilenode returning call1314
// compilenode returning call1314
// Begin line 576
  setline(576);
// Begin line 1017
  setline(1017);
// Begin line 576
  setline(576);
// compilenode returning *var_node
  Object call1315 = callmethod(*var_node, "with",
    0, params);
// compilenode returning call1315
// compilenode returning call1315
// compilenode returning self
  params[0] = call1315;
  Object call1316 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1316
// Begin line 575
  setline(575);
// compilenode returning module_ast
  params[0] = call1314;
  params[1] = call1316;
  Object call1317 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1317
  return call1317;
// compilenode returning undefined
    if1309 = undefined;
  } else {
  }
// compilenode returning if1309
// Begin line 579
  setline(579);
// Begin line 578
  setline(578);
// compilenode returning *var_p
// Begin line 579
  setline(579);
// Begin line 1017
  setline(1017);
// Begin line 579
  setline(579);
// compilenode returning *var_node
  Object call1318 = callmethod(*var_node, "with",
    0, params);
// compilenode returning call1318
// compilenode returning call1318
// compilenode returning self
  params[0] = call1318;
  Object call1319 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1319
// Begin line 578
  setline(578);
// compilenode returning module_ast
  params[0] = *var_p;
  params[1] = call1319;
  Object call1320 = callmethod(module_ast, "astcall",
    2, params);
// compilenode returning call1320
  return call1320;
// compilenode returning undefined
    if1302 = undefined;
  } else {
  }
// compilenode returning if1302
// Begin line 583
  setline(583);
// Begin line 585
  setline(585);
// Begin line 1017
  setline(1017);
// Begin line 581
  setline(581);
// compilenode returning *var_node
  Object call1322 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1322
// compilenode returning call1322
  if (strlit1323 == NULL) {
    strlit1323 = alloc_String("member");
  }
// compilenode returning strlit1323
  params[0] = strlit1323;
  Object opresult1325 = callmethod(call1322, "==", 1, params);
// compilenode returning opresult1325
  Object if1321;
  if (istrue(opresult1325)) {
// Begin line 582
  setline(582);
// Begin line 1017
  setline(1017);
// Begin line 582
  setline(582);
// compilenode returning *var_node
  Object call1326 = callmethod(*var_node, "in",
    0, params);
// compilenode returning call1326
// compilenode returning call1326
// Begin line 583
  setline(583);
// compilenode returning self
  params[0] = call1326;
  Object call1327 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1327
  *var_tmp = call1327;
  if (call1327 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 583
  setline(583);
// compilenode returning *var_node
  Object call1329 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1329
// compilenode returning call1329
// compilenode returning *var_tmp
// compilenode returning module_ast
  params[0] = call1329;
  params[1] = *var_tmp;
  Object call1330 = callmethod(module_ast, "astmember",
    2, params);
// compilenode returning call1330
  return call1330;
// compilenode returning undefined
    if1321 = undefined;
  } else {
  }
// compilenode returning if1321
// Begin line 588
  setline(588);
// Begin line 591
  setline(591);
// Begin line 1017
  setline(1017);
// Begin line 585
  setline(585);
// compilenode returning *var_node
  Object call1332 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1332
// compilenode returning call1332
  if (strlit1333 == NULL) {
    strlit1333 = alloc_String("array");
  }
// compilenode returning strlit1333
  params[0] = strlit1333;
  Object opresult1335 = callmethod(call1332, "==", 1, params);
// compilenode returning opresult1335
  Object if1331;
  if (istrue(opresult1335)) {
// Begin line 586
  setline(586);
// Begin line 1017
  setline(1017);
// Begin line 586
  setline(586);
// compilenode returning *var_node
  Object call1336 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1336
// compilenode returning call1336
// Begin line 587
  setline(587);
// compilenode returning self
  params[0] = call1336;
  Object call1337 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1337
  *var_tmp = call1337;
  if (call1337 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 588
  setline(588);
// Begin line 590
  setline(590);
// Begin line 1017
  setline(1017);
// Begin line 587
  setline(587);
// compilenode returning *var_node
  Object call1340 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1340
// compilenode returning call1340
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult1342 = callmethod(call1340, "/=", 1, params);
// compilenode returning opresult1342
  Object if1339;
  if (istrue(opresult1342)) {
// Begin line 588
  setline(588);
// compilenode returning *var_tmp
// compilenode returning module_ast
  params[0] = *var_tmp;
  Object call1343 = callmethod(module_ast, "astarray",
    1, params);
// compilenode returning call1343
  return call1343;
// compilenode returning undefined
    if1339 = undefined;
  } else {
  }
// compilenode returning if1339
    if1331 = if1339;
  } else {
  }
// compilenode returning if1331
// Begin line 625
  setline(625);
// Begin line 626
  setline(626);
// Begin line 1017
  setline(1017);
// Begin line 591
  setline(591);
// compilenode returning *var_node
  Object call1345 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1345
// compilenode returning call1345
  if (strlit1346 == NULL) {
    strlit1346 = alloc_String("method");
  }
// compilenode returning strlit1346
  params[0] = strlit1346;
  Object opresult1348 = callmethod(call1345, "==", 1, params);
// compilenode returning opresult1348
  Object if1344;
  if (istrue(opresult1348)) {
  Object *var_oldReturnType = alloc_var();
  *var_oldReturnType = undefined;
// Begin line 592
  setline(592);
// compilenode returning self
  Object call1349 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call1349
// Begin line 594
  setline(594);
// Begin line 596
  setline(596);
// Begin line 1017
  setline(1017);
// Begin line 593
  setline(593);
// compilenode returning *var_node
  Object call1351 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1351
// compilenode returning call1351
// Begin line 594
  setline(594);
// Begin line 1017
  setline(1017);
  Object obj1353 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1353, self, 0);
  addmethod2(obj1353, "outer", &reader_typechecker_outer_1354);
  adddatum2(obj1353, self, 0);
  block_savedest(obj1353);
  Object **closure1355 = createclosure(1);
  Object *selfpp1357 = alloc_var();
  *selfpp1357 = self;
  addtoclosure(closure1355, selfpp1357);
  struct UserObject *uo1355 = (struct UserObject*)obj1353;
  uo1355->data[1] = (Object)closure1355;
  addmethod2(obj1353, "apply", &meth_typechecker_apply1355);
  set_type(obj1353, 0);
// compilenode returning obj1353
  setclassname(obj1353, "Block<typechecker:1352>");
// compilenode returning obj1353
  params[0] = call1351;
  Object iter1350 = callmethod(call1351, "iter", 1, params);
  while(1) {
    Object cond1350 = callmethod(iter1350, "havemore", 0, NULL);
    if (!istrue(cond1350)) break;
    params[0] = callmethod(iter1350, "next", 0, NULL);
    callmethod(obj1353, "apply", 1, params);
  }
// compilenode returning call1351
// Begin line 596
  setline(596);
// Begin line 1017
  setline(1017);
// Begin line 596
  setline(596);
// compilenode returning *var_node
  Object call1358 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1358
// compilenode returning call1358
// Begin line 597
  setline(597);
// compilenode returning self
  params[0] = call1358;
  Object call1359 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1359
  *var_tmp2 = call1359;
  if (call1359 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 598
  setline(598);
// Begin line 600
  setline(600);
// Begin line 1017
  setline(1017);
// Begin line 597
  setline(597);
// compilenode returning *var_node
  Object call1362 = callmethod(*var_node, "varargs",
    0, params);
// compilenode returning call1362
// compilenode returning call1362
  Object if1361;
  if (istrue(call1362)) {
// Begin line 598
  setline(598);
// Begin line 1017
  setline(1017);
// Begin line 598
  setline(598);
// compilenode returning *var_node
  Object call1363 = callmethod(*var_node, "vararg",
    0, params);
// compilenode returning call1363
// compilenode returning call1363
// Begin line 599
  setline(599);
// compilenode returning self
  params[0] = call1363;
  Object call1364 = callmethod(self, "bindIdentifier",
    1, params);
// compilenode returning call1364
    if1361 = call1364;
  } else {
  }
// compilenode returning if1361
// Begin line 600
  setline(600);
// Begin line 1017
  setline(1017);
// Begin line 600
  setline(600);
// compilenode returning *var_node
  Object call1365 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1365
// compilenode returning call1365
// Begin line 601
  setline(601);
// compilenode returning self
  params[0] = call1365;
  Object call1366 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1366
  *var_tmp4 = call1366;
  if (call1366 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 602
  setline(602);
// Begin line 601
  setline(601);
// compilenode returning *var_currentReturnType
  *var_oldReturnType = *var_currentReturnType;
  if (*var_currentReturnType == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 602
  setline(602);
// compilenode returning *var_tmp4
// Begin line 603
  setline(603);
// compilenode returning self
  params[0] = *var_tmp4;
  Object call1368 = callmethod(self, "findType",
    1, params);
// compilenode returning call1368
  *var_currentReturnType = call1368;
  if (call1368 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 604
  setline(604);
// Begin line 606
  setline(606);
// Begin line 603
  setline(603);
// compilenode returning *var_currentReturnType
  Object bool1371 = alloc_Boolean(0);
// compilenode returning bool1371
  params[0] = bool1371;
  Object opresult1373 = callmethod(*var_currentReturnType, "==", 1, params);
// compilenode returning opresult1373
  Object if1370;
  if (istrue(opresult1373)) {
// Begin line 604
  setline(604);
  if (strlit1374 == NULL) {
    strlit1374 = alloc_String("return type of method not defined as a type.");
  }
// compilenode returning strlit1374
// compilenode returning module_util
  params[0] = strlit1374;
  Object call1375 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call1375
    if1370 = call1375;
  } else {
  }
// compilenode returning if1370
// Begin line 606
  setline(606);
// Begin line 1017
  setline(1017);
// Begin line 606
  setline(606);
// compilenode returning *var_node
  Object call1376 = callmethod(*var_node, "body",
    0, params);
// compilenode returning call1376
// compilenode returning call1376
// Begin line 607
  setline(607);
// compilenode returning self
  params[0] = call1376;
  Object call1377 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1377
  *var_l = call1377;
  if (call1377 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 615
  setline(615);
// Begin line 618
  setline(618);
// Begin line 1017
  setline(1017);
// Begin line 607
  setline(607);
// compilenode returning *var_l
  Object call1380 = callmethod(*var_l, "size",
    0, params);
// compilenode returning call1380
// compilenode returning call1380
  Object num1381 = alloc_Float64(0.0);
// compilenode returning num1381
  params[0] = num1381;
  Object opresult1383 = callmethod(call1380, ">", 1, params);
// compilenode returning opresult1383
  Object if1379;
  if (istrue(opresult1383)) {
  Object *var_lastStatement = alloc_var();
  *var_lastStatement = undefined;
  Object *var_realType = alloc_var();
  *var_realType = undefined;
// Begin line 609
  setline(609);
// Begin line 1017
  setline(1017);
// Begin line 608
  setline(608);
// compilenode returning *var_l
  Object call1384 = callmethod(*var_l, "last",
    0, params);
// compilenode returning call1384
// compilenode returning call1384
  *var_lastStatement = call1384;
  if (call1384 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 609
  setline(609);
// compilenode returning *var_lastStatement
// Begin line 610
  setline(610);
// compilenode returning self
  params[0] = *var_lastStatement;
  Object call1385 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1385
  *var_realType = call1385;
  if (call1385 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 615
  setline(615);
// Begin line 617
  setline(617);
// Begin line 1017
  setline(1017);
// Begin line 610
  setline(610);
// compilenode returning *var_lastStatement
  Object call1387 = callmethod(*var_lastStatement, "kind",
    0, params);
// compilenode returning call1387
// compilenode returning call1387
  if (strlit1388 == NULL) {
    strlit1388 = alloc_String("return");
  }
// compilenode returning strlit1388
  params[0] = strlit1388;
  Object opresult1390 = callmethod(call1387, "==", 1, params);
// compilenode returning opresult1390
  Object if1386;
  if (istrue(opresult1390)) {
    if1386 = undefined;
  } else {
// Begin line 615
  setline(615);
// Begin line 612
  setline(612);
// Begin line 1017
  setline(1017);
// Begin line 612
  setline(612);
// compilenode returning *var_realType
// compilenode returning *var_currentReturnType
// Begin line 617
  setline(617);
// compilenode returning self
  params[0] = *var_realType;
  params[1] = *var_currentReturnType;
  Object call1392 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call1392
  Object call1393 = callmethod(call1392, "not",
    0, params);
// compilenode returning call1393
// compilenode returning call1393
  Object if1391;
  if (istrue(call1393)) {
// Begin line 615
  setline(615);
// Begin line 613
  setline(613);
  if (strlit1394 == NULL) {
    strlit1394 = alloc_String("returning type ");
  }
// compilenode returning strlit1394
// Begin line 615
  setline(615);
// Begin line 614
  setline(614);
  if (strlit1395 == NULL) {
    strlit1395 = alloc_String("");
  }
// compilenode returning strlit1395
// Begin line 615
  setline(615);
// Begin line 1017
  setline(1017);
// Begin line 614
  setline(614);
// compilenode returning *var_realType
  Object call1396 = callmethod(*var_realType, "value",
    0, params);
// compilenode returning call1396
// compilenode returning call1396
  params[0] = call1396;
  Object opresult1398 = callmethod(strlit1395, "++", 1, params);
// compilenode returning opresult1398
  if (strlit1399 == NULL) {
    strlit1399 = alloc_String(" from method of return type ");
  }
// compilenode returning strlit1399
  params[0] = strlit1399;
  Object opresult1401 = callmethod(opresult1398, "++", 1, params);
// compilenode returning opresult1401
  params[0] = opresult1401;
  Object opresult1403 = callmethod(strlit1394, "++", 1, params);
// compilenode returning opresult1403
// Begin line 615
  setline(615);
// Begin line 1017
  setline(1017);
// Begin line 615
  setline(615);
// compilenode returning *var_currentReturnType
  Object call1404 = callmethod(*var_currentReturnType, "value",
    0, params);
// compilenode returning call1404
// compilenode returning call1404
  params[0] = call1404;
  Object opresult1406 = callmethod(opresult1403, "++", 1, params);
// compilenode returning opresult1406
// Begin line 613
  setline(613);
// compilenode returning module_util
  params[0] = opresult1406;
  Object call1407 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call1407
    if1391 = call1407;
  } else {
  }
// compilenode returning if1391
    if1386 = if1391;
  }
// compilenode returning if1386
    if1379 = if1386;
  } else {
  }
// compilenode returning if1379
// Begin line 619
  setline(619);
// Begin line 618
  setline(618);
// compilenode returning *var_oldReturnType
  *var_currentReturnType = *var_oldReturnType;
  if (*var_oldReturnType == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 619
  setline(619);
// compilenode returning self
  Object call1409 = callmethod(self, "popScope",
    0, params);
// compilenode returning call1409
// Begin line 621
  setline(621);
// Begin line 620
  setline(620);
// Begin line 1017
  setline(1017);
// Begin line 620
  setline(620);
// compilenode returning *var_node
  Object call1410 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1410
// compilenode returning call1410
// compilenode returning *var_tmp2
// compilenode returning *var_l
// Begin line 621
  setline(621);
// compilenode returning *var_tmp4
// Begin line 620
  setline(620);
// compilenode returning module_ast
  params[0] = call1410;
  params[1] = *var_tmp2;
  params[2] = *var_l;
  params[3] = *var_tmp4;
  Object call1411 = callmethod(module_ast, "astmethod",
    4, params);
// compilenode returning call1411
  *var_tmp = call1411;
  if (call1411 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 623
  setline(623);
// Begin line 1017
  setline(1017);
// Begin line 623
  setline(623);
// Begin line 1017
  setline(1017);
// Begin line 622
  setline(622);
// compilenode returning *var_node
  Object call1413 = callmethod(*var_node, "varargs",
    0, params);
// compilenode returning call1413
// compilenode returning call1413
// compilenode returning *var_tmp
  params[0] = call1413;
  Object call1414 = callmethod(*var_tmp, "varargs:=",
    1, params);
// compilenode returning call1414
// compilenode returning nothing
// Begin line 624
  setline(624);
// Begin line 1017
  setline(1017);
// Begin line 624
  setline(624);
// Begin line 1017
  setline(1017);
// Begin line 623
  setline(623);
// compilenode returning *var_node
  Object call1415 = callmethod(*var_node, "vararg",
    0, params);
// compilenode returning call1415
// compilenode returning call1415
// compilenode returning *var_tmp
  params[0] = call1415;
  Object call1416 = callmethod(*var_tmp, "vararg:=",
    1, params);
// compilenode returning call1416
// compilenode returning nothing
// Begin line 625
  setline(625);
// Begin line 624
  setline(624);
// compilenode returning *var_tmp
  return *var_tmp;
// compilenode returning undefined
    if1344 = undefined;
  } else {
  }
// compilenode returning if1344
// Begin line 635
  setline(635);
// Begin line 636
  setline(636);
// Begin line 1017
  setline(1017);
// Begin line 626
  setline(626);
// compilenode returning *var_node
  Object call1418 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1418
// compilenode returning call1418
  if (strlit1419 == NULL) {
    strlit1419 = alloc_String("block");
  }
// compilenode returning strlit1419
  params[0] = strlit1419;
  Object opresult1421 = callmethod(call1418, "==", 1, params);
// compilenode returning opresult1421
  Object if1417;
  if (istrue(opresult1421)) {
// Begin line 627
  setline(627);
// compilenode returning self
  Object call1422 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call1422
// Begin line 629
  setline(629);
// Begin line 631
  setline(631);
// Begin line 1017
  setline(1017);
// Begin line 628
  setline(628);
// compilenode returning *var_node
  Object call1424 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1424
// compilenode returning call1424
// Begin line 629
  setline(629);
// Begin line 1017
  setline(1017);
  Object obj1426 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1426, self, 0);
  addmethod2(obj1426, "outer", &reader_typechecker_outer_1427);
  adddatum2(obj1426, self, 0);
  block_savedest(obj1426);
  Object **closure1428 = createclosure(1);
  Object *selfpp1430 = alloc_var();
  *selfpp1430 = self;
  addtoclosure(closure1428, selfpp1430);
  struct UserObject *uo1428 = (struct UserObject*)obj1426;
  uo1428->data[1] = (Object)closure1428;
  addmethod2(obj1426, "apply", &meth_typechecker_apply1428);
  set_type(obj1426, 0);
// compilenode returning obj1426
  setclassname(obj1426, "Block<typechecker:1425>");
// compilenode returning obj1426
  params[0] = call1424;
  Object iter1423 = callmethod(call1424, "iter", 1, params);
  while(1) {
    Object cond1423 = callmethod(iter1423, "havemore", 0, NULL);
    if (!istrue(cond1423)) break;
    params[0] = callmethod(iter1423, "next", 0, NULL);
    callmethod(obj1426, "apply", 1, params);
  }
// compilenode returning call1424
// Begin line 631
  setline(631);
// Begin line 1017
  setline(1017);
// Begin line 631
  setline(631);
// compilenode returning *var_node
  Object call1431 = callmethod(*var_node, "body",
    0, params);
// compilenode returning call1431
// compilenode returning call1431
// Begin line 632
  setline(632);
// compilenode returning self
  params[0] = call1431;
  Object call1432 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1432
  *var_l = call1432;
  if (call1432 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning self
  Object call1434 = callmethod(self, "popScope",
    0, params);
// compilenode returning call1434
// Begin line 633
  setline(633);
// Begin line 1017
  setline(1017);
// Begin line 633
  setline(633);
// compilenode returning *var_node
  Object call1435 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1435
// compilenode returning call1435
// compilenode returning *var_l
// compilenode returning module_ast
  params[0] = call1435;
  params[1] = *var_l;
  Object call1436 = callmethod(module_ast, "astblock",
    2, params);
// compilenode returning call1436
  *var_tmp = call1436;
  if (call1436 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 635
  setline(635);
// Begin line 634
  setline(634);
// compilenode returning *var_tmp
  return *var_tmp;
// compilenode returning undefined
    if1417 = undefined;
  } else {
  }
// compilenode returning if1417
// Begin line 645
  setline(645);
// Begin line 646
  setline(646);
// Begin line 1017
  setline(1017);
// Begin line 636
  setline(636);
// compilenode returning *var_node
  Object call1439 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1439
// compilenode returning call1439
  if (strlit1440 == NULL) {
    strlit1440 = alloc_String("object");
  }
// compilenode returning strlit1440
  params[0] = strlit1440;
  Object opresult1442 = callmethod(call1439, "==", 1, params);
// compilenode returning opresult1442
  Object if1438;
  if (istrue(opresult1442)) {
// Begin line 639
  setline(639);
// Begin line 1017
  setline(1017);
  Object obj1444 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1444, self, 0);
  addmethod2(obj1444, "outer", &reader_typechecker_outer_1445);
  adddatum2(obj1444, self, 0);
  block_savedest(obj1444);
  Object **closure1446 = createclosure(3);
  addtoclosure(closure1446, var_Binding);
  addtoclosure(closure1446, var_scopes);
  Object *selfpp1457 = alloc_var();
  *selfpp1457 = self;
  addtoclosure(closure1446, selfpp1457);
  struct UserObject *uo1446 = (struct UserObject*)obj1444;
  uo1446->data[1] = (Object)closure1446;
  addmethod2(obj1444, "apply", &meth_typechecker_apply1446);
  set_type(obj1444, 0);
// compilenode returning obj1444
  setclassname(obj1444, "Block<typechecker:1443>");
// compilenode returning obj1444
  *var_tmp = obj1444;
  if (obj1444 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 641
  setline(641);
// Begin line 1017
  setline(1017);
// Begin line 641
  setline(641);
// compilenode returning *var_node
  Object call1459 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1459
// compilenode returning call1459
// compilenode returning *var_tmp
// Begin line 642
  setline(642);
// compilenode returning self
  params[0] = call1459;
  params[1] = *var_tmp;
  Object call1460 = callmethod(self, "resolveIdentifiersList(1)withBlock",
    2, params);
// compilenode returning call1460
  *var_l = call1460;
  if (call1460 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 643
  setline(643);
// Begin line 642
  setline(642);
// compilenode returning *var_l
// Begin line 643
  setline(643);
// Begin line 1017
  setline(1017);
// Begin line 643
  setline(643);
// compilenode returning *var_node
  Object call1462 = callmethod(*var_node, "superclass",
    0, params);
// compilenode returning call1462
// compilenode returning call1462
// compilenode returning self
  params[0] = call1462;
  Object call1463 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1463
// Begin line 642
  setline(642);
// compilenode returning module_ast
  params[0] = *var_l;
  params[1] = call1463;
  Object call1464 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call1464
  *var_tmp2 = call1464;
  if (call1464 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 645
  setline(645);
// Begin line 644
  setline(644);
// compilenode returning *var_tmp2
  return *var_tmp2;
// compilenode returning undefined
    if1438 = undefined;
  } else {
  }
// compilenode returning if1438
// Begin line 672
  setline(672);
// Begin line 674
  setline(674);
// Begin line 1017
  setline(1017);
// Begin line 646
  setline(646);
// compilenode returning *var_node
  Object call1467 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1467
// compilenode returning call1467
  if (strlit1468 == NULL) {
    strlit1468 = alloc_String("class");
  }
// compilenode returning strlit1468
  params[0] = strlit1468;
  Object opresult1470 = callmethod(call1467, "==", 1, params);
// compilenode returning opresult1470
  Object if1466;
  if (istrue(opresult1470)) {
// Begin line 647
  setline(647);
// compilenode returning self
  Object call1471 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call1471
// Begin line 651
  setline(651);
// Begin line 1017
  setline(1017);
  Object obj1473 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1473, self, 0);
  addmethod2(obj1473, "outer", &reader_typechecker_outer_1474);
  adddatum2(obj1473, self, 0);
  block_savedest(obj1473);
  Object **closure1475 = createclosure(3);
  addtoclosure(closure1475, var_Binding);
  addtoclosure(closure1475, var_scopes);
  Object *selfpp1491 = alloc_var();
  *selfpp1491 = self;
  addtoclosure(closure1475, selfpp1491);
  struct UserObject *uo1475 = (struct UserObject*)obj1473;
  uo1475->data[1] = (Object)closure1475;
  addmethod2(obj1473, "apply", &meth_typechecker_apply1475);
  set_type(obj1473, 0);
// compilenode returning obj1473
  setclassname(obj1473, "Block<typechecker:1472>");
// compilenode returning obj1473
  *var_tmp = obj1473;
  if (obj1473 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 661
  setline(661);
// Begin line 664
  setline(664);
// Begin line 1017
  setline(1017);
// Begin line 664
  setline(664);
// Begin line 1017
  setline(1017);
// Begin line 653
  setline(653);
// compilenode returning *var_node
  Object call1494 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1494
// compilenode returning call1494
  Object call1495 = callmethod(call1494, "kind",
    0, params);
// compilenode returning call1495
// compilenode returning call1495
  if (strlit1496 == NULL) {
    strlit1496 = alloc_String("generic");
  }
// compilenode returning strlit1496
  params[0] = strlit1496;
  Object opresult1498 = callmethod(call1495, "==", 1, params);
// compilenode returning opresult1498
  Object if1493;
  if (istrue(opresult1498)) {
// Begin line 661
  setline(661);
// Begin line 663
  setline(663);
// Begin line 1017
  setline(1017);
// Begin line 663
  setline(663);
// Begin line 1017
  setline(1017);
// Begin line 654
  setline(654);
// compilenode returning *var_node
  Object call1500 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1500
// compilenode returning call1500
  Object call1501 = callmethod(call1500, "params",
    0, params);
// compilenode returning call1501
// compilenode returning call1501
// Begin line 661
  setline(661);
// Begin line 1017
  setline(1017);
  Object obj1503 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1503, self, 0);
  addmethod2(obj1503, "outer", &reader_typechecker_outer_1504);
  adddatum2(obj1503, self, 0);
  block_savedest(obj1503);
  Object **closure1505 = createclosure(2);
  addtoclosure(closure1505, var_Binding);
  Object *selfpp1517 = alloc_var();
  *selfpp1517 = self;
  addtoclosure(closure1505, selfpp1517);
  struct UserObject *uo1505 = (struct UserObject*)obj1503;
  uo1505->data[1] = (Object)closure1505;
  addmethod2(obj1503, "apply", &meth_typechecker_apply1505);
  set_type(obj1503, 0);
// compilenode returning obj1503
  setclassname(obj1503, "Block<typechecker:1502>");
// compilenode returning obj1503
  params[0] = call1501;
  Object iter1499 = callmethod(call1501, "iter", 1, params);
  while(1) {
    Object cond1499 = callmethod(iter1499, "havemore", 0, NULL);
    if (!istrue(cond1499)) break;
    params[0] = callmethod(iter1499, "next", 0, NULL);
    callmethod(obj1503, "apply", 1, params);
  }
// compilenode returning call1501
    if1493 = call1501;
  } else {
  }
// compilenode returning if1493
// Begin line 665
  setline(665);
// Begin line 667
  setline(667);
// Begin line 1017
  setline(1017);
// Begin line 664
  setline(664);
// compilenode returning *var_node
  Object call1519 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1519
// compilenode returning call1519
// Begin line 665
  setline(665);
// Begin line 1017
  setline(1017);
  Object obj1521 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1521, self, 0);
  addmethod2(obj1521, "outer", &reader_typechecker_outer_1522);
  adddatum2(obj1521, self, 0);
  block_savedest(obj1521);
  Object **closure1523 = createclosure(1);
  Object *selfpp1525 = alloc_var();
  *selfpp1525 = self;
  addtoclosure(closure1523, selfpp1525);
  struct UserObject *uo1523 = (struct UserObject*)obj1521;
  uo1523->data[1] = (Object)closure1523;
  addmethod2(obj1521, "apply", &meth_typechecker_apply1523);
  set_type(obj1521, 0);
// compilenode returning obj1521
  setclassname(obj1521, "Block<typechecker:1520>");
// compilenode returning obj1521
  params[0] = call1519;
  Object iter1518 = callmethod(call1519, "iter", 1, params);
  while(1) {
    Object cond1518 = callmethod(iter1518, "havemore", 0, NULL);
    if (!istrue(cond1518)) break;
    params[0] = callmethod(iter1518, "next", 0, NULL);
    callmethod(obj1521, "apply", 1, params);
  }
// compilenode returning call1519
// Begin line 667
  setline(667);
// Begin line 1017
  setline(1017);
// Begin line 667
  setline(667);
// compilenode returning *var_node
  Object call1526 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1526
// compilenode returning call1526
// compilenode returning *var_tmp
// Begin line 668
  setline(668);
// compilenode returning self
  params[0] = call1526;
  params[1] = *var_tmp;
  Object call1527 = callmethod(self, "resolveIdentifiersList(1)withBlock",
    2, params);
// compilenode returning call1527
  *var_tmp2 = call1527;
  if (call1527 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 668
  setline(668);
// compilenode returning *var_node
  Object call1529 = callmethod(*var_node, "params",
    0, params);
// compilenode returning call1529
// compilenode returning call1529
// Begin line 669
  setline(669);
// compilenode returning self
  params[0] = call1529;
  Object call1530 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1530
  *var_tmp3 = call1530;
  if (call1530 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 671
  setline(671);
// Begin line 669
  setline(669);
// Begin line 1017
  setline(1017);
// Begin line 669
  setline(669);
// compilenode returning *var_node
  Object call1532 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1532
// compilenode returning call1532
// compilenode returning *var_tmp3
// Begin line 670
  setline(670);
// compilenode returning *var_tmp2
// Begin line 671
  setline(671);
// Begin line 1017
  setline(1017);
// Begin line 671
  setline(671);
// compilenode returning *var_node
  Object call1533 = callmethod(*var_node, "superclass",
    0, params);
// compilenode returning call1533
// compilenode returning call1533
// compilenode returning self
  params[0] = call1533;
  Object call1534 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1534
// Begin line 669
  setline(669);
// compilenode returning module_ast
  params[0] = call1532;
  params[1] = *var_tmp3;
  params[2] = *var_tmp2;
  params[3] = call1534;
  Object call1535 = callmethod(module_ast, "astclass",
    4, params);
// compilenode returning call1535
  *var_node = call1535;
  if (call1535 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 672
  setline(672);
// compilenode returning self
  Object call1537 = callmethod(self, "popScope",
    0, params);
// compilenode returning call1537
    if1466 = call1537;
  } else {
  }
// compilenode returning if1466
// Begin line 697
  setline(697);
// Begin line 700
  setline(700);
// Begin line 1017
  setline(1017);
// Begin line 674
  setline(674);
// compilenode returning *var_node
  Object call1539 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1539
// compilenode returning call1539
  if (strlit1540 == NULL) {
    strlit1540 = alloc_String("bind");
  }
// compilenode returning strlit1540
  params[0] = strlit1540;
  Object opresult1542 = callmethod(call1539, "==", 1, params);
// compilenode returning opresult1542
  Object if1538;
  if (istrue(opresult1542)) {
// Begin line 675
  setline(675);
// Begin line 1017
  setline(1017);
// Begin line 675
  setline(675);
// compilenode returning *var_node
  Object call1543 = callmethod(*var_node, "dest",
    0, params);
// compilenode returning call1543
// compilenode returning call1543
// Begin line 676
  setline(676);
// compilenode returning self
  params[0] = call1543;
  Object call1544 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1544
  *var_tmp = call1544;
  if (call1544 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 676
  setline(676);
// compilenode returning *var_node
  Object call1546 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1546
// compilenode returning call1546
// Begin line 677
  setline(677);
// compilenode returning self
  params[0] = call1546;
  Object call1547 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1547
  *var_tmp2 = call1547;
  if (call1547 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 695
  setline(695);
// Begin line 696
  setline(696);
// Begin line 1017
  setline(1017);
// Begin line 677
  setline(677);
// compilenode returning *var_tmp
  Object call1550 = callmethod(*var_tmp, "kind",
    0, params);
// compilenode returning call1550
// compilenode returning call1550
  if (strlit1551 == NULL) {
    strlit1551 = alloc_String("identifier");
  }
// compilenode returning strlit1551
  params[0] = strlit1551;
  Object opresult1553 = callmethod(call1550, "==", 1, params);
// compilenode returning opresult1553
  Object if1549;
  if (istrue(opresult1553)) {
// Begin line 678
  setline(678);
// Begin line 1017
  setline(1017);
// Begin line 678
  setline(678);
// compilenode returning *var_tmp
  Object call1554 = callmethod(*var_tmp, "value",
    0, params);
// compilenode returning call1554
// compilenode returning call1554
// Begin line 679
  setline(679);
// compilenode returning self
  params[0] = call1554;
  Object call1555 = callmethod(self, "findName",
    1, params);
// compilenode returning call1555
  *var_tmp3 = call1555;
  if (call1555 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 679
  setline(679);
// compilenode returning *var_tmp
  Object call1557 = callmethod(*var_tmp, "dtype",
    0, params);
// compilenode returning call1557
// compilenode returning call1557
// Begin line 680
  setline(680);
// compilenode returning self
  params[0] = call1557;
  Object call1558 = callmethod(self, "findType",
    1, params);
// compilenode returning call1558
  *var_tmp4 = call1558;
  if (call1558 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 685
  setline(685);
// Begin line 687
  setline(687);
// Begin line 1017
  setline(1017);
// Begin line 680
  setline(680);
// compilenode returning *var_tmp3
  Object call1561 = callmethod(*var_tmp3, "kind",
    0, params);
// compilenode returning call1561
// compilenode returning call1561
  if (strlit1562 == NULL) {
    strlit1562 = alloc_String("def");
  }
// compilenode returning strlit1562
  params[0] = strlit1562;
  Object opresult1564 = callmethod(call1561, "==", 1, params);
// compilenode returning opresult1564
  Object if1560;
  if (istrue(opresult1564)) {
// Begin line 681
  setline(681);
  if (strlit1565 == NULL) {
    strlit1565 = alloc_String("reassignment to constant ");
  }
// compilenode returning strlit1565
// Begin line 1017
  setline(1017);
// Begin line 681
  setline(681);
// compilenode returning *var_tmp
  Object call1566 = callmethod(*var_tmp, "value",
    0, params);
// compilenode returning call1566
// compilenode returning call1566
  params[0] = call1566;
  Object opresult1568 = callmethod(strlit1565, "++", 1, params);
// compilenode returning opresult1568
  if (strlit1569 == NULL) {
    strlit1569 = alloc_String("");
  }
// compilenode returning strlit1569
  params[0] = strlit1569;
  Object opresult1571 = callmethod(opresult1568, "++", 1, params);
// compilenode returning opresult1571
// compilenode returning module_util
  params[0] = opresult1571;
  Object call1572 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1572
    if1560 = call1572;
  } else {
// Begin line 685
  setline(685);
// Begin line 684
  setline(684);
// Begin line 1017
  setline(1017);
// Begin line 682
  setline(682);
// compilenode returning *var_tmp3
  Object call1574 = callmethod(*var_tmp3, "kind",
    0, params);
// compilenode returning call1574
// compilenode returning call1574
  if (strlit1575 == NULL) {
    strlit1575 = alloc_String("method");
  }
// compilenode returning strlit1575
  params[0] = strlit1575;
  Object opresult1577 = callmethod(call1574, "==", 1, params);
// compilenode returning opresult1577
  Object if1573;
  if (istrue(opresult1577)) {
// Begin line 683
  setline(683);
  if (strlit1578 == NULL) {
    strlit1578 = alloc_String("assignment to method ");
  }
// compilenode returning strlit1578
// Begin line 1017
  setline(1017);
// Begin line 683
  setline(683);
// Begin line 1017
  setline(1017);
// Begin line 683
  setline(683);
// compilenode returning *var_node
  Object call1579 = callmethod(*var_node, "dest",
    0, params);
// compilenode returning call1579
// compilenode returning call1579
  Object call1580 = callmethod(call1579, "value",
    0, params);
// compilenode returning call1580
// compilenode returning call1580
  params[0] = call1580;
  Object opresult1582 = callmethod(strlit1578, "++", 1, params);
// compilenode returning opresult1582
  if (strlit1583 == NULL) {
    strlit1583 = alloc_String("");
  }
// compilenode returning strlit1583
  params[0] = strlit1583;
  Object opresult1585 = callmethod(opresult1582, "++", 1, params);
// compilenode returning opresult1585
// compilenode returning module_util
  params[0] = opresult1585;
  Object call1586 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1586
    if1573 = call1586;
  } else {
// Begin line 685
  setline(685);
// Begin line 687
  setline(687);
// Begin line 1017
  setline(1017);
// Begin line 684
  setline(684);
// compilenode returning *var_tmp3
  Object call1588 = callmethod(*var_tmp3, "kind",
    0, params);
// compilenode returning call1588
// compilenode returning call1588
  if (strlit1589 == NULL) {
    strlit1589 = alloc_String("undef");
  }
// compilenode returning strlit1589
  params[0] = strlit1589;
  Object opresult1591 = callmethod(call1588, "==", 1, params);
// compilenode returning opresult1591
  Object if1587;
  if (istrue(opresult1591)) {
// Begin line 685
  setline(685);
  if (strlit1592 == NULL) {
    strlit1592 = alloc_String("assignment to undeclared ");
  }
// compilenode returning strlit1592
// Begin line 1017
  setline(1017);
// Begin line 685
  setline(685);
// compilenode returning *var_tmp
  Object call1593 = callmethod(*var_tmp, "value",
    0, params);
// compilenode returning call1593
// compilenode returning call1593
  params[0] = call1593;
  Object opresult1595 = callmethod(strlit1592, "++", 1, params);
// compilenode returning opresult1595
  if (strlit1596 == NULL) {
    strlit1596 = alloc_String("");
  }
// compilenode returning strlit1596
  params[0] = strlit1596;
  Object opresult1598 = callmethod(opresult1595, "++", 1, params);
// compilenode returning opresult1598
// compilenode returning module_util
  params[0] = opresult1598;
  Object call1599 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1599
    if1587 = call1599;
  } else {
  }
// compilenode returning if1587
    if1573 = if1587;
  }
// compilenode returning if1573
    if1560 = if1573;
  }
// compilenode returning if1560
// Begin line 691
  setline(691);
// Begin line 687
  setline(687);
// Begin line 1017
  setline(1017);
// Begin line 687
  setline(687);
// compilenode returning *var_tmp2
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1601 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1601
// Begin line 1017
  setline(1017);
// Begin line 687
  setline(687);
// compilenode returning *var_tmp
  Object call1602 = callmethod(*var_tmp, "dtype",
    0, params);
// compilenode returning call1602
// compilenode returning call1602
// Begin line 693
  setline(693);
// compilenode returning self
  params[0] = call1601;
  params[1] = call1602;
  Object call1603 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call1603
  Object call1604 = callmethod(call1603, "not",
    0, params);
// compilenode returning call1604
// compilenode returning call1604
  Object if1600;
  if (istrue(call1604)) {
// Begin line 691
  setline(691);
// Begin line 689
  setline(689);
// Begin line 688
  setline(688);
  if (strlit1605 == NULL) {
    strlit1605 = alloc_String("assigning value of nonconforming type ");
  }
// compilenode returning strlit1605
// Begin line 689
  setline(689);
// compilenode returning *var_tmp2
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1606 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1606
// compilenode returning module_subtype
  params[0] = call1606;
  Object call1607 = callmethod(module_subtype, "nicename",
    1, params);
// compilenode returning call1607
  params[0] = call1607;
  Object opresult1609 = callmethod(strlit1605, "++", 1, params);
// compilenode returning opresult1609
// Begin line 690
  setline(690);
  if (strlit1610 == NULL) {
    strlit1610 = alloc_String(" to var of type ");
  }
// compilenode returning strlit1610
  params[0] = strlit1610;
  Object opresult1612 = callmethod(opresult1609, "++", 1, params);
// compilenode returning opresult1612
// Begin line 691
  setline(691);
// Begin line 1017
  setline(1017);
// Begin line 691
  setline(691);
// compilenode returning *var_tmp
  Object call1613 = callmethod(*var_tmp, "dtype",
    0, params);
// compilenode returning call1613
// compilenode returning call1613
// compilenode returning self
  params[0] = call1613;
  Object call1614 = callmethod(self, "findType",
    1, params);
// compilenode returning call1614
// compilenode returning module_subtype
  params[0] = call1614;
  Object call1615 = callmethod(module_subtype, "nicename",
    1, params);
// compilenode returning call1615
  params[0] = call1615;
  Object opresult1617 = callmethod(opresult1612, "++", 1, params);
// compilenode returning opresult1617
// Begin line 688
  setline(688);
// compilenode returning module_util
  params[0] = opresult1617;
  Object call1618 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call1618
    if1600 = call1618;
  } else {
  }
// compilenode returning if1600
    if1549 = if1600;
  } else {
// Begin line 695
  setline(695);
// Begin line 696
  setline(696);
// Begin line 1017
  setline(1017);
// Begin line 693
  setline(693);
// compilenode returning *var_tmp
  Object call1620 = callmethod(*var_tmp, "kind",
    0, params);
// compilenode returning call1620
// compilenode returning call1620
  if (strlit1621 == NULL) {
    strlit1621 = alloc_String("call");
  }
// compilenode returning strlit1621
  params[0] = strlit1621;
  Object opresult1623 = callmethod(call1620, "==", 1, params);
// compilenode returning opresult1623
// Begin line 696
  setline(696);
// Begin line 1017
  setline(1017);
// Begin line 693
  setline(693);
// compilenode returning *var_node
  Object call1624 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1624
// compilenode returning call1624
  if (strlit1625 == NULL) {
    strlit1625 = alloc_String("call");
  }
// compilenode returning strlit1625
  params[0] = strlit1625;
  Object opresult1627 = callmethod(call1624, "/=", 1, params);
// compilenode returning opresult1627
  params[0] = opresult1627;
  Object opresult1629 = callmethod(opresult1623, "&", 1, params);
// compilenode returning opresult1629
  Object if1619;
  if (istrue(opresult1629)) {
// Begin line 695
  setline(695);
// Begin line 1017
  setline(1017);
// Begin line 694
  setline(694);
// compilenode returning *var_tmp
  Object call1630 = callmethod(*var_tmp, "value",
    0, params);
// compilenode returning call1630
// compilenode returning call1630
  *var_tmp = call1630;
  if (call1630 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1619 = nothing;
  } else {
  }
// compilenode returning if1619
    if1549 = if1619;
  }
// compilenode returning if1549
// Begin line 697
  setline(697);
// Begin line 699
  setline(699);
// Begin line 696
  setline(696);
// compilenode returning *var_tmp
// Begin line 699
  setline(699);
// Begin line 1017
  setline(1017);
// Begin line 696
  setline(696);
// compilenode returning *var_node
  Object call1633 = callmethod(*var_node, "dest",
    0, params);
// compilenode returning call1633
// compilenode returning call1633
  params[0] = call1633;
  Object opresult1635 = callmethod(*var_tmp, "/=", 1, params);
// compilenode returning opresult1635
// Begin line 699
  setline(699);
// Begin line 696
  setline(696);
// compilenode returning *var_tmp2
// Begin line 699
  setline(699);
// Begin line 1017
  setline(1017);
// Begin line 696
  setline(696);
// compilenode returning *var_node
  Object call1636 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1636
// compilenode returning call1636
  params[0] = call1636;
  Object opresult1638 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult1638
  params[0] = opresult1638;
  Object opresult1640 = callmethod(opresult1635, "|", 1, params);
// compilenode returning opresult1640
  Object if1632;
  if (istrue(opresult1640)) {
// Begin line 697
  setline(697);
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = *var_tmp2;
  Object call1641 = callmethod(module_ast, "astbind",
    2, params);
// compilenode returning call1641
  return call1641;
// compilenode returning undefined
    if1632 = undefined;
  } else {
  }
// compilenode returning if1632
    if1538 = if1632;
  } else {
  }
// compilenode returning if1538
// Begin line 797
  setline(797);
// Begin line 798
  setline(798);
// Begin line 1017
  setline(1017);
// Begin line 700
  setline(700);
// compilenode returning *var_node
  Object call1643 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1643
// compilenode returning call1643
  if (strlit1644 == NULL) {
    strlit1644 = alloc_String("type");
  }
// compilenode returning strlit1644
  params[0] = strlit1644;
  Object opresult1646 = callmethod(call1643, "==", 1, params);
// compilenode returning opresult1646
  Object if1642;
  if (istrue(opresult1646)) {
// Begin line 795
  setline(795);
// Begin line 796
  setline(796);
// Begin line 1017
  setline(1017);
// Begin line 796
  setline(796);
// Begin line 1017
  setline(1017);
// Begin line 701
  setline(701);
// compilenode returning *var_node
  Object call1648 = callmethod(*var_node, "generics",
    0, params);
// compilenode returning call1648
// compilenode returning call1648
  Object call1649 = callmethod(call1648, "size",
    0, params);
// compilenode returning call1649
// compilenode returning call1649
  Object num1650 = alloc_Float64(0.0);
// compilenode returning num1650
  params[0] = num1650;
  Object opresult1652 = callmethod(call1649, ">", 1, params);
// compilenode returning opresult1652
  Object if1647;
  if (istrue(opresult1652)) {
// Begin line 702
  setline(702);
// compilenode returning self
  Object call1653 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call1653
// Begin line 708
  setline(708);
// Begin line 710
  setline(710);
// Begin line 1017
  setline(1017);
// Begin line 703
  setline(703);
// compilenode returning *var_node
  Object call1655 = callmethod(*var_node, "generics",
    0, params);
// compilenode returning call1655
// compilenode returning call1655
// Begin line 708
  setline(708);
// Begin line 1017
  setline(1017);
  Object obj1657 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1657, self, 0);
  addmethod2(obj1657, "outer", &reader_typechecker_outer_1658);
  adddatum2(obj1657, self, 0);
  block_savedest(obj1657);
  Object **closure1659 = createclosure(2);
  addtoclosure(closure1659, var_Binding);
  Object *selfpp1670 = alloc_var();
  *selfpp1670 = self;
  addtoclosure(closure1659, selfpp1670);
  struct UserObject *uo1659 = (struct UserObject*)obj1657;
  uo1659->data[1] = (Object)closure1659;
  addmethod2(obj1657, "apply", &meth_typechecker_apply1659);
  set_type(obj1657, 0);
// compilenode returning obj1657
  setclassname(obj1657, "Block<typechecker:1656>");
// compilenode returning obj1657
  params[0] = call1655;
  Object iter1654 = callmethod(call1655, "iter", 1, params);
  while(1) {
    Object cond1654 = callmethod(iter1654, "havemore", 0, NULL);
    if (!istrue(cond1654)) break;
    params[0] = callmethod(iter1654, "next", 0, NULL);
    callmethod(obj1657, "apply", 1, params);
  }
// compilenode returning call1655
// Begin line 711
  setline(711);
  Object array1671 = alloc_List();
// compilenode returning array1671
  *var_tmp = array1671;
  if (array1671 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 721
  setline(721);
// Begin line 723
  setline(723);
// Begin line 1017
  setline(1017);
// Begin line 711
  setline(711);
// compilenode returning *var_node
  Object call1674 = callmethod(*var_node, "methods",
    0, params);
// compilenode returning call1674
// compilenode returning call1674
// Begin line 721
  setline(721);
// Begin line 1017
  setline(1017);
  Object obj1676 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1676, self, 0);
  addmethod2(obj1676, "outer", &reader_typechecker_outer_1677);
  adddatum2(obj1676, self, 0);
  block_savedest(obj1676);
  Object **closure1678 = createclosure(4);
  addtoclosure(closure1678, var_tmp2);
  addtoclosure(closure1678, var_tmp3);
  addtoclosure(closure1678, var_tmp);
  Object *selfpp1701 = alloc_var();
  *selfpp1701 = self;
  addtoclosure(closure1678, selfpp1701);
  struct UserObject *uo1678 = (struct UserObject*)obj1676;
  uo1678->data[1] = (Object)closure1678;
  addmethod2(obj1676, "apply", &meth_typechecker_apply1678);
  set_type(obj1676, 0);
// compilenode returning obj1676
  setclassname(obj1676, "Block<typechecker:1675>");
// compilenode returning obj1676
  params[0] = call1674;
  Object iter1673 = callmethod(call1674, "iter", 1, params);
  while(1) {
    Object cond1673 = callmethod(iter1673, "havemore", 0, NULL);
    if (!istrue(cond1673)) break;
    params[0] = callmethod(iter1673, "next", 0, NULL);
    callmethod(obj1676, "apply", 1, params);
  }
// compilenode returning call1674
// Begin line 723
  setline(723);
// compilenode returning self
  Object call1702 = callmethod(self, "popScope",
    0, params);
// compilenode returning call1702
// Begin line 724
  setline(724);
// Begin line 1017
  setline(1017);
// Begin line 724
  setline(724);
// compilenode returning *var_node
  Object call1703 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1703
// compilenode returning call1703
// compilenode returning *var_tmp
// compilenode returning module_ast
  params[0] = call1703;
  params[1] = *var_tmp;
  Object call1704 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1704
  *var_tmp = call1704;
  if (call1704 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 726
  setline(726);
// Begin line 1017
  setline(1017);
// Begin line 726
  setline(726);
// Begin line 1017
  setline(1017);
// Begin line 725
  setline(725);
// compilenode returning *var_node
  Object call1706 = callmethod(*var_node, "generics",
    0, params);
// compilenode returning call1706
// compilenode returning call1706
// compilenode returning *var_tmp
  params[0] = call1706;
  Object call1707 = callmethod(*var_tmp, "generics:=",
    1, params);
// compilenode returning call1707
// compilenode returning nothing
// Begin line 727
  setline(727);
// Begin line 1017
  setline(1017);
// Begin line 727
  setline(727);
// Begin line 1017
  setline(1017);
// Begin line 726
  setline(726);
// compilenode returning *var_node
  Object call1708 = callmethod(*var_node, "nominal",
    0, params);
// compilenode returning call1708
// compilenode returning call1708
// compilenode returning *var_tmp
  params[0] = call1708;
  Object call1709 = callmethod(*var_tmp, "nominal:=",
    1, params);
// compilenode returning call1709
// compilenode returning nothing
// Begin line 728
  setline(728);
// Begin line 727
  setline(727);
// compilenode returning *var_tmp
  return *var_tmp;
// compilenode returning undefined
    if1647 = undefined;
  } else {
// Begin line 795
  setline(795);
// Begin line 758
  setline(758);
// Begin line 1017
  setline(1017);
// Begin line 758
  setline(758);
// Begin line 1017
  setline(1017);
// Begin line 728
  setline(728);
// compilenode returning *var_node
  Object call1711 = callmethod(*var_node, "unionTypes",
    0, params);
// compilenode returning call1711
// compilenode returning call1711
  Object call1712 = callmethod(call1711, "size",
    0, params);
// compilenode returning call1712
// compilenode returning call1712
  Object num1713 = alloc_Float64(0.0);
// compilenode returning num1713
  params[0] = num1713;
  Object opresult1715 = callmethod(call1712, ">", 1, params);
// compilenode returning opresult1715
  Object if1710;
  if (istrue(opresult1715)) {
// Begin line 729
  setline(729);
// Begin line 1017
  setline(1017);
// Begin line 729
  setline(729);
// compilenode returning *var_node
  Object call1716 = callmethod(*var_node, "unionTypes",
    0, params);
// compilenode returning call1716
// compilenode returning call1716
// Begin line 730
  setline(730);
// compilenode returning self
  params[0] = call1716;
  Object call1717 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1717
  *var_tmp = call1717;
  if (call1717 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 730
  setline(730);
// compilenode returning *var_node
  Object call1719 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1719
// compilenode returning call1719
// Begin line 1017
  setline(1017);
// Begin line 730
  setline(730);
// compilenode returning *var_node
  Object call1720 = callmethod(*var_node, "methods",
    0, params);
// compilenode returning call1720
// compilenode returning call1720
// compilenode returning module_ast
  params[0] = call1719;
  params[1] = call1720;
  Object call1721 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1721
  *var_tmp2 = call1721;
  if (call1721 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 732
  setline(732);
// Begin line 731
  setline(731);
// compilenode returning *var_tmp
// Begin line 732
  setline(732);
// Begin line 1017
  setline(1017);
  Object obj1725 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1725, self, 0);
  addmethod2(obj1725, "outer", &reader_typechecker_outer_1726);
  adddatum2(obj1725, self, 0);
  block_savedest(obj1725);
  Object **closure1727 = createclosure(2);
  addtoclosure(closure1727, var_tmp2);
  Object *selfpp1731 = alloc_var();
  *selfpp1731 = self;
  addtoclosure(closure1727, selfpp1731);
  struct UserObject *uo1727 = (struct UserObject*)obj1725;
  uo1727->data[1] = (Object)closure1727;
  addmethod2(obj1725, "apply", &meth_typechecker_apply1727);
  set_type(obj1725, 0);
// compilenode returning obj1725
  setclassname(obj1725, "Block<typechecker:1724>");
// compilenode returning obj1725
  params[0] = *var_tmp;
  Object iter1723 = callmethod(*var_tmp, "iter", 1, params);
  while(1) {
    Object cond1723 = callmethod(iter1723, "havemore", 0, NULL);
    if (!istrue(cond1723)) break;
    params[0] = callmethod(iter1723, "next", 0, NULL);
    callmethod(obj1725, "apply", 1, params);
  }
// compilenode returning *var_tmp
// Begin line 735
  setline(735);
// Begin line 734
  setline(734);
  Object bool1732 = alloc_Boolean(0);
// compilenode returning bool1732
  *var_tmp4 = bool1732;
  if (bool1732 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 748
  setline(748);
// Begin line 750
  setline(750);
// Begin line 1017
  setline(1017);
// Begin line 735
  setline(735);
// compilenode returning *var_tmp2
  Object call1735 = callmethod(*var_tmp2, "unionTypes",
    0, params);
// compilenode returning call1735
// compilenode returning call1735
// Begin line 748
  setline(748);
// Begin line 1017
  setline(1017);
  Object obj1737 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1737, self, 0);
  addmethod2(obj1737, "outer", &reader_typechecker_outer_1738);
  adddatum2(obj1737, self, 0);
  block_savedest(obj1737);
  Object **closure1739 = createclosure(3);
  addtoclosure(closure1739, var_tmp4);
  addtoclosure(closure1739, var_tmp3);
  Object *selfpp1768 = alloc_var();
  *selfpp1768 = self;
  addtoclosure(closure1739, selfpp1768);
  struct UserObject *uo1739 = (struct UserObject*)obj1737;
  uo1739->data[1] = (Object)closure1739;
  addmethod2(obj1737, "apply", &meth_typechecker_apply1739);
  set_type(obj1737, 0);
// compilenode returning obj1737
  setclassname(obj1737, "Block<typechecker:1736>");
// compilenode returning obj1737
  params[0] = call1735;
  Object iter1734 = callmethod(call1735, "iter", 1, params);
  while(1) {
    Object cond1734 = callmethod(iter1734, "havemore", 0, NULL);
    if (!istrue(cond1734)) break;
    params[0] = callmethod(iter1734, "next", 0, NULL);
    callmethod(obj1737, "apply", 1, params);
  }
// compilenode returning call1735
// Begin line 756
  setline(756);
// Begin line 757
  setline(757);
// Begin line 750
  setline(750);
// compilenode returning *var_tmp4
  Object bool1770 = alloc_Boolean(0);
// compilenode returning bool1770
  params[0] = bool1770;
  Object opresult1772 = callmethod(*var_tmp4, "/=", 1, params);
// compilenode returning opresult1772
  Object if1769;
  if (istrue(opresult1772)) {
// Begin line 751
  setline(751);
// Begin line 1017
  setline(1017);
// Begin line 751
  setline(751);
// compilenode returning *var_node
  Object call1773 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1773
// compilenode returning call1773
// compilenode returning *var_tmp4
// compilenode returning module_ast
  params[0] = call1773;
  params[1] = *var_tmp4;
  Object call1774 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1774
  *var_tmp3 = call1774;
  if (call1774 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 753
  setline(753);
// Begin line 755
  setline(755);
// Begin line 1017
  setline(1017);
// Begin line 752
  setline(752);
// compilenode returning *var_tmp2
  Object call1777 = callmethod(*var_tmp2, "unionTypes",
    0, params);
// compilenode returning call1777
// compilenode returning call1777
// Begin line 753
  setline(753);
// Begin line 1017
  setline(1017);
  Object obj1779 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1779, self, 0);
  addmethod2(obj1779, "outer", &reader_typechecker_outer_1780);
  adddatum2(obj1779, self, 0);
  block_savedest(obj1779);
  Object **closure1781 = createclosure(2);
  addtoclosure(closure1781, var_tmp3);
  Object *selfpp1784 = alloc_var();
  *selfpp1784 = self;
  addtoclosure(closure1781, selfpp1784);
  struct UserObject *uo1781 = (struct UserObject*)obj1779;
  uo1781->data[1] = (Object)closure1781;
  addmethod2(obj1779, "apply", &meth_typechecker_apply1781);
  set_type(obj1779, 0);
// compilenode returning obj1779
  setclassname(obj1779, "Block<typechecker:1778>");
// compilenode returning obj1779
  params[0] = call1777;
  Object iter1776 = callmethod(call1777, "iter", 1, params);
  while(1) {
    Object cond1776 = callmethod(iter1776, "havemore", 0, NULL);
    if (!istrue(cond1776)) break;
    params[0] = callmethod(iter1776, "next", 0, NULL);
    callmethod(obj1779, "apply", 1, params);
  }
// compilenode returning call1777
// Begin line 756
  setline(756);
// Begin line 755
  setline(755);
// compilenode returning *var_tmp3
  *var_tmp2 = *var_tmp3;
  if (*var_tmp3 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1769 = nothing;
  } else {
  }
// compilenode returning if1769
// Begin line 757
  setline(757);
// compilenode returning *var_tmp2
// compilenode returning module_subtype
  params[0] = *var_tmp2;
  Object call1786 = callmethod(module_subtype, "resetType",
    1, params);
// compilenode returning call1786
    if1710 = call1786;
  } else {
// Begin line 795
  setline(795);
// Begin line 793
  setline(793);
// Begin line 1017
  setline(1017);
// Begin line 793
  setline(793);
// Begin line 1017
  setline(1017);
// Begin line 758
  setline(758);
// compilenode returning *var_node
  Object call1788 = callmethod(*var_node, "intersectionTypes",
    0, params);
// compilenode returning call1788
// compilenode returning call1788
  Object call1789 = callmethod(call1788, "size",
    0, params);
// compilenode returning call1789
// compilenode returning call1789
  Object num1790 = alloc_Float64(0.0);
// compilenode returning num1790
  params[0] = num1790;
  Object opresult1792 = callmethod(call1789, ">", 1, params);
// compilenode returning opresult1792
  Object if1787;
  if (istrue(opresult1792)) {
// Begin line 759
  setline(759);
// Begin line 1017
  setline(1017);
// Begin line 759
  setline(759);
// compilenode returning *var_node
  Object call1793 = callmethod(*var_node, "intersectionTypes",
    0, params);
// compilenode returning call1793
// compilenode returning call1793
// Begin line 760
  setline(760);
// compilenode returning self
  params[0] = call1793;
  Object call1794 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call1794
  *var_tmp = call1794;
  if (call1794 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 760
  setline(760);
// compilenode returning *var_node
  Object call1796 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1796
// compilenode returning call1796
// Begin line 1017
  setline(1017);
// Begin line 760
  setline(760);
// compilenode returning *var_node
  Object call1797 = callmethod(*var_node, "methods",
    0, params);
// compilenode returning call1797
// compilenode returning call1797
// compilenode returning module_ast
  params[0] = call1796;
  params[1] = call1797;
  Object call1798 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1798
  *var_tmp2 = call1798;
  if (call1798 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 762
  setline(762);
// Begin line 761
  setline(761);
// compilenode returning *var_tmp
// Begin line 762
  setline(762);
// Begin line 1017
  setline(1017);
  Object obj1802 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1802, self, 0);
  addmethod2(obj1802, "outer", &reader_typechecker_outer_1803);
  adddatum2(obj1802, self, 0);
  block_savedest(obj1802);
  Object **closure1804 = createclosure(2);
  addtoclosure(closure1804, var_tmp2);
  Object *selfpp1808 = alloc_var();
  *selfpp1808 = self;
  addtoclosure(closure1804, selfpp1808);
  struct UserObject *uo1804 = (struct UserObject*)obj1802;
  uo1804->data[1] = (Object)closure1804;
  addmethod2(obj1802, "apply", &meth_typechecker_apply1804);
  set_type(obj1802, 0);
// compilenode returning obj1802
  setclassname(obj1802, "Block<typechecker:1801>");
// compilenode returning obj1802
  params[0] = *var_tmp;
  Object iter1800 = callmethod(*var_tmp, "iter", 1, params);
  while(1) {
    Object cond1800 = callmethod(iter1800, "havemore", 0, NULL);
    if (!istrue(cond1800)) break;
    params[0] = callmethod(iter1800, "next", 0, NULL);
    callmethod(obj1802, "apply", 1, params);
  }
// compilenode returning *var_tmp
// Begin line 765
  setline(765);
// Begin line 764
  setline(764);
  Object bool1809 = alloc_Boolean(0);
// compilenode returning bool1809
  *var_tmp4 = bool1809;
  if (bool1809 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 780
  setline(780);
// Begin line 785
  setline(785);
// Begin line 1017
  setline(1017);
// Begin line 765
  setline(765);
// compilenode returning *var_tmp2
  Object call1812 = callmethod(*var_tmp2, "intersectionTypes",
    0, params);
// compilenode returning call1812
// compilenode returning call1812
// Begin line 780
  setline(780);
// Begin line 1017
  setline(1017);
  Object obj1814 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1814, self, 0);
  addmethod2(obj1814, "outer", &reader_typechecker_outer_1815);
  adddatum2(obj1814, self, 0);
  block_savedest(obj1814);
  Object **closure1816 = createclosure(2);
  addtoclosure(closure1816, var_tmp4);
  Object *selfpp1855 = alloc_var();
  *selfpp1855 = self;
  addtoclosure(closure1816, selfpp1855);
  struct UserObject *uo1816 = (struct UserObject*)obj1814;
  uo1816->data[1] = (Object)closure1816;
  addmethod2(obj1814, "apply", &meth_typechecker_apply1816);
  set_type(obj1814, 0);
// compilenode returning obj1814
  setclassname(obj1814, "Block<typechecker:1813>");
// compilenode returning obj1814
  params[0] = call1812;
  Object iter1811 = callmethod(call1812, "iter", 1, params);
  while(1) {
    Object cond1811 = callmethod(iter1811, "havemore", 0, NULL);
    if (!istrue(cond1811)) break;
    params[0] = callmethod(iter1811, "next", 0, NULL);
    callmethod(obj1814, "apply", 1, params);
  }
// compilenode returning call1812
// Begin line 791
  setline(791);
// Begin line 792
  setline(792);
// Begin line 785
  setline(785);
// compilenode returning *var_tmp4
  Object bool1857 = alloc_Boolean(0);
// compilenode returning bool1857
  params[0] = bool1857;
  Object opresult1859 = callmethod(*var_tmp4, "/=", 1, params);
// compilenode returning opresult1859
  Object if1856;
  if (istrue(opresult1859)) {
// Begin line 786
  setline(786);
// Begin line 1017
  setline(1017);
// Begin line 786
  setline(786);
// compilenode returning *var_node
  Object call1860 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1860
// compilenode returning call1860
// compilenode returning *var_tmp4
// compilenode returning module_ast
  params[0] = call1860;
  params[1] = *var_tmp4;
  Object call1861 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call1861
  *var_tmp3 = call1861;
  if (call1861 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 788
  setline(788);
// Begin line 790
  setline(790);
// Begin line 1017
  setline(1017);
// Begin line 787
  setline(787);
// compilenode returning *var_tmp2
  Object call1864 = callmethod(*var_tmp2, "intersectionTypes",
    0, params);
// compilenode returning call1864
// compilenode returning call1864
// Begin line 788
  setline(788);
// Begin line 1017
  setline(1017);
  Object obj1866 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj1866, self, 0);
  addmethod2(obj1866, "outer", &reader_typechecker_outer_1867);
  adddatum2(obj1866, self, 0);
  block_savedest(obj1866);
  Object **closure1868 = createclosure(2);
  addtoclosure(closure1868, var_tmp3);
  Object *selfpp1871 = alloc_var();
  *selfpp1871 = self;
  addtoclosure(closure1868, selfpp1871);
  struct UserObject *uo1868 = (struct UserObject*)obj1866;
  uo1868->data[1] = (Object)closure1868;
  addmethod2(obj1866, "apply", &meth_typechecker_apply1868);
  set_type(obj1866, 0);
// compilenode returning obj1866
  setclassname(obj1866, "Block<typechecker:1865>");
// compilenode returning obj1866
  params[0] = call1864;
  Object iter1863 = callmethod(call1864, "iter", 1, params);
  while(1) {
    Object cond1863 = callmethod(iter1863, "havemore", 0, NULL);
    if (!istrue(cond1863)) break;
    params[0] = callmethod(iter1863, "next", 0, NULL);
    callmethod(obj1866, "apply", 1, params);
  }
// compilenode returning call1864
// Begin line 791
  setline(791);
// Begin line 790
  setline(790);
// compilenode returning *var_tmp3
  *var_tmp2 = *var_tmp3;
  if (*var_tmp3 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1856 = nothing;
  } else {
  }
// compilenode returning if1856
// Begin line 792
  setline(792);
// compilenode returning *var_tmp2
// compilenode returning module_subtype
  params[0] = *var_tmp2;
  Object call1873 = callmethod(module_subtype, "resetType",
    1, params);
// compilenode returning call1873
    if1787 = call1873;
  } else {
// Begin line 795
  setline(795);
// Begin line 794
  setline(794);
// compilenode returning *var_node
  *var_tmp2 = *var_node;
  if (*var_node == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1787 = nothing;
  }
// compilenode returning if1787
    if1710 = if1787;
  }
// compilenode returning if1710
    if1647 = if1710;
  }
// compilenode returning if1647
// Begin line 797
  setline(797);
// Begin line 796
  setline(796);
// compilenode returning *var_tmp2
  return *var_tmp2;
// compilenode returning undefined
    if1642 = undefined;
  } else {
  }
// compilenode returning if1642
// Begin line 814
  setline(814);
// Begin line 817
  setline(817);
// Begin line 1017
  setline(1017);
// Begin line 798
  setline(798);
// compilenode returning *var_node
  Object call1876 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1876
// compilenode returning call1876
  if (strlit1877 == NULL) {
    strlit1877 = alloc_String("vardec");
  }
// compilenode returning strlit1877
  params[0] = strlit1877;
  Object opresult1879 = callmethod(call1876, "==", 1, params);
// compilenode returning opresult1879
  Object if1875;
  if (istrue(opresult1879)) {
// Begin line 800
  setline(800);
// Begin line 1017
  setline(1017);
// Begin line 799
  setline(799);
// compilenode returning *var_node
  Object call1880 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1880
// compilenode returning call1880
  *var_tmp = call1880;
  if (call1880 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 800
  setline(800);
// compilenode returning *var_tmp
// Begin line 801
  setline(801);
// compilenode returning self
  params[0] = *var_tmp;
  Object call1882 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1882
  *var_tmp2 = call1882;
  if (call1882 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 801
  setline(801);
// compilenode returning *var_node
  Object call1884 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1884
// compilenode returning call1884
// Begin line 802
  setline(802);
// compilenode returning self
  params[0] = call1884;
  Object call1885 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1885
  *var_tmp4 = call1885;
  if (call1885 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 809
  setline(809);
// Begin line 812
  setline(812);
// Begin line 802
  setline(802);
// compilenode returning *var_tmp2
  Object bool1888 = alloc_Boolean(0);
// compilenode returning bool1888
  params[0] = bool1888;
  Object opresult1890 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult1890
  Object if1887;
  if (istrue(opresult1890)) {
// Begin line 803
  setline(803);
// compilenode returning *var_tmp4
// Begin line 804
  setline(804);
// compilenode returning self
  params[0] = *var_tmp4;
  Object call1891 = callmethod(self, "findType",
    1, params);
// compilenode returning call1891
  *var_tmp3 = call1891;
  if (call1891 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 805
  setline(805);
// Begin line 804
  setline(804);
// compilenode returning *var_tmp3
  *var_tmp4 = *var_tmp3;
  if (*var_tmp3 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 809
  setline(809);
// Begin line 805
  setline(805);
// Begin line 1017
  setline(1017);
// Begin line 805
  setline(805);
// compilenode returning *var_tmp2
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1895 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1895
// compilenode returning *var_tmp3
// Begin line 811
  setline(811);
// compilenode returning self
  params[0] = call1895;
  params[1] = *var_tmp3;
  Object call1896 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call1896
  Object call1897 = callmethod(call1896, "not",
    0, params);
// compilenode returning call1897
// compilenode returning call1897
  Object if1894;
  if (istrue(call1897)) {
// Begin line 809
  setline(809);
// Begin line 807
  setline(807);
// Begin line 806
  setline(806);
  if (strlit1898 == NULL) {
    strlit1898 = alloc_String("initialising var of type ");
  }
// compilenode returning strlit1898
// Begin line 807
  setline(807);
// compilenode returning *var_tmp3
// compilenode returning module_subtype
  params[0] = *var_tmp3;
  Object call1899 = callmethod(module_subtype, "nicename",
    1, params);
// compilenode returning call1899
  params[0] = call1899;
  Object opresult1901 = callmethod(strlit1898, "++", 1, params);
// compilenode returning opresult1901
// Begin line 808
  setline(808);
  if (strlit1902 == NULL) {
    strlit1902 = alloc_String(" with expression of type ");
  }
// compilenode returning strlit1902
  params[0] = strlit1902;
  Object opresult1904 = callmethod(opresult1901, "++", 1, params);
// compilenode returning opresult1904
// Begin line 809
  setline(809);
// compilenode returning *var_tmp2
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1905 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1905
// compilenode returning module_subtype
  params[0] = call1905;
  Object call1906 = callmethod(module_subtype, "nicename",
    1, params);
// compilenode returning call1906
  params[0] = call1906;
  Object opresult1908 = callmethod(opresult1904, "++", 1, params);
// compilenode returning opresult1908
// Begin line 806
  setline(806);
// compilenode returning module_util
  params[0] = opresult1908;
  Object call1909 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call1909
    if1894 = call1909;
  } else {
  }
// compilenode returning if1894
    if1887 = if1894;
  } else {
  }
// compilenode returning if1887
// Begin line 814
  setline(814);
// Begin line 816
  setline(816);
// Begin line 812
  setline(812);
// compilenode returning *var_tmp2
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult1912 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult1912
// Begin line 816
  setline(816);
// Begin line 812
  setline(812);
// compilenode returning *var_tmp4
// Begin line 816
  setline(816);
// Begin line 1017
  setline(1017);
// Begin line 812
  setline(812);
// compilenode returning *var_node
  Object call1913 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1913
// compilenode returning call1913
  params[0] = call1913;
  Object opresult1915 = callmethod(*var_tmp4, "/=", 1, params);
// compilenode returning opresult1915
  params[0] = opresult1915;
  Object opresult1917 = callmethod(opresult1912, "|", 1, params);
// compilenode returning opresult1917
  Object if1910;
  if (istrue(opresult1917)) {
// Begin line 813
  setline(813);
// Begin line 1017
  setline(1017);
// Begin line 813
  setline(813);
// compilenode returning *var_tmp4
// Begin line 1017
  setline(1017);
// Begin line 813
  setline(813);
// Begin line 1017
  setline(1017);
// Begin line 813
  setline(813);
// compilenode returning *var_node
  Object call1918 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1918
// compilenode returning call1918
  Object call1919 = callmethod(call1918, "value",
    0, params);
// compilenode returning call1919
// compilenode returning call1919
// Begin line 814
  setline(814);
// compilenode returning self
  params[0] = call1919;
  Object call1920 = callmethod(self, "findName",
    1, params);
// compilenode returning call1920
  params[0] = *var_tmp4;
  Object call1921 = callmethod(call1920, "dtype:=",
    1, params);
// compilenode returning call1921
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 814
  setline(814);
// compilenode returning *var_node
  Object call1922 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1922
// compilenode returning call1922
// compilenode returning *var_tmp2
// compilenode returning *var_tmp4
// compilenode returning module_ast
  params[0] = call1922;
  params[1] = *var_tmp2;
  params[2] = *var_tmp4;
  Object call1923 = callmethod(module_ast, "astvardec",
    3, params);
// compilenode returning call1923
  return call1923;
// compilenode returning undefined
    if1910 = undefined;
  } else {
  }
// compilenode returning if1910
    if1875 = if1910;
  } else {
  }
// compilenode returning if1875
// Begin line 833
  setline(833);
// Begin line 836
  setline(836);
// Begin line 1017
  setline(1017);
// Begin line 817
  setline(817);
// compilenode returning *var_node
  Object call1925 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1925
// compilenode returning call1925
  if (strlit1926 == NULL) {
    strlit1926 = alloc_String("defdec");
  }
// compilenode returning strlit1926
  params[0] = strlit1926;
  Object opresult1928 = callmethod(call1925, "==", 1, params);
// compilenode returning opresult1928
  Object if1924;
  if (istrue(opresult1928)) {
// Begin line 819
  setline(819);
// Begin line 1017
  setline(1017);
// Begin line 818
  setline(818);
// compilenode returning *var_node
  Object call1929 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1929
// compilenode returning call1929
  *var_tmp = call1929;
  if (call1929 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 819
  setline(819);
// compilenode returning *var_tmp
// Begin line 820
  setline(820);
// compilenode returning self
  params[0] = *var_tmp;
  Object call1931 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1931
  *var_tmp2 = call1931;
  if (call1931 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 820
  setline(820);
// compilenode returning *var_node
  Object call1933 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1933
// compilenode returning call1933
// Begin line 821
  setline(821);
// compilenode returning self
  params[0] = call1933;
  Object call1934 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1934
  *var_tmp4 = call1934;
  if (call1934 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tmp4
// Begin line 822
  setline(822);
// compilenode returning self
  params[0] = *var_tmp4;
  Object call1936 = callmethod(self, "findType",
    1, params);
// compilenode returning call1936
  *var_tmp3 = call1936;
  if (call1936 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 826
  setline(826);
// Begin line 822
  setline(822);
// Begin line 1017
  setline(1017);
// Begin line 822
  setline(822);
// compilenode returning *var_tmp2
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1939 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1939
// compilenode returning *var_tmp3
// Begin line 828
  setline(828);
// compilenode returning self
  params[0] = call1939;
  params[1] = *var_tmp3;
  Object call1940 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call1940
  Object call1941 = callmethod(call1940, "not",
    0, params);
// compilenode returning call1941
// compilenode returning call1941
  Object if1938;
  if (istrue(call1941)) {
// Begin line 826
  setline(826);
// Begin line 824
  setline(824);
// Begin line 823
  setline(823);
  if (strlit1942 == NULL) {
    strlit1942 = alloc_String("initialising def of type ");
  }
// compilenode returning strlit1942
// Begin line 824
  setline(824);
// compilenode returning *var_tmp3
// compilenode returning module_subtype
  params[0] = *var_tmp3;
  Object call1943 = callmethod(module_subtype, "nicename",
    1, params);
// compilenode returning call1943
  params[0] = call1943;
  Object opresult1945 = callmethod(strlit1942, "++", 1, params);
// compilenode returning opresult1945
// Begin line 825
  setline(825);
  if (strlit1946 == NULL) {
    strlit1946 = alloc_String(" with expression of type ");
  }
// compilenode returning strlit1946
  params[0] = strlit1946;
  Object opresult1948 = callmethod(opresult1945, "++", 1, params);
// compilenode returning opresult1948
// Begin line 826
  setline(826);
// compilenode returning *var_tmp2
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1949 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1949
// compilenode returning module_subtype
  params[0] = call1949;
  Object call1950 = callmethod(module_subtype, "nicename",
    1, params);
// compilenode returning call1950
  params[0] = call1950;
  Object opresult1952 = callmethod(opresult1948, "++", 1, params);
// compilenode returning opresult1952
// Begin line 823
  setline(823);
// compilenode returning module_util
  params[0] = opresult1952;
  Object call1953 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call1953
    if1938 = call1953;
  } else {
  }
// compilenode returning if1938
// Begin line 829
  setline(829);
// Begin line 831
  setline(831);
// Begin line 1017
  setline(1017);
// Begin line 828
  setline(828);
// compilenode returning *var_node
  Object call1955 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1955
// compilenode returning call1955
  Object bool1956 = alloc_Boolean(0);
// compilenode returning bool1956
  params[0] = bool1956;
  Object opresult1958 = callmethod(call1955, "==", 1, params);
// compilenode returning opresult1958
// Begin line 831
  setline(831);
// Begin line 1017
  setline(1017);
// Begin line 828
  setline(828);
// compilenode returning *var_tmp4
  Object call1959 = callmethod(*var_tmp4, "value",
    0, params);
// compilenode returning call1959
// compilenode returning call1959
  if (strlit1960 == NULL) {
    strlit1960 = alloc_String("Dynamic");
  }
// compilenode returning strlit1960
  params[0] = strlit1960;
  Object opresult1962 = callmethod(call1959, "==", 1, params);
// compilenode returning opresult1962
  params[0] = opresult1962;
  Object opresult1964 = callmethod(opresult1958, "|", 1, params);
// compilenode returning opresult1964
  Object if1954;
  if (istrue(opresult1964)) {
// Begin line 829
  setline(829);
// compilenode returning *var_tmp2
// Begin line 830
  setline(830);
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1965 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1965
  *var_tmp4 = call1965;
  if (call1965 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if1954 = nothing;
  } else {
  }
// compilenode returning if1954
// Begin line 833
  setline(833);
// Begin line 835
  setline(835);
// Begin line 831
  setline(831);
// compilenode returning *var_tmp2
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult1969 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult1969
// Begin line 835
  setline(835);
// Begin line 831
  setline(831);
// compilenode returning *var_tmp4
// Begin line 835
  setline(835);
// Begin line 1017
  setline(1017);
// Begin line 831
  setline(831);
// compilenode returning *var_node
  Object call1970 = callmethod(*var_node, "dtype",
    0, params);
// compilenode returning call1970
// compilenode returning call1970
  params[0] = call1970;
  Object opresult1972 = callmethod(*var_tmp4, "/=", 1, params);
// compilenode returning opresult1972
  params[0] = opresult1972;
  Object opresult1974 = callmethod(opresult1969, "|", 1, params);
// compilenode returning opresult1974
  Object if1967;
  if (istrue(opresult1974)) {
// Begin line 832
  setline(832);
// Begin line 1017
  setline(1017);
// Begin line 832
  setline(832);
// compilenode returning *var_tmp4
// Begin line 1017
  setline(1017);
// Begin line 832
  setline(832);
// Begin line 1017
  setline(1017);
// Begin line 832
  setline(832);
// compilenode returning *var_node
  Object call1975 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1975
// compilenode returning call1975
  Object call1976 = callmethod(call1975, "value",
    0, params);
// compilenode returning call1976
// compilenode returning call1976
// Begin line 833
  setline(833);
// compilenode returning self
  params[0] = call1976;
  Object call1977 = callmethod(self, "findName",
    1, params);
// compilenode returning call1977
  params[0] = *var_tmp4;
  Object call1978 = callmethod(call1977, "dtype:=",
    1, params);
// compilenode returning call1978
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 833
  setline(833);
// compilenode returning *var_node
  Object call1979 = callmethod(*var_node, "name",
    0, params);
// compilenode returning call1979
// compilenode returning call1979
// compilenode returning *var_tmp2
// compilenode returning *var_tmp4
// compilenode returning module_ast
  params[0] = call1979;
  params[1] = *var_tmp2;
  params[2] = *var_tmp4;
  Object call1980 = callmethod(module_ast, "astdefdec",
    3, params);
// compilenode returning call1980
  return call1980;
// compilenode returning undefined
    if1967 = undefined;
  } else {
  }
// compilenode returning if1967
    if1924 = if1967;
  } else {
  }
// compilenode returning if1924
// Begin line 849
  setline(849);
// Begin line 852
  setline(852);
// Begin line 1017
  setline(1017);
// Begin line 836
  setline(836);
// compilenode returning *var_node
  Object call1982 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call1982
// compilenode returning call1982
  if (strlit1983 == NULL) {
    strlit1983 = alloc_String("return");
  }
// compilenode returning strlit1983
  params[0] = strlit1983;
  Object opresult1985 = callmethod(call1982, "==", 1, params);
// compilenode returning opresult1985
  Object if1981;
  if (istrue(opresult1985)) {
// Begin line 838
  setline(838);
// Begin line 840
  setline(840);
// Begin line 837
  setline(837);
// compilenode returning *var_currentReturnType
  Object bool1987 = alloc_Boolean(0);
// compilenode returning bool1987
  params[0] = bool1987;
  Object opresult1989 = callmethod(*var_currentReturnType, "==", 1, params);
// compilenode returning opresult1989
  Object if1986;
  if (istrue(opresult1989)) {
// Begin line 838
  setline(838);
  if (strlit1990 == NULL) {
    strlit1990 = alloc_String("return statement with no surrounding method");
  }
// compilenode returning strlit1990
// compilenode returning module_util
  params[0] = strlit1990;
  Object call1991 = callmethod(module_util, "syntax_error",
    1, params);
// compilenode returning call1991
    if1986 = call1991;
  } else {
  }
// compilenode returning if1986
// Begin line 841
  setline(841);
// Begin line 1017
  setline(1017);
// Begin line 840
  setline(840);
// compilenode returning *var_node
  Object call1992 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call1992
// compilenode returning call1992
  *var_tmp = call1992;
  if (call1992 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 841
  setline(841);
// compilenode returning *var_tmp
// Begin line 842
  setline(842);
// compilenode returning self
  params[0] = *var_tmp;
  Object call1994 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call1994
  *var_tmp2 = call1994;
  if (call1994 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tmp2
// Begin line 843
  setline(843);
// compilenode returning self
  params[0] = *var_tmp2;
  Object call1996 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call1996
  *var_tmp3 = call1996;
  if (call1996 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 846
  setline(846);
// Begin line 843
  setline(843);
// Begin line 1017
  setline(1017);
// Begin line 843
  setline(843);
// compilenode returning *var_tmp3
// compilenode returning *var_currentReturnType
// Begin line 848
  setline(848);
// compilenode returning self
  params[0] = *var_tmp3;
  params[1] = *var_currentReturnType;
  Object call1999 = callmethod(self, "conformsType(1)to",
    2, params);
// compilenode returning call1999
  Object call2000 = callmethod(call1999, "not",
    0, params);
// compilenode returning call2000
// compilenode returning call2000
  Object if1998;
  if (istrue(call2000)) {
// Begin line 846
  setline(846);
// Begin line 844
  setline(844);
  if (strlit2001 == NULL) {
    strlit2001 = alloc_String("returning type ");
  }
// compilenode returning strlit2001
// Begin line 846
  setline(846);
// Begin line 845
  setline(845);
  if (strlit2002 == NULL) {
    strlit2002 = alloc_String("");
  }
// compilenode returning strlit2002
// Begin line 846
  setline(846);
// Begin line 1017
  setline(1017);
// Begin line 845
  setline(845);
// compilenode returning *var_tmp3
  Object call2003 = callmethod(*var_tmp3, "value",
    0, params);
// compilenode returning call2003
// compilenode returning call2003
  params[0] = call2003;
  Object opresult2005 = callmethod(strlit2002, "++", 1, params);
// compilenode returning opresult2005
  if (strlit2006 == NULL) {
    strlit2006 = alloc_String(" from method of return type ");
  }
// compilenode returning strlit2006
  params[0] = strlit2006;
  Object opresult2008 = callmethod(opresult2005, "++", 1, params);
// compilenode returning opresult2008
  params[0] = opresult2008;
  Object opresult2010 = callmethod(strlit2001, "++", 1, params);
// compilenode returning opresult2010
// Begin line 846
  setline(846);
// Begin line 1017
  setline(1017);
// Begin line 846
  setline(846);
// compilenode returning *var_currentReturnType
  Object call2011 = callmethod(*var_currentReturnType, "value",
    0, params);
// compilenode returning call2011
// compilenode returning call2011
  params[0] = call2011;
  Object opresult2013 = callmethod(opresult2010, "++", 1, params);
// compilenode returning opresult2013
// Begin line 844
  setline(844);
// compilenode returning module_util
  params[0] = opresult2013;
  Object call2014 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call2014
    if1998 = call2014;
  } else {
  }
// compilenode returning if1998
// Begin line 849
  setline(849);
// Begin line 851
  setline(851);
// Begin line 848
  setline(848);
// compilenode returning *var_tmp2
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult2017 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult2017
  Object if2015;
  if (istrue(opresult2017)) {
// Begin line 849
  setline(849);
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_tmp2;
  Object call2018 = callmethod(module_ast, "astreturn",
    1, params);
// compilenode returning call2018
  return call2018;
// compilenode returning undefined
    if2015 = undefined;
  } else {
  }
// compilenode returning if2015
    if1981 = if2015;
  } else {
  }
// compilenode returning if1981
// Begin line 857
  setline(857);
// Begin line 860
  setline(860);
// Begin line 1017
  setline(1017);
// Begin line 852
  setline(852);
// compilenode returning *var_node
  Object call2020 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call2020
// compilenode returning call2020
  if (strlit2021 == NULL) {
    strlit2021 = alloc_String("index");
  }
// compilenode returning strlit2021
  params[0] = strlit2021;
  Object opresult2023 = callmethod(call2020, "==", 1, params);
// compilenode returning opresult2023
  Object if2019;
  if (istrue(opresult2023)) {
// Begin line 854
  setline(854);
// Begin line 1017
  setline(1017);
// Begin line 853
  setline(853);
// compilenode returning *var_node
  Object call2024 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2024
// compilenode returning call2024
  *var_tmp = call2024;
  if (call2024 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 854
  setline(854);
// compilenode returning *var_tmp
// Begin line 855
  setline(855);
// compilenode returning self
  params[0] = *var_tmp;
  Object call2026 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2026
  *var_tmp2 = call2026;
  if (call2026 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 855
  setline(855);
// compilenode returning *var_node
  Object call2028 = callmethod(*var_node, "index",
    0, params);
// compilenode returning call2028
// compilenode returning call2028
// Begin line 856
  setline(856);
// compilenode returning self
  params[0] = call2028;
  Object call2029 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2029
  *var_tmp3 = call2029;
  if (call2029 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 857
  setline(857);
// Begin line 859
  setline(859);
// Begin line 856
  setline(856);
// compilenode returning *var_tmp2
// compilenode returning *var_tmp
  params[0] = *var_tmp;
  Object opresult2033 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult2033
// Begin line 859
  setline(859);
// Begin line 856
  setline(856);
// compilenode returning *var_tmp3
// Begin line 859
  setline(859);
// Begin line 1017
  setline(1017);
// Begin line 856
  setline(856);
// compilenode returning *var_node
  Object call2034 = callmethod(*var_node, "index",
    0, params);
// compilenode returning call2034
// compilenode returning call2034
  params[0] = call2034;
  Object opresult2036 = callmethod(*var_tmp3, "/=", 1, params);
// compilenode returning opresult2036
  params[0] = opresult2036;
  Object opresult2038 = callmethod(opresult2033, "|", 1, params);
// compilenode returning opresult2038
  Object if2031;
  if (istrue(opresult2038)) {
// Begin line 857
  setline(857);
// compilenode returning *var_tmp2
// compilenode returning *var_tmp3
// compilenode returning module_ast
  params[0] = *var_tmp2;
  params[1] = *var_tmp3;
  Object call2039 = callmethod(module_ast, "astindex",
    2, params);
// compilenode returning call2039
  return call2039;
// compilenode returning undefined
    if2031 = undefined;
  } else {
  }
// compilenode returning if2031
    if2019 = if2031;
  } else {
  }
// compilenode returning if2019
// Begin line 864
  setline(864);
// Begin line 867
  setline(867);
// Begin line 1017
  setline(1017);
// Begin line 860
  setline(860);
// compilenode returning *var_node
  Object call2041 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call2041
// compilenode returning call2041
  if (strlit2042 == NULL) {
    strlit2042 = alloc_String("op");
  }
// compilenode returning strlit2042
  params[0] = strlit2042;
  Object opresult2044 = callmethod(call2041, "==", 1, params);
// compilenode returning opresult2044
  Object if2040;
  if (istrue(opresult2044)) {
// Begin line 861
  setline(861);
// Begin line 1017
  setline(1017);
// Begin line 861
  setline(861);
// compilenode returning *var_node
  Object call2045 = callmethod(*var_node, "left",
    0, params);
// compilenode returning call2045
// compilenode returning call2045
// Begin line 862
  setline(862);
// compilenode returning self
  params[0] = call2045;
  Object call2046 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2046
  *var_tmp = call2046;
  if (call2046 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 862
  setline(862);
// compilenode returning *var_node
  Object call2048 = callmethod(*var_node, "right",
    0, params);
// compilenode returning call2048
// compilenode returning call2048
// Begin line 863
  setline(863);
// compilenode returning self
  params[0] = call2048;
  Object call2049 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2049
  *var_tmp2 = call2049;
  if (call2049 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 864
  setline(864);
// Begin line 866
  setline(866);
// Begin line 863
  setline(863);
// compilenode returning *var_tmp
// Begin line 866
  setline(866);
// Begin line 1017
  setline(1017);
// Begin line 863
  setline(863);
// compilenode returning *var_node
  Object call2052 = callmethod(*var_node, "left",
    0, params);
// compilenode returning call2052
// compilenode returning call2052
  params[0] = call2052;
  Object opresult2054 = callmethod(*var_tmp, "/=", 1, params);
// compilenode returning opresult2054
// Begin line 866
  setline(866);
// Begin line 863
  setline(863);
// compilenode returning *var_tmp2
// Begin line 866
  setline(866);
// Begin line 1017
  setline(1017);
// Begin line 863
  setline(863);
// compilenode returning *var_node
  Object call2055 = callmethod(*var_node, "right",
    0, params);
// compilenode returning call2055
// compilenode returning call2055
  params[0] = call2055;
  Object opresult2057 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult2057
  params[0] = opresult2057;
  Object opresult2059 = callmethod(opresult2054, "|", 1, params);
// compilenode returning opresult2059
  Object if2051;
  if (istrue(opresult2059)) {
// Begin line 864
  setline(864);
// Begin line 1017
  setline(1017);
// Begin line 864
  setline(864);
// compilenode returning *var_node
  Object call2060 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2060
// compilenode returning call2060
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = call2060;
  params[1] = *var_tmp;
  params[2] = *var_tmp2;
  Object call2061 = callmethod(module_ast, "astop",
    3, params);
// compilenode returning call2061
  return call2061;
// compilenode returning undefined
    if2051 = undefined;
  } else {
  }
// compilenode returning if2051
    if2040 = if2051;
  } else {
  }
// compilenode returning if2040
// Begin line 873
  setline(873);
// Begin line 876
  setline(876);
// Begin line 1017
  setline(1017);
// Begin line 867
  setline(867);
// compilenode returning *var_node
  Object call2063 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call2063
// compilenode returning call2063
  if (strlit2064 == NULL) {
    strlit2064 = alloc_String("if");
  }
// compilenode returning strlit2064
  params[0] = strlit2064;
  Object opresult2066 = callmethod(call2063, "==", 1, params);
// compilenode returning opresult2066
  Object if2062;
  if (istrue(opresult2066)) {
// Begin line 868
  setline(868);
// Begin line 1017
  setline(1017);
// Begin line 868
  setline(868);
// compilenode returning *var_node
  Object call2067 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2067
// compilenode returning call2067
// Begin line 869
  setline(869);
// compilenode returning self
  params[0] = call2067;
  Object call2068 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2068
  *var_tmp = call2068;
  if (call2068 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 869
  setline(869);
// compilenode returning *var_node
  Object call2070 = callmethod(*var_node, "thenblock",
    0, params);
// compilenode returning call2070
// compilenode returning call2070
// Begin line 870
  setline(870);
// compilenode returning self
  params[0] = call2070;
  Object call2071 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call2071
  *var_tmp2 = call2071;
  if (call2071 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 870
  setline(870);
// compilenode returning *var_node
  Object call2073 = callmethod(*var_node, "elseblock",
    0, params);
// compilenode returning call2073
// compilenode returning call2073
// Begin line 871
  setline(871);
// compilenode returning self
  params[0] = call2073;
  Object call2074 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call2074
  *var_tmp3 = call2074;
  if (call2074 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 873
  setline(873);
// Begin line 875
  setline(875);
// Begin line 871
  setline(871);
// compilenode returning *var_tmp
// Begin line 875
  setline(875);
// Begin line 1017
  setline(1017);
// Begin line 871
  setline(871);
// compilenode returning *var_node
  Object call2077 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2077
// compilenode returning call2077
  params[0] = call2077;
  Object opresult2079 = callmethod(*var_tmp, "/=", 1, params);
// compilenode returning opresult2079
// Begin line 875
  setline(875);
// Begin line 871
  setline(871);
// compilenode returning *var_tmp2
// Begin line 875
  setline(875);
// Begin line 1017
  setline(1017);
// Begin line 871
  setline(871);
// compilenode returning *var_node
  Object call2080 = callmethod(*var_node, "thenblock",
    0, params);
// compilenode returning call2080
// compilenode returning call2080
  params[0] = call2080;
  Object opresult2082 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult2082
  params[0] = opresult2082;
  Object opresult2084 = callmethod(opresult2079, "|", 1, params);
// compilenode returning opresult2084
// Begin line 875
  setline(875);
// Begin line 872
  setline(872);
// compilenode returning *var_tmp3
// Begin line 875
  setline(875);
// Begin line 1017
  setline(1017);
// Begin line 872
  setline(872);
// compilenode returning *var_node
  Object call2085 = callmethod(*var_node, "elseblock",
    0, params);
// compilenode returning call2085
// compilenode returning call2085
  params[0] = call2085;
  Object opresult2087 = callmethod(*var_tmp3, "/=", 1, params);
// compilenode returning opresult2087
  params[0] = opresult2087;
  Object opresult2089 = callmethod(opresult2084, "|", 1, params);
// compilenode returning opresult2089
  Object if2076;
  if (istrue(opresult2089)) {
// Begin line 873
  setline(873);
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning *var_tmp3
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = *var_tmp2;
  params[2] = *var_tmp3;
  Object call2090 = callmethod(module_ast, "astif",
    3, params);
// compilenode returning call2090
  return call2090;
// compilenode returning undefined
    if2076 = undefined;
  } else {
  }
// compilenode returning if2076
    if2062 = if2076;
  } else {
  }
// compilenode returning if2062
// Begin line 880
  setline(880);
// Begin line 883
  setline(883);
// Begin line 1017
  setline(1017);
// Begin line 876
  setline(876);
// compilenode returning *var_node
  Object call2092 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call2092
// compilenode returning call2092
  if (strlit2093 == NULL) {
    strlit2093 = alloc_String("while");
  }
// compilenode returning strlit2093
  params[0] = strlit2093;
  Object opresult2095 = callmethod(call2092, "==", 1, params);
// compilenode returning opresult2095
  Object if2091;
  if (istrue(opresult2095)) {
// Begin line 877
  setline(877);
// Begin line 1017
  setline(1017);
// Begin line 877
  setline(877);
// compilenode returning *var_node
  Object call2096 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2096
// compilenode returning call2096
// Begin line 878
  setline(878);
// compilenode returning self
  params[0] = call2096;
  Object call2097 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2097
  *var_tmp = call2097;
  if (call2097 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 878
  setline(878);
// compilenode returning *var_node
  Object call2099 = callmethod(*var_node, "body",
    0, params);
// compilenode returning call2099
// compilenode returning call2099
// Begin line 879
  setline(879);
// compilenode returning self
  params[0] = call2099;
  Object call2100 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call2100
  *var_tmp2 = call2100;
  if (call2100 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 880
  setline(880);
// Begin line 882
  setline(882);
// Begin line 879
  setline(879);
// compilenode returning *var_tmp
// Begin line 882
  setline(882);
// Begin line 1017
  setline(1017);
// Begin line 879
  setline(879);
// compilenode returning *var_node
  Object call2103 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2103
// compilenode returning call2103
  params[0] = call2103;
  Object opresult2105 = callmethod(*var_tmp, "/=", 1, params);
// compilenode returning opresult2105
// Begin line 882
  setline(882);
// Begin line 879
  setline(879);
// compilenode returning *var_tmp2
// Begin line 882
  setline(882);
// Begin line 1017
  setline(1017);
// Begin line 879
  setline(879);
// compilenode returning *var_node
  Object call2106 = callmethod(*var_node, "body",
    0, params);
// compilenode returning call2106
// compilenode returning call2106
  params[0] = call2106;
  Object opresult2108 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult2108
  params[0] = opresult2108;
  Object opresult2110 = callmethod(opresult2105, "|", 1, params);
// compilenode returning opresult2110
  Object if2102;
  if (istrue(opresult2110)) {
// Begin line 880
  setline(880);
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = *var_tmp2;
  Object call2111 = callmethod(module_ast, "astwhile",
    2, params);
// compilenode returning call2111
  return call2111;
// compilenode returning undefined
    if2102 = undefined;
  } else {
  }
// compilenode returning if2102
    if2091 = if2102;
  } else {
  }
// compilenode returning if2091
// Begin line 887
  setline(887);
// Begin line 890
  setline(890);
// Begin line 1017
  setline(1017);
// Begin line 883
  setline(883);
// compilenode returning *var_node
  Object call2113 = callmethod(*var_node, "kind",
    0, params);
// compilenode returning call2113
// compilenode returning call2113
  if (strlit2114 == NULL) {
    strlit2114 = alloc_String("for");
  }
// compilenode returning strlit2114
  params[0] = strlit2114;
  Object opresult2116 = callmethod(call2113, "==", 1, params);
// compilenode returning opresult2116
  Object if2112;
  if (istrue(opresult2116)) {
// Begin line 884
  setline(884);
// Begin line 1017
  setline(1017);
// Begin line 884
  setline(884);
// compilenode returning *var_node
  Object call2117 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2117
// compilenode returning call2117
// Begin line 885
  setline(885);
// compilenode returning self
  params[0] = call2117;
  Object call2118 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2118
  *var_tmp = call2118;
  if (call2118 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 885
  setline(885);
// compilenode returning *var_node
  Object call2120 = callmethod(*var_node, "body",
    0, params);
// compilenode returning call2120
// compilenode returning call2120
// Begin line 886
  setline(886);
// compilenode returning self
  params[0] = call2120;
  Object call2121 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2121
  *var_tmp2 = call2121;
  if (call2121 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 887
  setline(887);
// Begin line 889
  setline(889);
// Begin line 886
  setline(886);
// compilenode returning *var_tmp
// Begin line 889
  setline(889);
// Begin line 1017
  setline(1017);
// Begin line 886
  setline(886);
// compilenode returning *var_node
  Object call2124 = callmethod(*var_node, "value",
    0, params);
// compilenode returning call2124
// compilenode returning call2124
  params[0] = call2124;
  Object opresult2126 = callmethod(*var_tmp, "/=", 1, params);
// compilenode returning opresult2126
// Begin line 889
  setline(889);
// Begin line 886
  setline(886);
// compilenode returning *var_tmp2
// Begin line 889
  setline(889);
// Begin line 1017
  setline(1017);
// Begin line 886
  setline(886);
// compilenode returning *var_node
  Object call2127 = callmethod(*var_node, "body",
    0, params);
// compilenode returning call2127
// compilenode returning call2127
  params[0] = call2127;
  Object opresult2129 = callmethod(*var_tmp2, "/=", 1, params);
// compilenode returning opresult2129
  params[0] = opresult2129;
  Object opresult2131 = callmethod(opresult2126, "|", 1, params);
// compilenode returning opresult2131
  Object if2123;
  if (istrue(opresult2131)) {
// Begin line 887
  setline(887);
// compilenode returning *var_tmp
// compilenode returning *var_tmp2
// compilenode returning module_ast
  params[0] = *var_tmp;
  params[1] = *var_tmp2;
  Object call2132 = callmethod(module_ast, "astfor",
    2, params);
// compilenode returning call2132
  return call2132;
// compilenode returning undefined
    if2123 = undefined;
  } else {
  }
// compilenode returning if2123
    if2112 = if2123;
  } else {
  }
// compilenode returning if2112
// Begin line 890
  setline(890);
// compilenode returning *var_node
  return *var_node;
}
Object meth_typechecker_apply2149(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[2];
  Object *var_Binding = closure[0];
  Object *var_tpb = closure[1];
  Object self = *closure[2];
// Begin line 907
  setline(907);
// Begin line 909
  setline(909);
// Begin line 1017
  setline(1017);
// Begin line 904
  setline(904);
// compilenode returning *var_e
  Object call2151 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2151
// compilenode returning call2151
  if (strlit2152 == NULL) {
    strlit2152 = alloc_String("type");
  }
// compilenode returning strlit2152
  params[0] = strlit2152;
  Object opresult2154 = callmethod(call2151, "==", 1, params);
// compilenode returning opresult2154
  Object if2150;
  if (istrue(opresult2154)) {
// Begin line 905
  setline(905);
  if (strlit2155 == NULL) {
    strlit2155 = alloc_String("type");
  }
// compilenode returning strlit2155
// compilenode returning *var_Binding
  params[0] = strlit2155;
  Object call2156 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2156
  *var_tpb = call2156;
  if (call2156 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 907
  setline(907);
// Begin line 1017
  setline(1017);
// Begin line 906
  setline(906);
// compilenode returning *var_e
// compilenode returning *var_tpb
  params[0] = *var_e;
  Object call2158 = callmethod(*var_tpb, "value:=",
    1, params);
// compilenode returning call2158
// compilenode returning nothing
// Begin line 907
  setline(907);
// Begin line 1017
  setline(1017);
// Begin line 907
  setline(907);
// compilenode returning *var_e
  Object call2159 = callmethod(*var_e, "value",
    0, params);
// compilenode returning call2159
// compilenode returning call2159
// compilenode returning *var_tpb
// Begin line 908
  setline(908);
// compilenode returning self
  params[0] = call2159;
  params[1] = *var_tpb;
  Object call2160 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2160
    if2150 = call2160;
  } else {
  }
// compilenode returning if2150
  return if2150;
}
Object meth_typechecker_apply2166(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object *var_tpb = closure[0];
  Object self = *closure[1];
// Begin line 914
  setline(914);
// Begin line 916
  setline(916);
// Begin line 1017
  setline(1017);
// Begin line 911
  setline(911);
// compilenode returning *var_e
  Object call2168 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2168
// compilenode returning call2168
  if (strlit2169 == NULL) {
    strlit2169 = alloc_String("type");
  }
// compilenode returning strlit2169
  params[0] = strlit2169;
  Object opresult2171 = callmethod(call2168, "==", 1, params);
// compilenode returning opresult2171
  Object if2167;
  if (istrue(opresult2171)) {
// Begin line 912
  setline(912);
// Begin line 1017
  setline(1017);
// Begin line 912
  setline(912);
// compilenode returning *var_e
  Object call2172 = callmethod(*var_e, "value",
    0, params);
// compilenode returning call2172
// compilenode returning call2172
// Begin line 913
  setline(913);
// compilenode returning self
  params[0] = call2172;
  Object call2173 = callmethod(self, "findName",
    1, params);
// compilenode returning call2173
  *var_tpb = call2173;
  if (call2173 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1017
  setline(1017);
// Begin line 913
  setline(913);
// compilenode returning *var_e
// Begin line 914
  setline(914);
// compilenode returning self
  params[0] = *var_e;
  Object call2175 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2175
// Begin line 913
  setline(913);
// compilenode returning *var_tpb
  params[0] = call2175;
  Object call2176 = callmethod(*var_tpb, "value:=",
    1, params);
// compilenode returning call2176
// compilenode returning nothing
// Begin line 914
  setline(914);
// Begin line 1017
  setline(1017);
// Begin line 914
  setline(914);
// compilenode returning *var_tpb
  Object call2177 = callmethod(*var_tpb, "value",
    0, params);
// compilenode returning call2177
// compilenode returning call2177
// compilenode returning module_subtype
  params[0] = call2177;
  Object call2178 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2178
    if2167 = call2178;
  } else {
  }
// compilenode returning if2167
  return if2167;
}
Object meth_typechecker_apply2315(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_gp = alloc_var();
  *var_gp = args[0];
  Object params[2];
  Object *var_Binding = closure[0];
  Object self = *closure[1];
  Object *var_nomnm = alloc_var();
  *var_nomnm = undefined;
  Object *var_nom = alloc_var();
  *var_nom = undefined;
  Object *var_gtpb = alloc_var();
  *var_gtpb = undefined;
// Begin line 950
  setline(950);
// Begin line 1017
  setline(1017);
// Begin line 949
  setline(949);
// compilenode returning *var_gp
  Object call2316 = callmethod(*var_gp, "value",
    0, params);
// compilenode returning call2316
// compilenode returning call2316
  *var_nomnm = call2316;
  if (call2316 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 950
  setline(950);
// compilenode returning *var_nomnm
  Object array2317 = alloc_List();
// compilenode returning array2317
// compilenode returning module_ast
  params[0] = *var_nomnm;
  params[1] = array2317;
  Object call2318 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call2318
  *var_nom = call2318;
  if (call2318 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 952
  setline(952);
// Begin line 1017
  setline(1017);
// Begin line 951
  setline(951);
  Object bool2319 = alloc_Boolean(1);
// compilenode returning bool2319
// compilenode returning *var_nom
  params[0] = bool2319;
  Object call2320 = callmethod(*var_nom, "nominal:=",
    1, params);
// compilenode returning call2320
// compilenode returning nothing
// Begin line 952
  setline(952);
// compilenode returning *var_nom
// compilenode returning module_subtype
  params[0] = *var_nom;
  Object call2321 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2321
// Begin line 953
  setline(953);
  if (strlit2322 == NULL) {
    strlit2322 = alloc_String("type");
  }
// compilenode returning strlit2322
// compilenode returning *var_Binding
  params[0] = strlit2322;
  Object call2323 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2323
  *var_gtpb = call2323;
  if (call2323 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 955
  setline(955);
// Begin line 1017
  setline(1017);
// Begin line 954
  setline(954);
// compilenode returning *var_nom
// compilenode returning *var_gtpb
  params[0] = *var_nom;
  Object call2324 = callmethod(*var_gtpb, "value:=",
    1, params);
// compilenode returning call2324
// compilenode returning nothing
// Begin line 955
  setline(955);
// Begin line 1017
  setline(1017);
// Begin line 955
  setline(955);
// compilenode returning *var_gp
  Object call2325 = callmethod(*var_gp, "value",
    0, params);
// compilenode returning call2325
// compilenode returning call2325
// compilenode returning *var_gtpb
// Begin line 956
  setline(956);
// compilenode returning self
  params[0] = call2325;
  params[1] = *var_gtpb;
  Object call2326 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2326
  return call2326;
}
Object meth_typechecker_apply2184(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[3];
  Object *var_isobj = closure[0];
  Object *var_Binding = closure[1];
  Object *var_tpb = closure[2];
  Object *var_tmp = closure[3];
  Object *var_DynamicType = closure[4];
  Object self = *closure[5];
// Begin line 974
  setline(974);
// Begin line 976
  setline(976);
// Begin line 918
  setline(918);
// compilenode returning *var_isobj
// Begin line 976
  setline(976);
// Begin line 1017
  setline(1017);
// Begin line 918
  setline(918);
// compilenode returning *var_e
  Object call2186 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2186
// compilenode returning call2186
  if (strlit2187 == NULL) {
    strlit2187 = alloc_String("vardec");
  }
// compilenode returning strlit2187
  params[0] = strlit2187;
  Object opresult2189 = callmethod(call2186, "==", 1, params);
// compilenode returning opresult2189
// Begin line 976
  setline(976);
// Begin line 1017
  setline(1017);
// Begin line 918
  setline(918);
// compilenode returning *var_e
  Object call2190 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2190
// compilenode returning call2190
  if (strlit2191 == NULL) {
    strlit2191 = alloc_String("defdec");
  }
// compilenode returning strlit2191
  params[0] = strlit2191;
  Object opresult2193 = callmethod(call2190, "==", 1, params);
// compilenode returning opresult2193
  params[0] = opresult2193;
  Object opresult2195 = callmethod(opresult2189, "|", 1, params);
// compilenode returning opresult2195
  params[0] = opresult2195;
  Object opresult2197 = callmethod(*var_isobj, "&", 1, params);
// compilenode returning opresult2197
  Object if2185;
  if (istrue(opresult2197)) {
// Begin line 919
  setline(919);
// Begin line 1017
  setline(1017);
// Begin line 919
  setline(919);
// Begin line 1017
  setline(1017);
// Begin line 919
  setline(919);
// compilenode returning *var_e
  Object call2198 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2198
// compilenode returning call2198
  Object call2199 = callmethod(call2198, "value",
    0, params);
// compilenode returning call2199
// compilenode returning call2199
  if (strlit2200 == NULL) {
    strlit2200 = alloc_String("method");
  }
// compilenode returning strlit2200
// compilenode returning *var_Binding
  params[0] = strlit2200;
  Object call2201 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2201
// Begin line 920
  setline(920);
// compilenode returning self
  params[0] = call2199;
  params[1] = call2201;
  Object call2202 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2202
    if2185 = call2202;
  } else {
// Begin line 974
  setline(974);
// Begin line 928
  setline(928);
// Begin line 1017
  setline(1017);
// Begin line 920
  setline(920);
// compilenode returning *var_e
  Object call2204 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2204
// compilenode returning call2204
  if (strlit2205 == NULL) {
    strlit2205 = alloc_String("vardec");
  }
// compilenode returning strlit2205
  params[0] = strlit2205;
  Object opresult2207 = callmethod(call2204, "==", 1, params);
// compilenode returning opresult2207
  Object if2203;
  if (istrue(opresult2207)) {
// Begin line 921
  setline(921);
// Begin line 1017
  setline(1017);
// Begin line 921
  setline(921);
// compilenode returning *var_e
  Object call2208 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call2208
// compilenode returning call2208
// Begin line 922
  setline(922);
// compilenode returning self
  params[0] = call2208;
  Object call2209 = callmethod(self, "findType",
    1, params);
// compilenode returning call2209
  *var_tpb = call2209;
  if (call2209 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 923
  setline(923);
// Begin line 925
  setline(925);
// Begin line 1017
  setline(1017);
// Begin line 922
  setline(922);
// compilenode returning *var_tpb
  Object call2212 = callmethod(*var_tpb, "kind",
    0, params);
// compilenode returning call2212
// compilenode returning call2212
  if (strlit2213 == NULL) {
    strlit2213 = alloc_String("type");
  }
// compilenode returning strlit2213
  params[0] = strlit2213;
  Object opresult2215 = callmethod(call2212, "/=", 1, params);
// compilenode returning opresult2215
  Object if2211;
  if (istrue(opresult2215)) {
// Begin line 923
  setline(923);
  if (strlit2216 == NULL) {
    strlit2216 = alloc_String("declared type of ");
  }
// compilenode returning strlit2216
// Begin line 1017
  setline(1017);
// Begin line 923
  setline(923);
// Begin line 1017
  setline(1017);
// Begin line 923
  setline(923);
// compilenode returning *var_e
  Object call2217 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2217
// compilenode returning call2217
  Object call2218 = callmethod(call2217, "value",
    0, params);
// compilenode returning call2218
// compilenode returning call2218
  params[0] = call2218;
  Object opresult2220 = callmethod(strlit2216, "++", 1, params);
// compilenode returning opresult2220
  if (strlit2221 == NULL) {
    strlit2221 = alloc_String(", '");
  }
// compilenode returning strlit2221
  params[0] = strlit2221;
  Object opresult2223 = callmethod(opresult2220, "++", 1, params);
// compilenode returning opresult2223
// Begin line 1017
  setline(1017);
// Begin line 923
  setline(923);
// Begin line 1017
  setline(1017);
// Begin line 923
  setline(923);
// compilenode returning *var_e
  Object call2224 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call2224
// compilenode returning call2224
  Object call2225 = callmethod(call2224, "value",
    0, params);
// compilenode returning call2225
// compilenode returning call2225
  params[0] = call2225;
  Object opresult2227 = callmethod(opresult2223, "++", 1, params);
// compilenode returning opresult2227
  if (strlit2228 == NULL) {
    strlit2228 = alloc_String("', not a type");
  }
// compilenode returning strlit2228
  params[0] = strlit2228;
  Object opresult2230 = callmethod(opresult2227, "++", 1, params);
// compilenode returning opresult2230
// compilenode returning module_util
  params[0] = opresult2230;
  Object call2231 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call2231
    if2211 = call2231;
  } else {
  }
// compilenode returning if2211
// Begin line 925
  setline(925);
  if (strlit2232 == NULL) {
    strlit2232 = alloc_String("var");
  }
// compilenode returning strlit2232
// compilenode returning *var_Binding
  params[0] = strlit2232;
  Object call2233 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2233
  *var_tmp = call2233;
  if (call2233 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 927
  setline(927);
// Begin line 1017
  setline(1017);
// Begin line 926
  setline(926);
// compilenode returning *var_tpb
// compilenode returning *var_tmp
  params[0] = *var_tpb;
  Object call2235 = callmethod(*var_tmp, "dtype:=",
    1, params);
// compilenode returning call2235
// compilenode returning nothing
// Begin line 927
  setline(927);
// Begin line 1017
  setline(1017);
// Begin line 927
  setline(927);
// Begin line 1017
  setline(1017);
// Begin line 927
  setline(927);
// compilenode returning *var_e
  Object call2236 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2236
// compilenode returning call2236
  Object call2237 = callmethod(call2236, "value",
    0, params);
// compilenode returning call2237
// compilenode returning call2237
// compilenode returning *var_tmp
// Begin line 928
  setline(928);
// compilenode returning self
  params[0] = call2237;
  params[1] = *var_tmp;
  Object call2238 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2238
    if2203 = call2238;
  } else {
// Begin line 974
  setline(974);
// Begin line 936
  setline(936);
// Begin line 1017
  setline(1017);
// Begin line 928
  setline(928);
// compilenode returning *var_e
  Object call2240 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2240
// compilenode returning call2240
  if (strlit2241 == NULL) {
    strlit2241 = alloc_String("defdec");
  }
// compilenode returning strlit2241
  params[0] = strlit2241;
  Object opresult2243 = callmethod(call2240, "==", 1, params);
// compilenode returning opresult2243
  Object if2239;
  if (istrue(opresult2243)) {
// Begin line 929
  setline(929);
// Begin line 1017
  setline(1017);
// Begin line 929
  setline(929);
// compilenode returning *var_e
  Object call2244 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call2244
// compilenode returning call2244
// Begin line 930
  setline(930);
// compilenode returning self
  params[0] = call2244;
  Object call2245 = callmethod(self, "findType",
    1, params);
// compilenode returning call2245
  *var_tpb = call2245;
  if (call2245 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 931
  setline(931);
// Begin line 933
  setline(933);
// Begin line 1017
  setline(1017);
// Begin line 930
  setline(930);
// compilenode returning *var_tpb
  Object call2248 = callmethod(*var_tpb, "kind",
    0, params);
// compilenode returning call2248
// compilenode returning call2248
  if (strlit2249 == NULL) {
    strlit2249 = alloc_String("type");
  }
// compilenode returning strlit2249
  params[0] = strlit2249;
  Object opresult2251 = callmethod(call2248, "/=", 1, params);
// compilenode returning opresult2251
  Object if2247;
  if (istrue(opresult2251)) {
// Begin line 931
  setline(931);
  if (strlit2252 == NULL) {
    strlit2252 = alloc_String("declared type of ");
  }
// compilenode returning strlit2252
// Begin line 1017
  setline(1017);
// Begin line 931
  setline(931);
// Begin line 1017
  setline(1017);
// Begin line 931
  setline(931);
// compilenode returning *var_e
  Object call2253 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2253
// compilenode returning call2253
  Object call2254 = callmethod(call2253, "value",
    0, params);
// compilenode returning call2254
// compilenode returning call2254
  params[0] = call2254;
  Object opresult2256 = callmethod(strlit2252, "++", 1, params);
// compilenode returning opresult2256
  if (strlit2257 == NULL) {
    strlit2257 = alloc_String(", '");
  }
// compilenode returning strlit2257
  params[0] = strlit2257;
  Object opresult2259 = callmethod(opresult2256, "++", 1, params);
// compilenode returning opresult2259
// Begin line 1017
  setline(1017);
// Begin line 931
  setline(931);
// Begin line 1017
  setline(1017);
// Begin line 931
  setline(931);
// compilenode returning *var_e
  Object call2260 = callmethod(*var_e, "dtype",
    0, params);
// compilenode returning call2260
// compilenode returning call2260
  Object call2261 = callmethod(call2260, "value",
    0, params);
// compilenode returning call2261
// compilenode returning call2261
  params[0] = call2261;
  Object opresult2263 = callmethod(opresult2259, "++", 1, params);
// compilenode returning opresult2263
  if (strlit2264 == NULL) {
    strlit2264 = alloc_String("', not a type");
  }
// compilenode returning strlit2264
  params[0] = strlit2264;
  Object opresult2266 = callmethod(opresult2263, "++", 1, params);
// compilenode returning opresult2266
// compilenode returning module_util
  params[0] = opresult2266;
  Object call2267 = callmethod(module_util, "type_error",
    1, params);
// compilenode returning call2267
    if2247 = call2267;
  } else {
  }
// compilenode returning if2247
// Begin line 933
  setline(933);
  if (strlit2268 == NULL) {
    strlit2268 = alloc_String("def");
  }
// compilenode returning strlit2268
// compilenode returning *var_Binding
  params[0] = strlit2268;
  Object call2269 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2269
  *var_tmp = call2269;
  if (call2269 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 935
  setline(935);
// Begin line 1017
  setline(1017);
// Begin line 934
  setline(934);
// compilenode returning *var_tpb
// compilenode returning *var_tmp
  params[0] = *var_tpb;
  Object call2271 = callmethod(*var_tmp, "dtype:=",
    1, params);
// compilenode returning call2271
// compilenode returning nothing
// Begin line 935
  setline(935);
// Begin line 1017
  setline(1017);
// Begin line 935
  setline(935);
// Begin line 1017
  setline(1017);
// Begin line 935
  setline(935);
// compilenode returning *var_e
  Object call2272 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2272
// compilenode returning call2272
  Object call2273 = callmethod(call2272, "value",
    0, params);
// compilenode returning call2273
// compilenode returning call2273
// compilenode returning *var_tmp
// Begin line 936
  setline(936);
// compilenode returning self
  params[0] = call2273;
  params[1] = *var_tmp;
  Object call2274 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2274
    if2239 = call2274;
  } else {
// Begin line 974
  setline(974);
// Begin line 938
  setline(938);
// Begin line 1017
  setline(1017);
// Begin line 936
  setline(936);
// compilenode returning *var_e
  Object call2276 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2276
// compilenode returning call2276
  if (strlit2277 == NULL) {
    strlit2277 = alloc_String("method");
  }
// compilenode returning strlit2277
  params[0] = strlit2277;
  Object opresult2279 = callmethod(call2276, "==", 1, params);
// compilenode returning opresult2279
  Object if2275;
  if (istrue(opresult2279)) {
// Begin line 937
  setline(937);
// Begin line 1017
  setline(1017);
// Begin line 937
  setline(937);
// Begin line 1017
  setline(1017);
// Begin line 937
  setline(937);
// compilenode returning *var_e
  Object call2280 = callmethod(*var_e, "value",
    0, params);
// compilenode returning call2280
// compilenode returning call2280
  Object call2281 = callmethod(call2280, "value",
    0, params);
// compilenode returning call2281
// compilenode returning call2281
  if (strlit2282 == NULL) {
    strlit2282 = alloc_String("method");
  }
// compilenode returning strlit2282
// compilenode returning *var_Binding
  params[0] = strlit2282;
  Object call2283 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2283
// Begin line 938
  setline(938);
// compilenode returning self
  params[0] = call2281;
  params[1] = call2283;
  Object call2284 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2284
    if2275 = call2284;
  } else {
// Begin line 974
  setline(974);
// Begin line 971
  setline(971);
// Begin line 1017
  setline(1017);
// Begin line 938
  setline(938);
// compilenode returning *var_e
  Object call2286 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2286
// compilenode returning call2286
  if (strlit2287 == NULL) {
    strlit2287 = alloc_String("class");
  }
// compilenode returning strlit2287
  params[0] = strlit2287;
  Object opresult2289 = callmethod(call2286, "==", 1, params);
// compilenode returning opresult2289
  Object if2285;
  if (istrue(opresult2289)) {
  Object *var_className = alloc_var();
  *var_className = undefined;
  Object *var_classGenerics = alloc_var();
  *var_classGenerics = undefined;
  Object *var_classInstanceType_39_ = alloc_var();
  *var_classInstanceType_39_ = undefined;
  Object *var_classInstanceType = alloc_var();
  *var_classInstanceType = undefined;
  Object *var_classItselfType = alloc_var();
  *var_classItselfType = undefined;
// Begin line 939
  setline(939);
  if (strlit2290 == NULL) {
    strlit2290 = alloc_String("def");
  }
// compilenode returning strlit2290
// compilenode returning *var_Binding
  params[0] = strlit2290;
  Object call2291 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2291
  *var_tmp = call2291;
  if (call2291 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 941
  setline(941);
  var_className = alloc_var();
  *var_className = undefined;
// compilenode returning nothing
// Begin line 942
  setline(942);
  Object array2293 = alloc_List();
// compilenode returning array2293
  var_classGenerics = alloc_var();
  *var_classGenerics = array2293;
  if (array2293 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning self
  Object call2294 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call2294
// Begin line 955
  setline(955);
// Begin line 958
  setline(958);
// Begin line 1017
  setline(1017);
// Begin line 958
  setline(958);
// Begin line 1017
  setline(1017);
// Begin line 943
  setline(943);
// compilenode returning *var_e
  Object call2296 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2296
// compilenode returning call2296
  Object call2297 = callmethod(call2296, "kind",
    0, params);
// compilenode returning call2297
// compilenode returning call2297
  if (strlit2298 == NULL) {
    strlit2298 = alloc_String("identifier");
  }
// compilenode returning strlit2298
  params[0] = strlit2298;
  Object opresult2300 = callmethod(call2297, "==", 1, params);
// compilenode returning opresult2300
  Object if2295;
  if (istrue(opresult2300)) {
// Begin line 945
  setline(945);
// Begin line 1017
  setline(1017);
// Begin line 945
  setline(945);
// Begin line 1017
  setline(1017);
// Begin line 944
  setline(944);
// compilenode returning *var_e
  Object call2301 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2301
// compilenode returning call2301
  Object call2302 = callmethod(call2301, "value",
    0, params);
// compilenode returning call2302
// compilenode returning call2302
  *var_className = call2302;
  if (call2302 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2295 = nothing;
  } else {
// Begin line 947
  setline(947);
// Begin line 1017
  setline(1017);
// Begin line 947
  setline(947);
// Begin line 1017
  setline(1017);
// Begin line 947
  setline(947);
// Begin line 1017
  setline(1017);
// Begin line 946
  setline(946);
// compilenode returning *var_e
  Object call2304 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2304
// compilenode returning call2304
  Object call2305 = callmethod(call2304, "value",
    0, params);
// compilenode returning call2305
// compilenode returning call2305
  Object call2306 = callmethod(call2305, "value",
    0, params);
// compilenode returning call2306
// compilenode returning call2306
  *var_className = call2306;
  if (call2306 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 948
  setline(948);
// Begin line 1017
  setline(1017);
// Begin line 948
  setline(948);
// Begin line 1017
  setline(1017);
// Begin line 947
  setline(947);
// compilenode returning *var_e
  Object call2308 = callmethod(*var_e, "name",
    0, params);
// compilenode returning call2308
// compilenode returning call2308
  Object call2309 = callmethod(call2308, "params",
    0, params);
// compilenode returning call2309
// compilenode returning call2309
  *var_classGenerics = call2309;
  if (call2309 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 955
  setline(955);
// Begin line 948
  setline(948);
// compilenode returning *var_classGenerics
// Begin line 955
  setline(955);
// Begin line 1017
  setline(1017);
  Object obj2313 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2313, self, 0);
  addmethod2(obj2313, "outer", &reader_typechecker_outer_2314);
  adddatum2(obj2313, self, 0);
  block_savedest(obj2313);
  Object **closure2315 = createclosure(2);
  addtoclosure(closure2315, var_Binding);
  Object *selfpp2327 = alloc_var();
  *selfpp2327 = self;
  addtoclosure(closure2315, selfpp2327);
  struct UserObject *uo2315 = (struct UserObject*)obj2313;
  uo2315->data[1] = (Object)closure2315;
  addmethod2(obj2313, "apply", &meth_typechecker_apply2315);
  set_type(obj2313, 0);
// compilenode returning obj2313
  setclassname(obj2313, "Block<typechecker:2312>");
// compilenode returning obj2313
  params[0] = *var_classGenerics;
  Object iter2311 = callmethod(*var_classGenerics, "iter", 1, params);
  while(1) {
    Object cond2311 = callmethod(iter2311, "havemore", 0, NULL);
    if (!istrue(cond2311)) break;
    params[0] = callmethod(iter2311, "next", 0, NULL);
    callmethod(obj2313, "apply", 1, params);
  }
// compilenode returning *var_classGenerics
    if2295 = *var_classGenerics;
  }
// compilenode returning if2295
// Begin line 959
  setline(959);
// Begin line 958
  setline(958);
// Begin line 1017
  setline(1017);
// Begin line 958
  setline(958);
// compilenode returning *var_e
  Object call2328 = callmethod(*var_e, "value",
    0, params);
// compilenode returning call2328
// compilenode returning call2328
// Begin line 959
  setline(959);
// Begin line 1017
  setline(1017);
// Begin line 959
  setline(959);
// compilenode returning *var_e
  Object call2329 = callmethod(*var_e, "superclass",
    0, params);
// compilenode returning call2329
// compilenode returning call2329
// Begin line 958
  setline(958);
// compilenode returning module_ast
  params[0] = call2328;
  params[1] = call2329;
  Object call2330 = callmethod(module_ast, "astobject",
    2, params);
// compilenode returning call2330
// Begin line 960
  setline(960);
// compilenode returning self
  params[0] = call2330;
  Object call2331 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call2331
  *var_classInstanceType_39_ = call2331;
  if (call2331 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning self
  Object call2332 = callmethod(self, "popScope",
    0, params);
// compilenode returning call2332
// Begin line 962
  setline(962);
// Begin line 961
  setline(961);
  if (strlit2333 == NULL) {
    strlit2333 = alloc_String("InstanceOf<");
  }
// compilenode returning strlit2333
// compilenode returning *var_className
  params[0] = *var_className;
  Object opresult2335 = callmethod(strlit2333, "++", 1, params);
// compilenode returning opresult2335
  if (strlit2336 == NULL) {
    strlit2336 = alloc_String(">");
  }
// compilenode returning strlit2336
  params[0] = strlit2336;
  Object opresult2338 = callmethod(opresult2335, "++", 1, params);
// compilenode returning opresult2338
// Begin line 962
  setline(962);
// Begin line 1017
  setline(1017);
// Begin line 962
  setline(962);
// compilenode returning *var_classInstanceType_39_
  Object call2339 = callmethod(*var_classInstanceType_39_, "methods",
    0, params);
// compilenode returning call2339
// compilenode returning call2339
// Begin line 961
  setline(961);
// compilenode returning module_ast
  params[0] = opresult2338;
  params[1] = call2339;
  Object call2340 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call2340
  *var_classInstanceType = call2340;
  if (call2340 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 964
  setline(964);
// Begin line 963
  setline(963);
  if (strlit2341 == NULL) {
    strlit2341 = alloc_String("ClassOf<");
  }
// compilenode returning strlit2341
// compilenode returning *var_className
  params[0] = *var_className;
  Object opresult2343 = callmethod(strlit2341, "++", 1, params);
// compilenode returning opresult2343
  if (strlit2344 == NULL) {
    strlit2344 = alloc_String(">");
  }
// compilenode returning strlit2344
  params[0] = strlit2344;
  Object opresult2346 = callmethod(opresult2343, "++", 1, params);
// compilenode returning opresult2346
// Begin line 964
  setline(964);
  Object array2347 = alloc_List();
  if (strlit2348 == NULL) {
    strlit2348 = alloc_String("new");
  }
// compilenode returning strlit2348
// Begin line 1017
  setline(1017);
// Begin line 964
  setline(964);
// compilenode returning *var_e
  Object call2349 = callmethod(*var_e, "params",
    0, params);
// compilenode returning call2349
// compilenode returning call2349
// compilenode returning *var_classInstanceType
// compilenode returning module_ast
  params[0] = strlit2348;
  params[1] = call2349;
  params[2] = *var_classInstanceType;
  Object call2350 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call2350
  params[0] = call2350;
  callmethod(array2347, "push", 1, params);
// compilenode returning array2347
// Begin line 963
  setline(963);
// compilenode returning module_ast
  params[0] = opresult2346;
  params[1] = array2347;
  Object call2351 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call2351
  *var_classItselfType = call2351;
  if (call2351 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 967
  setline(967);
// Begin line 1017
  setline(1017);
// Begin line 966
  setline(966);
// compilenode returning *var_classGenerics
// compilenode returning *var_classItselfType
  params[0] = *var_classGenerics;
  Object call2352 = callmethod(*var_classItselfType, "generics:=",
    1, params);
// compilenode returning call2352
// compilenode returning nothing
// Begin line 967
  setline(967);
// compilenode returning *var_classInstanceType
// compilenode returning module_subtype
  params[0] = *var_classInstanceType;
  Object call2353 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2353
// Begin line 968
  setline(968);
// compilenode returning *var_classItselfType
// compilenode returning module_subtype
  params[0] = *var_classItselfType;
  Object call2354 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2354
// Begin line 970
  setline(970);
// Begin line 1017
  setline(1017);
// Begin line 969
  setline(969);
// compilenode returning *var_classItselfType
// compilenode returning *var_tmp
  params[0] = *var_classItselfType;
  Object call2355 = callmethod(*var_tmp, "dtype:=",
    1, params);
// compilenode returning call2355
// compilenode returning nothing
// Begin line 970
  setline(970);
// compilenode returning *var_className
// compilenode returning *var_tmp
// Begin line 971
  setline(971);
// compilenode returning self
  params[0] = *var_className;
  params[1] = *var_tmp;
  Object call2356 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2356
    if2285 = call2356;
  } else {
// Begin line 974
  setline(974);
// Begin line 976
  setline(976);
// Begin line 1017
  setline(1017);
// Begin line 971
  setline(971);
// compilenode returning *var_e
  Object call2358 = callmethod(*var_e, "kind",
    0, params);
// compilenode returning call2358
// compilenode returning call2358
  if (strlit2359 == NULL) {
    strlit2359 = alloc_String("import");
  }
// compilenode returning strlit2359
  params[0] = strlit2359;
  Object opresult2361 = callmethod(call2358, "==", 1, params);
// compilenode returning opresult2361
  Object if2357;
  if (istrue(opresult2361)) {
// Begin line 972
  setline(972);
  if (strlit2362 == NULL) {
    strlit2362 = alloc_String("def");
  }
// compilenode returning strlit2362
// compilenode returning *var_Binding
  params[0] = strlit2362;
  Object call2363 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2363
  *var_tmp = call2363;
  if (call2363 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 974
  setline(974);
// Begin line 1017
  setline(1017);
// Begin line 973
  setline(973);
// compilenode returning *var_DynamicType
// compilenode returning *var_tmp
  params[0] = *var_DynamicType;
  Object call2365 = callmethod(*var_tmp, "dtype:=",
    1, params);
// compilenode returning call2365
// compilenode returning nothing
// Begin line 974
  setline(974);
// Begin line 1017
  setline(1017);
// Begin line 974
  setline(974);
// Begin line 1017
  setline(1017);
// Begin line 974
  setline(974);
// compilenode returning *var_e
  Object call2366 = callmethod(*var_e, "value",
    0, params);
// compilenode returning call2366
// compilenode returning call2366
  Object call2367 = callmethod(call2366, "value",
    0, params);
// compilenode returning call2367
// compilenode returning call2367
// compilenode returning *var_tmp
// Begin line 975
  setline(975);
// compilenode returning self
  params[0] = call2367;
  params[1] = *var_tmp;
  Object call2368 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2368
    if2357 = call2368;
  } else {
  }
// compilenode returning if2357
    if2285 = if2357;
  }
// compilenode returning if2285
    if2275 = if2285;
  }
// compilenode returning if2275
    if2239 = if2275;
  }
// compilenode returning if2239
    if2203 = if2239;
  }
// compilenode returning if2203
    if2185 = if2203;
  }
// compilenode returning if2185
  return if2185;
}
Object meth_typechecker_apply2374(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_e = alloc_var();
  *var_e = args[0];
  Object params[1];
  Object *var_tmp = closure[0];
  Object *var_nl = closure[1];
  Object self = *closure[2];
// Begin line 978
  setline(978);
// Begin line 1017
  setline(1017);
// Begin line 978
  setline(978);
// compilenode returning *var_e
  Object call2375 = callmethod(*var_e, "line",
    0, params);
// compilenode returning call2375
// compilenode returning call2375
// compilenode returning module_util
  params[0] = call2375;
  Object call2376 = callmethod(module_util, "setline",
    1, params);
// compilenode returning call2376
// Begin line 979
  setline(979);
// compilenode returning *var_e
// Begin line 980
  setline(980);
// compilenode returning self
  params[0] = *var_e;
  Object call2377 = callmethod(self, "resolveIdentifiers",
    1, params);
// compilenode returning call2377
  *var_tmp = call2377;
  if (call2377 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning *var_tmp
// Begin line 981
  setline(981);
// compilenode returning self
  params[0] = *var_tmp;
  Object call2379 = callmethod(self, "expressionType",
    1, params);
// compilenode returning call2379
// compilenode returning *var_tmp
// compilenode returning *var_nl
  params[0] = *var_tmp;
  Object call2380 = callmethod(*var_nl, "push",
    1, params);
// compilenode returning call2380
  return call2380;
}
Object meth_typechecker_resolveIdentifiersList_40_1_41_withBlock2133(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object *var_lst = alloc_var();
  *var_lst = args[0];
  Object *var_bk = alloc_var();
  *var_bk = args[1];
  Object params[1];
  Object *var_scopes = closure[0];
  Object *var_Binding = closure[1];
  Object *var_DynamicType = closure[2];
  Object *var_nl = alloc_var();
  *var_nl = undefined;
  Object *var_isobj = alloc_var();
  *var_isobj = undefined;
  Object *var_tpb = alloc_var();
  *var_tpb = undefined;
  Object *var_tmp = alloc_var();
  *var_tmp = undefined;
// Begin line 895
  setline(895);
  Object array2134 = alloc_List();
// compilenode returning array2134
  var_nl = alloc_var();
  *var_nl = array2134;
  if (array2134 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 896
  setline(896);
// Begin line 895
  setline(895);
  Object bool2135 = alloc_Boolean(0);
// compilenode returning bool2135
  var_isobj = alloc_var();
  *var_isobj = bool2135;
  if (bool2135 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 897
  setline(897);
  var_tpb = alloc_var();
  *var_tpb = undefined;
// compilenode returning nothing
// Begin line 898
  setline(898);
// Begin line 897
  setline(897);
  Object bool2136 = alloc_Boolean(0);
// compilenode returning bool2136
  var_tmp = alloc_var();
  *var_tmp = bool2136;
  if (bool2136 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 898
  setline(898);
// compilenode returning self
  Object call2137 = callmethod(self, "pushScope",
    0, params);
// compilenode returning call2137
// Begin line 899
  setline(899);
// Begin line 1017
  setline(1017);
// Begin line 899
  setline(899);
// compilenode returning *var_bk
  Object call2138 = callmethod(*var_bk, "apply",
    0, params);
// compilenode returning call2138
// compilenode returning call2138
// Begin line 902
  setline(902);
// Begin line 900
  setline(900);
  if (strlit2140 == NULL) {
    strlit2140 = alloc_String("___is_object");
  }
// compilenode returning strlit2140
// Begin line 903
  setline(903);
// Begin line 1017
  setline(1017);
// Begin line 900
  setline(900);
// compilenode returning *var_scopes
  Object call2141 = callmethod(*var_scopes, "last",
    0, params);
// compilenode returning call2141
// compilenode returning call2141
  params[0] = strlit2140;
  Object call2142 = callmethod(call2141, "contains",
    1, params);
// compilenode returning call2142
  Object if2139;
  if (istrue(call2142)) {
// Begin line 902
  setline(902);
// Begin line 901
  setline(901);
  Object bool2143 = alloc_Boolean(1);
// compilenode returning bool2143
  *var_isobj = bool2143;
  if (bool2143 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if2139 = nothing;
  } else {
  }
// compilenode returning if2139
// Begin line 907
  setline(907);
// Begin line 903
  setline(903);
// compilenode returning *var_lst
// Begin line 907
  setline(907);
// Begin line 1017
  setline(1017);
  Object obj2147 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2147, self, 0);
  addmethod2(obj2147, "outer", &reader_typechecker_outer_2148);
  adddatum2(obj2147, self, 0);
  block_savedest(obj2147);
  Object **closure2149 = createclosure(3);
  addtoclosure(closure2149, var_Binding);
  addtoclosure(closure2149, var_tpb);
  Object *selfpp2161 = alloc_var();
  *selfpp2161 = self;
  addtoclosure(closure2149, selfpp2161);
  struct UserObject *uo2149 = (struct UserObject*)obj2147;
  uo2149->data[1] = (Object)closure2149;
  addmethod2(obj2147, "apply", &meth_typechecker_apply2149);
  set_type(obj2147, 0);
// compilenode returning obj2147
  setclassname(obj2147, "Block<typechecker:2146>");
// compilenode returning obj2147
  params[0] = *var_lst;
  Object iter2145 = callmethod(*var_lst, "iter", 1, params);
  while(1) {
    Object cond2145 = callmethod(iter2145, "havemore", 0, NULL);
    if (!istrue(cond2145)) break;
    params[0] = callmethod(iter2145, "next", 0, NULL);
    callmethod(obj2147, "apply", 1, params);
  }
// compilenode returning *var_lst
// Begin line 914
  setline(914);
// Begin line 910
  setline(910);
// compilenode returning *var_lst
// Begin line 914
  setline(914);
// Begin line 1017
  setline(1017);
  Object obj2164 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2164, self, 0);
  addmethod2(obj2164, "outer", &reader_typechecker_outer_2165);
  adddatum2(obj2164, self, 0);
  block_savedest(obj2164);
  Object **closure2166 = createclosure(2);
  addtoclosure(closure2166, var_tpb);
  Object *selfpp2179 = alloc_var();
  *selfpp2179 = self;
  addtoclosure(closure2166, selfpp2179);
  struct UserObject *uo2166 = (struct UserObject*)obj2164;
  uo2166->data[1] = (Object)closure2166;
  addmethod2(obj2164, "apply", &meth_typechecker_apply2166);
  set_type(obj2164, 0);
// compilenode returning obj2164
  setclassname(obj2164, "Block<typechecker:2163>");
// compilenode returning obj2164
  params[0] = *var_lst;
  Object iter2162 = callmethod(*var_lst, "iter", 1, params);
  while(1) {
    Object cond2162 = callmethod(iter2162, "havemore", 0, NULL);
    if (!istrue(cond2162)) break;
    params[0] = callmethod(iter2162, "next", 0, NULL);
    callmethod(obj2164, "apply", 1, params);
  }
// compilenode returning *var_lst
// Begin line 974
  setline(974);
// Begin line 917
  setline(917);
// compilenode returning *var_lst
// Begin line 974
  setline(974);
// Begin line 1017
  setline(1017);
  Object obj2182 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2182, self, 0);
  addmethod2(obj2182, "outer", &reader_typechecker_outer_2183);
  adddatum2(obj2182, self, 0);
  block_savedest(obj2182);
  Object **closure2184 = createclosure(6);
  addtoclosure(closure2184, var_isobj);
  addtoclosure(closure2184, var_Binding);
  addtoclosure(closure2184, var_tpb);
  addtoclosure(closure2184, var_tmp);
  addtoclosure(closure2184, var_DynamicType);
  Object *selfpp2369 = alloc_var();
  *selfpp2369 = self;
  addtoclosure(closure2184, selfpp2369);
  struct UserObject *uo2184 = (struct UserObject*)obj2182;
  uo2184->data[1] = (Object)closure2184;
  addmethod2(obj2182, "apply", &meth_typechecker_apply2184);
  set_type(obj2182, 0);
// compilenode returning obj2182
  setclassname(obj2182, "Block<typechecker:2181>");
// compilenode returning obj2182
  params[0] = *var_lst;
  Object iter2180 = callmethod(*var_lst, "iter", 1, params);
  while(1) {
    Object cond2180 = callmethod(iter2180, "havemore", 0, NULL);
    if (!istrue(cond2180)) break;
    params[0] = callmethod(iter2180, "next", 0, NULL);
    callmethod(obj2182, "apply", 1, params);
  }
// compilenode returning *var_lst
// Begin line 981
  setline(981);
// Begin line 977
  setline(977);
// compilenode returning *var_lst
// Begin line 981
  setline(981);
// Begin line 1017
  setline(1017);
  Object obj2372 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2372, self, 0);
  addmethod2(obj2372, "outer", &reader_typechecker_outer_2373);
  adddatum2(obj2372, self, 0);
  block_savedest(obj2372);
  Object **closure2374 = createclosure(3);
  addtoclosure(closure2374, var_tmp);
  addtoclosure(closure2374, var_nl);
  Object *selfpp2381 = alloc_var();
  *selfpp2381 = self;
  addtoclosure(closure2374, selfpp2381);
  struct UserObject *uo2374 = (struct UserObject*)obj2372;
  uo2374->data[1] = (Object)closure2374;
  addmethod2(obj2372, "apply", &meth_typechecker_apply2374);
  set_type(obj2372, 0);
// compilenode returning obj2372
  setclassname(obj2372, "Block<typechecker:2371>");
// compilenode returning obj2372
  params[0] = *var_lst;
  Object iter2370 = callmethod(*var_lst, "iter", 1, params);
  while(1) {
    Object cond2370 = callmethod(iter2370, "havemore", 0, NULL);
    if (!istrue(cond2370)) break;
    params[0] = callmethod(iter2370, "next", 0, NULL);
    callmethod(obj2372, "apply", 1, params);
  }
// compilenode returning *var_lst
// Begin line 983
  setline(983);
// compilenode returning self
  Object call2382 = callmethod(self, "popScope",
    0, params);
// compilenode returning call2382
// Begin line 984
  setline(984);
// compilenode returning *var_nl
  return *var_nl;
}
Object meth_typechecker_apply2387(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object params[1];
  Object self = *closure[0];
  return nothing;
}
Object meth_typechecker_resolveIdentifiersList2383(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_lst = alloc_var();
  *var_lst = args[0];
  Object params[2];
// Begin line 987
  setline(987);
// compilenode returning *var_lst
// Begin line 988
  setline(988);
// Begin line 1017
  setline(1017);
  Object obj2385 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj2385, self, 0);
  addmethod2(obj2385, "outer", &reader_typechecker_outer_2386);
  adddatum2(obj2385, self, 0);
  block_savedest(obj2385);
  Object **closure2387 = createclosure(1);
  Object *selfpp2388 = alloc_var();
  *selfpp2388 = self;
  addtoclosure(closure2387, selfpp2388);
  struct UserObject *uo2387 = (struct UserObject*)obj2385;
  uo2387->data[1] = (Object)closure2387;
  addmethod2(obj2385, "apply", &meth_typechecker_apply2387);
  set_type(obj2385, 0);
// compilenode returning obj2385
  setclassname(obj2385, "Block<typechecker:2384>");
// compilenode returning obj2385
// Begin line 988
  setline(988);
// compilenode returning self
  params[0] = *var_lst;
  params[1] = obj2385;
  Object call2389 = callmethod(self, "resolveIdentifiersList(1)withBlock",
    2, params);
// compilenode returning call2389
  return call2389;
}
Object meth_typechecker_typecheck2390(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object *var_values = alloc_var();
  *var_values = args[0];
  Object params[2];
  Object *var_Binding = closure[0];
  Object *var_DynamicType = closure[1];
  Object *var_NumberType = closure[2];
  Object *var_StringType = closure[3];
  Object *var_BooleanType = closure[4];
  Object *var_btmp = alloc_var();
  *var_btmp = undefined;
// Begin line 991
  setline(991);
  if (strlit2391 == NULL) {
    strlit2391 = alloc_String("typechecking.");
  }
// compilenode returning strlit2391
// compilenode returning module_util
  params[0] = strlit2391;
  Object call2392 = callmethod(module_util, "log_verbose",
    1, params);
// compilenode returning call2392
// Begin line 993
  setline(993);
  var_btmp = alloc_var();
  *var_btmp = undefined;
// compilenode returning nothing
  if (strlit2393 == NULL) {
    strlit2393 = alloc_String("print");
  }
// compilenode returning strlit2393
  if (strlit2394 == NULL) {
    strlit2394 = alloc_String("method");
  }
// compilenode returning strlit2394
// compilenode returning *var_Binding
  params[0] = strlit2394;
  Object call2395 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2395
// Begin line 994
  setline(994);
// compilenode returning self
  params[0] = strlit2393;
  params[1] = call2395;
  Object call2396 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2396
  if (strlit2397 == NULL) {
    strlit2397 = alloc_String("length");
  }
// compilenode returning strlit2397
  if (strlit2398 == NULL) {
    strlit2398 = alloc_String("method");
  }
// compilenode returning strlit2398
// compilenode returning *var_Binding
  params[0] = strlit2398;
  Object call2399 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2399
// Begin line 995
  setline(995);
// compilenode returning self
  params[0] = strlit2397;
  params[1] = call2399;
  Object call2400 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2400
  if (strlit2401 == NULL) {
    strlit2401 = alloc_String("escapestring");
  }
// compilenode returning strlit2401
  if (strlit2402 == NULL) {
    strlit2402 = alloc_String("method");
  }
// compilenode returning strlit2402
// compilenode returning *var_Binding
  params[0] = strlit2402;
  Object call2403 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2403
// Begin line 996
  setline(996);
// compilenode returning self
  params[0] = strlit2401;
  params[1] = call2403;
  Object call2404 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2404
  if (strlit2405 == NULL) {
    strlit2405 = alloc_String("HashMap");
  }
// compilenode returning strlit2405
  if (strlit2406 == NULL) {
    strlit2406 = alloc_String("def");
  }
// compilenode returning strlit2406
// compilenode returning *var_Binding
  params[0] = strlit2406;
  Object call2407 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2407
// Begin line 997
  setline(997);
// compilenode returning self
  params[0] = strlit2405;
  params[1] = call2407;
  Object call2408 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2408
  if (strlit2409 == NULL) {
    strlit2409 = alloc_String("true");
  }
// compilenode returning strlit2409
  if (strlit2410 == NULL) {
    strlit2410 = alloc_String("def");
  }
// compilenode returning strlit2410
// compilenode returning *var_Binding
  params[0] = strlit2410;
  Object call2411 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2411
// Begin line 998
  setline(998);
// compilenode returning self
  params[0] = strlit2409;
  params[1] = call2411;
  Object call2412 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2412
  if (strlit2413 == NULL) {
    strlit2413 = alloc_String("false");
  }
// compilenode returning strlit2413
  if (strlit2414 == NULL) {
    strlit2414 = alloc_String("def");
  }
// compilenode returning strlit2414
// compilenode returning *var_Binding
  params[0] = strlit2414;
  Object call2415 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2415
// Begin line 999
  setline(999);
// compilenode returning self
  params[0] = strlit2413;
  params[1] = call2415;
  Object call2416 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2416
  if (strlit2417 == NULL) {
    strlit2417 = alloc_String("self");
  }
// compilenode returning strlit2417
  if (strlit2418 == NULL) {
    strlit2418 = alloc_String("def");
  }
// compilenode returning strlit2418
// compilenode returning *var_Binding
  params[0] = strlit2418;
  Object call2419 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2419
// Begin line 1000
  setline(1000);
// compilenode returning self
  params[0] = strlit2417;
  params[1] = call2419;
  Object call2420 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2420
  if (strlit2421 == NULL) {
    strlit2421 = alloc_String("raise");
  }
// compilenode returning strlit2421
  if (strlit2422 == NULL) {
    strlit2422 = alloc_String("method");
  }
// compilenode returning strlit2422
// compilenode returning *var_Binding
  params[0] = strlit2422;
  Object call2423 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2423
// Begin line 1001
  setline(1001);
// compilenode returning self
  params[0] = strlit2421;
  params[1] = call2423;
  Object call2424 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2424
  if (strlit2425 == NULL) {
    strlit2425 = alloc_String("type");
  }
// compilenode returning strlit2425
// compilenode returning *var_Binding
  params[0] = strlit2425;
  Object call2426 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2426
  *var_btmp = call2426;
  if (call2426 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1003
  setline(1003);
// Begin line 1017
  setline(1017);
// Begin line 1002
  setline(1002);
// compilenode returning *var_DynamicType
// compilenode returning *var_btmp
  params[0] = *var_DynamicType;
  Object call2428 = callmethod(*var_btmp, "value:=",
    1, params);
// compilenode returning call2428
// compilenode returning nothing
// Begin line 1003
  setline(1003);
  if (strlit2429 == NULL) {
    strlit2429 = alloc_String("Dynamic");
  }
// compilenode returning strlit2429
// compilenode returning *var_btmp
// Begin line 1004
  setline(1004);
// compilenode returning self
  params[0] = strlit2429;
  params[1] = *var_btmp;
  Object call2430 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2430
  if (strlit2431 == NULL) {
    strlit2431 = alloc_String("type");
  }
// compilenode returning strlit2431
// compilenode returning *var_Binding
  params[0] = strlit2431;
  Object call2432 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2432
  *var_btmp = call2432;
  if (call2432 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1006
  setline(1006);
// Begin line 1017
  setline(1017);
// Begin line 1005
  setline(1005);
// compilenode returning *var_NumberType
// compilenode returning *var_btmp
  params[0] = *var_NumberType;
  Object call2434 = callmethod(*var_btmp, "value:=",
    1, params);
// compilenode returning call2434
// compilenode returning nothing
// Begin line 1006
  setline(1006);
  if (strlit2435 == NULL) {
    strlit2435 = alloc_String("Number");
  }
// compilenode returning strlit2435
// compilenode returning *var_btmp
// Begin line 1007
  setline(1007);
// compilenode returning self
  params[0] = strlit2435;
  params[1] = *var_btmp;
  Object call2436 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2436
  if (strlit2437 == NULL) {
    strlit2437 = alloc_String("type");
  }
// compilenode returning strlit2437
// compilenode returning *var_Binding
  params[0] = strlit2437;
  Object call2438 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2438
  *var_btmp = call2438;
  if (call2438 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1009
  setline(1009);
// Begin line 1017
  setline(1017);
// Begin line 1008
  setline(1008);
// compilenode returning *var_StringType
// compilenode returning *var_btmp
  params[0] = *var_StringType;
  Object call2440 = callmethod(*var_btmp, "value:=",
    1, params);
// compilenode returning call2440
// compilenode returning nothing
// Begin line 1009
  setline(1009);
  if (strlit2441 == NULL) {
    strlit2441 = alloc_String("String");
  }
// compilenode returning strlit2441
// compilenode returning *var_btmp
// Begin line 1010
  setline(1010);
// compilenode returning self
  params[0] = strlit2441;
  params[1] = *var_btmp;
  Object call2442 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2442
  if (strlit2443 == NULL) {
    strlit2443 = alloc_String("type");
  }
// compilenode returning strlit2443
// compilenode returning *var_Binding
  params[0] = strlit2443;
  Object call2444 = callmethod(*var_Binding, "new",
    1, params);
// compilenode returning call2444
  *var_btmp = call2444;
  if (call2444 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 1012
  setline(1012);
// Begin line 1017
  setline(1017);
// Begin line 1011
  setline(1011);
// compilenode returning *var_BooleanType
// compilenode returning *var_btmp
  params[0] = *var_BooleanType;
  Object call2446 = callmethod(*var_btmp, "value:=",
    1, params);
// compilenode returning call2446
// compilenode returning nothing
// Begin line 1012
  setline(1012);
  if (strlit2447 == NULL) {
    strlit2447 = alloc_String("Boolean");
  }
// compilenode returning strlit2447
// compilenode returning *var_btmp
// Begin line 1013
  setline(1013);
// compilenode returning self
  params[0] = strlit2447;
  params[1] = *var_btmp;
  Object call2448 = callmethod(self, "bindName",
    2, params);
// compilenode returning call2448
// compilenode returning *var_DynamicType
// compilenode returning module_subtype
  params[0] = *var_DynamicType;
  Object call2449 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2449
// Begin line 1014
  setline(1014);
// compilenode returning *var_NumberType
// compilenode returning module_subtype
  params[0] = *var_NumberType;
  Object call2450 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2450
// Begin line 1015
  setline(1015);
// compilenode returning *var_StringType
// compilenode returning module_subtype
  params[0] = *var_StringType;
  Object call2451 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2451
// Begin line 1016
  setline(1016);
// compilenode returning *var_BooleanType
// compilenode returning module_subtype
  params[0] = *var_BooleanType;
  Object call2452 = callmethod(module_subtype, "addType",
    1, params);
// compilenode returning call2452
// Begin line 1017
  setline(1017);
// compilenode returning *var_values
// Begin line 1018
  setline(1018);
// compilenode returning self
  params[0] = *var_values;
  Object call2453 = callmethod(self, "resolveIdentifiersList",
    1, params);
// compilenode returning call2453
  return call2453;
}
Object module_typechecker_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<typechecker>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[3];
  Object *var_scopes = alloc_var();
  *var_scopes = undefined;
  Object *var_DynamicIdentifier = alloc_var();
  *var_DynamicIdentifier = undefined;
  Object *var_TopOther = alloc_var();
  *var_TopOther = undefined;
  Object *var_StringIdentifier = alloc_var();
  *var_StringIdentifier = undefined;
  Object *var_StringOther = alloc_var();
  *var_StringOther = undefined;
  Object *var_BooleanIdentifier = alloc_var();
  *var_BooleanIdentifier = undefined;
  Object *var_BooleanOther = alloc_var();
  *var_BooleanOther = undefined;
  Object *var_NumberIdentifier = alloc_var();
  *var_NumberIdentifier = undefined;
  Object *var_NumberOther = alloc_var();
  *var_NumberOther = undefined;
  Object *var_DynamicType = alloc_var();
  *var_DynamicType = undefined;
  Object *var_NumberType = alloc_var();
  *var_NumberType = undefined;
  Object *var_StringType = alloc_var();
  *var_StringType = undefined;
  Object *var_BooleanType = alloc_var();
  *var_BooleanType = undefined;
  Object *var_currentReturnType = alloc_var();
  *var_currentReturnType = undefined;
  Object *var_Binding = alloc_var();
  *var_Binding = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of ast
  if (module_ast == NULL)
    module_ast = module_ast_init();
  Object *var_ast = alloc_var();
  *var_ast = module_ast;
// compilenode returning undefined
// Begin line 4
  setline(4);
// Import of util
  if (module_util == NULL)
    module_util = module_util_init();
  Object *var_util = alloc_var();
  *var_util = module_util;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Import of subtype
  if (module_subtype == NULL)
    module_subtype = module_subtype_init();
  Object *var_subtype = alloc_var();
  *var_subtype = module_subtype;
// compilenode returning undefined
  Object array4 = alloc_List();
// Begin line 1017
  setline(1017);
// Begin line 6
  setline(6);
// compilenode returning *var_HashMap
  Object call5 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call5
// compilenode returning call5
  params[0] = call5;
  callmethod(array4, "push", 1, params);
// compilenode returning array4
  var_scopes = alloc_var();
  *var_scopes = array4;
  if (array4 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 8
  setline(8);
  if (strlit6 == NULL) {
    strlit6 = alloc_String("Dynamic");
  }
// compilenode returning strlit6
  Object bool7 = alloc_Boolean(0);
// compilenode returning bool7
// compilenode returning module_ast
  params[0] = strlit6;
  params[1] = bool7;
  Object call8 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call8
  *var_DynamicIdentifier = call8;
  if (call8 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 9
  setline(9);
  if (strlit9 == NULL) {
    strlit9 = alloc_String("other");
  }
// compilenode returning strlit9
  if (strlit10 == NULL) {
    strlit10 = alloc_String("Dynamic");
  }
// compilenode returning strlit10
  Object bool11 = alloc_Boolean(0);
// compilenode returning bool11
// compilenode returning module_ast
  params[0] = strlit10;
  params[1] = bool11;
  Object call12 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call12
// compilenode returning module_ast
  params[0] = strlit9;
  params[1] = call12;
  Object call13 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call13
  *var_TopOther = call13;
  if (call13 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 10
  setline(10);
  if (strlit14 == NULL) {
    strlit14 = alloc_String("String");
  }
// compilenode returning strlit14
  Object bool15 = alloc_Boolean(0);
// compilenode returning bool15
// compilenode returning module_ast
  params[0] = strlit14;
  params[1] = bool15;
  Object call16 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call16
  *var_StringIdentifier = call16;
  if (call16 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 11
  setline(11);
  if (strlit17 == NULL) {
    strlit17 = alloc_String("other");
  }
// compilenode returning strlit17
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit17;
  params[1] = *var_StringIdentifier;
  Object call18 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call18
  *var_StringOther = call18;
  if (call18 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 12
  setline(12);
  if (strlit19 == NULL) {
    strlit19 = alloc_String("Boolean");
  }
// compilenode returning strlit19
  Object bool20 = alloc_Boolean(0);
// compilenode returning bool20
// compilenode returning module_ast
  params[0] = strlit19;
  params[1] = bool20;
  Object call21 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call21
  *var_BooleanIdentifier = call21;
  if (call21 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 13
  setline(13);
  if (strlit22 == NULL) {
    strlit22 = alloc_String("other");
  }
// compilenode returning strlit22
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit22;
  params[1] = *var_BooleanIdentifier;
  Object call23 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call23
  *var_BooleanOther = call23;
  if (call23 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 14
  setline(14);
  if (strlit24 == NULL) {
    strlit24 = alloc_String("Number");
  }
// compilenode returning strlit24
  Object bool25 = alloc_Boolean(0);
// compilenode returning bool25
// compilenode returning module_ast
  params[0] = strlit24;
  params[1] = bool25;
  Object call26 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call26
  *var_NumberIdentifier = call26;
  if (call26 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 15
  setline(15);
  if (strlit27 == NULL) {
    strlit27 = alloc_String("other");
  }
// compilenode returning strlit27
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit27;
  params[1] = *var_NumberIdentifier;
  Object call28 = callmethod(module_ast, "astidentifier",
    2, params);
// compilenode returning call28
  *var_NumberOther = call28;
  if (call28 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 16
  setline(16);
  if (strlit29 == NULL) {
    strlit29 = alloc_String("Dynamic");
  }
// compilenode returning strlit29
  Object array30 = alloc_List();
// compilenode returning array30
// compilenode returning module_ast
  params[0] = strlit29;
  params[1] = array30;
  Object call31 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call31
  *var_DynamicType = call31;
  if (call31 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 33
  setline(33);
// Begin line 17
  setline(17);
  if (strlit32 == NULL) {
    strlit32 = alloc_String("Number");
  }
// compilenode returning strlit32
// Begin line 33
  setline(33);
  Object array33 = alloc_List();
// Begin line 18
  setline(18);
  if (strlit34 == NULL) {
    strlit34 = alloc_String("+");
  }
// compilenode returning strlit34
  Object array35 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array35, "push", 1, params);
// compilenode returning array35
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit34;
  params[1] = array35;
  params[2] = *var_NumberIdentifier;
  Object call36 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call36
  params[0] = call36;
  callmethod(array33, "push", 1, params);
// Begin line 19
  setline(19);
  if (strlit37 == NULL) {
    strlit37 = alloc_String("*");
  }
// compilenode returning strlit37
  Object array38 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array38, "push", 1, params);
// compilenode returning array38
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit37;
  params[1] = array38;
  params[2] = *var_NumberIdentifier;
  Object call39 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call39
  params[0] = call39;
  callmethod(array33, "push", 1, params);
// Begin line 20
  setline(20);
  if (strlit40 == NULL) {
    strlit40 = alloc_String("-");
  }
// compilenode returning strlit40
  Object array41 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array41, "push", 1, params);
// compilenode returning array41
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit40;
  params[1] = array41;
  params[2] = *var_NumberIdentifier;
  Object call42 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call42
  params[0] = call42;
  callmethod(array33, "push", 1, params);
// Begin line 21
  setline(21);
  if (strlit43 == NULL) {
    strlit43 = alloc_String("/");
  }
// compilenode returning strlit43
  Object array44 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array44, "push", 1, params);
// compilenode returning array44
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit43;
  params[1] = array44;
  params[2] = *var_NumberIdentifier;
  Object call45 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call45
  params[0] = call45;
  callmethod(array33, "push", 1, params);
// Begin line 22
  setline(22);
  if (strlit46 == NULL) {
    strlit46 = alloc_String("%");
  }
// compilenode returning strlit46
  Object array47 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array47, "push", 1, params);
// compilenode returning array47
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit46;
  params[1] = array47;
  params[2] = *var_NumberIdentifier;
  Object call48 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call48
  params[0] = call48;
  callmethod(array33, "push", 1, params);
// Begin line 23
  setline(23);
  if (strlit49 == NULL) {
    strlit49 = alloc_String("==");
  }
// compilenode returning strlit49
  Object array50 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array50, "push", 1, params);
// compilenode returning array50
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit49;
  params[1] = array50;
  params[2] = *var_BooleanIdentifier;
  Object call51 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call51
  params[0] = call51;
  callmethod(array33, "push", 1, params);
// Begin line 24
  setline(24);
  if (strlit52 == NULL) {
    strlit52 = alloc_String("!=");
  }
// compilenode returning strlit52
  Object array53 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array53, "push", 1, params);
// compilenode returning array53
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit52;
  params[1] = array53;
  params[2] = *var_BooleanIdentifier;
  Object call54 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call54
  params[0] = call54;
  callmethod(array33, "push", 1, params);
// Begin line 25
  setline(25);
  if (strlit55 == NULL) {
    strlit55 = alloc_String("/=");
  }
// compilenode returning strlit55
  Object array56 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array56, "push", 1, params);
// compilenode returning array56
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit55;
  params[1] = array56;
  params[2] = *var_BooleanIdentifier;
  Object call57 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call57
  params[0] = call57;
  callmethod(array33, "push", 1, params);
// Begin line 26
  setline(26);
  if (strlit58 == NULL) {
    strlit58 = alloc_String("++");
  }
// compilenode returning strlit58
  Object array59 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array59, "push", 1, params);
// compilenode returning array59
// compilenode returning *var_DynamicIdentifier
// compilenode returning module_ast
  params[0] = strlit58;
  params[1] = array59;
  params[2] = *var_DynamicIdentifier;
  Object call60 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call60
  params[0] = call60;
  callmethod(array33, "push", 1, params);
// Begin line 27
  setline(27);
  if (strlit61 == NULL) {
    strlit61 = alloc_String("<");
  }
// compilenode returning strlit61
  Object array62 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array62, "push", 1, params);
// compilenode returning array62
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit61;
  params[1] = array62;
  params[2] = *var_BooleanIdentifier;
  Object call63 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call63
  params[0] = call63;
  callmethod(array33, "push", 1, params);
// Begin line 28
  setline(28);
  if (strlit64 == NULL) {
    strlit64 = alloc_String("<=");
  }
// compilenode returning strlit64
  Object array65 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array65, "push", 1, params);
// compilenode returning array65
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit64;
  params[1] = array65;
  params[2] = *var_BooleanIdentifier;
  Object call66 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call66
  params[0] = call66;
  callmethod(array33, "push", 1, params);
// Begin line 29
  setline(29);
  if (strlit67 == NULL) {
    strlit67 = alloc_String(">");
  }
// compilenode returning strlit67
  Object array68 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array68, "push", 1, params);
// compilenode returning array68
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit67;
  params[1] = array68;
  params[2] = *var_BooleanIdentifier;
  Object call69 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call69
  params[0] = call69;
  callmethod(array33, "push", 1, params);
// Begin line 30
  setline(30);
  if (strlit70 == NULL) {
    strlit70 = alloc_String(">=");
  }
// compilenode returning strlit70
  Object array71 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array71, "push", 1, params);
// compilenode returning array71
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit70;
  params[1] = array71;
  params[2] = *var_BooleanIdentifier;
  Object call72 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call72
  params[0] = call72;
  callmethod(array33, "push", 1, params);
// Begin line 31
  setline(31);
  if (strlit73 == NULL) {
    strlit73 = alloc_String("..");
  }
// compilenode returning strlit73
  Object array74 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array74, "push", 1, params);
// compilenode returning array74
// compilenode returning *var_DynamicIdentifier
// compilenode returning module_ast
  params[0] = strlit73;
  params[1] = array74;
  params[2] = *var_DynamicIdentifier;
  Object call75 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call75
  params[0] = call75;
  callmethod(array33, "push", 1, params);
// Begin line 32
  setline(32);
  if (strlit76 == NULL) {
    strlit76 = alloc_String("asString");
  }
// compilenode returning strlit76
  Object array77 = alloc_List();
// compilenode returning array77
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit76;
  params[1] = array77;
  params[2] = *var_StringIdentifier;
  Object call78 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call78
  params[0] = call78;
  callmethod(array33, "push", 1, params);
// Begin line 33
  setline(33);
  if (strlit79 == NULL) {
    strlit79 = alloc_String("prefix-");
  }
// compilenode returning strlit79
  Object array80 = alloc_List();
// compilenode returning array80
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit79;
  params[1] = array80;
  params[2] = *var_NumberIdentifier;
  Object call81 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call81
  params[0] = call81;
  callmethod(array33, "push", 1, params);
// compilenode returning array33
// Begin line 17
  setline(17);
// compilenode returning module_ast
  params[0] = strlit32;
  params[1] = array33;
  Object call82 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call82
  *var_NumberType = call82;
  if (call82 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 50
  setline(50);
// Begin line 35
  setline(35);
  if (strlit83 == NULL) {
    strlit83 = alloc_String("String");
  }
// compilenode returning strlit83
// Begin line 50
  setline(50);
  Object array84 = alloc_List();
// Begin line 36
  setline(36);
  if (strlit85 == NULL) {
    strlit85 = alloc_String("++");
  }
// compilenode returning strlit85
  Object array86 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array86, "push", 1, params);
// compilenode returning array86
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit85;
  params[1] = array86;
  params[2] = *var_StringIdentifier;
  Object call87 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call87
  params[0] = call87;
  callmethod(array84, "push", 1, params);
// Begin line 37
  setline(37);
  if (strlit88 == NULL) {
    strlit88 = alloc_String("size");
  }
// compilenode returning strlit88
  Object array89 = alloc_List();
// compilenode returning array89
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit88;
  params[1] = array89;
  params[2] = *var_NumberIdentifier;
  Object call90 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call90
  params[0] = call90;
  callmethod(array84, "push", 1, params);
// Begin line 38
  setline(38);
  if (strlit91 == NULL) {
    strlit91 = alloc_String("ord");
  }
// compilenode returning strlit91
  Object array92 = alloc_List();
// compilenode returning array92
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit91;
  params[1] = array92;
  params[2] = *var_NumberIdentifier;
  Object call93 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call93
  params[0] = call93;
  callmethod(array84, "push", 1, params);
// Begin line 39
  setline(39);
  if (strlit94 == NULL) {
    strlit94 = alloc_String("at");
  }
// compilenode returning strlit94
  Object array95 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array95, "push", 1, params);
// compilenode returning array95
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit94;
  params[1] = array95;
  params[2] = *var_StringIdentifier;
  Object call96 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call96
  params[0] = call96;
  callmethod(array84, "push", 1, params);
// Begin line 40
  setline(40);
  if (strlit97 == NULL) {
    strlit97 = alloc_String("==");
  }
// compilenode returning strlit97
  Object array98 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array98, "push", 1, params);
// compilenode returning array98
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit97;
  params[1] = array98;
  params[2] = *var_BooleanIdentifier;
  Object call99 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call99
  params[0] = call99;
  callmethod(array84, "push", 1, params);
// Begin line 41
  setline(41);
  if (strlit100 == NULL) {
    strlit100 = alloc_String("!=");
  }
// compilenode returning strlit100
  Object array101 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array101, "push", 1, params);
// compilenode returning array101
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit100;
  params[1] = array101;
  params[2] = *var_BooleanIdentifier;
  Object call102 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call102
  params[0] = call102;
  callmethod(array84, "push", 1, params);
// Begin line 42
  setline(42);
  if (strlit103 == NULL) {
    strlit103 = alloc_String("/=");
  }
// compilenode returning strlit103
  Object array104 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array104, "push", 1, params);
// compilenode returning array104
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit103;
  params[1] = array104;
  params[2] = *var_BooleanIdentifier;
  Object call105 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call105
  params[0] = call105;
  callmethod(array84, "push", 1, params);
// Begin line 43
  setline(43);
  if (strlit106 == NULL) {
    strlit106 = alloc_String("iter");
  }
// compilenode returning strlit106
  Object array107 = alloc_List();
// compilenode returning array107
// compilenode returning *var_DynamicIdentifier
// compilenode returning module_ast
  params[0] = strlit106;
  params[1] = array107;
  params[2] = *var_DynamicIdentifier;
  Object call108 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call108
  params[0] = call108;
  callmethod(array84, "push", 1, params);
// Begin line 45
  setline(45);
// Begin line 44
  setline(44);
  if (strlit109 == NULL) {
    strlit109 = alloc_String("substringFrom(1)to");
  }
// compilenode returning strlit109
  Object array110 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array110, "push", 1, params);
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array110, "push", 1, params);
// compilenode returning array110
// Begin line 45
  setline(45);
// compilenode returning *var_StringIdentifier
// Begin line 44
  setline(44);
// compilenode returning module_ast
  params[0] = strlit109;
  params[1] = array110;
  params[2] = *var_StringIdentifier;
  Object call111 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call111
  params[0] = call111;
  callmethod(array84, "push", 1, params);
// Begin line 47
  setline(47);
// Begin line 46
  setline(46);
  if (strlit112 == NULL) {
    strlit112 = alloc_String("replace(1)with");
  }
// compilenode returning strlit112
  Object array113 = alloc_List();
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array113, "push", 1, params);
// compilenode returning *var_NumberOther
  params[0] = *var_NumberOther;
  callmethod(array113, "push", 1, params);
// compilenode returning array113
// Begin line 47
  setline(47);
// compilenode returning *var_StringIdentifier
// Begin line 46
  setline(46);
// compilenode returning module_ast
  params[0] = strlit112;
  params[1] = array113;
  params[2] = *var_StringIdentifier;
  Object call114 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call114
  params[0] = call114;
  callmethod(array84, "push", 1, params);
// Begin line 48
  setline(48);
  if (strlit115 == NULL) {
    strlit115 = alloc_String("hashcode");
  }
// compilenode returning strlit115
  Object array116 = alloc_List();
// compilenode returning array116
// compilenode returning *var_NumberIdentifier
// compilenode returning module_ast
  params[0] = strlit115;
  params[1] = array116;
  params[2] = *var_NumberIdentifier;
  Object call117 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call117
  params[0] = call117;
  callmethod(array84, "push", 1, params);
// Begin line 49
  setline(49);
  if (strlit118 == NULL) {
    strlit118 = alloc_String("indices");
  }
// compilenode returning strlit118
  Object array119 = alloc_List();
// compilenode returning array119
// compilenode returning *var_DynamicIdentifier
// compilenode returning module_ast
  params[0] = strlit118;
  params[1] = array119;
  params[2] = *var_DynamicIdentifier;
  Object call120 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call120
  params[0] = call120;
  callmethod(array84, "push", 1, params);
// Begin line 50
  setline(50);
  if (strlit121 == NULL) {
    strlit121 = alloc_String("asString");
  }
// compilenode returning strlit121
  Object array122 = alloc_List();
// compilenode returning array122
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit121;
  params[1] = array122;
  params[2] = *var_StringIdentifier;
  Object call123 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call123
  params[0] = call123;
  callmethod(array84, "push", 1, params);
// compilenode returning array84
// Begin line 35
  setline(35);
// compilenode returning module_ast
  params[0] = strlit83;
  params[1] = array84;
  Object call124 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call124
  *var_StringType = call124;
  if (call124 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 64
  setline(64);
// Begin line 52
  setline(52);
  if (strlit125 == NULL) {
    strlit125 = alloc_String("Boolean");
  }
// compilenode returning strlit125
// Begin line 64
  setline(64);
  Object array126 = alloc_List();
// Begin line 53
  setline(53);
  if (strlit127 == NULL) {
    strlit127 = alloc_String("++");
  }
// compilenode returning strlit127
  Object array128 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array128, "push", 1, params);
// compilenode returning array128
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit127;
  params[1] = array128;
  params[2] = *var_StringIdentifier;
  Object call129 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call129
  params[0] = call129;
  callmethod(array126, "push", 1, params);
// Begin line 54
  setline(54);
  if (strlit130 == NULL) {
    strlit130 = alloc_String("&");
  }
// compilenode returning strlit130
  Object array131 = alloc_List();
// compilenode returning *var_BooleanOther
  params[0] = *var_BooleanOther;
  callmethod(array131, "push", 1, params);
// compilenode returning array131
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit130;
  params[1] = array131;
  params[2] = *var_BooleanIdentifier;
  Object call132 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call132
  params[0] = call132;
  callmethod(array126, "push", 1, params);
// Begin line 55
  setline(55);
  if (strlit133 == NULL) {
    strlit133 = alloc_String("|");
  }
// compilenode returning strlit133
  Object array134 = alloc_List();
// compilenode returning *var_BooleanOther
  params[0] = *var_BooleanOther;
  callmethod(array134, "push", 1, params);
// compilenode returning array134
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit133;
  params[1] = array134;
  params[2] = *var_BooleanIdentifier;
  Object call135 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call135
  params[0] = call135;
  callmethod(array126, "push", 1, params);
// Begin line 56
  setline(56);
  if (strlit136 == NULL) {
    strlit136 = alloc_String("&&");
  }
// compilenode returning strlit136
  Object array137 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array137, "push", 1, params);
// compilenode returning array137
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit136;
  params[1] = array137;
  params[2] = *var_BooleanIdentifier;
  Object call138 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call138
  params[0] = call138;
  callmethod(array126, "push", 1, params);
// Begin line 57
  setline(57);
  if (strlit139 == NULL) {
    strlit139 = alloc_String("||");
  }
// compilenode returning strlit139
  Object array140 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array140, "push", 1, params);
// compilenode returning array140
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit139;
  params[1] = array140;
  params[2] = *var_BooleanIdentifier;
  Object call141 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call141
  params[0] = call141;
  callmethod(array126, "push", 1, params);
// Begin line 58
  setline(58);
  if (strlit142 == NULL) {
    strlit142 = alloc_String("==");
  }
// compilenode returning strlit142
  Object array143 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array143, "push", 1, params);
// compilenode returning array143
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit142;
  params[1] = array143;
  params[2] = *var_BooleanIdentifier;
  Object call144 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call144
  params[0] = call144;
  callmethod(array126, "push", 1, params);
// Begin line 59
  setline(59);
  if (strlit145 == NULL) {
    strlit145 = alloc_String("!=");
  }
// compilenode returning strlit145
  Object array146 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array146, "push", 1, params);
// compilenode returning array146
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit145;
  params[1] = array146;
  params[2] = *var_BooleanIdentifier;
  Object call147 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call147
  params[0] = call147;
  callmethod(array126, "push", 1, params);
// Begin line 60
  setline(60);
  if (strlit148 == NULL) {
    strlit148 = alloc_String("/=");
  }
// compilenode returning strlit148
  Object array149 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array149, "push", 1, params);
// compilenode returning array149
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit148;
  params[1] = array149;
  params[2] = *var_BooleanIdentifier;
  Object call150 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call150
  params[0] = call150;
  callmethod(array126, "push", 1, params);
// Begin line 61
  setline(61);
  if (strlit151 == NULL) {
    strlit151 = alloc_String("prefix!");
  }
// compilenode returning strlit151
  Object array152 = alloc_List();
// compilenode returning array152
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit151;
  params[1] = array152;
  params[2] = *var_BooleanIdentifier;
  Object call153 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call153
  params[0] = call153;
  callmethod(array126, "push", 1, params);
// Begin line 62
  setline(62);
  if (strlit154 == NULL) {
    strlit154 = alloc_String("not");
  }
// compilenode returning strlit154
  Object array155 = alloc_List();
// compilenode returning array155
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit154;
  params[1] = array155;
  params[2] = *var_BooleanIdentifier;
  Object call156 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call156
  params[0] = call156;
  callmethod(array126, "push", 1, params);
// Begin line 63
  setline(63);
  if (strlit157 == NULL) {
    strlit157 = alloc_String("ifTrue");
  }
// compilenode returning strlit157
  Object array158 = alloc_List();
// compilenode returning *var_TopOther
  params[0] = *var_TopOther;
  callmethod(array158, "push", 1, params);
// compilenode returning array158
// compilenode returning *var_BooleanIdentifier
// compilenode returning module_ast
  params[0] = strlit157;
  params[1] = array158;
  params[2] = *var_BooleanIdentifier;
  Object call159 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call159
  params[0] = call159;
  callmethod(array126, "push", 1, params);
// Begin line 64
  setline(64);
  if (strlit160 == NULL) {
    strlit160 = alloc_String("asString");
  }
// compilenode returning strlit160
  Object array161 = alloc_List();
// compilenode returning array161
// compilenode returning *var_StringIdentifier
// compilenode returning module_ast
  params[0] = strlit160;
  params[1] = array161;
  params[2] = *var_StringIdentifier;
  Object call162 = callmethod(module_ast, "astmethodtype",
    3, params);
// compilenode returning call162
  params[0] = call162;
  callmethod(array126, "push", 1, params);
// compilenode returning array126
// Begin line 52
  setline(52);
// compilenode returning module_ast
  params[0] = strlit125;
  params[1] = array126;
  Object call163 = callmethod(module_ast, "asttype",
    2, params);
// compilenode returning call163
  *var_BooleanType = call163;
  if (call163 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 68
  setline(68);
// Begin line 66
  setline(66);
  Object bool164 = alloc_Boolean(0);
// compilenode returning bool164
  var_currentReturnType = alloc_var();
  *var_currentReturnType = bool164;
  if (bool164 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 68
  setline(68);
// Begin line 1017
  setline(1017);
  Object obj165 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj165, self, 0);
  addmethod2(obj165, "outer", &reader_typechecker_outer_166);
  adddatum2(obj165, self, 0);
  block_savedest(obj165);
  Object **closure167 = createclosure(1);
  addtoclosure(closure167, var_DynamicType);
  struct UserObject *uo167 = (struct UserObject*)obj165;
  uo167->data[1] = (Object)closure167;
  addmethod2(obj165, "new", &meth_typechecker_new167);
  set_type(obj165, 0);
// compilenode returning obj165
  *var_Binding = obj165;
  if (obj165 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// compilenode returning nothing
// Begin line 81
  setline(81);
  block_savedest(self);
  Object **closure174 = createclosure(1);
  addtoclosure(closure174, var_scopes);
  struct UserObject *uo174 = (struct UserObject*)self;
  uo174->data[1] = (Object)closure174;
  addmethod2(self, "haveBinding", &meth_typechecker_haveBinding174);
// compilenode returning 
// Begin line 93
  setline(93);
  block_savedest(self);
  Object **closure186 = createclosure(2);
  addtoclosure(closure186, var_scopes);
  addtoclosure(closure186, var_Binding);
  struct UserObject *uo186 = (struct UserObject*)self;
  uo186->data[2] = (Object)closure186;
  addmethod2(self, "findName", &meth_typechecker_findName186);
// compilenode returning 
// Begin line 111
  setline(111);
  block_savedest(self);
  Object **closure205 = createclosure(1);
  addtoclosure(closure205, var_scopes);
  struct UserObject *uo205 = (struct UserObject*)self;
  uo205->data[3] = (Object)closure205;
  addmethod2(self, "findDeepMethod", &meth_typechecker_findDeepMethod205);
// compilenode returning 
// Begin line 116
  setline(116);
  block_savedest(self);
  Object **closure241 = createclosure(2);
  addtoclosure(closure241, var_HashMap);
  addtoclosure(closure241, var_scopes);
  struct UserObject *uo241 = (struct UserObject*)self;
  uo241->data[4] = (Object)closure241;
  addmethod2(self, "pushScope", &meth_typechecker_pushScope241);
// compilenode returning 
// Begin line 120
  setline(120);
  block_savedest(self);
  Object **closure244 = createclosure(1);
  addtoclosure(closure244, var_scopes);
  struct UserObject *uo244 = (struct UserObject*)self;
  uo244->data[5] = (Object)closure244;
  addmethod2(self, "popScope", &meth_typechecker_popScope244);
// compilenode returning 
// Begin line 165
  setline(165);
  addmethod2(self, "conformsType(1)to", &meth_typechecker_conformsType_40_1_41_to246);
// compilenode returning 
// Begin line 366
  setline(366);
  block_savedest(self);
  Object **closure338 = createclosure(4);
  addtoclosure(closure338, var_BooleanType);
  addtoclosure(closure338, var_DynamicType);
  addtoclosure(closure338, var_NumberType);
  addtoclosure(closure338, var_StringType);
  struct UserObject *uo338 = (struct UserObject*)self;
  uo338->data[7] = (Object)closure338;
  addmethod2(self, "expressionType", &meth_typechecker_expressionType338);
// compilenode returning 
// Begin line 379
  setline(379);
  addmethod2(self, "checkShadowing", &meth_typechecker_checkShadowing859);
// compilenode returning 
// Begin line 385
  setline(385);
  block_savedest(self);
  Object **closure901 = createclosure(1);
  addtoclosure(closure901, var_scopes);
  struct UserObject *uo901 = (struct UserObject*)self;
  uo901->data[9] = (Object)closure901;
  addmethod2(self, "bindName", &meth_typechecker_bindName901);
// compilenode returning 
// Begin line 405
  setline(405);
  block_savedest(self);
  Object **closure906 = createclosure(3);
  addtoclosure(closure906, var_scopes);
  addtoclosure(closure906, var_Binding);
  addtoclosure(closure906, var_DynamicType);
  struct UserObject *uo906 = (struct UserObject*)self;
  uo906->data[10] = (Object)closure906;
  addmethod2(self, "bindIdentifier", &meth_typechecker_bindIdentifier906);
// compilenode returning 
// Begin line 468
  setline(468);
  addmethod2(self, "betaReduceType", &meth_typechecker_betaReduceType951);
// compilenode returning 
// Begin line 519
  setline(519);
  block_savedest(self);
  Object **closure1114 = createclosure(1);
  addtoclosure(closure1114, var_DynamicType);
  struct UserObject *uo1114 = (struct UserObject*)self;
  uo1114->data[12] = (Object)closure1114;
  addmethod2(self, "findType", &meth_typechecker_findType1114);
// compilenode returning 
// Begin line 547
  setline(547);
  addmethod2(self, "resolveIdentifier", &meth_typechecker_resolveIdentifier1208);
// compilenode returning 
// Begin line 890
  setline(890);
  block_savedest(self);
  Object **closure1267 = createclosure(3);
  addtoclosure(closure1267, var_currentReturnType);
  addtoclosure(closure1267, var_Binding);
  addtoclosure(closure1267, var_scopes);
  struct UserObject *uo1267 = (struct UserObject*)self;
  uo1267->data[14] = (Object)closure1267;
  addmethod2(self, "resolveIdentifiers", &meth_typechecker_resolveIdentifiers1267);
// compilenode returning 
// Begin line 984
  setline(984);
  block_savedest(self);
  Object **closure2133 = createclosure(3);
  addtoclosure(closure2133, var_scopes);
  addtoclosure(closure2133, var_Binding);
  addtoclosure(closure2133, var_DynamicType);
  struct UserObject *uo2133 = (struct UserObject*)self;
  uo2133->data[15] = (Object)closure2133;
  addmethod2(self, "resolveIdentifiersList(1)withBlock", &meth_typechecker_resolveIdentifiersList_40_1_41_withBlock2133);
// compilenode returning 
// Begin line 988
  setline(988);
  addmethod2(self, "resolveIdentifiersList", &meth_typechecker_resolveIdentifiersList2383);
// compilenode returning 
// Begin line 1017
  setline(1017);
  block_savedest(self);
  Object **closure2390 = createclosure(5);
  addtoclosure(closure2390, var_Binding);
  addtoclosure(closure2390, var_DynamicType);
  addtoclosure(closure2390, var_NumberType);
  addtoclosure(closure2390, var_StringType);
  addtoclosure(closure2390, var_BooleanType);
  struct UserObject *uo2390 = (struct UserObject*)self;
  uo2390->data[17] = (Object)closure2390;
  addmethod2(self, "typecheck", &meth_typechecker_typecheck2390);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_typechecker_init();
  gracelib_stats();
  return 0;
}
