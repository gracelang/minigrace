#include "gracelib.h"
#include <stdlib.h>
#pragma weak main
static char compilerRevision[] = "4df500fa93a8e8f5886b3590424a7aa67e21bf0e";
static Object undefined;
static Object nothing;
static Object argv;
Object reader_util_outer_44(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_util_outer_187(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_util_outer_230(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object reader_util_outer_498(Object self, int nparams, Object* args, int flags) {
  struct UserObject *uo = (struct UserObject*)self;
  return uo->data[0];
}
Object module_io_init();
Object module_io;
Object module_sys_init();
Object module_sys;
Object module_buildinfo_init();
Object module_buildinfo;
static Object strlit7;
static Object strlit8;
static Object strlit9;
static Object strlit15;
static Object strlit16;
static Object strlit21;
static Object strlit54;
static Object strlit58;
static Object strlit65;
static Object strlit71;
static Object strlit77;
static Object strlit88;
static Object strlit91;
static Object strlit94;
static Object strlit97;
static Object strlit99;
static Object strlit102;
static Object strlit105;
static Object strlit108;
static Object strlit114;
static Object strlit125;
static Object strlit136;
static Object strlit147;
static Object strlit150;
static Object strlit153;
static Object strlit159;
static Object strlit163;
static Object strlit168;
static Object strlit175;
static Object strlit181;
static Object strlit190;
static Object strlit195;
static Object strlit207;
static Object strlit210;
static Object strlit217;
static Object strlit221;
static Object strlit224;
static Object strlit233;
static Object strlit249;
static Object strlit252;
static Object strlit255;
static Object strlit258;
static Object strlit261;
static Object strlit270;
static Object strlit274;
static Object strlit279;
static Object strlit288;
static Object strlit292;
static Object strlit295;
static Object strlit300;
static Object strlit305;
static Object strlit312;
static Object strlit319;
static Object strlit324;
static Object strlit329;
static Object strlit333;
static Object strlit336;
static Object strlit341;
static Object strlit344;
static Object strlit349;
static Object strlit354;
static Object strlit359;
static Object strlit364;
static Object strlit371;
static Object strlit374;
static Object strlit379;
static Object strlit382;
static Object strlit387;
static Object strlit392;
static Object strlit397;
static Object strlit402;
static Object strlit408;
static Object strlit412;
static Object strlit415;
static Object strlit420;
static Object strlit423;
static Object strlit428;
static Object strlit433;
static Object strlit438;
static Object strlit443;
static Object strlit464;
static Object strlit467;
static Object strlit469;
static Object strlit494;
Object meth_util_runOnNew_40_1_41_else18(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[1];
  Object *var_b = alloc_var();
  *var_b = args[0];
  Object *var_e = alloc_var();
  *var_e = args[1];
  Object params[1];
// Begin line 28
  setline(28);
// Begin line 22
  setline(22);
  Object var_val___compilerRevision20 = alloc_String(compilerRevision);
// compilenode returning var_val___compilerRevision20
  if (strlit21 == NULL) {
    strlit21 = alloc_String("647a358cc4dcc6a3f67f3ff8e870386ef6241111");
  }
// compilenode returning strlit21
  params[0] = strlit21;
  Object opresult23 = callmethod(var_val___compilerRevision20, "/=", 1, params);
// compilenode returning opresult23
// Begin line 28
  setline(28);
// Begin line 23
  setline(23);
  Object var_val___compilerRevision24 = alloc_String(compilerRevision);
// compilenode returning var_val___compilerRevision24
  Object bool25 = alloc_Boolean(0);
// compilenode returning bool25
  params[0] = bool25;
  Object opresult27 = callmethod(var_val___compilerRevision24, "/=", 1, params);
// compilenode returning opresult27
  params[0] = opresult27;
  Object opresult29 = callmethod(opresult23, "&", 1, params);
// compilenode returning opresult29
  Object if19;
  if (istrue(opresult29)) {
// Begin line 24
  setline(24);
// Begin line 247
  setline(247);
// Begin line 24
  setline(24);
// compilenode returning *var_b
  Object call30 = callmethod(*var_b, "apply",
    0, params);
// compilenode returning call30
// compilenode returning call30
    if19 = call30;
  } else {
// Begin line 26
  setline(26);
// Begin line 247
  setline(247);
// Begin line 26
  setline(26);
// compilenode returning *var_e
  Object call31 = callmethod(*var_e, "apply",
    0, params);
// compilenode returning call31
// compilenode returning call31
    if19 = call31;
  }
// compilenode returning if19
  return if19;
}
Object meth_util_apply188(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_seeneq = closure[0];
  Object *var_extv = closure[1];
  Object *var_extn = closure[2];
  Object self = *closure[3];
// Begin line 85
  setline(85);
// Begin line 86
  setline(86);
// Begin line 78
  setline(78);
// compilenode returning *var_c
  if (strlit190 == NULL) {
    strlit190 = alloc_String("=");
  }
// compilenode returning strlit190
  params[0] = strlit190;
  Object opresult192 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult192
  Object if189;
  if (istrue(opresult192)) {
// Begin line 80
  setline(80);
// Begin line 79
  setline(79);
  Object bool193 = alloc_Boolean(1);
// compilenode returning bool193
  *var_seeneq = bool193;
  if (bool193 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 81
  setline(81);
// Begin line 80
  setline(80);
  if (strlit195 == NULL) {
    strlit195 = alloc_String("");
  }
// compilenode returning strlit195
  *var_extv = strlit195;
  if (strlit195 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if189 = nothing;
  } else {
// Begin line 85
  setline(85);
// Begin line 83
  setline(83);
// Begin line 81
  setline(81);
// compilenode returning *var_seeneq
  Object call198 = callmethod(*var_seeneq, "prefix!",
    0, params);
// compilenode returning call198
  Object if197;
  if (istrue(call198)) {
// Begin line 83
  setline(83);
// Begin line 82
  setline(82);
// compilenode returning *var_extn
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult200 = callmethod(*var_extn, "++", 1, params);
// compilenode returning opresult200
  *var_extn = opresult200;
  if (opresult200 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if197 = nothing;
  } else {
// Begin line 85
  setline(85);
// Begin line 84
  setline(84);
// compilenode returning *var_extv
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult203 = callmethod(*var_extv, "++", 1, params);
// compilenode returning opresult203
  *var_extv = opresult203;
  if (opresult203 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if197 = nothing;
  }
// compilenode returning if197
    if189 = if197;
  }
// compilenode returning if189
  return if189;
}
Object meth_util_apply231(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_c = alloc_var();
  *var_c = args[0];
  Object params[1];
  Object *var_seendot = closure[0];
  Object *var_modnamev = closure[1];
  Object self = *closure[2];
// Begin line 101
  setline(101);
// Begin line 102
  setline(102);
// Begin line 99
  setline(99);
// compilenode returning *var_c
  if (strlit233 == NULL) {
    strlit233 = alloc_String(".");
  }
// compilenode returning strlit233
  params[0] = strlit233;
  Object opresult235 = callmethod(*var_c, "==", 1, params);
// compilenode returning opresult235
  Object if232;
  if (istrue(opresult235)) {
// Begin line 101
  setline(101);
// Begin line 100
  setline(100);
  Object bool236 = alloc_Boolean(1);
// compilenode returning bool236
  *var_seendot = bool236;
  if (bool236 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if232 = nothing;
  } else {
  }
// compilenode returning if232
// Begin line 104
  setline(104);
// Begin line 105
  setline(105);
// Begin line 247
  setline(247);
// Begin line 102
  setline(102);
// compilenode returning *var_seendot
  Object call239 = callmethod(*var_seendot, "not",
    0, params);
// compilenode returning call239
// compilenode returning call239
  Object if238;
  if (istrue(call239)) {
// Begin line 104
  setline(104);
// Begin line 103
  setline(103);
// compilenode returning *var_modnamev
// compilenode returning *var_c
  params[0] = *var_c;
  Object opresult241 = callmethod(*var_modnamev, "++", 1, params);
// compilenode returning opresult241
  *var_modnamev = opresult241;
  if (opresult241 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if238 = nothing;
  } else {
  }
// compilenode returning if238
  return if238;
}
Object meth_util_apply45(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_ai = alloc_var();
  *var_ai = args[0];
  Object params[2];
  Object *var_argv = closure[0];
  Object *var_arg = closure[1];
  Object *var_skip = closure[2];
  Object *var_outfilev = closure[3];
  Object *var_verbosityv = closure[4];
  Object *var_vtagv = closure[5];
  Object *var_runmodev = closure[6];
  Object *var_buildtypev = closure[7];
  Object *var_noexecv = closure[8];
  Object *var_modnamev = closure[9];
  Object *var_gracelibPathv = closure[10];
  Object *var_targetv = closure[11];
  Object *var_versionNumber = closure[12];
  Object *var_extensionsv = closure[13];
  Object *var_infilev = closure[14];
  Object self = *closure[15];
// Begin line 37
  setline(37);
// compilenode returning *var_ai
// compilenode returning *var_argv
  params[0] = *var_ai;
  Object call46 = callmethod(*var_argv, "at",
    1, params);
// compilenode returning call46
  *var_arg = call46;
  if (call46 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 111
  setline(111);
// Begin line 38
  setline(38);
// compilenode returning *var_skip
  Object if48;
  if (istrue(*var_skip)) {
// Begin line 40
  setline(40);
// Begin line 39
  setline(39);
  Object bool49 = alloc_Boolean(0);
// compilenode returning bool49
  *var_skip = bool49;
  if (bool49 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if48 = nothing;
  } else {
// Begin line 111
  setline(111);
// Begin line 40
  setline(40);
  Object num52 = alloc_Float64(1.0);
// compilenode returning num52
// compilenode returning *var_arg
  params[0] = num52;
  Object call53 = callmethod(*var_arg, "at",
    1, params);
// compilenode returning call53
  if (strlit54 == NULL) {
    strlit54 = alloc_String("-");
  }
// compilenode returning strlit54
  params[0] = strlit54;
  Object opresult56 = callmethod(call53, "==", 1, params);
// compilenode returning opresult56
  Object if51;
  if (istrue(opresult56)) {
// Begin line 90
  setline(90);
// Begin line 92
  setline(92);
// Begin line 41
  setline(41);
// compilenode returning *var_arg
  if (strlit58 == NULL) {
    strlit58 = alloc_String("-o");
  }
// compilenode returning strlit58
  params[0] = strlit58;
  Object opresult60 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult60
  Object if57;
  if (istrue(opresult60)) {
// Begin line 42
  setline(42);
// compilenode returning *var_ai
  Object num61 = alloc_Float64(1.0);
// compilenode returning num61
  params[0] = num61;
  Object sum63 = callmethod(*var_ai, "+", 1, params);
// compilenode returning sum63
// compilenode returning *var_argv
  params[0] = sum63;
  Object call64 = callmethod(*var_argv, "at",
    1, params);
// compilenode returning call64
  if (strlit65 == NULL) {
    strlit65 = alloc_String("w");
  }
// compilenode returning strlit65
// compilenode returning module_io
  params[0] = call64;
  params[1] = strlit65;
  Object call66 = callmethod(module_io, "open",
    2, params);
// compilenode returning call66
  *var_outfilev = call66;
  if (call66 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 44
  setline(44);
// Begin line 43
  setline(43);
  Object bool68 = alloc_Boolean(1);
// compilenode returning bool68
  *var_skip = bool68;
  if (bool68 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if57 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 46
  setline(46);
// Begin line 44
  setline(44);
// compilenode returning *var_arg
  if (strlit71 == NULL) {
    strlit71 = alloc_String("--verbose");
  }
// compilenode returning strlit71
  params[0] = strlit71;
  Object opresult73 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult73
  Object if70;
  if (istrue(opresult73)) {
// Begin line 46
  setline(46);
// Begin line 45
  setline(45);
  Object num74 = alloc_Float64(40.0);
// compilenode returning num74
  *var_verbosityv = num74;
  if (num74 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if70 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 49
  setline(49);
// Begin line 46
  setline(46);
// compilenode returning *var_arg
  if (strlit77 == NULL) {
    strlit77 = alloc_String("--vtag");
  }
// compilenode returning strlit77
  params[0] = strlit77;
  Object opresult79 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult79
  Object if76;
  if (istrue(opresult79)) {
// Begin line 48
  setline(48);
// Begin line 47
  setline(47);
  Object bool80 = alloc_Boolean(1);
// compilenode returning bool80
  *var_skip = bool80;
  if (bool80 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 48
  setline(48);
// compilenode returning *var_ai
  Object num82 = alloc_Float64(1.0);
// compilenode returning num82
  params[0] = num82;
  Object sum84 = callmethod(*var_ai, "+", 1, params);
// compilenode returning sum84
// compilenode returning *var_argv
  params[0] = sum84;
  Object call85 = callmethod(*var_argv, "at",
    1, params);
// compilenode returning call85
  *var_vtagv = call85;
  if (call85 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if76 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 51
  setline(51);
// Begin line 49
  setline(49);
// compilenode returning *var_arg
  if (strlit88 == NULL) {
    strlit88 = alloc_String("--make");
  }
// compilenode returning strlit88
  params[0] = strlit88;
  Object opresult90 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult90
  Object if87;
  if (istrue(opresult90)) {
// Begin line 51
  setline(51);
// Begin line 50
  setline(50);
  if (strlit91 == NULL) {
    strlit91 = alloc_String("make");
  }
// compilenode returning strlit91
  *var_runmodev = strlit91;
  if (strlit91 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if87 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 54
  setline(54);
// Begin line 51
  setline(51);
// compilenode returning *var_arg
  if (strlit94 == NULL) {
    strlit94 = alloc_String("--run");
  }
// compilenode returning strlit94
  params[0] = strlit94;
  Object opresult96 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult96
  Object if93;
  if (istrue(opresult96)) {
// Begin line 53
  setline(53);
// Begin line 52
  setline(52);
  if (strlit97 == NULL) {
    strlit97 = alloc_String("run");
  }
// compilenode returning strlit97
  *var_buildtypev = strlit97;
  if (strlit97 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 54
  setline(54);
// Begin line 53
  setline(53);
  if (strlit99 == NULL) {
    strlit99 = alloc_String("make");
  }
// compilenode returning strlit99
  *var_runmodev = strlit99;
  if (strlit99 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if93 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 56
  setline(56);
// Begin line 54
  setline(54);
// compilenode returning *var_arg
  if (strlit102 == NULL) {
    strlit102 = alloc_String("--native");
  }
// compilenode returning strlit102
  params[0] = strlit102;
  Object opresult104 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult104
  Object if101;
  if (istrue(opresult104)) {
// Begin line 56
  setline(56);
// Begin line 55
  setline(55);
  if (strlit105 == NULL) {
    strlit105 = alloc_String("native");
  }
// compilenode returning strlit105
  *var_buildtypev = strlit105;
  if (strlit105 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if101 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 58
  setline(58);
// Begin line 56
  setline(56);
// compilenode returning *var_arg
  if (strlit108 == NULL) {
    strlit108 = alloc_String("--noexec");
  }
// compilenode returning strlit108
  params[0] = strlit108;
  Object opresult110 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult110
  Object if107;
  if (istrue(opresult110)) {
// Begin line 58
  setline(58);
// Begin line 57
  setline(57);
  Object bool111 = alloc_Boolean(1);
// compilenode returning bool111
  *var_noexecv = bool111;
  if (bool111 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if107 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 61
  setline(61);
// Begin line 58
  setline(58);
// compilenode returning *var_arg
  if (strlit114 == NULL) {
    strlit114 = alloc_String("--module");
  }
// compilenode returning strlit114
  params[0] = strlit114;
  Object opresult116 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult116
  Object if113;
  if (istrue(opresult116)) {
// Begin line 60
  setline(60);
// Begin line 59
  setline(59);
  Object bool117 = alloc_Boolean(1);
// compilenode returning bool117
  *var_skip = bool117;
  if (bool117 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 60
  setline(60);
// compilenode returning *var_ai
  Object num119 = alloc_Float64(1.0);
// compilenode returning num119
  params[0] = num119;
  Object sum121 = callmethod(*var_ai, "+", 1, params);
// compilenode returning sum121
// compilenode returning *var_argv
  params[0] = sum121;
  Object call122 = callmethod(*var_argv, "at",
    1, params);
// compilenode returning call122
  *var_modnamev = call122;
  if (call122 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if113 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 64
  setline(64);
// Begin line 61
  setline(61);
// compilenode returning *var_arg
  if (strlit125 == NULL) {
    strlit125 = alloc_String("--gracelib");
  }
// compilenode returning strlit125
  params[0] = strlit125;
  Object opresult127 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult127
  Object if124;
  if (istrue(opresult127)) {
// Begin line 63
  setline(63);
// Begin line 62
  setline(62);
  Object bool128 = alloc_Boolean(1);
// compilenode returning bool128
  *var_skip = bool128;
  if (bool128 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 63
  setline(63);
// compilenode returning *var_ai
  Object num130 = alloc_Float64(1.0);
// compilenode returning num130
  params[0] = num130;
  Object sum132 = callmethod(*var_ai, "+", 1, params);
// compilenode returning sum132
// compilenode returning *var_argv
  params[0] = sum132;
  Object call133 = callmethod(*var_argv, "at",
    1, params);
// compilenode returning call133
  *var_gracelibPathv = call133;
  if (call133 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if124 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 67
  setline(67);
// Begin line 64
  setline(64);
// compilenode returning *var_arg
  if (strlit136 == NULL) {
    strlit136 = alloc_String("--target");
  }
// compilenode returning strlit136
  params[0] = strlit136;
  Object opresult138 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult138
  Object if135;
  if (istrue(opresult138)) {
// Begin line 66
  setline(66);
// Begin line 65
  setline(65);
  Object bool139 = alloc_Boolean(1);
// compilenode returning bool139
  *var_skip = bool139;
  if (bool139 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 66
  setline(66);
// compilenode returning *var_ai
  Object num141 = alloc_Float64(1.0);
// compilenode returning num141
  params[0] = num141;
  Object sum143 = callmethod(*var_ai, "+", 1, params);
// compilenode returning sum143
// compilenode returning *var_argv
  params[0] = sum143;
  Object call144 = callmethod(*var_argv, "at",
    1, params);
// compilenode returning call144
  *var_targetv = call144;
  if (call144 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if135 = nothing;
  } else {
// Begin line 90
  setline(90);
// Begin line 72
  setline(72);
// Begin line 67
  setline(67);
// compilenode returning *var_arg
  if (strlit147 == NULL) {
    strlit147 = alloc_String("--version");
  }
// compilenode returning strlit147
  params[0] = strlit147;
  Object opresult149 = callmethod(*var_arg, "==", 1, params);
// compilenode returning opresult149
  Object if146;
  if (istrue(opresult149)) {
// Begin line 68
  setline(68);
  if (strlit150 == NULL) {
    strlit150 = alloc_String("minigrace ");
  }
// compilenode returning strlit150
// compilenode returning *var_versionNumber
  params[0] = *var_versionNumber;
  Object opresult152 = callmethod(strlit150, "++", 1, params);
// compilenode returning opresult152
  if (strlit153 == NULL) {
    strlit153 = alloc_String(".");
  }
// compilenode returning strlit153
  params[0] = strlit153;
  Object opresult155 = callmethod(opresult152, "++", 1, params);
// compilenode returning opresult155
// Begin line 247
  setline(247);
// Begin line 68
  setline(68);
// compilenode returning module_buildinfo
  Object call156 = callmethod(module_buildinfo, "gitgeneration",
    0, params);
// compilenode returning call156
// compilenode returning call156
  params[0] = call156;
  Object opresult158 = callmethod(opresult155, "++", 1, params);
// compilenode returning opresult158
  if (strlit159 == NULL) {
    strlit159 = alloc_String("");
  }
// compilenode returning strlit159
  params[0] = strlit159;
  Object opresult161 = callmethod(opresult158, "++", 1, params);
// compilenode returning opresult161
  params[0] = opresult161;
  Object call162 = gracelib_print(NULL, 1,  params);
// compilenode returning call162
// Begin line 69
  setline(69);
  if (strlit163 == NULL) {
    strlit163 = alloc_String("git revision ");
  }
// compilenode returning strlit163
// Begin line 247
  setline(247);
// Begin line 69
  setline(69);
// compilenode returning module_buildinfo
  Object call164 = callmethod(module_buildinfo, "gitrevision",
    0, params);
// compilenode returning call164
// compilenode returning call164
  params[0] = call164;
  Object opresult166 = callmethod(strlit163, "++", 1, params);
// compilenode returning opresult166
  params[0] = opresult166;
  Object call167 = gracelib_print(NULL, 1,  params);
// compilenode returning call167
// Begin line 70
  setline(70);
  if (strlit168 == NULL) {
    strlit168 = alloc_String("<http://ecs.vuw.ac.nz/~mwh/minigrace/>");
  }
// compilenode returning strlit168
  params[0] = strlit168;
  Object call169 = gracelib_print(NULL, 1,  params);
// compilenode returning call169
// Begin line 71
  setline(71);
  Object num170 = alloc_Float64(0.0);
// compilenode returning num170
// compilenode returning module_sys
  params[0] = num170;
  Object call171 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call171
    if146 = call171;
  } else {
// Begin line 90
  setline(90);
// Begin line 72
  setline(72);
  Object num173 = alloc_Float64(2.0);
// compilenode returning num173
// compilenode returning *var_arg
  params[0] = num173;
  Object call174 = callmethod(*var_arg, "at",
    1, params);
// compilenode returning call174
  if (strlit175 == NULL) {
    strlit175 = alloc_String("X");
  }
// compilenode returning strlit175
  params[0] = strlit175;
  Object opresult177 = callmethod(call174, "==", 1, params);
// compilenode returning opresult177
  Object if172;
  if (istrue(opresult177)) {
  Object *var_ext = alloc_var();
  *var_ext = undefined;
  Object *var_extn = alloc_var();
  *var_extn = undefined;
  Object *var_extv = alloc_var();
  *var_extv = undefined;
  Object *var_seeneq = alloc_var();
  *var_seeneq = undefined;
// Begin line 73
  setline(73);
  Object num178 = alloc_Float64(3.0);
// compilenode returning num178
// Begin line 247
  setline(247);
// Begin line 73
  setline(73);
// compilenode returning *var_arg
  Object call179 = callmethod(*var_arg, "size",
    0, params);
// compilenode returning call179
// compilenode returning call179
// compilenode returning *var_arg
  params[0] = num178;
  params[1] = call179;
  Object call180 = callmethod(*var_arg, "substringFrom(1)to",
    2, params);
// compilenode returning call180
  var_ext = alloc_var();
  *var_ext = call180;
  if (call180 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 75
  setline(75);
// Begin line 74
  setline(74);
  if (strlit181 == NULL) {
    strlit181 = alloc_String("");
  }
// compilenode returning strlit181
  var_extn = alloc_var();
  *var_extn = strlit181;
  if (strlit181 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 76
  setline(76);
// Begin line 75
  setline(75);
  Object bool182 = alloc_Boolean(1);
// compilenode returning bool182
  var_extv = alloc_var();
  *var_extv = bool182;
  if (bool182 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 77
  setline(77);
// Begin line 76
  setline(76);
  Object bool183 = alloc_Boolean(0);
// compilenode returning bool183
  var_seeneq = alloc_var();
  *var_seeneq = bool183;
  if (bool183 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 85
  setline(85);
// Begin line 77
  setline(77);
// compilenode returning *var_ext
// Begin line 85
  setline(85);
// Begin line 247
  setline(247);
  Object obj186 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj186, self, 0);
  addmethod2(obj186, "outer", &reader_util_outer_187);
  adddatum2(obj186, self, 0);
  block_savedest(obj186);
  Object **closure188 = createclosure(4);
  addtoclosure(closure188, var_seeneq);
  addtoclosure(closure188, var_extv);
  addtoclosure(closure188, var_extn);
  Object *selfpp205 = alloc_var();
  *selfpp205 = self;
  addtoclosure(closure188, selfpp205);
  struct UserObject *uo188 = (struct UserObject*)obj186;
  uo188->data[1] = (Object)closure188;
  addmethod2(obj186, "apply", &meth_util_apply188);
  set_type(obj186, 0);
// compilenode returning obj186
  setclassname(obj186, "Block<util:185>");
// compilenode returning obj186
  params[0] = *var_ext;
  Object iter184 = callmethod(*var_ext, "iter", 1, params);
  while(1) {
    Object cond184 = callmethod(iter184, "havemore", 0, NULL);
    if (!istrue(cond184)) break;
    params[0] = callmethod(iter184, "next", 0, NULL);
    callmethod(obj186, "apply", 1, params);
  }
// compilenode returning *var_ext
// Begin line 87
  setline(87);
// compilenode returning *var_extn
// compilenode returning *var_extv
// compilenode returning *var_extensionsv
  params[0] = *var_extn;
  params[1] = *var_extv;
  Object call206 = callmethod(*var_extensionsv, "put",
    2, params);
// compilenode returning call206
    if172 = call206;
  } else {
// Begin line 89
  setline(89);
  if (strlit207 == NULL) {
    strlit207 = alloc_String("minigrace: invalid argument ");
  }
// compilenode returning strlit207
// compilenode returning *var_arg
  params[0] = *var_arg;
  Object opresult209 = callmethod(strlit207, "++", 1, params);
// compilenode returning opresult209
  if (strlit210 == NULL) {
    strlit210 = alloc_String(".""\x0a""");
  }
// compilenode returning strlit210
  params[0] = strlit210;
  Object opresult212 = callmethod(opresult209, "++", 1, params);
// compilenode returning opresult212
// Begin line 90
  setline(90);
// Begin line 247
  setline(247);
// Begin line 89
  setline(89);
// compilenode returning module_io
  Object call213 = callmethod(module_io, "error",
    0, params);
// compilenode returning call213
// compilenode returning call213
  params[0] = opresult212;
  Object call214 = callmethod(call213, "write",
    1, params);
// compilenode returning call214
// Begin line 90
  setline(90);
  Object num215 = alloc_Float64(1.0);
// compilenode returning num215
// compilenode returning module_sys
  params[0] = num215;
  Object call216 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call216
    if172 = call216;
  }
// compilenode returning if172
    if146 = if172;
  }
// compilenode returning if146
    if135 = if146;
  }
// compilenode returning if135
    if124 = if135;
  }
// compilenode returning if124
    if113 = if124;
  }
// compilenode returning if113
    if107 = if113;
  }
// compilenode returning if107
    if101 = if107;
  }
// compilenode returning if101
    if93 = if101;
  }
// compilenode returning if93
    if87 = if93;
  }
// compilenode returning if87
    if76 = if87;
  }
// compilenode returning if76
    if70 = if76;
  }
// compilenode returning if70
    if57 = if70;
  }
// compilenode returning if57
    if51 = if57;
  } else {
  Object *var_filename = alloc_var();
  *var_filename = undefined;
// Begin line 94
  setline(94);
// Begin line 93
  setline(93);
// compilenode returning *var_arg
  var_filename = alloc_var();
  *var_filename = *var_arg;
  if (*var_arg == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 94
  setline(94);
// compilenode returning *var_filename
  if (strlit217 == NULL) {
    strlit217 = alloc_String("r");
  }
// compilenode returning strlit217
// compilenode returning module_io
  params[0] = *var_filename;
  params[1] = strlit217;
  Object call218 = callmethod(module_io, "open",
    2, params);
// compilenode returning call218
  *var_infilev = call218;
  if (call218 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 104
  setline(104);
// Begin line 107
  setline(107);
// Begin line 95
  setline(95);
// compilenode returning *var_modnamev
  if (strlit221 == NULL) {
    strlit221 = alloc_String("main");
  }
// compilenode returning strlit221
  params[0] = strlit221;
  Object opresult223 = callmethod(*var_modnamev, "==", 1, params);
// compilenode returning opresult223
  Object if220;
  if (istrue(opresult223)) {
  Object *var_seendot = alloc_var();
  *var_seendot = undefined;
// Begin line 97
  setline(97);
// Begin line 96
  setline(96);
  if (strlit224 == NULL) {
    strlit224 = alloc_String("");
  }
// compilenode returning strlit224
  *var_modnamev = strlit224;
  if (strlit224 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 98
  setline(98);
// Begin line 97
  setline(97);
  Object bool226 = alloc_Boolean(0);
// compilenode returning bool226
  var_seendot = alloc_var();
  *var_seendot = bool226;
  if (bool226 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 104
  setline(104);
// Begin line 98
  setline(98);
// compilenode returning *var_filename
// Begin line 104
  setline(104);
// Begin line 247
  setline(247);
  Object obj229 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj229, self, 0);
  addmethod2(obj229, "outer", &reader_util_outer_230);
  adddatum2(obj229, self, 0);
  block_savedest(obj229);
  Object **closure231 = createclosure(3);
  addtoclosure(closure231, var_seendot);
  addtoclosure(closure231, var_modnamev);
  Object *selfpp243 = alloc_var();
  *selfpp243 = self;
  addtoclosure(closure231, selfpp243);
  struct UserObject *uo231 = (struct UserObject*)obj229;
  uo231->data[1] = (Object)closure231;
  addmethod2(obj229, "apply", &meth_util_apply231);
  set_type(obj229, 0);
// compilenode returning obj229
  setclassname(obj229, "Block<util:228>");
// compilenode returning obj229
  params[0] = *var_filename;
  Object iter227 = callmethod(*var_filename, "iter", 1, params);
  while(1) {
    Object cond227 = callmethod(iter227, "havemore", 0, NULL);
    if (!istrue(cond227)) break;
    params[0] = callmethod(iter227, "next", 0, NULL);
    callmethod(obj229, "apply", 1, params);
  }
// compilenode returning *var_filename
    if220 = *var_filename;
  } else {
  }
// compilenode returning if220
// Begin line 111
  setline(111);
// Begin line 114
  setline(114);
// Begin line 107
  setline(107);
// compilenode returning *var_outfilev
// Begin line 114
  setline(114);
// Begin line 247
  setline(247);
// Begin line 107
  setline(107);
// compilenode returning module_io
  Object call245 = callmethod(module_io, "output",
    0, params);
// compilenode returning call245
// compilenode returning call245
  params[0] = call245;
  Object opresult247 = callmethod(*var_outfilev, "==", 1, params);
// compilenode returning opresult247
  Object if244;
  if (istrue(opresult247)) {
// Begin line 111
  setline(111);
// Begin line 113
  setline(113);
// Begin line 108
  setline(108);
// compilenode returning *var_targetv
  if (strlit249 == NULL) {
    strlit249 = alloc_String("c");
  }
// compilenode returning strlit249
  params[0] = strlit249;
  Object opresult251 = callmethod(*var_targetv, "==", 1, params);
// compilenode returning opresult251
  Object if248;
  if (istrue(opresult251)) {
// Begin line 109
  setline(109);
// compilenode returning *var_modnamev
  if (strlit252 == NULL) {
    strlit252 = alloc_String(".c");
  }
// compilenode returning strlit252
  params[0] = strlit252;
  Object opresult254 = callmethod(*var_modnamev, "++", 1, params);
// compilenode returning opresult254
  if (strlit255 == NULL) {
    strlit255 = alloc_String("w");
  }
// compilenode returning strlit255
// compilenode returning module_io
  params[0] = opresult254;
  params[1] = strlit255;
  Object call256 = callmethod(module_io, "open",
    2, params);
// compilenode returning call256
  *var_outfilev = call256;
  if (call256 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if248 = nothing;
  } else {
// Begin line 111
  setline(111);
// compilenode returning *var_modnamev
  if (strlit258 == NULL) {
    strlit258 = alloc_String(".ll");
  }
// compilenode returning strlit258
  params[0] = strlit258;
  Object opresult260 = callmethod(*var_modnamev, "++", 1, params);
// compilenode returning opresult260
  if (strlit261 == NULL) {
    strlit261 = alloc_String("w");
  }
// compilenode returning strlit261
// compilenode returning module_io
  params[0] = opresult260;
  params[1] = strlit261;
  Object call262 = callmethod(module_io, "open",
    2, params);
// compilenode returning call262
  *var_outfilev = call262;
  if (call262 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if248 = nothing;
  }
// compilenode returning if248
    if244 = if248;
  } else {
  }
// compilenode returning if244
    if51 = if244;
  }
// compilenode returning if51
    if48 = if51;
  }
// compilenode returning if48
  return if48;
}
Object meth_util_parseargs32(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[2];
  Object params[1];
  Object *var_outfilev = closure[0];
  Object *var_verbosityv = closure[1];
  Object *var_vtagv = closure[2];
  Object *var_runmodev = closure[3];
  Object *var_buildtypev = closure[4];
  Object *var_noexecv = closure[5];
  Object *var_modnamev = closure[6];
  Object *var_gracelibPathv = closure[7];
  Object *var_targetv = closure[8];
  Object *var_versionNumber = closure[9];
  Object *var_extensionsv = closure[10];
  Object *var_infilev = closure[11];
  Object *var_argv = alloc_var();
  *var_argv = undefined;
// Begin line 32
  setline(32);
// Begin line 247
  setline(247);
// Begin line 31
  setline(31);
// compilenode returning module_sys
  Object call33 = callmethod(module_sys, "argv",
    0, params);
// compilenode returning call33
// compilenode returning call33
  var_argv = alloc_var();
  *var_argv = call33;
  if (call33 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 111
  setline(111);
// Begin line 117
  setline(117);
// Begin line 247
  setline(247);
// Begin line 32
  setline(32);
// compilenode returning *var_argv
  Object call35 = callmethod(*var_argv, "size",
    0, params);
// compilenode returning call35
// compilenode returning call35
  Object num36 = alloc_Float64(1.0);
// compilenode returning num36
  params[0] = num36;
  Object opresult38 = callmethod(call35, ">", 1, params);
// compilenode returning opresult38
  Object if34;
  if (istrue(opresult38)) {
  Object *var_indices = alloc_var();
  *var_indices = undefined;
  Object *var_arg = alloc_var();
  *var_arg = undefined;
  Object *var_skip = alloc_var();
  *var_skip = undefined;
// Begin line 34
  setline(34);
// Begin line 247
  setline(247);
// Begin line 33
  setline(33);
// compilenode returning *var_argv
  Object call39 = callmethod(*var_argv, "indices",
    0, params);
// compilenode returning call39
// compilenode returning call39
  var_indices = alloc_var();
  *var_indices = call39;
  if (call39 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 35
  setline(35);
  var_arg = alloc_var();
  *var_arg = undefined;
// compilenode returning nothing
// Begin line 36
  setline(36);
// Begin line 35
  setline(35);
  Object bool40 = alloc_Boolean(1);
// compilenode returning bool40
  var_skip = alloc_var();
  *var_skip = bool40;
  if (bool40 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 111
  setline(111);
// Begin line 36
  setline(36);
// compilenode returning *var_indices
// Begin line 111
  setline(111);
// Begin line 247
  setline(247);
  Object obj43 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj43, self, 0);
  addmethod2(obj43, "outer", &reader_util_outer_44);
  adddatum2(obj43, self, 0);
  block_savedest(obj43);
  Object **closure45 = createclosure(16);
  addtoclosure(closure45, var_argv);
  addtoclosure(closure45, var_arg);
  addtoclosure(closure45, var_skip);
  addtoclosure(closure45, var_outfilev);
  addtoclosure(closure45, var_verbosityv);
  addtoclosure(closure45, var_vtagv);
  addtoclosure(closure45, var_runmodev);
  addtoclosure(closure45, var_buildtypev);
  addtoclosure(closure45, var_noexecv);
  addtoclosure(closure45, var_modnamev);
  addtoclosure(closure45, var_gracelibPathv);
  addtoclosure(closure45, var_targetv);
  addtoclosure(closure45, var_versionNumber);
  addtoclosure(closure45, var_extensionsv);
  addtoclosure(closure45, var_infilev);
  Object *selfpp264 = alloc_var();
  *selfpp264 = self;
  addtoclosure(closure45, selfpp264);
  struct UserObject *uo45 = (struct UserObject*)obj43;
  uo45->data[1] = (Object)closure45;
  addmethod2(obj43, "apply", &meth_util_apply45);
  set_type(obj43, 0);
// compilenode returning obj43
  setclassname(obj43, "Block<util:42>");
// compilenode returning obj43
  params[0] = *var_indices;
  Object iter41 = callmethod(*var_indices, "iter", 1, params);
  while(1) {
    Object cond41 = callmethod(iter41, "havemore", 0, NULL);
    if (!istrue(cond41)) break;
    params[0] = callmethod(iter41, "next", 0, NULL);
    callmethod(obj43, "apply", 1, params);
  }
// compilenode returning *var_indices
    if34 = *var_indices;
  } else {
  }
// compilenode returning if34
// Begin line 122
  setline(122);
// Begin line 124
  setline(124);
// Begin line 117
  setline(117);
// compilenode returning *var_gracelibPathv
  Object bool266 = alloc_Boolean(0);
// compilenode returning bool266
  params[0] = bool266;
  Object opresult268 = callmethod(*var_gracelibPathv, "==", 1, params);
// compilenode returning opresult268
  Object if265;
  if (istrue(opresult268)) {
// Begin line 122
  setline(122);
// Begin line 123
  setline(123);
// Begin line 118
  setline(118);
// compilenode returning *var_targetv
  if (strlit270 == NULL) {
    strlit270 = alloc_String("llvm");
  }
// compilenode returning strlit270
  params[0] = strlit270;
  Object opresult272 = callmethod(*var_targetv, "==", 1, params);
// compilenode returning opresult272
  Object if269;
  if (istrue(opresult272)) {
// Begin line 120
  setline(120);
// Begin line 247
  setline(247);
// Begin line 119
  setline(119);
// compilenode returning module_sys
  Object call273 = callmethod(module_sys, "execPath",
    0, params);
// compilenode returning call273
// compilenode returning call273
  if (strlit274 == NULL) {
    strlit274 = alloc_String("/gracelib.bc");
  }
// compilenode returning strlit274
  params[0] = strlit274;
  Object opresult276 = callmethod(call273, "++", 1, params);
// compilenode returning opresult276
  *var_gracelibPathv = opresult276;
  if (opresult276 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if269 = nothing;
  } else {
// Begin line 122
  setline(122);
// Begin line 247
  setline(247);
// Begin line 121
  setline(121);
// compilenode returning module_sys
  Object call278 = callmethod(module_sys, "execPath",
    0, params);
// compilenode returning call278
// compilenode returning call278
  if (strlit279 == NULL) {
    strlit279 = alloc_String("/gracelib.o");
  }
// compilenode returning strlit279
  params[0] = strlit279;
  Object opresult281 = callmethod(call278, "++", 1, params);
// compilenode returning opresult281
  *var_gracelibPathv = opresult281;
  if (opresult281 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if269 = nothing;
  }
// compilenode returning if269
    if265 = if269;
  } else {
  }
// compilenode returning if265
  return if265;
}
Object meth_util_log_verbose283(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[3];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_verbosityv = closure[0];
  Object *var_vtagv = closure[1];
  Object *var_modnamev = closure[2];
// Begin line 142
  setline(142);
// Begin line 127
  setline(127);
// compilenode returning *var_verbosityv
  Object num285 = alloc_Float64(40.0);
// compilenode returning num285
  params[0] = num285;
  Object opresult287 = callmethod(*var_verbosityv, ">=", 1, params);
// compilenode returning opresult287
  Object if284;
  if (istrue(opresult287)) {
// Begin line 128
  setline(128);
  if (strlit288 == NULL) {
    strlit288 = alloc_String("minigrace");
  }
// compilenode returning strlit288
// Begin line 129
  setline(129);
// Begin line 247
  setline(247);
// Begin line 128
  setline(128);
// compilenode returning module_io
  Object call289 = callmethod(module_io, "error",
    0, params);
// compilenode returning call289
// compilenode returning call289
  params[0] = strlit288;
  Object call290 = callmethod(call289, "write",
    1, params);
// compilenode returning call290
// Begin line 130
  setline(130);
// Begin line 129
  setline(129);
// compilenode returning *var_vtagv
  Object if291;
  if (istrue(*var_vtagv)) {
// Begin line 130
  setline(130);
  if (strlit292 == NULL) {
    strlit292 = alloc_String("[");
  }
// compilenode returning strlit292
// compilenode returning *var_vtagv
  params[0] = *var_vtagv;
  Object opresult294 = callmethod(strlit292, "++", 1, params);
// compilenode returning opresult294
  if (strlit295 == NULL) {
    strlit295 = alloc_String("]");
  }
// compilenode returning strlit295
  params[0] = strlit295;
  Object opresult297 = callmethod(opresult294, "++", 1, params);
// compilenode returning opresult297
// Begin line 131
  setline(131);
// Begin line 247
  setline(247);
// Begin line 130
  setline(130);
// compilenode returning module_io
  Object call298 = callmethod(module_io, "error",
    0, params);
// compilenode returning call298
// compilenode returning call298
  params[0] = opresult297;
  Object call299 = callmethod(call298, "write",
    1, params);
// compilenode returning call299
    if291 = call299;
  } else {
  }
// compilenode returning if291
// Begin line 132
  setline(132);
  if (strlit300 == NULL) {
    strlit300 = alloc_String(": ");
  }
// compilenode returning strlit300
// Begin line 133
  setline(133);
// Begin line 247
  setline(247);
// Begin line 132
  setline(132);
// compilenode returning module_io
  Object call301 = callmethod(module_io, "error",
    0, params);
// compilenode returning call301
// compilenode returning call301
  params[0] = strlit300;
  Object call302 = callmethod(call301, "write",
    1, params);
// compilenode returning call302
// Begin line 133
  setline(133);
// compilenode returning *var_modnamev
// Begin line 134
  setline(134);
// Begin line 247
  setline(247);
// Begin line 133
  setline(133);
// compilenode returning module_io
  Object call303 = callmethod(module_io, "error",
    0, params);
// compilenode returning call303
// compilenode returning call303
  params[0] = *var_modnamev;
  Object call304 = callmethod(call303, "write",
    1, params);
// compilenode returning call304
// Begin line 134
  setline(134);
  if (strlit305 == NULL) {
    strlit305 = alloc_String(": ");
  }
// compilenode returning strlit305
// Begin line 135
  setline(135);
// Begin line 247
  setline(247);
// Begin line 134
  setline(134);
// compilenode returning module_io
  Object call306 = callmethod(module_io, "error",
    0, params);
// compilenode returning call306
// compilenode returning call306
  params[0] = strlit305;
  Object call307 = callmethod(call306, "write",
    1, params);
// compilenode returning call307
// Begin line 135
  setline(135);
// Begin line 247
  setline(247);
// Begin line 135
  setline(135);
// Begin line 247
  setline(247);
// Begin line 135
  setline(135);
// compilenode returning module_sys
  Object call308 = callmethod(module_sys, "cputime",
    0, params);
// compilenode returning call308
// compilenode returning call308
  Object call309 = callmethod(call308, "asString",
    0, params);
// compilenode returning call309
// compilenode returning call309
// Begin line 136
  setline(136);
// Begin line 247
  setline(247);
// Begin line 135
  setline(135);
// compilenode returning module_io
  Object call310 = callmethod(module_io, "error",
    0, params);
// compilenode returning call310
// compilenode returning call310
  params[0] = call309;
  Object call311 = callmethod(call310, "write",
    1, params);
// compilenode returning call311
// Begin line 136
  setline(136);
  if (strlit312 == NULL) {
    strlit312 = alloc_String("/");
  }
// compilenode returning strlit312
// Begin line 137
  setline(137);
// Begin line 247
  setline(247);
// Begin line 136
  setline(136);
// compilenode returning module_io
  Object call313 = callmethod(module_io, "error",
    0, params);
// compilenode returning call313
// compilenode returning call313
  params[0] = strlit312;
  Object call314 = callmethod(call313, "write",
    1, params);
// compilenode returning call314
// Begin line 137
  setline(137);
// Begin line 247
  setline(247);
// Begin line 137
  setline(137);
// Begin line 247
  setline(247);
// Begin line 137
  setline(137);
// compilenode returning module_sys
  Object call315 = callmethod(module_sys, "elapsed",
    0, params);
// compilenode returning call315
// compilenode returning call315
  Object call316 = callmethod(call315, "asString",
    0, params);
// compilenode returning call316
// compilenode returning call316
// Begin line 138
  setline(138);
// Begin line 247
  setline(247);
// Begin line 137
  setline(137);
// compilenode returning module_io
  Object call317 = callmethod(module_io, "error",
    0, params);
// compilenode returning call317
// compilenode returning call317
  params[0] = call316;
  Object call318 = callmethod(call317, "write",
    1, params);
// compilenode returning call318
// Begin line 138
  setline(138);
  if (strlit319 == NULL) {
    strlit319 = alloc_String(": ");
  }
// compilenode returning strlit319
// Begin line 139
  setline(139);
// Begin line 247
  setline(247);
// Begin line 138
  setline(138);
// compilenode returning module_io
  Object call320 = callmethod(module_io, "error",
    0, params);
// compilenode returning call320
// compilenode returning call320
  params[0] = strlit319;
  Object call321 = callmethod(call320, "write",
    1, params);
// compilenode returning call321
// Begin line 139
  setline(139);
// compilenode returning *var_s
// Begin line 140
  setline(140);
// Begin line 247
  setline(247);
// Begin line 139
  setline(139);
// compilenode returning module_io
  Object call322 = callmethod(module_io, "error",
    0, params);
// compilenode returning call322
// compilenode returning call322
  params[0] = *var_s;
  Object call323 = callmethod(call322, "write",
    1, params);
// compilenode returning call323
// Begin line 140
  setline(140);
  if (strlit324 == NULL) {
    strlit324 = alloc_String("""\x0a""");
  }
// compilenode returning strlit324
// Begin line 141
  setline(141);
// Begin line 247
  setline(247);
// Begin line 140
  setline(140);
// compilenode returning module_io
  Object call325 = callmethod(module_io, "error",
    0, params);
// compilenode returning call325
// compilenode returning call325
  params[0] = strlit324;
  Object call326 = callmethod(call325, "write",
    1, params);
// compilenode returning call326
    if284 = call326;
  } else {
  }
// compilenode returning if284
  return if284;
}
Object meth_util_outprint327(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[4];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_outfilev = closure[0];
// Begin line 145
  setline(145);
// compilenode returning *var_s
// compilenode returning *var_outfilev
  params[0] = *var_s;
  Object call328 = callmethod(*var_outfilev, "write",
    1, params);
// compilenode returning call328
// Begin line 146
  setline(146);
  if (strlit329 == NULL) {
    strlit329 = alloc_String("""\x0a""");
  }
// compilenode returning strlit329
// compilenode returning *var_outfilev
  params[0] = strlit329;
  Object call330 = callmethod(*var_outfilev, "write",
    1, params);
// compilenode returning call330
  return call330;
}
Object meth_util_syntax_error331(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[5];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_vtagv = closure[0];
  Object *var_modnamev = closure[1];
  Object *var_linenumv = closure[2];
  Object *var_lineposv = closure[3];
// Begin line 150
  setline(150);
// Begin line 149
  setline(149);
// compilenode returning *var_vtagv
  Object if332;
  if (istrue(*var_vtagv)) {
// Begin line 150
  setline(150);
  if (strlit333 == NULL) {
    strlit333 = alloc_String("[");
  }
// compilenode returning strlit333
// compilenode returning *var_vtagv
  params[0] = *var_vtagv;
  Object opresult335 = callmethod(strlit333, "++", 1, params);
// compilenode returning opresult335
  if (strlit336 == NULL) {
    strlit336 = alloc_String("]");
  }
// compilenode returning strlit336
  params[0] = strlit336;
  Object opresult338 = callmethod(opresult335, "++", 1, params);
// compilenode returning opresult338
// Begin line 151
  setline(151);
// Begin line 247
  setline(247);
// Begin line 150
  setline(150);
// compilenode returning module_io
  Object call339 = callmethod(module_io, "error",
    0, params);
// compilenode returning call339
// compilenode returning call339
  params[0] = opresult338;
  Object call340 = callmethod(call339, "write",
    1, params);
// compilenode returning call340
    if332 = call340;
  } else {
  }
// compilenode returning if332
// Begin line 152
  setline(152);
  if (strlit341 == NULL) {
    strlit341 = alloc_String("");
  }
// compilenode returning strlit341
// compilenode returning *var_modnamev
  params[0] = *var_modnamev;
  Object opresult343 = callmethod(strlit341, "++", 1, params);
// compilenode returning opresult343
  if (strlit344 == NULL) {
    strlit344 = alloc_String(".grace:");
  }
// compilenode returning strlit344
  params[0] = strlit344;
  Object opresult346 = callmethod(opresult343, "++", 1, params);
// compilenode returning opresult346
// compilenode returning *var_linenumv
  params[0] = *var_linenumv;
  Object opresult348 = callmethod(opresult346, "++", 1, params);
// compilenode returning opresult348
  if (strlit349 == NULL) {
    strlit349 = alloc_String(":");
  }
// compilenode returning strlit349
  params[0] = strlit349;
  Object opresult351 = callmethod(opresult348, "++", 1, params);
// compilenode returning opresult351
// compilenode returning *var_lineposv
  params[0] = *var_lineposv;
  Object opresult353 = callmethod(opresult351, "++", 1, params);
// compilenode returning opresult353
  if (strlit354 == NULL) {
    strlit354 = alloc_String(": Syntax error: ");
  }
// compilenode returning strlit354
  params[0] = strlit354;
  Object opresult356 = callmethod(opresult353, "++", 1, params);
// compilenode returning opresult356
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult358 = callmethod(opresult356, "++", 1, params);
// compilenode returning opresult358
  if (strlit359 == NULL) {
    strlit359 = alloc_String("");
  }
// compilenode returning strlit359
  params[0] = strlit359;
  Object opresult361 = callmethod(opresult358, "++", 1, params);
// compilenode returning opresult361
// Begin line 153
  setline(153);
// Begin line 247
  setline(247);
// Begin line 152
  setline(152);
// compilenode returning module_io
  Object call362 = callmethod(module_io, "error",
    0, params);
// compilenode returning call362
// compilenode returning call362
  params[0] = opresult361;
  Object call363 = callmethod(call362, "write",
    1, params);
// compilenode returning call363
// Begin line 153
  setline(153);
  if (strlit364 == NULL) {
    strlit364 = alloc_String("""\x0a""");
  }
// compilenode returning strlit364
// Begin line 154
  setline(154);
// Begin line 247
  setline(247);
// Begin line 153
  setline(153);
// compilenode returning module_io
  Object call365 = callmethod(module_io, "error",
    0, params);
// compilenode returning call365
// compilenode returning call365
  params[0] = strlit364;
  Object call366 = callmethod(call365, "write",
    1, params);
// compilenode returning call366
// Begin line 154
  setline(154);
  Object num367 = alloc_Float64(1.0);
// compilenode returning num367
// compilenode returning module_sys
  params[0] = num367;
  Object call368 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call368
  return call368;
}
Object meth_util_type_error369(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[6];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_vtagv = closure[0];
  Object *var_modnamev = closure[1];
  Object *var_linenumv = closure[2];
  Object *var_lineposv = closure[3];
// Begin line 158
  setline(158);
// Begin line 157
  setline(157);
// compilenode returning *var_vtagv
  Object if370;
  if (istrue(*var_vtagv)) {
// Begin line 158
  setline(158);
  if (strlit371 == NULL) {
    strlit371 = alloc_String("[");
  }
// compilenode returning strlit371
// compilenode returning *var_vtagv
  params[0] = *var_vtagv;
  Object opresult373 = callmethod(strlit371, "++", 1, params);
// compilenode returning opresult373
  if (strlit374 == NULL) {
    strlit374 = alloc_String("]");
  }
// compilenode returning strlit374
  params[0] = strlit374;
  Object opresult376 = callmethod(opresult373, "++", 1, params);
// compilenode returning opresult376
// Begin line 159
  setline(159);
// Begin line 247
  setline(247);
// Begin line 158
  setline(158);
// compilenode returning module_io
  Object call377 = callmethod(module_io, "error",
    0, params);
// compilenode returning call377
// compilenode returning call377
  params[0] = opresult376;
  Object call378 = callmethod(call377, "write",
    1, params);
// compilenode returning call378
    if370 = call378;
  } else {
  }
// compilenode returning if370
// Begin line 160
  setline(160);
  if (strlit379 == NULL) {
    strlit379 = alloc_String("");
  }
// compilenode returning strlit379
// compilenode returning *var_modnamev
  params[0] = *var_modnamev;
  Object opresult381 = callmethod(strlit379, "++", 1, params);
// compilenode returning opresult381
  if (strlit382 == NULL) {
    strlit382 = alloc_String(".grace:");
  }
// compilenode returning strlit382
  params[0] = strlit382;
  Object opresult384 = callmethod(opresult381, "++", 1, params);
// compilenode returning opresult384
// compilenode returning *var_linenumv
  params[0] = *var_linenumv;
  Object opresult386 = callmethod(opresult384, "++", 1, params);
// compilenode returning opresult386
  if (strlit387 == NULL) {
    strlit387 = alloc_String(":");
  }
// compilenode returning strlit387
  params[0] = strlit387;
  Object opresult389 = callmethod(opresult386, "++", 1, params);
// compilenode returning opresult389
// compilenode returning *var_lineposv
  params[0] = *var_lineposv;
  Object opresult391 = callmethod(opresult389, "++", 1, params);
// compilenode returning opresult391
  if (strlit392 == NULL) {
    strlit392 = alloc_String(": Type error: ");
  }
// compilenode returning strlit392
  params[0] = strlit392;
  Object opresult394 = callmethod(opresult391, "++", 1, params);
// compilenode returning opresult394
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult396 = callmethod(opresult394, "++", 1, params);
// compilenode returning opresult396
  if (strlit397 == NULL) {
    strlit397 = alloc_String("");
  }
// compilenode returning strlit397
  params[0] = strlit397;
  Object opresult399 = callmethod(opresult396, "++", 1, params);
// compilenode returning opresult399
// Begin line 161
  setline(161);
// Begin line 247
  setline(247);
// Begin line 160
  setline(160);
// compilenode returning module_io
  Object call400 = callmethod(module_io, "error",
    0, params);
// compilenode returning call400
// compilenode returning call400
  params[0] = opresult399;
  Object call401 = callmethod(call400, "write",
    1, params);
// compilenode returning call401
// Begin line 161
  setline(161);
  if (strlit402 == NULL) {
    strlit402 = alloc_String("""\x0a""");
  }
// compilenode returning strlit402
// Begin line 162
  setline(162);
// Begin line 247
  setline(247);
// Begin line 161
  setline(161);
// compilenode returning module_io
  Object call403 = callmethod(module_io, "error",
    0, params);
// compilenode returning call403
// compilenode returning call403
  params[0] = strlit402;
  Object call404 = callmethod(call403, "write",
    1, params);
// compilenode returning call404
// Begin line 162
  setline(162);
  Object num405 = alloc_Float64(1.0);
// compilenode returning num405
// compilenode returning module_sys
  params[0] = num405;
  Object call406 = callmethod(module_sys, "exit",
    1, params);
// compilenode returning call406
  return call406;
}
Object meth_util_warning407(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[7];
  Object *var_s = alloc_var();
  *var_s = args[0];
  Object params[1];
  Object *var_vtagv = closure[0];
  Object *var_modnamev = closure[1];
  Object *var_linenumv = closure[2];
  Object *var_lineposv = closure[3];
// Begin line 165
  setline(165);
  if (strlit408 == NULL) {
    strlit408 = alloc_String("minigrace");
  }
// compilenode returning strlit408
// Begin line 166
  setline(166);
// Begin line 247
  setline(247);
// Begin line 165
  setline(165);
// compilenode returning module_io
  Object call409 = callmethod(module_io, "error",
    0, params);
// compilenode returning call409
// compilenode returning call409
  params[0] = strlit408;
  Object call410 = callmethod(call409, "write",
    1, params);
// compilenode returning call410
// Begin line 167
  setline(167);
// Begin line 166
  setline(166);
// compilenode returning *var_vtagv
  Object if411;
  if (istrue(*var_vtagv)) {
// Begin line 167
  setline(167);
  if (strlit412 == NULL) {
    strlit412 = alloc_String("[");
  }
// compilenode returning strlit412
// compilenode returning *var_vtagv
  params[0] = *var_vtagv;
  Object opresult414 = callmethod(strlit412, "++", 1, params);
// compilenode returning opresult414
  if (strlit415 == NULL) {
    strlit415 = alloc_String("]");
  }
// compilenode returning strlit415
  params[0] = strlit415;
  Object opresult417 = callmethod(opresult414, "++", 1, params);
// compilenode returning opresult417
// Begin line 168
  setline(168);
// Begin line 247
  setline(247);
// Begin line 167
  setline(167);
// compilenode returning module_io
  Object call418 = callmethod(module_io, "error",
    0, params);
// compilenode returning call418
// compilenode returning call418
  params[0] = opresult417;
  Object call419 = callmethod(call418, "write",
    1, params);
// compilenode returning call419
    if411 = call419;
  } else {
  }
// compilenode returning if411
// Begin line 169
  setline(169);
  if (strlit420 == NULL) {
    strlit420 = alloc_String("");
  }
// compilenode returning strlit420
// compilenode returning *var_modnamev
  params[0] = *var_modnamev;
  Object opresult422 = callmethod(strlit420, "++", 1, params);
// compilenode returning opresult422
  if (strlit423 == NULL) {
    strlit423 = alloc_String(".grace:");
  }
// compilenode returning strlit423
  params[0] = strlit423;
  Object opresult425 = callmethod(opresult422, "++", 1, params);
// compilenode returning opresult425
// compilenode returning *var_linenumv
  params[0] = *var_linenumv;
  Object opresult427 = callmethod(opresult425, "++", 1, params);
// compilenode returning opresult427
  if (strlit428 == NULL) {
    strlit428 = alloc_String(":");
  }
// compilenode returning strlit428
  params[0] = strlit428;
  Object opresult430 = callmethod(opresult427, "++", 1, params);
// compilenode returning opresult430
// compilenode returning *var_lineposv
  params[0] = *var_lineposv;
  Object opresult432 = callmethod(opresult430, "++", 1, params);
// compilenode returning opresult432
  if (strlit433 == NULL) {
    strlit433 = alloc_String(": warning: ");
  }
// compilenode returning strlit433
  params[0] = strlit433;
  Object opresult435 = callmethod(opresult432, "++", 1, params);
// compilenode returning opresult435
// compilenode returning *var_s
  params[0] = *var_s;
  Object opresult437 = callmethod(opresult435, "++", 1, params);
// compilenode returning opresult437
  if (strlit438 == NULL) {
    strlit438 = alloc_String("");
  }
// compilenode returning strlit438
  params[0] = strlit438;
  Object opresult440 = callmethod(opresult437, "++", 1, params);
// compilenode returning opresult440
// Begin line 170
  setline(170);
// Begin line 247
  setline(247);
// Begin line 169
  setline(169);
// compilenode returning module_io
  Object call441 = callmethod(module_io, "error",
    0, params);
// compilenode returning call441
// compilenode returning call441
  params[0] = opresult440;
  Object call442 = callmethod(call441, "write",
    1, params);
// compilenode returning call442
// Begin line 170
  setline(170);
  if (strlit443 == NULL) {
    strlit443 = alloc_String("""\x0a""");
  }
// compilenode returning strlit443
// Begin line 171
  setline(171);
// Begin line 247
  setline(247);
// Begin line 170
  setline(170);
// compilenode returning module_io
  Object call444 = callmethod(module_io, "error",
    0, params);
// compilenode returning call444
// compilenode returning call444
  params[0] = strlit443;
  Object call445 = callmethod(call444, "write",
    1, params);
// compilenode returning call445
  return call445;
}
Object meth_util_verbosity446(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[8];
  Object params[1];
  Object *var_verbosityv = closure[0];
// compilenode returning *var_verbosityv
  return *var_verbosityv;
}
Object meth_util_outfile447(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[9];
  Object params[1];
  Object *var_outfilev = closure[0];
// compilenode returning *var_outfilev
  return *var_outfilev;
}
Object meth_util_infile448(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[10];
  Object params[1];
  Object *var_infilev = closure[0];
// compilenode returning *var_infilev
  return *var_infilev;
}
Object meth_util_modname449(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[11];
  Object params[1];
  Object *var_modnamev = closure[0];
// compilenode returning *var_modnamev
  return *var_modnamev;
}
Object meth_util_runmode450(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[12];
  Object params[1];
  Object *var_runmodev = closure[0];
// compilenode returning *var_runmodev
  return *var_runmodev;
}
Object meth_util_buildtype451(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[13];
  Object params[1];
  Object *var_buildtypev = closure[0];
// compilenode returning *var_buildtypev
  return *var_buildtypev;
}
Object meth_util_gracelibPath452(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[14];
  Object params[1];
  Object *var_gracelibPathv = closure[0];
// compilenode returning *var_gracelibPathv
  return *var_gracelibPathv;
}
Object meth_util_setline453(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[15];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object params[1];
  Object *var_linenumv = closure[0];
// Begin line 195
  setline(195);
// compilenode returning *var_l
  *var_linenumv = *var_l;
  if (*var_l == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_util_setPosition455(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[16];
  Object *var_l = alloc_var();
  *var_l = args[0];
  Object *var_p = alloc_var();
  *var_p = args[1];
  Object params[1];
  Object *var_linenumv = closure[0];
  Object *var_lineposv = closure[1];
// Begin line 199
  setline(199);
// Begin line 198
  setline(198);
// compilenode returning *var_l
  *var_linenumv = *var_l;
  if (*var_l == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 200
  setline(200);
// Begin line 199
  setline(199);
// compilenode returning *var_p
  *var_lineposv = *var_p;
  if (*var_p == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_util_linenum458(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[17];
  Object params[1];
  Object *var_linenumv = closure[0];
// compilenode returning *var_linenumv
  return *var_linenumv;
}
Object meth_util_linepos459(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[18];
  Object params[1];
  Object *var_lineposv = closure[0];
// compilenode returning *var_lineposv
  return *var_lineposv;
}
Object meth_util_vtag460(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[19];
  Object params[1];
  Object *var_vtagv = closure[0];
// compilenode returning *var_vtagv
  return *var_vtagv;
}
Object meth_util_noexec461(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[20];
  Object params[1];
  Object *var_noexecv = closure[0];
// compilenode returning *var_noexecv
  return *var_noexecv;
}
Object meth_util_target462(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[21];
  Object params[1];
  Object *var_targetv = closure[0];
// compilenode returning *var_targetv
  return *var_targetv;
}
Object meth_util_engine463(Object self, int nparams, Object *args, int32_t flags) {
  Object params[1];
  if (strlit464 == NULL) {
    strlit464 = alloc_String("native");
  }
// compilenode returning strlit464
  return strlit464;
}
Object meth_util_extensions465(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[23];
  Object params[1];
  Object *var_extensionsv = closure[0];
// compilenode returning *var_extensionsv
  return *var_extensionsv;
}
Object meth_util_debug466(Object self, int nparams, Object *args, int32_t flags) {
  Object *var_s = args + 0;
  Object params[1];
  return nothing;
}
Object meth_util_hex468(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[25];
  Object *var_num = alloc_var();
  *var_num = args[0];
  Object params[1];
  Object *var_hexdigits = closure[0];
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 228
  setline(228);
// Begin line 227
  setline(227);
  if (strlit469 == NULL) {
    strlit469 = alloc_String("");
  }
// compilenode returning strlit469
  var_s = alloc_var();
  *var_s = strlit469;
  if (strlit469 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 233
  setline(233);
  Object while470;
  while (1) {
// Begin line 234
  setline(234);
// Begin line 228
  setline(228);
// compilenode returning *var_num
  Object num471 = alloc_Float64(0.0);
// compilenode returning num471
  params[0] = num471;
  Object opresult473 = callmethod(*var_num, ">", 1, params);
// compilenode returning opresult473
    while470 = opresult473;
    if (!istrue(opresult473)) break;
  Object *var_i = alloc_var();
  *var_i = undefined;
// Begin line 230
  setline(230);
// Begin line 229
  setline(229);
// compilenode returning *var_num
  Object num474 = alloc_Float64(16.0);
// compilenode returning num474
  params[0] = num474;
  Object modulus476 = callmethod(*var_num, "%", 1, params);
// compilenode returning modulus476
  var_i = alloc_var();
  *var_i = modulus476;
  if (modulus476 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 230
  setline(230);
// compilenode returning *var_s
// compilenode returning *var_i
  Object num477 = alloc_Float64(1.0);
// compilenode returning num477
  params[0] = num477;
  Object sum479 = callmethod(*var_i, "+", 1, params);
// compilenode returning sum479
// compilenode returning *var_hexdigits
  params[0] = sum479;
  Object call480 = callmethod(*var_hexdigits, "at",
    1, params);
// compilenode returning call480
  params[0] = call480;
  Object opresult482 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult482
  *var_s = opresult482;
  if (opresult482 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 232
  setline(232);
// Begin line 231
  setline(231);
// compilenode returning *var_num
// compilenode returning *var_i
  params[0] = *var_i;
  Object diff485 = callmethod(*var_num, "-", 1, params);
// compilenode returning diff485
  *var_num = diff485;
  if (diff485 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 233
  setline(233);
// Begin line 232
  setline(232);
// compilenode returning *var_num
  Object num487 = alloc_Float64(16.0);
// compilenode returning num487
  params[0] = num487;
  Object quotient489 = callmethod(*var_num, "/", 1, params);
// compilenode returning quotient489
  *var_num = quotient489;
  if (quotient489 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  }
// compilenode returning while470
// Begin line 234
  setline(234);
// compilenode returning *var_s
  return *var_s;
}
Object meth_util_apply499(Object realself, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)realself;
  Object **closure = uo->data[1];
  Object *var_i = alloc_var();
  *var_i = args[0];
  Object params[1];
  Object *var_min = closure[0];
  Object *var_s = closure[1];
  Object *var_joiner = closure[2];
  Object *var_iterable = closure[3];
  Object self = *closure[4];
// Begin line 244
  setline(244);
// Begin line 245
  setline(245);
// Begin line 242
  setline(242);
// compilenode returning *var_i
// compilenode returning *var_min
  params[0] = *var_min;
  Object opresult502 = callmethod(*var_i, "/=", 1, params);
// compilenode returning opresult502
  Object if500;
  if (istrue(opresult502)) {
// Begin line 244
  setline(244);
// Begin line 243
  setline(243);
// compilenode returning *var_s
// compilenode returning *var_joiner
  params[0] = *var_joiner;
  Object opresult504 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult504
  *var_s = opresult504;
  if (opresult504 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
    if500 = nothing;
  } else {
  }
// compilenode returning if500
// Begin line 245
  setline(245);
// compilenode returning *var_s
// compilenode returning *var_i
// compilenode returning *var_iterable
  params[0] = *var_i;
  Object call506 = callmethod(*var_iterable, "at",
    1, params);
// compilenode returning call506
  params[0] = call506;
  Object opresult508 = callmethod(*var_s, "++", 1, params);
// compilenode returning opresult508
  *var_s = opresult508;
  if (opresult508 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
  return nothing;
}
Object meth_util_join491(Object self, int nparams, Object *args, int32_t flags) {
  struct UserObject *uo = (struct UserObject*)self;
  Object **closure = uo->data[26];
  Object *var_joiner = alloc_var();
  *var_joiner = args[0];
  Object *var_iterable = alloc_var();
  *var_iterable = args[1];
  Object params[1];
  Object *var_ind = alloc_var();
  *var_ind = undefined;
  Object *var_min = alloc_var();
  *var_min = undefined;
  Object *var_s = alloc_var();
  *var_s = undefined;
// Begin line 239
  setline(239);
// Begin line 247
  setline(247);
// Begin line 238
  setline(238);
// compilenode returning *var_iterable
  Object call492 = callmethod(*var_iterable, "indices",
    0, params);
// compilenode returning call492
// compilenode returning call492
  *var_ind = call492;
  if (call492 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 240
  setline(240);
// Begin line 247
  setline(247);
// Begin line 239
  setline(239);
// compilenode returning *var_ind
  Object call493 = callmethod(*var_ind, "first",
    0, params);
// compilenode returning call493
// compilenode returning call493
  *var_min = call493;
  if (call493 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 241
  setline(241);
// Begin line 240
  setline(240);
  if (strlit494 == NULL) {
    strlit494 = alloc_String("");
  }
// compilenode returning strlit494
  var_s = alloc_var();
  *var_s = strlit494;
  if (strlit494 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 245
  setline(245);
// Begin line 241
  setline(241);
// compilenode returning *var_ind
// Begin line 245
  setline(245);
// Begin line 247
  setline(247);
  Object obj497 = alloc_obj2(1,2);
// OBJECT OUTER DEC outer
  adddatum2(obj497, self, 0);
  addmethod2(obj497, "outer", &reader_util_outer_498);
  adddatum2(obj497, self, 0);
  block_savedest(obj497);
  Object **closure499 = createclosure(5);
  addtoclosure(closure499, var_min);
  addtoclosure(closure499, var_s);
  addtoclosure(closure499, var_joiner);
  addtoclosure(closure499, var_iterable);
  Object *selfpp510 = alloc_var();
  *selfpp510 = self;
  addtoclosure(closure499, selfpp510);
  struct UserObject *uo499 = (struct UserObject*)obj497;
  uo499->data[1] = (Object)closure499;
  addmethod2(obj497, "apply", &meth_util_apply499);
  set_type(obj497, 0);
// compilenode returning obj497
  setclassname(obj497, "Block<util:496>");
// compilenode returning obj497
  params[0] = *var_ind;
  Object iter495 = callmethod(*var_ind, "iter", 1, params);
  while(1) {
    Object cond495 = callmethod(iter495, "havemore", 0, NULL);
    if (!istrue(cond495)) break;
    params[0] = callmethod(iter495, "next", 0, NULL);
    callmethod(obj497, "apply", 1, params);
  }
// compilenode returning *var_ind
// Begin line 247
  setline(247);
// compilenode returning *var_s
  return *var_s;
}
Object module_util_init() {
  Object self = alloc_obj2(100, 100);
  setclassname(self, "Module<util>");
  Object *var_HashMap = alloc_var();
  *var_HashMap = alloc_HashMapClassObject();
  Object params[1];
  Object *var___compilerRevision = alloc_var();
  *var___compilerRevision = undefined;
  Object *var_verbosityv = alloc_var();
  *var_verbosityv = undefined;
  Object *var_outfilev = alloc_var();
  *var_outfilev = undefined;
  Object *var_infilev = alloc_var();
  *var_infilev = undefined;
  Object *var_modnamev = alloc_var();
  *var_modnamev = undefined;
  Object *var_runmodev = alloc_var();
  *var_runmodev = undefined;
  Object *var_buildtypev = alloc_var();
  *var_buildtypev = undefined;
  Object *var_gracelibPathv = alloc_var();
  *var_gracelibPathv = undefined;
  Object *var_linenumv = alloc_var();
  *var_linenumv = undefined;
  Object *var_lineposv = alloc_var();
  *var_lineposv = undefined;
  Object *var_vtagv = alloc_var();
  *var_vtagv = undefined;
  Object *var_noexecv = alloc_var();
  *var_noexecv = undefined;
  Object *var_targetv = alloc_var();
  *var_targetv = undefined;
  Object *var_versionNumber = alloc_var();
  *var_versionNumber = undefined;
  Object *var_extensionsv = alloc_var();
  *var_extensionsv = undefined;
  Object *var_hexdigits = alloc_var();
  *var_hexdigits = undefined;
// Begin line 2
  setline(2);
// Import of io
  if (module_io == NULL)
    module_io = module_io_init();
  Object *var_io = alloc_var();
  *var_io = module_io;
// compilenode returning undefined
// Begin line 3
  setline(3);
// Import of sys
  if (module_sys == NULL)
    module_sys = module_sys_init();
  Object *var_sys = alloc_var();
  *var_sys = module_sys;
// compilenode returning undefined
// Begin line 5
  setline(5);
// Import of buildinfo
  if (module_buildinfo == NULL)
    module_buildinfo = module_buildinfo_init();
  Object *var_buildinfo = alloc_var();
  *var_buildinfo = module_buildinfo;
// compilenode returning undefined
// Begin line 6
  setline(6);
// Begin line 5
  setline(5);
  Object bool3 = alloc_Boolean(0);
// compilenode returning bool3
  var___compilerRevision = alloc_var();
  *var___compilerRevision = bool3;
  if (bool3 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 7
  setline(7);
// Begin line 6
  setline(6);
  Object num4 = alloc_Float64(30.0);
// compilenode returning num4
  var_verbosityv = alloc_var();
  *var_verbosityv = num4;
  if (num4 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 8
  setline(8);
// Begin line 247
  setline(247);
// Begin line 7
  setline(7);
// compilenode returning module_io
  Object call5 = callmethod(module_io, "output",
    0, params);
// compilenode returning call5
// compilenode returning call5
  var_outfilev = alloc_var();
  *var_outfilev = call5;
  if (call5 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 9
  setline(9);
// Begin line 247
  setline(247);
// Begin line 8
  setline(8);
// compilenode returning module_io
  Object call6 = callmethod(module_io, "input",
    0, params);
// compilenode returning call6
// compilenode returning call6
  var_infilev = alloc_var();
  *var_infilev = call6;
  if (call6 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 10
  setline(10);
// Begin line 9
  setline(9);
  if (strlit7 == NULL) {
    strlit7 = alloc_String("main");
  }
// compilenode returning strlit7
  var_modnamev = alloc_var();
  *var_modnamev = strlit7;
  if (strlit7 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 11
  setline(11);
// Begin line 10
  setline(10);
  if (strlit8 == NULL) {
    strlit8 = alloc_String("build");
  }
// compilenode returning strlit8
  var_runmodev = alloc_var();
  *var_runmodev = strlit8;
  if (strlit8 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 12
  setline(12);
// Begin line 11
  setline(11);
  if (strlit9 == NULL) {
    strlit9 = alloc_String("bc");
  }
// compilenode returning strlit9
  var_buildtypev = alloc_var();
  *var_buildtypev = strlit9;
  if (strlit9 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 13
  setline(13);
// Begin line 12
  setline(12);
  Object bool10 = alloc_Boolean(0);
// compilenode returning bool10
  var_gracelibPathv = alloc_var();
  *var_gracelibPathv = bool10;
  if (bool10 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 14
  setline(14);
// Begin line 13
  setline(13);
  Object num11 = alloc_Float64(1.0);
// compilenode returning num11
  var_linenumv = alloc_var();
  *var_linenumv = num11;
  if (num11 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 15
  setline(15);
// Begin line 14
  setline(14);
  Object num12 = alloc_Float64(1.0);
// compilenode returning num12
  var_lineposv = alloc_var();
  *var_lineposv = num12;
  if (num12 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 16
  setline(16);
// Begin line 15
  setline(15);
  Object bool13 = alloc_Boolean(0);
// compilenode returning bool13
  var_vtagv = alloc_var();
  *var_vtagv = bool13;
  if (bool13 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 17
  setline(17);
// Begin line 16
  setline(16);
  Object bool14 = alloc_Boolean(0);
// compilenode returning bool14
  var_noexecv = alloc_var();
  *var_noexecv = bool14;
  if (bool14 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 18
  setline(18);
// Begin line 17
  setline(17);
  if (strlit15 == NULL) {
    strlit15 = alloc_String("c");
  }
// compilenode returning strlit15
  var_targetv = alloc_var();
  *var_targetv = strlit15;
  if (strlit15 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 19
  setline(19);
// Begin line 18
  setline(18);
  if (strlit16 == NULL) {
    strlit16 = alloc_String("0.0.3");
  }
// compilenode returning strlit16
  var_versionNumber = alloc_var();
  *var_versionNumber = strlit16;
  if (strlit16 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 21
  setline(21);
// Begin line 247
  setline(247);
// Begin line 19
  setline(19);
// compilenode returning *var_HashMap
  Object call17 = callmethod(*var_HashMap, "new",
    0, params);
// compilenode returning call17
// compilenode returning call17
  var_extensionsv = alloc_var();
  *var_extensionsv = call17;
  if (call17 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 26
  setline(26);
  addmethod2(self, "runOnNew(1)else", &meth_util_runOnNew_40_1_41_else18);
// compilenode returning 
// Begin line 122
  setline(122);
  block_savedest(self);
  Object **closure32 = createclosure(12);
  addtoclosure(closure32, var_outfilev);
  addtoclosure(closure32, var_verbosityv);
  addtoclosure(closure32, var_vtagv);
  addtoclosure(closure32, var_runmodev);
  addtoclosure(closure32, var_buildtypev);
  addtoclosure(closure32, var_noexecv);
  addtoclosure(closure32, var_modnamev);
  addtoclosure(closure32, var_gracelibPathv);
  addtoclosure(closure32, var_targetv);
  addtoclosure(closure32, var_versionNumber);
  addtoclosure(closure32, var_extensionsv);
  addtoclosure(closure32, var_infilev);
  struct UserObject *uo32 = (struct UserObject*)self;
  uo32->data[2] = (Object)closure32;
  addmethod2(self, "parseargs", &meth_util_parseargs32);
// compilenode returning 
// Begin line 140
  setline(140);
  block_savedest(self);
  Object **closure283 = createclosure(3);
  addtoclosure(closure283, var_verbosityv);
  addtoclosure(closure283, var_vtagv);
  addtoclosure(closure283, var_modnamev);
  struct UserObject *uo283 = (struct UserObject*)self;
  uo283->data[3] = (Object)closure283;
  addmethod2(self, "log_verbose", &meth_util_log_verbose283);
// compilenode returning 
// Begin line 146
  setline(146);
  block_savedest(self);
  Object **closure327 = createclosure(1);
  addtoclosure(closure327, var_outfilev);
  struct UserObject *uo327 = (struct UserObject*)self;
  uo327->data[4] = (Object)closure327;
  addmethod2(self, "outprint", &meth_util_outprint327);
// compilenode returning 
// Begin line 154
  setline(154);
  block_savedest(self);
  Object **closure331 = createclosure(4);
  addtoclosure(closure331, var_vtagv);
  addtoclosure(closure331, var_modnamev);
  addtoclosure(closure331, var_linenumv);
  addtoclosure(closure331, var_lineposv);
  struct UserObject *uo331 = (struct UserObject*)self;
  uo331->data[5] = (Object)closure331;
  addmethod2(self, "syntax_error", &meth_util_syntax_error331);
// compilenode returning 
// Begin line 162
  setline(162);
  block_savedest(self);
  Object **closure369 = createclosure(4);
  addtoclosure(closure369, var_vtagv);
  addtoclosure(closure369, var_modnamev);
  addtoclosure(closure369, var_linenumv);
  addtoclosure(closure369, var_lineposv);
  struct UserObject *uo369 = (struct UserObject*)self;
  uo369->data[6] = (Object)closure369;
  addmethod2(self, "type_error", &meth_util_type_error369);
// compilenode returning 
// Begin line 170
  setline(170);
  block_savedest(self);
  Object **closure407 = createclosure(4);
  addtoclosure(closure407, var_vtagv);
  addtoclosure(closure407, var_modnamev);
  addtoclosure(closure407, var_linenumv);
  addtoclosure(closure407, var_lineposv);
  struct UserObject *uo407 = (struct UserObject*)self;
  uo407->data[7] = (Object)closure407;
  addmethod2(self, "warning", &meth_util_warning407);
// compilenode returning 
// Begin line 174
  setline(174);
  block_savedest(self);
  Object **closure446 = createclosure(1);
  addtoclosure(closure446, var_verbosityv);
  struct UserObject *uo446 = (struct UserObject*)self;
  uo446->data[8] = (Object)closure446;
  addmethod2(self, "verbosity", &meth_util_verbosity446);
// compilenode returning 
// Begin line 177
  setline(177);
  block_savedest(self);
  Object **closure447 = createclosure(1);
  addtoclosure(closure447, var_outfilev);
  struct UserObject *uo447 = (struct UserObject*)self;
  uo447->data[9] = (Object)closure447;
  addmethod2(self, "outfile", &meth_util_outfile447);
// compilenode returning 
// Begin line 180
  setline(180);
  block_savedest(self);
  Object **closure448 = createclosure(1);
  addtoclosure(closure448, var_infilev);
  struct UserObject *uo448 = (struct UserObject*)self;
  uo448->data[10] = (Object)closure448;
  addmethod2(self, "infile", &meth_util_infile448);
// compilenode returning 
// Begin line 183
  setline(183);
  block_savedest(self);
  Object **closure449 = createclosure(1);
  addtoclosure(closure449, var_modnamev);
  struct UserObject *uo449 = (struct UserObject*)self;
  uo449->data[11] = (Object)closure449;
  addmethod2(self, "modname", &meth_util_modname449);
// compilenode returning 
// Begin line 186
  setline(186);
  block_savedest(self);
  Object **closure450 = createclosure(1);
  addtoclosure(closure450, var_runmodev);
  struct UserObject *uo450 = (struct UserObject*)self;
  uo450->data[12] = (Object)closure450;
  addmethod2(self, "runmode", &meth_util_runmode450);
// compilenode returning 
// Begin line 189
  setline(189);
  block_savedest(self);
  Object **closure451 = createclosure(1);
  addtoclosure(closure451, var_buildtypev);
  struct UserObject *uo451 = (struct UserObject*)self;
  uo451->data[13] = (Object)closure451;
  addmethod2(self, "buildtype", &meth_util_buildtype451);
// compilenode returning 
// Begin line 192
  setline(192);
  block_savedest(self);
  Object **closure452 = createclosure(1);
  addtoclosure(closure452, var_gracelibPathv);
  struct UserObject *uo452 = (struct UserObject*)self;
  uo452->data[14] = (Object)closure452;
  addmethod2(self, "gracelibPath", &meth_util_gracelibPath452);
// compilenode returning 
// Begin line 196
  setline(196);
  block_savedest(self);
  Object **closure453 = createclosure(1);
  addtoclosure(closure453, var_linenumv);
  struct UserObject *uo453 = (struct UserObject*)self;
  uo453->data[15] = (Object)closure453;
  addmethod2(self, "setline", &meth_util_setline453);
// compilenode returning 
// Begin line 200
  setline(200);
  block_savedest(self);
  Object **closure455 = createclosure(2);
  addtoclosure(closure455, var_linenumv);
  addtoclosure(closure455, var_lineposv);
  struct UserObject *uo455 = (struct UserObject*)self;
  uo455->data[16] = (Object)closure455;
  addmethod2(self, "setPosition", &meth_util_setPosition455);
// compilenode returning 
// Begin line 202
  setline(202);
  block_savedest(self);
  Object **closure458 = createclosure(1);
  addtoclosure(closure458, var_linenumv);
  struct UserObject *uo458 = (struct UserObject*)self;
  uo458->data[17] = (Object)closure458;
  addmethod2(self, "linenum", &meth_util_linenum458);
// compilenode returning 
// Begin line 205
  setline(205);
  block_savedest(self);
  Object **closure459 = createclosure(1);
  addtoclosure(closure459, var_lineposv);
  struct UserObject *uo459 = (struct UserObject*)self;
  uo459->data[18] = (Object)closure459;
  addmethod2(self, "linepos", &meth_util_linepos459);
// compilenode returning 
// Begin line 208
  setline(208);
  block_savedest(self);
  Object **closure460 = createclosure(1);
  addtoclosure(closure460, var_vtagv);
  struct UserObject *uo460 = (struct UserObject*)self;
  uo460->data[19] = (Object)closure460;
  addmethod2(self, "vtag", &meth_util_vtag460);
// compilenode returning 
// Begin line 211
  setline(211);
  block_savedest(self);
  Object **closure461 = createclosure(1);
  addtoclosure(closure461, var_noexecv);
  struct UserObject *uo461 = (struct UserObject*)self;
  uo461->data[20] = (Object)closure461;
  addmethod2(self, "noexec", &meth_util_noexec461);
// compilenode returning 
// Begin line 214
  setline(214);
  block_savedest(self);
  Object **closure462 = createclosure(1);
  addtoclosure(closure462, var_targetv);
  struct UserObject *uo462 = (struct UserObject*)self;
  uo462->data[21] = (Object)closure462;
  addmethod2(self, "target", &meth_util_target462);
// compilenode returning 
// Begin line 217
  setline(217);
  addmethod2(self, "engine", &meth_util_engine463);
// compilenode returning 
// Begin line 220
  setline(220);
  block_savedest(self);
  Object **closure465 = createclosure(1);
  addtoclosure(closure465, var_extensionsv);
  struct UserObject *uo465 = (struct UserObject*)self;
  uo465->data[23] = (Object)closure465;
  addmethod2(self, "extensions", &meth_util_extensions465);
// compilenode returning 
// Begin line 222
  setline(222);
  addmethod2(self, "debug", &meth_util_debug466);
// compilenode returning 
// Begin line 226
  setline(226);
// Begin line 225
  setline(225);
  if (strlit467 == NULL) {
    strlit467 = alloc_String("0123456789abcdef");
  }
// compilenode returning strlit467
  var_hexdigits = alloc_var();
  *var_hexdigits = strlit467;
  if (strlit467 == undefined)
    callmethod(nothing, "assignment", 0, NULL);
// compilenode returning nothing
// Begin line 234
  setline(234);
  block_savedest(self);
  Object **closure468 = createclosure(1);
  addtoclosure(closure468, var_hexdigits);
  struct UserObject *uo468 = (struct UserObject*)self;
  uo468->data[25] = (Object)closure468;
  addmethod2(self, "hex", &meth_util_hex468);
// compilenode returning 
// Begin line 247
  setline(247);
  addmethod2(self, "join", &meth_util_join491);
// compilenode returning 
  return self;
}
int main(int argc, char **argv) {
  initprofiling();
  gracelib_argv(argv);
  Object params[1];
  undefined = alloc_Undefined();
  nothing = alloc_Nothing();
  Object tmp_argv = alloc_List();
  int i; for (i=0; i<argc; i++) {
    params[0] = alloc_String(argv[i]);
    callmethod(tmp_argv, "push", 1,params);
  }
  module_sys_init_argv(tmp_argv);
  module_util_init();
  gracelib_stats();
  return 0;
}
